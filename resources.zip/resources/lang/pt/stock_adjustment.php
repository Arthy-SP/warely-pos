<?php
 return [
"stock_adjustment" => "Ajuste de estoque",
"stock_adjustments" => "ajustes de estoque",
"list" => "Listar configurações de estoque",
"add" => "Adicionar ajuste de estoque",
"all_stock_adjustments" => "Todas as configurações de estoque",
"search_product" => "Pesquisar produtos para ajuste de estoque",
"adjustment_type" => "Tipo de ajuste",
"normal" => "normal",
"anormal" => "anormal",
"total_amount" => "Valor total",
"total_amount_recovered" => "Valor total recuperado",
"reason_for_stock_adjustment" => "Razão",
"stock_adjustment_added_successfully" => "Ajustando estoque adicionado com sucesso",
"search_products" => "Pesquisar produtos",
"delete_success" => "Ajuste de estoque excluído com sucesso",
"view_details" => "Veja detalhes do ajuste de estoque",
];
