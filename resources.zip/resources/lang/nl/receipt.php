<?php
 return [
"product" => "Artikel",
"qty" => "Aantal stuks",
"unit_price" => "Eenheid prijs",
"subtotal" => "Subtotaal",
"discount" => "Korting",
"tax" => "Tax",
"total" => "Totaal",
"invoice_number" => "Factuur nr.",
"date" => "Datum",
"receipt_settings" => "Ontvangstinstellingen",
"receipt_settings_mgs" => "Alle ontvangst-gerelateerde instellingen voor deze locatie",
"print_receipt_on_invoice" => "Factuur automatisch afdrukken na finaliseren",
"receipt_printer_type" => "Bonprinter Type",
"receipt_settings_updated" => "Ontvangstinstelling succesvol bijgewerkt",
];
