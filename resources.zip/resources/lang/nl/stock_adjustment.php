<?php
 return [
"stock_adjustment" => "Voorraadaanpassing",
"stock_adjustments" => "Voorraadaanpassingen",
"list" => "Lijst Voorraad Aanpassingen",
"add" => "Voorraadaanpassing toevoegen",
"all_stock_adjustments" => "Alle voorraadaanpassingen",
"search_product" => "Zoek producten voor voorraadcorrectie",
"adjustment_type" => "Aanpassingstype",
"normal" => "Normal",
"abnormal" => "Abnormaal",
"total_amount" => "Totaalbedrag",
"total_amount_recovered" => "Totale hoeveelheid hersteld",
"reason_for_stock_adjustment" => "Reden",
"stock_adjustment_added_successfully" => "Voorraadaanpassing succesvol toegevoegd",
"search_products" => "Zoek producten",
"delete_success" => "Voorraadaanpassing succesvol verwijderd",
"view_details" => "Bekijk details van de voorraadaanpassing",
];
