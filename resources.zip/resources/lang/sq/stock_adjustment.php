<?php
 return [
"stock_adjustment" => "Rregullimi i stoqeve",
"stock_adjustments" => "Rregullimet e stoqeve",
"list" => "Rregullimet e aksioneve të listës",
"add" => "Shto rregullimin e stoqeve",
"all_stock_adjustments" => "Të gjitha rregullimet e aksioneve",
"search_product" => "Kërko produkte për rregullimin e stokut",
"adjustment_type" => "Lloji i rregullimit",
"normal" => "Normal",
"abnormal" => "Jonormal",
"total_amount" => "Shuma totale",
"total_amount_recovered" => "Shuma totale e rikuperuar",
"reason_for_stock_adjustment" => "Arsyeja",
"stock_adjustment_added_successfully" => "Rregullimi i stoqeve u shtua me sukses",
"search_products" => "Kërko Produkte",
"delete_success" => "Rregullimi i stoqeve është fshirë me sukses",
"view_details" => "Shikoni detajet e përshtatjes së stoqeve",
];
