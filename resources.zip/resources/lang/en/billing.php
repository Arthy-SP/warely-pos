<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Brand Language Lines
    |--------------------------------------------------------------------------
    |
    | The following language lines are used for Brand CRUD operations.
    |
    */

    'sms_otp_charge' => 'SMS OTP Charge',
    'promotional_sms_charge' => 'Promotional SMS Charge',
    'whatsapp_message_charge' => 'Whatsapp Message Charge',
    'email_charge' => 'Email Charge',
    'country' => 'Country',
    "action"=> "Action",
    "add_new_service_charges" => "Add new service charges",
    "edit_service_charges" => "Update service charges",
    "delete_service_charges" => "Delete service charges",
    "are_you_sure_you_want_to_delete" => "Are you sure you want to delete",
    "top_up_amount" => "Top Up amount"
    ];
