<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Business Language Lines
    |--------------------------------------------------------------------------
    |
    | The following language lines are used during registration of a business.
    |
    */
    "business_GTO" => "GTO",
    "business_outlets" => "Outlets/Locations",
    "manage_outlets" => "Manage outlets",
    "outlet_name" => "Name",
    "outlet_file_formats" => "File formats pattern",
    "outlet_report_formats" => "Report formats pattern",
    "outlet_report_type" => "Report Type",
    "outlet_file_date" => "File date format",
    "outlet_report_date" => "Report date format",
    "outlet_start_date" => "Start date"
];
