<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Restaurant Language Lines
    |--------------------------------------------------------------------------
    */

    'nfc' => 'NFC Cards',
    'title' => 'NFC Cards',
    'view' => 'NFC Cards',
    'settings' => "Settings",
    'list' => "Card List",
    'card_no' => "Card Number",
    'status' => "Status",
    'balance' => "Balance",
    'meta_data' => "Meta Data",
    'remark' => "Remark",
    'sr_no' => "Serial Number",
    'is_verified' => "Is Verified?",
    'edit_nfc_settings' => "Update Settings",
    'transaction_type' => "Transaction Type",
    'payment_method' => "Payment Method",
    'amount' => "Amount",
    'created_at' => "Created At",
    'debit' => "Debit",
    'credit' => "Credit",
    'date' => "Date",
    'promos' => "Promos",
    'nfc_promos' => "NFC Promos",
    'add_nfc_promo' => "Add NFC Promo",
    'edit_nfc_promo' => "Edit NFC Promo",
    'title' => "Title",
    'topup_amount' => "Topup Amount",
    'promo_amount' => "Extra Amount",
    'nfc_amount' => "NFC Amount",
    'expiry_at' => "Expiry At",
    'status' => "Status",
    'name' => "Full Name",
    'phone' => "Phone Number",
    'ic_number' => "Identity Card Number",
    'date' => "Date",
    "total" => "Total Amount",
    'nfc_report' => "NFC Topup Reports",
    'reports' => "Topup Reports",
    'show' => "Show Topup Transactions",
    "total_topup_amount" => "Total Topup Amount",
    "total_promo_amount" => "Total Promo Amount",
    "total_amount" => "Total Amount",
    "promoamount" => "Promo Amount",
    "expiry_date" =>"Expiry Date",
    "action"=>"Action",
    "void_reason"=>"Void Reason",
    "nfc_balance_reports" => "NFC Balance Reports",
];
?>