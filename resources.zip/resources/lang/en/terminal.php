<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Restaurant Language Lines
    |--------------------------------------------------------------------------
    */

    'terminal' => 'Terminals/POS',
    'title' => 'Terminals/POS',
    'view' => 'Terminals/POS',
    'device_name' => "Device Name",
    'device_id' => "Device Id",
    'status' => "Status",
    'created_at' => "Created At",
    'terminals' => "Terminals/POS",
    'add_terminal' => "Add Terminal/POS",
    'edit_terminal' => "Edit Terminal/POS",
    'name' => "Name",
    'show' => "Show Terminal/POS",
    "action" => "Action",
    "last_logged_in" => "Last Logged In",
    "unique_id" => "Unique Id",
    "location" => "Location Name",
    "fcm_token" => "FCM Token",
    "terminal_type" => "Type"
];
?>