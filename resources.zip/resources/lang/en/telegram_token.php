<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Tax Rates Language Lines
    |--------------------------------------------------------------------------
    |
    | The following language lines are used for Tax Rate CRUD operations.
    |
    */

    'bot_token' => 'Bot Token',
    'manage_your_telegram_bot_tokens' => 'Manage your telegram bot tokens',
    'all_your_bot_tokens' => 'All your bot tokens',
    'name' => 'Name',
    'rate' => 'Tax Rate %',
    'added_success' => 'Bot token added successfully',
    'updated_success' => 'Bot token updated successfully',
    'deleted_success' => 'Bot token deleted successfully',
    'add_telegram_bot_token' => 'Add Telegram Bot Token',
    'edit_bot_token' => 'Edit Bot Token',
    'token_id'=> 'Token id',
    
    'add_telegram_channel_and_groups' => 'Add new telegram channel or group',
    'telegram_channel_group_added_success' => 'Telegram channel and group added successfully',
    'telegram_channel_group_updated_success' => 'Telegram channel and group updated successfully',
    'telegram_channel_and_groups' => 'All your telegram channels and groups',
    'edit_telegram_channel_groups' => 'Edit telegram channel/group',
    'business_name' => 'Business Name',
    'business_location_name' => 'Business Location Name',
    'channel_or_group_id' => 'Channel/Group id',
    'serial_no'=> 'Serial No.',
    'channel' => 'Channel',
    'group' => 'Group',
    'type' => 'Type'
];
