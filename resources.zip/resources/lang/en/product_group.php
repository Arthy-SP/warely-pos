<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Restaurant Language Lines
    |--------------------------------------------------------------------------
    */

    'title' => 'Product Groups',
    'view' => 'Product Groups',
    'name' => "Name",
    'edit_product_group' => "Edit Product Group",
    'add_product_group' => "Add Product Group"
];