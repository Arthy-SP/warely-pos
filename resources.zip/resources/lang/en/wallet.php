<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Business Language Lines
    |--------------------------------------------------------------------------
    |
    | The following language lines are used during registration of a business.
    |
    */
    "wallet" => "Wallet",
    "wallet_business" => "Business name",
    "wallet_Contact" => "Contact Number",
    "wallet_business_mail" => "Mail ID",
    "wallet_last_top_up_on" => "Last Top-up on",
    'wallet_balance' => 'Wallet Balance: :balance',
    "wallet_action" => "Action",
    "wallet_details" => "Wallet details",
    "wallet_transations" => "Transations",
    "wallet_balance_report" => "Wallet Balance Report",
    "wallet_top_up_amount" => "TOP UP AMOUNT",
    "wallet_sms_charges" => "SMS CHARGES",
    "wallet_whatapp_charges" => "WHATSAPP CHARGES",
    "wallet_pramotional_charges" => "PROMOTIONAL MESSAGES",
    "wallet_remaining_balance" => "Remaining balance",
    "wallet_total_top_up_amount" => "Top up amount",
    "wallet_total_deduct" => "Amount deducted",
    'wallet_total_balance' => 'Wallet Balance',
    "wallet_transations" => "Wallet transations",
    "manage_wallet" => "Manage wallet",
    "balance" => "Balance"

];
