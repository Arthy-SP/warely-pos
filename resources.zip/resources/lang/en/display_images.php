<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Restaurant Language Lines
    |--------------------------------------------------------------------------
    */

    'queue' => 'Queue',
    'title' => 'Queues',
    'manage_your_queue_schema' => 'Manage Queue Schema',
    'all_your_queue_schema' => 'All Queue Schema',
    'prefix' => 'Prefix',
    'start' => 'Queue Start',
    'end' => 'Queue End',
    'status' => 'Status',
    'estimated_wait_time' => 'Estimated Wait Time',
    'minutes' => 'Minutes',
    'pax_range_start' => 'Pax Range Start',
    'pax_range_end' => 'Pax Range End',
    'add_queue_schema' => 'Add Queue Schema',
    'edit_queue_schema' => 'Edit Queue Schema',
    'queue_schema_name' => 'Queue Schema name',
    'short_description' => 'Description',
    'select_queue_schema' => 'Select Queue Schema',
    'show_queue_schema' => 'Show Queue Schema',
    'queue_schema_label' => 'Queue Schema label',
    'queue_management' => 'Queue Management',
    'add_pax_category' => 'Add Pax Category',
    'edit_pax_category' => 'Edit Pax Category',
    'pax_category_name' => 'Pax Category name',
    'pax_categories' => 'Pax Categories',
    'manage_your_pax_categories' => 'Manage Pax Categories',
    'all_your_pax_categories' => 'All Pax Categories',
    'start_from' => 'Start From',
    'end_to' => 'End To',
    'pax_range' => 'Pax Range',
    'generate_qr' => 'Generate QR',
    'manage_display_images' => 'Manage Display Images',
    'display_images' => 'Display Images',
    'all_display_images' => 'All Display Images',
    'display_image' => 'Display Image',
    'image' => 'Image',
    'generate_qr' => 'Generate QR & Links',
    'manage_generate_qr' => 'Manage Generate QR & Links',
    'generate_links' => 'Generate Links',
    'manage_generate_links' => 'Manage Generate Links',
    'register_queue_url' => 'Register URL',
    'queue_display_url' => 'Display URL',
    'register_queue_qr' => 'Register Queue QR',
    'manage_your_queue_settings' => 'Manage Queue Settings',
    'all_your_queue_settings' => 'All Queue Settings',
    'skip_queue_limit' => 'Skip Queue Limit',
    'settings' => 'Settings',
    'image_type' => "Image Type",
    'status' => "Status",
    'edit_display_image' => 'Edit Display Image',
    'orientation' => 'Image Orientation'
];
