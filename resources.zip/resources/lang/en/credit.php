<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Restaurant Language Lines
    |--------------------------------------------------------------------------
    */

    'title' => 'Credit',
    'promo_title' => 'Title',
    'view' => 'Credit',
    'settings' => "Settings",
    'list' => "Credit List",
    'status' => "Status",
    'balance' => "Balance",
    'remark' => "Remark",
    'transaction_type' => "Transaction Type",
    'payment_type' => "Payment Type",
    'amount' => "Amount",
    'created_at' => "Created At",
    'debit' => "Debit",
    'credit' => "Credit",
    'date' => "Date",
    'expiry_at' => "Expiry At",
    'status' => "Status",
    'phone' => "Phone Number",
    'payment_method' => "Payment Method",
    'date' => "Date",
    "total" => "Total Amount",
    'reports' => "Topup Reports",
    "total_topup_amount" => "Total Topup Amount",
    "total_promo_amount" => "Total Promo Amount",
    'show' => "Show Topup Transactions",
    "total_amount" => "Total Amount",
    "expiry_date" =>"Expiry Date",
    "action"=>"Action",
    "promoamount" => "Promo Amount",
    'topup_amount' => "Topup Amount",
    'promo_amount' => "Extra Amount",
    "void_reason"=>"Void Reason",
    'promos' => "Promos",
    'credit_promos' => "Credit Promos",
    'add_credit_promo' => "Add Credit Promo",
    'edit_credit_promo' => "Edit Credit Promo",
    'credit_amount' => "Credit Amount",
    'name'=>"Name",
    'opening_balance'=>'Opening Balance',
    'closing_balance'=>'Closing Balance',
    'transaction'=>'Transaction',
    'timestamp'=>'Timestamp'
];
?>