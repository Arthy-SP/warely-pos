<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Commission Language Lines
    |--------------------------------------------------------------------------
    |
    | The following language lines are used for Commission CRUD operations.
    |
    */

    'commission' => 'Commission',
    'add_commission' => 'Add Commission',
    'name' => 'Commission Name',
    'connection_type' => 'Connection Type',
    'capability_profile' => 'Capability Profile',
    'ip_address' => 'IP Address',
    'port' => 'Port',
    'path' => 'Path',
    'added_success' => 'Printer added successfully',
    'manage_your_printers' => 'Manage your Printers',
    'all_your_printer' => 'All configured Printers',
    'deleted_success' => 'Printer deleted successfully',
    'edit_printer_setting' => 'Edit Printer Configuration',
    'commission_group' => 'Commission Group',
    'character_per_line' => 'Characters per line',
    'printer_name' => 'Printer name',
    'updated_success' => 'Printer updated successfully',
    'edit_printer' => 'Edit Printer',
    'commission_percentage' => 'Commission Percentage',
];
