<?php
 return [
"stock_adjustment" => "Ajuste de Stock",
"stock_adjustments" => "Ajustes de stock",
"list" => "Listar ajustes de stock",
"add" => "Agregar ajuste de stock",
"all_stock_adjustments" => "Todos los ajustes de stock",
"search_product" => "Buscar productos para el ajuste de stock",
"adjustment_type" => "Tipo de ajuste",
"normal" => "Normal",
"abnormal" => "Anormal",
"total_amount" => "Cantidad total",
"total_amount_recovered" => "Cantidad total recuperada",
"reason_for_stock_adjustment" => "Razón",
"stock_adjustment_added_successfully" => "Ajuste de stock agregado con éxito",
"search_products" => "Buscar Productos",
"delete_success" => "Ajuste de stock eliminado con éxito",
"view_details" => "Ver detalles de ajuste de stock",
];
