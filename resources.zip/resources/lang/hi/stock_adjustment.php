<?php
 return [
"stock_adjustment" => "स्टॉक समायोजन",
"stock_adjustments" => "स्टॉक समायोजन",
"list" => "स्टॉक समायोजन सूची",
"add" => "स्टॉक समायोजन जोड़ें",
"all_stock_adjustments" => "सभी स्टॉक समायोजन",
"search_product" => "स्टॉक समायोजन के लिए उत्पाद खोजें",
"adjustment_type" => "समायोजन प्रकार",
"normal" => "सामान्य",
"abnormal" => "असामान्य",
"total_amount" => "कुल रकम",
"total_amount_recovered" => "कुल राशि पुनर्प्राप्त",
"reason_for_stock_adjustment" => "कारण",
"stock_adjustment_added_successfully" => "स्टॉक समायोजन सफलतापूर्वक जोड़ा",
"search_products" => "उत्पादों को खोजना",
"delete_success" => "शेयर समायोजन सफलतापूर्वक हटा दिया गया",
"view_details" => "स्टॉक समायोजन विवरण देखें",
];
