<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class AddPrinterGroupToApiPrinterTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('api_printer', function (Blueprint $table) {
            $table->integer('printer_group_id')->index()->after('business_location_id');
            $table->boolean('print_receipt')->default(1)->after('business_location_id');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('api_printer', function (Blueprint $table) {
            //
        });
    }
}
