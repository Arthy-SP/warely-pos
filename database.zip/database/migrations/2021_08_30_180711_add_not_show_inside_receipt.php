<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class AddNotShowInsideReceipt extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('products', function (Blueprint $table) {
            $table->boolean('not_for_receipt')->default(false)->after('not_for_selling');
            $table->boolean('not_for_digital_ordering')->default(false)->after('not_for_selling');
            $table->boolean('not_for_pickup_delivery')->default(false)->after('not_for_selling');
            $table->integer('sequence')->default(0)->after('not_for_selling');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('products', function (Blueprint $table) {
            $table->dropColumn('not_for_receipt');
            $table->dropColumn('sequence');
        });
    }
}
