<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateCampaignListsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('campaign_lists', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->integer('business_id')->index();
            $table->integer('location_id')->index();
            $table->integer('layout_id')->default(0);
            $table->integer('coupon_id')->default(0);
            $table->integer('campaign_id')->default(0);
            $table->bigInteger('sender_id')->default(0);
            $table->bigInteger('receiver_id')->default(0);
            $table->bigInteger('telegram_user_id')->default(0);
            $table->integer('approval_id')->default(0);
            $table->longText('front_layout_code')->nullable();
            $table->longText('back_layout_code')->nullable();
            $table->longText('full_image')->nullable();
            $table->dateTime('issue_date');
            $table->dateTime('expiry_date');
            $table->dateTime('redeem_date');
            $table->string('qr_sn',255)->nullable(true);
            $table->integer('status')->default(0);
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('campaign_lists');
    }
}
