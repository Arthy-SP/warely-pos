<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateWalletTransactionsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('wallet_transactions', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->unsignedInteger('wallet_id')->nullable();
            $table->string('transaction_type', 100)->nullable();
            $table->string('transaction_id', 191)->nullable();
            $table->timestamp('transaction_date')->nullable();
            $table->string('status', 100)->nullable();
            $table->decimal('amount', 22, 4)->nullable();
            $table->string('payment_type', 100)->nullable();
            $table->string('service_type', 100)->nullable();
            $table->decimal('available_balance', 22, 4)->nullable();
            $table->boolean('is_void')->default(0);
            $table->string('void_reason', 191)->nullable();
            $table->text('description')->nullable();
            $table->string('phone')->nullable();
            $table->unsignedInteger('business_id')->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('wallet_transactions');
    }
}
