<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateBusinessOutletsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */

    public function up()
    {
        Schema::create('business_outlets', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->unsignedInteger('business_id')->nullable();
            $table->string('name');
            $table->date('start_date'); 
            $table->enum('report_type', ['hourly', 'date_wise']);
            $table->json('file_formats')->nullable(); 
            $table->json('date_formats')->nullable();
            $table->json('report_formats')->nullable(); 
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('business_outlets');
    }
}
