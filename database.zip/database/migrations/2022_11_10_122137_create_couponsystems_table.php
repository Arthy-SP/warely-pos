<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateCouponsystemsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('couponsystems', function (Blueprint $table) {
            $table->increments('id');
            $table->integer('business_id')->index();
            $table->integer('location_id')->index();
            $table->string('coupon_name', 50)->nullable();
            $table->integer('coupon_qty')->default(0);
            $table->decimal('coupon_value', 22, 4)->default(0);
            $table->dateTime('start_date');
            $table->integer('expiry_day')->default(0);
            $table->integer('min_purchase')->default(0);
            $table->integer('min_pax')->default(0);
            $table->tinyInteger('status')->default(0);
            $table->longText('front_image')->nullable();
            $table->longText('back_image')->nullable();
            $table->longText('qr_image')->nullable();
            $table->integer('layout_id')->default(0);
            $table->longText('extra_field_data')->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('couponsystems');
    }
}
