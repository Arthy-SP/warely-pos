<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateUserChannelReferralsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('user_channel_referrals', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->unsignedBigInteger('telegram_user_id')->references('id')->on('telegram_user');
            $table->unsignedBigInteger('telegram_channel_id')->references('id')->on('telegram_channels');
            $table->string('referral_by')->nullable();
            $table->string('referral_to')->nullable();
            $table->string('status')->nullable();
            $table->string('action_taken_by')->default('null');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('user_channel_referrals');
    }
}
