<?php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateNfcTransactionsTable extends Migration
{
    public function up()
    {
        Schema::create('nfc_transactions', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->unsignedBigInteger('card_no');
            $table->enum('transaction_type', ['credit', 'debit']);
            $table->string('payment_method');
            $table->decimal('amount', 10, 2);
            $table->text('note')->nullable();
            $table->unsignedBigInteger('business_id');
            $table->unsignedBigInteger('location_id');
            $table->timestamps();

            // Foreign keys
            $table->foreign('card_no')->references('id')->on('nfc_cards');
            $table->foreign('business_id')->references('id')->on('business');
            $table->foreign('location_id')->references('id')->on('business_locations');
        });
    }

    public function down()
    {
        Schema::dropIfExists('nfc_transactions');
    }
}
