<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class AddLunchDinnerTimeToBusinessLocationsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('business_locations', function (Blueprint $table) {
            $table->string('lunch_start_time')->default('11:00:00')->after('lalamove_sk');
            $table->string('lunch_end_time')->default('15:00:00')->after('lalamove_sk');
            $table->string('dinner_start_time')->default('17:00:00')->after('lalamove_sk');
            $table->string('dinner_end_time')->default('22:00:00')->after('lalamove_sk');
            $table->boolean('not_pin_authentication')->default(false)->after('lalamove_sk');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('business_locations', function (Blueprint $table) {
            //
        });
    }
}
