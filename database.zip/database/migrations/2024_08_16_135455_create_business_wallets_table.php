<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateBusinessWalletsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('business_wallets', function (Blueprint $table) {
            $table->increments("id");
            $table->decimal('balance', 22, 4)->default(0.0);
            $table->enum('status', ['active', 'inactive'])->default('active');
            $table->string('remark', 191)->nullable();
            $table->string('service_charge', 191)->nullable();
            $table->unsignedInteger('business_id')->nullable();
            $table->unsignedInteger('created_by')->nullable();
            $table->timestamps(); 
            $table->softDeletes(); 
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('business_wallets');
    }
}
