<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateTableReservationsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */

    public function up()
    {
        Schema::create('table_reservations', function (Blueprint $table) {
            $table->id(); // id
            $table->string('first_name'); // first_name
            $table->string('last_name'); // last_name
            $table->string('phone'); // phone
            $table->string('email'); // email
            $table->dateTime('booking_date'); // booking_date
            $table->foreignId('slot_id')->constrained('slots'); // slot_id
            $table->foreignId('business_id')->constrained('business'); // business_id
            $table->foreignId('location_id')->constrained('business_locations'); // location_id
            $table->foreignId('terminal_id')->constrained('terminals'); // terminal_id
            $table->foreignId('table_id')->constrained('res_tables'); // table_id
            $table->string('payment_status'); // payment_status
            $table->integer('pax'); // pax (number of people)
            $table->timestamps(); // created_at, updated_at
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('table_reservations');
    }
}
