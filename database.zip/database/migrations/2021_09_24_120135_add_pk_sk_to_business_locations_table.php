<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class AddPkSkToBusinessLocationsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('business_locations', function (Blueprint $table) {
            $table->string('stripe_pk')->nullable()->after('custom_field4');
            $table->string('stripe_sk')->nullable()->after('custom_field4');
            $table->string('lalamove_pk')->nullable()->after('custom_field4');
            $table->string('lalamove_sk')->nullable()->after('custom_field4');
            $table->string('cds')->nullable()->after('default_cash_float');
            $table->string('cds_logo_image')->nullable()->after('default_cash_float');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('business_locations', function (Blueprint $table) {
            //
        });
    }
}
