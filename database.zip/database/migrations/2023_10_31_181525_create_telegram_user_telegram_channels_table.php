<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateTelegramUserTelegramChannelsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('telegram_user_telegram_channels', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->unsignedBigInteger('telegram_user_id')->references('id')->on('telegram_user');
            $table->unsignedBigInteger('telegram_channel_id')->references('id')->on('telegram_channels');
            $table->string('new_status')->nullable();
            $table->string('old_status')->nullable();
            $table->string('lucky_draw_number')->nullable();
            $table->string('action_taken_by')->default('null');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('telegram_user_telegram_channels');
    }
}
