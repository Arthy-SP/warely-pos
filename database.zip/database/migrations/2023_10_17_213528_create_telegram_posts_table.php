<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateTelegramPostsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('telegram_posts', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->string('name')->nullable();
            $table->integer('business_id')->default(0);
            $table->integer('business_location_id')->default(0);
            $table->string('bot_token_id')->nullable();
            $table->string('channel_or_group_id')->nullable();
            $table->longText('post_description')->nullable();
            $table->string('image')->nullable();
            $table->integer('created_by')->unsigned()->default(0);
            $table->dateTime('scheduled_at')->nullable();
            $table->tinyInteger('is_sended')->default(0);
            $table->softDeletes();
            $table->timestamps();

            //Index Columns
            $table->index('scheduled_at');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('telegram_posts');
    }
}
