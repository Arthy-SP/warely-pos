<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateCampaignsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('campaigns', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->integer('business_id')->index();
            $table->integer('location_id')->index();
            $table->integer('layout_id')->default(0);
            $table->integer('coupon_id')->default(0);
            $table->string('name',255)->nullable(true);
            $table->integer('coupon_qty')->default(0);
            $table->integer('coupon_qty_redeem')->default(0);
            $table->string('coupon_password',50)->nullable(true);
            $table->string('coupon_api',255)->nullable(true);
            $table->dateTime('expiry_date');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('campaigns');
    }
}
