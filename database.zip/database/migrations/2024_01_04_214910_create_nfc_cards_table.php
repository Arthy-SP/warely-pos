<?php
// database/migrations/xxxx_xx_xx_create_nfc_cards_table.php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateNfcCardsTable extends Migration
{
    public function up()
    {
        Schema::create('nfc_cards', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->string('card_no');
            $table->string('status');
            $table->decimal('balance', 10, 2);
            $table->text('remark')->nullable();
            $table->unsignedBigInteger('business_id');
            $table->unsignedBigInteger('location_id');
            $table->json('nfc_meta_data')->nullable();
            $table->timestamps();

            // Foreign keys
            $table->foreign('business_id')->references('id')->on('business');
            $table->foreign('location_id')->references('id')->on('business_locations');
        });
    }

    public function down()
    {
        Schema::dropIfExists('nfc_cards');
    }
}
