<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class AddRefundAllToTransactionsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('transactions', function (Blueprint $table) {
            $table->string('order_no')->nullable()->after('ref_no');
            $table->integer('refund_all')->default(0)->after('type_for_api');
            $table->integer('pending_order')->default(0)->after('type_for_api');
            $table->integer('sent')->default(0)->after('type_for_api');
            $table->integer('pickup_completed')->default(0)->after('type_for_api');
            $table->integer('pickup_sent')->default(0)->after('type_for_api');
            $table->string('lalamove_orderRef')->nullable()->after('pickup_completed');
            $table->string('lalamove_status')->nullable()->after('pickup_completed');
            $table->text('lalamove_result')->nullable()->after('pickup_completed');
            $table->decimal('delivery_charges', 22, 4)->default(0)->after('service_charges');
            $table->decimal('deposit', 22, 4)->default(0)->after('lalamove_result');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('transactions', function (Blueprint $table) {
            //
        });
    }
}
