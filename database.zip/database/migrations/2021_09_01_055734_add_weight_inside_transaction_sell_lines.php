<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class AddWeightInsideTransactionSellLines extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('transaction_sell_lines', function (Blueprint $table) {
            $table->decimal('weight', 22, 4)->default(0)->after('variation_id');
            $table->string('quantity_returned_note', 20)->nullable()->after('quantity_returned');
            $table->integer('serve_later_quantity')->default(0)->after('sub_unit_id');
            $table->integer('printed')->default(1)->after('sub_unit_id');
            $table->integer('change_price')->default(0)->after('sub_unit_id');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('transaction_sell_lines', function (Blueprint $table) {
            $table->dropColumn('weight');
        });
    }
}
