<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreatsReservationsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('reservations', function (Blueprint $table) {
            $table->increments('id');
            $table->integer('business_id')->unsigned();
            $table->foreign('business_id')->references('id')->on('business')->onDelete('cascade');
            $table->integer('location_id')->nullable()->index();
            $table->char('prefix', 10)->nullable();
            $table->string('name', 50)->nullable();
            $table->integer('pax')->default(0);
            $table->dateTime('reservation_date');
            $table->char('phone_number', 15)->nullable();
            $table->decimal('deposit', 22, 4)->default(0);
            $table->tinyInteger('void')->default(0);
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('reservations');
    }
}
