<?php

return [
    
    'accountSid' => env('YOUR_TWILIO_ACCOUNT_SID'),
    'authToken'=> env('YOUR_TWILIO_AUTH_TOKEN'),
    'serviceSid' => env('YOUR_TWILIO_SERVICE_SID'),   
];
