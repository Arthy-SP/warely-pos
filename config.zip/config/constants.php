<?php

return [
    
     /*
    |--------------------------------------------------------------------------
    | App Constants
    |--------------------------------------------------------------------------
    |List of all constants for the app
    */

    'langs' => [
        'en' => ['full_name' => 'English', 'short_name' => 'English'],
        'es' => ['full_name' => 'Spanish - Español', 'short_name' => 'Spanish'],
        'sq' => ['full_name' => 'Albanian - Shqip', 'short_name' => 'Albanian'],
        'hi' => ['full_name' => 'Hindi - हिंदी', 'short_name' => 'Hindi'],
        'nl' => ['full_name' => 'Dutch', 'short_name' => 'Dutch'],
        'fr' => ['full_name' => 'French - Français', 'short_name' => 'French'],
        'de' => ['full_name' => 'German - Deutsch', 'short_name' => 'German'],
        'ar' => ['full_name' => 'Arabic - العَرَبِيَّة', 'short_name' => 'Arabic'],
        'tr' => ['full_name' => 'Turkish - Türkçe', 'short_name' => 'Turkish'],
        'id' => ['full_name' => 'Indonesian', 'short_name' => 'Indonesian'],
        'ps' => ['full_name' => 'Pashto', 'short_name' => 'Pashto'],
        'pt' => ['full_name' => 'Portuguese', 'short_name' => 'Portuguese'],
        'vi' => ['full_name' => 'Vietnamese', 'short_name' => 'Vietnamese'],
        'ce' => ['full_name' => 'Chinese', 'short_name' => ''],
        'ro' => ['full_name' => 'Romanian', 'short_name' => ''],
        'lo' => ['full_name' => 'Lao', 'short_name' => '']
    ],
    'langs_rtl' => ['ar'],
    'non_utf8_languages' => ['ar', 'hi', 'ps'],
    
    'document_size_limit' => '1000000', //in Bytes,
    'image_size_limit' => '5000000', //in Bytes

    'asset_version' => 47,

    'disable_purchase_in_other_currency' => true,
    
    'iraqi_selling_price_adjustment' => false,

    'currency_precision' => 2, //Maximum 4
    'quantity_precision' => 2,  //Maximum 4

    'product_img_path' => 'img',
    'product_variation_img_path' => 'retail_product_images',

    'cds_path' => 'cds',
    'success_path' => 'success_image',
    'coupons_path' => 'coupons',
    'modifier_image_path' => 'modifier_images',

    'enable_sell_in_diff_currency' => false,
    'currency_exchange_rate' => 1,
    'orders_refresh_interval' => 600, //Auto refresh interval on Kitchen and Orders page in seconds,

    'default_date_format' => 'm/d/Y', //Default date format to be used if session is not set. All valid formats can be found on https://www.php.net/manual/en/function.date.php
    
    'new_notification_count_interval' => 60, //Interval to check for new notifications in seconds;Default is 60sec
    
    'administrator_usernames' => env('ADMINISTRATOR_USERNAMES'),
    'allow_registration' => env('ALLOW_REGISTRATION', true),
    'app_title' => env('APP_TITLE'),
    'mpdf_temp_path' => storage_path('app/pdf'), //Temporary path used by mpdf
    
    'document_upload_mimes_types' => ['application/pdf' => '.pdf',
        'text/csv' => '.csv',
        'application/zip' => '.zip',
        'application/msword' => '.doc',
        'application/vnd.openxmlformats-officedocument.wordprocessingml.document' => '.docx',
        'image/jpeg' => '.jpeg',
        'image/jpg' => '.jpg',
        'image/png' => '.png'
        
    ], //List of MIME type: https://developer.mozilla.org/en-US/docs/Web/HTTP/Basics_of_HTTP/MIME_types/Common_types
    'show_report_606' => false,
    'show_report_607' => false,
    'whatsapp_base_url' => 'https://wa.me',
    'enable_crm_call_log' => false,
    'enable_product_bulk_edit' => false,  //Will be depreciated in future
    'enable_convert_draft_to_invoice' => false, //Experimental beta feature.
    'enable_download_pdf' => false,         //Experimental feature
    'invoice_scheme_separator' => '-',
    'business_location_document_upload_mimes_types' => [
        'image/jpeg' => '.jpeg',
        'image/jpg' => '.jpg',
        'image/png' => '.png',
        'video/x-flv' => '.flv',
        'video/mp4' => '.mp4',
        'video/x-msvideo' => '.avi',
        'video/x-ms-wmv' => '.wmv'
    ],
    'business_location_image_upload_mimes_types' => [
        'image/jpeg' => '.jpeg',
        'image/jpg' => '.jpg',
        'image/png' => '.png'
    ],
    'lalamoveBaseURL' => 'https://rest.sandbox.lalamove.com', // URl to Lalamove Sandbox API //https://rest.lalamove.com //Production
    "businessStartTime" => " 17:30:01", // Morning 6 AM
    "businessEndTime" => " 17:29:59", // Morning 5:59 AM
    "businessStartTimeDefault" => " 00:00:00",
    "businessEndTimeDefault" => " 23:59:59",
    "setBusinessTime" => true,
    'specialAccountBusinessIds' => env('SPECIAL_ACCOUNT_BUSINESS_IDS'),
    'awsS3Env' => env('AWS_S3_ENV'),
    'awsS3BaseUrl' => env('AWS_URL'),
    'qRAppBaseUrl' => env('QR_APP_BASE_URL', "https://dev.qr.warelypos.com"),
    'AWS_SECRET_ACCESS_KEY' => env('AWS_SECRET_ACCESS_KEY'),
    'AWS_ACCESS_KEY_ID' => env('AWS_ACCESS_KEY_ID'),
    'AWS_BUCKET' => env('AWS_BUCKET'),
    'AWS_DEFAULT_REGION' => env('AWS_DEFAULT_REGION'),
    'WHATSAPP_API_URL' => env('WHATSAPP_API_URL') ? env('WHATSAPP_API_URL') : 'https://graph.facebook.com/v17.0/100527563135823/messages',
    'WHATSAPP_API_AUTH_TOKEN' => env('WHATSAPP_API_AUTH_TOKEN') ? env('WHATSAPP_API_AUTH_TOKEN') : 'Bearer EAADbpEwnTxMBO161OHB5XhC67jqfhwoQfqf086wN4D2wZBHytNWtF6SNmxiPqxW3rdekgYSQ2FKCDNmYcWz4rCpBPD2pF8rB8ZBGhiCtjEf4GW5PYvugwr6k2kfMmUKjp56sqZCMakKPzECc2x93BIa7Tz7u235YdeRMjFUHI04Ss1ubGSR2fP9U5HDuENQBhOBn4fTNrrRLWnS',
    'WA_QUEUE_TABLE_ASSIGN_TEMPLATE' => env('WA_QUEUE_TABLE_ASSIGN_TEMPLATE'),
    'WA_QUEUE_REGISTRATION_TEMPLATE' => env('WA_QUEUE_REGISTRATION_TEMPLATE'),
    "DISPLAY_IMAGE_TYPE" => [
        'Queue' => 'Queue', 
        'QR' => 'QR', 
        'CDS' => 'CDS', 
        'Kiosk' => 'Kiosk'
    ],
    "DISPLAY_IMAGE_STATUS" => [
        'Active' => 'Active', 
        'Inactive' => 'Inactive'
    ],
    "DISPLAY_IMAGE_ORIENTATION" => [
        'Portrait' => 'Portrait', 
        'Landscape' => 'Landscape',
        'Square' => 'Square'
    ],
    "QR_APP_URL" => env('QR_APP_URL')
];
