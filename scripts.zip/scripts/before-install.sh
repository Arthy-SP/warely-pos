#!/bin/bash

exec > /var/log/before_install_output.log 2> /var/log/before_install_error.log

cp /home/warelypos-backend/.env /tmp > /dev/null -f
cp -r /home/warelypos-backend/public/uploads /tmp/ > /dev/null -f

rm -f /etc/nginx/sites-available/default > /dev/null
rm -f /etc/nginx/sites-enabled/default > /dev/null