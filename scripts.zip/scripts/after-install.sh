#!/bin/bash

ENVFILE=/tmp/warelypos-backend/.env
AWS_REGION=ap-southeast-1
SECRET_ID=

exec > /var/log/after_install_output.log 2> /var/log/after_install_error.log

exec > /var/log/after_install_output.log 2> /var/log/after_install_error.log

for S_ID in $SECRET_ID
do
  aws secretsmanager get-secret-value --secret-id $S_ID --region $AWS_REGION | \
    jq -r '.SecretString' | \
    jq -r "to_entries|map(\"\n\(.key)=\\\"\(.value|tostring)\\\"\")|.[]" | tee -a $ENVFILE > /dev/null
done

eval $(cat $ENVFILE | sed 's/^/export /')

#Restore uploads
if [ -d /tmp/uploads ]
then
  rm -rf /tmp/warelypos-backend/public/uploads > /dev/null -f
  mv /tmp/uploads /tmp/warelypos-backend/public/ > /dev/null -f
fi

while [ ! -f /usr/bin/composer ] && [ ! -f /usr/local/bin/composer ]; do
    echo "Waiting for composer to install.."
    sleep 1
done
echo "Composer is installed."

mkdir -p /tmp/warelypos-backend/storage/framework/{views,cache,sessions}
cd /tmp/warelypos-backend
composer install

rm -rf /home/warelypos-backend
mv /tmp/warelypos-backend /home/
chmod -R 777 /home/warelypos-backend
