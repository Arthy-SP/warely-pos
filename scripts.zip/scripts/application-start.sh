#!/bin/bash

exec > /var/log/appstart_install_output.log 2> /var/log/appstart_install_error.log

mv /home/warelypos-backend/scripts/nginx-conf /etc/nginx/sites-available/warelypos
ln -s /etc/nginx/sites-available/warelypos /etc/nginx/sites-enabled/
service nginx restart

APPLICATION=
GROUP=
#Remove Deployments freeup space
DEPLOYMENT_ID=$(aws deploy get-deployment-group --application-name ${APPLICATION} --deployment-group-name ${GROUP} --region ap-southeast-1 | jq .deploymentGroupInfo.deploymentGroupId | tr -d '"')
DEPLOYMENT_FAILD=$(aws deploy list-deployments --application-name ${APPLICATION} --deployment-group-name ${GROUP} --include-only-statuses Failed --region ap-southeast-1 | jq .deployments | jq -c '.[]' | tr -d '"')
DEPLOYMENT_SUCCESS=$(aws deploy list-deployments --application-name ${APPLICATION} --deployment-group-name ${GROUP} --include-only-statuses Succeeded --region ap-southeast-1 | jq .deployments | jq -c '.[]' | tr -d '"')
DEPLOYMENT_FAILD=($DEPLOYMENT_FAILD)
DEPLOYMENT_SUCCESS=($DEPLOYMENT_SUCCESS)

for dep in "${DEPLOYMENT_FAILD[@]:1}"
do
  echo "$dep Removed!"
  rm -rf /opt/codedeploy-agent/deployment-root/$DEPLOYMENT_ID/$dep
done

for dep in "${DEPLOYMENT_SUCCESS[@]:1}"
do
  echo "$dep Removed!"
  rm -rf /opt/codedeploy-agent/deployment-root/$DEPLOYMENT_ID/$dep
done
