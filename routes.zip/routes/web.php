<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

include_once('install_r.php');

Route::middleware(['setData'])->group(function () {
    Route::get('/', function () {
        return view('welcome');
    });

    Auth::routes();

    Route::get('/business/register', 'BusinessController@getRegister')->name('business.getRegister');
    Route::post('/business/register', 'BusinessController@postRegister')->name('business.postRegister');
    Route::post('/business/register/check-username', 'BusinessController@postCheckUsername')->name('business.postCheckUsername');
    Route::post('/business/register/check-email', 'BusinessController@postCheckEmail')->name('business.postCheckEmail');

    Route::get('/invoice/{token}', 'SellPosController@showInvoice')
        ->name('show_invoice');
    Route::get('/quote/{token}', 'SellPosController@showInvoice')
        ->name('show_quote');
});

//Routes for authenticated users only
Route::middleware(['setData', 'auth', 'SetSessionData', 'language', 'timezone', 'AdminSidebarMenu', 'CheckUserLogin'])->group(function () {
    Route::get('/home', 'HomeController@index')->name('home');
    Route::get('/home/get-totals', 'HomeController@getTotals');
    Route::get('/home/product-stock-alert', 'HomeController@getProductStockAlert');
    Route::get('/home/purchase-payment-dues', 'HomeController@getPurchasePaymentDues');
    Route::get('/home/sales-payment-dues', 'HomeController@getSalesPaymentDues');
    Route::post('/attach-medias-to-model', 'HomeController@attachMediasToGivenModel')->name('attach.medias.to.model');
    Route::get('/calendar', 'HomeController@getCalendar')->name('calendar');
    
    Route::post('/test-email', 'BusinessController@testEmailConfiguration');
    Route::post('/save-email-details', 'BusinessController@saveEmailConfiguration');
    Route::post('/test-sms', 'BusinessController@testSmsConfiguration');
    Route::get('/business/settings', 'BusinessController@getBusinessSettings')->name('business.getBusinessSettings');
    Route::post('/business/update', 'BusinessController@postBusinessSettings')->name('business.postBusinessSettings');
    Route::get('/user/profile', 'UserController@getProfile')->name('user.getProfile');
    Route::post('/user/update', 'UserController@updateProfile')->name('user.updateProfile');
    Route::post('/user/update-password', 'UserController@updatePassword')->name('user.updatePassword');

    Route::resource('brands', 'BrandController');
    
    Route::resource('payment-account', 'PaymentAccountController');

    Route::resource('tax-rates', 'TaxRateController');

    Route::resource('telegram-tokens', 'TelegramTokenController');
    Route::resource('telegram-channels', 'TelegramController');
    Route::resource('telegram-post', 'TelegramPostController');
    Route::post('telegram/sendpost', 'TelegramPostController@sendPost');
    Route::post('telegram/schedule-post', 'TelegramPostController@schedulePost');
    Route::post('telegram/get-associated-campaigns', 'TelegramPostController@getAssociatedCampaigns');

    Route::resource('units', 'UnitController');

    Route::get('/contacts/payments/{contact_id}', 'ContactController@getContactPayments');
    Route::get('/contacts/map', 'ContactController@contactMap');
    Route::get('/contacts/update-status/{id}', 'ContactController@updateStatus');
    Route::get('/contacts/stock-report/{supplier_id}', 'ContactController@getSupplierStockReport');
    Route::get('/contacts/ledger', 'ContactController@getLedger');
    Route::post('/contacts/send-ledger', 'ContactController@sendLedger');
    Route::get('/contacts/import', 'ContactController@getImportContacts')->name('contacts.import');
    Route::post('/contacts/import', 'ContactController@postImportContacts');
    Route::post('/contacts/check-contact-id', 'ContactController@checkContactId');
    Route::get('/contacts/customers', 'ContactController@getCustomers');
    Route::post('/contacts/send_peppol_email', 'ContactController@sendPeppolEmail');
    Route::resource('contacts', 'ContactController');
    Route::get('/credit-transactions-by-contact-id/{contact_id}', 'ContactController@credit_transactions_by_contact_id');
    Route::get('/credit-transactions-list', 'ContactController@index');


    Route::get('taxonomies-ajax-index-page', 'TaxonomyController@getTaxonomyIndexPage');
    Route::resource('taxonomies', 'TaxonomyController');
    Route::get('taxonomies/manage-products/{id}', 'TaxonomyController@manageProducts');
    Route::post('taxonomies/update-manage-products/{id}', 'TaxonomyController@updateManageProducts');

    Route::resource('variation-templates', 'VariationTemplateController');
    Route::resource('retail-variation-templates', 'RetailVariationTemplateController');

    
    Route::get('/get-products-by-unit', 'ProductController@getProductsByUnit');
    Route::get('/products/stock-history/{id}', 'ProductController@productStockHistory');
    Route::get('/delete-media/{media_id}', 'ProductController@deleteMedia');
    Route::post('/products/mass-deactivate', 'ProductController@massDeactivate');
    Route::get('/products/activate/{id}', 'ProductController@activate');
    Route::get('/products/view-product-group-price/{id}', 'ProductController@viewGroupPrice');
    Route::get('/products/add-selling-prices/{id}', 'ProductController@addSellingPrices');
    Route::post('/products/save-selling-prices', 'ProductController@saveSellingPrices');
    Route::post('/products/mass-delete', 'ProductController@massDestroy');
    Route::get('/products/view/{id}', 'ProductController@view');
    Route::get('/products/view-product-variations-stocks/{id}', 'ProductController@viewVariationStocks');

    Route::get('/products/list', 'ProductController@getProducts');
    Route::get('/products/retail-product-list', 'ProductController@retail_product_list');
    Route::get('/products/list-no-variation', 'ProductController@getProductsWithoutVariations');
    Route::post('/products/bulk-edit', 'ProductController@bulkEdit');
    Route::post('/products/bulk-update', 'ProductController@bulkUpdate');
    Route::post('/products/bulk-update-location', 'ProductController@updateProductLocation');
    Route::get('/products/get-product-to-edit/{product_id}', 'ProductController@getProductToEdit');
    
    Route::post('/products/get_sub_categories', 'ProductController@getSubCategories');
    Route::get('/products/get_sub_units', 'ProductController@getSubUnits');
    Route::post('/products/product_form_part', 'ProductController@getProductVariationFormPart');
    Route::post('/products/get_product_variation_row', 'ProductController@getProductVariationRow');
    Route::post('/products/get_variation_template', 'ProductController@getVariationTemplate');
    Route::get('/products/get_variation_value_row', 'ProductController@getVariationValueRow');
    Route::post('/products/check_product_sku', 'ProductController@checkProductSku');
    Route::get('/products/quick_add', 'ProductController@quickAdd');
    Route::post('/products/save_quick_product', 'ProductController@saveQuickProduct');
    Route::get('/products/get-combo-product-entry-row', 'ProductController@getComboProductEntryRow');
    

    // Retail Flow
    Route::post('/products/get_retail_variation_template', 'ProductController@getRetailVariationTemplate');
    Route::get('/products/get_retail_variation_value_row', 'ProductController@getRetailVariationValueRow');
    Route::post('/products/get_retail_product_variation_row', 'ProductController@getRetailProductVariationRow');




//product bulk price schedule
    Route::get('/products/update_price/schedule', 'ProductBulkPriceScheduleController@index');
    Route::post('/products/update_price/schedule', 'ProductBulkPriceScheduleController@store');
    Route::get('/products/update_price/schedules', 'ProductBulkPriceScheduleController@getSchedules');
    Route::get('/products/update_price/schedules/{category_id}/{page}', 'ProductBulkPriceScheduleController@viewSchedules');
    Route::put('/products/update_price/schedules/{category_id}', 'ProductBulkPriceScheduleController@updateSchedules')->name('schedules.update');
    Route::get('/products/update_price/export/{category_id}', 'ProductBulkPriceScheduleController@exportSchedules');
    Route::delete('/products/update_price/schedules/delete/{category_id}', 'ProductBulkPriceScheduleController@destroySchedules');
    Route::get('/products/update_price/schedules/cron', function () {
        \Artisan::call('schedule:bulk-update-prices');
        return response()->json(['success' => true, 'msg' => 'Cron executed.']);
    });
    Route::resource('products', 'ProductController');

    Route::post('/purchases/update-status', 'PurchaseController@updateStatus');
    Route::get('/purchases/get_products', 'PurchaseController@getProducts');
    Route::get('/purchases/get_suppliers', 'PurchaseController@getSuppliers');
    Route::post('/purchases/get_purchase_entry_row', 'PurchaseController@getPurchaseEntryRow');
    Route::post('/purchases/check_ref_number', 'PurchaseController@checkRefNumber');
    Route::get('/purchases/get_peppol_lists', 'PurchaseController@peppolLists')->name('peppols.index');
    Route::get('/purchases/peppol_create', 'PurchaseController@peppol_create');
    Route::post('/purchases/peppol_store', 'PurchaseController@peppol_store');
    Route::post('/purchases/download_peppol/{id}', 'PurchaseController@download_peppol');
    Route::delete('/purchases/destroy_peppol/{id}', 'PurchaseController@destroy_peppol');
    Route::resource('purchases', 'PurchaseController')->except(['show']);

    Route::get('/toggle-subscription/{id}', 'SellPosController@toggleRecurringInvoices');
    Route::post('/sells/pos/get-types-of-service-details', 'SellPosController@getTypesOfServiceDetails');
    Route::get('/sells/subscriptions', 'SellPosController@listSubscriptions');
    Route::get('/sells/duplicate/{id}', 'SellController@duplicateSell');
    Route::get('/sells/drafts', 'SellController@getDrafts');
    Route::get('/sells/convert-to-draft/{id}', 'SellPosController@convertToInvoice');
    Route::get('/sells/convert-to-proforma/{id}', 'SellPosController@convertToProforma');
    Route::get('/sells/quotations', 'SellController@getQuotations');
    Route::get('/sells/draft-dt', 'SellController@getDraftDatables');
    Route::get('/sells/generate_txt_receipt', 'SellController@generateTxtReceipt');
    Route::get('/sells/generate_custom_report', 'SellController@generateCustomReport');
    Route::post('/sells/get_payment_method', 'SellController@getPaymentMethod');
    Route::resource('sells', 'SellController')->except(['show']);

    Route::get('/import-sales', 'ImportSalesController@index');
    Route::post('/import-sales/preview', 'ImportSalesController@preview');
    Route::post('/import-sales', 'ImportSalesController@import');
    Route::get('/revert-sale-import/{batch}', 'ImportSalesController@revertSaleImport');

    Route::get('/sells/pos/get_product_row/{variation_id}/{location_id}', 'SellPosController@getProductRow');
    Route::post('/sells/pos/get_payment_row', 'SellPosController@getPaymentRow');
    Route::post('/sells/pos/get-reward-details', 'SellPosController@getRewardDetails');
    Route::get('/sells/pos/get-recent-transactions', 'SellPosController@getRecentTransactions');
    Route::get('/sells/pos/get-product-suggestion', 'SellPosController@getProductSuggestion');
    Route::get('/sells/pos/get-featured-products/{location_id}', 'SellPosController@getFeaturedProducts');
    Route::resource('pos', 'SellPosController');

    Route::resource('roles', 'RoleController');

    Route::resource('users', 'ManageUserController');

    Route::resource('bussiness_wallet_transation', 'BusinessWalletTransationController');

    Route::get('/business/wallet/summeries', 'BusinessWalletTransationController@summeries');

    Route::resource('group-taxes', 'GroupTaxController');

    Route::get('/barcodes/set_default/{id}', 'BarcodeController@setDefault');
    Route::resource('barcodes', 'BarcodeController');

    //Invoice schemes..
    Route::get('/invoice-schemes/set_default/{id}', 'InvoiceSchemeController@setDefault');
    Route::resource('invoice-schemes', 'InvoiceSchemeController');
    Route::resource('business-outlets', 'BusinessOutletsController');
    Route::get('business-outlets/outlets/locations', 'BusinessOutletsController@outletsLocations')->name('business_outlets.locations');
    Route::post('/generate_GTO_files', 'API\GTOController@generate_GTO_files');
    Route::post('/upload/gto/sales', 'API\GTOController@uploadGtoSalesFile');
    Route::resource('check-numbers', 'CheckNumberController');

    // NFC Card Management
    Route::group(['prefix' => 'nfc'], function () {
        Route::resource('settings', 'NfcCardController');
        Route::get('list', 'NfcCardController@list');
        Route::get('transactions/{card_no}', 'NfcCardController@card_transactions');
        Route::delete('delete-card/{id}', 'NfcCardController@deleteCard');
        Route::post('update-active-status/{id}', 'NfcCardController@activateCard');
        Route::post('update-inactive-status/{id}', 'NfcCardController@deactivateCard');
        Route::post('void-transaction/{id}', 'NfcCardController@void_transaction');
        Route::resource('promos', 'NfcPromosController');
        Route::resource('reports', 'NfcReportController');
        Route::get('reports/show/{date}', 'NfcReportController@show');
        Route::get('get-reason/{id}','NfcCardController@getReason');
        Route::get('update-user-info/{id}', 'NfcCardController@editNfcCardDetails');
        Route::post('update-card-details/{id}', 'NfcCardController@updateCardDetail');
        Route::get('/transaction/create', 'NfcCardController@createNfcTransaction');
        Route::post('/create-transaction', 'NfcCardController@create_transaction');
    });

    

    //Credit Wallet management

    Route::group(['prefix' => 'credit'], function () {
        Route::resource('settings', 'CreditController');
        Route::get('list', 'CreditController@list');
        Route::post('update-active-status/{id}', 'CreditController@activateCredit');
        Route::post('update-inactive-status/{id}', 'CreditController@deactivateCredit');
        Route::get('update-credit-info/{id}', 'CreditController@editCreditDetails');
        Route::post('update-credit-details/{id}', 'CreditController@updateCreditDetail');
        Route::get('transactions/{credit_id}', 'CreditController@credit_transactions');
        Route::resource('reports', 'CreditReportController');
        Route::get('reports/show/{date}', 'CreditReportController@show');
        Route::get('get-reason/{id}','CreditController@getReason');
        Route::post('void-transaction/{id}', 'CreditController@void_transaction');
        Route::resource('promos', 'CreditPromosController');
        Route::get('/get_all_credit_transactions', 'CreditController@get_all_credit_transactions');
       
    });

    //HRM Module
    Route::group(['prefix' => 'attendance'], function () {
        Route::post('/edit', 'AttendanceController@edit');
        Route::get('/attendance_report', 'AttendanceController@attendance_report');
        Route::get('/history/{user_id}/{date}', 'AttendanceController@history');

        // Route::post('/create-transaction', 'NfcCardController@create_transaction');
    });
    //Print Labels
    Route::get('/labels/show', 'LabelsController@show');
    Route::get('/labels/add-product-row', 'LabelsController@addProductRow');
    Route::get('/labels/preview', 'LabelsController@preview');

    //Reports...
    Route::get('/reports/purchase-report', 'ReportController@purchaseReport');
    Route::get('/reports/sale-report', 'ReportController@saleReport');
    Route::get('/reports/service-staff-report', 'ReportController@getServiceStaffReport');
    Route::get('/reports/service-staff-line-orders', 'ReportController@serviceStaffLineOrders');
    Route::get('/reports/table-report', 'ReportController@getTableReport');
    Route::get('/reports/profit-loss', 'ReportController@getProfitLoss');
    Route::get('/reports/get-opening-stock', 'ReportController@getOpeningStock');
    Route::get('/reports/purchase-sell', 'ReportController@getPurchaseSell');
    Route::get('/reports/customer-supplier', 'ReportController@getCustomerSuppliers');
    Route::get('/reports/stock-report', 'ReportController@getStockReport');
    Route::get('/reports/combined-stock-report', 'ReportController@getcombinedStockReport');
    Route::get('/reports/stock-details', 'ReportController@getStockDetails');
    Route::get('/reports/tax-report', 'ReportController@getTaxReport');
    Route::get('/reports/tax-details', 'ReportController@getTaxDetails');
    Route::get('/reports/trending-products', 'ReportController@getTrendingProducts');
    Route::get('/reports/expense-report', 'ReportController@getExpenseReport');
    Route::get('/reports/stock-adjustment-report', 'ReportController@getStockAdjustmentReport');
    Route::get('/reports/register-report', 'ReportController@getRegisterReport');
    Route::get('/reports/sales-representative-report', 'ReportController@getSalesRepresentativeReport');
    Route::get('/reports/sales-representative-total-expense', 'ReportController@getSalesRepresentativeTotalExpense');
    Route::get('/reports/sales-representative-total-sell', 'ReportController@getSalesRepresentativeTotalSell');
    Route::get('/reports/sales-representative-total-commission', 'ReportController@getSalesRepresentativeTotalCommission');
    Route::get('/reports/stock-expiry', 'ReportController@getStockExpiryReport');
    Route::get('/reports/stock-expiry-edit-modal/{purchase_line_id}', 'ReportController@getStockExpiryReportEditModal');
    Route::post('/reports/stock-expiry-update', 'ReportController@updateStockExpiryReport')->name('updateStockExpiryReport');
    Route::get('/reports/customer-group', 'ReportController@getCustomerGroup');
    Route::get('/reports/product-purchase-report', 'ReportController@getproductPurchaseReport');
    Route::get('/reports/product-sell-report', 'ReportController@getproductSellReport');
    Route::get('/reports/product-sell-report-with-purchase', 'ReportController@getproductSellReportWithPurchase');
    Route::get('/reports/sales-by-receipt', 'ReportController@salesByReceipt');
    Route::get('/peppol/received-invoices', 'ReportControllerCopy@salesByReceipt');
    Route::get('/reports/sales-report', 'ReportController@salesReport');
    Route::get('reports/nfc-balance-reports', 'ReportController@nfcBalanceReport');
    Route::get('/reports/product-report', 'ReportController@productReport');
    Route::get('/reports/voucher-report', 'ReportController@voucherReport');
    Route::get('/reports/discount-report', 'ReportController@discountReport');
    Route::get('/reports/profit-analysis-report', 'ReportController@profitReport');
    Route::get('/reports/product-sell-grouped-report', 'ReportController@getproductSellGroupedReport');
    Route::get('/reports/product-sell-group-by-products', 'ReportController@getproductSellGroupedProducts');
    Route::get('/reports/product-sell-group-by-payments', 'ReportController@getSellReportGroupedByPaymentType');
    Route::get('/reports/lot-report', 'ReportController@getLotReport');
    Route::get('/reports/purchase-payment-report', 'ReportController@purchasePaymentReport');
    Route::get('/reports/sell-payment-report', 'ReportController@sellPaymentReport');
    Route::get('/reports/product-stock-details', 'ReportController@productStockDetails');
    Route::get('/reports/adjust-product-stock', 'ReportController@adjustProductStock');
    Route::get('/reports/get-profit/{by?}', 'ReportController@getProfit');
    Route::get('/reports/items-report', 'ReportController@itemsReport');
    Route::get('/reports/get-stock-value', 'ReportController@getStockValue');
    Route::get('/reports/user-commission-report', 'ReportController@getUserCommission');

    
    Route::get('business-location/activate-deactivate/{location_id}', 'BusinessLocationController@activateDeactivateLocation');

    //Business Location Settings...
    Route::prefix('business-location/{location_id}')->name('location.')->group(function () {
        Route::get('settings', 'LocationSettingsController@index')->name('settings');
        Route::post('settings', 'LocationSettingsController@updateSettings')->name('settings_update');
    });

    //Business Locations...
    Route::post('business-location/check-location-id', 'BusinessLocationController@checkLocationId');
    Route::resource('business-location', 'BusinessLocationController');

    //Invoice layouts..
    Route::resource('invoice-layouts', 'InvoiceLayoutController');

    //Expense Categories...
    Route::resource('expense-categories', 'ExpenseCategoryController');

    //Expenses...
    Route::resource('expenses', 'ExpenseController');

    //Transaction payments...
    // Route::get('/payments/opening-balance/{contact_id}', 'TransactionPaymentController@getOpeningBalancePayments');
    Route::get('/payments/show-child-payments/{payment_id}', 'TransactionPaymentController@showChildPayments');
    Route::get('/payments/view-payment/{payment_id}', 'TransactionPaymentController@viewPayment');
    Route::get('/payments/add_payment/{transaction_id}', 'TransactionPaymentController@addPayment');
    Route::get('/payments/pay-contact-due/{contact_id}', 'TransactionPaymentController@getPayContactDue');
    Route::post('/payments/pay-contact-due', 'TransactionPaymentController@postPayContactDue');
    Route::resource('payments', 'TransactionPaymentController');

    //Printers...
    Route::resource('printers', 'PrinterController');

    //Printer categories...
    Route::resource('printer_categories', 'PrinterCategoriesController');
    
    //User Commission
    Route::resource('user_commission', 'CommissionController');
    Route::get('/get_subcategory', 'CommissionController@getSubCategories');
    Route::post('commission_update', 'CommissionController@commissionUpdate')->name('business.commission_update');
    
    //Manage POS Device
    Route::resource('manage-pos-device', 'ManagePOSController');



    //Printer categories...
    Route::resource('reward_lists', 'RewardListController');

    Route::get('/stock-adjustments/remove-expired-stock/{purchase_line_id}', 'StockAdjustmentController@removeExpiredStock');
    Route::post('/stock-adjustments/get_product_row', 'StockAdjustmentController@getProductRow');
    Route::resource('stock-adjustments', 'StockAdjustmentController');

    Route::get('/cash-register/register-details', 'CashRegisterController@getRegisterDetails');
    Route::get('/cash-register/close-register/{id?}', 'CashRegisterController@getCloseRegister');
    Route::post('/cash-register/close-register', 'CashRegisterController@postCloseRegister');
    Route::resource('cash-register', 'CashRegisterController');

    //Import products
    Route::get('/import-products', 'ImportProductsController@index');
    Route::post('/import-products/store', 'ImportProductsController@store');

    //Sales Commission Agent
    Route::resource('sales-commission-agents', 'SalesCommissionAgentController');

    //Stock Transfer
    Route::get('stock-transfers/print/{id}', 'StockTransferController@printInvoice');
    Route::post('stock-transfers/update-status/{id}', 'StockTransferController@updateStatus');
    Route::resource('stock-transfers', 'StockTransferController');
    
    Route::get('/opening-stock/add/{product_id}', 'OpeningStockController@add');
    Route::post('/opening-stock/save', 'OpeningStockController@save');

    //Customer Groups
    Route::resource('customer-group', 'CustomerGroupController');

    //Import opening stock
    Route::get('/import-opening-stock', 'ImportOpeningStockController@index');
    Route::post('/import-opening-stock/store', 'ImportOpeningStockController@store');

    //Sell return
    Route::resource('sell-return', 'SellReturnController');
    Route::get('sell-return/get-product-row', 'SellReturnController@getProductRow');
    Route::get('/sell-return/print/{id}', 'SellReturnController@printInvoice');
    Route::get('/sell-return/add/{id}', 'SellReturnController@add');
    
    //Backup
    Route::get('backup/download/{file_name}', 'BackUpController@download');
    Route::get('backup/delete/{file_name}', 'BackUpController@delete');
    Route::resource('backup', 'BackUpController', ['only' => [
        'index', 'create', 'store'
    ]]);

    Route::get('selling-price-group/activate-deactivate/{id}', 'SellingPriceGroupController@activateDeactivate');
    Route::get('export-selling-price-group', 'SellingPriceGroupController@export');
    Route::post('import-selling-price-group', 'SellingPriceGroupController@import');

    Route::resource('selling-price-group', 'SellingPriceGroupController');

    Route::resource('notification-templates', 'NotificationTemplateController')->only(['index', 'store']);
    Route::get('notification/get-template/{transaction_id}/{template_for}', 'NotificationController@getTemplate');
    Route::post('notification/send', 'NotificationController@send');

    //Xero URLs
    Route::resource('xero-settings', 'XeroController');
    Route::get('/xero/auth/{clientId}', 'XeroController@authorizeWithXero')->name('xero.auth');
    Route::get('/sync/products', 'XeroController@syncProductsToXero')->name('sync.products');
    Route::get('/sync/orders', 'XeroController@syncOrdersToXero')->name('sync.orders');
    Route::post('save-location-to-session', 'XeroController@getSelectedLocation')->name('get.selected.location');
    // Route::post('/set-location-session', 'XeroController@setLocationSession');
    Route::post('/unset-location-session', 'XeroController@unsetLocationSession')->name('unset.location.session');

    Route::post('/purchase-return/update', 'CombinedPurchaseReturnController@update');
    Route::get('/purchase-return/edit/{id}', 'CombinedPurchaseReturnController@edit');
    Route::post('/purchase-return/save', 'CombinedPurchaseReturnController@save');
    Route::post('/purchase-return/get_product_row', 'CombinedPurchaseReturnController@getProductRow');
    Route::get('/purchase-return/create', 'CombinedPurchaseReturnController@create');
    Route::get('/purchase-return/add/{id}', 'PurchaseReturnController@add');
    Route::resource('/purchase-return', 'PurchaseReturnController', ['except' => ['create']]);

    Route::get('/discount/activate/{id}', 'DiscountController@activate');
    Route::post('/discount/mass-deactivate', 'DiscountController@massDeactivate');
    Route::resource('discount', 'DiscountController');

    Route::get('/voucher/activate/{id}', 'VoucherController@activate');
    Route::post('/voucher/mass-deactivate', 'VoucherController@massDeactivate');
    Route::resource('voucher', 'VoucherController');


    // Queue Management
    Route::group(['prefix' => 'queue'], function () {
        Route::resource('queue-schema', 'Queue\QueueSchemaController');
        Route::resource('pax-categories', 'Queue\QueuePaxCategoriesController');
        Route::get('generate-qr', 'Queue\QueueController@generateQR');
        Route::get('generate-links', 'Queue\QueueController@generateLinks');
        Route::resource('settings', 'Queue\QueueSettingsController');
    });

    Route::get('display-images', 'DisplayImagesController@index');
    Route::post('store', 'DisplayImagesController@store');
    Route::get('edit/{id}', 'DisplayImagesController@edit');
    Route::put('update/{id}', 'DisplayImagesController@update');
    Route::delete('destroy/{id}', 'DisplayImagesController@destroy');

    Route::group(['prefix' => 'account'], function () {
        Route::resource('/account', 'AccountController');
        Route::get('/fund-transfer/{id}', 'AccountController@getFundTransfer');
        Route::post('/fund-transfer', 'AccountController@postFundTransfer');
        Route::get('/deposit/{id}', 'AccountController@getDeposit');
        Route::post('/deposit', 'AccountController@postDeposit');
        Route::get('/close/{id}', 'AccountController@close');
        Route::get('/activate/{id}', 'AccountController@activate');
        Route::get('/delete-account-transaction/{id}', 'AccountController@destroyAccountTransaction');
        Route::get('/get-account-balance/{id}', 'AccountController@getAccountBalance');
        Route::get('/balance-sheet', 'AccountReportsController@balanceSheet');
        Route::get('/trial-balance', 'AccountReportsController@trialBalance');
        Route::get('/payment-account-report', 'AccountReportsController@paymentAccountReport');
        Route::get('/link-account/{id}', 'AccountReportsController@getLinkAccount');
        Route::post('/link-account', 'AccountReportsController@postLinkAccount');
        Route::get('/cash-flow', 'AccountController@cashFlow');
    });
    
    Route::resource('account-types', 'AccountTypeController');

    //Restaurant module
    Route::get('/generate-qr/{id}/{tableName}/{locationId}/{businessId}', 'Restaurant\TableController@generateQR')->name('generateQR');

    Route::group(['prefix' => 'modules'], function () {
        Route::resource('tables', 'Restaurant\TableController');
        Route::resource('modifiers', 'Restaurant\ModifierSetsController');
        Route::resource('floor-plan', 'Restaurant\FloorPlanController');

        //Map modifier to products
        Route::get('/product-modifiers/{id}/edit', 'Restaurant\ProductModifierSetController@edit');
        Route::post('/product-modifiers/{id}/update', 'Restaurant\ProductModifierSetController@update');
        Route::get('/product-modifiers/product-row/{product_id}', 'Restaurant\ProductModifierSetController@product_row');

        Route::get('/add-selected-modifiers', 'Restaurant\ProductModifierSetController@add_selected_modifiers');

        Route::get('/kitchen', 'Restaurant\KitchenController@index');
        Route::get('/kitchen/mark-as-cooked/{id}', 'Restaurant\KitchenController@markAsCooked');
        Route::post('/refresh-orders-list', 'Restaurant\KitchenController@refreshOrdersList');
        Route::post('/refresh-line-orders-list', 'Restaurant\KitchenController@refreshLineOrdersList');

        Route::get('/orders', 'Restaurant\OrderController@index');
        Route::get('/orders/mark-as-served/{id}', 'Restaurant\OrderController@markAsServed');
        Route::get('/data/get-pos-details', 'Restaurant\DataController@getPosDetails');
        Route::get('/orders/mark-line-order-as-served/{id}', 'Restaurant\OrderController@markLineOrderAsServed');
        Route::get('/print-line-order', 'Restaurant\OrderController@printLineOrder');
    });

    Route::get('bookings/get-todays-bookings', 'Restaurant\BookingController@getTodaysBookings');
    Route::resource('bookings', 'Restaurant\BookingController');
    
    Route::resource('types-of-service', 'TypesOfServiceController');
    Route::get('sells/edit-shipping/{id}', 'SellController@editShipping');
    Route::put('sells/update-shipping/{id}', 'SellController@updateShipping');
    Route::get('shipments', 'SellController@shipments');

    Route::post('upload-module', 'Install\ModulesController@uploadModule');
    Route::resource('manage-modules', 'Install\ModulesController')
        ->only(['index', 'destroy', 'update']);
    Route::resource('warranties', 'WarrantyController');

    Route::resource('dashboard-configurator', 'DashboardConfiguratorController')
    ->only(['edit', 'update']);

    Route::get('view-media/{model_id}', 'SellController@viewMedia');

    //common controller for document & note
    Route::get('get-document-note-page', 'DocumentAndNoteController@getDocAndNoteIndexPage');
    Route::post('post-document-upload', 'DocumentAndNoteController@postMedia');
    Route::resource('note-documents', 'DocumentAndNoteController');
    Route::resource('purchase-order', 'PurchaseOrderController');
    Route::get('get-purchase-orders/{contact_id}', 'PurchaseOrderController@getPurchaseOrders');
    Route::get('get-purchase-order-lines/{purchase_order_id}', 'PurchaseController@getPurchaseOrderLines');
    Route::get('edit-purchase-orders/{id}/status', 'PurchaseOrderController@getEditPurchaseOrderStatus');
    Route::put('update-purchase-orders/{id}/status', 'PurchaseOrderController@postEditPurchaseOrderStatus');
    Route::resource('sales-order', 'SalesOrderController')->only(['index']);
    Route::get('get-sales-orders/{customer_id}', 'SalesOrderController@getSalesOrders');
    Route::get('get-sales-order-lines', 'SellPosController@getSalesOrderLines');
    Route::get('edit-sales-orders/{id}/status', 'SalesOrderController@getEditSalesOrderStatus');
    Route::put('update-sales-orders/{id}/status', 'SalesOrderController@postEditSalesOrderStatus');
    Route::get('reports/activity-log', 'ReportController@activityLog');


    // Route::group(['prefix' => 'coupon'], function(){
    Route::get('/get-layout/{id}', 'CouponLayoutController@getLayout');
    Route::get('/get-coupons/{id}', 'CouponsystemController@getcoupons');
    Route::get('/coupons/get-totals', 'CouponsystemController@getTotals');
    Route::get('/coupons/get-campaign', 'CouponsystemController@getCampaign');
    Route::resource('/coupons-layout', 'CouponLayoutController');
    Route::get('/coupons-layout/create', 'CouponLayoutController@create');
    Route::resource('/campaign', 'CampaignController');
    Route::get('/campaign/create', 'CampaignController@create');
    Route::resource('/campaign-list', 'CampaignListController');
    Route::get('/url_image/{id}', 'CampaignListController@urlImage');

    Route::get('/campaign-list/create', 'CampaignListController@create');
    Route::post('/qrupdatestatus', 'CampaignListController@updatestatus');
    Route::resource('/coupons', 'CouponsystemController');
    Route::get('/coupons/create', 'CouponsystemController@create');
    Route::get('coupons-dashboard', 'CouponsystemController@dashboard');
    Route::post('savelayout/{id}', 'CouponsystemController@savelayout');
    // });

    Route::resource('product-groups', 'ProductGroupController');
    Route::post('get_terminals', 'TerminalController@getTerminals');
    Route::resource('terminals', 'TerminalController');

    Route::resource('membership', 'CustomerMembershipController');
    Route::post('/membership/create', 'CustomerMembershipController@create');
    Route::get('/membership/edit/{id}', 'CustomerMembershipController@edit');
    Route::get('/membership/{id}', 'CustomerMembershipController@view');
    Route::get('crm-settings', 'CustomerMembershipController@crmSettings')->name('crm-settings.crmSettings');
    Route::get('points-transactions', 'CustomerMembershipController@pointsTransactions')->name('points-transactions');
    Route::get('/membership/{id}', 'CustomerMembershipController@view');
    Route::get('crm-settings/{id}/edit', 'CustomerMembershipController@crmSettingsedit')->name('crm-settings.edit');
    Route::put('crm-settings/{id}', 'CustomerMembershipController@crmsettingsUpdate')->name('crm-settings.update');

    Route::get('recent-points-transactions/{contact_id}', 'CustomerMembershipController@recentPointsTransactions')->name('recent-points-transactions');
    Route::get('recent-all-transactions', 'CustomerMembershipController@recentAllTransactions')->name('recent-all-transactions');




     // Lazada Routes by Arthy
     Route::get('/lazada/main/{code?}', 'Lazada\LazadaMainController@index')->name('lazap');
     Route::get('/lazada/access/get', 'Lazada\LazadaMainController@getAcessToken');
     Route::get('/lazada/refresh', 'Lazada\LazadaMainController@refreshToken');
     Route::get('/lazada/api-settings', 'Lazada\LazadaMainController@apiSettings');
     Route::post('/lazada/update-api-settings', 'Lazada\LazadaMainController@updateSettings');
     Route::get('/lazada/add/product', 'Lazada\LazadaMainController@AddProduct');
     Route::get('/lazada/update/product', 'Lazada\LazadaMainController@UpdateProduct');
     Route::get('/lazada/product/list', 'Lazada\LazadaMainController@retail_product_list');
     Route::post('/lazada/product/upload', 'Lazada\LazadaMainController@UploadProductToLazada');
     Route::post('/lazada/product/remove', 'Lazada\LazadaMainController@RemoveProductFromLazada');
     Route::get('/lazada/destroy/product', 'Lazada\LazadaMainController@DeleteProduct');
     Route::get('/lazada/image/upload', 'Lazada\LazadaMainController@imageUpload');
     Route::get('/lazada/test', 'Lazada\LazadaMainController@testdata');
     Route::get('/lazada/get/cat_attributes', 'Lazada\LazadaMainController@getCatAttributes')->name('get_product_attributes');
 
     Route::get('/trigger-cron-job', 'Lazada\LazadaMainController@triggerCronJob');
 
      // Shopee Routes by Arthy
      Route::get('/shopee/api-settings', 'Shopee\ShopeeMainController@apiSettings');
      Route::post('/shopee/update-api-settings', 'Shopee\ShopeeMainController@updateSettings');
      Route::get('/shopee/get/code', 'Shopee\ShopeeMainController@index')->name('shopeeapp');
      Route::get('/shopee/main', 'Shopee\ShopeeMainController@getAccessValue')->name('shopeeAcess');
      Route::get('/shopee/product/add', 'Shopee\ShopeeMainController@AddProduct')->name('shopeeproductAdd');
      Route::get('/shopee/get/category', 'Shopee\ShopeeMainController@getCategoriesByParent')->name('CategoryfromParent');
      Route::get('/shopee/get/attribute', 'Shopee\ShopeeMainController@getAttributes')->name('getShopeeAttribute');
      Route::get('/shopee/product/list', 'Shopee\ShopeeMainController@retail_product_list');
      Route::get('/shopee/product/update', 'Shopee\ShopeeMainController@UpdateProduct')->name('shopeeproductUpdate');
      Route::post('/shopee/product/upload', 'Shopee\ShopeeMainController@UploadProductToShopee');
      Route::get('/shopee/product/destroy', 'Shopee\ShopeeMainController@DeleteProduct');
      Route::get('/shopee/refresh', 'Shopee\ShopeeMainController@refreshtoken1');
 
      Route::get('/shopee/test', 'Shopee\ShopeeMainController@store');

});


Route::middleware(['EcomApi'])->prefix('api/ecom')->group(function () {
    Route::get('products/{id?}', 'ProductController@getProductsApi');
    Route::get('categories', 'CategoryController@getCategoriesApi');
    Route::get('brands', 'BrandController@getBrandsApi');
    Route::post('customers', 'ContactController@postCustomersApi');
    Route::get('settings', 'BusinessController@getEcomSettings');
    Route::get('variations', 'ProductController@getVariationsApi');
    Route::post('orders', 'SellPosController@placeOrdersApi');
});

//common route
Route::middleware(['auth'])->group(function () {
    Route::get('/logout', 'Auth\LoginController@logout')->name('logout');
});

Route::middleware(['setData', 'auth', 'SetSessionData', 'language', 'timezone'])->group(function () {
    Route::get('/load-more-notifications', 'HomeController@loadMoreNotifications');
    Route::get('/get-total-unread', 'HomeController@getTotalUnreadNotifications');
    Route::get('/purchases/print/{id}', 'PurchaseController@printInvoice');
    Route::get('/purchases/{id}', 'PurchaseController@show');
    Route::get('/download-purchase-order/{id}/pdf', 'PurchaseOrderController@downloadPdf')->name('purchaseOrder.downloadPdf');
    Route::get('/sells/{id}', 'SellController@show');
    Route::get('/sells/{transaction_id}/print', 'SellPosController@printInvoice')->name('sell.printInvoice');
    Route::get('/download-sells/{transaction_id}/pdf', 'SellPosController@downloadPdf')->name('sell.downloadPdf');
    Route::get('/download-quotation/{id}/pdf', 'SellPosController@downloadQuotationPdf')
        ->name('quotation.downloadPdf');
    Route::get('/download-packing-list/{id}/pdf', 'SellPosController@downloadPackingListPdf')
        ->name('packing.downloadPdf');
    Route::get('/sells/invoice-url/{id}', 'SellPosController@showInvoiceUrl');
    Route::get('/show-notification/{id}', 'HomeController@showNotification');
    Route::get('/fetch-terminals', 'PrinterController@fetchterminals')->name('fetch.terminals');
});

//Reservation List
Route::get('/access-token', 'ManagePOSController@getAccessToken');
Route::resource('reservation-list', 'TableReservationController');
// Route::get('/table-reservations', [TableReservationController::class, 'index'])->name('table-reservations.index');
Route::delete('/table-reservations/{id}', [TableReservationController::class, 'destroy'])->name('table-reservations.destroy');
Route::get('/table-reservations/{id}/edit', [TableReservationController::class, 'edit'])->name('table-reservations.edit');

Route::prefix('peppol')->group(function () {
    Route::get('register', 'PeppolController@register');
    Route::get('received-invoices', 'PeppolController@receivedInvoices');
    Route::get('received-orders', 'PeppolController@receivedOrders');
    Route::post('change/invoice/status', 'PeppolController@changeInvoiceStatus');
    Route::resource('invoices', 'PeppolController');
    Route::post('register', 'PeppolController@store');
    Route::post('acknowledgement', 'PeppolController@invoiceAcknowledgement');
    Route::post('receive/docs', 'PeppolController@documentReceived');
    Route::get('register-legal-entity', 'PeppolController@registerLegalEntity');
    Route::post('store-legal-entity', 'PeppolController@storeLegalEntity');

    // Route::post('register-legal-entity', 'PeppolController@registerLegalEntity');
    //Route::get('settings', 'PeppolSettingsController@index')->name('peppol.settings')->middleware('can:peppol.settings');
});
Route::post('peppol/convert-order', 'PeppolController@convertOrderToInvoice');

Route::get('invoices-dashboard', 'PeppolNewController@dashboard')->name('invoices.dashboard');
Route::get('invoices', 'PeppolNewController@index')->name('invoices.index');
