<?php

use Illuminate\Http\Request;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

// Route::middleware('auth:api')->get('/user', function (Request $request) {
//     return $request->user();
// });

Route::post('/process-payment', 'API\TakeawayController@processPayment');
Route::post('/razer-pay/vcode', 'BusinessLocationController@razerPayVcode');
Route::post('/update_business_currency', 'BusinessController@updateCurrency'); 
Route::get('/get_all_currencies', 'HomeController@getCurrency'); 
Route::group([
    'prefix' => 'auth'
], function () {
    Route::any('/customer_login', 'API\AuthController@customer_login');
    Route::any('/customer_signup', 'API\AuthController@customer_signup');
    Route::get('/customer_signup/activate/{token}/{business_id}/{location_id}', 'API\AuthController@customer_signup_activate');
    Route::any('/update_customer_profile', 'API\AuthController@update_customer_profile');
    Route::any('/change_customer_password', 'API\AuthController@change_customer_password');
    Route::post('/update-customer-profile', 'API\AuthController@updateCustomerProfile');
    Route::post('/customer/email/send', 'API\AuthController@sendEmailCustomer');
    Route::post('/customer/email/verify', 'API\AuthController@verifyEmailCustomer');
    Route::post('/customer/mobile/verify', 'API\AuthController@verifyMobileCustomer');
    Route::post('/social/login', 'API\AuthController@socialLogin');
    Route::group([
      'middleware' => 'auth:api'
    ], function() {
        Route::get('/customer_logout', 'API\AuthController@customer_logout');
        Route::get('/customer_profile', 'API\AuthController@customer_profile');
        Route::get('/validate-auth-token', 'AuthController@validateAuthToken');
    });
    Route::any('/signup', 'API\AuthController@signup');
    Route::any('/request_otp', 'API\AuthController@request_otp');
    Route::any('/digital-ordering-login', 'API\AuthController@digital_ordering_login');
    Route::any('/send-otp', 'API\AuthController@send_otp');
    Route::any('/quick_onboard', 'API\AuthController@quick_onboard');
    Route::any('/verify_otp', 'API\AuthController@verify_otp');
    Route::any('/generate_user_access_code', 'API\AuthController@generate_user_access_code');
    Route::any('/verify_user_access_code', 'API\AuthController@verify_user_access_code');
    Route::any('/delete_account', 'API\AuthController@user_account_delete');



});

Route::group(['middleware' => 'auth0'], function () {
    Route::post('/secured/oauth/token', [Auth0Controller::class, 'secured']);
});

//Route::middleware('auth:api')->get('/validate-auth-token', 'YourController@validateAuthToken');


Route::group([      
    'middleware' => 'api',    
    'prefix' => 'password'
], function () {    
    Route::any('/create', 'API\PasswordResetController@create');
    Route::get('/find/{token}', 'API\PasswordResetController@find');
    Route::any('/reset', 'API\PasswordResetController@reset');
});

/**
 * Manage POS Devices API's
*/
Route::get('/peppol-test', 'PurchaseController@test');


Route::post('/save_pos_device', 'ManagePOSController@save');
Route::post('/update_pos_device_fcm', 'ManagePOSController@updatePosDeviceApi');
Route::get('/manage-pos/{id}/edit', 'ManagePOSController@edit')->name('manage-pos.edit');
//Route::post('manage_pos_device', 'ManagePOSController@index')->name('manage_pos_device.index');
Route::any('/get_pos_device', 'ManagePOSController@get_pos_device');
Route::any('/delete_pos_device', 'ManagePOSController@delete_pos_device');
Route::any('/send_order_print_request', 'ManagePOSController@send_print_request');
Route::any('/send_qrcode_print_request', 'ManagePOSController@send_qrcode_print_request');
Route::any('/send_order_print_request_terminal', 'ManagePOSController@send_order_print_request_terminal');
Route::any('/get_order_print_requests', 'ManagePOSController@get_order_print_requests');
Route::any('/get_all_print_requests', 'ManagePOSController@get_all_order_print_requests');
Route::any('/delete_print_requests', 'ManagePOSController@delete_print_requests');


/**
* Auth API
*/
Route::any('/login', 'API\AuthController@login');
Route::any('/get_business_location_list', 'API\AuthController@get_business_location_list');
Route::any('/get_location_user_list', 'API\AuthController@get_location_user_list');
Route::any('/verify_pin', 'API\AuthController@verify_pin');
Route::any('/get_pin', 'API\AuthController@get_pin');
Route::any('/get_business_location_for_web', 'API\AuthController@get_business_location_for_web');
Route::any('/get_business_location_details', 'API\AuthController@get_business_location_details');
Route::any('/checkEmail', 'API\AuthController@checkEmail');
Route::any('/checkContactNo', 'API\AuthController@checkContactNo');
Route::any('/send_email', 'API\AuthController@send_email');
Route::any('/getUserInfoFromContact', 'API\AuthController@getUserInfoFromContact');
Route::any('/getContactByBusinessId', 'ContactController@getContactByBusinessId');
Route::any('/generateQRSignUp', 'API\AuthController@generateQRSignUp');
Route::any('/saveCustomerProfileNote', 'API\AuthController@saveCustomerProfileNote');
Route::any('/reset-password', 'API\AuthController@resetPassword');
/**
* Cash Float API
*/
Route::any('/get_cash_float', 'API\CashFloatController@get_cash_float');
Route::any('/insert_cash_float', 'API\CashFloatController@insert_cash_float');
Route::any('/close_sales', 'API\CashFloatController@close_sales');
Route::any('/close_sales_with_float', 'API\CashFloatController@close_sales_with_float');
Route::any('/update_payment_method', 'API\CashFloatController@update_payment_method');
Route::any('/record_open_drawer', 'API\CashFloatController@record_open_drawer');
Route::any('/get_close_sale_details', 'API\CashFloatController@get_close_sale_details');

/**
* Takeaway API
*/
Route::any('/get_category_retail_products', 'API\TakeawayController@get_category_retail_products');
Route::any('/stock_details', 'API\TakeawayController@stock_details');
Route::any('/get_all_categories', 'API\TakeawayController@get_all_categories');
Route::any('/get_all_categories_do', 'API\TakeawayController@get_all_categories_do');
Route::any('/get_category_products', 'API\TakeawayController@get_category_products');
Route::any('/get_category_products_do', 'API\TakeawayController@get_category_products_do');
Route::any('/get_product_modifier', 'API\TakeawayController@get_product_modifier');
Route::any('/get_open_modifiers', 'API\TakeawayController@get_open_modifiers');
Route::any('/get_product_modifier_do', 'API\TakeawayController@get_product_modifier_do');
Route::any('/save_order', 'API\TakeawayController@save_order');
Route::any('/save_takeaway_digital_ordering', 'API\TakeawayController@save_takeaway_digital_ordering');
Route::any('/get_takeaway_transaction', 'API\TakeawayController@get_takeaway_transaction');
Route::any('/get_takeaway_orders', 'API\TakeawayController@get_takeaway_orders');
Route::any('/view_takeaway_order', 'API\TakeawayController@view_takeaway_order');
Route::any('/view_retail_order', 'API\TakeawayController@view_retail_order');
// Route::any('/void_transaction', 'API\TakeawayController@void_transaction');
Route::any('/get_discount_addon', 'API\TakeawayController@get_discount_addon');
Route::any('/update_transaction_status', 'API\TakeawayController@update_transaction_status');
Route::any('/get_all_sales', 'API\TakeawayController@get_all_sales');
Route::any('/get_all_sales_attaphouse', 'API\TakeawayController@get_all_sales_attaphouse');
Route::any('/get_all_sales_pagewise', 'API\TakeawayController@get_all_sales_pagewise');

Route::any('/void_order', 'API\TakeawayController@void_order');

// Vouchers
Route::any('/get_vouchers', 'VoucherController@get_vouchers');
Route::any('/stripe_payment_notification', 'API\TakeawayController@stripe_payment_callback');

Route::any('/sale_history_by_days', 'API\TakeawayController@sales_history');
Route::any('/sale_history_by_days_test', 'API\TakeawayController@sales_history_test');

Route::any('/refund_order', 'API\TakeawayController@refund_order');
Route::any('/check_dinein_detail', 'API\TakeawayController@check_dinein_detail');
Route::any('/check_takeaway_order', 'API\TakeawayController@check_takeaway_order');
Route::any('/get_stripe_and_lalamove_key', 'API\TakeawayController@get_stripe_and_lalamove_key');
Route::any('/get_invoice_no', 'API\TakeawayController@get_invoice_no');
Route::any('/get_invoice_history/{transaction_id}', 'API\TakeawayController@get_invoice_history');
Route::any('/check_driver_details', 'API\TakeawayController@check_driver_details');
Route::any('/get_customer_profile_sale', 'API\TakeawayController@get_customer_profile_sale');
Route::any('/order_history_by_user', 'API\TakeawayController@order_history_by_user');
Route::any('/guest_user_order_history', 'API\TakeawayController@guest_user_order_history');

// Bulk Requests
Route::any('/save_order_bulk', 'API\TakeawayController@save_order_bulk');
Route::any('/refund_order_bulk', 'API\TakeawayController@refund_order_bulk');
Route::any('/update_pos_selling_status', 'API\TakeawayController@update_pos_selling_status');
Route::any('/update_modifier_pos_selling_status', 'API\TakeawayController@update_modifier_pos_selling_status');
Route::any('/complete_takeaway_order', 'API\TakeawayController@complete_takeaway_order');
Route::any('/complete_takeaway_order_bulk', 'API\TakeawayController@complete_takeaway_order_bulk');

/**
* Dine In API
*/
Route::any('/get_all_location_table', 'API\DineInController@get_all_location_table');
Route::any('/save_dine_in_order', 'API\DineInController@save_dine_in_order');
Route::any('/save_digital_ordering', 'API\TakeawayController@save_digital_ordering');
Route::any('/save_digital_ordering_static_qr', 'API\TakeawayController@save_digital_ordering_static_qr');
Route::any('/update_dine_in_order', 'API\DineInController@update_dine_in_order');
Route::any('/update_pickup_order', 'API\DineInController@update_pickup_order');
Route::any('/update_digital_ordering', 'API\TakeawayController@update_digital_ordering');
Route::post('/digital_ordering_stripe_payment', 'API\TakeawayController@digital_ordering_stripe_payment');
Route::post('/client/secret/key', 'API\TakeawayController@CreateClientSecret');
Route::any('/view_dinein_order', 'API\TakeawayController@view_dinein_order');
Route::any('/close_table', 'API\DineInController@close_table');
Route::any('/generate_qr_token', 'API\DineInController@generate_qr_token');
Route::any('/check_qr_token', 'API\DineInController@check_qr_token');
Route::any('/update_serve_later_quantity', 'API\DineInController@update_serve_later_quantity');
Route::any('/update_serve_later_quantity_bulk', 'API\DineInController@update_serve_later_quantity_bulk');
Route::any('/update_pending_order', 'API\DineInController@update_pending_order');
Route::any('/transfer_table', 'API\DineInController@transfer_table');
Route::any('/check_qr_dinein_preparation_time', 'API\DineInController@check_qr_dinein_preparation_time');
Route::any('/merge_table', 'API\DineInController@merge_table');
// Bulk Requests
Route::any('/save_dine_in_order_bulk', 'API\DineInController@save_dine_in_order_bulk');
Route::any('/update_dine_in_order_bulk', 'API\DineInController@update_dine_in_order_bulk');
Route::any('/view_dinein_order_bulk', 'API\TakeawayController@view_dinein_order_bulk');
/**
* Printer API
*/
Route::any('/get_connection_list', 'API\ApiPrinterController@get_connection_list');
Route::any('/get_connection', 'API\ApiPrinterController@get_connection');
Route::any('/create_connection', 'API\ApiPrinterController@create_connection');
Route::any('/update_connection', 'API\ApiPrinterController@update_connection');
Route::any('/delete_connection', 'API\ApiPrinterController@delete_connection');
Route::any('/get_printer_category', 'API\ApiPrinterController@get_printer_category');

/**
* Generate Report
*/
Route::any('/generate_z_report', 'API\GenerateReportController@generate_z_report');
Route::any('/generate_refund_credit_note_report', 'API\GenerateReportController@generate_refund_credit_report');
Route::any('/get_open_drawer_record', 'API\GenerateReportController@get_open_drawer_record');
Route::any('/get_product_sales', 'API\GenerateReportController@get_product_sales');
Route::any('/generate_gto_files', 'API\GenerateReportController@generate_gto_files');
Route::any('/cron_pos_outlet_form', 'API\GenerateReportController@cron_pos_outlet_form');
Route::any('/get_product_sales_attap_house', 'API\GenerateReportController@get_product_sales_attap_house');
Route::any('/generate_hourly_report', 'API\GenerateReportController@generate_hourly_report');
Route::any('/generate_hourly_report_attap_house', 'API\GenerateReportController@generate_hourly_report_attap_house');
Route::any('/generate_z_report_attap_house', 'API\GenerateReportController@generate_z_report_attap_house');
/**
* Service Send Events (SSE)
*/
Route::any('/sse_send_orders', 'API\SSEController@sentOrders');
Route::any('/sse_check_update_orders', 'API\SSEController@checkUpdateOrders');
Route::any('/sse_check_update_all_orders', 'API\SSEController@checkUpdateAllOrders');
// Route::get('/getEventStream', 'EventStreamController@stream');
Route::any('/sse_check_delivery_status', 'API\SSEController@checkUpdateDeliveryStatus');
Route::any('/sse/queue/current/', 'API\SSEController@fetchCurrentQueue');

/**
 * Handheld
 */
Route::any('/handheld_login', 'API\HandheldController@login');
Route::any('/handheldTest', 'API\HandheldController@test_fn');
Route::any('/handheld_get_delivery_order_list', 'API\HandheldController@get_delivery_order_list');
Route::any('/handheld_view_order', 'API\HandheldController@view_order');
Route::any('/handheld_reject_order', 'API\HandheldController@reject_order');
Route::any('/handheld_history_info', 'API\HandheldController@get_history_info');
Route::any('/print_delivery_report', 'API\HandheldController@print_delivery_report');
Route::any('/handheld_get_business_location_details', 'API\HandheldController@handheld_get_business_location_details');
Route::any('/handheld_update_store_status', 'API\HandheldController@handheld_update_store_status');
Route::any('/handheld_get_store_status', 'API\HandheldController@handheld_get_store_status');


/**
* Pickup/Delivery
*/
Route::any('/stripePost', 'API\TakeawayController@stripePost');
Route::any('/save_pickup_delivery', 'API\TakeawayController@save_pickup_delivery');
Route::any('/find_pickup_store', 'API\PickupController@find_pickup_store');

Route::any('/track_order', 'API\TakeawayController@track_order');
Route::any('/track_order_history', 'API\TakeawayController@track_order_history');

Route::any('/lalamove_webhook', 'API\DeliveryController@lalamove_webhook');
Route::any('/update_lalamove_status', 'API\DeliveryController@update_lalamove_status');
Route::any('/check_status_delivery_store', 'API\DeliveryController@check_status_delivery_store');

Route::any('/check_qr_pickup_preparation_time', 'API\PickupController@check_qr_pickup_preparation_time');

//Route::any('/track_pickup_order', 'API\PickupController@track_pickup_order'); REMOVE
//Route::any('/track_delivery_order', 'API\DeliveryController@track_delivery_order'); REMOVE

/**
* POS Pickup
*/
Route::any('/get_pickup_order', 'API\PickupController@get_pickup_order');
Route::any('/view_pickup_order', 'API\TakeawayController@view_pickup_order');
Route::any('/update_pickup_completed', 'API\PickupController@update_pickup_completed');

/**
* POS Delivery
*/
Route::any('/get_delivery_order', 'API\DeliveryController@get_delivery_order');
Route::any('/cron_job_update_lalamove_status', 'API\DeliveryController@cron_job_update_lalamove_status');
//Route::any('/cancel_lalamove_order', 'API\DeliveryController@cancel_lalamove_order');
Route::any('/view_delivery_order', 'API\TakeawayController@view_delivery_order');

/**
* Lalamove
*/
Route::any('/getQuotation', 'API\LalamoveController@getQuotation');
Route::any('/placeOrder', 'API\LalamoveController@placeOrder');

/**
* Reservation
*/
Route::any('/save_reservation', 'API\ReservationController@save_reservation');
Route::any('/get_reservation', 'API\ReservationController@get_reservation');
Route::any('/void_reservation', 'API\ReservationController@void_reservation');
Route::any('/update_reservation', 'API\ReservationController@update_reservation');

//Discount
Route::any('/get_discounts', 'DiscountController@get_discounts');

Route::get('/smooch_pay/callback', 'API\SmoochPayController@callback');


/**
* Attendance
*/
Route::group(['prefix' => 'attendance'], function () {
    Route::post('/clock-in', 'AttendanceController@clockIn');
    Route::post('/clock-out', 'AttendanceController@clockOut');
    Route::post('/start-break', 'AttendanceController@startBreak');
    Route::post('/end-break', 'AttendanceController@endBreak');
    Route::post('/details','AttendanceController@details');
});

/**
* Reward List
*/
Route::any('/get_reward_list', 'API\RewardListController@get_reward_list');
Route::post('/update_location_price_group', 'API\AuthController@update_location_price_group');

/**
 * KDS route
 */
Route::any('/kdsLogin', 'KDS\AccessController@kdsLogin');
Route::any('/kdsLogout', 'KDS\AccessController@kdsLogout');
Route::any('/getKdsBusinessLocationList', 'KDS\AccessController@getKdsBusinessLocationList');
Route::any('/getKdsBusinessLocationDetails', 'KDS\AccessController@getKdsBusinessLocationDetails');
Route::any('/getOnGoingList', 'KDS\onGoingController@getOnGoingList');
Route::any('/getServeLaterList', 'KDS\onGoingController@getServeLaterList');
Route::any('/voidItem', 'KDS\onGoingController@voidItem');
Route::any('/getTodayHistoryList', 'KDS\HistoryController@getTodayHistoryList');
Route::any('/closeTicket', 'KDS\onGoingController@closeTicket');
Route::any('/kdsIsCross', 'KDS\onGoingController@kdsIsCross');
Route::any('/reorderTicket', 'KDS\onGoingController@reorderTicket');

Route::any('/generate_GTO_files', 'API\GTOController@cron_generate_GTO_files');
Route::any('/connectFTP', 'API\GTOController@connectToFTP');

/*
*   Contact API's
*/
Route::any('/get_all_customers', 'ContactController@getContactsByBusinessId');

Route::post('display-images', 'API\ManageQueueController@displayImages');

// Queue Management
Route::group(['prefix' => 'queue'], function () {
    // Public End-Points
    Route::post('register', 'API\ManageQueueController@register')->middleware('checkQueueSettings');
    Route::get('details', 'API\ManageQueueController@fetchDetails')->middleware('checkQueueSettings');
    Route::post('current', 'API\ManageQueueController@fetchCurrentQueue')->middleware('checkQueueSettings');
    Route::post('missed', 'API\ManageQueueController@fetchMissedQueue')->middleware('checkQueueSettings');

    // Private End-Points
    Route::post('list', 'API\ManageQueueController@fetchQueueList')->middleware('checkQueueSettings');
    Route::post('call', 'API\ManageQueueController@call')->middleware('checkQueueSettings');
    Route::post('skip', 'API\ManageQueueController@skip')->middleware('checkQueueSettings');
    Route::post('table/assign', 'API\ManageQueueController@assignQueueToTable')->middleware('checkQueueSettings');
    Route::post('re-queue', 'API\ManageQueueController@reQueueToTable')->middleware('checkQueueSettings');
    Route::post('list/missed', 'API\ManageQueueController@fetchMissedQueueList')->middleware('checkQueueSettings');
});

/**
 * Coupon api
 */
// Route::get('/get_coupon/{telegram_user_id}/{campaign_id?}/{issue?}', 'API\CouponController@getCoupon')->middleware('throttle:1,0.10');
Route::post('user_coupon_details', 'API\CouponController@checkUserCouponDetail');
Route::post('user_all_coupon_details', 'API\CouponController@checkUserAllCoupons');
Route::post('issue_new_coupon',  'API\CouponController@issueCoupon');
Route::post('reissue_coupon', 'API\CouponController@reissueCoupon');
Route::get('/telegram_channels', 'API\CouponController@getTelegramChannelList');
Route::get('/telegram_groups', 'API\CouponController@getTelegramGroupList');
Route::post('/campaign_lists', 'API\CouponController@getAllCampaignList');
Route::get('/campaign/{id?}', 'API\CouponController@getCampaign');
Route::any('/get_all_coupons', 'API\CouponController@get_all_coupons');
Route::any('/verify_coupon', 'API\CouponController@verify_coupon');
Route::any('/get_campaign_coupons', 'API\CouponController@get_campaign_coupons');

Route::get('/get_coupon/{telegram_user_id}/{campaign_id?}/{issue?}', 'API\CouponController@getCoupon');
Route::post('/redeem_coupon', 'API\CouponController@redeemCoupon');
Route::get('/campaign_list/{channel_id?}', 'API\CouponController@getCampaignList');

Route::get('/user/{user_id}', 'API\TelegramUserController@getTelegramUser');
Route::get('/users', 'API\TelegramUserController@getAllUserList');
Route::post('/create-user', 'API\TelegramUserController@storeTelegramUser');
Route::put('/update-user', 'API\TelegramUserController@updateTelegramUser');
Route::post('/channel-status', 'API\TelegramUserController@addUserChannelStatus');
Route::put('/channel-status', 'API\TelegramUserController@addUserChannelStatus');
Route::get('/get-user-channels-status/{user_id}', 'API\TelegramUserController@getUserChannelStatus');
Route::get('/get-business/{channel_id}', 'API\TelegramUserController@getAllBusiness');
Route::get('/get-channel-locations/{channel_id}', 'API\TelegramUserController@channelBusinessLocation');
Route::post('/get-channel-campaigns', 'API\TelegramUserController@getCampaigns');

Route::put('/invite-user', 'API\TelegramUserController@telegramInviteUser');
Route::get('/user-invite-list/{user_id}', 'API\TelegramUserController@getUserInviteList');
Route::post('/user-invite-list', 'API\TelegramUserController@getSingleUserInviteList');
Route::post('/leaderboard', 'API\TelegramUserController@leaderBoardData');

Route::get('/merchant/menu/', 'API\AuthController@merchantMenu');
// Route::post('/oauth/token', 'API\AuthController@getAccessToken');

// Grab Food Menu
//Route::get('/merchant/menu/', 'API\AuthController@merchantMenunew');
//Grab Mart menu
Route::get('/merchant/menu/', 'API\AuthController@merchantMenuGmart');

Route::post('/oauth/token', 'API\AuthController@getAccessToken');
// Route::post('/menu-sync', 'API\AuthController@getJobStatus');
Route::post('/orders', 'API\AuthController@orders');
Route::any('/order/state', 'API\AuthController@orderStatus');
Route::put('/orders/{orderID}', 'API\AuthController@editOrder');
Route::put('/order/cancel', 'API\AuthController@orderCancel');
// Route::get('/grab-subcategories/{ids}', 'ProductController@grabSubcategories')->name('grab-subcategories');

// NFC Cards
Route::group(['prefix' => 'nfc-card'], function () {
    Route::any('/deduct_amount', 'API\TakeawayController@deductNFCBalance');
    Route::post('/register', 'NfcCardController@registerNfcCard');
    Route::post('/details', 'NfcCardController@getNfcCardDetails');
    Route::post('/recharge', 'NfcCardController@rechargeNfcCard');
    Route::post('/transactions', 'NfcCardController@getNfcCardTransactions');
    Route::post('/update', 'NfcCardController@udpateNfcCardDetails');
    Route::post('/verify', 'NfcCardController@verifyNfcCard');
    Route::post('/topup/list', 'NfcReportController@nfcTopupList');
    Route::post('/topup/transactions', 'NfcReportController@nfcTopupTransactions');
    Route::post('/void/transaction','NfcCardController@voidTopupTransaction');
    Route::post('/search','NfcCardController@nfcCardSearch');
    Route::post('/transfer','NfcCardController@nfcCardTransfer');
    Route::post('/info', 'NfcCardController@get_nfc_card_details');
    Route::post('/send/otp','NfcCardController@sendOtp');
    Route::post('/verify/otp','NfcCardController@verifyOtp');
});

//Table Reservation Flow
Route::post('/save_table_bookings', 'TableReservationController@save_table_bookings');
Route::post('/update_table_bookings', 'TableReservationController@update_table_bookings');
Route::post('/delete_table_bookings', 'TableReservationController@delete_table_bookings');
Route::any('/get_all_reservations_list', 'TableReservationController@get_all_reservations_list');

//Credit Wallet Management
Route::group(['prefix' => 'credit'], function () {
    Route::post('/create', 'CreditController@createCredit');
    Route::post('/recharge', 'CreditController@rechargeCreditWallet');
    Route::post('/details','CreditController@get_credit_details');
    Route::post('/transactions', 'CreditController@get_credit_transactions');
    Route::post('/send/otp','CreditController@sendOtp');
    Route::post('/verify/otp','CreditController@verifyOtp');
    Route::post('/topup/transactions','CreditReportController@creditTopupTransactions');
    Route::post('/topup/list', 'CreditReportController@creditTopupList');
    Route::post('/void/transaction','CreditController@voidTopupTransaction');


});
Route::any('/view_order_invoice', 'API\TakeawayController@view_order_invoice');
Route::any('/email_order_invoice', 'API\TakeawayController@email_order_invoice');

//temp Api delete nfc card
Route::get('/delete-nfc/{business_id}/{card_no}/{sr_no}', 'API\TelegramUserController@deleteNfcCard');
Route::get('/hit-bot', 'API\TelegramUserController@hitBot');

// NFC Cards
Route::group(['prefix' => 'terminal'], function () {
    Route::post('/list', 'TerminalController@list');
    Route::post('/update/fcm', 'TerminalController@updateFcmToken');
    Route::post('/update/device', 'TerminalController@updateDeviceDetail');
    Route::post('/update/status', 'TerminalController@updateTerminalStatus');
    Route::post('/detail', 'TerminalController@fetchTerminalDetail');
});

Route::prefix('reward_points')->group(function () {
    Route::post('transactions', 'API\DineInController@rpTransactions')->name('reward_points.transactions');
});

Route::group(['prefix' => 'upsell'], function () {
    Route::post('/products', 'API\TakeawayController@fetchUpSellProducts');
});