<?php $__env->startSection('title', __( 'queue.pax_categories' )); ?>

<?php $__env->startSection('content'); ?>

<!-- Content Header (Page header) -->
<section class="content-header">
    <h1><?php echo app('translator')->getFromJson( 'queue.pax_categories' ); ?>
        <small><?php echo app('translator')->getFromJson( 'queue.manage_your_pax_categories' ); ?></small>
    </h1>
</section>

<!-- Main content -->
<section class="content">

	<div class="box">
        <div class="box-header">
        	<h3 class="box-title"><?php echo app('translator')->getFromJson( 'queue.all_your_pax_categories' ); ?></h3>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('queue.create')): ?>
            	<div class="box-tools">
                    <button type="button" class="btn btn-block btn-primary btn-modal" 
                    	data-href="<?php echo e(action('Queue\QueuePaxCategoriesController@create'), false); ?>" 
                    	data-container=".pax_categories_modal">
                    	<i class="fa fa-plus"></i> <?php echo app('translator')->getFromJson( 'messages.add' ); ?></button>
                </div>
            <?php endif; ?>
        </div>
        <div class="box-body">
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('queue.view')): ?>
            	<table class="table table-bordered table-striped" id="pax_categories_table">
            		<thead>
            			<tr>
                            <th><?php echo app('translator')->getFromJson( 'queue.start_from' ); ?></th>
                            <th><?php echo app('translator')->getFromJson( 'queue.end_to' ); ?></th>
                            <th><?php echo app('translator')->getFromJson( 'queue.name' ); ?></th>
            				<th><?php echo app('translator')->getFromJson( 'messages.action' ); ?></th>
            			</tr>
            		</thead>
            	</table>
            <?php endif; ?>
        </div>
    </div>

    <div class="modal fade pax_categories_modal" tabindex="-1" role="dialog" 
    	aria-labelledby="gridSystemModalLabel">
    </div>

</section>
<!-- /.content -->

<?php $__env->stopSection(); ?>

<?php $__env->startSection('javascript'); ?>
    <script type="text/javascript">
        $(document).ready(function(){

            $(document).on('submit', 'form#pax_category_add_form', function(e){
                e.preventDefault();
                var data = $(this).serialize();
                $.ajax({
                    method: "POST",
                    url: $(this).attr("action"),
                    dataType: "json",
                    data: data,
                    success: function(result){
                        if(result.success == true){
                            $('div.pax_categories_modal').modal('hide');
                            toastr.success(result.msg);
                            pax_categories_table.ajax.reload();
                        } else {
                            toastr.error(result.msg);
                        }
                    }
                });
            });

            //Brands table
            var pax_categories_table = $('#pax_categories_table').DataTable({
                processing: true,
                serverSide: true,
                ajax: '/queue/pax-categories',
                columns: [
                    { data: 'start_from', name: 'start_from'  },
                    { data: 'end_to', name: 'end_to'},
                    { data: 'description', name: 'description'},
                    { data: 'action', name: 'action'}
                ],
            });

            $(document).on('click', 'button.edit_pax_categories_button', function(){
                $( "div.pax_categories_modal" ).load( $(this).data('href'), function(){
                    $(this).modal('show');
                    $('form#pax_category_edit_form').submit(function(e){
                        e.preventDefault();
                        var data = $(this).serialize();
                        $.ajax({
                            method: "POST",
                            url: $(this).attr("action"),
                            dataType: "json",
                            data: data,
                            success: function(result){
                                if(result.success == true){
                                    $('div.pax_categories_modal').modal('hide');
                                    toastr.success(result.msg);
                                    pax_categories_table.ajax.reload();
                                } else {
                                    toastr.error(result.msg);
                                }
                            }
                        });
                    });
                });
            });

            $(document).on('click', 'button.delete_pax_categories_button', function(){
                swal({
                  title: LANG.sure,
                  text: LANG.confirm_delete_table,
                  icon: "warning",
                  buttons: true,
                  dangerMode: true,
                }).then((willDelete) => {
                    if (willDelete) {
                        var href = $(this).data('href');
                        var data = $(this).serialize();
                        $.ajax({
                            method: "DELETE",
                            url: href,
                            dataType: "json",
                            data: data,
                            success: function(result){
                                if(result.success == true){
                                    toastr.success(result.msg);
                                    pax_categories_table.ajax.reload();
                                } else {
                                    toastr.error(result.msg);
                                }
                            }
                        });
                    }
                });
            });
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel_works\admin_pos\resources\views/queue/pax_categories/index.blade.php ENDPATH**/ ?>