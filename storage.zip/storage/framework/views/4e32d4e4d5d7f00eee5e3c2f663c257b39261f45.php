<?php $__env->startSection('title', __('wallet.wallet_transations')); ?>

<?php $__env->startSection('content'); ?>

<!-- Content Header (Page header) -->
<section class="content-header content-header-custom">
    <h1>
    <h1><?php echo e(__('wallet.wallet_balance', ['balance' => $walletBalance]), false); ?></h1>
    </h1>
</section>
<!-- Main content -->
<section class="content content-custom no-print">
  <br>
    <?php if(auth()->user()->can('dashboard.data')): ?>
    	<div class="row">
            <div class="col-md-4 col-xs-12">
            </div>
    		<div class="col-md-8 col-xs-12">
    			<div class="btn-group pull-right" data-toggle="buttons">
    				<label class="btn btn-info active">
        				<input type="radio" name="date-filter"
        				data-start="<?php echo e(date('Y-m-d'), false); ?>" 
        				data-end="<?php echo e(date('Y-m-d'), false); ?>"
        				checked> <?php echo e(__('home.today'), false); ?>

      				</label>
      				<label class="btn btn-info">
        				<input type="radio" name="date-filter"
        				data-start="<?php echo e($date_filters['this_week']['start'], false); ?>" 
        				data-end="<?php echo e($date_filters['this_week']['end'], false); ?>"
        				> <?php echo e(__('home.this_week'), false); ?>

      				</label>
      				<label class="btn btn-info">
        				<input type="radio" name="date-filter"
        				data-start="<?php echo e($date_filters['this_month']['start'], false); ?>" 
        				data-end="<?php echo e($date_filters['this_month']['end'], false); ?>"
        				> <?php echo e(__('home.this_month'), false); ?>

      				</label>
      				<label class="btn btn-info">
        				<input type="radio" name="date-filter" 
        				data-start="<?php echo e($date_filters['this_fy']['start'], false); ?>" 
        				data-end="<?php echo e($date_filters['this_fy']['end'], false); ?>" 
        				> <?php echo e(__('home.this_fy'), false); ?>

      				</label>
                </div>
    		</div>
    	</div>
    	<br>
    	<div class="row row-custom">
        	<div class="col-md-3 col-sm-6 col-xs-12 col-custom">
    	      <div class="info-box info-box-new-style">
    	        <span class="info-box-icon bg-aqua"><i class="ion ion-cash"></i></span>

    	        <div class="info-box-content">
    	          <span class="info-box-text"><?php echo e(__('wallet.wallet_top_up_amount'), false); ?></span>
    	          <span class="info-box-number total_top_up"><i class="fas fa-sync fa-spin fa-fw margin-bottom"></i></span>
    	        </div>
    	        <!-- /.info-box-content -->
    	      </div>
    	      <!-- /.info-box -->
    	    </div>
    	    <!-- /.col -->
    	    <div class="col-md-3 col-sm-6 col-xs-12 col-custom">
    	      <div class="info-box info-box-new-style">
    	        <span class="info-box-icon bg-aqua"><i class="ion ion-ios-chatboxes-outline"></i></span>

    	        <div class="info-box-content">
    	          <span class="info-box-text"><?php echo e(__('wallet.wallet_sms_charges'), false); ?></span>
    	          <span class="info-box-number wallet_sms_charges"><i class="fas fa-sync fa-spin fa-fw margin-bottom"></i></span>
    	        </div>
    	        <!-- /.info-box-content -->
    	      </div>
    	      <!-- /.info-box -->
    	    </div>
    	    <!-- /.col -->
    	    <div class="col-md-3 col-sm-6 col-xs-12 col-custom">
    	      <div class="info-box info-box-new-style">
    	        <span class="info-box-icon bg-yellow">
    	        	<i class="fa fa-dollar"></i>
                <i class="fab fa-whatsapp fa-lg"></i>
                </span>

    	        <div class="info-box-content">
    	          <span class="info-box-text"><?php echo e(__('wallet.wallet_whatapp_charges'), false); ?></span>
                <span class="info-box-number wallet_whatapp_charges"><i class="fas fa-sync fa-spin fa-fw margin-bottom"></i>0.00</span>
                </span>
    	        </div>
                    <!-- /.info-box-content -->
    	      </div>
    	      <!-- /.info-box -->
    	    </div>
          <div class="clearfix visible-sm-block"></div>
          <div class="col-md-3 col-sm-6 col-xs-12 col-custom">
            <div class="info-box info-box-new-style">
              <span class="info-box-icon bg-red">
                <i class="fas fa-bullhorn"></i>
              </span>

              <div class="info-box-content">
                <span class="info-box-text">
                  <?php echo e(__('wallet.wallet_pramotional_charges'), false); ?>

                </span>
                <span class="info-box-number wallet_pramotional_charges"><i class="fas fa-sync fa-spin fa-fw margin-bottom"></i>0.00</span>
              </div>
              <!-- /.info-box-content -->
            </div>
            <!-- /.info-box -->
          </div>
      	</div>

        <div class="row" <?php if(!auth()->user()->can('dashboard.data')): ?>style="margin-top: 190px !important;"<?php endif; ?>>
              <div class="col-sm-12">
                <div class="row">
                    <div class="col-md-12">
                        <?php $__env->startComponent('components.filters', ['title' => __('report.filters')]); ?>
                            <div class="col-md-3">
                                <div class="form-group">
                                    <?php echo Form::label('Service_type', __('Service type') . ':'); ?>

                                    <?php echo Form::select('Service_type', ['SMS OTP charges' => __('SMS OTP charges'), 'Whatsapp message charges' => __('Whatsapp message charges')], null, ['class' => 'form-control select2', 'style' => 'width:100%', 'id' => 'service_type', 'placeholder' => __('lang_v1.all')]);; ?>

                                </div>
                            </div>
                            
                            <?php if(empty($only) || in_array('wallet_transation_date_range', $only)): ?>
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <?php echo Form::label('wallet_transation_date_range', __('report.date_range') . ':'); ?>

                                        <?php echo Form::text('wallet_transation_date_range', null, ['placeholder' => __('lang_v1.select_a_date_range'), 'class' => 'form-control', 'readonly']);; ?>

                                    </div>
                                </div>
                            <?php endif; ?>
                        <?php echo $__env->renderComponent(); ?>
                    </div>
                </div>
                <?php $__env->startComponent('components.widget', ['class' => 'box-warning']); ?>
                    <?php $__env->slot('title'); ?>
                        <?php echo app('translator')->getFromJson('wallet.wallet_balance_report'); ?>
                    <?php $__env->endSlot(); ?>
                  <div class="table-responsive">
                    <table class="table table-bordered table-striped ajax_view" id="wallet_trnsations_reports" style="width: 100%;">
                        <thead>
                            <tr>
                                <th><?php echo app('translator')->getFromJson('Timestamp'); ?></th>
                                <th><?php echo app('translator')->getFromJson('Phone'); ?></th>
                                <th><?php echo app('translator')->getFromJson('Services'); ?></th>
                                <th><?php echo app('translator')->getFromJson('Transations'); ?></th>
                                <th><?php echo app('translator')->getFromJson('Type'); ?></th>
                                <th><?php echo app('translator')->getFromJson('Remaining Balance'); ?></th>
                            </tr>
                        </thead>
                    </table>
                    </div>
                    <?php echo $__env->renderComponent(); ?>
                </div>
        </div>
        
    <?php endif; ?>
</section>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('javascript'); ?>
<script type="text/javascript">
  $(document).ready(function() {

      /*Added date picker*/
    $('#wallet_transation_date_range').daterangepicker(
        dateRangeSettings,
        function (start, end) {
            $('#wallet_transation_date_range').val(start.format(moment_date_format) + ' ~ ' + end.format(moment_date_format));
            transations.ajax.reload();
        }
    );

    $('#wallet_transation_date_range').on('cancel.daterangepicker', function(ev, picker) {
        $('#wallet_transation_date_range').val('');
        transations.ajax.reload();
    });
    
    var transations = $('#wallet_trnsations_reports').DataTable({
      processing: true,
      serverSide: true,
      scrollY: "75vh",
      scrollX: true,
      scrollCollapse: true,
      aaSorting: [[1, 'desc']],
      ajax: {
        url: '/bussiness_wallet_transation',
        type: 'GET',
        "data": function ( d ) {
            d.service_type = $('#service_type').val();
            if($('#wallet_transation_date_range').val()) {
                var start = $('#wallet_transation_date_range').data('daterangepicker').startDate.format('YYYY-MM-DD');
                var end = $('#wallet_transation_date_range').data('daterangepicker').endDate.format('YYYY-MM-DD');
                d.start_date = start;
                d.end_date = end;
                }
                
            console.log(d);
            d = __datatable_ajax_callback(d);
        }
     
      },
      columnDefs: [
        {
          targets: 5, 
          orderable: false,
          searchable: false
        }
      ],
      columns: [
        { data: 'transaction_date', name: 'transaction_date' },
        { data: 'phone', name: 'phone' },
        { data: 'service_type', name: 'service_type' },
        { data: 'amount', name: 'amount',
          render: function(data, type, row) {
                return parseFloat(data).toFixed(2);
            }
        },
        { data: 'transaction_type', name: 'transaction_type' },
        { data: 'available_balance', name: 'available_balance',
          render: function(data, type, row) {
                return parseFloat(data).toFixed(2);
            }
         }
      ]
    });
    
    $(document).on('change', '#service_type', function() {
        transations.ajax.reload();
    });

    //weekly, monthly, yearly filter
    var start = $('input[name="date-filter"]:checked').data('start');
		var end = $('input[name="date-filter"]:checked').data('end');
		update_statistics(start, end);

		$(document).on('change', 'input[name="date-filter"]', function(){
			var start = $('input[name="date-filter"]:checked').data('start');
			var end = $('input[name="date-filter"]:checked').data('end');
			update_statistics(start, end);
		});

    function update_statistics(start, end) {
        var data = { start: start, end: end };
        var loader = '<i class="fa fa-refresh fa-spin fa-fw"></i>';
        $('.wallet_remaining_balance').html(loader);
        $('.wallet_topup_amount').html(loader);

        $.ajax({
            method: "GET",
            url: '/business/wallet/summeries', 
            dataType: "json",
            data: data,
            success: function(response) {
                $('.wallet_sms_charges').html(__currency_trans_from_en(response.total_deductions));
                $('.total_top_up').html(__currency_trans_from_en(response.total_wallet_topup_amount));
            },
            error: function(xhr, status, error) {
                console.log('Error:', error);
            }
        });
    }
  });
</script>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel_works\admin_pos\resources\views/wallet_transations/index.blade.php ENDPATH**/ ?>