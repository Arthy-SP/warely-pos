<?php $__env->startSection('title', __( 'credit.reports' )); ?>

<?php $__env->startSection('content'); ?>

<!-- Content Header (Page header) -->
<section class="content-header">
    <h1>Credits Topup Reports
        <small>Manage your Credits Topup Reports</small>
    </h1>
</section>

<!-- Main content -->
<section class="content">
<div class="row">
                <div class="col-md-12">
                    <?php $__env->startComponent('components.filters', ['title' => __('report.filters')]); ?>
                    <div class="col-md-3" id="location_filter">
                        <div class="form-group">
                            <?php echo Form::label('location_id',  __('purchase.business_location') . ':'); ?>

                            <?php echo Form::select('location_id', $business_locations, null, ['class' => 'form-control select2', 'style' => 'width:100%', 'placeholder' => __('lang_v1.all')]);; ?>

                        </div>
                    </div>
                    <?php echo $__env->renderComponent(); ?>
                </div>
            </div>
    <div class="box">
        <div class="box-body">
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('invoice.view')): ?>
            	<table class="table table-bordered table-striped" id="credit_report_table"> 
            		<thead>
            			<tr>
                            <th><?php echo app('translator')->getFromJson( 'credit.date' ); ?> <?php
                if(session('business.enable_tooltip')){
                    echo '<i class="fa fa-info-circle text-info hover-q no-print " aria-hidden="true" 
                    data-container="body" data-toggle="popover" data-placement="auto bottom" 
                    data-content="' . __('credit.date') . '" data-html="true" data-trigger="hover"></i>';
                }
                ?></th>
                            <th><?php echo app('translator')->getFromJson( 'credit.total_topup_amount' ); ?> <?php
                if(session('business.enable_tooltip')){
                    echo '<i class="fa fa-info-circle text-info hover-q no-print " aria-hidden="true" 
                    data-container="body" data-toggle="popover" data-placement="auto bottom" 
                    data-content="' . __('credit.total_topup_amount') . '" data-html="true" data-trigger="hover"></i>';
                }
                ?></th>
                            <th><?php echo app('translator')->getFromJson( 'credit.total_promo_amount' ); ?> <?php
                if(session('business.enable_tooltip')){
                    echo '<i class="fa fa-info-circle text-info hover-q no-print " aria-hidden="true" 
                    data-container="body" data-toggle="popover" data-placement="auto bottom" 
                    data-content="' . __('credit.total_promo_amount') . '" data-html="true" data-trigger="hover"></i>';
                }
                ?></th>
                            <th><?php echo app('translator')->getFromJson( 'credit.total' ); ?> <?php
                if(session('business.enable_tooltip')){
                    echo '<i class="fa fa-info-circle text-info hover-q no-print " aria-hidden="true" 
                    data-container="body" data-toggle="popover" data-placement="auto bottom" 
                    data-content="' . __('credit.total') . '" data-html="true" data-trigger="hover"></i>';
                }
                ?></th>
                            <th><?php echo app('translator')->getFromJson( 'messages.action' ); ?></th>
            			</tr>
            		</thead>
            	</table>
            <?php endif; ?>
        </div>
    </div>

    <div class="modal fade nfc_promo_modal" tabindex="-1" role="dialog" 
    	aria-labelledby="gridSystemModalLabel">
    </div>

</section>
<!-- /.content -->

<?php $__env->stopSection(); ?>

<?php $__env->startSection('javascript'); ?>
    <script type="text/javascript">
        $(document).ready(function(){
            var credit_report_table = $('#credit_report_table').DataTable({
                searching: false,
                ordering: true,
                // info: false,
                // dom: 'Bfrtip',
                // buttons: [],
                processing: true,
                serverSide: true,
                "ajax": {
                    "url": '/credit/reports',
                    "data": function ( d ) {
                        d.location_id = $('#location_id').val();
                        d = __datatable_ajax_callback(d);
                    }
                },
                columns: [
                    { data: 'date', name: 'date'  },
                    { data: 'total_topup_amount', name: 'total_topup_amount'},
                    { data: 'total_promo_amount', name: 'total_promo_amount'},
                    { data: 'total_amount', name: 'total_amount'},
                    { data: 'action', name: 'action'}
                ],
            });
            $(document).on('change', '#location_id', 
                function() {
                    credit_report_table.ajax.reload();
            });
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel_works\admin_pos\resources\views/credits_reports/index.blade.php ENDPATH**/ ?>