<?php $__env->startSection('title', 'Coupons Dashboard'); ?>

<?php $__env->startSection('content'); ?>

<!-- Content Header (Page header) -->
<section class="content-header">
    <h1>Coupons Dashboard</h1>    
</section>

<!-- Main content -->
<section class="content">
<div class="row">
				<div class="col-md-3 col-xs-12">
              <?php if(count($all_Coupons) > 0): ?>
				          <?php echo Form::select('all_Coupons', $all_Coupons, $all_Coupons , ['class' => 'form-control', 'id' => 'all_Coupons','placeholder' => 'Select Coupon Group', '']);; ?>

              <?php endif; ?>
        </div>
			  <div class="col-md-3 col-xs-12">
              <?php if(count($all_Campaign) > 0): ?>
			  	        <?php echo Form::select('all_Campaign', $all_Campaign, $all_Campaign , ['class' => 'form-control', 'id' => 'all_Campaign','placeholder' => 'Select Campaign', '']);; ?>

              <?php endif; ?>
        </div>
        <div class="col-md-3 col-xs-12">
			  	        <?php echo Form::select('coupon_status', $coupon_status, $coupon_status,['class' => 'form-control', 'id' => 'coupon_status','placeholder' => 'Select Coupon Type', '']);; ?>

        </div>

        <div class="col-md-3">
            <div class="form-group">
                <!-- <?php echo Form::label('coupon_list_filter_date_range', __('report.date_range') . ':'); ?> -->
                <?php echo Form::text('coupon_list_filter_date_range', null, ['placeholder' => __('lang_v1.select_a_date_range'), 'class' => 'form-control', 'readonly']);; ?>

            </div>
        </div>
</div>
<div class="row">
	<br>
        	<div class="col-md-3 col-sm-6 col-xs-12 col-custom">
    	      <div class="info-box info-box-new-style">
    	        <span class="info-box-icon bg-aqua"><i class="ion ion-cash"></i></span>

    	        <div class="info-box-content">
    	          <span class="info-box-text">Available Coupons</span>
    	          <span class="info-box-number total_AVAILABLE"><?php echo e($coupons['AVAILABLE'], false); ?></span>
    	        </div>
    	        <!-- /.info-box-content -->
    	      </div>
    	      <!-- /.info-box -->
    	    </div>
    	    <!-- /.col -->
    	    <div class="col-md-3 col-sm-6 col-xs-12 col-custom">
    	      <div class="info-box info-box-new-style">
    	        <span class="info-box-icon bg-aqua"><i class="ion ion-ios-cart-outline"></i></span>

    	        <div class="info-box-content">
    	          <span class="info-box-text">Issued Coupons</span>
    	          <span class="info-box-number total_ISSUED"><?php echo e($coupons['ISSUED'], false); ?></span>
    	        </div>
    	        <!-- /.info-box-content -->
    	      </div>
    	      <!-- /.info-box -->
    	    </div>
    	    <!-- /.col -->
    	    <div class="col-md-3 col-sm-6 col-xs-12 col-custom">
    	      <div class="info-box info-box-new-style">
    	        <span class="info-box-icon bg-green">
    	        	<i class="fa fa-dollar"></i>
    				<i class="fa fa-exclamation"></i>
    	        </span>

    	        <div class="info-box-content">
    	          <span class="info-box-text">Redeem Coupons</span>
    	          <span class="info-box-number total_REDEEM"><?php echo e($coupons['REDEEM'], false); ?></span>
    	        </div>
    	        <!-- /.info-box-content -->
    	      </div>
    	      <!-- /.info-box -->
    	    </div>
    	    <!-- /.col -->
    	   
          <div class="clearfix visible-sm-block"></div>
          <div class="col-md-3 col-sm-6 col-xs-12 col-custom">
            <div class="info-box info-box-new-style">
              <span class="info-box-icon bg-red">
                <i class="fas fa-minus-circle"></i>
              </span>

              <div class="info-box-content">
                <span class="info-box-text">Expired Coupons</span>
                <span class="info-box-number total_EXPIRED"><?php echo e($coupons['EXPIRED'], false); ?></span>
              </div>
              <!-- /.info-box-content -->
            </div>
            <!-- /.info-box -->
          </div>
      	</div>
		  
    <?php $__env->startComponent('components.widget', ['class' => 'box-primary', 'title' => '']); ?>
        <div class="table-responsive">
            <table class="table table-bordered table-striped" id="campaignlist">
                <thead>
                    <tr>
                        <th width="5%">Id</th>
                        <th width="15%">QR S/N</th>
                        <th width="15%">Issue Date</th>
                        <th width="15%">Expiry Date</th>
                        <th width="15%">Redeem Date</th>
                        <th width="10%">Status</th>
                        <th width="15%"><?php echo app('translator')->getFromJson('messages.action'); ?></th>
                    </tr>
                </thead>
            </table>
        </div>
    <?php echo $__env->renderComponent(); ?>
</section>

<!-- /.content -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('javascript'); ?>


<script type="text/javascript">
var all_Coupons=0;
var all_Campaign=0;
var barcode_table;
// update_statistics_coupons();
$(document).ready( function(){
        $(document).on('change', '.StatusSelect', function(){
            $.ajax({
                        method: "POST",
                        url: '/qrupdatestatus',
                        data: {cid:$(this).find(':selected').data('id'),val:$(this).val()},
                        success: function(result){
                            if(result.success === 1){
                                toastr.success(result.msg);
                                update_statistics_coupons()
                            } else {
                                toastr.error(result.msg);
                            }
                        }
                    });
        });

        $(document).on('click', 'button.delete_barcode_button', function(){
            swal({
              title: LANG.sure,
              text: LANG.confirm_delete_barcode,
              icon: "warning",
              buttons: true,
              dangerMode: true,
            }).then((willDelete) => {
                if (willDelete) {
                    var href = $(this).data('href');
                    var data = $(this).serialize();

                    $.ajax({
                        method: "DELETE",
                        url: href,
                        dataType: "json",
                        data: data,
                        success: function(result){
                            if(result.success === true){
                                toastr.success(result.msg);
                                barcode_table.ajax.reload();
                            } else {
                                toastr.error(result.msg);
                            }
                        }
                    });
                }
            });
        });

        
        $(document).on('change', '#all_Coupons', function() {
          $.ajax({
                method: 'get',
                url: '/coupons/get-campaign',
                dataType: 'html',
                data: {coupon_id:$(this).val()},
                success: function(data) {
                    console.log(data);
                       $('#all_Campaign').html(data)
                  },
                });
          update_statistics_coupons();
        })
        
        $(document).on('change', '#all_Campaign', function() {
          update_statistics_coupons();
        })

        $(document).on('change', '#coupon_status', function() {
          update_statistics_coupons();
        })

        $('#coupon_list_filter_date_range').daterangepicker(dateRangeSettings, function (start, end) {
            $('#coupon_list_filter_date_range').val(start.format(moment_date_format) + ' ~ ' + end.format(moment_date_format));
            var start_date = $('#coupon_list_filter_date_range').data('daterangepicker').startDate.format('YYYY-MM-DD H:m:s');
            var end_date = $('#coupon_list_filter_date_range').data('daterangepicker').endDate.format('YYYY-MM-DD H:m:s');
            update_statistics_coupons();
        });

        $('#coupon_list_filter_date_range').on('cancel.daterangepicker', function(ev, picker) {
            $('#coupon_list_filter_date_range').val('');
            update_statistics_coupons();
            // purchase_table.ajax.reload();
        });

    function update_statistics_coupons() {
      var location_id = '';
      if ($('#all_Coupons').length > 0) {
        all_Coupons = $('#all_Coupons').val();
      }
      if ($('#all_Campaign').length > 0) {
            all_Campaign = $('#all_Campaign').val();
          }
          if($('#coupon_status').length>0){
            coupon_Status = $('#coupon_status').val();
            console.log(coupon_Status);
          }
          if($('#coupon_list_filter_date_range').length>0){
              var start_Date = $('#coupon_list_filter_date_range').data('daterangepicker').startDate.format('YYYY-MM-DD H:m:s');
              var end_Date = $('#coupon_list_filter_date_range').data('daterangepicker').endDate.format('YYYY-MM-DD H:m:s');
            }
            console.log(start_Date, end_Date);
        var data = { coupon_id: all_Coupons, campaign_id: all_Campaign};
        //get purchase details
        var loader = '<i class="fas fa-sync fa-spin fa-fw margin-bottom"></i>';
        $('.total_AVAILABLE').html(loader);
        $('.total_ISSUED').html(loader);
        $('.total_REDEEM').html(loader);
        $('.total_EXPIRED').html(loader);
        $.ajax({
            method: 'get',
            url: '/coupons/get-totals',
            dataType: 'json',
            data: data,
            success: function(data) {
                //purchase details
                $('.total_AVAILABLE').html((data.AVAILABLE));
                $('.total_ISSUED').html((data.ISSUED));
                $('.total_REDEEM').html((data.REDEEM));
                $('.total_EXPIRED').html((data.EXPIRED));
            },
        });

      $("#campaignlist").dataTable().fnDestroy()
        barcode_table = $('#campaignlist').DataTable({
                processing: true,
                serverSide: true,
                buttons:[],
                ajax: '/campaign-list?id='+all_Campaign+'&coupon_id='+all_Coupons+'&status='+coupon_Status+'&start_d='+start_Date+'&end='+end_Date,
                bPaginate: true,
                columnDefs: [{
                    "targets": 6,
                    "orderable": false,
                    "searchable": false
                }]
            });
            console.log(start_Date, end_Date);
    }
    update_statistics_coupons();
  })        
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel_works\admin_pos\resources\views/coupon_system/dashboard.blade.php ENDPATH**/ ?>