<?php $__env->startSection('title', __( 'nfc.title' )); ?>

<?php $__env->startSection('content'); ?>

<!-- Content Header (Page header) -->
<section class="content-header">
    <h1>HRMS
    </h1><br>
    <div class="row">
        <div class="col-md-12">
            <?php $__env->startComponent('components.filters', ['title' => __('report.filters')]); ?>
              <?php if(empty($only) || in_array('report_list_filter_location_id', $only)): ?>
                <div class="col-md-3">
                    <div class="form-group">
                        <?php echo Form::label('report_list_filter_location_id',  __('purchase.business_location') . ':'); ?>

                        <?php echo Form::select('report_list_filter_location_id', $business_locations, null, ['class' => 'form-control select2', 'style' => 'width:100%', 'placeholder' => __('lang_v1.all') ]);; ?>

                    </div>
                </div>
               <?php endif; ?> 
                <?php if(empty($only) || in_array('report_filter_date_range', $only)): ?>
                    <div class="col-md-3">
                        <div class="form-group">
                            <?php echo Form::label('report_filter_date_range', __('report.date_range') . ':'); ?>

                            <?php echo Form::text('report_filter_date_range', null, ['placeholder' => __('lang_v1.select_a_date_range'), 'class' => 'form-control', 'readonly']); ?>

                        </div>
                    </div>
                <?php endif; ?>
                <?php if(empty($only) || in_array('report_users_filter', $only)): ?>
                <div class="col-md-3">
                    <div class="form-group">
                        <?php echo Form::label('report_users_filter',  __('Users') . ':'); ?>

                        <?php echo Form::select('report_users_filter', $users, null, ['class' => 'form-control select2', 'style' => 'width:100%', 'placeholder' => __('lang_v1.all') ]);; ?>

                    </div>
                </div>
               <?php endif; ?> 
            <?php echo $__env->renderComponent(); ?>
        </div>
    </div>
</section>

<!-- Main content -->
<section class="content">
    <div class="box">
        <div class="box-header">
            <h3 class="box-title">Attendance Report</h3>
        </div>
        <div class="box-body">
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('invoice.view')): ?>
                <table class="table table-bordered table-striped" id="attendance_table">
                    <thead>
                        <tr>
                            <th><?php echo app('translator')->getFromJson( 'Name' ); ?> <?php
                if(session('business.enable_tooltip')){
                    echo '<i class="fa fa-info-circle text-info hover-q no-print " aria-hidden="true" 
                    data-container="body" data-toggle="popover" data-placement="auto bottom" 
                    data-content="' . __('Name') . '" data-html="true" data-trigger="hover"></i>';
                }
                ?></th>
                            <th><?php echo app('translator')->getFromJson( 'Date' ); ?> <?php
                if(session('business.enable_tooltip')){
                    echo '<i class="fa fa-info-circle text-info hover-q no-print " aria-hidden="true" 
                    data-container="body" data-toggle="popover" data-placement="auto bottom" 
                    data-content="' . __('Date') . '" data-html="true" data-trigger="hover"></i>';
                }
                ?></th>
                            <th><?php echo app('translator')->getFromJson( 'Check In' ); ?> <?php
                if(session('business.enable_tooltip')){
                    echo '<i class="fa fa-info-circle text-info hover-q no-print " aria-hidden="true" 
                    data-container="body" data-toggle="popover" data-placement="auto bottom" 
                    data-content="' . __('Check In') . '" data-html="true" data-trigger="hover"></i>';
                }
                ?></th>
                            <th><?php echo app('translator')->getFromJson( 'Check Out' ); ?> <?php
                if(session('business.enable_tooltip')){
                    echo '<i class="fa fa-info-circle text-info hover-q no-print " aria-hidden="true" 
                    data-container="body" data-toggle="popover" data-placement="auto bottom" 
                    data-content="' . __('Check Out') . '" data-html="true" data-trigger="hover"></i>';
                }
                ?></th>
                            <th><?php echo app('translator')->getFromJson( 'Total Working Hrs' ); ?> <?php
                if(session('business.enable_tooltip')){
                    echo '<i class="fa fa-info-circle text-info hover-q no-print " aria-hidden="true" 
                    data-container="body" data-toggle="popover" data-placement="auto bottom" 
                    data-content="' . __('Total Working Hrs') . '" data-html="true" data-trigger="hover"></i>';
                }
                ?></th>
                            <th><?php echo app('translator')->getFromJson( 'Total Shift Hrs' ); ?> <?php
                if(session('business.enable_tooltip')){
                    echo '<i class="fa fa-info-circle text-info hover-q no-print " aria-hidden="true" 
                    data-container="body" data-toggle="popover" data-placement="auto bottom" 
                    data-content="' . __('Total Shift Hrs') . '" data-html="true" data-trigger="hover"></i>';
                }
                ?></th>
                            <th><?php echo app('translator')->getFromJson( 'Total Break Hrs' ); ?> <?php
                if(session('business.enable_tooltip')){
                    echo '<i class="fa fa-info-circle text-info hover-q no-print " aria-hidden="true" 
                    data-container="body" data-toggle="popover" data-placement="auto bottom" 
                    data-content="' . __('Total Break Time') . '" data-html="true" data-trigger="hover"></i>';
                }
                ?></th>
                            <th><?php echo app('translator')->getFromJson( 'messages.action' ); ?></th>
                        </tr>
                    </thead>
                </table>
            <?php endif; ?>
        </div>
    </div>

    <div class="modal fade check_numbers_modal" tabindex="-1" role="dialog" 
        aria-labelledby="gridSystemModalLabel">
    </div>

</section>
<!-- /.content -->

<?php $__env->stopSection(); ?>

<?php $__env->startSection('javascript'); ?>
    <script type="text/javascript">
        $(document).ready(function(){
            $('#report_filter_date_range').daterangepicker(
                dateRangeSettings,
                function (start, end) {
                    $('#report_filter_date_range').val(start.format(moment_date_format) + ' ~ ' + end.format(moment_date_format));
                    attendance_table.ajax.reload();
                }
            );

            $('#report_filter_date_range').on('cancel.daterangepicker', function(ev, picker) {
                $('#report_filter_date_range').val('');
                attendance_table.ajax.reload();
            });

            // Initialize the DataTable
            var attendance_table = $('#attendance_table').DataTable({
                processing: true,
                serverSide: true,
                ajax: {
                    url: '/attendance/attendance_report',
                    data: function (d) {
                        d.location_id = $('#report_list_filter_location_id').val();
                        var user_id = $('#report_users_filter').val();
                        d.user_id = user_id;
                        if ($('#report_filter_date_range').val()) {
                            var start = $('#report_filter_date_range').data('daterangepicker').startDate.format('YYYY-MM-DD');
                            var end = $('#report_filter_date_range').data('daterangepicker').endDate.format('YYYY-MM-DD');
                            d.start_date = start;
                            d.end_date = end;
                        }
                    }
                },
                columns: [
                    { data: 'first_name', name: 'first_name' },
                    { data: 'date', name: 'date' },
                    { data: 'first_clockin_time', name: 'first_clockin_time' },
                    { data: 'last_clockout_time', name: 'last_clockout_time' },
                    { data: 'total_working_hours', name: 'total_working_hours' },
                    { data: 'total_shift_hours', name: 'total_shift_hours' },
                    { data: 'total_break_time', name: 'total_break_time' },
                    { data: 'action', name: 'action', orderable: false, searchable: false }
                ]
            });
            $(document).on('change', '#report_users_filter', function() {
                attendance_table.ajax.reload();
            });
            $(document).on('change', '#report_list_filter_location_id', function() {
                attendance_table.ajax.reload();
            });
           
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel_works\admin_pos\resources\views/attendance/index.blade.php ENDPATH**/ ?>