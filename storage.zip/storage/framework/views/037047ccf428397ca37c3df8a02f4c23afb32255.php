<div class="table-responsive">
<table class="table table-bordered table-striped" id="all_sales_report" style="width: 100%;">
    <thead>
        <tr>
            <th><?php echo app('translator')->getFromJson('messages.date'); ?></th>
            <th><?php echo app('translator')->getFromJson('lang_v1.receipt'); ?></th>
            <th>Total Item Sales</th>
            <th>Refunds</th>
            <th><?php echo app('translator')->getFromJson('lang_v1.item_discount'); ?></th>
            <th><?php echo app('translator')->getFromJson('lang_v1.customer_discount'); ?></th>
            <th><?php echo app('translator')->getFromJson('lang_v1.order_discount'); ?></th>
            <th><?php echo app('translator')->getFromJson('lang_v1.foc'); ?></th>
            <th><?php echo app('translator')->getFromJson('lang_v1.net_sales'); ?></th>
            <th><?php echo app('translator')->getFromJson('lang_v1.points_deducted'); ?></th>
            <th><?php echo app('translator')->getFromJson('lang_v1.service_charges'); ?></th>
            <th>Payment Method</th>
            <th>Payment Type</th>
            <th><?php echo app('translator')->getFromJson('lang_v1.gross'); ?></th>
            <th><?php echo app('translator')->getFromJson('lang_v1.gst'); ?></th>
            <th><?php echo app('translator')->getFromJson('lang_v1.rounding'); ?></th>
            <th>Voucher Amount</th>
            <th><?php echo app('translator')->getFromJson('lang_v1.tips'); ?></th>
            <th><?php echo app('translator')->getFromJson('lang_v1.payable_amount'); ?></th>
            <!-- <th><?php echo app('translator')->getFromJson('lang_v1.cash'); ?></th>
            <th><?php echo app('translator')->getFromJson('lang_v1.nets'); ?></th> -->
            <!-- Column for product names -->
        </tr>
    </thead>
    <tfoot>
    <tr class="bg-gray font-17 footer-total text-center">
        <td colspan="2"><strong><?php echo app('translator')->getFromJson('sale.total'); ?>:</strong></td>
        <td class="total_item_sales_sum"><span class="display_currency" data-currency_symbol="true"></span></td>
        <td class="item_discount_sum"><span class="display_currency" data-currency_symbol="true"></span></td>
        <td class="refunds"><span class="display_currency" data-currency_symbol="true"></span></td>
        <td class="total_customer_discount"><span class="display_currency" data-currency_symbol="true"></span></td>
        <td class="foc"><span class="display_currency" data-currency_symbol="true"></span></td>
        <td class="net_sales"><span class="display_currency" data-currency_symbol="true"></span></td>
        <td class="points_deducted"><span class="display_currency" data-currency_symbol="true"></span></td>
        <td class="service_charges"><span class="display_currency" data-currency_symbol="true"></span></td>
        <td class="payment_method"><span class="display_currency" data-currency_symbol="true"></span></td>
        <td class="payment_type"><span class="display_currency" data-currency_symbol="true"></span></td>
        <td class="gross"><span class="display_currency" data-currency_symbol="true"></span></td>
        <td class="gst"><span class="display_currency" data-currency_symbol="true"></span></td>
        <td class="rounding"><span class="display_currency" data-currency_symbol="true"></span></td>
        <td class="voucher"><span class="display_currency" data-currency_symbol="true"></span></td>
        <td class="tips"><span class="display_currency" data-currency_symbol="true"></span></td>
        <td class="payable"><span class="display_currency" data-currency_symbol="true"></span></td>
        <td></td>
    </tr>
</tfoot>
</table>
</div><?php /**PATH C:\xampp\htdocs\laravel_works\admin_pos\resources\views/report/partials/all_sales_report.blade.php ENDPATH**/ ?>