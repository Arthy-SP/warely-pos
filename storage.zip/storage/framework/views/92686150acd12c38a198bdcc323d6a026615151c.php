<div class="table-responsive">
    <table class="table table-bordered table-striped" id="profit_analysis_report" style="width: 100%;">
        <thead>
            <tr>
                <th><?php echo app('translator')->getFromJson('product.category'); ?></th>
                <th>SKU</th>
                <th>Product Name</th>
                <th>Quantity Sold</th>
                <th>Total Item Sales</th>
                <th>FOC</th>
                <th>Net Sales</th>
                <th>Purchase Price</th>
                <th>Profit %</th>
                <th>Profit $</th>
            </tr>
        </thead>
        <tfoot>
            <tr class="bg-gray font-17 footer-total text-center">
                <td colspan="3"><strong><?php echo app('translator')->getFromJson('sale.total'); ?>:</strong></td>            
                <td class="total_quantity_sold"><span class="display_currency" data-currency_symbol="true"></span></td>
                <td class="total_item_sales"><span class="display_currency" data-currency_symbol="true"></span></td>
                <td class="foc"><span class="display_currency" data-currency_symbol="true"></span></td>
                <td class="net_sales"><span class="display_currency" data-currency_symbol="true"></span></td>
                <td class="purchase_price"><span class="display_currency" data-currency_symbol="true"></span></td>
                <td class="profit_percent"><span class="display_currency" data-currency_symbol="true"></span></td>
                <td class="profit"><span class="display_currency" data-currency_symbol="true"></span></td>
            
            </tr>
        </tfoot>
    </table>
</div><?php /**PATH C:\xampp\htdocs\laravel_works\admin_pos\resources\views/report/partials/profit_reports.blade.php ENDPATH**/ ?>