<?php $__env->startSection('title', __('sale.products')); ?>

<?php $__env->startSection('content'); ?>

<!-- Content Header (Page header) -->
<section class="content-header">
    <h1>Add Product</h1>


    <!-- <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Level</a></li>
        <li class="active">Here</li>
    </ol> -->
</section>

<!-- Main content -->
<section class="content">

    <div class="row">
        <div class="col-md-12">
            <?php $__env->startComponent('components.filters', ['title' => __('report.filters')]); ?>

            <div class="col-md-3">
                <div class="form-group">
                    <?php echo Form::label('category_id','Product Category:'); ?>

                    <?php echo Form::select('category_id', $categories, null, ['class' => 'form-control select2', 'style' => 'width:100%', 'id' => 'product_list_filter_category_id', 'placeholder' => __('lang_v1.all')]); ?>

                </div>
            </div>

            <div class="col-md-3" id="location_filter">
                <div class="form-group">
                    <?php echo Form::label('location_id', __('purchase.business_location') . ':'); ?>

                    <?php echo Form::select('location_id', $business_locations, null, ['class' => 'form-control select2', 'style' => 'width:100%', 'placeholder' => __('lang_v1.all')]); ?>

                </div>
            </div>



            <?php echo $__env->renderComponent(); ?>
        </div>
    </div>
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('product.view')): ?>
    <div class="row">
        <div class="col-md-12">
            <!-- Custom Tabs -->
            <div class="nav-tabs-custom">
          
                <div class="tab-content">
                      <?php echo Form::open(['url' => action('Lazada\LazadaMainController@UploadProductToLazada'),'method' => 'post', 'id' => 'lazada_add_form' ]); ?>

                    <div class="row">
                        <div class="col-md-3">
                            <div class="form-group">
                                <label for="Category">Choose a Category:</label>
                                <select class="form-control" name="lazada_cat_id" id="lazada_cat_id">
                                    <option value="">Select a Category</option>
                                    <?php $__currentLoopData = $lazada_cat['data']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($category['category_id'], false); ?>" data-children="<?php echo e(json_encode($category['children']), false); ?>"><?php echo e($category['name'], false); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </select>
                            </div>
                        </div>
                        <!-- sub category -->
                        <div class="col-md-3">
                            <div class="form-group">
                                <label for="subcategory">Choose a subcategory:</label>
                                <select class="form-control" name="subcategory_id" id="subcategory">
                                    <option value="">Select a subcategory</option>
                                    <!-- Subcategory options will be populated here -->
                                </select>
                            </div>
                        </div>
                        <!-- child category -->
                        <div class="col-md-3" id="child_cat_div">
                            <div class="form-group">
                                <label for="subcategory">Choose a Child category:</label>
                                <select class="form-control" name="child_cat" id="child_cat">
                                    <option value="">Select a Child Category</option>
                                    <!-- Subcategory options will be populated here -->
                                </select>
                            </div>
                        </div>
                        <!-- child category -->
                        <div class="col-md-3" id="leaf_cat_id">
                            <div class="form-group">
                                <label for="subcategory">Choose a Leaf category:</label>
                                <select class="form-control" name="leaf_cat" id="leaf_cat">
                                    <option value="">Select a Leaf Category</option>
                                    <!-- Subcategory options will be populated here -->
                                </select>
                            </div>
                        </div>
                   
                        <div id="dynamic-fields"></div>
                    </div>

                    <div class="">
                        <div id="retail_product_list_tab">
                            <?php echo $__env->make('lazada.product_list_table', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php endif; ?>



</section>
<!-- /.content -->

<?php $__env->stopSection(); ?>

<?php $__env->startSection('javascript'); ?>
<script src="<?php echo e(asset('js/product.js?v=' . $asset_v), false); ?>"></script>
<script src="<?php echo e(asset('js/opening_stock.js?v=' . $asset_v), false); ?>"></script>
<script type="text/javascript">
    $(document).ready(function() {

        $('#lazada_cat_id').on('change', function(e) {

            const subcategorySelect = document.getElementById('subcategory');
            const selectedOption = $('option:selected', this).attr('data-children');
            const children = JSON.parse(selectedOption);
            $('input#sub_cat_id').val('');
            $('input#child_cat_id').val('');
            $('input#leaf_cat_id').val('');
            // Clear existing options in subcategory
            subcategorySelect.innerHTML = '<option value="">Select a subcategory</option>';

            if (children) {
                children.forEach(child => {
                    const option = document.createElement('option');
                    option.value = child['category_id'];
                    option.setAttribute('data-children', JSON.stringify(child['children']));
                    option.textContent = child['name'];

                    subcategorySelect.appendChild(option);
                });
            }
        });
        $('#subcategory').on('change', function(e) {
            const child_category = document.getElementById('child_cat');
            const selectedOption = $('option:selected', this).attr('data-children');
            $('input#sub_cat_id').val($(this).val());
            $('input#child_cat_id').val('');
            $('input#leaf_cat_id').val('');

            if (selectedOption == 'undefined' || selectedOption == '') {
                document.getElementById("child_cat_div").style.display = 'none';
                document.getElementById("leaf_cat_id").style.display = 'none';
                attributeAjaxcall($(this).val());

            } else {
                document.getElementById("child_cat_div").style.display = 'block';
                const children = JSON.parse(selectedOption);
                child_category.innerHTML = '<option value="">Select a Child Category</option>';

                if (children) {
                    children.forEach(child => {
                        const option = document.createElement('option');
                        option.value = child['category_id'];
                        option.textContent = child['name'];
                        option.setAttribute('data-children', JSON.stringify(child['children']));
                        child_category.appendChild(option);
                    });
                }
            }

        });
        $('#child_cat').on('change', function(e) {
            const leaf_cat_selected = document.getElementById('leaf_cat');

            const selectedOption = $('option:selected', this).attr('data-children');

            $('input#child_cat_id').val($(this).val());
            $('input#leaf_cat_id').val('');
            if (selectedOption === 'undefined' || selectedOption === null) {
                document.getElementById("leaf_cat_id").style.display = 'none';
                attributeAjaxcall($(this).val());
            } else {
                document.getElementById("leaf_cat_id").style.display = 'block';
                const children = JSON.parse(selectedOption);
                leaf_cat_selected.innerHTML = '<option value="">Select a Leaf Category</option>';

                if (children) {
                    children.forEach(child => {
                        const option = document.createElement('option');
                        option.value = child['category_id'];
                        option.textContent = child['name'];
                        leaf_cat_selected.appendChild(option);
                    });
                }
            }


        });
        $('#leaf_cat').on('change', function(e) {
            const selectedOption = $('option:selected', this).attr('data-children');
            $('input#leaf_cat_id').val($(this).val());
            attributeAjaxcall($(this).val());

        });



        retail_product_table = $('#retail_product_table').DataTable({
            processing: true,
            serverSide: true,
            aaSorting: [
                [3, 'asc']
            ],
            scrollY: "75vh",
            scrollX: true,
            scrollCollapse: true,
            searching: false,
            buttons: [],
            "ajax": {
                "url": "/lazada/product/list",
                "data": function(d) {
                    d.type = $('#product_list_filter_type').val();
                    d.category_id = $('#product_list_filter_category_id').val();
                    d.brand_id = $('#product_list_filter_brand_id').val();
                    d.unit_id = $('#product_list_filter_unit_id').val();
                    d.tax_id = $('#product_list_filter_tax_id').val();
                    d.active_state = $('#active_state').val();
                    d.not_for_selling = $('#not_for_selling').is(':checked');
                    d.location_id = $('#location_id').val();
                    if ($('#repair_model_id').length == 1) {
                        d.repair_model_id = $('#repair_model_id').val();
                    }

                    if ($('#woocommerce_enabled').length == 1 && $('#woocommerce_enabled').is(':checked')) {
                        d.woocommerce_enabled = 1;
                    }
                    d.action = "add";
                    d = __datatable_ajax_callback(d);
                }
            },
            columnDefs: [{
                "targets": [0, 1, 2],
                "orderable": false,
                "searchable": false
            }],
            columns: [{
                    data: 'mass_delete'
                },
                {
                    data: 'image',
                    name: 'products.image'
                },
                {
                    data: 'product',
                    name: 'products.name'
                },
                {
                    data: 'sku',
                    name: 'products.sku'
                },
                {
                    data: 'brand',
                    name: 'brands.name'
                },
                {
                    data: 'category',
                    name: 'c1.name'
                },
                {
                    data: 'sku',
                    name: 'products.sku'
                },
                {
                    data: 'product_locations',
                    name: 'product_locations'
                },
                {
                    data: 'type',
                    name: 'type'
                },
                {
                    data: 'current_stock',
                    name: 'products.current_stock'
                },
                {
                    data: 'lazada_price',
                    name: 'lazada_price',
                    searchable: false
                },

            ],
            createdRow: function(row, data, dataIndex) {
                if ($('input#is_rack_enabled').val() == 1) {
                    var target_col = 0;

                    $(row).find('td:eq(' + target_col + ') div').prepend('<i style="margin:auto;" class="fa fa-plus-circle text-success cursor-pointer no-print rack-details" title="' + LANG.details + '"></i>&nbsp;&nbsp;');
                }
                $(row).find('td:eq(0)').attr('class', 'selectable_td');
            },
            fnDrawCallback: function(oSettings) {
                __currency_convert_recursively($('#retail_product_table'));
            },
        });
        // Array to track the ids of the details displayed rows

        $(document).on('change', '#product_list_filter_type, #product_list_filter_category_id, #product_list_filter_brand_id, #product_list_filter_unit_id, #product_list_filter_tax_id, #location_id, #active_state, #repair_model_id',
            function() {

                retail_product_table.ajax.reload();

            });

        $('#product_location').select2({
            dropdownParent: $('#product_location').closest('.modal')
        });
    });

    function validateSelections() {
        // Validate main category selection
        if ($('#lazada_cat_id').val() === '') {
            swal({
                title: 'Main category is required!',
                text: 'Please select a main category.',
                icon: 'warning',
                buttons: ['OK'],
            });
            return false;
        }

        // Validate subcategory selection
        if ($('#subcategory').val() === '') {
            swal({
                title: 'Subcategory is required!',
                text: 'Please select a subcategory.',
                icon: 'warning',
                buttons: ['OK'],
            });
            return false;
        }

        // Validate child category selection (only if visible)
        if ($('#child_cat').is(':visible') && $('#child_cat').val() === '') {
            swal({
                title: 'Child category is required!',
                text: 'Please select a child category.',
                icon: 'warning',
                buttons: ['OK'],
            });
            return false;
        }

        // Validate leaf category selection (only if visible)
        if ($('#leaf_cat').is(':visible') && $('#leaf_cat').val() === '') {
            swal({
                title: 'Leaf category is required!',
                text: 'Please select a leaf category.',
                icon: 'warning',
                buttons: ['OK'],
            });
            return false;
        }

        return true; // All selections are valid
    }

    $(document).on('click', '#add-selected', function(e) {

        e.preventDefault();
        var selected_rows = getSelectedRows();
        isValid = true; 
        document.querySelectorAll('.validate-input').forEach(function(input) {
            const errorMessage = input.nextElementSibling; // Assume the error message is right after the input
            const value = input.value.trim();
          
            if (value === '') {
              
                isValid = false; 
                swal({
                    title: 'Validation Error!',
                    text: 'Please Enter All Input Fields.',
                    icon: 'warning',
                    buttons: ['OK'],
                });
                return false;
            }


        });
        if (validateSelections()) {
       if(isValid){
                if (selected_rows.length > 0) {
                    $('input#selected_products').val(selected_rows);
                    swal({
                        title: LANG.sure,
                        icon: "warning",
                        buttons: true,
                        dangerMode: true,
                    }).then((willDelete) => {
                        if (willDelete) {
                            var form = $('form#lazada_add_form')

                            var data = form.serialize();
                            $.ajax({
                                method: form.attr('method'),
                                url: form.attr('action'),
                                dataType: 'json',
                                data: data,
                                success: function(result) {
                                    if (result.success == true) {
                                        toastr.success(result.msg);
                                        retail_product_table.ajax.reload();
                                        form
                                            .find('#selected_products')
                                            .val('');
                                    } else {
                                        retail_product_table.ajax.reload();
                                        toastr.error(result.msg);
                                    }
                                },
                            });
                        }
                    });
                } else {
                    $('input#selected_products').val('');
                    swal('<?php echo app('translator')->getFromJson("lang_v1.no_row_selected"); ?>');
                }
            }
        }
        
       
    })


    function attributeAjaxcall(childCatId) {
        $.ajax({
                url: '<?php echo e(route('get_product_attributes'), false); ?>', // Define this route in Laravel
                type: 'GET',
                data: { 
                    child_cat_id: childCatId  // Send childCatId as a parameter
                },
                success: function(response) {
                    let fieldsHtml = '';
                        $.each(response, function(index, attribute) {
                    if (attribute.is_mandatory === 1 && attribute.attribute_type === 'normal') {
                       
                        if (attribute.input_type === 'multiEnumInput') {
                           
                            // Dropdown field
                            fieldsHtml += `
                             <div class="col-md-3" >
                            <div class="form-group">
                                    <label for="${attribute.name}">${attribute.label} : </label>
                                    <input type="hidden" class="form-control" value="${attribute.name}" id="${attribute.label}" name="option_label[]" >
                                    <select class="form-control validate-input" id="${attribute.name}" name="option_atribute[]">
                                        <option value="">Select ${attribute.label}</option>
                                        ${attribute.options.map(option => `
                                            <option value="${option.id}">${option.name}</option>
                                        `).join('')}
                                    </select>
                                </div>
                                </div>
                            `;
                        } else if (attribute.input_type === 'singleSelect') {
                            // Text input field
                            fieldsHtml += `
                            <div class="col-md-3">
                                <div class="form-group">
                                    <label for="${attribute.name}">${attribute.label} :</label>
                                   
                                    <input type="hidden" class="form-control" value="${attribute.name}" id="${attribute.name}" name="atri_label[]" placeholder="Enter ${attribute.label}">

                                    <input type="text" class="form-control validate-input" id="${attribute.name}" name="atribute[]" placeholder="Enter ${attribute.label}">
                                </div>
                                </div>
                            `;
                        }
                    }
                });
                    // Append the fields to the form
                    $('#dynamic-fields').html(fieldsHtml);
                },
                error: function() {
                    alert('Error fetching attributes.');
                }
            });
    }
</script>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel_works\new_pos\resources\views/lazada/add_product.blade.php ENDPATH**/ ?>