<?php $__env->startSection('title', __( 'lang_v1.xero' )); ?>

<?php $__env->startSection('content'); ?>
<section class="content-header">
    <h1><?php echo app('translator')->getFromJson('lang_v1.xero'); ?></h1>
</section>
<section class="content">
    <div class="row">

        <div class="col-sm-12">
            <div class="col-sm-6">
                <div class="form-group">
                    <label for="location_id"><?php echo app('translator')->getFromJson('Location'); ?></label>
                    <select name="location_id" id="location_id" class="form-control">
                        <!--<option value=""><?php echo app('translator')->getFromJson('All Locations'); ?></option>-->
                        <?php $__currentLoopData = $locations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $name): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($id, false); ?>"><?php echo e($name, false); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
            </div>
        </div>
        
        <div class="col-sm-6">
            
            <div class="col-sm-12">
                <div class="box box-solid">
                    <div class="box-header">
                        <i class="fa fa-user"></i>
                        <h3 class="box-title">Authorize User</h3>
                    </div>
                    <div class="box-body">
                        <div class="col-sm-6">
                        <a href="<?php echo e(route('xero.auth', ['client_id' => $business->xero_client_id]), false); ?>" class="btn btn-primary">Authorize with Xero</a>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-sm-12">
                <div class="box box-solid">
                    <div class="box-header">
                        <i class="fa fa-cubes"></i>
                        <h3 class="box-title"><?php echo app('translator')->getFromJson('woocommerce::lang.sync_products'); ?>:</h3>
                    </div>
                    <div class="box-body">
                        <?php if(!empty($alerts['not_synced_product']) || !empty($alerts['not_updated_product'])): ?>
                        <div class="col-sm-12">
                            <div class="alert alert-warning alert-dismissible">
                                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                                <ul>
                                    <?php if(!empty($alerts['not_synced_product'])): ?>
                                        <li><?php echo e($alerts['not_synced_product'], false); ?></li>
                                    <?php endif; ?>
                                    <?php if(!empty($alerts['not_updated_product'])): ?>
                                        <li><?php echo e($alerts['not_updated_product'], false); ?></li>
                                    <?php endif; ?>
                                </ul>
                            </div>
                        </div>
                        <?php endif; ?>
                        <div class="col-sm-6">
                            <div style="display: inline-flex; width: 100%;">
                            <a href="<?php echo e(route('sync.products'), false); ?>" class="btn btn-success">Sync Products</a>
                            </div>
                            <span class="last_sync_new_products"></span>
                        </div>
                        <div class="col-sm-12">
                            <br>
                            <button type="button" class="btn btn-danger btn-xs" id="reset_products"> <i class="fa fa-undo"></i> <?php echo app('translator')->getFromJson('woocommerce::lang.reset_synced_products'); ?></button>
                        </div>
                    </div>
               </div>
           </div>

           <div class="col-sm-12">
               <div class="box box-solid">
                    <div class="box-header">
                        <i class="fa fa-cart-plus"></i>
                        <h3 class="box-title"><?php echo app('translator')->getFromJson('woocommerce::lang.sync_orders'); ?>:</h3>
                    </div>
                    <div class="box-body">
                        <div class="col-sm-6">
                            <div style="display: inline-flex; width: 100%;">
                                <a href="<?php echo e(route('sync.products'), false); ?>" class="btn btn-success">Sync Products</a>
                            </div>
                            <span class="last_sync_new_products"></span>
                        </div>
                    </div>
               </div>
            </div>

        </div>
    </div>
</section>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('javascript'); ?>
<script type="text/javascript">
    $(document).ready(function () {

        // $(window).on('load', function() {
        //     unsetSessionKey();
        // });

        $('#location_id').on('change', function () {
            var locationId = $(this).val();
            fetchSelectedLocation(locationId);
        });

        function unsetSessionKey() {
            $.ajax({
                url: "<?php echo e(route('unset.location.session'), false); ?>",
                type: 'POST',
                data: {
                    _token: "<?php echo e(csrf_token(), false); ?>"
                },
                async: false,
                success: function (response) {
                },
                error: function (xhr, status, error) {
                }
            });
        }

        function fetchSelectedLocation(locationId) {
            $.ajax({
                url: "<?php echo e(route('get.selected.location'), false); ?>",
                type: 'POST',
                data: {
                    location_id: locationId
                },
                success: function (response) {
                    console.log(response.location);
                },
                error: function (xhr, status, error) {
                }
            });
        }
    });
   
    function getQueryParam(name) {
        const urlParams = new URLSearchParams(window.location.search);
        return urlParams.get(name);
    }

    function saveCodeToLocalStorage() {
        const code = getQueryParam('code');

        if (code) {
            localStorage.setItem('xeroCode', code);
            console.log('Code saved to local storage:', code);
        }
    }

    window.onload = function() {
        saveCodeToLocalStorage();

        const savedCode = localStorage.getItem('xeroCode');
        if (savedCode) {
            console.log('Code retrieved from local storage:', savedCode);
        } else {
            console.log('No code found in local storage.');
        }
    };
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel_works\admin_pos\resources\views/xero/index.blade.php ENDPATH**/ ?>