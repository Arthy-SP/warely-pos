<?php $__env->startSection('title', __( 'gto.business_outlets' )); ?>
<?php $__env->startSection('content'); ?>
<section class="content-header">
    <h1><?php echo app('translator')->getFromJson( 'gto.business_outlets' ); ?>
        <small><?php echo app('translator')->getFromJson( 'gto.manage_outlets' ); ?></small>
    </h1>
</section>

<!-- Main content -->
<section class="content">
	<div class="box box-solid">
        <div class="box-header">
            <h3 class="box-title">&nbsp;</h3>
        	<div class="box-tools">
                <div class="col-sm-12 text-right">
                    <button type="button" class="btn btn-primary" id="add_new_outlet"><i class="fa fa-plus"></i> <?php echo app('translator')->getFromJson('messages.add'); ?></button>
                </div>
            </div>
        </div>

        <div class="box-body">
                <div class="table-responsive">
                    <table class="table table-bordered table-striped" id="manage_outlets_table">
                        <thead>
                            <tr>
                                <th><?php echo app('translator')->getFromJson( 'gto.outlet_name' ); ?></th>
                                <th><?php echo app('translator')->getFromJson( 'gto.outlet_start_date' ); ?></th>
                                <th><?php echo app('translator')->getFromJson( 'gto.outlet_report_type' ); ?></th>
                                <th><?php echo app('translator')->getFromJson( 'gto.outlet_file_formats' ); ?></th>
                                <th><?php echo app('translator')->getFromJson( 'gto.outlet_file_date' ); ?></th>
                                <th><?php echo app('translator')->getFromJson( 'gto.outlet_report_date' ); ?></th>
                                <th><?php echo app('translator')->getFromJson( 'gto.outlet_report_formats' ); ?></th>
                                <th><?php echo app('translator')->getFromJson( 'Action' ); ?></th>
                            </tr>
                        </thead>
                    </table>
                </div>
        </div>
    </div>

</section>
<?php echo $__env->make('business_outlets.create', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('business_outlets.edit', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('javascript'); ?>
    <script type="text/javascript">
        $(document).ready(function() {
            function initializeAndReorderSelect(selectElement) {
                let updating = false;
                let options = selectElement.find('option').get();
                options.sort(() => Math.random() - 0.5);
                selectElement.empty().append(options);
                selectElement.trigger('change');
                selectElement.on('change', function(e) {
                    if (updating) return; 
                    updating = true; 

                    let selectedValues = $(this).val();
                    let allOptions = selectElement.find('option').get();

                    let selectedOptions = [];
                    let remainingOptions = [];

                    allOptions.forEach(option => {
                        if (selectedValues.includes(option.value)) {
                            selectedOptions.push(option);
                        } else {
                            remainingOptions.push(option);
                        }
                    });

                    selectElement.empty().append(selectedOptions).append(remainingOptions);
                    selectElement.trigger('change');

                    updating = false; 
                });
            }

            // Function to sequentially select options
            function selectOptionsSequentially(formats,selectElement, index = 0) {
                if (index < formats.length) {
                    var valueToSelect = formats[index];
                    var currentValues = selectElement.val() || [];
                    if (!currentValues.includes(valueToSelect.toString())) {
                    currentValues.push(valueToSelect);
                    }
                    selectElement.val(currentValues).trigger('change'); 
                        selectOptionsSequentially(formats,selectElement, index + 1);
                }
            }

            $('#manage_outlets').submit(function (e) {
                e.preventDefault(); 
                var submitButton = $(this).find('button[type="submit"]');
                submitButton.prop('disabled', true);
                var formData = $(this).serialize(); 
                formData += '&file_formats=' + encodeURIComponent(JSON.stringify(fileFormatArray)); 
                $.ajax({
                    url: $(this).attr('action'),
                    method: $(this).attr('method'),
                    data: formData,
                    success: function (response) { 
                        if(response.success){
                            fileFormatArray.length = 0
                            toastr.success("Outlet add sucessfully.");
                            outletDatatable.ajax.reload();
                            $('div#add_outlet_model').modal('hide');
                            $('#manage_outlets')[0].reset();
                            $('.select2').trigger('change'); 
                        } else {
                            toastr.error(response.message);
                        }
                    },
                    error: function (xhr, status, error) {
                        toastr.error(error);
                    },
                    complete: function () {
                    submitButton.prop('disabled', false);
                    }
                    });
            });  

            var outletDatatable = $('#manage_outlets_table').DataTable({
                processing: true,
                serverSide: true,
                ajax: {
                    url: "<?php echo e(route('business-outlets.index'), false); ?>", 
                    type: "GET",
                },
                columns: [
                    { "data": "name" },
                    { "data": "start_date" },
                    { "data": "report_type" },
                    { "data": "file_formats" },
                    { "data": "file_date_format" },
                    { "data": "report_date_format" },
                    { "data": "report_formats" },
                    { data: 'action', name: 'action', orderable: false, searchable: false }
                ]
            });

            // Initialize both select elements on add outlet
            let outletReportformat = $('#outlet_report_format');
            initializeAndReorderSelect(outletReportformat);

            // Initialize both select elements on update  outlet
            let updateOutletReportformat = $('#update_outlet_report_format');
            initializeAndReorderSelect(updateOutletReportformat);
           
            //Preview file/report pattern
            $('#outlet_report_format, #update_outlet_report_format').on('change', function() {
                let selectedOptions = $(this).find('option:selected');
                let selectedTexts = selectedOptions.map(function() {
                    return $(this).text() +" | " ;
                }).get();
                let formattedTexts = selectedTexts.join('')
                if (selectedTexts.length > 0) {
                    $('#report_format_preview, #update_report_format_preview').text(`Selected formats: ${formattedTexts}`);
                } else {
                    $('#report_format_preview, #update_report_format_preview').text('');
                }
            });

            $('#add_outlet_model').on('shown.bs.modal', function () {
                $('#outlet_report_format').select2({
                    placeholder: "<?php echo e(__('messages.please_select'), false); ?>",
                    allowClear: true
                });
            });
            $('button#add_new_outlet').click( function(){
                $('div#add_outlet_model').modal('show');
                $('#report_format_preview, #file_format_preview').text('');
            });

            //update outlet
            $('#update_outlet_model').on('shown.bs.modal', function () {
                $('#update_outlet_report_format').select2({
                    placeholder: "<?php echo e(__('messages.please_select'), false); ?>",
                    allowClear: true
                });
            });
            let updateFileFormatArray = []
            //load data on edit model
            $(document).on('click', 'button#outlet-update', function() {
                const outletId = $(this).data('id');
                $.ajax({
                    url: '/business-outlets/' + outletId ,
                    method: 'GET',  
                    success: function(response) {
                        const data = response.data;
                        updateFileFormatArray = data.format_array;
                        if(response.success){ 
                            let formActionUrl = '/business-outlets/' +outletId;
                            $('#update_outlets_form').attr('action', formActionUrl);
                            $('#update_outlet_model #name').val(data.name);
                            $('#update_outlet_model #start_date').val(data.start_date);
                            let selectFileformatlement = $('#update_outlet_file_format1').val(data.file_formats.split(".txt").join(""));
                            let selectReportformatlement = $('#update_outlet_report_format');
                            $(`#update_file_format_preview`).text(`Selected formats:${data.file_formats}`);
                           // selectOptionsSequentially(data.file_formats, selectFileformatlement);
                            selectOptionsSequentially(data.report_formats, selectReportformatlement);
                            $('#update_outlet_model #report_type').val(data.report_type).trigger('change');
                            $('#update_outlet_model #report_date_format').val(data.date_formats && data.date_formats.report ? data.date_formats.report : "Ymd").trigger('change');
                            $('#update_outlet_model #file_date_format').val(data.date_formats && data.date_formats.file ? data.date_formats.file : "ymd" ).trigger('change');
                        }
                        $('#update_outlet_model').modal('show');
                    },
                    error: function(xhr) {
                        console.error('Error fetching outlet data:', xhr);
                    }
                });            
            
            });

            //Update outlet data
            $('#update_outlets_form').submit(function (e) {
                e.preventDefault(); 
                var submitButton = $(this).find('button[type="submit"]');
                submitButton.prop('disabled', true);
                var formData = $(this).serialize();
                formData += '&file_formats=' + encodeURIComponent(JSON.stringify(updateFileFormatArray)); 
                $.ajax({
                    url: $(this).attr('action'),
                    method: $(this).attr('method'),
                    data: formData,
                    success: function (response) { 
                        if(response.success){
                            toastr.success("Outlet add sucessfully.");
                            outletDatatable.ajax.reload();
                            $('div#update_outlet_model').modal('hide');
                            $('#update_outlets_form')[0].reset();
                            $('.select2').trigger('change'); 
                        } else {
                            toastr.error(response.message);
                        }
                    },
                    error: function (xhr, status, error) {
                        toastr.error(error);
                    },
                    complete: function () {
                    submitButton.prop('disabled', false);
                    }
                    });
            }); 
            function manageFileFormats(tagId, previewId, format, fileId, fileArr){
                fileArr.push(fileId);
                $(`#${tagId}`).val($(`#${tagId}`).val()+format);
                if (format) {
                    $(`#${previewId}`).text(`Selected formats: ${$(`#${tagId}`).val()}.txt`);
                }
            }
            let fileFormatArray = [];
            $(".file-format-btn").on("click", function(){
                const format = $(this).text().trim();
                const id = $(this).data("id");
                const action = $(this).data("action");
                console.log(fileFormatArray)
                if(action === "create"){
                    manageFileFormats("outlet_file_format1","file_format_preview", format, id, fileFormatArray );
                }else{
                    manageFileFormats("update_outlet_file_format1","update_file_format_preview", format, id, updateFileFormatArray );
                }
            })
            $(".clear-file-format").on("click", function(){
                $("#outlet_file_format1,#update_outlet_file_format1").val("");
                fileFormatArray.length = 0;
                updateFileFormatArray.length = 0;
                $(`#update_file_format_preview, #file_format_preview`).text(`Selected formats:`);
            })

        });
        function downloadSample(fileFormats,reportType, reportFormats) {
            let reportFormatsArray = reportFormats.split("|");
            let content = '';
            if(reportType === "hourly") {
                content = Array(24).fill(reportFormatsArray.map(format => `0.00 | `).join("")).join("\n");
            } else {
                content = reportFormatsArray.map(format => `0.00 | `).join("");
            }
           let dataURL = 'data:text/plain;charset=utf-8,' + encodeURIComponent(content);
            const a = document.createElement('a');
            a.href = dataURL;
            a.download = fileFormats;
            a.click();
            URL.revokeObjectURL(a.href);
        }
    </script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel_works\admin_pos\resources\views/business_outlets/index.blade.php ENDPATH**/ ?>