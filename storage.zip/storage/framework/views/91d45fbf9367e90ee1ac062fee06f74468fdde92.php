<?php $__env->startSection('title',__('Shopee')); ?>

<?php $__env->startSection('content'); ?>

<!-- Content Header (Page header) -->
<section class="content-header">
    <h1><?php echo app('translator')->getFromJson('woocommerce::lang.api_settings'); ?></h1>
</section>

<!-- Main content -->
<section class="content">
     
    <?php echo Form::open(['url' => action('Shopee\ShopeeMainController@updateSettings'),'method' => 'post','onsubmit' => 'return validateForm(event)', 'id' => 'api_setting_form' ]); ?>

    <div class="row">
        <div class="col-xs-12">
            <!--  <pos-tab-container> -->
            <div class="col-xs-12 pos-tab-container">
               
                <div class="col-lg-10 col-md-10 col-sm-10 col-xs-10 pos-tab">
                        <div class="row">
                            <div class="col-xs-4">
                                <div class="form-group" style="margin: 15px;">
                                    <?php echo Form::label('Shopee APP ID'); ?>

                                    <?php echo Form::text('shp_app_id',$default_settings['shp_app_id'], ['class' => 'form-control', 'placeholder' => 'Shopee APP ID', 'id' => 'shp_app_id','pattern' => '[0-9]+','title' => 'Only numbers are allowed','type' => 'number' ]); ?>

         
                                </div>
                            </div>
                            <div class="col-xs-4">
                                <div class="form-group" style="margin: 15px;">
                                    <?php echo Form::label('Shopee Secret Key'); ?>

                                    <?php echo Form::text('shp_scrt_key', $default_settings['shp_scrt_key'],['class' => 'form-control','placeholder' => 'Shopee Secret Key','id' => 'shp_secret_key',]); ?>

                                </div>
                            </div>
                            <div class="col-xs-4">
                                <div class="form-group" style="margin: 15px;">
                                    <?php echo Form::label('Shopee Shop ID'); ?>

                                    <?php echo Form::text('shp_shop_id', $default_settings['shp_shop_id'],['class' => 'form-control','placeholder' => 'Shopee Shop Id','id' => 'shp_shop_id','pattern' => '[0-9]+','title' => 'Only numbers are allowed','type' => 'number' ]); ?>

                                </div>
                            </div>
                            
                        </div>
                    
                </div>
            </div>


            <!--  </pos-tab-container> -->
        </div>
    </div>
    <div class="row">
        <div class="col-xs-12">
            <div class="form-group pull-right">
            <?php echo e(Form::submit('Update', ['class' => 'btn btn-danger', 'id' => 'submitButton']), false); ?>

                <!-- <?php echo e(Form::submit('update', ['class'=>"btn btn-danger"]), false); ?> -->
            </div>
        </div>
    </div>
    <?php echo Form::close(); ?>

</section>
<style>

div.pos-tab-container {
    z-index: 10;
    background-color: #ffffff;
    padding: 60px !important;
    border-radius: 4px;
    -moz-border-radius: 4px;
    border: 1px solid #ddd;
    margin-bottom: 28px;
    -webkit-box-shadow: 0 6px 12px rgba(0,0,0,.175);
    box-shadow: 0 6px 12px rgba(0,0,0,.100);
    -moz-box-shadow: 0 6px 12px rgba(0,0,0,.175);
    background-clip: padding-box;
}
</style>


<script>
    document.getElementById('shp_app_id').addEventListener('input', function(e) {
        // Allow only numeric input (no decimals or other characters)
        this.value = this.value.replace(/[^0-9]/g, '');
    });
    document.getElementById('shp_shop_id').addEventListener('input', function(e) {
        // Allow only numeric input (no decimals or other characters)
        this.value = this.value.replace(/[^0-9]/g, '');
    });

    function validateForm(event) {
       
        var shpAppKey = document.getElementById('shp_app_id').value;
        var shpSecretKey = document.getElementById('shp_secret_key').value;
        var shpShopID = document.getElementById('shp_shop_id').value;

        if (shpAppKey === '' || shpSecretKey === ''|| shpShopID === '') {
            event.preventDefault(); 
            alert("Both fields are required. Please fill out all fields.");
            return false; // Prevent form submission
        }
        return true; // Allow form submission if all fields are filled
    }
</script>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('javascript'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel_works\admin_pos\resources\views/shopee/api_settings.blade.php ENDPATH**/ ?>