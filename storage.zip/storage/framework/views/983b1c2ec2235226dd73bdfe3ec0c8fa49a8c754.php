<div class="table-responsive">
<table class="table table-bordered table-striped" id="receipt_sr_sales_report" style="width: 100%;">
    <thead>
        <tr>
            <th>S.No</th>
            <th><?php echo app('translator')->getFromJson('report.receipt_no'); ?></th>
            <th><?php echo app('translator')->getFromJson('messages.date'); ?></th>
            <th><?php echo app('translator')->getFromJson('lang_v1.product_details'); ?></th>
            <th>Refunds</th>
            <th><?php echo app('translator')->getFromJson('lang_v1.foc'); ?></th>
            <th><?php echo app('translator')->getFromJson('lang_v1.cart_disc'); ?></th>
            <th><?php echo app('translator')->getFromJson('lang_v1.net_sales'); ?></th>
            <th><?php echo app('translator')->getFromJson('lang_v1.points_deducted'); ?></th>
            <th><?php echo app('translator')->getFromJson('lang_v1.srv_charge'); ?></th>
            <th><?php echo app('translator')->getFromJson('lang_v1.gross'); ?></th>
            <th><?php echo app('translator')->getFromJson('lang_v1.gst'); ?></th>
            <th><?php echo app('translator')->getFromJson('sale.total_amount'); ?></th>
            <th>Voucher Amount</th>
            <th><?php echo app('translator')->getFromJson('lang_v1.tips'); ?></th>
            <th><?php echo app('translator')->getFromJson('lang_v1.payable_amount'); ?></th>
        </tr>
    </thead>
    <tfoot>
        <tr class="bg-gray font-17 footer-total text-center">
            <td colspan="4"><strong><?php echo app('translator')->getFromJson('sale.total'); ?>:</strong></td>            
            <td class="foc"><span class="display_currency" data-currency_symbol="true"></span></td>
            <td class="refunds"><span class="display_currency" data-currency_symbol="true"></span></td>
            <td class="cart_discount"><span class="display_currency" data-currency_symbol="true"></span></td>
            <td class="net_sales"><span class="display_currency" data-currency_symbol="true"></span></td>
            <td class="points_deducted"><span class="display_currency" data-currency_symbol="true"></span></td>
            <td class="service_charges"><span class="display_currency" data-currency_symbol="true"></span></td>
            <td class="gross"><span class="display_currency" data-currency_symbol="true"></span></td>
            <td class="gst"><span class="display_currency" data-currency_symbol="true"></span></td>
            <td class="total_item_sales_sum"><span class="display_currency" data-currency_symbol="true"></span></td>
            <td class="voucher_amount"><span class="display_currency" data-currency_symbol="true"></span></td>
            <td class="tips"><span class="display_currency" data-currency_symbol="true"></span></td>
            <td class="payable"><span class="display_currency" data-currency_symbol="true"></span></td>

        </tr>
    </tfoot>
</table>
</div><?php /**PATH C:\xampp\htdocs\laravel_works\admin_pos\resources\views/report/partials/invoice_sales_report.blade.php ENDPATH**/ ?>