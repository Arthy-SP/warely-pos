<?php $__env->startSection('title', __('Customer Membership')); ?>

<?php $__env->startSection('content'); ?>


<!-- Content Header (Page header) -->
<section class="content-header">
    <h1>Customer Memberships
        <small>Manage your Membership</small>
    </h1>
</section>

<!-- Main content -->
<section class="content">
    <div class="box">
        <div class="box-header">
            <div class="box-tools">
            
                <a class="btn btn-block btn-primary" 
                    href="<?php echo e(action('CustomerMembershipController@create'), false); ?>" >
                    <i class="fa fa-plus"></i> <?php echo app('translator')->getFromJson( 'messages.add' ); ?>
                </a>
            </div>
        </div>

        <div class="box-body">
            <table class="table table-bordered table-striped" id="membership_table"> 
                <thead>
                    <tr>
                        <th><?php echo app('translator')->getFromJson('Tier Name'); ?> <?php
                if(session('business.enable_tooltip')){
                    echo '<i class="fa fa-info-circle text-info hover-q no-print " aria-hidden="true" 
                    data-container="body" data-toggle="popover" data-placement="auto bottom" 
                    data-content="' . __('Tier Name') . '" data-html="true" data-trigger="hover"></i>';
                }
                ?></th>
                        <th><?php echo app('translator')->getFromJson('Targeted amount to activate Tier (in $)'); ?> <?php
                if(session('business.enable_tooltip')){
                    echo '<i class="fa fa-info-circle text-info hover-q no-print " aria-hidden="true" 
                    data-container="body" data-toggle="popover" data-placement="auto bottom" 
                    data-content="' . __('Targeted amount to activate Tier (in $)') . '" data-html="true" data-trigger="hover"></i>';
                }
                ?></th>
                        <th><?php echo app('translator')->getFromJson('Minimum Number of Orders To Earn Reward'); ?> <?php
                if(session('business.enable_tooltip')){
                    echo '<i class="fa fa-info-circle text-info hover-q no-print " aria-hidden="true" 
                    data-container="body" data-toggle="popover" data-placement="auto bottom" 
                    data-content="' . __('Minimum Number of Orders To Earn Reward') . '" data-html="true" data-trigger="hover"></i>';
                }
                ?></th>
                        <th><?php echo app('translator')->getFromJson('Minimum Earnable Points Per Order'); ?> <?php
                if(session('business.enable_tooltip')){
                    echo '<i class="fa fa-info-circle text-info hover-q no-print " aria-hidden="true" 
                    data-container="body" data-toggle="popover" data-placement="auto bottom" 
                    data-content="' . __('Minimum Earnable Points Per Order') . '" data-html="true" data-trigger="hover"></i>';
                }
                ?></th>
                        <th><?php echo app('translator')->getFromJson('Maximum Points Per Order'); ?> <?php
                if(session('business.enable_tooltip')){
                    echo '<i class="fa fa-info-circle text-info hover-q no-print " aria-hidden="true" 
                    data-container="body" data-toggle="popover" data-placement="auto bottom" 
                    data-content="' . __('Maximum Points Per Order') . '" data-html="true" data-trigger="hover"></i>';
                }
                ?></th>
                        <th><?php echo app('translator')->getFromJson('Need Amount for 1 point'); ?> <?php
                if(session('business.enable_tooltip')){
                    echo '<i class="fa fa-info-circle text-info hover-q no-print " aria-hidden="true" 
                    data-container="body" data-toggle="popover" data-placement="auto bottom" 
                    data-content="' . __('Need Amount for 1 point') . '" data-html="true" data-trigger="hover"></i>';
                }
                ?></th>
                        <th><?php echo app('translator')->getFromJson('Minimum Order number To Redeem Points'); ?> <?php
                if(session('business.enable_tooltip')){
                    echo '<i class="fa fa-info-circle text-info hover-q no-print " aria-hidden="true" 
                    data-container="body" data-toggle="popover" data-placement="auto bottom" 
                    data-content="' . __('Minimum Order number To Redeem Points') . '" data-html="true" data-trigger="hover"></i>';
                }
                ?></th>
                        <th><?php echo app('translator')->getFromJson('Minimum Redeem Point Per Order'); ?> <?php
                if(session('business.enable_tooltip')){
                    echo '<i class="fa fa-info-circle text-info hover-q no-print " aria-hidden="true" 
                    data-container="body" data-toggle="popover" data-placement="auto bottom" 
                    data-content="' . __('Minimum Redeem Point Per Order') . '" data-html="true" data-trigger="hover"></i>';
                }
                ?></th>
                        <th><?php echo app('translator')->getFromJson('Maximum Redeem Point Per Order'); ?> <?php
                if(session('business.enable_tooltip')){
                    echo '<i class="fa fa-info-circle text-info hover-q no-print " aria-hidden="true" 
                    data-container="body" data-toggle="popover" data-placement="auto bottom" 
                    data-content="' . __('Maximum Redeem Point Per Order') . '" data-html="true" data-trigger="hover"></i>';
                }
                ?></th>
                        <th><?php echo app('translator')->getFromJson('messages.action'); ?></th>
                    </tr>
                </thead>
            </table>
        </div>
    </div>

    <div class="modal fade nfc_promo_modal" tabindex="-1" role="dialog" 
        aria-labelledby="gridSystemModalLabel">
    </div>

</section>
<!-- /.content -->

<?php $__env->stopSection(); ?>

<?php $__env->startSection('javascript'); ?>
    <script type="text/javascript">
        $(document).ready(function(){
            var membership_table = $('#membership_table').DataTable({
                processing: true,
                serverSide: true,
                scrollY:        "75vh",
                scrollX:        true,
                scrollCollapse: true,
                ajax: '/membership',
                columns: [
                    { data: 'membership_name', name: 'membership_name' },
                    { data: 'minimum_order_amount_to_earn_reward', name: 'minimum_order_amount_to_earn_reward' },
                    { data: 'minimum_orders_to_earn_reward', name: 'minimum_orders_to_earn_reward' },
                    { data: 'minimum_points_earn_per_order', name: 'minimum_points_earn_per_order' },
                    { data: 'maximum_points_per_order', name: 'maximum_points_per_order' },
                    { data: 'redeem_amount_per_unit_point', name: 'redeem_amount_per_unit_point' },
                    { data: 'minimum_order_total_to_redeem_points', name: 'minimum_order_total_to_redeem_points' },
                    { data: 'minimum_redeem_point', name: 'minimum_redeem_point' },
                    { data: 'maximum_redeem_point_per_order', name: 'maximum_redeem_point_per_order' },
                    { data: 'action', name: 'action' }
                ],
            });


            $(document).on('submit', 'form#membership_add_form', function(e){
                e.preventDefault();
                var data = $(this).serialize();
                $.ajax({
                    method: "POST",
                    url: $(this).attr("action"),
                    dataType: "json",
                    data: data,
                    success: function(result){
                        if(result.success == true){
                            toastr.success(result.message);
                            console.log('Success message');
                            if ($.fn.DataTable.isDataTable('#membership_table')) {
                                $('#membership_table').DataTable().ajax.reload();
                            }
                        } else {
                            toastr.error(result.message);
                        }
                    },
                    error: function(xhr, status, error) {
                        console.error(xhr.responseText);
                    }
                });
            });

            $('form#membership_edit_form').submit(function(e){
                e.preventDefault(); 

                var data = $(this).serialize();

                $.ajax({
                    method: "POST",
                    url: $(this).attr("action"), // Form action URL
                    dataType: "json",
                    data: data,
                    success: function(result){
                        if(result.success == true){
                            // Display success toast message
                            toastr.success(result.message);

                        } else {
                            // Display error toast message if form submission failed
                            toastr.error(result.message);
                        }
                    },
                    error: function(xhr, status, error) {
                        console.error(xhr.responseText);
                        toastr.error('An error occurred while processing your request.', 'Error');
                    }
                });
            });

            $(document).on('click', 'button.delete_membership_button', function(){
                swal({
                  title: LANG.sure,
                  text: LANG.confirm_delete_table,
                  icon: "warning",
                  buttons: true,
                  dangerMode: true,
                }).then((willDelete) => {
                    if (willDelete) {
                        var href = $(this).data('href');
                        var data = $(this).serialize();
                        $.ajax({
                            method: "DELETE",
                            url: href,
                            dataType: "json",
                            data: data,
                            success: function(result){
                                if(result.success == true){
                                    toastr.success(result.message);
                                    membership_table.ajax.reload();
                                } else {
                                    toastr.error(result.message);
                                }
                            }
                        });
                    }
                });
            });

        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel_works\admin_pos\resources\views/customer_membership/index.blade.php ENDPATH**/ ?>