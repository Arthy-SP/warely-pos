<?php $__env->startSection('title', __('shopee')); ?>

<?php $__env->startSection('content'); ?>

<!-- Content Header (Page header) -->
<section class="content-header">
    <h1>Account</h1>
    
<!--     
    <select>
        <?php $__currentLoopData = $data['cat']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option><?php echo e($category['name'], false); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select> -->
   

</section>


<!-- Main content -->
<section class="content">
    <div class="row">
        <div class="col-md-12">
            <div class="box box-primary " >
                <div class="box-header " style="cursor: pointer;">
                    <h3 class="box-title" style="color: #3c8dbc;">My Account</h3>
                   
                </div>
                <div class="box-body" style="padding: 40px;">
                    <div class="col-md-3">
                      <label>Shop ID :</label> <span><p style="display: inline;"><?php echo e($data['shop_id'], false); ?></p></span>
                    </div>
                    <div class="col-md-3">
                        <label>Shop Name:</label> <span><p style="display: inline;"><?php echo e($data['shop_name'], false); ?></p></span>
                    </div>
                    <div class="col-md-3">
                        <label>Region/Country:</label> <span><p style="display: inline;"><?php echo e($data['shop_region'], false); ?></p></span>
                    </div>
                    <div class="col-md-3">
                        <a class="btn btn-xs btn-danger" href="https://auth.lazada.com/oauth/authorize?response_type=code&force_auth=true&redirect_uri=https://www.fabulousnaturals.com/&client_id=130703" target="_blank">Re- Authorize</a>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-md-12">
            <div class="box  box-primary " >
                <div class="box-header " style="cursor: pointer;">
                    <h3 class="box-title" style="color: #3c8dbc;">Product Details</h3>
                   
                </div>
                <div class="box-body" style="padding: 40px;">
                    <div class="col-md-3">
                      <label>Total Product :</label> <span><p style="display: inline;"><?php echo e($data['total_products']??'0', false); ?></p></span>
                    </div>
                    <div class="col-md-3">
                        <label>Total Lazada Product :</label> <span><p style="display: inline;"><?php echo e($data['lzd_products_count']??'0', false); ?></p></span>
                    </div>
                    <div class="col-md-3">
                        <label>Total Images Uploaded :</label> <span><p style="display: inline;"><?php echo e($data['lzd_img_count']??'0', false); ?></p></span>
                    </div>
                    <div class="col-md-3">
                        <label>Remaining Product:</label> <span><p style="display: inline;"><?php echo e($data['total_products'] - $data['lzd_products_count'] ??'0', false); ?></p></span>
                    </div>
                    
                </div>
            </div>
        </div>
    </div>

</section>
<!-- /.content -->


<?php echo e($data['acess'], false); ?>

<script src="http://code.jquery.com/jquery-1.11.0.min.js"></script>
<!-- <script>
   
    $(document).ready(function(){
   
        $('#category_id').on('change',function(e)
        {
           
            const subcategorySelect = document.getElementById('subcategory');
            const selectedOption = $('option:selected', this).attr('data-children');
            const children = JSON.parse(selectedOption);

            // Clear existing options in subcategory
            subcategorySelect.innerHTML = '<option value="">Select a subcategory</option>';

            if (children) {
                children.forEach(child => {
                    const option = document.createElement('option');
                    option.value = child['category_id'];
                    option.textContent = child['name'];
                    subcategorySelect.appendChild(option);
                });
            }
    });
});

</script> -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel_works\admin_pos\resources\views/shopee/index.blade.php ENDPATH**/ ?>