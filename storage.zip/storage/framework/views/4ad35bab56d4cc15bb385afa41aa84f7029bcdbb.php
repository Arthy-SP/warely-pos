<div class="table-responsive">
    <table class="table table-bordered table-striped" id="product_items_sales_report" style="width: 100%;">
        <thead>
            <tr>
                <th><?php echo app('translator')->getFromJson('category.category_name'); ?></th>
                <th><?php echo app('translator')->getFromJson('product.product_name'); ?></th>
                <th><?php echo app('translator')->getFromJson('product.sku'); ?></th>
                <th><?php echo app('translator')->getFromJson('lang_v1.unit_selling_price'); ?></th>
                <th><?php echo app('translator')->getFromJson('lang_v1.unit_purchase_price'); ?></th>
                <th><?php echo app('translator')->getFromJson('lang_v1.sold_quantity'); ?></th>
                <th><?php echo app('translator')->getFromJson('product.item_sales'); ?></th>
                <th><?php echo app('translator')->getFromJson('product.total_disc'); ?></th>
                <th><?php echo app('translator')->getFromJson('product.refunds'); ?></th>
                <th><?php echo app('translator')->getFromJson('product.gross_revenue'); ?></th>
            </tr>
        </thead>
        <tfoot>
            <tr class="bg-gray font-17 footer-total text-center">
                <td colspan="3"><strong><?php echo app('translator')->getFromJson('sale.total'); ?>:</strong></td>            
                <td class="foc"><span class="display_currency" data-currency_symbol="true"></span></td>
                <td class="sold_quantity"><span class="display_currency" data-currency_symbol="true"></span></td>
                <td class="item_sales"><span class="display_currency" data-currency_symbol="true"></span></td>
                <td class="item_purchase_sales"><span class="display_currency" data-currency_symbol="true"></span></td>
                <td class="total_disc"><span class="display_currency" data-currency_symbol="true"></span></td>
                <td class="refunds"><span class="display_currency" data-currency_symbol="true"></span></td>
                <td class="gross"><span class="display_currency" data-currency_symbol="true"></span></td>
                
            </tr>
        </tfoot>
    </table>
</div><?php /**PATH C:\xampp\htdocs\laravel_works\admin_pos\resources\views/report/partials/report_by_item_categories.blade.php ENDPATH**/ ?>