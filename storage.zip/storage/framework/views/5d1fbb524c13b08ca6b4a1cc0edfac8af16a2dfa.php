<?php $__env->startSection('title', __( 'credit.title' )); ?>

<?php $__env->startSection('content'); ?>

<!-- Content Header (Page header) -->
<section class="content-header">
    <h1>Credit List
        <small>Manage your credit list</small>
    </h1>
</section>

<!-- Main content -->
<section class="content">

	<div class="box">
        <div class="box-header">
        	<h3 class="box-title">All your credits</h3>
        </div>
        <div class="box-body">
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('invoice.view')): ?>
            	<table class="table table-bordered table-striped" id="credit_table">
            		<thead>
            			<tr>
                            <th><?php echo app('translator')->getFromJson( 'credit.name' ); ?> <?php
                if(session('business.enable_tooltip')){
                    echo '<i class="fa fa-info-circle text-info hover-q no-print " aria-hidden="true" 
                    data-container="body" data-toggle="popover" data-placement="auto bottom" 
                    data-content="' . __('credit.name') . '" data-html="true" data-trigger="hover"></i>';
                }
                ?></th>
                            <th><?php echo app('translator')->getFromJson( 'credit.phone' ); ?> <?php
                if(session('business.enable_tooltip')){
                    echo '<i class="fa fa-info-circle text-info hover-q no-print " aria-hidden="true" 
                    data-container="body" data-toggle="popover" data-placement="auto bottom" 
                    data-content="' . __('credit.phone') . '" data-html="true" data-trigger="hover"></i>';
                }
                ?></th>
                            <th><?php echo app('translator')->getFromJson( 'credit.balance' ); ?> <?php
                if(session('business.enable_tooltip')){
                    echo '<i class="fa fa-info-circle text-info hover-q no-print " aria-hidden="true" 
                    data-container="body" data-toggle="popover" data-placement="auto bottom" 
                    data-content="' . __('credit.balance') . '" data-html="true" data-trigger="hover"></i>';
                }
                ?></th>
                            <th><?php echo app('translator')->getFromJson( 'credit.status' ); ?> <?php
                if(session('business.enable_tooltip')){
                    echo '<i class="fa fa-info-circle text-info hover-q no-print " aria-hidden="true" 
                    data-container="body" data-toggle="popover" data-placement="auto bottom" 
                    data-content="' . __('credit.status') . '" data-html="true" data-trigger="hover"></i>';
                }
                ?></th>
                            <th><?php echo app('translator')->getFromJson( 'credit.remark' ); ?> <?php
                if(session('business.enable_tooltip')){
                    echo '<i class="fa fa-info-circle text-info hover-q no-print " aria-hidden="true" 
                    data-container="body" data-toggle="popover" data-placement="auto bottom" 
                    data-content="' . __('credit.remark') . '" data-html="true" data-trigger="hover"></i>';
                }
                ?></th>
                            <th><?php echo app('translator')->getFromJson( 'messages.action' ); ?></th>
            			</tr>
            		</thead>
            	</table>
            <?php endif; ?>
        </div>
    </div>

    <div class="modal fade check_numbers_modal" tabindex="-1" role="dialog" 
    	aria-labelledby="gridSystemModalLabel">
    </div>

</section>
<!-- /.content -->

<?php $__env->stopSection(); ?>

<?php $__env->startSection('javascript'); ?>
    <script type="text/javascript">
        $(document).ready(function(){
            var credit_table = $('#credit_table').DataTable({
                processing: true,
                serverSide: true,
                ajax: '/credit/list',
                columns: [
                    { data: 'name', name: 'name'},
                    { data: 'phone_number', name: 'phone_number'},
                    { data: 'balance', name: 'balance'},
                    { data: 'status', name: 'status'},
                    { data: 'remark', name: 'remark'},
                    { data: 'action', name: 'action'}
                ],
                order: [[ 3, 'asc' ]],
            });

            $(document).on('click', 'button.delete_nfc_card_button', function(){
                swal({
                  title: LANG.sure,
                  text: LANG.confirm_delete_table,
                  icon: "warning",
                  buttons: true,
                  dangerMode: true,
                }).then((willDelete) => {
                    if (willDelete) {
                        var href = $(this).data('href');
                        var data = $(this).serialize();
                        $.ajax({
                            method: "DELETE",
                            url: href,
                            dataType: "json",
                            data: data,
                            success: function(result){
                                if(result.success == true){
                                    toastr.success(result.message);
                                    nfc_cards_table.ajax.reload();
                                } else {
                                    toastr.error(result.message);
                                }
                            }
                        });
                    }
                });
            });

            $(document).on('click', '.activate_credit_button', function () {
                handleCardStatusChange($(this).data('href'), 'activate');
            });

            // Handle Deactivate NFC Card button click
            $(document).on('click', '.deactivate_credit_button', function () {
                handleCardStatusChange($(this).data('href'), 'deactivate');
            });

            function handleCardStatusChange(url, action) {
                $.ajax({
                    type: 'POST',
                    url: url,
                    data: {_token: '<?php echo e(csrf_token(), false); ?>'},
                    dataType: 'json',
                    success: function (response) {
                        if (response.success) {
                            toastr.success(response.message);
                            credit_table.ajax.reload();
                        } else {
                            toastr.error(response.message);
                        }
                    },
                    error: function (xhr, status, error) {
                        console.error(error);
                    }
                });
            }

            $(document).on('click', 'button.credit_edit_details_form', function(){
                $( "div.check_numbers_modal" ).load( $(this).data('href'), function(){
                    $(this).modal('show');
                    $('form#credit_edit_details_form').submit(function(e){
                        e.preventDefault();
                        var data = $(this).serialize();
                        $.ajax({
                            method: "POST",
                            url: $(this).attr("action"),
                            dataType: "json",
                            data: data,
                            success: function(result){
                                if(result.success == true){
                                    $('div.check_numbers_modal').modal('hide');
                                    toastr.success(result.message);
                                    credit_table.ajax.reload();
                                } else {
                                    toastr.error(result.message);
                                }
                            }
                        });
                    });
                });
            });
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel_works\admin_pos\resources\views/credit/list.blade.php ENDPATH**/ ?>