<div class="modal-dialog" role="document">
  <div class="modal-content">

    <?php echo Form::open(['url' => action('RetailVariationTemplateController@store'), 'method' => 'post', 'id' => 'variation_add_form', 'class' => 'form-horizontal' ]); ?>

    <div class="modal-header">
      <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
      <h4 class="modal-title"><?php echo app('translator')->getFromJson('Add Variation Sets'); ?></h4>
    </div>

    <div class="modal-body">
      <div class="form-group">
        <?php echo Form::label('name', __('Variation Title') . ':*', ['class' => 'col-sm-3 control-label']); ?>


        <div class="col-sm-9">
          <?php echo Form::text('name', null, ['class' => 'form-control', 'required', 'placeholder' => __('Variation Title')]);; ?>

        </div>
      </div>
      <div class="form-group"> 
        <label class="col-sm-3 control-label"><?php echo app('translator')->getFromJson('Variation Name & Value'); ?>:*</label>
        <div class="col-sm-4">
          <?php echo Form::text('variation_names[]', null, ['class' => 'form-control', 'required', 'placeholder' => __('Variation Name')]);; ?>

        </div>
        <div class="col-sm-4">
          <?php echo Form::text('variation_values[]', null, ['class' => 'form-control', 'required', 'placeholder' => __('Variation Value')]);; ?>

        </div>
        <div class="col-sm-1">
          <button type="button" class="btn btn-primary" id="retail_variation_values">+</button>
        </div>
      </div>
      <div id="variation_values"></div>
    </div>

    <div class="modal-footer">
      <button type="submit" class="btn btn-primary"><?php echo app('translator')->getFromJson('messages.save'); ?></button>
      <button type="button" class="btn btn-default" data-dismiss="modal"><?php echo app('translator')->getFromJson('messages.close'); ?></button>
    </div>

    <?php echo Form::close(); ?>


  </div><!-- /.modal-content -->
</div><!-- /.modal-dialog -->


<?php /**PATH C:\xampp\htdocs\laravel_works\admin_pos\resources\views/retail_variation/create.blade.php ENDPATH**/ ?>