<?php $__env->startSection('title', __( 'credit.title' )); ?>

<?php $__env->startSection('content'); ?>

<!-- Content Header (Page header) -->
<section class="content-header">
    <h1>Credits Transactions
        <small>Manage your credit transactions</small>
    </h1>
</section>

<!-- Main content -->
<section class="content">
    <div class="row">
        <div class="col-md-12">
            <?php $__env->startComponent('components.filters', ['title' => __('report.filters')]); ?>
                <div class="col-md-3">
                    <div class="form-group">
                        <?php echo Form::label('transaction_type', __('credit.transaction_type') . ':'); ?>

                        <?php echo Form::select('transaction_type', ['debit' => __('credit.debit'), 'credit' => __('credit.credit')], null, ['class' => 'form-control select2', 'style' => 'width:100%', 'id' => 'transaction_type', 'placeholder' => __('lang_v1.all')]);; ?>

                    </div>
                </div>
                
                <?php if(empty($only) || in_array('credit_list_filter_date_range', $only)): ?>
                    <div class="col-md-3">
                        <div class="form-group">
                            <?php echo Form::label('credit_list_filter_date_range', __('report.date_range') . ':'); ?>

                            <?php echo Form::text('credit_list_filter_date_range', null, ['placeholder' => __('lang_v1.select_a_date_range'), 'class' => 'form-control', 'readonly']);; ?>

                        </div>
                    </div>
                <?php endif; ?>
            <?php echo $__env->renderComponent(); ?>
        </div>
    </div>

	<div class="box">
        <div class="box-body">
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('invoice.view')): ?>
            	<table class="table table-bordered table-striped" id="credit_transactions_table">
            		<thead>
            			<tr>
                            <th><?php echo app('translator')->getFromJson( 'credit.name' ); ?> <?php
                if(session('business.enable_tooltip')){
                    echo '<i class="fa fa-info-circle text-info hover-q no-print " aria-hidden="true" 
                    data-container="body" data-toggle="popover" data-placement="auto bottom" 
                    data-content="' . __('credit.name') . '" data-html="true" data-trigger="hover"></i>';
                }
                ?></th>
                            <th><?php echo app('translator')->getFromJson( 'credit.phone' ); ?> <?php
                if(session('business.enable_tooltip')){
                    echo '<i class="fa fa-info-circle text-info hover-q no-print " aria-hidden="true" 
                    data-container="body" data-toggle="popover" data-placement="auto bottom" 
                    data-content="' . __('credit.phone') . '" data-html="true" data-trigger="hover"></i>';
                }
                ?></th>
                            <th><?php echo app('translator')->getFromJson( 'credit.opening_balance' ); ?> <?php
                if(session('business.enable_tooltip')){
                    echo '<i class="fa fa-info-circle text-info hover-q no-print " aria-hidden="true" 
                    data-container="body" data-toggle="popover" data-placement="auto bottom" 
                    data-content="' . __('credit.opening_balance') . '" data-html="true" data-trigger="hover"></i>';
                }
                ?></th>
                            <th><?php echo app('translator')->getFromJson( 'credit.transaction' ); ?> <?php
                if(session('business.enable_tooltip')){
                    echo '<i class="fa fa-info-circle text-info hover-q no-print " aria-hidden="true" 
                    data-container="body" data-toggle="popover" data-placement="auto bottom" 
                    data-content="' . __('credit.transaction') . '" data-html="true" data-trigger="hover"></i>';
                }
                ?></th>
                            <th><?php echo app('translator')->getFromJson( 'credit.closing_balance' ); ?> <?php
                if(session('business.enable_tooltip')){
                    echo '<i class="fa fa-info-circle text-info hover-q no-print " aria-hidden="true" 
                    data-container="body" data-toggle="popover" data-placement="auto bottom" 
                    data-content="' . __('credit.closing_balance') . '" data-html="true" data-trigger="hover"></i>';
                }
                ?></th>
                            <th><?php echo app('translator')->getFromJson( 'Transaction Type' ); ?> <?php
                if(session('business.enable_tooltip')){
                    echo '<i class="fa fa-info-circle text-info hover-q no-print " aria-hidden="true" 
                    data-container="body" data-toggle="popover" data-placement="auto bottom" 
                    data-content="' . __('Transaction Type') . '" data-html="true" data-trigger="hover"></i>';
                }
                ?></th>
                            <th><?php echo app('translator')->getFromJson( 'credit.timestamp' ); ?> <?php
                if(session('business.enable_tooltip')){
                    echo '<i class="fa fa-info-circle text-info hover-q no-print " aria-hidden="true" 
                    data-container="body" data-toggle="popover" data-placement="auto bottom" 
                    data-content="' . __('credit.timestamp') . '" data-html="true" data-trigger="hover"></i>';
                }
                ?></th>
            			</tr>
            		</thead>
            	</table>
            <?php endif; ?>
        </div>
    </div>

    <div class="modal fade check_numbers_modal" tabindex="-1" role="dialog" 
    	aria-labelledby="gridSystemModalLabel">
    </div>

</section>
<!-- /.content -->

<?php $__env->stopSection(); ?>

<?php $__env->startSection('javascript'); ?>
    <script type="text/javascript">
        $(document).ready(function(){
            //Date range as a button
            $('#credit_list_filter_date_range').daterangepicker(
                dateRangeSettings,
                function (start, end) {
                    $('#credit_list_filter_date_range').val(start.format(moment_date_format) + ' ~ ' + end.format(moment_date_format));
                    credit_transactions_table.ajax.reload();
                }
            );
            $('#credit_list_filter_date_range').on('cancel.daterangepicker', function(ev, picker) {
                $('#credit_list_filter_date_range').val('');
                credit_transactions_table.ajax.reload();
            });

            var credit_transactions_table = $('#credit_transactions_table').DataTable({
                processing: true,
                serverSide: true,
                "ajax": {
                    "url": '/credit/get_all_credit_transactions',
                    "data": function ( d ) {
                        d.transaction_type = $('#transaction_type').val();
                        if($('#credit_list_filter_date_range').val()) {
                            var start = $('#credit_list_filter_date_range').data('daterangepicker').startDate.format('YYYY-MM-DD');
                            var end = $('#credit_list_filter_date_range').data('daterangepicker').endDate.format('YYYY-MM-DD');
                            d.start_date = start;
                            d.end_date = end;
                          }
                          
                        console.log(d);
                        d = __datatable_ajax_callback(d);
                    }
                },
                columns: [
                    { data: 'name', name: 'name'},
                    { data: 'phone_number', name: 'phone_number'},
                    { data: 'opening_balance', name: 'opening_balance',searchable: false },
                    { data: 'transaction', name: 'transaction' ,searchable: false },
                    { data: 'closing_balance', name: 'closing_balance', searchable: false},
                    { data: 'transaction_type', name: 'transaction_type'},
                    { data: 'timestamp', name: 'timestamp', searchable: false},
                ],
            });

            $(document).on('change', '#transaction_type', function() {
                credit_transactions_table.ajax.reload();
            });
        });

    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel_works\admin_pos\resources\views/credit/credits_transactions.blade.php ENDPATH**/ ?>