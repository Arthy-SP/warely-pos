<?php
$colspan = 10;
$custom_labels = json_decode(session('business.custom_labels'), true);
?>
<div class="table-responsive ">

    <table class="table table-bordered table-striped ajax_view hide-footer" id="retail_product_table">
        <thead>
            <tr>
                <th><input type="checkbox" id="select-all-row" data-table-id="retail_product_table"></th>
                <th>&nbsp;</th>

                <th style="width:10%"><?php echo app('translator')->getFromJson('sale.product'); ?></th>
                <th style="width:10%"><?php echo app('translator')->getFromJson('product.sku'); ?></th>
                <th style="width:10%"><?php echo app('translator')->getFromJson('product.brand'); ?></th>
                <th style="width:10%"><?php echo app('translator')->getFromJson('product.category'); ?></th>
                <th style="width:10%">SellerSku</th>
                <th style="width:10%"><?php echo app('translator')->getFromJson('purchase.business_location'); ?> <?php
                if(session('business.enable_tooltip')){
                    echo '<i class="fa fa-info-circle text-info hover-q no-print " aria-hidden="true" 
                    data-container="body" data-toggle="popover" data-placement="auto bottom" 
                    data-content="' . __('lang_v1.product_business_location_tooltip') . '" data-html="true" data-trigger="hover"></i>';
                }
                ?></th>
                <th style="width:10%"><?php echo app('translator')->getFromJson('product.product_type'); ?></th>
                <th style="width:10%"><?php echo app('translator')->getFromJson( 'Quantity' ); ?></th>
                <th style="width:10%"><?php echo app('translator')->getFromJson( 'Price' ); ?></th>
            </tr>
        </thead>
        <tfoot>
            <tr>
                <td colspan="<?php echo e($colspan, false); ?>">
                    <div style="display: flex; width: 100%;">

                        &nbsp;
                       
                        <?php echo Form::hidden('selected_products', null, ['id' => 'selected_products']); ?>

                        <?php echo Form::hidden('sub_cat_id', null, ['id' => 'sub_cat_id']); ?>

                        <?php echo Form::hidden('child_cat_id', null, ['id' => 'child_cat_id']); ?>

                        <?php echo Form::hidden('leaf_cat_id', null, ['id' => 'leaf_cat_id']); ?>

                        <?php echo Form::hidden('action', $action, ['id' => 'action']); ?>


                        <?php if($action == 'update'): ?>
                        <?php echo Form::submit('Update To Lazada', array('class' => 'btn btn-xs btn-success', 'id' => 'update-selected')); ?>

                        <?php elseif($action == 'delete'): ?>
                        <?php echo Form::submit('Remove Product', array('class' => 'btn btn-xs btn-danger', 'id' => 'remove-selected')); ?>

                        <?php else: ?>
                        <?php echo Form::submit('Add To Lazada', array('class' => 'btn btn-xs btn-success', 'id' => 'add-selected')); ?>


                        <?php endif; ?>

                        <?php echo Form::close(); ?> <?php
                if(session('business.enable_tooltip')){
                    echo '<i class="fa fa-info-circle text-info hover-q no-print " aria-hidden="true" 
                    data-container="body" data-toggle="popover" data-placement="auto bottom" 
                    data-content="' . __('lang_v1.deactive_product_tooltip') . '" data-html="true" data-trigger="hover"></i>';
                }
                ?>
                    </div>
                </td>
            </tr>
        </tfoot>
    </table>
</div><?php /**PATH C:\xampp\htdocs\laravel_works\admin_pos\resources\views/lazada/product_list_table.blade.php ENDPATH**/ ?>