<div class="table-responsive">
    <table class="table table-bordered table-striped" id="discount_report" style="width: 100%;">
        <thead>
            <tr>
                <th><?php echo app('translator')->getFromJson('sale.invoice_no'); ?></th>
                <th><?php echo app('translator')->getFromJson('messages.date'); ?></th>
                <th><?php echo app('translator')->getFromJson('lang_v1.coupon_discount'); ?></th>
                <th><?php echo app('translator')->getFromJson('lang_v1.cart_discount'); ?></th>
                <th><?php echo app('translator')->getFromJson('lang_v1.item_discount'); ?></th>
                <th><?php echo app('translator')->getFromJson('lang_v1.total_discount'); ?></th>
            </tr>
        </thead>
        <tfoot>
            <tr class="bg-gray font-17 footer-total text-center">
                <td colspan="2"><strong><?php echo app('translator')->getFromJson('sale.total'); ?>:</strong></td>            
                <td class="coupon_discount"><span class="display_currency" data-currency_symbol="true"></span></td>
                <td class="cart_discount"><span class="display_currency" data-currency_symbol="true"></span></td>
                <td class="item_discount"><span class="display_currency" data-currency_symbol="true"></span></td>
                <td class="total_disc"><span class="display_currency" data-currency_symbol="true"></span></td>
            </tr>
        </tfoot>
    </table>
</div><?php /**PATH C:\xampp\htdocs\laravel_works\admin_pos\resources\views/report/partials/all_discounts_sales.blade.php ENDPATH**/ ?>