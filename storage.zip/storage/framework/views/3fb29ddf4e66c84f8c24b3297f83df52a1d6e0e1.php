<?php $__env->startSection('title', __('Peppol Register')); ?>

<?php $__env->startSection('content'); ?>

<!-- Content Header (Page header) -->
<section class="content-header">
    <br>
    <h1>Register New Peppol Identifier</h1>
</section>

<!-- Main content -->
<section class="content no-print">
    <?php echo Form::open(['url' => action('PeppolController@store'), 'method' => 'post', 'id' => 'peppol_registration_form' ]); ?>

    <div class="box box-solid">
        <div class="box-body">
            <div class="row">
                <div class="col-sm-6">
                    <div class="form-group">
                        <?php echo Form::label('legal_entity_id', __('Legal Entity Id') . ':*'); ?>

                        <?php echo Form::text('legal_entity_id', null, ['class' => 'form-control', 'required', 'placeholder' => __('Legal Entity Id')]);; ?>

                    </div>
                </div>
                <div class="col-sm-6">
                    <div class="form-group">
                        <?php echo Form::label('identifier', __('Peppol Identifier') . ':*'); ?>

                        <?php echo Form::text('identifier', null, ['class' => 'form-control', 'required', 'maxlength' => 64]);; ?>

                    </div>
                </div>
            </div>
        </div>
    </div> <!-- box end -->
    <div class="box box-solid">
        <div class="box-body">
            <div class="row">
                <div class="col-sm-12">
                    <button type="submit" class="btn btn-primary pull-right"><?php echo app('translator')->getFromJson('messages.save'); ?></button>
                </div>
            </div>
        </div>
    </div> <!-- box end -->
    <?php echo Form::close(); ?>

</section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('javascript'); ?>
    <script type="text/javascript">
        __page_leave_confirmation('#peppol_registration_form');
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel_works\admin_pos\resources\views/peppol/register.blade.php ENDPATH**/ ?>