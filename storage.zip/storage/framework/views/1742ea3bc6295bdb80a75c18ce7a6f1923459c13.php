<?php $__env->startSection('title', __( 'gto.business_outlets' )); ?>
<?php $__env->startSection('content'); ?>
<section class="content-header">
    <h1><?php echo app('translator')->getFromJson( 'gto.business_outlets' ); ?>
        <small><?php echo app('translator')->getFromJson( 'gto.manage_outlets' ); ?></small>
    </h1>
</section>

<!-- Main content -->
<section class="content">
	<div class="box box-solid">
        <div class="box-body">
                <div class="table-responsive">
                    <table class="table table-bordered table-striped" id="manage_outlets_locations_table">
                        <thead>
                            <tr>
                                <th><?php echo app('translator')->getFromJson( 'gto.outlet_name' ); ?></th>
                                <th><?php echo app('translator')->getFromJson( 'Action' ); ?></th>
                            </tr>
                        </thead>
                    </table>
                </div>
        </div>
    </div>

</section>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('javascript'); ?>
    <script type="text/javascript">
        $(document).ready(function() {
            var outletDatatable = $('#manage_outlets_locations_table').DataTable({
                processing: true,
                serverSide: true,
                ajax: {
                    url: "<?php echo e(route('business_outlets.locations'), false); ?>", 
                    type: "GET",
                },
                columns: [
                    { "data": "name" },
                    { data: 'action', name: 'action', orderable: false, searchable: false }
                ]
            });
            $(document).on("change", ".sales-date-picker", function(e) {
                const $button = $(this);
                $button.prop('disabled', true); 
                const rowId = $button.data("id");
                const locationId = $(this).data("location");
                const SelectedDate = $(`#sales-date-${rowId}`).val();
                if (!SelectedDate) {
                    alert("Please fill date first.");
                } else {
                    e.preventDefault(); 
                    $.ajax({
                        url: "/generate_GTO_files",
                        method: "POST",
                        data: { date: SelectedDate, locationId : locationId },
                        success: function(response) { 
                            const fileUrl = response.file;
                            if (response.success && response.file) {
                                toastr.success("You can download sales file.");
                                const filePathArr = fileUrl.split("/");
                                const filePath =  filePathArr[filePathArr.length -1];
                                $(`#sales-download-${rowId}`).attr("download", filePath);
                                $(`#sales-download-${rowId}`).attr("href", response.file);
                                $(`#sales-download-${rowId}`).attr("path", response.path);
                                $(`#sales-download-${rowId}`).prop('disabled', false);
                            } else {
                                toastr.error(response.message);
                            }
                        },
                        error: function(xhr, status, error) {
                            toastr.error(error);
                        },
                        complete: function() {
                           $button.prop('disabled', false); 
                            $(`#sales-upload-${rowId}`).prop('disabled', false);
                            $(`#sales-download-${rowId}`).css({
                                'pointer-events': 'auto',
                                'opacity': '1'
                            });
                        }
                    });
                }
            });
            $(document).on("click", ".upload_sales_file", function(e) {
                const $button = $(this); 
                const rowId = $button.data("id");
                const locationId = $button.data("location");
                const file = $(`#sales-download-${rowId}`).attr("path");
                if(!file){
                    toastr.error("Sales file download first.");
                }else{
                    $button.prop('disabled', true);
                    $.ajax({
                        url: "/upload/gto/sales",
                        method: "POST",
                        data: { locationId: locationId, file :  file},
                        success: function(response) { 
                            if (response.success) {
                                toastr.success(response.message);
                            } else {
                                toastr.error(response.message);
                            }
                        },
                        error: function(xhr, status, error) {
                            toastr.error(error);
                        },
                        complete: function() {
                            $button.prop('disabled', false); 
                        }
                    });
                }
            });
        });
    </script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel_works\admin_pos\resources\views/business_outlets/outlet-locations.blade.php ENDPATH**/ ?>