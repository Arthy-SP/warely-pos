<div class="pos-tab-content">
     <div class="row">
        <div class="col-sm-12">
            <h4><?php echo app('translator')->getFromJson('lang_v1.labels_for_custom_payments'); ?>:</h4>
        </div>
        <div class="clearfix"></div>
        <div class="col-sm-4">
            <div class="form-group">
                <?php echo Form::label('custom_payment_1_label', __('lang_v1.custom_payment_1'));; ?>

                <?php echo Form::text('custom_labels[payments][custom_pay_1]', !empty($custom_labels['payments']['custom_pay_1']) ? $custom_labels['payments']['custom_pay_1'] : null, 
                    ['class' => 'form-control', 'id' => 'custom_payment_1']);; ?>

            </div>
        </div>
        <div class="col-sm-2">
            <div class="form-group">
                <?php echo Form::label('custom_payment_1_color', __('choose color'));; ?>

                <?php echo Form::text('custom_labels[payments_color][custom_pay_1_color]', !empty($custom_labels['payments_color']['custom_pay_1_color']) ? $custom_labels['payments_color']['custom_pay_1_color'] : '#ECECEC', 
                    ['class' => 'form-control jscolor', 'id' => 'custom_payment_1_color']);; ?>

            </div>
        </div>
        <div class="col-sm-4">
            <div class="form-group">
                <?php echo Form::label('custom_payment_2_label', __('lang_v1.custom_payment_2'));; ?>

                <?php echo Form::text('custom_labels[payments][custom_pay_2]', !empty($custom_labels['payments']['custom_pay_2']) ? $custom_labels['payments']['custom_pay_2'] : null, 
                    ['class' => 'form-control', 'id' => 'custom_payment_2']);; ?>

            </div>
        </div>
        <div class="col-sm-2">
            <div class="form-group">
                <?php echo Form::label('custom_payment_2_color', __('choose color'));; ?>

                <?php echo Form::text('custom_labels[payments_color][custom_pay_2_color]', !empty($custom_labels['payments_color']['custom_pay_2_color']) ? $custom_labels['payments_color']['custom_pay_2_color'] : '#ECECEC', 
                    ['class' => 'form-control jscolor', 'id' => 'custom_payment_2_color']);; ?>

            </div>
        </div>
        <div class="col-sm-4">
            <div class="form-group">
                <?php echo Form::label('custom_payment_3_label', __('lang_v1.custom_payment_3'));; ?>

                <?php echo Form::text('custom_labels[payments][custom_pay_3]', !empty($custom_labels['payments']['custom_pay_3']) ? $custom_labels['payments']['custom_pay_3'] : null, 
                    ['class' => 'form-control', 'id' => 'custom_payment_3']);; ?>

            </div>
        </div>
        <div class="col-sm-2">
            <div class="form-group">
                <?php echo Form::label('custom_payment_3_color', __('choose color'));; ?>

                <?php echo Form::text('custom_labels[payments_color][custom_pay_3_color]', !empty($custom_labels['payments_color']['custom_pay_3_color']) ? $custom_labels['payments_color']['custom_pay_3_color'] : '#ECECEC', 
                    ['class' => 'form-control jscolor', 'id' => 'custom_payment_3_color']);; ?>

            </div>
        </div>
        <div class="col-sm-4">
            <div class="form-group">
                <?php echo Form::label('custom_payment_4_label', __('lang_v1.custom_payment', ['number' => 4]));; ?>

                <?php echo Form::text('custom_labels[payments][custom_pay_4]', !empty($custom_labels['payments']['custom_pay_4']) ? $custom_labels['payments']['custom_pay_4'] : null, 
                    ['class' => 'form-control', 'id' => 'custom_payment_4']);; ?>

            </div>
        </div>
        <div class="col-sm-2">
            <div class="form-group">
                <?php echo Form::label('custom_payment_4_color', __('choose color'));; ?>

                <?php echo Form::text('custom_labels[payments_color][custom_pay_4_color]', !empty($custom_labels['payments_color']['custom_pay_4_color']) ? $custom_labels['payments_color']['custom_pay_4_color'] : '#ECECEC', 
                    ['class' => 'form-control jscolor', 'id' => 'custom_payment_4_color']);; ?>

            </div>
        </div>
        <div class="col-sm-4">
            <div class="form-group">
                <?php echo Form::label('custom_payment_5_label', __('lang_v1.custom_payment', ['number' => 5]));; ?>

                <?php echo Form::text('custom_labels[payments][custom_pay_5]', !empty($custom_labels['payments']['custom_pay_5']) ? $custom_labels['payments']['custom_pay_5'] : null, 
                    ['class' => 'form-control', 'id' => 'custom_payment_5']);; ?>

            </div>
        </div>
        <div class="col-sm-2">
            <div class="form-group">
                <?php echo Form::label('custom_payment_5_color', __('choose color'));; ?>

                <?php echo Form::text('custom_labels[payments_color][custom_pay_5_color]', !empty($custom_labels['payments_color']['custom_pay_5_color']) ? $custom_labels['payments_color']['custom_pay_5_color'] : '#ECECEC', 
                    ['class' => 'form-control jscolor', 'id' => 'custom_payment_5_color']);; ?>

            </div>
        </div>
        <div class="col-sm-4">
            <div class="form-group">
                <?php echo Form::label('custom_payment_6_label', __('lang_v1.custom_payment', ['number' => 6]));; ?>

                <?php echo Form::text('custom_labels[payments][custom_pay_6]', !empty($custom_labels['payments']['custom_pay_6']) ? $custom_labels['payments']['custom_pay_6'] : null, 
                    ['class' => 'form-control', 'id' => 'custom_payment_6']);; ?>

            </div>
        </div>
        <div class="col-sm-2">
            <div class="form-group">
                <?php echo Form::label('custom_payment_6_color', __('choose color'));; ?>

                <?php echo Form::text('custom_labels[payments_color][custom_pay_6_color]', !empty($custom_labels['payments_color']['custom_pay_6_color']) ? $custom_labels['payments_color']['custom_pay_6_color'] : '#ECECEC', 
                    ['class' => 'form-control jscolor', 'id' => 'custom_payment_6_color']);; ?>

            </div>
        </div>
        <div class="col-sm-4">
            <div class="form-group">
                <?php echo Form::label('custom_payment_7_label', __('lang_v1.custom_payment', ['number' => 7]));; ?>

                <?php echo Form::text('custom_labels[payments][custom_pay_7]', !empty($custom_labels['payments']['custom_pay_7']) ? $custom_labels['payments']['custom_pay_7'] : null, 
                    ['class' => 'form-control', 'id' => 'custom_payment_7']);; ?>

            </div>
        </div>
        <div class="col-sm-2">
            <div class="form-group">
                <?php echo Form::label('custom_payment_7_color', __('choose color'));; ?>

                <?php echo Form::text('custom_labels[payments_color][custom_pay_7_color]', !empty($custom_labels['payments_color']['custom_pay_7_color']) ? $custom_labels['payments_color']['custom_pay_7_color'] : '#ECECEC', 
                    ['class' => 'form-control jscolor', 'id' => 'custom_payment_7_color']);; ?>

            </div>
        </div>
        <div class="col-sm-4">
            <div class="form-group">
                <?php echo Form::label('custom_payment_8_label', __('lang_v1.custom_payment', ['number' => 8]));; ?>

                <?php echo Form::text('custom_labels[payments][custom_pay_8]', !empty($custom_labels['payments']['custom_pay_8']) ? $custom_labels['payments']['custom_pay_8'] : null, 
                    ['class' => 'form-control', 'id' => 'custom_payment_8']);; ?>

            </div>
        </div>
        <div class="col-sm-2">
            <div class="form-group">
                <?php echo Form::label('custom_payment_8_color', __('choose color'));; ?>

                <?php echo Form::text('custom_labels[payments_color][custom_pay_8_color]', !empty($custom_labels['payments_color']['custom_pay_8_color']) ? $custom_labels['payments_color']['custom_pay_8_color'] : '#ECECEC', 
                    ['class' => 'form-control jscolor', 'id' => 'custom_payment_8_color']);; ?>

            </div>
        </div>
        <div class="col-sm-4">
            <div class="form-group">
                <?php echo Form::label('custom_payment_9_label', __('lang_v1.custom_payment', ['number' => 9]));; ?>

                <?php echo Form::text('custom_labels[payments][custom_pay_9]', !empty($custom_labels['payments']['custom_pay_9']) ? $custom_labels['payments']['custom_pay_9'] : null, 
                    ['class' => 'form-control', 'id' => 'custom_payment_9']);; ?>

            </div>
        </div>
        <div class="col-sm-2">
            <div class="form-group">
                <?php echo Form::label('custom_payment_9_color', __('choose color'));; ?>

                <?php echo Form::text('custom_labels[payments_color][custom_pay_9_color]', !empty($custom_labels['payments_color']['custom_pay_9_color']) ? $custom_labels['payments_color']['custom_pay_9_color'] : '#ECECEC', 
                    ['class' => 'form-control jscolor', 'id' => 'custom_payment_9_color']);; ?>

            </div>
        </div>
        <div class="col-sm-4">
            <div class="form-group">
                <?php echo Form::label('custom_payment_10_label', __('lang_v1.custom_payment', ['number' => 10]));; ?>

                <?php echo Form::text('custom_labels[payments][custom_pay_10]', !empty($custom_labels['payments']['custom_pay_10']) ? $custom_labels['payments']['custom_pay_10'] : null, 
                    ['class' => 'form-control', 'id' => 'custom_payment_10']);; ?>

            </div>
        </div>
        <div class="col-sm-2">
            <div class="form-group">
                <?php echo Form::label('custom_payment_10_color', __('choose color'));; ?>

                <?php echo Form::text('custom_labels[payments_color][custom_pay_10_color]', !empty($custom_labels['payments_color']['custom_pay_10_color']) ? $custom_labels['payments_color']['custom_pay_10_color'] : '#ECECEC', 
                    ['class' => 'form-control jscolor', 'id' => 'custom_payment_10_color']);; ?>

            </div>
        </div>
        <div class="col-sm-4">
            <div class="form-group">
                <?php echo Form::label('custom_payment_11_label', __('lang_v1.custom_payment', ['number' => 11]));; ?>

                <?php echo Form::text('custom_labels[payments][custom_pay_11]', !empty($custom_labels['payments']['custom_pay_11']) ? $custom_labels['payments']['custom_pay_11'] : null, 
                    ['class' => 'form-control', 'id' => 'custom_payment_11']);; ?>

            </div>
        </div>
        <div class="col-sm-2">
            <div class="form-group">
                <?php echo Form::label('custom_payment_11_color', __('choose color'));; ?>

                <?php echo Form::text('custom_labels[payments_color][custom_pay_11_color]', !empty($custom_labels['payments_color']['custom_pay_11_color']) ? $custom_labels['payments_color']['custom_pay_11_color'] : '#ECECEC', 
                    ['class' => 'form-control jscolor', 'id' => 'custom_payment_11_color']);; ?>

            </div>
        </div>
        <div class="col-sm-4">
            <div class="form-group">
                <?php echo Form::label('custom_payment_12_label', __('lang_v1.custom_payment', ['number' => 12]));; ?>

                <?php echo Form::text('custom_labels[payments][custom_pay_12]', !empty($custom_labels['payments']['custom_pay_12']) ? $custom_labels['payments']['custom_pay_12'] : null, 
                    ['class' => 'form-control', 'id' => 'custom_payment_12']);; ?>

            </div>
        </div>
        <div class="col-sm-2">
            <div class="form-group">
                <?php echo Form::label('custom_payment_12_color', __('choose color'));; ?>

                <?php echo Form::text('custom_labels[payments_color][custom_pay_12_color]', !empty($custom_labels['payments_color']['custom_pay_12_color']) ? $custom_labels['payments_color']['custom_pay_12_color'] : '#ECECEC', 
                    ['class' => 'form-control jscolor', 'id' => 'custom_payment_12_color']);; ?>

            </div>
        </div>
        <div class="col-sm-4">
            <div class="form-group">
                <?php echo Form::label('custom_payment_13_label', __('lang_v1.custom_payment', ['number' => 13]));; ?>

                <?php echo Form::text('custom_labels[payments][custom_pay_13]', !empty($custom_labels['payments']['custom_pay_13']) ? $custom_labels['payments']['custom_pay_13'] : null, 
                    ['class' => 'form-control', 'id' => 'custom_payment_13']);; ?>

            </div>
        </div>
        <div class="col-sm-2">
            <div class="form-group">
                <?php echo Form::label('custom_payment_13_color', __('choose color'));; ?>

                <?php echo Form::text('custom_labels[payments_color][custom_pay_13_color]', !empty($custom_labels['payments_color']['custom_pay_13_color']) ? $custom_labels['payments_color']['custom_pay_13_color'] : '#ECECEC', 
                    ['class' => 'form-control jscolor', 'id' => 'custom_payment_13_color']);; ?>

            </div>
        </div>
        <div class="col-sm-4">
            <div class="form-group">
                <?php echo Form::label('custom_payment_14_label', __('lang_v1.custom_payment', ['number' => 14]));; ?>

                <?php echo Form::text('custom_labels[payments][custom_pay_14]', !empty($custom_labels['payments']['custom_pay_14']) ? $custom_labels['payments']['custom_pay_14'] : null, 
                    ['class' => 'form-control', 'id' => 'custom_payment_14']);; ?>

            </div>
        </div>
        <div class="col-sm-2">
            <div class="form-group">
                <?php echo Form::label('custom_payment_14_color', __('choose color'));; ?>

                <?php echo Form::text('custom_labels[payments_color][custom_pay_14_color]', !empty($custom_labels['payments_color']['custom_pay_14_color']) ? $custom_labels['payments_color']['custom_pay_14_color'] : '#ECECEC', 
                    ['class' => 'form-control jscolor', 'id' => 'custom_payment_14_color']);; ?>

            </div>
        </div>
        <div class="col-sm-4">
            <div class="form-group">
                <?php echo Form::label('custom_payment_15_label', __('lang_v1.custom_payment', ['number' => 15]));; ?>

                <?php echo Form::text('custom_labels[payments][custom_pay_15]', !empty($custom_labels['payments']['custom_pay_15']) ? $custom_labels['payments']['custom_pay_15'] : null, 
                    ['class' => 'form-control', 'id' => 'custom_payment_15']);; ?>

            </div>
        </div>
        <div class="col-sm-2">
            <div class="form-group">
                <?php echo Form::label('custom_payment_15_color', __('choose color'));; ?>

                <?php echo Form::text('custom_labels[payments_color][custom_pay_15_color]', !empty($custom_labels['payments_color']['custom_pay_15_color']) ? $custom_labels['payments_color']['custom_pay_15_color'] : '#ECECEC', 
                    ['class' => 'form-control jscolor', 'id' => 'custom_payment_15_color']);; ?>

            </div>
        </div>
        <div class="clearfix"></div>
        <div class="col-sm-12">
            <h4><?php echo app('translator')->getFromJson('lang_v1.labels_for_contact_custom_fields'); ?>:</h4>
        </div>
        <div class="col-sm-3">
            <div class="form-group">
                <?php echo Form::label('contact_custom_field_1_label', __('lang_v1.contact_custom_field1'));; ?>

                <?php echo Form::text('custom_labels[contact][custom_field_1]', !empty($custom_labels['contact']['custom_field_1']) ? $custom_labels['contact']['custom_field_1'] : null, 
                    ['class' => 'form-control', 'id' => 'contact_custom_field_1_label']);; ?>

            </div>
        </div>
        <div class="col-sm-3">
            <div class="form-group">
                <?php echo Form::label('contact_custom_field_2_label', __('lang_v1.contact_custom_field2'));; ?>

                <?php echo Form::text('custom_labels[contact][custom_field_2]', !empty($custom_labels['contact']['custom_field_2']) ? $custom_labels['contact']['custom_field_2'] : null, 
                    ['class' => 'form-control', 'id' => 'contact_custom_field_2_label']);; ?>

            </div>
        </div>
        <div class="col-sm-3">
            <div class="form-group">
                <?php echo Form::label('contact_custom_field_3_label', __('lang_v1.contact_custom_field3'));; ?>

                <?php echo Form::text('custom_labels[contact][custom_field_3]', !empty($custom_labels['contact']['custom_field_3']) ? $custom_labels['contact']['custom_field_3'] : null, 
                    ['class' => 'form-control', 'id' => 'contact_custom_field_3_label']);; ?>

            </div>
        </div>
        <div class="col-sm-3">
            <div class="form-group">
                <?php echo Form::label('contact_custom_field_4_label', __('lang_v1.contact_custom_field4'));; ?>

                <?php echo Form::text('custom_labels[contact][custom_field_4]', !empty($custom_labels['contact']['custom_field_4']) ? $custom_labels['contact']['custom_field_4'] : null, 
                    ['class' => 'form-control', 'id' => 'contact_custom_field_4_label']);; ?>

            </div>
        </div>
        <div class="col-sm-3">
            <div class="form-group">
                <?php echo Form::label('contact_custom_field_5_label', __('lang_v1.custom_field', ['number' => 5]));; ?>

                <?php echo Form::text('custom_labels[contact][custom_field_5]', !empty($custom_labels['contact']['custom_field_5']) ? $custom_labels['contact']['custom_field_5'] : null, 
                    ['class' => 'form-control', 'id' => 'contact_custom_field_5_label']);; ?>

            </div>
        </div>
        <div class="col-sm-3">
            <div class="form-group">
                <?php echo Form::label('contact_custom_field_6_label', __('lang_v1.custom_field', ['number' => 6]));; ?>

                <?php echo Form::text('custom_labels[contact][custom_field_6]', !empty($custom_labels['contact']['custom_field_6']) ? $custom_labels['contact']['custom_field_6'] : null, 
                    ['class' => 'form-control', 'id' => 'contact_custom_field_6_label']);; ?>

            </div>
        </div>
        <div class="col-sm-3">
            <div class="form-group">
                <?php echo Form::label('contact_custom_field_7_label', __('lang_v1.custom_field', ['number' => 7]));; ?>

                <?php echo Form::text('custom_labels[contact][custom_field_7]', !empty($custom_labels['contact']['custom_field_7']) ? $custom_labels['contact']['custom_field_7'] : null, 
                    ['class' => 'form-control', 'id' => 'contact_custom_field_7_label']);; ?>

            </div>
        </div>
        <div class="col-sm-3">
            <div class="form-group">
                <?php echo Form::label('contact_custom_field_8_label', __('lang_v1.custom_field', ['number' => 8]));; ?>

                <?php echo Form::text('custom_labels[contact][custom_field_8]', !empty($custom_labels['contact']['custom_field_8']) ? $custom_labels['contact']['custom_field_8'] : null, 
                    ['class' => 'form-control', 'id' => 'contact_custom_field_8_label']);; ?>

            </div>
        </div>
        <div class="col-sm-3">
            <div class="form-group">
                <?php echo Form::label('contact_custom_field_9_label', __('lang_v1.custom_field', ['number' => 9]));; ?>

                <?php echo Form::text('custom_labels[contact][custom_field_9]', !empty($custom_labels['contact']['custom_field_9']) ? $custom_labels['contact']['custom_field_9'] : null, 
                    ['class' => 'form-control', 'id' => 'contact_custom_field_9_label']);; ?>

            </div>
        </div>
        <div class="col-sm-3">
            <div class="form-group">
                <?php echo Form::label('contact_custom_field_10_label', __('lang_v1.custom_field', ['number' => 10]));; ?>

                <?php echo Form::text('custom_labels[contact][custom_field_10]', !empty($custom_labels['contact']['custom_field_10']) ? $custom_labels['contact']['custom_field_10'] : null, 
                    ['class' => 'form-control', 'id' => 'contact_custom_field_10_label']);; ?>

            </div>
        </div>
        <div class="clearfix"></div>
        <div class="col-sm-12">
            <h4><?php echo app('translator')->getFromJson('lang_v1.labels_for_product_custom_fields'); ?>:</h4>
        </div>
        <div class="col-sm-3">
            <div class="form-group">
                <?php echo Form::label('product_custom_field_1_label', __('lang_v1.product_custom_field1'));; ?>

                <?php echo Form::text('custom_labels[product][custom_field_1]', !empty($custom_labels['product']['custom_field_1']) ? $custom_labels['product']['custom_field_1'] : null, 
                    ['class' => 'form-control', 'id' => 'product_custom_field_1_label']);; ?>

            </div>
        </div>
        <div class="col-sm-3">
            <div class="form-group">
                <?php echo Form::label('product_custom_field_2_label', __('lang_v1.product_custom_field2'));; ?>

                <?php echo Form::text('custom_labels[product][custom_field_2]', !empty($custom_labels['product']['custom_field_2']) ? $custom_labels['product']['custom_field_2'] : null, 
                    ['class' => 'form-control', 'id' => 'product_custom_field_2_label']);; ?>

            </div>
        </div>
        <div class="col-sm-3">
            <div class="form-group">
                <?php echo Form::label('product_custom_field_3_label', __('lang_v1.product_custom_field3'));; ?>

                <?php echo Form::text('custom_labels[product][custom_field_3]', !empty($custom_labels['product']['custom_field_3']) ? $custom_labels['product']['custom_field_3'] : null, 
                    ['class' => 'form-control', 'id' => 'product_custom_field_3_label']);; ?>

            </div>
        </div>
        <div class="col-sm-3">
            <div class="form-group">
                <?php echo Form::label('product_custom_field_4_label', __('lang_v1.product_custom_field4'));; ?>

                <?php echo Form::text('custom_labels[product][custom_field_4]', !empty($custom_labels['product']['custom_field_4']) ? $custom_labels['product']['custom_field_4'] : null, 
                    ['class' => 'form-control', 'id' => 'product_custom_field_4_label']);; ?>

            </div>
        </div>
        <div class="clearfix"></div>
        <div class="col-sm-12">
            <h4><?php echo app('translator')->getFromJson('lang_v1.labels_for_location_custom_fields'); ?>:</h4>
        </div>
        <div class="col-sm-3">
            <div class="form-group">
                <?php echo Form::label('location_custom_field_1_label', __('lang_v1.location_custom_field1'));; ?>

                <?php echo Form::text('custom_labels[location][custom_field_1]', !empty($custom_labels['location']['custom_field_1']) ? $custom_labels['location']['custom_field_1'] : null, 
                    ['class' => 'form-control', 'id' => 'location_custom_field_1_label']);; ?>

            </div>
        </div>
        <div class="col-sm-3">
            <div class="form-group">
                <?php echo Form::label('location_custom_field_2_label', __('lang_v1.location_custom_field2'));; ?>

                <?php echo Form::text('custom_labels[location][custom_field_2]', !empty($custom_labels['location']['custom_field_2']) ? $custom_labels['location']['custom_field_2'] : null, 
                    ['class' => 'form-control', 'id' => 'location_custom_field_2_label']);; ?>

            </div>
        </div>
        <div class="col-sm-3">
            <div class="form-group">
                <?php echo Form::label('location_custom_field_3_label', __('lang_v1.location_custom_field3'));; ?>

                <?php echo Form::text('custom_labels[location][custom_field_3]', !empty($custom_labels['location']['custom_field_3']) ? $custom_labels['location']['custom_field_3'] : null, 
                    ['class' => 'form-control', 'id' => 'location_custom_field_3_label']);; ?>

            </div>
        </div>
        <div class="col-sm-3">
            <div class="form-group">
                <?php echo Form::label('location_custom_field_4_label', __('lang_v1.location_custom_field4'));; ?>

                <?php echo Form::text('custom_labels[location][custom_field_4]', !empty($custom_labels['location']['custom_field_4']) ? $custom_labels['location']['custom_field_4'] : null, 
                    ['class' => 'form-control', 'id' => 'location_custom_field_4_label']);; ?>

            </div>
        </div>
        <div class="clearfix"></div>
        <div class="col-sm-12">
            <h4><?php echo app('translator')->getFromJson('lang_v1.labels_for_user_custom_fields'); ?>:</h4>
        </div>
        <div class="col-sm-3">
            <div class="form-group">
                <?php echo Form::label('user_custom_field_1_label', __('lang_v1.user_custom_field1'));; ?>

                <?php echo Form::text('custom_labels[user][custom_field_1]', !empty($custom_labels['user']['custom_field_1']) ? $custom_labels['user']['custom_field_1'] : null, 
                    ['class' => 'form-control', 'id' => 'user_custom_field_1_label']);; ?>

            </div>
        </div>
        <div class="col-sm-3">
            <div class="form-group">
                <?php echo Form::label('user_custom_field_2_label', __('lang_v1.user_custom_field2'));; ?>

                <?php echo Form::text('custom_labels[user][custom_field_2]', !empty($custom_labels['user']['custom_field_2']) ? $custom_labels['user']['custom_field_2'] : null, 
                    ['class' => 'form-control', 'id' => 'user_custom_field_2_label']);; ?>

            </div>
        </div>
        <div class="col-sm-3">
            <div class="form-group">
                <?php echo Form::label('user_custom_field_3_label', __('lang_v1.user_custom_field3'));; ?>

                <?php echo Form::text('custom_labels[user][custom_field_3]', !empty($custom_labels['user']['custom_field_3']) ? $custom_labels['user']['custom_field_3'] : null, 
                    ['class' => 'form-control', 'id' => 'user_custom_field_3_label']);; ?>

            </div>
        </div>
        <div class="col-sm-3">
            <div class="form-group">
                <?php echo Form::label('user_custom_field_4_label', __('lang_v1.user_custom_field4'));; ?>

                <?php echo Form::text('custom_labels[user][custom_field_4]', !empty($custom_labels['user']['custom_field_4']) ? $custom_labels['user']['custom_field_4'] : null, 
                    ['class' => 'form-control', 'id' => 'user_custom_field_4_label']);; ?>

            </div>
        </div>
        <div class="clearfix"></div>
        <div class="col-sm-12">
            <h4><?php echo app('translator')->getFromJson('lang_v1.labels_for_purchase_custom_fields'); ?>:</h4>
        </div>
        <div class="col-sm-3">
            <div class="form-group">
                <?php echo Form::label('purchase_custom_field_1_label', __('lang_v1.product_custom_field1'));; ?>

                <?php echo Form::text('custom_labels[purchase][custom_field_1]', !empty($custom_labels['purchase']['custom_field_1']) ? $custom_labels['purchase']['custom_field_1'] : null, 
                    ['class' => 'form-control', 'id' => 'purchase_custom_field_1_label']);; ?>

            </div>
        </div>
        <div class="col-sm-3">
            <div class="form-group">
                <?php echo Form::label('purchase_custom_field_2_label', __('lang_v1.product_custom_field2'));; ?>

                <?php echo Form::text('custom_labels[purchase][custom_field_2]', !empty($custom_labels['purchase']['custom_field_2']) ? $custom_labels['purchase']['custom_field_2'] : null, 
                    ['class' => 'form-control', 'id' => 'purchase_custom_field_2_label']);; ?>

            </div>
        </div>
        <div class="col-sm-3">
            <div class="form-group">
                <?php echo Form::label('purchase_custom_field_3_label', __('lang_v1.product_custom_field3'));; ?>

                <?php echo Form::text('custom_labels[purchase][custom_field_3]', !empty($custom_labels['purchase']['custom_field_3']) ? $custom_labels['purchase']['custom_field_3'] : null, 
                    ['class' => 'form-control', 'id' => 'purchase_custom_field_3_label']);; ?>

            </div>
        </div>
        <div class="col-sm-3">
            <div class="form-group">
                <?php echo Form::label('purchase_custom_field_4_label', __('lang_v1.product_custom_field4'));; ?>

                <?php echo Form::text('custom_labels[purchase][custom_field_4]', !empty($custom_labels['purchase']['custom_field_4']) ? $custom_labels['purchase']['custom_field_4'] : null, 
                    ['class' => 'form-control', 'id' => 'purchase_custom_field_4_label']);; ?>

            </div>
        </div>
        <div class="clearfix"></div>
        <div class="col-sm-12">
            <h4><?php echo app('translator')->getFromJson('lang_v1.labels_for_sell_custom_fields'); ?>:</h4>
        </div>
        <div class="col-sm-3">
            <div class="form-group">
                <?php echo Form::label('sell_custom_field_1_label', __('lang_v1.product_custom_field1'));; ?>

                <div class="input-group">
                    <?php echo Form::text('custom_labels[sell][custom_field_1]', !empty($custom_labels['sell']['custom_field_1']) ? $custom_labels['sell']['custom_field_1'] : null, 
                    ['class' => 'form-control', 'id' => 'sell_custom_field_1_label']);; ?>

                    <div class="input-group-addon">
                        <label>
                        <input type="checkbox" name="custom_labels[sell][is_custom_field_1_required]" value="1" <?php if(!empty($custom_labels['sell']['is_custom_field_1_required']) && $custom_labels['sell']['is_custom_field_1_required'] == 1): ?> checked <?php endif; ?> > <?php echo app('translator')->getFromJson('lang_v1.is_required'); ?></label>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-sm-3">
            <div class="form-group">
                <?php echo Form::label('sell_custom_field_2_label', __('lang_v1.product_custom_field2'));; ?>

                <div class="input-group"> 
                <?php echo Form::text('custom_labels[sell][custom_field_2]', !empty($custom_labels['sell']['custom_field_2']) ? $custom_labels['sell']['custom_field_2'] : null, 
                    ['class' => 'form-control', 'id' => 'sell_custom_field_2_label']);; ?>

                    <div class="input-group-addon">
                        <label>
                        <input type="checkbox" name="custom_labels[sell][is_custom_field_2_required]" value="1" <?php if(!empty($custom_labels['sell']['is_custom_field_2_required']) && $custom_labels['sell']['is_custom_field_2_required'] == 1): ?> checked <?php endif; ?> > <?php echo app('translator')->getFromJson('lang_v1.is_required'); ?></label>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-sm-3">
            <div class="form-group">
                <?php echo Form::label('sell_custom_field_3_label', __('lang_v1.product_custom_field3'));; ?>

                <div class="input-group">
                    <?php echo Form::text('custom_labels[sell][custom_field_3]', !empty($custom_labels['sell']['custom_field_3']) ? $custom_labels['sell']['custom_field_3'] : null, 
                    ['class' => 'form-control', 'id' => 'sell_custom_field_3_label']);; ?>

                    <div class="input-group-addon">
                        <label>
                        <input type="checkbox" name="custom_labels[sell][is_custom_field_3_required]" value="1" <?php if(!empty($custom_labels['sell']['is_custom_field_3_required']) && $custom_labels['sell']['is_custom_field_3_required'] == 1): ?> checked <?php endif; ?> > <?php echo app('translator')->getFromJson('lang_v1.is_required'); ?></label>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-sm-3">
            <div class="form-group">
                <?php echo Form::label('sell_custom_field_4_label', __('lang_v1.product_custom_field4'));; ?>

                <div class="input-group">
                    <?php echo Form::text('custom_labels[sell][custom_field_4]', !empty($custom_labels['sell']['custom_field_4']) ? $custom_labels['sell']['custom_field_4'] : null, 
                    ['class' => 'form-control', 'id' => 'sell_custom_field_4_label']);; ?>

                    <div class="input-group-addon">
                        <label>
                        <input type="checkbox" name="custom_labels[sell][is_custom_field_4_required]" value="1" <?php if(!empty($custom_labels['sell']['is_custom_field_4_required']) && $custom_labels['sell']['is_custom_field_4_required'] == 1): ?> checked <?php endif; ?> > <?php echo app('translator')->getFromJson('lang_v1.is_required'); ?></label>
                    </div>
                </div>
            </div>
        </div>
        <div class="clearfix"></div>
        <div class="col-sm-12">
            <h4><?php echo app('translator')->getFromJson('lang_v1.labels_for_sale_shipping_custom_fields'); ?>:</h4>
        </div>
        <div class="col-sm-6">
            <div class="form-group">
                <?php echo Form::label('shipping_custom_field_1_label', __('lang_v1.custom_field', ['number' => 1])); ?>

                <div class="input-group">
                <?php echo Form::text('custom_labels[shipping][custom_field_1]', !empty($custom_labels['shipping']['custom_field_1']) ? $custom_labels['shipping']['custom_field_1'] : null, 
                    ['class' => 'form-control', 'id' => 'shipping_custom_field_1_label']);; ?>

                    <div class="input-group-addon">
                        <label>
                        <input type="checkbox" name="custom_labels[shipping][is_custom_field_1_required]" value="1" <?php if(!empty($custom_labels['shipping']['is_custom_field_1_required']) && $custom_labels['shipping']['is_custom_field_1_required'] == 1): ?> checked <?php endif; ?> > <?php echo app('translator')->getFromJson('lang_v1.is_required'); ?></label>
                        &nbsp;
                        <label>
                            <input type="checkbox" name="custom_labels[shipping][is_custom_field_1_contact_default]" value="1" <?php if(!empty($custom_labels['shipping']['is_custom_field_1_contact_default']) && $custom_labels['shipping']['is_custom_field_1_contact_default'] == 1): ?> checked <?php endif; ?> > <?php echo app('translator')->getFromJson('lang_v1.is_default_for_contact'); ?>
                        </label>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-sm-6">
            <div class="form-group">
                <?php echo Form::label('shipping_custom_field_2_label', __('lang_v1.custom_field', ['number' => 2])); ?>

                <div class="input-group">
                <?php echo Form::text('custom_labels[shipping][custom_field_2]', !empty($custom_labels['shipping']['custom_field_2']) ? $custom_labels['shipping']['custom_field_2'] : null, 
                    ['class' => 'form-control', 'id' => 'shipping_custom_field_2_label']);; ?>

                    <div class="input-group-addon">
                        <label>
                        <input type="checkbox" name="custom_labels[shipping][is_custom_field_2_required]" value="1" <?php if(!empty($custom_labels['shipping']['is_custom_field_2_required']) && $custom_labels['shipping']['is_custom_field_2_required'] == 1): ?> checked <?php endif; ?> > <?php echo app('translator')->getFromJson('lang_v1.is_required'); ?></label>
                        &nbsp;
                        <label>
                            <input type="checkbox" name="custom_labels[shipping][is_custom_field_2_contact_default]" value="1" <?php if(!empty($custom_labels['shipping']['is_custom_field_2_contact_default']) && $custom_labels['shipping']['is_custom_field_2_contact_default'] == 1): ?> checked <?php endif; ?> > <?php echo app('translator')->getFromJson('lang_v1.is_default_for_contact'); ?>
                        </label>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-sm-6">
            <div class="form-group">
                <?php echo Form::label('shipping_custom_field_3_label', __('lang_v1.custom_field', ['number' => 3])); ?>

                <div class="input-group">
                <?php echo Form::text('custom_labels[shipping][custom_field_3]', !empty($custom_labels['shipping']['custom_field_3']) ? $custom_labels['shipping']['custom_field_3'] : null, 
                    ['class' => 'form-control', 'id' => 'shipping_custom_field_3_label']);; ?>

                    <div class="input-group-addon">
                        <label>
                        <input type="checkbox" name="custom_labels[shipping][is_custom_field_3_required]" value="1" <?php if(!empty($custom_labels['shipping']['is_custom_field_3_required']) && $custom_labels['shipping']['is_custom_field_3_required'] == 1): ?> checked <?php endif; ?> > <?php echo app('translator')->getFromJson('lang_v1.is_required'); ?></label>
                        &nbsp;
                        <label>
                            <input type="checkbox" name="custom_labels[shipping][is_custom_field_3_contact_default]" value="1" <?php if(!empty($custom_labels['shipping']['is_custom_field_3_contact_default']) && $custom_labels['shipping']['is_custom_field_3_contact_default'] == 1): ?> checked <?php endif; ?> > <?php echo app('translator')->getFromJson('lang_v1.is_default_for_contact'); ?>
                        </label>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-sm-6">
            <div class="form-group">
                <?php echo Form::label('shipping_custom_field_4_label', __('lang_v1.custom_field', ['number' => 4])); ?>

                <div class="input-group">
                <?php echo Form::text('custom_labels[shipping][custom_field_4]', !empty($custom_labels['shipping']['custom_field_4']) ? $custom_labels['shipping']['custom_field_4'] : null, 
                    ['class' => 'form-control', 'id' => 'shipping_custom_field_4_label']);; ?>

                    <div class="input-group-addon">
                        <label>
                        <input type="checkbox" name="custom_labels[shipping][is_custom_field_4_required]" value="1" <?php if(!empty($custom_labels['shipping']['is_custom_field_4_required']) && $custom_labels['shipping']['is_custom_field_4_required'] == 1): ?> checked <?php endif; ?> > <?php echo app('translator')->getFromJson('lang_v1.is_required'); ?></label>
                        &nbsp;
                        <label>
                            <input type="checkbox" name="custom_labels[shipping][is_custom_field_4_contact_default]" value="1" <?php if(!empty($custom_labels['shipping']['is_custom_field_4_contact_default']) && $custom_labels['shipping']['is_custom_field_4_contact_default'] == 1): ?> checked <?php endif; ?> > <?php echo app('translator')->getFromJson('lang_v1.is_default_for_contact'); ?>
                        </label>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-sm-6">
            <div class="form-group">
                <?php echo Form::label('shipping_custom_field_5_label', __('lang_v1.custom_field', ['number' => 5])); ?>

                <div class="input-group">
                <?php echo Form::text('custom_labels[shipping][custom_field_5]', !empty($custom_labels['shipping']['custom_field_5']) ? $custom_labels['shipping']['custom_field_5'] : null, 
                    ['class' => 'form-control', 'id' => 'shipping_custom_field_5_label']);; ?>

                    <div class="input-group-addon">
                        <label>
                        <input type="checkbox" name="custom_labels[shipping][is_custom_field_5_required]" value="1" <?php if(!empty($custom_labels['shipping']['is_custom_field_5_required']) && $custom_labels['shipping']['is_custom_field_5_required'] == 1): ?> checked <?php endif; ?> > <?php echo app('translator')->getFromJson('lang_v1.is_required'); ?></label>
                        &nbsp;
                        <label>
                            <input type="checkbox" name="custom_labels[shipping][is_custom_field_5_contact_default]" value="1" <?php if(!empty($custom_labels['shipping']['is_custom_field_5_contact_default']) && $custom_labels['shipping']['is_custom_field_5_contact_default'] == 1): ?> checked <?php endif; ?> > <?php echo app('translator')->getFromJson('lang_v1.is_default_for_contact'); ?>
                        </label>
                    </div>
                </div>
            </div>
        </div>
        <div class="clearfix"></div>
        <div class="col-sm-12">
            <h4><?php echo app('translator')->getFromJson('lang_v1.labels_for_types_of_service_custom_fields'); ?>:</h4>
        </div>
        <div class="col-sm-3">
            <div class="form-group">
                <?php echo Form::label('types_of_service_custom_field_1_label', __('lang_v1.service_custom_field_1'));; ?>

                <?php echo Form::text('custom_labels[types_of_service][custom_field_1]', !empty($custom_labels['types_of_service']['custom_field_1']) ? $custom_labels['types_of_service']['custom_field_1'] : null, 
                    ['class' => 'form-control', 'id' => 'types_of_service_custom_field_1_label']);; ?>

            </div>
        </div>
        <div class="col-sm-3">
            <div class="form-group">
                <?php echo Form::label('types_of_service_custom_field_2_label', __('lang_v1.service_custom_field_2'));; ?>

                <?php echo Form::text('custom_labels[types_of_service][custom_field_2]', !empty($custom_labels['types_of_service']['custom_field_2']) ? $custom_labels['types_of_service']['custom_field_2'] : null, 
                    ['class' => 'form-control', 'id' => 'types_of_service_custom_field_2_label']);; ?>

            </div>
        </div>
        <div class="col-sm-3">
            <div class="form-group">
                <?php echo Form::label('types_of_service_custom_field_3_label', __('lang_v1.service_custom_field_3'));; ?>

                <?php echo Form::text('custom_labels[types_of_service][custom_field_3]', !empty($custom_labels['types_of_service']['custom_field_3']) ? $custom_labels['types_of_service']['custom_field_3'] : null, 
                    ['class' => 'form-control', 'id' => 'types_of_service_custom_field_3_label']);; ?>

            </div>
        </div>
        <div class="col-sm-3">
            <div class="form-group">
                <?php echo Form::label('types_of_service_custom_field_4_label', __('lang_v1.service_custom_field_4'));; ?>

                <?php echo Form::text('custom_labels[types_of_service][custom_field_4]', !empty($custom_labels['types_of_service']['custom_field_4']) ? $custom_labels['types_of_service']['custom_field_4'] : null, 
                    ['class' => 'form-control', 'id' => 'types_of_service_custom_field_4_label']);; ?>

            </div>
        </div>
        <div class="col-sm-3">
            <div class="form-group">
                <?php echo Form::label('types_of_service_custom_field_5_label', __('lang_v1.custom_field', ['number' => 5]));; ?>

                <?php echo Form::text('custom_labels[types_of_service][custom_field_5]', !empty($custom_labels['types_of_service']['custom_field_5']) ? $custom_labels['types_of_service']['custom_field_5'] : null, 
                    ['class' => 'form-control', 'id' => 'types_of_service_custom_field_5_label']);; ?>

            </div>
        </div>
        <div class="col-sm-3">
            <div class="form-group">
                <?php echo Form::label('types_of_service_custom_field_6_label', __('lang_v1.custom_field', ['number' => 6]));; ?>

                <?php echo Form::text('custom_labels[types_of_service][custom_field_6]', !empty($custom_labels['types_of_service']['custom_field_6']) ? $custom_labels['types_of_service']['custom_field_6'] : null, 
                    ['class' => 'form-control', 'id' => 'types_of_service_custom_field_6_label']);; ?>

            </div>
        </div>
    </div>
</div>

<?php $__env->startSection('javascript'); ?>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jscolor/2.4.6/jscolor.min.js"></script>
<script>
    document.addEventListener('DOMContentLoaded', function() {
        jscolor.installByClassName('jscolor');

        document.querySelectorAll('.jscolor').forEach(function(input) {
            input.addEventListener('input', function() {
                if (this.value === '') {
                    this.jscolor.fromString('#ECECEC'); 
                }
            });
        });
    });
</script>
<?php $__env->stopSection(); ?><?php /**PATH C:\xampp\htdocs\laravel_works\admin_pos\resources\views/business/partials/settings_custom_labels.blade.php ENDPATH**/ ?>