<?php $__currentLoopData = $combinations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $combination): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php echo $__env->make('product.partials.retail_variation_value_row', [
        'variation_index' => $row_index, 
        'value_index' => $loop->index, 
        'variation_name' => $combination['values'], // Combined value names
        'variation_value_id' => null, // No specific ID for combined values
        'profit_percent' => $profit_percent,
        'value_ids' => $combination['value_ids'] // List of associated value IDs
    ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH C:\xampp\htdocs\laravel_works\admin_pos\resources\views/product/partials/retail_product_variation_template.blade.php ENDPATH**/ ?>