<div class="modal fade" id="update_outlet_model" tabindex="-1" role="dialog" aria-labelledby="gridSystemModalLabel">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <?php echo Form::open([ 'method' => 'PUT', 'id' => 'update_outlets_form', 'class' => 'update']); ?>

                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                    <h4 class="modal-title"><?php echo app('translator')->getFromJson('gto.manage_outlets'); ?></h4>
                </div>
                <div class="modal-body">
                    <div class="row">
                        <div class="col-sm-12">
                            <div class="form-group">
                                <?php echo Form::label('name', __('gto.outlet_name').':*'); ?>

                                <?php echo Form::text('name', null, ['class' => 'form-control', 'id' => 'name', 'required']); ?>

                            </div>
                        </div>
                    </div>
                    <div class="row file-format-cls">
                        <div class="col-sm-10">
                            <div class="form-group">
                                <?php echo Form::label('file_formats', __('gto.outlet_file_formats').':*'); ?>

                                <?php echo Form::text('file_formats[]', null, ['class' => 'form-control', 'id' => 'update_outlet_file_format1', 'required', 'readonly']); ?>  
                            </div>
                        </div>
                        <div class="col-sm-2 file-format-clr">
                            <button type="button" class="btn btn-outline-secondary clear-file-format">
                                    <i class="fas fa-times"></i>
                            </button>
                        </div>
                    </div>
                <div class="row">
                    <div class="col-sm-12">
                    <?php $__currentLoopData = $outletFileFormats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $format): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <button type="button" data-id = <?php echo e($index, false); ?> data-action="update" class="btn btn-info file-format-btn"><?php echo e($format, false); ?></button>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                    </div>
                    <div class="col-sm-12">
                        <span id="update_file_format_preview" class="text-danger"></span>
                    </div>
                </div> 
                    <div class="row">
                        <div class="col-sm-12">
                            <div class="form-group">
                                <?php echo Form::label('start_date', __('gto.outlet_start_date').':*'); ?>

                                <?php echo Form::date('start_date', null, ['class' => 'form-control', 'id' => 'start_date', 'required']); ?>

                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-sm-12">
                            <div class="form-group">
                                <?php echo Form::label('report_formats', __('gto.outlet_report_formats').':*'); ?>

                                <?php echo Form::select('report_formats[]', $outletReportFormats, null, ['class' => 'form-control select2', 'id' => 'update_outlet_report_format', 'multiple' => 'multiple', 'required']); ?>

                            </div>
                            <div class="form-group">
                                <span id="update_report_format_preview" class="text-danger"></span>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-sm-4">
                            <div class="form-group">
                                <?php echo Form::label('report_type', __('gto.outlet_report_type').':*'); ?>

                                <?php echo Form::select('report_type', ['hourly' => 'Hourly', 'date_wise' => 'Date Wise'], null, ['class' => 'form-control select2', 'id' => 'report_type', 'required']); ?>

                            </div>
                        </div>
                        <div class="col-sm-4">
                        <div class="form-group">
                        <?php echo Form::label('report_date_format', __('gto.outlet_report_date').':*'); ?>

                        <?php echo Form::select('report_date_format', $outletDateFormat, null, ['class' => 'form-control select2', 'id' => 'report_date_format', 'required']); ?>

                        </div>
                    </div>
                    <div class="col-sm-4">
                        <div class="reportform-group">
                        <?php echo Form::label('file_date_format', __('gto.outlet_file_date').':*'); ?>

                        <?php echo Form::select('file_date_format', $outletDateFormat, null, ['class' => 'form-control select2', 'id' => 'file_date_format', 'required']); ?>

                        </div>
                    </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="submit" class="btn btn-primary"><?php echo app('translator')->getFromJson('messages.save'); ?></button>
                    <button type="button" class="btn btn-default" data-dismiss="modal"><?php echo app('translator')->getFromJson('messages.close'); ?></button>
                </div>
            <?php echo Form::close(); ?>

        </div>
    </div>
</div>

    <?php /**PATH C:\xampp\htdocs\laravel_works\admin_pos\resources\views/business_outlets/edit.blade.php ENDPATH**/ ?>