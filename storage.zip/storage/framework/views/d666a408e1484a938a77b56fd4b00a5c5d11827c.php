<?php $__env->startSection('title',__('lazada')); ?>

<?php $__env->startSection('content'); ?>

<!-- Content Header (Page header) -->
<section class="content-header">
    <h1><?php echo app('translator')->getFromJson('woocommerce::lang.api_settings'); ?></h1>
</section>

<!-- Main content -->
<section class="content">
     
    <?php echo Form::open(['url' => action('Lazada\LazadaMainController@updateSettings'),'method' => 'post','onsubmit' => 'return validateForm(event)', 'id' => 'api_setting_form' ]); ?>

    <div class="row">
        <div class="col-xs-12">
            <!--  <pos-tab-container> -->
            <div class="col-xs-12 pos-tab-container">
               
                <div class="col-lg-10 col-md-10 col-sm-10 col-xs-10 pos-tab">
                        <div class="row">
                            <div class="col-xs-4">
                                <div class="form-group" style="margin: 15px;">
                                    <?php echo Form::label('Lazada APP Key'); ?>

                                    <?php echo Form::text('lzd_app_key',$default_settings['lzd_app_key'], ['class' => 'form-control', 'placeholder' => 'Lazada APP Key', 'id' => 'lzd_app_key','pattern' => '[0-9]+','title' => 'Only numbers are allowed','type' => 'number' ]); ?>

         
                                </div>
                            </div>
                            <div class="col-xs-4">
                                <div class="form-group" style="margin: 15px;">
                                    <?php echo Form::label('Lazada Secret Key'); ?>

                                    <?php echo Form::text('lzd_secret_key', $default_settings['lzd_secret_key'],['class' => 'form-control','placeholder' => 'Lazada Secret Key','id' => 'lzd_secret_key',]); ?>

                                </div>
                            </div>
                            
                        </div>
                    
                </div>
            </div>


            <!--  </pos-tab-container> -->
        </div>
    </div>
    <div class="row">
        <div class="col-xs-12">
            <div class="form-group pull-right">
            <?php echo e(Form::submit('Update', ['class' => 'btn btn-danger', 'id' => 'submitButton']), false); ?>

                <!-- <?php echo e(Form::submit('update', ['class'=>"btn btn-danger"]), false); ?> -->
            </div>
        </div>
    </div>
    <?php echo Form::close(); ?>

</section>
<style>

div.pos-tab-container {
    z-index: 10;
    background-color: #ffffff;
    padding: 60px !important;
    border-radius: 4px;
    -moz-border-radius: 4px;
    border: 1px solid #ddd;
    margin-bottom: 28px;
    -webkit-box-shadow: 0 6px 12px rgba(0,0,0,.175);
    box-shadow: 0 6px 12px rgba(0,0,0,.100);
    -moz-box-shadow: 0 6px 12px rgba(0,0,0,.175);
    background-clip: padding-box;
}
</style>


<script>
    document.getElementById('lzd_app_key').addEventListener('input', function(e) {
        // Allow only numeric input (no decimals or other characters)
        this.value = this.value.replace(/[^0-9]/g, '');
    });

    function validateForm(event) {
       
        var lzdAppKey = document.getElementById('lzd_app_key').value;
        var lzdSecretKey = document.getElementById('lzd_secret_key').value;

        if (lzdAppKey === '' || lzdSecretKey === '') {
            event.preventDefault(); 
            alert("Both fields are required. Please fill out all fields.");
            return false; // Prevent form submission
        }
        return true; // Allow form submission if all fields are filled
    }
</script>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('javascript'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel_works\admin_pos\resources\views/lazada/api_settings.blade.php ENDPATH**/ ?>