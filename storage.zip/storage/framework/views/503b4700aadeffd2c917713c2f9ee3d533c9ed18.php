<?php $__env->startSection('title', __( 'telegram_token.bot_token' )); ?>

<?php $__env->startSection('content'); ?>
<!-- Content Header (Page header) -->
<section class="content-header">
    <h1><?php echo app('translator')->getFromJson( 'telegram_token.bot_token' ); ?>
        <small><?php echo app('translator')->getFromJson( 'telegram_token.manage_your_telegram_bot_tokens' ); ?></small>
    </h1>
</section>

<!-- Main content -->
<section class="content">
    <?php $__env->startComponent('components.widget', ['class' => 'box-primary', 'title' => __( 'telegram_token.all_your_bot_tokens' )]); ?>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('telegram_token.create')): ?>
            <?php $__env->slot('tool'); ?>
                <div class="box-tools">
                    <button type="button" class="btn btn-block btn-primary btn-modal" 
                            data-href="<?php echo e(action('TelegramTokenController@create'), false); ?>" 
                            data-container=".telegram_token_modal">
                            <i class="fa fa-plus"></i> <?php echo app('translator')->getFromJson( 'messages.add' ); ?></button>
                </div>
            <?php $__env->endSlot(); ?>
        <?php endif; ?>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('telegram_token.view')): ?>
            <div class="table-responsive">
                <table class="table table-bordered table-striped" id="telegram_token_table">
                    <thead>
                        <tr>
                            <th><?php echo app('translator')->getFromJson( 'telegram_token.serial_no' ); ?></th>
                            <th><?php echo app('translator')->getFromJson( 'telegram_token.name' ); ?></th>
                            <th><?php echo app('translator')->getFromJson( 'telegram_token.token_id' ); ?></th>
                            
                            <th><?php echo app('translator')->getFromJson( 'messages.action' ); ?></th>
                        </tr>
                    </thead>
                </table>
            </div>
        <?php endif; ?>
    <?php echo $__env->renderComponent(); ?>

    <?php $__env->startComponent('components.widget', ['class' => 'box-primary']); ?>
        <?php $__env->slot('title'); ?>
            <?php echo app('translator')->getFromJson( 'telegram_token.telegram_channel_and_groups' ); ?> <?php
                if(session('business.enable_tooltip')){
                    echo '<i class="fa fa-info-circle text-info hover-q no-print " aria-hidden="true" 
                    data-container="body" data-toggle="popover" data-placement="auto bottom" 
                    data-content="' . __('tooltip.tax_groups') . '" data-html="true" data-trigger="hover"></i>';
                }
                ?>
        <?php $__env->endSlot(); ?>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('telegram_token.create')): ?>
            <?php $__env->slot('tool'); ?>
                <div class="box-tools">
                    <button type="button" class="btn btn-block btn-primary btn-modal" 
                    data-href="<?php echo e(action('TelegramController@create'), false); ?>" 
                    data-container=".telegram_channel_modal">
                    <i class="fa fa-plus"></i> <?php echo app('translator')->getFromJson( 'messages.add' ); ?></button>
                </div>
            <?php $__env->endSlot(); ?>
        <?php endif; ?>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('telegram_token.view')): ?>
            <div class="table-responsive">
                <table class="table table-bordered table-striped" id="telegram_channel_table">
                    <thead>
                        <tr>
                            <th><?php echo app('translator')->getFromJson( 'telegram_token.serial_no' ); ?></th>
                            <th><?php echo app('translator')->getFromJson( 'telegram_token.name' ); ?></th>
                            <th><?php echo app('translator')->getFromJson( 'telegram_token.channel_or_group_id' ); ?></th>
                            <th><?php echo app('translator')->getFromJson( 'telegram_token.type' ); ?></th>
                            
                            <th><?php echo app('translator')->getFromJson( 'messages.action' ); ?></th>
                        </tr>
                    </thead>
                </table>
            </div>
        <?php endif; ?>
    <?php echo $__env->renderComponent(); ?>
    
    <div class="modal fade telegram_token_modal" tabindex="-1" role="dialog" 
    	aria-labelledby="gridSystemModalLabel">
    </div>
    
    <div class="modal fade telegram_channel_modal" tabindex="-1" role="dialog" 
        aria-labelledby="gridSystemModalLabel">
    </div>

</section>
<!-- /.content -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('javascript'); ?>
<script type="text/javascript">
    $(document).ready( function(){
        var telegram_token_table = $('#telegram_token_table').DataTable({
        processing: true,
        serverSide: true,
        ajax: '/telegram-tokens',

        columns: [
            { data: 'id', name: 'id' },
            { data: 'name', name: 'name' },
            { data: 'token_id', name: 'token_id' },
            //{ data: 'business_location_name', name: 'business_location_name' },
            { data: 'action', name: 'action', orderable: false, searchable: false },
        ],
        createdRow: function (row, data, dataIndex) {
            // Add the serial number (row number) to the first column
            $(row).find('td:first').text(dataIndex + 1);
        },

    });

    $(document).on('submit', 'form#telegram_token_add_form', function(e) {
        e.preventDefault();
        var form = $(this);
        var data = form.serialize();

        $.ajax({
            method: 'POST',
            url: $(this).attr('action'),
            dataType: 'json',
            data: data,
            beforeSend: function(xhr) {
                __disable_submit_button(form.find('button[type="submit"]'));
            },
            success: function(result) {
                if (result.success == true) {
                    $('div.telegram_token_modal').modal('hide');
                    toastr.success(result.msg);
                    telegram_token_table.ajax.reload();
                } else {
                    toastr.error(result.msg);
                }
            },
        });
    });

    var telegram_channel_table = $('#telegram_channel_table').DataTable({
        processing: true,
        serverSide: true,
        ajax: '/telegram-channels',

        columns: [
            { data: 'id', name: 'id' },
            { data: 'name', name: 'name' },
            { data: 'channel_id', name: 'channel_id' },
            { data: 'type', name: 'type' },
            // { data: 'business_location_name', name: 'business_location_name' },
            { data: 'action', name: 'action', orderable: false, searchable: false },
        ],
        createdRow: function (row, data, dataIndex) {
            // Add the serial number (row number) to the first column
            $(row).find('td:first').text(dataIndex + 1);
        },

    });

    $(document).on('submit', 'form#telegram_channel_add_form', function(e) {
        e.preventDefault();
        var form = $(this);
        var data = form.serialize();

        $.ajax({
            method: 'POST',
            url: $(this).attr('action'),
            dataType: 'json',
            data: data,
            beforeSend: function(xhr) {
                __disable_submit_button(form.find('button[type="submit"]'));
            },
            success: function(result) {
                if (result.success == true) {
                    $('div.telegram_channel_modal').modal('hide');
                    toastr.success(result.msg);
                    telegram_token_table.ajax.reload();
                    telegram_channel_table.ajax.reload();
                } else {
                    toastr.error(result.msg);
                }
            },
        });
    });

    $(document).on('click', 'button.delete_telegram_channel_or_group_button', function() {
        swal({
            title: LANG.sure,
            text: LANG.confirm_delete_telegram_channel_or_group,
            icon: 'warning',
            buttons: true,
            dangerMode: true,
        }).then(willDelete => {
            if (willDelete) {
                var href = $(this).data('href');
                var data = $(this).serialize();

                $.ajax({
                    method: 'DELETE',
                    url: href,
                    dataType: 'json',
                    data: data,
                    success: function(result) {
                        if (result.success == true) {
                            toastr.success(result.msg);
                            telegram_channel_table.ajax.reload();
                        } else {
                            toastr.error(result.msg);
                        }
                    },
                });
            }
        });
    });

    $(document).on('click', 'button.edit_telegram_channel_or_group_button', function() {
        $('div.telegram_token_modal').load($(this).data('href'), function() {
            $(this).modal('show');

            $('form#telegram_channel_edit_form').submit(function(e) {
                e.preventDefault();
                var form = $(this);
                var data = form.serialize();

                $.ajax({
                    method: 'POST',
                    url: $(this).attr('action'),
                    dataType: 'json',
                    data: data,
                    beforeSend: function(xhr) {
                        __disable_submit_button(form.find('button[type="submit"]'));
                    },
                    success: function(result) {
                        if (result.success == true) {
                            $('div.telegram_token_modal').modal('hide');
                            toastr.success(result.msg);
                            // telegram_token_table.ajax.reload();
                            telegram_channel_table.ajax.reload();
                        } else {
                            toastr.error(result.msg);
                        }
                    },
                });
            });
        });
    });

    // Telegram token edit 
    $(document).on('click', 'button.edit_telegram_token_button', function() {
        $('div.telegram_token_modal').load($(this).data('href'), function() {
            $(this).modal('show');

            $('form#telegram_token_edit_form').submit(function(e) {
                e.preventDefault();
                var form = $(this);
                var data = form.serialize();

                $.ajax({
                    method: 'POST',
                    url: $(this).attr('action'),
                    dataType: 'json',
                    data: data,
                    beforeSend: function(xhr) {
                        __disable_submit_button(form.find('button[type="submit"]'));
                    },
                    success: function(result) {
                        if (result.success == true) {
                            $('div.telegram_token_modal').modal('hide');
                            toastr.success(result.msg);
                            telegram_token_table.ajax.reload();
                            // tax_groups_table.ajax.reload();
                        } else {
                            __enable_submit_button(form.find('button[type="submit"]'));
                            toastr.error(result.msg);
                        }
                    },
                });
            });
        });
    });

    $(document).on('click', 'button.delete_telegram_token_button', function() {
        swal({
            title: LANG.sure,
            text: LANG.confirm_delete_telegram_token,
            icon: 'warning',
            buttons: true,
            dangerMode: true,
        }).then(willDelete => {
            if (willDelete) {
                var href = $(this).data('href');
                var data = $(this).serialize();

                $.ajax({
                    method: 'DELETE',
                    url: href,
                    dataType: 'json',
                    data: data,
                    success: function(result) {
                        if (result.success == true) {
                            toastr.success(result.msg);
                            telegram_token_table.ajax.reload();
                            // tax_groups_table.ajax.reload();
                        } else {
                            toastr.error(result.msg);
                        }
                    },
                });
            }
        });
    });

    });

    // Helper function to enable the submit button
    function __enable_submit_button(button) {
        button.prop('disabled', false);
    }
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel_works\admin_pos\resources\views/telegram/index.blade.php ENDPATH**/ ?>