<div class="modal-dialog modal-lg" role="document">
  <div class="modal-content">

    <?php echo Form::open(['url' => action('BusinessLocationController@update', [$location->id]), 'method' => 'PUT', 'id' => 'business_location_add_form', 'files' => true, 'enctype' => 'multipart/form-data' ]); ?>


    <?php echo Form::hidden('hidden_id', $location->id, ['id' => 'hidden_id']);; ?>

    <div class="modal-header">
      <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
      <h4 class="modal-title"><?php echo app('translator')->getFromJson( 'business.edit_business_location' ); ?></h4>
    </div>

    <div class="modal-body">
      <div class="row">
        <div class="col-sm-12">
          <div class="form-group">
            <?php echo Form::label('name', __( 'invoice.name' ) . ':*'); ?>

              <?php echo Form::text('name', $location->name, ['class' => 'form-control', 'required', 'placeholder' => __( 'invoice.name' ) ]);; ?>

          </div>
        </div>
        <div class="col-sm-12">
          <div class="form-group">
            <?php echo Form::label('receipt_name', __( 'Receipt Name' ) . ':'); ?>

              <?php echo Form::text('receipt_name', $location->receipt_name, ['class' => 'form-control', 'placeholder' => __( 'Receipt Name' ) ]);; ?>

          </div>
        </div>
        <div class="clearfix"></div>
        <div class="col-sm-6">
          <div class="form-group">
            <?php echo Form::label('location_id', __( 'lang_v1.location_id' ) . ':'); ?>

              <?php echo Form::text('location_id', $location->location_id, ['class' => 'form-control', 'placeholder' => __( 'lang_v1.location_id' ) ]);; ?>

          </div>
        </div>
        <div class="col-sm-6">
          <div class="form-group">
            <?php echo Form::label('landmark', __( 'business.landmark' ) . ':'); ?>

              <?php echo Form::text('landmark', $location->landmark, ['class' => 'form-control', 'placeholder' => __( 'business.landmark' ) ]);; ?>

          </div>
        </div>
        <div class="clearfix"></div>
        <div class="col-sm-6">
          <div class="form-group">
            <?php echo Form::label('city', __( 'business.city' ) . ':*'); ?>

              <?php echo Form::text('city', $location->city, ['class' => 'form-control', 'placeholder' => __( 'business.city'), 'required' ]);; ?>

          </div>
        </div>
        <div class="col-sm-6">
          <div class="form-group">
            <?php echo Form::label('zip_code', __( 'business.zip_code' ) . ':*'); ?>

              <?php echo Form::text('zip_code', $location->zip_code, ['class' => 'form-control', 'placeholder' => __( 'business.zip_code'), 'required' ]);; ?>

          </div>
        </div>
        <div class="clearfix"></div>
        <div class="col-sm-6">
          <div class="form-group">
            <?php echo Form::label('state', __( 'business.state' ) . ':*'); ?>

              <?php echo Form::text('state', $location->state, ['class' => 'form-control', 'placeholder' => __( 'business.state'), 'required' ]);; ?>

          </div>
        </div>
        <div class="col-sm-6">
          <div class="form-group">
            <?php echo Form::label('country', __( 'business.country' ) . ':*'); ?>

              <?php echo Form::text('country', $location->country, ['class' => 'form-control', 'placeholder' => __( 'business.country'), 'required' ]);; ?>

          </div>
        </div>
        <div class="clearfix"></div>
        <div class="col-sm-6">
          <div class="form-group">
            <?php echo Form::label('mobile', __( 'business.mobile' ) . ':'); ?>

            <?php echo Form::text('mobile', $location->mobile, ['class' => 'form-control', 'placeholder' => __( 'business.mobile')]);; ?>

          </div>
        </div>
        <div class="col-sm-6">
          <div class="form-group">
            <?php echo Form::label('alternate_number', __( 'business.alternate_number' ) . ':'); ?>

            <?php echo Form::text('alternate_number', $location->alternate_number, ['class' => 'form-control', 'placeholder' => __( 'business.alternate_number')]);; ?>

          </div>
        </div>
        <div class="clearfix"></div>
        <div class="col-sm-6">
          <div class="form-group">
            <?php echo Form::label('email', __( 'business.email' ) . ':'); ?>

            <?php echo Form::email('email', $location->email, ['class' => 'form-control', 'placeholder' => __( 'business.email')]);; ?>

          </div>
        </div>
        <div class="col-sm-6">
          <div class="form-group">
            <?php echo Form::label('website', __( 'lang_v1.website' ) . ':'); ?>

            <?php echo Form::text('website', $location->website, ['class' => 'form-control', 'placeholder' => __( 'lang_v1.website')]);; ?>

          </div>
        </div>
        <div class="clearfix"></div>
        <div class="col-sm-6">
          <div class="form-group">
            <?php echo Form::label('invoice_scheme_id', __('invoice.invoice_scheme') . ':*'); ?> <?php
                if(session('business.enable_tooltip')){
                    echo '<i class="fa fa-info-circle text-info hover-q no-print " aria-hidden="true" 
                    data-container="body" data-toggle="popover" data-placement="auto bottom" 
                    data-content="' . __('tooltip.invoice_scheme') . '" data-html="true" data-trigger="hover"></i>';
                }
                ?>
              <?php echo Form::select('invoice_scheme_id', $invoice_schemes, $location->invoice_scheme_id, ['class' => 'form-control', 'required',
              'placeholder' => __('messages.please_select')]);; ?>

          </div>
        </div>
        <div class="col-sm-6">
          <div class="form-group">
            <?php echo Form::label('invoice_layout_id', __('lang_v1.invoice_layout_for_pos') . ':*'); ?> <?php
                if(session('business.enable_tooltip')){
                    echo '<i class="fa fa-info-circle text-info hover-q no-print " aria-hidden="true" 
                    data-container="body" data-toggle="popover" data-placement="auto bottom" 
                    data-content="' . __('tooltip.invoice_layout') . '" data-html="true" data-trigger="hover"></i>';
                }
                ?>
              <?php echo Form::select('invoice_layout_id', $invoice_layouts,  $location->invoice_layout_id, ['class' => 'form-control', 'required',
              'placeholder' => __('messages.please_select')]);; ?>

          </div>
        </div>
        <div class="col-sm-6">
          <div class="form-group">
            <?php echo Form::label('sale_invoice_layout_id', __('lang_v1.invoice_layout_for_sale') . ':*'); ?> <?php
                if(session('business.enable_tooltip')){
                    echo '<i class="fa fa-info-circle text-info hover-q no-print " aria-hidden="true" 
                    data-container="body" data-toggle="popover" data-placement="auto bottom" 
                    data-content="' . __('tooltip.invoice_layout') . '" data-html="true" data-trigger="hover"></i>';
                }
                ?>
              <?php echo Form::select('sale_invoice_layout_id', $invoice_layouts,  $location->sale_invoice_layout_id, ['class' => 'form-control', 'required',
              'placeholder' => __('messages.please_select')]);; ?>

          </div>
        </div>
        <div class="col-sm-6">
          <div class="form-group">
            <?php echo Form::label('selling_price_group_id', __('lang_v1.default_selling_price_group') . ':'); ?> <?php
                if(session('business.enable_tooltip')){
                    echo '<i class="fa fa-info-circle text-info hover-q no-print " aria-hidden="true" 
                    data-container="body" data-toggle="popover" data-placement="auto bottom" 
                    data-content="' . __('lang_v1.location_price_group_help') . '" data-html="true" data-trigger="hover"></i>';
                }
                ?>
              <?php echo Form::select('selling_price_group_id', $price_groups, $location->selling_price_group_id, ['class' => 'form-control',
              'placeholder' => __('messages.please_select')]);; ?>

          </div>
        </div>
        <div class="clearfix"></div>
        <?php
          $custom_labels = json_decode(session('business.custom_labels'), true);
          $location_custom_field1 = !empty($custom_labels['location']['custom_field_1']) ? $custom_labels['location']['custom_field_1'] : __('lang_v1.location_custom_field1');
          $location_custom_field2 = !empty($custom_labels['location']['custom_field_2']) ? $custom_labels['location']['custom_field_2'] : __('lang_v1.location_custom_field2');
          $location_custom_field3 = !empty($custom_labels['location']['custom_field_3']) ? $custom_labels['location']['custom_field_3'] : __('lang_v1.location_custom_field3');
          $location_custom_field4 = !empty($custom_labels['location']['custom_field_4']) ? $custom_labels['location']['custom_field_4'] : __('lang_v1.location_custom_field4');
        ?>
        <div class="col-sm-3">
        <div class="form-group">
            <?php echo Form::label('custom_field1', $location_custom_field1 . ':'); ?>

            <?php echo Form::text('custom_field1', $location->custom_field1, ['class' => 'form-control', 
                'placeholder' => $location_custom_field1]);; ?>

        </div>
      </div>
      <div class="col-sm-3">
        <div class="form-group">
            <?php echo Form::label('custom_field2', $location_custom_field2 . ':'); ?>

            <?php echo Form::text('custom_field2', $location->custom_field2, ['class' => 'form-control', 
                'placeholder' => $location_custom_field2]);; ?>

        </div>
      </div>
      <div class="col-sm-3">
        <div class="form-group">
            <?php echo Form::label('custom_field3', $location_custom_field3 . ':'); ?>

            <?php echo Form::text('custom_field3', $location->custom_field3, ['class' => 'form-control', 
                'placeholder' => $location_custom_field3]);; ?>

        </div>
      </div>
      <div class="col-sm-3">
        <div class="form-group">
            <?php echo Form::label('custom_field4', $location_custom_field4 . ':'); ?>

            <?php echo Form::text('custom_field4', $location->custom_field4, ['class' => 'form-control', 
                'placeholder' => $location_custom_field4]);; ?>

        </div>
      </div>
      <div class="clearfix"></div>
      <div class="col-sm-3">
        <div class="form-group">
            <?php echo Form::label('stripe_pk', 'Stripe public key :'); ?>

            <?php echo Form::text('stripe_pk', $location->stripe_pk, ['class' => 'form-control', 
                'placeholder' => 'Stripe public key']);; ?>

        </div>
      </div>
      <div class="col-sm-3">
        <div class="form-group">
            <?php echo Form::label('stripe_sk', 'Stripe secret key :'); ?>

            <?php echo Form::text('stripe_sk', $location->stripe_sk, ['class' => 'form-control', 
                'placeholder' => 'Stripe secret key']);; ?>

        </div>
      </div>
      <div class="col-sm-3">
        <div class="form-group">
            <?php echo Form::label('lalamove_pk', 'Lalamove public key :'); ?>

            <?php echo Form::text('lalamove_pk', $location->lalamove_pk, ['class' => 'form-control', 
                'placeholder' => 'Lalamove public key']);; ?>

        </div>
      </div>
      <div class="col-sm-3">
        <div class="form-group">
            <?php echo Form::label('lalamove_sk', 'Lalamove secret key :'); ?>

            <?php echo Form::text('lalamove_sk', $location->lalamove_sk, ['class' => 'form-control', 
                'placeholder' => 'Lalamove secret key']);; ?>

        </div>
      </div>
      <div class="clearfix"></div>
      <div class="col-sm-3">
        <div class="form-group">
            <?php echo Form::label('smooch_public_key', 'Smooch public key :'); ?>

            <?php echo Form::text('smooch_public_key', $location->smooch_public_key, ['class' => 'form-control', 
                'placeholder' => 'Smooch public key']);; ?>

        </div>
      </div>
      <div class="col-sm-3">
        <div class="form-group">
            <?php echo Form::label('smooch_secret_key', 'Smooch secret key :'); ?>

            <?php echo Form::text('smooch_secret_key', $location->smooch_secret_key, ['class' => 'form-control', 
                'placeholder' => 'Smooch secret key']);; ?>

        </div>
      </div>
      <div class="clearfix"></div>
      <div class="col-sm-3">
        <div class="form-group">
            <?php echo Form::label('lunch_start_time', 'Lunch start time :'); ?>

            <?php echo Form::text('lunch_start_time',  $location->lunch_start_time, ['class' => 'form-control', 
                'placeholder' => '(e.g. 11:00:00)']);; ?>

        </div>
      </div>
      <div class="col-sm-3">
        <div class="form-group">
            <?php echo Form::label('lunch_end_time', 'Lunch end time :'); ?>

            <?php echo Form::text('lunch_end_time', $location->lunch_end_time, ['class' => 'form-control', 
                'placeholder' => '(e.g. 15:00:00)']);; ?>

        </div>
      </div>
      <div class="col-sm-3">
        <div class="form-group">
            <?php echo Form::label('dinner_start_time', 'Dinner start time :'); ?>

            <?php echo Form::text('dinner_start_time', $location->dinner_start_time, ['class' => 'form-control', 
                'placeholder' => '(e.g. 18:00:00)']);; ?>

        </div>
      </div>
      <div class="col-sm-3">
        <div class="form-group">
            <?php echo Form::label('dinner_end_time', 'Dinner end time :'); ?>

            <?php echo Form::text('dinner_end_time', $location->dinner_end_time, ['class' => 'form-control', 
                'placeholder' => '(e.g. 22:00:00)']);; ?>

        </div>
      </div>
      <div class="clearfix"></div>
      <div class="col-sm-3">
        <div class="form-group">
            <?php echo Form::label('uen', 'UEN :'); ?>

            <?php echo Form::text('uen', $location->uen, ['class' => 'form-control', 
                'placeholder' => '']);; ?>

        </div>
      </div>
      <div class="col-sm-3">
        <div class="form-group">
            <?php echo Form::label('peppol_secret_key', 'Peppol Secret Key :'); ?>

            <?php echo Form::text('peppol_secret_key', $location->peppol_secret_key, ['class' => 'form-control', 
                'placeholder' => '']);; ?>

        </div>
      </div>
      <div class="col-sm-3">
        <div class="form-group">
            <?php echo Form::label('peppol_api_key', 'Peppol API Key :'); ?>

            <?php echo Form::text('peppol_api_key', $location->peppol_api_key, ['class' => 'form-control', 
                'placeholder' => '']);; ?>

        </div>
      </div>
      <div class="col-sm-3">
        <div class="form-group">
            <?php echo Form::label('peppol_business_id', 'Peppol Business Id :'); ?>

            <?php echo Form::text('peppol_business_id', $location->peppol_business_id, ['class' => 'form-control', 
                'placeholder' => '']);; ?>

        </div>
      </div>
      <div class="col-sm-3">
        <div class="form-group">
            <?php echo Form::label('machine_id', 'Machine Id :'); ?>

            <?php echo Form::text('machine_id', $location->machine_id, ['class' => 'form-control', 
                'placeholder' => '']);; ?>

        </div>
      </div>
      <div class="col-sm-3">
        <div class="form-group">
          <?php echo Form::label('outlet_location_id', 'Outlet Location :'); ?>

          <?php echo Form::select('outlet_location_id', $outlets, $location->outlet_location_id, ['class' => 'form-control',
          'placeholder' => __('messages.please_select')]);; ?>

        </div>
      </div>
      <div class="col-sm-3">
        <div class="form-group">
            <?php echo Form::label('ftp_server', 'FTP Server :'); ?>

            <?php echo Form::text('ftp_server', $location->ftp_server, ['class' => 'form-control', 
                'placeholder' => '']);; ?>

        </div>
      </div>
      <div class="col-sm-3">
        <div class="form-group">
            <?php echo Form::label('ftp_password', 'FTP Password :'); ?>

            <?php echo Form::text('ftp_password', $location->ftp_password, ['class' => 'form-control', 
                'placeholder' => '']);; ?>

        </div>
      </div>
      <div class="col-sm-3">
        <div class="form-group">
            <?php echo Form::label('ftp_port', 'FTP Port :'); ?>

            <?php echo Form::text('ftp_port', $location->ftp_port, ['class' => 'form-control', 
                'placeholder' => '']);; ?>

        </div>
      </div>
      <div class="col-md-4 mt-15">
        <?php echo Form::label('is_ftp', 'Is SFTP :'); ?>

        <label class="radio-inline">
            <input type="radio" name="is_sftp" id="inlineRadio1" value="1" <?php if($location->is_sftp == 1): ?> checked <?php endif; ?>>
            <?php echo app('translator')->getFromJson('Yes'); ?>
        </label>
        <label class="radio-inline">
            <input type="radio" name="is_sftp" id="inlineRadio2" value="0" <?php if($location->is_sftp == 0): ?> checked <?php endif; ?>>
            <?php echo app('translator')->getFromJson('No'); ?>
        </label>
      </div>
      <div class="clearfix"></div>

      <div class="col-sm-3">
        <div class="form-group">
            <?php echo Form::label('mall_code', 'Mall Code :'); ?>

            <?php echo Form::text('mall_code', $location->mall_code, ['class' => 'form-control', 
                'placeholder' => '']);; ?>

        </div>
      </div>
      <div class="col-sm-3">
        <div class="form-group">
            <?php echo Form::label('tenant_code', 'Tenant Code :'); ?>

            <?php echo Form::text('tenant_code', $location->tenant_code, ['class' => 'form-control', 
                'placeholder' => '']);; ?>

        </div>
      </div>
      <div class="col-sm-3">
        <div class="form-group">
            
          <?php echo Form::label('day_start_time', 'Day Start Time :'); ?>

          <?php echo Form::select('day_start_time', $day_start_time_array, $location->day_start_time, ['class' => 'form-control',
          'placeholder' => __('messages.please_select')]);; ?>

        </div>
      </div>
      <div class="col-sm-3">
        <div class="form-group">
          <?php echo Form::label('Business Location Layout', 'Business Location Layout :'); ?>

          <?php echo Form::select('business_location_layout', $business_location_layout_arr, $location->business_location_layout, ['class' => 'form-control',
          'placeholder' => __('messages.please_select')]);; ?>

        </div>
      </div>
      <div class="col-sm-3">
        <div class="form-group">
            <?php echo Form::label('paynow_store_code', 'Paynow Store Code :'); ?>

            <?php echo Form::text('paynow_store_code', $location->paynow_store_code, ['class' => 'form-control', 
                'placeholder' => 'Paynow Store Code']);; ?>

        </div>
      </div>
      <div class="col-sm-3">
        <div class="form-group">
            <?php echo Form::label('paynow_merchant_no', 'Paynow Merchant Number :'); ?>

            <?php echo Form::text('paynow_merchant_no', $location->paynow_merchant_no, ['class' => 'form-control', 
                'placeholder' => 'Paynow Merchant Number']);; ?>

        </div>
      </div>
      <div class="col-sm-3">
        <div class="form-group">
            <?php echo Form::label('paynow_access_code', 'Paynow Access Code :'); ?>

            <?php echo Form::text('paynow_access_code', $location->paynow_access_code, ['class' => 'form-control', 
                'placeholder' => 'Paynow Access Code']);; ?>

        </div>
      </div>
      <div class="clearfix"></div>
      <div class="col-sm-3">
          <div class="form-group">
              <?php echo Form::label('enable_special_access_pin', 'Enable Special Access Pin:'); ?>

              <?php echo Form::checkbox('enable_special_access_pin', 1, $location->enable_special_access_pin, ['class' => 'form-check-input']); ?>

          </div>
      </div>
      <div class="col-sm-3" id="special_access_pin_container" <?php if(!$location->enable_special_access_pin): ?> style="display: none" <?php endif; ?>>
          <div class="form-group">
              <?php echo Form::label('special_access_pin', 'Special Access Pin :'); ?>

              <?php echo Form::number('special_access_pin', $location->special_access_pin, ['class' => 'form-control', 'placeholder' => 'Special Access Pin', 'minlength' => 4, 'maxlength' => 4, 'pattern' => '[0-9]{4}', 'title' => 'Please enter exact 4-digit numeric pin']); ?>

          </div>
      </div>
      <div class="clearfix"></div>
      <hr>
      <div class="col-sm-3">
        <div class="form-group">
          <?php echo Form::label('default_cash_float', __( 'POS Cash Float' ) . ':'); ?>

            <?php echo Form::text('default_cash_float', $location->default_cash_float, ['class' => 'form-control', 'placeholder' => __( 'POS Cash Float' ) ]);; ?>

        </div>
      </div>
      <div class="col-sm-4">
        <div class="form-group">
          <?php echo Form::label('cds', 'CDS' . ':'); ?>

          <?php echo Form::file('cds', ['id' => 'cds', 'accept' => 'image/*, video/*']); ?>

          <small>
              <p class="help-block">
                  <?php if ($__env->exists('components.business_location_document_help_text')) echo $__env->make('components.business_location_document_help_text', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
              </p>
          </small>
        </div>
      </div>
      <div class="col-sm-4">
        <div class="form-group">
          <?php echo Form::label('cds_logo_image', 'CDS Logo Image' . ':'); ?>

          <?php echo Form::file('cds_logo_image', ['id' => 'cds_logo_image', 'accept' => 'image/*']);; ?>

          <small>
              <p class="help-block">
                  <?php if ($__env->exists('components.business_location_image_help_text')) echo $__env->make('components.business_location_image_help_text', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
              </p>
          </small>
        </div>
      </div>
      <div class="clearfix"></div>
      <div class="col-sm-4">
        <div class="form-group">
          <?php echo Form::label('success_image', 'Success Image' . ':'); ?>

          <?php echo Form::file('success_image', ['id' => 'success_image', 'accept' => 'image/*']);; ?>

          <small>
              <p class="help-block">
                  <?php if ($__env->exists('components.business_location_image_help_text')) echo $__env->make('components.business_location_image_help_text', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
              </p>
          </small>
        </div>
      </div>
      <div class="col-sm-4">
        <div class="form-group">
          <?php echo Form::label('logo', 'Location Logo' . ':'); ?>

          <?php echo Form::file('logo', ['id' => 'logo', 'accept' => 'image/*']);; ?>

          <small>
              <p class="help-block">
                  <?php if ($__env->exists('components.business_location_image_help_text')) echo $__env->make('components.business_location_image_help_text', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
              </p>
          </small>
          <span id="error-message" class="text-danger"></span>
        </div>
      </div>
      <div class="clearfix"></div>
      <div class="col-sm-4">
        <div class="form-group">
          <label>
            <?php echo Form::checkbox('not_pin_authentication', 1, $location->not_pin_authentication, ['class' => 'input-icheck']);; ?> <strong>Not PIN authentication</strong>
          </label> <?php
                if(session('business.enable_tooltip')){
                    echo '<i class="fa fa-info-circle text-info hover-q no-print " aria-hidden="true" 
                    data-container="body" data-toggle="popover" data-placement="auto bottom" 
                    data-content="' . 'If checked, user no need any PIN authentication in POS system.' . '" data-html="true" data-trigger="hover"></i>';
                }
                ?>
        </div>
      </div>
      <div class="col-sm-4">
        <div class="form-group">
          <label>
            <?php echo Form::checkbox('kitchen_receipt_chinese_only', 1, $location->kitchen_receipt_chinese_only, ['class' => 'input-icheck']);; ?> <strong>Kitchen receipt chinese only</strong>
          </label> <?php
                if(session('business.enable_tooltip')){
                    echo '<i class="fa fa-info-circle text-info hover-q no-print " aria-hidden="true" 
                    data-container="body" data-toggle="popover" data-placement="auto bottom" 
                    data-content="' . 'If checked, kitchen receipt will only show chinese character.' . '" data-html="true" data-trigger="hover"></i>';
                }
                ?>
        </div>
      </div>
      <div class="col-sm-4">
        <div class="form-group">
          <label>
            <?php echo Form::checkbox('hide_delivery_for_web', 1, $location->hide_delivery_for_web, ['class' => 'input-icheck']);; ?> <strong>Hide Delivery Option for Web</strong>
          </label> <?php
                if(session('business.enable_tooltip')){
                    echo '<i class="fa fa-info-circle text-info hover-q no-print " aria-hidden="true" 
                    data-container="body" data-toggle="popover" data-placement="auto bottom" 
                    data-content="' . 'If checked, dropdown will hide the Delivery option.' . '" data-html="true" data-trigger="hover"></i>';
                }
                ?>
        </div>
      </div>
      <div class="clearfix"></div>
      <div class="col-sm-4">
        <div class="form-group">
          <label>
            <?php echo Form::checkbox('hide_pickup_for_web', 1, $location->hide_pickup_for_web, ['class' => 'input-icheck']);; ?> <strong>Hide Pickup Option for Web</strong>
          </label> <?php
                if(session('business.enable_tooltip')){
                    echo '<i class="fa fa-info-circle text-info hover-q no-print " aria-hidden="true" 
                    data-container="body" data-toggle="popover" data-placement="auto bottom" 
                    data-content="' . 'If checked, dropdown will hide the Pickup option.' . '" data-html="true" data-trigger="hover"></i>';
                }
                ?>
        </div>
      </div>
      <div class="col-sm-4">
        <div class="form-group">
          <label>
            <?php echo Form::checkbox('hide_cash_calculator', 1, $location->hide_cash_calculator, ['class' => 'input-icheck']);; ?> <strong>Hide Cash Calculator (Takeaway)</strong>
          </label> <?php
                if(session('business.enable_tooltip')){
                    echo '<i class="fa fa-info-circle text-info hover-q no-print " aria-hidden="true" 
                    data-container="body" data-toggle="popover" data-placement="auto bottom" 
                    data-content="' . 'If checked, cash calculator, card payment pop up will be hide in the POS.' . '" data-html="true" data-trigger="hover"></i>';
                }
                ?>
        </div>
      </div>
      <div class="col-sm-4">
        <div class="form-group">
          <label>
            <?php echo Form::checkbox('split_kitchen_receipt_by_item', 1, $location->split_kitchen_receipt_by_item, ['class' => 'input-icheck']);; ?> <strong>Split Kitchen Receipt by Item</strong>
          </label> <?php
                if(session('business.enable_tooltip')){
                    echo '<i class="fa fa-info-circle text-info hover-q no-print " aria-hidden="true" 
                    data-container="body" data-toggle="popover" data-placement="auto bottom" 
                    data-content="' . 'If checked, kitchen receipt will be split by item in the POS.' . '" data-html="true" data-trigger="hover"></i>';
                }
                ?>
        </div>
      </div>
      <div class="clearfix"></div>
      <div class="col-sm-4">
        <div class="form-group">
          <label>
            <?php echo Form::checkbox('lock_change_price', 1, $location->lock_change_price, ['class' => 'input-icheck']);; ?> <strong>Lock Change Price</strong>
          </label> <?php
                if(session('business.enable_tooltip')){
                    echo '<i class="fa fa-info-circle text-info hover-q no-print " aria-hidden="true" 
                    data-container="body" data-toggle="popover" data-placement="auto bottom" 
                    data-content="' . 'If checked, user cannot change the price in the POS.' . '" data-html="true" data-trigger="hover"></i>';
                }
                ?>
        </div>
      </div>
      <div class="col-sm-4">
        <div class="form-group">
          <label>
            <?php echo Form::checkbox('hide_price_btn_qr', 1, $location->hide_price_btn_qr, ['class' => 'input-icheck']);; ?> <strong>Hide Price Button (Digital Ordering)</strong>
          </label> <?php
                if(session('business.enable_tooltip')){
                    echo '<i class="fa fa-info-circle text-info hover-q no-print " aria-hidden="true" 
                    data-container="body" data-toggle="popover" data-placement="auto bottom" 
                    data-content="' . 'If checked, Hide Price on Add and Checkout Button (Digital Ordering)' . '" data-html="true" data-trigger="hover"></i>';
                }
                ?>
        </div>
      </div>
       <div class="col-sm-4">
        <div class="form-group">
          <label>
            <?php echo Form::checkbox('allow_lesser_cash_float_amount', 1, $location->allow_lesser_cash_float_amount, ['class' => 'input-icheck']);; ?> <strong>Allow Lesser Cash Float Amount</strong>
          </label> <?php
                if(session('business.enable_tooltip')){
                    echo '<i class="fa fa-info-circle text-info hover-q no-print " aria-hidden="true" 
                    data-container="body" data-toggle="popover" data-placement="auto bottom" 
                    data-content="' . 'If checked, Allow Lesser Cash Float Amount' . '" data-html="true" data-trigger="hover"></i>';
                }
                ?>
        </div>
      </div>
      <div class="clearfix"></div>
      <hr>
      <div class="col-sm-12"><strong><?php echo app('translator')->getFromJson('Modules'); ?>: </strong></br></br></div>
      <div class="col-sm-4">
        <div class="form-group">
          <label>
            <?php echo Form::checkbox('show_dine_in', 1, $location->show_dine_in, ['class' => 'input-icheck']);; ?> <strong>Show Dine In Module</strong>
          </label> <?php
                if(session('business.enable_tooltip')){
                    echo '<i class="fa fa-info-circle text-info hover-q no-print " aria-hidden="true" 
                    data-container="body" data-toggle="popover" data-placement="auto bottom" 
                    data-content="' . 'If checked, Dine In module will be show in the POS.' . '" data-html="true" data-trigger="hover"></i>';
                }
                ?>
        </div>
      </div>
      <div class="col-sm-4">
        <div class="form-group">
          <label>
            <?php echo Form::checkbox('show_takeaway', 1, $location->show_takeaway, ['class' => 'input-icheck']);; ?> <strong>Show Takeaway Module</strong>
          </label> <?php
                if(session('business.enable_tooltip')){
                    echo '<i class="fa fa-info-circle text-info hover-q no-print " aria-hidden="true" 
                    data-container="body" data-toggle="popover" data-placement="auto bottom" 
                    data-content="' . 'If checked, Takeaway module will be show in the POS.' . '" data-html="true" data-trigger="hover"></i>';
                }
                ?>
        </div>
      </div>
      <div class="col-sm-4">
        <div class="form-group">
          <label>
            <?php echo Form::checkbox('show_pickup', 1, $location->show_pickup, ['class' => 'input-icheck']);; ?> <strong>Show Pickup Module</strong>
          </label> <?php
                if(session('business.enable_tooltip')){
                    echo '<i class="fa fa-info-circle text-info hover-q no-print " aria-hidden="true" 
                    data-container="body" data-toggle="popover" data-placement="auto bottom" 
                    data-content="' . 'If checked, Pickup module will be show in the POS.' . '" data-html="true" data-trigger="hover"></i>';
                }
                ?>
        </div>
      </div>
      <div class="clearfix"></div>
      <div class="col-sm-4">
        <div class="form-group">
          <label>
            <?php echo Form::checkbox('show_delivery', 1, $location->show_delivery, ['class' => 'input-icheck']);; ?> <strong>Show Delivery Module</strong>
          </label> <?php
                if(session('business.enable_tooltip')){
                    echo '<i class="fa fa-info-circle text-info hover-q no-print " aria-hidden="true" 
                    data-container="body" data-toggle="popover" data-placement="auto bottom" 
                    data-content="' . 'If checked, Delivery module will be show in the POS.' . '" data-html="true" data-trigger="hover"></i>';
                }
                ?>
        </div>
      </div>
      <div class="col-sm-4">
        <div class="form-group">
          <label>
            <?php echo Form::checkbox('show_retail', 1, $location->show_retail, ['class' => 'input-icheck']);; ?> <strong>Show Retail Module</strong>
          </label> <?php
                if(session('business.enable_tooltip')){
                    echo '<i class="fa fa-info-circle text-info hover-q no-print " aria-hidden="true" 
                    data-container="body" data-toggle="popover" data-placement="auto bottom" 
                    data-content="' . 'If checked, Retail module will be show in the POS.' . '" data-html="true" data-trigger="hover"></i>';
                }
                ?>
        </div>
      </div>
      <div class="col-sm-4">
        <div class="form-group">
          <label>
            <?php echo Form::checkbox('show_kiosk', 1, $location->show_kiosk, ['class' => 'input-icheck']);; ?> <strong>Show Kiosk Module</strong>
          </label> <?php
                if(session('business.enable_tooltip')){
                    echo '<i class="fa fa-info-circle text-info hover-q no-print " aria-hidden="true" 
                    data-container="body" data-toggle="popover" data-placement="auto bottom" 
                    data-content="' . 'If checked, Kiosk module will be show in the POS.' . '" data-html="true" data-trigger="hover"></i>';
                }
                ?>
        </div>
      </div>
      <div class="col-sm-4">
        <div class="form-group">
          <label>
            <?php echo Form::checkbox('show_reservation', 1, $location->show_reservation, ['class' => 'input-icheck']);; ?> <strong>Show Reservation Module</strong>
          </label> <?php
                if(session('business.enable_tooltip')){
                    echo '<i class="fa fa-info-circle text-info hover-q no-print " aria-hidden="true" 
                    data-container="body" data-toggle="popover" data-placement="auto bottom" 
                    data-content="' . 'If checked, Reservation module will be show in the POS.' . '" data-html="true" data-trigger="hover"></i>';
                }
                ?>
        </div>
      </div>
      <div class="col-sm-4">
        <div class="form-group">
            <label>
                <?php echo Form::hidden('is_static_qr', 0); ?>

                <?php echo Form::checkbox('is_static_qr', 1, $location->is_static_qr, ['class' => 'input-icheck', 'id' => 'is_static_qr']);; ?> <strong>Static QR</strong>
            </label>
        </div>
    </div>
    <div class="col-sm-4">
        <div class="form-group" id="static_payment_mode_radios" style="<?php echo e($location->is_static_qr ? 'block' : 'none', false); ?>">
            <label>
                <?php echo Form::radio('qr_payment_type', 'payfirst', $location->qr_payment_type == 'payfirst', ['class' => 'input-icheck']);; ?> <strong>Pay First</strong>
            </label>
            <br>
            <label>
                <?php echo Form::radio('qr_payment_type', 'paylater', $location->qr_payment_type == 'paylater', ['class' => 'input-icheck']);; ?> <strong>Pay Later</strong>
            </label>
        </div>
    </div>

      <div class="clearfix"></div>
      <hr>
      <div class="col-sm-12"><strong><?php echo app('translator')->getFromJson('RazerPay Configurations'); ?>: </strong></br></br></div>
       <div class="col-sm-3">
        <div class="form-group">
            <?php echo Form::label('Razer Pay Verify Key', 'Razer Pay Verify Key :'); ?>

            <?php echo Form::text('razer_verify_key', $location->razer_verify_key, ['class' => 'form-control', 
                'placeholder' => 'Razer Pay Verify Key']);; ?>

        </div>
      </div>  
       <div class="col-sm-3">
        <div class="form-group">
            <?php echo Form::label('Razer Pay Secret Key', 'Razer Pay Secret Key :'); ?>

            <?php echo Form::text('razer_secret_key', $location->razer_secret_key, ['class' => 'form-control', 
                'placeholder' => 'Razer Pay Secret Key']);; ?>

        </div>
      </div>  
       <div class="col-sm-3">
        <div class="form-group">
            <?php echo Form::label('Razer Pay Merchant ID', 'Razer Pay Merchant ID :'); ?>

            <?php echo Form::text('razer_merchant_id', $location->razer_merchant_id, ['class' => 'form-control', 
                'placeholder' => 'Razer Pay Merchant ID']);; ?>

        </div>
      </div>  
       <div class="col-sm-3">
        <div class="form-group">
            <?php echo Form::label('Razer Pay Application code', 'Razer Pay Application code :'); ?>

            <?php echo Form::text('razer_application_code', $location->razer_application_code, ['class' => 'form-control', 
                'placeholder' => 'Razer Pay Application code']);; ?>

        </div>
      </div>  
       <div class="col-sm-3">
        <div class="form-group">
            <?php echo Form::label('Terminal MID', 'Terminal MID :'); ?>

            <?php echo Form::text('razer_terminal_mid', $location->razer_terminal_mid, ['class' => 'form-control', 
                'placeholder' => 'Terminal MID']);; ?>

        </div>
      </div>  
       <div class="col-sm-3">
        <div class="form-group">
            <?php echo Form::label('Store ID', 'Store ID :'); ?>

            <?php echo Form::text('razer_store_id', $location->razer_store_id, ['class' => 'form-control', 
                'placeholder' => 'Store ID']);; ?>

        </div>
      </div>    
      <div class="clearfix"></div>

      <hr>
      <div class="col-sm-12"> 
        <div class="form-group">
            <?php echo Form::label('paynow_number', 'Paynow Number :'); ?>

            <?php echo Form::text('paynow_number', $location->paynow_number, ['class' => 'form-control']);; ?>

        </div>
      </div>
      <div class="clearfix"></div>
      <div class="col-sm-12">
        <div class="form-group">
          <?php echo Form::label('featured_products', __('lang_v1.pos_screen_featured_products') . ':'); ?> <?php
                if(session('business.enable_tooltip')){
                    echo '<i class="fa fa-info-circle text-info hover-q no-print " aria-hidden="true" 
                    data-container="body" data-toggle="popover" data-placement="auto bottom" 
                    data-content="' . __('lang_v1.featured_products_help') . '" data-html="true" data-trigger="hover"></i>';
                }
                ?>
            <?php echo Form::select('featured_products[]', $featured_products, $location->featured_products, ['class' => 'form-control',
            'id' => 'featured_products', 'multiple']);; ?>

        </div>
      </div>
      <div class="clearfix"></div>
      <hr>
      <div class="col-sm-12"><strong>Platforms Integration </strong></br></br></div>
        <div class="col-sm-3">
          <div class="form-group">
              <?php echo Form::label('grabFood_ck', 'GrabFood client key :'); ?>

              <?php echo Form::text('grabFood_ck', $location->grabFood_ck, ['class' => 'form-control', 
                  'placeholder' => 'GrabFood client key']);; ?>

          </div>
        </div>
        <div class="col-sm-3">
          <div class="form-group">
              <?php echo Form::label('grabFood_sk', 'GrabFood secret key :'); ?>

              <?php echo Form::text('grabFood_sk', $location->grabFood_sk, ['class' => 'form-control', 
                  'placeholder' => 'GrabFood secret key']);; ?>

          </div>
        </div>
        <div class="col-sm-3">
          <div class="form-group">
              <?php echo Form::label('deliveroo_ck', 'Deliveroo client key :'); ?>

              <?php echo Form::text('deliveroo_ck', $location->deliveroo_ck, ['class' => 'form-control', 
                  'placeholder' => 'Deliveroo client key']);; ?>

          </div>
        </div>
        <div class="col-sm-3">
          <div class="form-group">
              <?php echo Form::label('deliveroo_sk', 'Deliveroo secret key :'); ?>

              <?php echo Form::text('deliveroo_sk', $location->deliveroo_ck, ['class' => 'form-control', 
                  'placeholder' => 'Deliveroo secret key']);; ?>

          </div>
        </div>
        <div class="col-sm-3">
          <div class="form-group">
              <?php echo Form::label('snatch_table_key_1', 'SnatchTable key 1 :'); ?>

              <?php echo Form::text('snatch_table_key_1', $location->snatch_table_key_1, ['class' => 'form-control', 
                  'placeholder' => 'SnatchTable key 1']);; ?>

          </div>
        </div>
        <div class="col-sm-3">
          <div class="form-group">
              <?php echo Form::label('snatch_table_key_2', 'SnatchTable key 2 :'); ?>

              <?php echo Form::text('snatch_table_key_2', $location->snatch_table_key_2, ['class' => 'form-control', 
                  'placeholder' => 'SnatchTable key 2']);; ?>

          </div>
        </div>
        <div class="col-sm-12">
          <h4 class="modal-title">Header & Footer</h4>
        </div>
          <!-- Header Field -->
          <div class="col-sm-12">
            <div class="form-group">
              <?php echo Form::label('receipt_header', __('Receipt Header') . ':'); ?>

              <?php echo Form::textarea('receipt_header', isset($location) ? $location->receipt_header : null, ['class' => 'form-control', 'placeholder' => __('Receipt Header'), 'rows' => 3, 'id' => 'header']); ?>

            </div>
          </div>
          <!-- Footer Field -->
          <div class="col-sm-12">
            <div class="form-group">
              <?php echo Form::label('receipt_footer', __('Receipt Footer') . ':'); ?>

              <?php echo Form::textarea('receipt_footer', isset($location) ? $location->receipt_footer : null, ['class' => 'form-control', 'placeholder' => __('Receipt Footer'), 'rows' => 3, 'id' => 'footer']); ?>

            </div>
        </div>
          <div class="clearfix"></div>
        <hr>
          <div class="col-sm-12">
            <strong><?php echo app('translator')->getFromJson('lang_v1.payment_options'); ?>: <?php
                if(session('business.enable_tooltip')){
                    echo '<i class="fa fa-info-circle text-info hover-q no-print " aria-hidden="true" 
                    data-container="body" data-toggle="popover" data-placement="auto bottom" 
                    data-content="' . __('lang_v1.payment_option_help') . '" data-html="true" data-trigger="hover"></i>';
                }
                ?></strong>
            <div class="form-group">
            <table class="table table-condensed table-striped">
              <thead>
                <tr>
                  <th class="text-center"><?php echo app('translator')->getFromJson('lang_v1.payment_method'); ?></th>
                  <th class="text-center"><?php echo app('translator')->getFromJson('lang_v1.enable'); ?></th>
                  <th class="text-center <?php if(empty($accounts)): ?> hide <?php endif; ?>"><?php echo app('translator')->getFromJson('Platform'); ?> <?php
                if(session('business.enable_tooltip')){
                    echo '<i class="fa fa-info-circle text-info hover-q no-print " aria-hidden="true" 
                    data-container="body" data-toggle="popover" data-placement="auto bottom" 
                    data-content="' . __('Platform') . '" data-html="true" data-trigger="hover"></i>';
                }
                ?></th>
                  <th class="text-center <?php if(empty($accounts)): ?> hide <?php endif; ?>"><?php echo app('translator')->getFromJson('lang_v1.default_accounts'); ?> <?php
                if(session('business.enable_tooltip')){
                    echo '<i class="fa fa-info-circle text-info hover-q no-print " aria-hidden="true" 
                    data-container="body" data-toggle="popover" data-placement="auto bottom" 
                    data-content="' . __('lang_v1.default_account_help') . '" data-html="true" data-trigger="hover"></i>';
                }
                ?></th>
                </tr>
              </thead>
              <tbody>
                <?php
                  $default_payment_accounts = !empty($location->default_payment_accounts) ?
                                      json_decode($location->default_payment_accounts, true) : [];
                ?>
                <?php $__currentLoopData = $payment_types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                    <td class="text-center"><?php echo e($value, false); ?></td>
                    <td class="text-center"><?php echo Form::checkbox('default_payment_accounts[' . $key . '][is_enabled]', 1, !empty($default_payment_accounts[$key]['is_enabled']));; ?></td>
                    <td class="text-center">
                      <?php echo Form::select('default_payment_accounts[' . $key . '][platform][]', $platforms, !empty($default_payment_accounts[$key]['platform']) ? $default_payment_accounts[$key]['platform'] : null, ['class' => 'platform form-control select2', 'multiple', 'style' => 'width: 300px;']); ?>

                  </td>

                    <td class="text-center <?php if(empty($accounts)): ?> hide <?php endif; ?>">
                      <?php echo Form::select('default_payment_accounts[' . $key . '][account]', $accounts, !empty($default_payment_accounts[$key]['account']) ? $default_payment_accounts[$key]['account'] : null, ['class' => 'form-control input-sm']);; ?>

                    </td>
                  </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </tbody>
            </table>
            </div>
          </div>
      </div>
    </div>

    <div class="modal-footer">
      <button type="submit" class="btn btn-primary submit_bs_form"><?php echo app('translator')->getFromJson( 'messages.save' ); ?></button>
      <button type="button" class="btn btn-default" data-dismiss="modal"><?php echo app('translator')->getFromJson( 'messages.close' ); ?></button>
    </div>

    <?php echo Form::close(); ?>


  </div><!-- /.modal-content -->
</div><!-- /.modal-dialog -->

<script>
      $('.platform').select2();
</script>

<script>
$(document).ready(function() {
  // When the file input changes
  $('#logo').on('change', function() {
    var fileInput = $(this)[0];
    console.log(fileInput);
    if (fileInput.files && fileInput.files[0]) {
      var file = fileInput.files[0];
      var fileSize = file.size; // in bytes
      var maxSizeKB = 100; // Maximum size in kilobytes (100KB)

      if (fileSize > maxSizeKB * 1024) {
        alert('The file size exceeds the maximum allowed limit of ' + maxSizeKB + 'KB.');
        // Clear the file input value to prevent submitting the oversized file
        $(this).val('');
      }
    }
  });
});
</script>
<script>
    $(document).ready(function() {
        var $enableSpecialAccessPinCheckbox = $('#enable_special_access_pin');
        var $specialAccessPinContainer = $('#special_access_pin_container');

        $enableSpecialAccessPinCheckbox.on('change', function() {
            if ($(this).is(':checked')) {
                $specialAccessPinContainer.show();
            } else {
                $specialAccessPinContainer.hide();
            }
        });

        // Trigger change event to initialize visibility based on the initial state of the checkbox
        $enableSpecialAccessPinCheckbox.change();

        tinymce.init({
          selector: '#header',
          menubar: false,
          plugins: 'lists link image charmap print preview hr anchor pagebreak',
          height: 150,  
          toolbar_mode: 'sliding',
        });

        tinymce.init({
          selector: '#footer',
          menubar: false,
          plugins: 'lists link image charmap print preview hr anchor pagebreak',
          height: 150,  
          toolbar_mode: 'sliding',
        });
    });
</script>
<script>
$(document).ready(function() {
        function toggleRadioButtons() {
            if ($('#is_static_qr').is(':checked')) {
                $('#static_payment_mode_radios').show();
            } else {
                $('#static_payment_mode_radios').hide();
            }
        }

        toggleRadioButtons();

        $('#is_static_qr').on('change', function() {
            toggleRadioButtons();
        });
    });
</script>

<?php /**PATH C:\xampp\htdocs\laravel_works\admin_pos\resources\views/business_location/edit.blade.php ENDPATH**/ ?>