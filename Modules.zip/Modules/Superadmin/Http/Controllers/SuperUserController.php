<?php

namespace Modules\Superadmin\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Http\Response;

use App\Business;
use App\User;
use DB;
use Redirect;
use Yajra\DataTables\Facades\DataTables;

class SuperUserController extends BaseController
{
    /**
     * Display a listing of the resource.
     * @return Response
     */
    public function index()
    {
        if (!auth()->user()->can('superadmin')) {
            abort(403, 'Unauthorized action.');
        }

        $all_businesses = Business::orderby('name')
                                ->pluck('name', 'id');
        $users = User::with('business', 'businesses')->get();
        return view('superadmin::superuser.index')
                ->with(compact('users', 'all_businesses'));
    }

    public function store(Request $request){
        if (!auth()->user()->can('superadmin')) {
            abort(403, 'Unauthorized action.');
        }
        $user_data = $request->only(['user_id', 'business_id']);
        if($request->only('business_id') == null){
            return Redirect::back()->with('error', 'Please select business account.');
        }
        $check_user = DB::table('business_user')->where('user_id', $user_data['user_id']);
        if($check_user){
            $check_user->delete();
        }
        foreach($user_data['business_id'] as $businesses){ 
            if($businesses != null){
                    DB::table('business_user')->insert(['user_id'=>$user_data['user_id'], 'business_id'=>$businesses]);
            }
        }
        User::where('id', $user_data['user_id'])->update(['user_type'=>'superuser']);
        return Redirect::back()->with('success', 'Super admin successfully added.');
    }

    public function getSpecialAccount(){
        if(request()->ajax()){
            $users =User::with('business', 'businesses')->where('user_type', 'superuser')->orderBy('id', 'asc');
        return DataTables::of($users)
                // ->addColumn(
                //     'action', function($row){
                //             $action = '<button data-href="'.action('DeliveryController@show', [$row->id]).'" class="btn btn-xs btn-primary view_delivery"><i class="glyphicon glyphicon"></i> View</button>
                //             &nbsp;
                //                 <button data-href="' . action('DeliveryController@edit',[$row->id]). '" class="btn btn-xs btn-info arrange_delivery"><i class="bi bi-truck"></i>Arrange Delivery</button>';
                //                 return $action;
                //             })
                ->editColumn('id', function ($row) {
                        return $row->id;
                })
                ->editColumn('name', function ($row) {
                    return $row->first_name.' '.$row->last_name;
                })
                ->editColumn('username', function ($row) {
                        return $row->username;
                })
                ->editColumn('business', function ($row) {
                    $string = $row->business->name;
                    foreach ($row->businesses as $value) {
                        if($string!=$value->name){
                            if($row->businesses->last() == $value)
                                return $string = $string.', '.$value->name;
                            else
                                $string = $value->name.', '.$string;
                        }
                    }
                    return $string;
                })
                // ->rawColumns(['action'])
                ->make(true);

        }
        return view('superadmin::superuser.index');
    }
}
