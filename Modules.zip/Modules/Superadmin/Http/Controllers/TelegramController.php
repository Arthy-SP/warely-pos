<?php

namespace Modules\Superadmin\Http\Controllers;

use App\BusinessLocation;
use App\Campaign;
use App\CampaignConfiguration;
use App\TelegramChannel;
use Illuminate\Http\Request;
use Illuminate\Http\Response;
use DB;
use Redirect;
use App\Business;
use Yajra\DataTables\Facades\DataTables;

class TelegramController extends BaseController
{
    /**
     * Display a listing of the resource.
     * @return Response
     */
    public function index()
    {
        if (!auth()->user()->can('superadmin')) {
            abort(403, 'Unauthorized action.');
        }
        if (request()->ajax()) {
            $telegram_channels = CampaignConfiguration::with('configured_locations', 'configured_channels', 'business', 'campaign')
                ->get();
            return DataTables::of($telegram_channels)
                ->addColumn(
                    'action',
                    '<button data-href ="{{action(\'\Modules\Superadmin\Http\Controllers\TelegramController@edit\',["id" => $id])}}" class="btn btn-primary btn-xs btn-modal" data-container=".campaign_configuration_modal"><i class="glyphicon glyphicon-edit"></i>
                        @lang( "messages.edit")
                        </button>
                        <button data-href ="{{action(\'\Modules\Superadmin\Http\Controllers\TelegramController@destroy\',[$id])}}" class="btn btn-danger btn-xs delete_campaign_configuration_button"> <i class="glyphicon glyphicon-trash"></i> @lang("messages.delete")</button>'
                )
                ->editColumn('id', function ($row) {
                    return $row->id;
                })
                ->editColumn('name', function ($row) {
                    return $row->name;
                })
                ->editColumn('business_name', function ($row) {
                    return $row->business->name;
                })
                ->editColumn('campaign_name', function ($row) {
                    return $row->campaign->name;
                })
                ->editColumn('location_name', function ($row) {
                    $name = '';
                    if ($row->configured_locations) {
                        foreach ($row->configured_locations as $value) {
                            if ($row->configured_locations->last() == $value) {
                                $name .= $value->name;
                            } else {
                                $name .= $value->name . ', ';
                            }
                        }
                        return $name;
                    } else {
                        return "";
                    }
                })
                ->editColumn('channel_name', function ($row) {
                    $channel_name = '';
                    if ($row->configured_channels) {
                        foreach ($row->configured_channels as $value) {
                            if ($row->configured_channels->last() == $value) {
                                $channel_name .= $value->name;
                            } else {
                                $channel_name .= $value->name . ', ';
                            }
                        }
                        return $channel_name;
                    } else {
                        return "";
                    }
                })
                ->rawColumns(['action'])
                ->make(true);
        }
        return view('superadmin::telegram.index');
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $business = Business::all();
        $business_id = request()->session()->get('user.business_id');
        $campaigns = [];
        $business_locations = [];
        $all_channels = TelegramChannel::orderby('name')->pluck('name', 'id');

        return view('superadmin::telegram.create')
            ->with(compact('business_id', 'business', 'all_channels', 'campaigns', 'business_locations'));
    }

    public function store(Request $request)
    {
        if (!auth()->user()->can('superadmin')) {
            abort(403, 'Unauthorized action.');
        }
        try {
            $input = $request->only(['name', 'business_id', 'campaign_id']);
            if (!CampaignConfiguration::where('business_id', $input['business_id'])->where('campaign_id', $input['campaign_id'])->exists()) {
                DB::beginTransaction();
                $campaign_configured = CampaignConfiguration::create($input);

                //Add campaign configuration locations
                $location_ids = $request->input('location_ids');
                if (!empty($location_ids)) {
                    $campaign_configured->configured_locations()->sync($location_ids);
                }

                //Add campaign configuration channel
                $channel_ids = $request->input('channel_ids');
                if (!empty($channel_ids)) {
                    $campaign_configured->configured_channels()->sync($channel_ids);
                }
                DB::commit();
                $output = [
                    'success' => 1,
                    'msg' => 'Successfully campaign configured.'
                ];
            } else {
                $output = [
                    'success' => 0,
                    'msg' => 'Campaign already configured.'
                ];
            }
        } catch (\Exception $e) {
            DB::rollBack();
            \Log::emergency("File:" . $e->getFile() . "Line:" . $e->getLine() . "Message:" . $e->getMessage());

            $output = [
                'success' => 0,
                'msg' => __("messages.something_went_wrong")
            ];
        }
        return $output;

    }

    public function edit($id)
    {
        if (!auth()->user()->can('superadmin')) {
            abort(403, 'Unauthorized action.');
        }
        if (request()->ajax()) {
            $business_id = request()->session()->get('user.business_id');
            $campaign_configuration = CampaignConfiguration::with('configured_locations', 'configured_channels', 'business', 'campaign')
                ->find($id);

            $business = Business::all();
            $campaigns = Campaign::where('business_id', $campaign_configuration->business_id)->pluck('name', 'id');

            //Get all business locations
            $business_locations = BusinessLocation::forDropdown($campaign_configuration->business_id);

            $all_channels = TelegramChannel::orderby('name')->pluck('name', 'id');

            return view('superadmin::telegram.edit')
                ->with(compact('campaign_configuration', 'business_id', 'business', 'all_channels', 'campaigns', 'business_locations'));
        }
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, $id)
    {
        if (!auth()->user()->can('superadmin')) {
            abort(403, 'Unauthorized action.');
        }
        try {
            $input = $request->only(['name', 'business_id', 'campaign_id']);
            $campaign_configured = CampaignConfiguration::find($id);

            if ($campaign_configured) {
                DB::beginTransaction();
                $campaign_configured->name = $input['name'];
                // $campaign_configured->campaign_id = $input['campaign_id'];

                $campaign_configured->save();

                //Add campaign configuration locations
                $location_ids = !empty($request->input('location_ids')) ? $request->input('location_ids') : [];
                $campaign_configured->configured_locations()->sync($location_ids);

                //Add campaign configuration channel
                $channel_ids = !empty($request->input('channel_ids')) ? $request->input('channel_ids') : [];
                $campaign_configured->configured_channels()->sync($channel_ids);

                DB::commit();
                $output = [
                    'success' => 1,
                    'msg' => 'Successfully updated.'
                ];
            } else {
                $output = [
                    'success' => 0,
                    'msg' => 'Campaign already configured.'
                ];
            }
        } catch (\Exception $e) {
            DB::rollBack();
            \Log::emergency("File:" . $e->getFile() . "Line:" . $e->getLine() . "Message:" . $e->getMessage());

            $output = [
                'success' => 0,
                'msg' => __("messages.something_went_wrong")
            ];
        }
        return $output;
    }

    public function destroy($id)
    {

        if (!auth()->user()->can('superadmin')) {
            abort(403, 'Unauthorized action.');
        }

        if (request()->ajax()) {
            try {
                $campaign_configuration = CampaignConfiguration::findOrFail($id);
                $campaign_configuration->delete();

                //Deleting configured locations
                $campaign_configuration->configured_locations()->detach();

                //Deleting configured channels
                $campaign_configuration->configured_channels()->detach();

                $output = [
                    'success' => true,
                    'msg' => __("superadmin::lang.deleted_success")
                ];
            } catch (\Exception $e) {
                \Log::emergency("File:" . $e->getFile() . "Line:" . $e->getLine() . "Message:" . $e->getMessage());

                $output = [
                    'success' => false,
                    'msg' => __("messages.something_went_wrong")
                ];
            }
            return $output;
        }
    }

    public function getCampaigns(Request $request)
    {
        if ($request->ajax() && !empty($request->input('business_id'))) {
            $business_id = $request->input('business_id');
            $campaigns = Campaign::where('business_id', $business_id)
                ->select(['name', 'id'])
                ->get();
            $html = '';
            if ($campaigns->isNotEmpty()) {
                foreach ($campaigns as $key => $campaign) {
                    $html .= '<option value="' . $campaign->id . '">' . $campaign->name . '</option>';
                }
            }else {
                $html = '<option selected="selected" value="">Please Select</option>';
            }
            echo $html;
            exit;
        }
    }

    public function getLocations(Request $request)
    {

        if ($request->ajax() && !empty($request->input('business_id'))) {
            $business_id = $request->input('business_id');

            //Get all business locations
            $business_locations = BusinessLocation::forDropdown($business_id);

            $html = '<option value"">None</option>';
            if (!empty($business_locations)) {
                foreach ($business_locations as $key => $location) {
                    $html .= '<option value="' . $key . '">' . $location . '</option>';
                }
            }
            echo $html;
            exit;
        }
    }
}