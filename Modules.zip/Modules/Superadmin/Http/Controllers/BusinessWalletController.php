<?php

namespace Modules\Superadmin\Http\Controllers;

use Illuminate\Support\Facades\DB;
use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Yajra\DataTables\Facades\DataTables;
use App\BusinessWallet;
use App\Business;
use \Carbon;    
use App\User;
use App\WalletTransaction;

class BusinessWalletController extends BaseController
{
    /**
     * Display a listing of the resource with filters and DataTables.
     * @param Request $request
     * @return Response
     */
    public function index(Request $request)
    {
        $date_filters['this_yr'] = [
            'start' => Carbon::today()->startOfYear()->toDateString(),
            'end' => Carbon::today()->endOfYear()->toDateString()
        ];
        $date_filters['this_month']['start'] = date('Y-m-01');
        $date_filters['this_month']['end'] = date('Y-m-t');
        $date_filters['this_week']['start'] = date('Y-m-d', strtotime('monday this week'));
        $date_filters['this_week']['end'] = date('Y-m-d', strtotime('sunday this week'));
    
        if ($request->ajax()) {
            $businesses = DB::table('business')
                ->leftJoin('business_wallets', 'business.id', '=', 'business_wallets.business_id')
                ->select(
                    'business.*', 
                    'business_wallets.balance as wallet_balance',
                    'business_wallets.updated_at as wallet_last_top_up_on',
                    'business_wallets.id as wallet_id',
                    'business_wallets.business_id as wallet_business_id'
                )
                ->whereNotNull('business_wallets.id'); 
    
            // Apply filters
            if ($request->balance_less_than) {
                $businesses->where('business_wallets.balance', '<', $request->balance_less_than);
            }
    
            if ($request->balance_greater_than) {
                $businesses->where('business_wallets.balance', '>', $request->balance_greater_than);
            }
    
            $businesses = $businesses->get();
    
            return DataTables::of($businesses)
                ->addColumn('wallet_business', function ($business) {
                    return $business->name; 
                })
                ->addColumn('wallet_contact', function ($business) {
                    return $business->contact_no; 
                })
                ->addColumn('wallet_business_mail', function ($business) {
                    return $business->email; 
                })
                ->addColumn('wallet_last_top_up_on', function ($business) {
                    return $business->wallet_last_top_up_on;
                })
                ->addColumn('wallet_balance', function ($business) {
                    return "$" . $business->wallet_balance; 
                })
                ->addColumn('wallet_action', function ($business) {
                    $topupButton = '<button class="btn btn-xs btn-danger wallet_topup_button" data-id="' . $business->wallet_id . '" business-id="' . $business->wallet_business_id . '"><i class="fas fa-money-bill-alt"></i>Top-up</button>';
                    $transactionUrl = action('\Modules\Superadmin\Http\Controllers\BusinessWalletController@transations', [
                        $business->wallet_id,
                        $business->wallet_business_id
                    ]);
                    $transactions = '<a href="' . $transactionUrl . '" class="btn btn-info btn-xs wallet_transactions"><i class="fa fa-exchange-alt"></i> Transactions</a>';
    
                    return $topupButton . '  ' . $transactions;
                })
                ->rawColumns(['wallet_action'])
                ->make(true);
        }
    
        // Render the index view with date filters
        return view('superadmin::business_wallet.index')->with(compact('date_filters'));
    }
    
    public function store(Request $request)
    {
        // Retrieve the wallet by ID and business ID
        $wallet = BusinessWallet::where('id', $request->input("wallet_id"))
        ->where('business_id', $request->input("business_id"))
        ->first();
        
        if ($wallet) {
            // Update the wallet balance and create a wallet transaction record
            $new_balance = $wallet->balance + $request->input("amount");
            $wallet->update(['balance' => $new_balance]);
            
            $transaction = new WalletTransaction();
            $transaction->wallet_id = $wallet->id;
            $transaction->business_id = $wallet->business_id;
            $transaction->amount = $request->input("amount");
            $transaction->available_balance = $new_balance;
            $transaction->payment_type = $request->input("payment_type");
            $transaction->transaction_date = $request->input("transaction_date");
            $transaction->service_type = 'Wallet Top up'; 
            $transaction->transaction_type = 'credit'; 
            $transaction->description = $request->input("description");
            $transaction->save();
        }
        
        // Return a JSON response indicating success
        return response()->json([
            'success' => true,
            'message' => __("Top up added sucessfully..")
        ]);
    }

    /**
     * Display the wallet transactions for a specific wallet.
     * @param Request $request
     * @param int $wallet_id
     * @param int $business_id
     * @return Response
     */
    public function transations(Request $request, $wallet_id, $business_id)
    {
        // Check if the request is AJAX to load data for DataTables
        if ($request->ajax()) {
            // Retrieve the transactions for the specific wallet and business
            $transations = WalletTransaction::where('wallet_id', $wallet_id)
                                             ->where('business_id', $business_id)
                                             ->select("amount", "transaction_date", "service_type", "transaction_type", "payment_type", "available_balance", "description", "phone");
    
            return DataTables::of($transations)->make(true);
        }
    
        // Render the transactions view
        return view('superadmin::business_wallet.business_transations', [
            'wallet_id' => $wallet_id,
            'business_id' => $business_id
        ]);
    }

    /**
     * Display the recent transactions for the current week.
     * @param Request $request
     * @return Response
     */
    public function recentTransations(Request $request)
    {
        // Check if the request is AJAX to load data for DataTables
        if ($request->ajax()) {
            $startOfWeek = Carbon::now()->startOfWeek()->format('Y-m-d');
            $endOfWeek = Carbon::now()->endOfWeek()->format('Y-m-d');
            
            // Get transactions for the current week
            $transactions = WalletTransaction::select("amount", "transaction_date", "service_type", "transaction_type", "payment_type", "available_balance", "description")
            ->whereBetween('transaction_date', [$startOfWeek, $endOfWeek])
            ->get();

            return DataTables::of($transactions)->make(true);
        }
        
        // Render the recent transactions view
        return view('superadmin::business_wallet.recent_transations');
    }

    /**
     * Summarize wallet top-ups, deductions, and remaining balances.
     * @param Request $request
     * @return Response
     */
    public function summeries(Request $request)
    {
        // Get start and end dates for filtering
        $start_date = $request->get('start');
        $end_date = $request->get('end');
        
        // Calculate total top-ups, deductions, and remaining balance
        $walletTopUp = WalletTransaction::whereRaw('DATE(created_at) BETWEEN ? AND ?', [$start_date, $end_date])
        ->where('service_type', 'Wallet Top up')
        ->where('transaction_type', 'credit')
        ->select(DB::raw('SUM(amount) as total'))
        ->first()
        ->total;
        
        $walletDeductions = WalletTransaction::whereRaw('DATE(created_at) BETWEEN ? AND ?', [$start_date, $end_date])
        ->where('transaction_type', 'debit')
        ->select(DB::raw('SUM(amount) as total'))
        ->first()
        ->total;
        
        $remainingBalance = BusinessWallet::where('status', 'active')  
        ->selectRaw('IFNULL(SUM(balance), 0) as total_remaining_balance')  
        ->first()
        ->total_remaining_balance;    
        
        // Return a JSON response with the calculated summaries
        return response()->json([
            'total_wallet_topup_amount' => $walletTopUp ? $walletTopUp : 0.00,
            'total_remaining_balance' => $remainingBalance ? $remainingBalance : 0.00,
            'total_deductions' => $walletDeductions ? $walletDeductions : 0.00,
        ]);
    }
}
