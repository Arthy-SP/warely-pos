<?php
namespace Modules\Superadmin\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Yajra\DataTables\Facades\DataTables;
use App\ServiceChargesSettings;
use App\System;

class ServiceChargesSettingsController extends BaseController
{
    /**
     * Display a listing of the resource.
     * Handles AJAX request to fetch data for DataTables.
     * @param Request $request
     * @return Response
     */
    public function index(Request $request)
    {     
        if ($request->ajax()) {
            // Fetch service charge settings data for DataTables
            $data = ServiceChargesSettings::select("id", 'sms_otp_charge', 'promotional_sms_charge', 'whatsapp_message_charge', 'email_charge', 'country');
            return DataTables::of($data)
                ->addIndexColumn()
                ->addColumn(
                    'action',
                    function ($row) use ($data) {
                        // Action buttons for edit and delete functionality
                        $html = '<div class="btn-group">
                                    <button type="button" class="btn btn-info dropdown-toggle btn-xs" data-toggle="dropdown" aria-expanded="false">'
                                    . __("messages.actions") . 
                                    '<span class="caret"></span><span class="sr-only">Toggle Dropdown</span></button>
                                    <ul class="dropdown-menu dropdown-menu-left" role="menu">';
                            $html .= '<li class ="service_charges_edit" data-id="'.$row->id.'"><a href="#"><i class="glyphicon glyphicon-edit"></i> ' . __("messages.edit") . '</a></li>';
                            $html .= '<li class = "service_charges_delete" data-id="'.$row->id.'"><a href="#" class="delete-product"><i class="fa fa-trash"></i> ' . __("messages.delete") . '</a></li>';
                        $html .= '</ul></div>';
                        return $html;
                    }
                )
                ->rawColumns(['action'])
                ->make(true);
        }

        // Fetch wallet settings based on key
        $activeTab = $request->input("wallet_setting");
        $walletBalanceSettings = System::whereIn('key', ['message_limit', 'min_balance_alert'])->get();
        $walletBalanceSettings = $walletBalanceSettings->keyBy('key'); 
        
        // Return view with necessary variables
        return view('superadmin::service_charges_settings.index')->with(compact("walletBalanceSettings", "activeTab"));
    }

    /**
     * Store a newly created resource in storage.
     * Validate input and create service charges settings.
     * @param Request $request
     * @return \Illuminate\Http\JsonResponse
     */
    public function store(Request $request)
    {
        // Validate incoming request data
        $validatedData = $request->validate([
            'sms_otp_charge' => 'required|numeric|min:0',
            'promotional_sms_charge' => 'nullable|numeric|min:0',
            'whatsapp_message_charge' => 'nullable|numeric|min:0',
            'email_charge' => 'nullable|numeric|min:0',
            'country' => 'required|string|max:255',
            'country_code' => 'required|string|max:255',
        ]);

        // Check if the setting for the specified country already exists
        $existingSetting = ServiceChargesSettings::where('country', $validatedData['country'])->first();

        if ($existingSetting) {
            return response()->json([
                'success' => false,
                'message' => __("Service charges settings for this country already exist.")
            ]);
        }

        // Create a new service charge setting
        ServiceChargesSettings::create($validatedData);

        return response()->json([
            'success' => true,
            'message' => __("Service charges settings added successfully.")
        ]);
    }

    /**
     * Show the form for editing the specified resource.
     * @param int $id
     * @return \Illuminate\Http\JsonResponse
     */
    public function edit($id)
    {
        // Find the service charge by ID for editing
        $serviceCharge = ServiceChargesSettings::findOrFail($id);
        return response()->json($serviceCharge);
    }

    /**
     * Update the specified resource in storage.
     * Validate input and update service charges settings.
     * @param Request $request, int $id
     * @return \Illuminate\Http\JsonResponse
     */
    public function update(Request $request, $id)
    {
        // Validate incoming request data
        $validatedData = $request->validate([
            'sms_otp_charge' => 'required|numeric|min:0',
            'promotional_sms_charge' => 'nullable|numeric|min:0',
            'whatsapp_message_charge' => 'nullable|numeric|min:0',
            'email_charge' => 'nullable|numeric|min:0',
            'country' => 'required|string|max:255',
            'country_code' => 'required|string|max:255',
        ]);

        // Find the service charge by ID
        $serviceCharge = ServiceChargesSettings::findOrFail($id);

        // Check if the setting for the specified country already exists for a different ID
        $existingSetting = ServiceChargesSettings::where('country', $validatedData['country'])
                                                ->where('id', '!=', $id)
                                                ->first();

        if ($existingSetting) {
            return response()->json([
                'success' => false,
                'message' => __("Service charges settings for this country already exist.")
            ]);
        }

        // Update the service charge with validated data
        $serviceCharge->update($validatedData);
        
        return response()->json([
            'success' => true,
            'message' => __("Service charges settings updated successfully.")
        ]);
    }

    /**
     * Remove the specified resource from storage.
     * @param int $id
     * @return \Illuminate\Http\JsonResponse
     */
    public function destroy($id)
    {
        // Find the service charge by ID for deletion
        $serviceCharge = ServiceChargesSettings::find($id);

        if (!$serviceCharge) {
            return response()->json([            
                'success' => false,
                'message' => 'Service charge not found'], 404);
        }

        // Delete the service charge
        $serviceCharge->delete();

        return response()->json(['success' => true, 'message' => 'Service charge deleted successfully'], 200);
    }
}
