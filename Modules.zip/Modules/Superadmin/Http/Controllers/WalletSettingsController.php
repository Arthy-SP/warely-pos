<?php
namespace Modules\Superadmin\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\System;

class WalletSettingsController extends Controller
{
    /**
     * Store or update wallet settings in the system.
     * Handles form submission and saves the `min_balance_alert` and `message_limit` settings.
     * 
     * @param Request $request
     * @return \Illuminate\Http\RedirectResponse
     */
    public function store(Request $request)
    {
        $validatedData = $request->validate([
            'min_balance_alert' => 'required',  
            'message_limit' => 'required|numeric', 
        ]);

        foreach ($validatedData as $key => $value) {
            if ($request->input('id')) {
                System::updateOrCreate(
                    ['key' => $key, 'id' => $request->input('id')],  
                    ['value' => $value] 
                );
            } else {
                System::create([
                    'key' => $key,  
                    'value' => $value,  
                ]);
            }
        }

        // Redirect to the service charges settings page with a success message and wallet settings tab active
        return redirect()->route('service_charges_settings.index', ['wallet_setting' => 'true'])
            ->with('success', __("Wallet settings added successfully."));
    }
}
