@extends('layouts.app')
@section('title', __('superadmin::lang.superadmin') . ' | ' . __('superadmin::lang.communicator'))

@section('content')
@include('superadmin::layouts.nav')
<!-- Content Header (Page header) -->
<section class="content-header">
    <h1>@lang('superadmin::lang.telegram_campaign_configuration')</h1>
</section>

<!-- Main content -->
<section class="content">
        
        @if (\Session::has('success'))
            <div class="alert alert-success alert-dismissible" role="alert">
                <ul>
                    <li>{!! \Session::get('success') !!}</li>
                </ul>
            </div>
        @elseif(\Session::has('error'))
            <div class="alert alert-error alert-dismissible" role="alert">
                <ul>
                    <li>{!! \Session::get('error') !!}</li>
                </ul>
            </div>
        @endif
        <div class="box box-solid">
            <div class="box-body">
                <div class="row">
                    @component('components.widget', ['class' => 'box-primary', 'title' => 'All Configured Campaigns'])
                        @slot('tool')                                
                            <div class="box-tools">
                                <button type="button" class="btn btn-block btn-primary btn-modal" 
                                data-href="{{action('\Modules\Superadmin\Http\Controllers\TelegramController@create')}}" 
                                data-container=".campaign_configuration_modal">
                                <i class="fa fa-plus"></i> Add New Configration </button>
                            </div>
                        @endslot
                        <div class="table-responsive">
                            <table class="table table-bordered table-striped" id="campaign_configuration_table">
                                <thead>
                                    <tr>
                                        <th> # </th>
                                        <th> Name </th>
                                        <th> Business </th>
                                        <th> Campaign </th>
                                        <th> Location </th>
                                        <th> Channel </th>
                                        <th>@lang('messages.action')</th>
                                    </tr>
                                </thead>
                            </table>
                        </div>
                    @endcomponent
                </div>
            </div>
        </div>  
        
        <div class="modal fade campaign_configuration_modal" tabindex="-1" role="dialog" 
    	    aria-labelledby="gridSystemModalLabel">
        </div>
</section>

    <!-- /.content -->
@stop
@section('javascript')

<script type="text/javascript">

    function get_campaigns(){
     let b_id = $('#business_id').val();
     $.ajax({
        method: 'POST',
        url: '/superadmin/business/get_campaigns',
        dataType: 'html',
        data:{business_id: b_id}, 
        success: function (result) {
            if(result){
                $('#campaign_id').html(result);
            }
        }
     });
    }

    function get_locations(){
     let business_id = $('#business_id').val();
     console.log(business_id);
     $.ajax({
        method: 'POST',
        url: '/superadmin/business/get_locations',
        dataType: 'html',
        data:{business_id}, 
        success: function (result) {
            if(result){
                $('#location_id').html(result);
            }
        }
     });
    }

    $(document).ready(function() {
        setTimeout(function() {
            $(".alert").alert('close');
        }, 2000);
        campaign_configuration_table = $('#campaign_configuration_table').DataTable({
            processing: true,
            serverSide: true,
            ajax: {
                url: "{{action('\Modules\Superadmin\Http\Controllers\TelegramController@index')}}",
            },
            aaSorting: [[0, 'asc']],
            columns: [
                { data: 'id', name: 'id' },
                { data: 'name', name: 'name' },
                { data: 'business_name', name: 'business_name' },
                { data: 'campaign_name', name: 'campaign_name' },
                { data: 'location_name', name: 'location_name' },
                { data: 'channel_name', name: 'channel_name' },
                { data: 'action', name: 'action' }
            ]
        });
    });

    $('.campaign_configuration_modal').on('shown.bs.modal', function() {
        $('.campaign_configuration_modal')
            .find('.select2')
            .each(function() {
                __select2($(this));
            });
    });

    $(document).on('submit', 'form#telegram_channel_add_form', function(e) {
        e.preventDefault();
        var form = $(this);
        var data = form.serialize();

        $.ajax({
            method: 'POST',
            url: $(this).attr('action'),
            dataType: 'json',
            data: data,
            beforeSend: function(xhr) {
                __disable_submit_button(form.find('button[type="submit"]'));
            },
            success: function(result) {
                console.log("jbdks", result);
                if (result.success == true) {
                    $('div.campaign_configuration_modal').modal('hide');
                    toastr.success(result.msg);
                    campaign_configuration_table.ajax.reload();
                } else {
                    $('div.campaign_configuration_modal').modal('hide');
                    toastr.error(result.msg);
                }
            },
        });
    });

    $(document).on('submit', 'form#telegram_channel_update_form', function(e) {
        e.preventDefault();
        var form = $(this);
        var data = form.serialize();

        $.ajax({
            method: 'PATCH',
            url: $(this).attr('action'),
            dataType: 'json',
            data: data,
            beforeSend: function(xhr) {
                __disable_submit_button(form.find('button[type="submit"]'));
            },
            success: function(result) {
                if (result.success == true) {
                    $('div.campaign_configuration_modal').modal('hide');
                    toastr.success(result.msg);
                    campaign_configuration_table.ajax.reload();
                } else {
                    $('div.campaign_configuration_modal').modal('hide');
                    toastr.error(result.msg);
                }
            },
        });
    });

    $(document).on('click', 'button.delete_campaign_configuration_button', function() {
        swal({
            title: LANG.sure,
            text: LANG.confirm_campaign_configuration,
            icon: 'warning',
            buttons: true,
            dangerMode: true,
        }).then(willDelete => {
            if (willDelete) {
                var href = $(this).data('href');
                var data = $(this).serialize();

                $.ajax({
                    method: 'DELETE',
                    url: href,
                    dataType: 'json',
                    data: data,
                    success: function(result) {
                        if (result.success == true) {
                            toastr.success(result.msg);
                            campaign_configuration_table.ajax.reload();
                        } else {
                            toastr.error(result.msg);
                        }
                    },
                });
            }
        });
    });

    $(document).on('change', '#business_id', function(){
        get_campaigns();
        get_locations();
    });

</script>
@endsection