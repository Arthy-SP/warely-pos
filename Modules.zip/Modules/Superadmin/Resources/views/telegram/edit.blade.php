
<div class="modal-dialog" role="document">
  <div class="modal-content">

    {!! Form::open(['url' => action('\Modules\Superadmin\Http\Controllers\TelegramController@update', [$campaign_configuration->id]), 'method' => 'post', 'id' => 'telegram_channel_update_form' ]) !!}

    <div class="modal-header">
      <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
      <h4 class="modal-title">@lang( 'superadmin::lang.update_channel' )</h4>
    </div>

    <div class="modal-body">
      <div class="form-group col-md-12">
        {!! Form::label('name', __( 'superadmin::lang.name' ) . ':*') !!}
          {!! Form::text('name', $campaign_configuration->name, ['class' => 'form-control', 'required', 'placeholder' => __( 'superadmin::lang.channel_name' )]); !!}
      </div>

      <div class="form-group col-md-6">
        {!! Form::label('Business', __( 'superadmin::lang.business' ) . ':*') !!}
          {!! Form::select('business_id', $business->pluck('name', 'id'), $campaign_configuration->business_id, ['class' => 'form-control select2', 'placeholder' => __('superadmin::lang.please_select'), 'id'=>'business_id', 'required', 'disabled']); !!}
      </div>
      
      <div class="form-group col-md-6">
        {!! Form::label('Campaign', __( 'superadmin::lang.campaign' ) . ':*') !!}
        {!! Form::select('campaign_id', $campaigns, $campaign_configuration->campaign_id, ['class' => 'form-control select2', 'id' => 'campaign_id', 'required', 'disabled']); !!}
      </div>

      <div class="form-group col-md-12">
        {!! Form::label('Business Location', __( 'superadmin::lang.business_location' ) . ':*') !!}
        {!! Form::select('location_ids[]', $business_locations, $campaign_configuration->configured_locations->pluck('id'), ['class' => 'form-control select2', 'id'=>'location_id', 'required', 'multiple' => 'multiple']); !!}
      </div>

      <div class="form-group col-md-12">
        {!! Form::label('Channel/Group', __( 'superadmin::lang.channel_or_group' ) . ':*') !!}
        {!! Form::select('channel_ids[]', $all_channels, $campaign_configuration->configured_channels->pluck('id'), ['class' => 'form-control select2', 'id' => 'channel_id', 'required', 'multiple' => 'multiple']); !!}
      </div>
    </div>

    <div class="modal-footer">
      <button type="submit" class="btn btn-primary">@lang( 'messages.update' )</button>
      <button type="button" class="btn btn-default" data-dismiss="modal">@lang( 'messages.close' )</button>
    </div>

    {!! Form::close() !!}

  </div><!-- /.modal-content -->
</div><!-- /.modal-dialog -->

<!-- <script>
  $(document).ready(function(){
    $(document).on('submit', 'form#telegram_channel_update_form', function(e) {
        e.preventDefault();
        var form = $(this);
        var data = form.serialize();

        $.ajax({
            method: 'PATCH',
            url: $(this).attr('action'),
            dataType: 'json',
            data: data,
            beforeSend: function(xhr) {
                __disable_submit_button(form.find('button[type="submit"]'));
            },
            success: function(result) {
                if (result.success == true) {
                    $('div.telegram_channel_modal').modal('hide');
                    toastr.success(result.msg);
                    telegram_channel_table.ajax.reload();
                } else {
                    $('div.telegram_channel_modal').modal('hide');
                    toastr.error(result.msg);
                }
            },
        });
    });
  });
</script> -->