
<div class="modal-dialog" role="document">
  <div class="modal-content">

    {!! Form::open(['url' => action('\Modules\Superadmin\Http\Controllers\TelegramController@store'), 'method' => 'post', 'id' => 'telegram_channel_add_form' ]) !!}

    <div class="modal-header">
      <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
      <h4 class="modal-title">@lang( 'superadmin::lang.create_new_configuration' )</h4>
    </div>

    <div class="modal-body">
      <div class="form-group col-md-12">
        {!! Form::label('name', __( 'superadmin::lang.name' ) . ':*') !!}
          {!! Form::text('name', null, ['class' => 'form-control', 'required', 'placeholder' => __( 'superadmin::lang.channel_name' )]); !!}
      </div>

      <div class="form-group col-md-6">
        {!! Form::label('Business', __( 'superadmin::lang.business' ) . ':*') !!}
          {!! Form::select('business_id', $business->pluck('name', 'id'), null, ['class' => 'form-control select2', 'placeholder' => __('superadmin::lang.please_select'), 'id'=>'business_id', 'required']); !!}
      </div>
      
      <div class="form-group col-md-6">
        {!! Form::label('Campaign', __( 'superadmin::lang.campaign' ) . ':*') !!}
        {!! Form::select('campaign_id', $campaigns, null, ['class' => 'form-control select2', 'placeholder' => __('superadmin::lang.please_select'), 'id' => 'campaign_id', 'required']); !!}
      </div>

      <div class="form-group col-md-12">
        {!! Form::label('Business Location', __( 'superadmin::lang.business_location' ) . ':*') !!}
        {!! Form::select('location_ids[]', $business_locations, null, ['class' => 'form-control select2', 'id'=>'location_id', 'required', 'multiple' => 'multiple']); !!}
      </div>

      <div class="form-group col-md-12">
        {!! Form::label('Channel/Group', __( 'superadmin::lang.channel_or_group' ) . ':*') !!}
        {!! Form::select('channel_ids[]', $all_channels, null, ['class' => 'form-control select2', 'id' => 'channel_id', 'required', 'multiple' => 'multiple']); !!}
      </div>
    </div>

    <div class="modal-footer">
      <button type="submit" class="btn btn-primary">@lang( 'messages.save' )</button>
      <button type="button" class="btn btn-default" data-dismiss="modal">@lang( 'messages.close' )</button>
    </div>

    {!! Form::close() !!}

  </div><!-- /.modal-content -->
</div><!-- /.modal-dialog -->