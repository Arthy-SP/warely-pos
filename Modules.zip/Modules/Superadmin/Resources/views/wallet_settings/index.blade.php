<div class="form-container">
    {!! Form::open(['url' => action('\Modules\Superadmin\Http\Controllers\WalletSettingsController@store'), 'method' => 'post', 'id' => 'manage_wallet_form']) !!}
        
        <div class="form-header">
            <h4 class="form-title">@lang('wallet.manage_wallet')</h4>
        </div>

        <div class="form-body">
            <div class="form-group">
                {!! Form::label('min_balance_alert', __('Alert wallet balance is less than') . ':') !!}
                {!! Form::number('min_balance_alert', isset($walletBalanceSettings['min_balance_alert']) ? $walletBalanceSettings['min_balance_alert']->value : null, ['class' => 'form-control', 'placeholder' => __('Alert wallet balance is less than'),  'step' => '0.01']) !!}
            </div>

            <div class="form-group">
                {!! Form::label('message_limit', __('Allow message up to') . ':') !!}
                {!! Form::number('message_limit', isset($walletBalanceSettings['message_limit']) ? $walletBalanceSettings['message_limit']->value : null, ['class' => 'form-control', 'placeholder' => __('Allow message up to'),  'step' => '0.01']) !!}
            </div>

            <input type="hidden" name="id" id="wallet_id" value="{{ isset($walletBalanceSettings['message_limit']) ? $walletBalanceSettings['message_limit']->id : '' }}">
            <!-- Hidden input to determine if this is an update or creation -->
        </div>

        <div class="form-footer">
            <button type="submit" class="btn btn-primary">@lang('messages.save')</button>
            <button type="button" class="btn btn-default" onclick="window.history.back();">@lang('messages.close')</button>
        </div>

    {!! Form::close() !!}
</div>
