@extends('layouts.app')
@section('title', __('Service setting'))

@section('content')
@include('superadmin::layouts.nav')
<section class="content">

    <div class="row">
        <div class="col-md-12">
            <div class="nav-tabs-custom">
                <ul class="nav nav-tabs">
                    <li class="{{$activeTab ? '' : 'active'}}">
                        <a href="#charges_settings" data-toggle="tab" aria-expanded="{{$activeTab ? 'false' : 'true'}}"><i class="fa fa-bolt" aria-hidden="true"></i> @lang('lang_v1.charges_settings')</a>
                    </li>
                  
                    <li class="{{$activeTab ? 'active' : ''}}">
                        <a href="#wallet_settings" data-toggle="tab" aria-expanded="{{$activeTab ? 'true' : 'false'}}"><i class="fa fa-wallet" aria-hidden="true"></i> @lang('lang_v1.wallet_settings')</a>
                    </li>
                </ul>
                <div class="tab-content">
                    <div class="tab-pane {{$activeTab ? '' : 'active'}}" id="charges_settings">   
                    <div class="col-sm-12 text-right">
                        <button type="button" class="btn btn-primary" id="add_new_county_service_charge"><i class="fa fa-plus"></i> @lang('messages.add')</button>
                    </div>
                    <br><br>    
                    @include('superadmin::service_charges_settings.country_service_charges')
                    </div>
                     <div class="tab-pane {{$activeTab ? 'active' : ''}}" id="wallet_settings">
                     @include('superadmin::wallet_settings.index')
                    </div> 
                </div>
            </div>
        </div>
    </div>
<div class="modal fade product_modal" tabindex="-1" role="dialog" 
    aria-labelledby="gridSystemModalLabel">
</div>

<div class="modal fade" id="view_service_charges_settings" tabindex="-1" role="dialog" 
    aria-labelledby="gridSystemModalLabel">
</div>

@include('superadmin::service_charges_settings.create')
@include('superadmin::service_charges_settings.edit')
@include('superadmin::service_charges_settings.delete')

</section>

@endsection

@section('javascript')
    <script src="{{ asset('js/product.js?v=' . $asset_v) }}"></script>
    <script src="{{ asset('js/opening_stock.js?v=' . $asset_v) }}"></script>
    <script type="text/javascript">
        //load service_charges_settings datatables
        $(document).ready(function () {
            var activeTab = @json($activeTab);
            if (activeTab) {
                toastr.success("Wallet setting added sucessfully.");
                service_charges_settings.ajax.reload();
            } 
            var service_charges_settings = $('#service_charges_settings').DataTable({
                processing: true,
                serverSide: true,
                aaSorting: [[0, 'asc']], 
                scrollY: "75vh",
                scrollX: true,
                scrollCollapse: true,
                ajax: {
                    url: "/superadmin/service_charges_settings",
                    type: "GET" 
                },
                columns: [
                { data: 'country', name: 'country' },
                { 
                    data: 'sms_otp_charge', name: 'sms_otp_charge',
                    render: function(data, type, row) {
                        return __currency_trans_from_en(data);
                    }
                },
                { 
                    data: 'promotional_sms_charge',
                    name: 'promotional_sms_charge',
                    render: function(data, type, row) {
                        return __currency_trans_from_en(data);
                    }    
                },
                { 
                    data: 'whatsapp_message_charge',
                    name: 'whatsapp_message_charge',
                        render: function(data, type, row) {
                        return __currency_trans_from_en(data);
                    }
                },
                { 
                    data: 'email_charge', 
                    name: 'email_charge',
                    render: function(data, type, row) {
                        return __currency_trans_from_en(data);
                    }
                },
                { data: 'action', name: 'action', orderable: false, searchable: false }
                ]
            });

        //show add new service charges popup model
        $('button#add_new_county_service_charge').click( function(){
            $('div#add_new_county_service_charge_modal').modal('show');
        });

        //add new service charges submit form
        $('#add_new_county_service_charge_form').submit(function (e) {
            e.preventDefault(); 
            var submitButton = $(this).find('button[type="submit"]');
            submitButton.prop('disabled', true);
            var formData = $(this).serialize();
            $.ajax({
                url: $(this).attr('action'),
                method: $(this).attr('method'),
                data: formData,
                success: function (response) {             
                    if(response.success == true){
                        $('div#add_new_county_service_charge_modal').modal('hide');
                        toastr.success(response.message);
                        service_charges_settings.ajax.reload();
                        $('#add_new_county_service_charge_form')[0].reset();
                    } else {
                        toastr.error(response.message);
                    }
                },
                error: function (xhr, status, error) {
                    toastr.error(error);
                },
                complete: function () {
                submitButton.prop('disabled', false);
            }
            });
        });

        //On update service charges then load data
        $(document).on('click', '.service_charges_edit', function (e) {
            e.preventDefault();
            var id = $(this).attr('data-id');
            $.ajax({
                url: '/superadmin/service_charges_settings/' + id,
                method: 'GET',
                success: function (data) {
                    console.log(data)
                    var formActionUrl = '/superadmin/service_charges_settings/update/' + data.id;
                    $('#edit_county_service_charge_form').attr('action', formActionUrl);
                    $('#edit_county_service_charge_modal').find('input[name="sms_otp_charge"]').val(data.sms_otp_charge);
                    $('#edit_county_service_charge_modal').find('input[name="promotional_sms_charge"]').val(data.promotional_sms_charge);
                    $('#edit_county_service_charge_modal').find('input[name="whatsapp_message_charge"]').val(data.whatsapp_message_charge);
                    $('#edit_county_service_charge_modal').find('input[name="email_charge"]').val(data.email_charge);
                    $('#edit_county_service_charge_modal').find('input[name="country_code"]').val(data.country_code);
                    $.getJSON('{{ asset('countries.json') }}', function(countriesData) {
                        var countrySelect = $('#country-select');
                        countrySelect.empty(); 
                        countrySelect.append('<option value="">@lang('Select Country')</option>'); 
                        
                        $.each(countriesData, function(index, country) {
                            var option = $('<option></option>')
                                .val(country.name)
                                .text(country.name)
                                .attr('dialcode', country.dialCode);
                            
                            countrySelect.append(option);
                        });
                        countrySelect.val(data.country);
                        countrySelect.change(function() {
                            var selectedOption = $(this).find('option:selected');
                            var dialCode = selectedOption.attr('dialcode');
                            $('#edit_country_code').val(dialCode);
                        });
                    });

                    $('#edit_county_service_charge_modal').modal('show');
                },
                error: function (xhr, status, error) {
                    toastr.error(error);
                }
            });
        });

        //Delete charges process
        $(document).on('click', '.service_charges_delete', function (e) {
            const id = $(this).attr('data-id');
            const formActionUrl = '/superadmin/service_charges_settings/delete/' + id;
            $('#delete_service_charge_form').attr('action', formActionUrl);
            $('#delete_service_charge_modal').modal('show');
        });

        //delete service charges submit form
        $('#delete_service_charge_form').on('submit', function(event) {
                event.preventDefault(); 
                var formAction = $(this).attr('action');
                var formData = $(this).serialize(); 
                console.log(formAction)
                $.ajax({
                    url: formAction,
                    type: 'DELETE',
                    data: formData,
                    success: function(response) {
                        console.log(response)
                    if(response.success == true){
                        $('#delete_service_charge_modal').modal('hide');
                        toastr.success(response.message);
                        service_charges_settings.ajax.reload();
                        $('#delete_service_charge_form')[0].reset();
                    } else {
                        toastr.error(response.message);
                    }
                    },
                    error: function(xhr) {
                        toastr.error('An error occurred while deleting the service charge.');
                    }
                });
        });

        //update service charges submit form
        $('#edit_county_service_charge_form').submit(function (e) {
            var actionUrl = $(this).attr('action');
            console.log("actionUrl");
            console.log(actionUrl);
            e.preventDefault(); 
            var submitButton = $(this).find('button[type="submit"]');
            submitButton.prop('disabled', true);
            var formData = $(this).serialize();

            var actionUrl = $(this).attr('action');
            $.ajax({
            url: actionUrl,
            method: "PUT",
                data: formData,
                success: function (response) {
                    
                    if(response.success == true){
                        $('div#edit_county_service_charge_modal').modal('hide');
                        toastr.success(response.message);
                        service_charges_settings.ajax.reload();
                        $('#add_new_county_service_charge_form')[0].reset();
                    } else {
                        toastr.error(response.message);
                    }
                },
                error: function (xhr, status, error) {
                    toastr.error(error);
                },
                complete: function () {
                submitButton.prop('disabled', false);
            }
            });
        });

});
    </script>
@endsection