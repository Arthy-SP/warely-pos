<div class="modal fade" id="add_new_county_service_charge_modal" tabindex="-1" role="dialog" 
    	aria-labelledby="gridSystemModalLabel">
	<div class="modal-dialog" role="document">
		<div class="modal-content">

		{!! Form::open(['url' => action('\Modules\Superadmin\Http\Controllers\ServiceChargesSettingsController@store'), 'method' => 'post', 'id' => 'add_new_county_service_charge_form' ]) !!}
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
				<h4 class="modal-title">@lang('billing.add_new_service_charges')</h4>
				</div>

				<div class="modal-body">
					<div class="row">
                        <div class="col-sm-6">
                            <div class="form-group">
                                {!! Form::label('sms_otp_charge', __('SMS OTP Charge') . ':*') !!}
                                {!! Form::number('sms_otp_charge', null, ['class' => 'form-control', 'placeholder' => __('Enter SMS OTP Charge'), 'step' => '0.01']) !!}
                            </div>
                        </div>

                        <div class="col-sm-6">
                            <div class="form-group">
                                {!! Form::label('promotional_sms_charge', __('Promotional SMS Charge') . ':') !!}
                                {!! Form::number('promotional_sms_charge', null, ['class' => 'form-control', 'placeholder' => __('Enter Promotional SMS Charge'), 'step' => '0.01']) !!}
                            </div>
                        </div>

                        <div class="col-sm-6">
                            <div class="form-group">
                                {!! Form::label('whatsapp_message_charge', __('WhatsApp Message Charge') . ':') !!}
                                {!! Form::number('whatsapp_message_charge', null, ['class' => 'form-control', 'placeholder' => __('Enter WhatsApp Message Charge'), 'step' => '0.01']) !!}
                            </div>
                        </div>

                        <div class="col-sm-6">
                            <div class="form-group">
                                {!! Form::label('email_charge', __('Email Charge') . ':') !!}
                                {!! Form::number('email_charge', null, ['class' => 'form-control', 'placeholder' => __('Enter Email Charge'), 'step' => '0.01']) !!}
                            </div>
                        </div>

                        <div class="col-sm-6">
                        <div class="form-group">
                            {!! Form::label('country', __('Country') . ':') !!}
                            {!! Form::select('country', [], null, ['class' => 'form-control', 'placeholder' => __('Select Country')]) !!}
                        </div>
                    </div>
                    {!! Form::hidden('country_code', null, ['id' => 'country_code']) !!}

				    </div>
				</div>

				<div class="modal-footer">
				<button type="submit" class="btn btn-primary">@lang( 'messages.save' )</button>
				<button type="button" class="btn btn-default" data-dismiss="modal">@lang( 'messages.close' )</button>
			</div>

		{!! Form::close() !!}

		</div>
	</div>
</div>

<script>
    document.addEventListener('DOMContentLoaded', function () {
        const publicPath = `{{ asset('countries.json') }}`;

        fetch(publicPath)
            .then(response => response.json())
            .then(data => {
                const countrySelect = document.querySelector('select[name="country"]');
                const countryCodeInput = document.querySelector('input[name="country_code"]');
                data.forEach(country => {
                    const option = document.createElement('option');
                    option.value = country.name; 
                    option.textContent = country.name; 
                    option.dataset.dialcode = country.dialCode; 
                    countrySelect.appendChild(option);
                });
                    // Add event listener to update hidden country_code when a country is selected
                countrySelect.addEventListener('change', function () {
                const selectedOption = countrySelect.options[countrySelect.selectedIndex];
                const dialCode = selectedOption.dataset.dialcode; 
                countryCodeInput.value = dialCode || ''; 
            });
            })
            .catch(error => console.error('Error fetching countries:', error));
    });
</script>

