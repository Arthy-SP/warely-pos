<div class="modal fade" id="edit_county_service_charge_modal" tabindex="-1" role="dialog" aria-labelledby="gridSystemModalLabel">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
        {!! Form::model($serviceCharge, ['url' => '/superadmin/service_charges_settings/update/' .$serviceCharge->id, 'method' => 'PUT','id' => 'edit_county_service_charge_form']) !!}   
             <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                    <h4 class="modal-title">@lang('billing.edit_service_charges')</h4>
                </div>

                <div class="modal-body">
                    <div class="row">
                        <div class="col-sm-6">
                            <div class="form-group">
                                {!! Form::label('sms_otp_charge', __('SMS OTP Charge') . ':') !!}
                                {!! Form::number('sms_otp_charge', $serviceCharge->sms_otp_charge, ['class' => 'form-control', 'placeholder' => __('Enter SMS OTP Charge'), 'step' => '0.01']) !!}
                            </div>
                        </div>

                        <div class="col-sm-6">
                            <div class="form-group">
                                {!! Form::label('promotional_sms_charge', __('Promotional SMS Charge') . ':') !!}
                                {!! Form::number('promotional_sms_charge', $serviceCharge->promotional_sms_charge, ['class' => 'form-control', 'placeholder' => __('Enter Promotional SMS Charge'), 'step' => '0.01']) !!}
                            </div>
                        </div>

                        <div class="col-sm-6">
                            <div class="form-group">
                                {!! Form::label('whatsapp_message_charge', __('WhatsApp Message Charge') . ':') !!}
                                {!! Form::number('whatsapp_message_charge', $serviceCharge->whatsapp_message_charge, ['class' => 'form-control', 'placeholder' => __('Enter WhatsApp Message Charge'), 'step' => '0.01']) !!}
                            </div>
                        </div>

                        <div class="col-sm-6">
                            <div class="form-group">
                                {!! Form::label('email_charge', __('Email Charge') . ':') !!}
                                {!! Form::number('email_charge', $serviceCharge->email_charge, ['class' => 'form-control', 'placeholder' => __('Enter Email Charge'), 'step' => '0.01']) !!}
                            </div>
                        </div>

                        <div class="col-sm-6">
                            <div class="form-group">
                                {!! Form::label('country', __('Country') . ':') !!}
                                {!! Form::select('country', [], $serviceCharge->country, [
                                    'class' => 'form-control',
                                    'placeholder' => __('Select Country'),
                                    'id' => 'country-select'
                                ]) !!}
                            </div>
                        </div>
                        {!! Form::hidden('country_code', null, ['id' => 'edit_country_code']) !!}


                    </div>
                </div>

                <div class="modal-footer">
                    <button type="submit" class="btn btn-primary">@lang('messages.update')</button>
                    <button type="button" class="btn btn-default" data-dismiss="modal">@lang('messages.close')</button>
                </div>

            {!! Form::close() !!}
        </div>
    </div>
</div>
<script>





</script>
