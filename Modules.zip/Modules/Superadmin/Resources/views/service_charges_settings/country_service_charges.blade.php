<div class="table-responsive">
    <table class="table table-bordered table-striped ajax_view hide-footer" id="service_charges_settings">
        <thead>
            <tr>
                <th>@lang('billing.country')</th>
                <th>@lang('billing.sms_otp_charge')</th>               
                <th>@lang('billing.promotional_sms_charge')</th>
                <th>@lang('billing.whatsapp_message_charge')</th>
                <th>@lang('billing.email_charge')</th>
                <th>@lang('billing.action')</th>
            </tr>
        </thead>
    </table>
</div>