@extends('layouts.app')
@section('title', __('superadmin::lang.superadmin') . ' | ' . __('superadmin::lang.communicator'))

@section('content')
@include('superadmin::layouts.nav')
<!-- Content Header (Page header) -->
<section class="content-header">
    <h1>@lang('superadmin::lang.superuser')</h1>
</section>

<!-- Main content -->
<section class="content">
        @if (\Session::has('success'))
            <div class="alert alert-success alert-dismissible" role="alert">
                <ul>
                    <li>{!! \Session::get('success') !!}</li>
                </ul>
            </div>
        @elseif(\Session::has('error'))
            <div class="alert alert-error alert-dismissible" role="alert">
                <ul>
                    <li>{!! \Session::get('error') !!}</li>
                </ul>
            </div>
        @endif
        <div class="box box-solid">
            <div class="box-body">
                <div class="row">
                    <div class="col-sm-12">

                        <table class="table mb-0">
                            <thead>
                              <tr>
                                <th scope="col">User Name</th>
                                <th scope="col">Businesses</th>
                                <th scope="col">Action</th>
                              </tr>
                            </thead>
                            <tbody>
                            {{-- @foreach ($users as $user) --}}
                            {!! Form::open(['url' => action('\Modules\Superadmin\Http\Controllers\SuperUserController@store'), 'method' => 'post', 'id' => 'super_user_register_form','files' => true ]) !!}
                                    <tr>
                                        <td>
                                            <div class="input-group">
                                                {!! Form::select('user_id', $users->pluck('username', 'id'), null, ['class' => 'form-control select2', 'id' => 'user_id' ]); !!}
                                            </div>
                                        </td>
                                        <td>
                                            <div class="input-group">
                                                {!! Form::select('business_id[]', $all_businesses, null, ['class' => 'form-control select2', 'multiple' => 'multiple']); !!}
                                            </div>
                                        </td>
                                        <td>{!! Form::submit(__('messages.submit'), ['class' => 'btn btn-sm btn-success pull-center']) !!}</td>
                                    </tr>
                                    {!! Form::close() !!}
                                </tbody>
                        </table>
                    </div>
                </div>
            </div>    
        </div>
        <div class="box box-solid">
            <div class="box-body">
                <div class="row">
                    <div class="box-body">
                    @can('superadmin')
                        <div class="table-responsive">
                            <table class="table table-bordered table-striped" id="superadmin_special_account_business_table">
                                <thead>
                                    <tr>
                                        <th>
                                            @lang('#')
                                        </th>
                                        <th>@lang( 'Name' )</th>
                                        <th>@lang('User Name')</th>
                                        <th>@lang('business.email')</th>
                                        <th>@lang('Business')</th>
                                    </tr>
                                </thead>
                            </table>
                        </div>
                    @endcan
                </div>
                
                <div class="col-md-12">
                    <div class="form-group">
                        {{-- {!! Form::submit(__('messages.submit'), ['class' => 'btn btn-success pull-right']) !!} --}}
                        {{-- {!! Form::close() !!} --}}
                    </div>
                </div>
            </div>
        </div>  
    </div>    
</section>
    <!-- /.content -->
@stop
@section('javascript')

<script type="text/javascript">
	$(document).ready(function() {
        setTimeout(function() {
            $(".alert").alert('close');
        }, 2000);
        superadmin_business_table = $('#superadmin_special_account_business_table').DataTable({
            processing: true,
            serverSide: true,
            ajax: {
                url: "{{action('\Modules\Superadmin\Http\Controllers\SuperUserController@getSpecialAccount')}}",
            },
            aaSorting: [[0, 'desc']],
            columns: [
                { data: 'id', name: 'id' },
                { data: 'name', name: 'name' },
                { data: 'username', name: 'username', searchable: false},
                { data: 'email', name: 'email' },
                { data: 'business', name: 'business' },
                // { data: 'action', name: 'action', orderable: false, searchable: false },
            ]
        });

        // $('#package_id, #subscription_status, #is_active, #last_transaction_date, #no_transaction_since').change( function(){
        //     superadmin_business_table.ajax.reload();
        // });
    });
    // $(document).on('click', 'a.delete_business_confirmation', function(e){
    //     e.preventDefault();
    //     swal({
    //         title: LANG.sure,
    //         text: "Once deleted, you will not be able to recover this business!",
    //         icon: "warning",
    //         buttons: true,
    //         dangerMode: true,
    //     }).then((confirmed) => {
    //         if (confirmed) {
    //             window.location.href = $(this).attr('href');
    //         }
    //     });
    // });
</script>
@endsection