@extends('layouts.app')
@section('content')
@include('superadmin::layouts.nav')
	<section class="content-header">
	</section>
    <section class="content">
        <div class="row">
			<div class="col-md-12 col-xs-12">
				<div class="btn-group pull-right" data-toggle="buttons">
					<label class="btn btn-info active">
						<input type="radio" name="date-filter"
						data-start="{{ date('Y-m-d') }}" 
						data-end="{{ date('Y-m-d') }}"
						checked> {{ __('home.today') }}
					</label>
					<label class="btn btn-info">
						<input type="radio" name="date-filter"
						data-start="{{ $date_filters['this_week']['start']}}" 
						data-end="{{ $date_filters['this_week']['end']}}"
						> {{ __('home.this_week') }}
					</label>
					<label class="btn btn-info">
						<input type="radio" name="date-filter"
						data-start="{{ $date_filters['this_month']['start']}}" 
						data-end="{{ $date_filters['this_month']['end']}}"
						> {{ __('home.this_month') }}
					</label>
					<label class="btn btn-info">
						<input type="radio" name="date-filter" 
						data-start="{{ $date_filters['this_yr']['start']}}" 
						data-end="{{ $date_filters['this_yr']['end']}}" 
						> {{ __('superadmin::lang.this_year') }}
					</label>
				</div>
			</div>
		</div>
	    <br/>
		<div class="row">
	        <div class="col-lg-4 col-xs-6">
	          <!-- small box -->
	          <div class="small-box bg-aqua">
	            <div class="inner">
	              <h3><span class="wallet_remaining_balance">&nbsp;</span></h3>

	              <p>@lang('wallet.wallet_remaining_balance')</p>
	            </div>
	            <div class="icon">
	              <i class="fa fa-refresh"></i>
	            </div>
	          </div>
	        </div>
	        <div class="col-lg-4 col-xs-6">
	          <!-- small box -->
	          <div class="small-box bg-yellow">
	            <div class="inner">
	              <h3><span class="wallet_topup_amount">&nbsp;</span></h3>
	              <p>@lang('wallet.wallet_total_top_up_amount')</p>
	            </div>
	            <div class="icon">
	              <i class="ion ion-person-add"></i>
	            </div>
	          </div>
	        </div>
	        <div class="col-lg-4 col-xs-6">
	          <!-- small box -->
	          <div class="small-box bg-red">
	            <div class="inner">
	              <h3><span class="total_deductions">&nbsp;</span></h3>
	              <p>@lang('wallet.wallet_total_deduct')</p>
	            </div>
	            <div class="icon">
	              <i class="ion ion-pie-graph"></i>
	            </div>
	          </div>
	        </div>
    	</div>
        <div class="row">
            <div class="col-md-12">
                @component('components.filters', ['title' => __('report.filters')])
                    <div class="col-md-3">
                        <div class="form-group">
                            {!! Form::label('balance_less_than', __('Balance less than') . ':') !!}
                            {!! Form::number('balance_less_than', null, ['placeholder' => __('amount'), 'class' => 'wallet_balance_filter form-control']); !!}
                        </div>
                    </div>
                
                    <div class="col-md-3">
                        <div class="form-group">
                            {!! Form::label('balance_grater_than', __('Balance grater than') . ':') !!}
                            {!! Form::number('balance_grater_than', null, ['placeholder' => __('amount'), 'class' => 'wallet_balance_filter form-control']); !!}
                        </div>
                    </div>
                    
                @endcomponent
            </div>
        </div>

        <div class="row">
            @component('components.widget', ['class' => 'box-primary', 'title' => __( 'wallet.wallet_details' )])
            <div class="col-md-12 col-xs-12">
				<div class="btn-group pull-right">
                <a href="{{ action('\Modules\Superadmin\Http\Controllers\BusinessWalletController@recentTransations') }}" class="btn btn-info btn-xs wallet_transactions">
                    <i class="fa fa-exchange-alt"></i> Transactions
                </a>
				</div>
			</div>
            <br><br>
                <div class="table-responsive">
                    <table class="table table-bordered table-striped" id="busniess_wallet_table">
                        <thead>
                            <tr>
                                <th>@lang( 'wallet.wallet_business' )</th>
                                <th>@lang( 'wallet.wallet_Contact' )</th>
                                <th>@lang( 'wallet.wallet_business_mail' )</th>
                                <th>@lang( 'wallet.wallet_last_top_up_on' )</th>
                                <th>@lang( 'wallet.wallet_total_balance' )</th>
                                <th>@lang( 'wallet.wallet_action' )</th>
                            </tr>
                        </thead>
                    </table>
                </div>
            @endcomponent
            <div class="modal fade user_modal" tabindex="-1" role="dialog" 
                aria-labelledby="gridSystemModalLabel">
            </div>
        </div>
    </section>
    @include('superadmin::business_wallet.create')

<!-- /.content -->
@stop

@section('javascript')
<script type="text/javascript">
  $(document).ready(function() {
        /*Date filter */
        var start = $('input[name="date-filter"]:checked').data('start');
		var end = $('input[name="date-filter"]:checked').data('end');
        /*Date filter load dataTable*/
		update_statistics(start, end);
		$(document).on('change', 'input[name="date-filter"]', function(){
			var start = $('input[name="date-filter"]:checked').data('start');
			var end = $('input[name="date-filter"]:checked').data('end');
			update_statistics(start, end);
		});

        function update_statistics(start, end) {
            var data = { start: start, end: end };
            var loader = '<i class="fa fa-refresh fa-spin fa-fw"></i>';
            $('.wallet_remaining_balance').html(loader);
            $('.wallet_topup_amount').html(loader);

            $.ajax({
                method: "GET",
                url: '/superadmin/wallet/summaries', 
                dataType: "json",
                data: data,
                success: function(response) {
                    $('.wallet_remaining_balance').html(__currency_trans_from_en(response.total_remaining_balance));
                    $('.wallet_topup_amount').html(__currency_trans_from_en(response.total_wallet_topup_amount));
                    $('.total_deductions').html(__currency_trans_from_en(response.total_deductions));
                },
                error: function(xhr, status, error) {
                    console.log('Error:', error);
                }
            });
        }

        $(document).on('change', '.wallet_balance_filter', function() {
            console.log("Filter data");
            busniess_wallet_table.ajax.reload();
        });

        /*busniess_wallet_table load dataTable*/
        var busniess_wallet_table = $('#busniess_wallet_table').DataTable({
            processing: true,
            serverSide: true,
            ajax: {
                url: "{{ route('business_wallet.index') }}", 
                type: "GET",
                data: function(d) {
                    d.balance_less_than = $('#balance_less_than').val();
                    d.balance_greater_than = $('#balance_grater_than').val();
                }
            },
            columnDefs: [{
                "targets": [5], 
                "orderable": false,
                "searchable": false
            }],
            columns: [
                { "data": "wallet_business" },
                { "data": "wallet_contact" },
                { "data": "wallet_business_mail" },
                { "data": "wallet_last_top_up_on" },
                { "data": "wallet_balance",
                    "render": function(data, type, row) {
                        return __currency_trans_from_en(data);
                    }
                },
                { "data": "wallet_action" }
            ]
        });

        /*wallet_topup popup show*/
        $(document).on('click', '.wallet_topup_button', function() {
            const walletId = $(this).data('id');  
            const businessId   = $(this).attr('business-id');  
            $('#add_wallet_topup_modal').find('input[name="wallet_id"]').val(walletId);
            $('#business-name-f-top-up-s').text($(this).attr('data-name'));
            $('#add_wallet_topup_modal').find('input[name="business_id"]').val(businessId);
            $('#add_wallet_topup_modal').modal('show');
        });

        /*wallet_topup form submition*/
        $('#add_wallet_topup_form').submit(function (e) {
            e.preventDefault(); 
            var submitButton = $(this).find('button[type="submit"]');
            submitButton.prop('disabled', true);
            var formData = $(this).serialize();
            $.ajax({
                url: $(this).attr('action'),
                method: $(this).attr('method'),
                data: formData,
                success: function (response) {             
                    if(response.success == true){
                        $('div#add_wallet_topup_modal').modal('hide');
                        toastr.success(response.message);
                        busniess_wallet_table.ajax.reload();
                        $('#add_wallet_topup_form')[0].reset();
                        setTimeout(function() {
                            location.reload();
                        }, 1000);
                    } else {
                        toastr.error(response.message);
                    }
                },
                error: function (xhr, status, error) {
                    toastr.error(error);
                },
                complete: function () {
                submitButton.prop('disabled', false);
            }
            });
        });
    });
</script>
@endsection
