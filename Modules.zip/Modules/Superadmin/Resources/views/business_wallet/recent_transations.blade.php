@extends('layouts.app')
@section('content')
@include('superadmin::layouts.nav')
	<section class="content-header">
		<h1>
			@lang('superadmin::lang.welcome_superadmin')
		</h1>
	</section>
    <section class="content">
	    <br/>
        <div class="row">
            @component('components.widget', ['class' => 'box-primary', 'title' => __( 'wallet.wallet_details' )])
                <div class="table-responsive">
                    <table id="wallet_transactions_table" class="table table-bordered table-striped">
                        <thead>
                            <tr>
                                <th>Timestamp</th>
                                <th>Amount</th>
                                <th>Transaction Type</th>
                                <th>Service Type</th>
                                <th>Payment Type</th>
                                <th>Available Balance</th>
                                <th>Description</th>
                            </tr>
                        </thead>
                    </table>
                </div>
            @endcomponent
            <div class="modal fade user_modal" tabindex="-1" role="dialog" 
                aria-labelledby="gridSystemModalLabel">
            </div>
        </div>
    </section>

<!-- /.content -->
@stop

@section('javascript')
<script type="text/javascript">
  $(document).ready(function() {
    var walletId = @json($wallet_id);
    var businessId = @json($business_id);
      var users_table = $('#wallet_transactions_table').DataTable({
          processing: true,
          serverSide: true,
          ajax: {
            url: '/superadmin/recent/wallet/transations/',
            type: "GET"
          },
          columnDefs: [{
              "targets": [5], 
              "orderable": false,
              "searchable": false
          }],
          columns: [
                { "data": "transaction_date" },
                { "data": "amount",
                    "render": function(data, type, row) {
                        return __currency_trans_from_en(data);
                    }
                },
                { "data": "transaction_type" },
                { "data": "service_type" },
                { "data": "payment_type" },
                { "data": "available_balance",
                   "render": function(data, type, row) {
                        return __currency_trans_from_en(data);
                    }
                 },
                { "data": "description" }
          ]
      });
    });
</script>
@endsection
