<div class="modal fade" id="add_wallet_topup_modal" tabindex="-1" role="dialog" 
     aria-labelledby="gridSystemModalLabel">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
        {!! Form::open(['url' => action('\Modules\Superadmin\Http\Controllers\BusinessWalletController@store'), 'method' => 'post', 'id' => 'add_wallet_topup_form' ]) !!}
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                <h3 class="modal-title">@lang('billing.top_up_amount')</h3>
                <h5 class="modal-title" id="business-name-f-top-up-s"></h5>
            </div>
            <div class="modal-body">
                <div class="row">
                    <div class="col-sm-12">
                        <div class="form-group">
                            {!! Form::label('transaction_date', __('Timestamp') . ':') !!}
                            @php
                                // Get the current date and time in the format required by datetime-local input
                                $currentDateTime = \Carbon\Carbon::now()->format('Y-m-d\TH:i');
                            @endphp

                            {!! Form::datetimeLocal('transaction_date', $currentDateTime, [
                                'class' => 'form-control',
                                'min' => $currentDateTime // Set the minimum allowable date and time
                            ]) !!}                       
                         </div>
                    </div>

                    <div class="col-sm-12">
                        <div class="form-group">
                            {!! Form::label('amount', __('Top up amount') . ':') !!}
                            {!! Form::number('amount', null, ['class' => 'form-control', 'placeholder' => __('Top up amount'), 'step' => '0.01' ]) !!}
                        </div>
                    </div>

                    <div class="col-sm-12">
                        <div class="form-group">
                            {!! Form::label('payment_type', __('Payment Type') . ':') !!}
                            {!! Form::text('payment_type', null, ['class' => 'form-control', 'placeholder' => __('Payment type')]) !!}
                        </div>
                    </div>

                    <div class="col-sm-12">
                        <div class="form-group">
                            {!! Form::label('transaction_id', __('Transaction id') . ':') !!}
                            {!! Form::text('transaction_id', null, ['class' => 'form-control', 'placeholder' => __('Transaction Id')]) !!}
                        </div>
                    </div>

                    <div class="col-sm-12">
                        <div class="form-group">
                            {!! Form::label('description', __('Description') . ':') !!}
                            {!! Form::text('description', null, ['class' => 'form-control', 'placeholder' => __('Description')]) !!}
                        </div>
                    </div>
                    {!! Form::hidden('wallet_id', null, ['id' => 'walletId']) !!}
                    {!! Form::hidden('business_id', null, ['id' => 'bussinessId']) !!}
                </div>
            </div>

            <div class="modal-footer">
                <button type="submit" class="btn btn-primary">@lang( 'messages.save' )</button>
                <button type="button" class="btn btn-default" data-dismiss="modal">@lang( 'messages.close' )</button>
            </div>

        {!! Form::close() !!}

        </div>
    </div>
</div>
