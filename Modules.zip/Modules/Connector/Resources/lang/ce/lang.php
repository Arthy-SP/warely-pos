<?php
return [
    "connector_module"=>"连接器模块",
	"connector"=>"连接器",
	"create_client"=>"创建客户端",
	"client_secret"=>"客户端机密",
	"clients"=>"客户端",
	"documentation"=>"文档",
];