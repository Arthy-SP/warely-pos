<?php
return [
	"connector_module"=>"Modeli i Lidhësit",
	"connector"=>"Lidhësi",
	"create_client"=>"Krijo klientin",
	"client_secret"=>"Sekreti i klientit",
	"clients"=>"Klientët",
	"documentation"=>"Dokumentacioni",
];