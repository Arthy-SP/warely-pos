<?php
return [
	"connector_module"=>"Bağlayıcı Modülü",
	"connector"=>"Bağlayıcı",
	"create_client"=>"İstemci Oluştur",
	"client_secret"=>"İstemci Sırrı",
	"clients"=>"Müşteriler",
	"documentation"=>"Belgeler",
];