<?php

return [
    'name' => 'Connector',
    'module_version' => "1.1",
    'pid' => 9
];
