<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Couponsystem extends Model
{

    protected $guarded = [];

    protected $casts = [
        'occurence_weekly_options' => 'array',
    ];

}
