<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class BusinessOutlets extends Model
{
    protected $fillable = ['business_id', 'name', 'file_formats', "report_type", "start_date", "report_formats", "date_formats", "serial_no", "use_pipe_for_report", "file_extension"];

    protected $casts = [
        'date_formats' => 'array',
        'file_formats' => 'array',
        'report_formats' => 'array',
    ];
}
