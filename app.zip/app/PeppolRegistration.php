<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class PeppolRegistration extends Model
{
    protected $fillable = [
        'legal_entity_id',
        'identifier',
        'status'
    ];
}