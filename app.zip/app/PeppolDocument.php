<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class PeppolDocument extends Model
{
    protected $table = 'peppol_documents';

    // Fillable fields for mass assignment
    protected $fillable = [
        'guid',
        'webhook_event_id',
        'document_data'
    ];

    // Cast document_data as a JSON type
    protected $casts = [
        'document_data' => 'array',
    ];

    // Relationship to the PeppolWebhookEvent model
    public function webhookEvent()
    {
        return $this->belongsTo(PeppolWebhookEvent::class, 'webhook_event_id');
    }
}
