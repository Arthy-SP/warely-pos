<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class CustomerMembership extends Model
{
    protected $fillable = [
        'membership_name',
        'minimum_order_amount_to_earn_reward',
        'minimum_orders_to_earn_reward',
        'minimum_points_earn_per_order',
        'business_id',
        'maximum_points_per_order',
        'redeem_amount_per_unit_point',
        'minimum_order_total_to_redeem_points',
        'minimum_redeem_point',
        'maximum_redeem_point_per_order',
        'redemption_order_period',
        'redemption_order_period_type',
        'rp_expiry_period',
        'rp_expiry_type',
        'amount_for_unit_rp',
        'minimum_order_total_to_earn_points'
    ];
}

