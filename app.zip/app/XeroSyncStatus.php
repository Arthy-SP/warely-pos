<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class XeroSyncStatus extends Model
{
    /**
     * The table associated with the model.
     *
     * @var string
     */
    protected $table = 'xero_sync_status';

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'record_type', 'last_synced_at', 'sync_status', 'error_message', 'retry_count', 'last_processed_product_id',
    ];

    /**
     * The attributes that should be cast to native types.
     *
     * @var array
     */
    protected $casts = [
        'last_synced_at' => 'datetime',
    ];
}
