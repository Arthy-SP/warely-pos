<?php

namespace App\Notifications;

use App\Utils\NotificationUtil;
use Illuminate\Bus\Queueable;
use Illuminate\Notifications\Messages\MailMessage;
use Illuminate\Notifications\Notification;

class TestEmailNotification extends Notification
{
    use Queueable;

    protected $notificationInfo;
    protected $subject;
    protected $content;
    protected $recipientEmail;
    protected $attachmentPath;

    /**
     * Create a new notification instance.
     *
     * @return void
     */
    public function __construct($notificationInfo, $subject, $content, $attachmentPath)
    {
        $this->notificationInfo = $notificationInfo;
        $notificationUtil = new NotificationUtil();
        $notificationUtil->configureEmail($notificationInfo, false);
        $this->subject = $subject;
        $this->content = $content;
        $this->attachmentPath = $attachmentPath;
        // $this->recipientEmail = $recipientEmail;
    }

    /**
     * Get the notification's delivery channels.
     *
     * @param  mixed  $notifiable
     * @return array
     */
    public function via($notifiable)
    {
        return ['mail'];
    }

    /**
     * Get the mail representation of the notification.
     *
     * @param  mixed  $notifiable
     * @return \Illuminate\Notifications\Messages\MailMessage
     */
    public function toMail($notifiable)
    {
        if($this->content =='E-receipt'){
            $viewFile = "emails.ereceipt";
        }
        else{
            $viewFile = "emails.salesreport";
        }

        return (new MailMessage)
        ->bcc('donovan@warelycorp.com', 'Warely Corp')
        ->bcc('mayankdubey@warelycorp.com', 'Warely Corp')
        ->bcc('WarelyReports@warelycorp.com', 'Warely Corp')
        ->subject($this->subject)
        ->view( $viewFile, ['content' => $this->content])
        ->attach($this->attachmentPath['url']);            
    }

    /**
     * Get the array representation of the notification.
     *
     * @param  mixed  $notifiable
     * @return array
     */
    public function toArray($notifiable)
    {
        return [
            //
        ];
    }
}
