<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class TableReservation extends Model
{

    protected $fillable = [
        'first_name',
        'last_name',
        'phone',
        'email',
        'booking_date',
        'slot_id',
        'business_id',
        'location_id',
        'terminal_id',
        'table_id',
        'payment_status',
        'pax',
        'status'
    ];
}
