<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Campaign extends Model
{
    protected $guarded = [];

    protected $casts = [
        'location_id' => 'array',
        'channel_id' => 'array'
    ];

    public function coupon_system(){
        return $this->belongsTo(Couponsystem::class, 'coupon_id', 'id');   
    }
}
