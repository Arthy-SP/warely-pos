<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

use App\Category;
use App\Product;

class PrinterModifiers extends Model
{
    use SoftDeletes;

    /**
     * The attributes that aren't mass assignable.
     *
     * @var array
     */
    protected $guarded = ['id'];

    public static function forDropdown($business_id, $show_select = true)
    {
        $query = ApiPrinterModifiers::where('business_id', $business_id);

        $printers = $query->pluck('name', 'id');
        if ($show_select) {
            $printers->prepend(__('messages.please_select'), '');
        }
        return $printers;
    }

    public function productModifiers()
    {
        return $this->belongsToMany(\App\Product::class, 'api_printer_modifiers', 'printer_group_id', 'product_modifiers_id');
    }

}
