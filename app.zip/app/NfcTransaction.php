<?php
namespace App;

use Illuminate\Database\Eloquent\Model;

class NfcTransaction extends Model
{
    protected $fillable = [
        'transaction_type', 'payment_method', 'amount', 'remark', 'business_id', 'location_id', 'nfc_card_id', 'nfc_promo_id', 'is_void', 'void_reason','user_id','is_manual_transaction','created_at', 'updated_at' // Add 'nfc_card_id'
    ];

    protected $casts = [
        'nfc_card_id' => 'integer',
        'nfc_promo_id' => 'integer',
    ];

    public function card()
    {
        return $this->belongsTo(NfcCard::class, 'nfc_card_id'); 
    }

    public function getByCardNo($cardNo)
    {
        return $this->where('card_no', $cardNo)->get();
    }

    public function promo()
    {
        return $this->belongsTo(NfcPromos::class, 'nfc_promo_id'); 
    }
}
