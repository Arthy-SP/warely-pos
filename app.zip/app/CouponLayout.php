<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class CouponLayout extends Model
{
    //
    protected $guarded = [];

}
