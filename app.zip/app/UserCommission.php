<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class UserCommission extends Model
{
    use SoftDeletes;

    /**
     * The attributes that aren't mass assignable.
     *
     * @var array
     */
    protected $guarded = ['id'];

    public function product_category()
    {
        return $this->belongsToMany(\App\Category::class, 'api_commission_categories', 'commission_group_id', 'product_categories_id');
    }

    public static function forDropdown($business_id){
        return UserCommission::where('business_id', $business_id)->where('deleted_at', null)->pluck('name', 'id');
    }
}
