<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class CampaignTelegram extends Model
{
    protected $guarded = [];
    public function campaign()
    {
        return $this->hasMany(Campaign::class, 'id', 'campaign_id');
    }

    public function location()
    {
        return $this->hasMany(BusinessLocation::class, 'id', 'location_id');
    }

    public function business()
    {
        return $this->hasMany(Business::class, 'id', 'business_id');
    }

    public function business_location()
    {
        return $this->hasMany(BusinessLocation::class, 'id', 'location_id');
    }
}
