<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class TransactionVoidSellLine extends Model
{
    /**
     * The attributes that aren't mass assignable.
     *
     * @var array
     */
    protected $guarded = ['id'];
    
    public function transaction()
    {
        return $this->belongsTo(\App\Transaction::class);
    }

    public function product()
    {
        return $this->belongsTo(\App\Product::class, 'product_id');
    }

    public function variations()
    {
        return $this->belongsTo(\App\Variation::class, 'variation_id')->withTrashed();
    }

    public function modifiers()
    {
        return $this->hasMany(\App\TransactionVoidSellLine::class, 'parent_sell_line_id', 'sell_line_id')
            ->where('children_type', 'modifier');
    }
}
