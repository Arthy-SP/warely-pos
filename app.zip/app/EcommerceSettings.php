<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class EcommerceSettings extends Model
{
   
    protected $table = 'ecommerce_settings';
   
    protected $fillable = ['access_token', 'acess_expiry_seconds', 'refresh_token','refresh_expiry_seconds'];
}
