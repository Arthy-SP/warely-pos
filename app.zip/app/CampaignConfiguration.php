<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class CampaignConfiguration extends Model
{
    use SoftDeletes;
    protected $guarded = ['id'];


    public function business()
    {
        return $this->belongsTo(\App\Business::class, 'business_id');
    }

    public function campaign()
    {
        return $this->belongsTo(\App\Campaign::class, 'campaign_id');
    }
    public function configured_locations()
    {
        return $this->belongsToMany(\App\BusinessLocation::class, 'campaign_configuration_business_locations', 'campaign_configuration_id', 'business_location_id');
    }

    public function configured_channels()
    {
        return $this->belongsToMany(\App\TelegramChannel::class, 'campaign_configuration_channels', 'campaign_configuration_id', 'channel_id');
    }
}
