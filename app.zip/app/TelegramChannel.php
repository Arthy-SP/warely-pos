<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class TelegramChannel extends Model
{
    use SoftDeletes;
    //
    protected $guarded = ['id'];
    protected $fillable = ['name', 'channel_id', 'channel_int_id', 'business_id', 'location_id', 'type'];
    public function users(){
        return $this->belongsToMany(TelegramUser::class, 'telegram_user_telegram_channels')->withPivot('old_status', 'new_status', 'referred_by', 'referred_to', 'action_taken_by');
    }

    public function campaignTelegrams()
    {
        return $this->hasMany(CampaignTelegram::class, 'telegram_channel_id');
    }

    public function telegram_campaigns()
    {
        return $this->belongsToMany(Campaign::class, 'campaign_telegrams', 'telegram_channel_id', 'campaign_id');
    }

    public function business()
    {
        return $this->hasMany(CampaignTelegram::class, 'telegram_channel_id');
    }

    public function all_channel_businesses()
    {
        return $this->belongsToMany(Business::class, 'campaign_telegrams', 'telegram_channel_id', 'business_id');
    }

    public function channel_locations()
    {
        return $this->belongsToMany(BusinessLocation::class, 'campaign_telegrams', 'telegram_channel_id', 'location_id');
    }

    public function channel_campaigns()
    {
        return $this->belongsToMany(Campaign::class, 'campaign_telegrams', 'telegram_channel_id', 'campaign_id');
    }

}
