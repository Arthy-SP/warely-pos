<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ProductBulkPriceSchedule extends Model
{

    protected $table = 'product_bulk_price_schedules';

    protected $fillable = [
        'category_id',
        'product_id',
        'schedule_date_time',
        'prices',
        'status',
        "business_id"
    ];

    protected $casts = [
        'prices' => 'array',
        'schedule_date_time' => 'datetime',
    ];

    public function category()
    {
        return $this->belongsTo(Category::class);
    }

    public function product()
    {
        return $this->belongsTo(Product::class);
    }
}
