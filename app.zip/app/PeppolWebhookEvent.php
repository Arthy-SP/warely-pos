<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class PeppolWebhookEvent extends Model
{
    protected $fillable = [
        'event_type', 'event_group', 'event', 'document_guid', 'guid', 'raw_response'
    ];

    // Define relationship with PeppolDocument
    public function document()
    {
        return $this->hasOne(PeppolDocument::class, 'webhook_event_id');
    }
}
