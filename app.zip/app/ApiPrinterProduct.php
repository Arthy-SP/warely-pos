<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ApiPrinterProduct extends Model
{
     protected $table = 'api_printer_product';

     protected $fillable = [
         'printer_group_id',
         'product_id',
     ];
 
    //  public function printerGroup()
    //  {
    //      return $this->belongsTo(PrinterGroup::class, 'printer_group_id');
    //  }

    //  public function product()
    //  {
    //      return $this->belongsTo(Product::class, 'product_id');
    //  }
}
