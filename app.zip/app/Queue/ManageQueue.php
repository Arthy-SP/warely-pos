<?php

namespace App\Queue;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class ManageQueue extends Model
{
    use SoftDeletes;

    protected $table = 'manage_queue';
    
    /**
     * The attributes that aren't mass assignable.
     *
     * @var array
     */
    protected $guarded = ['id'];
}
