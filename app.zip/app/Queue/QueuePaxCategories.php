<?php

namespace App\Queue;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class QueuePaxCategories extends Model
{
    use SoftDeletes;

    /**
     * The attributes that aren't mass assignable.
     *
     * @var array
     */
    protected $guarded = ['id'];

    /**
     * Return list of pax categories for a business
     *
     * @param int $business_id
     *
     * @return array
     */
    public static function forDropdown($business_id)
    {
        $query = QueuePaxCategories::where('business_id', $business_id);
        $result = $query->get();
        $paxCategories = $result->pluck('description', 'id');
        return $paxCategories;
    }
}
