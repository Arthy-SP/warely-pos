<?php 
namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class PeppolLegalEntity extends Model
{

    protected $fillable = [
        'business_id',
        'acts_as_receiver',
        'acts_as_sender',
        'additional_tax_identifiers',
        'advertisements',
        'api_keys',
        'city',
        'classification_code',
        'country',
        'county',
        'line1',
        'line2',
        'party_name',
        'peppol_identifiers',
        'public',
        'tax_registered',
        'tenant_id',
        'zip',
    ];

    protected $casts = [
        'additional_tax_identifiers' => 'array',
        'advertisements' => 'array',
        'api_keys' => 'array',
        'peppol_identifiers' => 'array',
        'acts_as_receiver' => 'boolean',
        'acts_as_sender' => 'boolean',
        'public' => 'boolean',
        'tax_registered' => 'boolean',
    ];
}
