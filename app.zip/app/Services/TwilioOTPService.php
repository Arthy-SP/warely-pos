<?php

namespace App\Services;

use GuzzleHttp\Client;
use GuzzleHttp\Exception\ClientException;
use Config;

class TwilioOTPService
{

    public function sendOTPWithTwilio($to) {
        $accountSid = Config::get('twilio.accountSid');
        $authToken = Config::get('twilio.authToken');
        $serviceSid = Config::get('twilio.serviceSid');   
        $client = new Client([
            'base_uri' => 'https://verify.twilio.com/v2/',
            'headers' => [
                'Authorization' => 'Basic ' . base64_encode("$accountSid:$authToken"),
                'Content-Type' => 'application/x-www-form-urlencoded',
            ]
        ]);
    
        try {
            $response = $client->post("Services/$serviceSid/Verifications", [
                'form_params' => [
                    'To' => $to,
                    'Channel' => 'sms'
                ]
            ]);
    
            if ($response->getStatusCode() == 201) {
                return true;
            } else {
                return false;
            }
        } catch (\Exception $e) {
            \Log::error('Error sending OTP: ' . $e->getMessage());
            return false;
        }
    }

    public function verifyOTPWithTwilio($contactNumber, $otp) {
        $client = new Client();
        $accountSid = Config::get('twilio.accountSid');
        $authToken = Config::get('twilio.authToken');
        $serviceSid = Config::get('twilio.serviceSid'); 
        try {
            $response = $client->post("https://verify.twilio.com/v2/Services/$serviceSid/VerificationCheck", [
                'headers' => [
                    'Authorization' => 'Basic '. base64_encode("$accountSid:$authToken"),
                    'Content-Type' => 'application/x-www-form-urlencoded'
                ],
                'form_params' => [
                    'To' => $contactNumber,
                    'Code' => $otp
                ]
            ]);
    
            $responseBody = json_decode($response->getBody(), true);
            if ($response->getStatusCode() == 200 && $responseBody['valid']) {
                return ['success' => true, 'valid' => true];
            } else {
                return ['success' => true, 'valid' => false, 'message' => 'Invalid OTP', 'status' => 401];
            }
        } catch (\Exception $e) {
            \Log::error('Error verifying OTP with Twilio: ' . $e->getMessage());
            return ['success' => false, 'message' => 'Error verifying OTP', 'status' => 500];
        }
    }
}

