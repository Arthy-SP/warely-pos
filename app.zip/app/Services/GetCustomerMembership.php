<?php

namespace App\Services;

use App\Transaction;
use Carbon\Carbon;
use App\CustomerMembership;
use App\Business;

class GetCustomerMembership
{

    public function getCustomerMembership($contactId, $business_id)
    {
        $salesExpiry = Business::where('id', $business_id)
                                ->select(['id', 'rp_sales_calculation_period', 'rp_sales_calculation_period_type'])
                                ->first();
        if($salesExpiry->rp_sales_calculation_period_type == 'year') {
            $salesMonthCount = $salesExpiry->rp_sales_calculation_period * 12;
        } else {
            $salesMonthCount = $salesExpiry->rp_sales_calculation_period;
        }
        
        $currentDate = Carbon::now();
        $threeMonthsAgo = $currentDate->subMonths($salesMonthCount);

        $transactions = Transaction::where('contact_id', $contactId)
                                   ->where('created_at', '>=', $threeMonthsAgo)
                                   ->get();

        $totalRPEarned = $transactions->sum('rp_earned');

        $totalCountSell = 0;
        $totalSumSell = 0;
        $totalCountSellReturn = 0;
        $totalSumSellReturn = 0;

        foreach ($transactions as $transaction) {
            if ($transaction->type === 'sell') {
                $totalCountSell++;
                $totalSumSell += $transaction->final_total;
            }
            elseif ($transaction->type === 'sell_return') {
                $totalCountSellReturn++;
                $totalSumSellReturn += $transaction->final_total;
            }
        }
        
        $totalCount = $totalCountSell - $totalCountSellReturn;
        $totalSum = $totalSumSell - $totalSumSellReturn;

        $selectedMembership = null;
        $nextTierMembership = null;
        $memberships = CustomerMembership::where('business_id', $business_id)
                                  ->get();

        foreach ($memberships as $membership) {
            if ($totalSum >= $membership->minimum_order_amount_to_earn_reward &&
                $totalCount >= $membership->minimum_orders_to_earn_reward) {
                if ($selectedMembership === null || 
                    $membership->minimum_order_amount_to_earn_reward > $selectedMembership->minimum_order_amount_to_earn_reward) {
                    $selectedMembership = $membership;
                }
            }
        }

        if(count($memberships) == 0) {

            $selectedMembership['id'] = null;
            $selectedMembership['membership_name'] = null;
            $selectedMembership['minimum_order_amount_to_earn_reward'] = 0;
            $selectedMembership['minimum_points_earn_per_order'] = 0;
            $selectedMembership['created_at'] = null;
            $selectedMembership['updated_at'] = null;
            $selectedMembership['business_id'] = null;
            $selectedMembership['maximum_points_per_order'] = 0;
            $selectedMembership['redeem_amount_per_unit_point'] = 0;
            $selectedMembership['amount_for_unit_rp'] = 1;
            $selectedMembership['minimum_order_total_to_redeem_points'] = 0;
            $selectedMembership['minimum_redeem_point'] = 0;
            $selectedMembership['maximum_redeem_point_per_order'] = 0;
            $selectedMembership['minimum_orders_to_earn_reward'] = 0;
            $selectedMembership['redemption_order_period'] = 0;
            $selectedMembership['redemption_order_period_type'] = 0;
            $selectedMembership['rp_expiry_period'] = 0;
            $selectedMembership['rp_expiry_type'] = 0;
            $selectedMembership['expires_on'] = null;
            $selectedMembership['total_points_earned'] = 0;
            $selectedMembership['next_target_points'] = 0;
            $selectedMembership['next_target_type_name'] = null;
            $selectedMembership['next_target_points_remaining'] = 0;
            $selectedMembership['current_Sales'] = 0;
            $selectedMembership['target_sales'] = 0;
            $selectedMembership['business_has_memberships'] = false;
            $selectedMembership['user_has_membership'] = false;

            return $selectedMembership;

        } else {

        if($selectedMembership) {
            $minOrderAmt = $selectedMembership->minimum_order_amount_to_earn_reward;
            $expiry_date = $selectedMembership->rp_expiry_period;
            $expiry_type = $selectedMembership->rp_expiry_type;
            $selectedMembership['expires_on'] = $expiry_date.' '.$expiry_type;
        } else {
            $minOrderAmt = 0;
        }

        foreach ($memberships as $membership) {
            if ($membership->minimum_order_amount_to_earn_reward > $minOrderAmt) {
                if ($nextTierMembership === null || 
                    $membership->minimum_order_amount_to_earn_reward < $nextTierMembership->minimum_order_amount_to_earn_reward) {
                    $nextTierMembership = $membership;
                }
            }
        }

        if(empty($selectedMembership)) {
            $remainingTargetPerUnitPoint = $nextTierMembership->amount_for_unit_rp;
            // $expiry_date = $nextTierMembership->rp_expiry_period;
            // $expiry_type = $nextTierMembership->rp_expiry_type;
            // $selectedMembership['expires_on'] = $expiry_date.' '.$expiry_type;
        } else {
            $remainingTargetPerUnitPoint = $selectedMembership->amount_for_unit_rp;
            // $expiry_date = $selectedMembership->rp_expiry_period;
            // $expiry_type = $selectedMembership->rp_expiry_type;
            // $selectedMembership['expires_on'] = $expiry_date.' '.$expiry_type;
        }

        if($nextTierMembership){
            $remainingTargetSum = $nextTierMembership->minimum_order_amount_to_earn_reward - $totalSum;
            $remainingTargetPoints = $remainingTargetSum * $remainingTargetPerUnitPoint;
            $nextTargetPoints = !empty($nextTierMembership->minimum_order_amount_to_earn_reward)? round($nextTierMembership->minimum_order_amount_to_earn_reward, 2) : null;
            $nextTierMembership = !empty($nextTierMembership->membership_name) ? $nextTierMembership->membership_name : null;
        } else {
            $remainingTargetSum = 0;
            $remainingTargetPoints = 0;
            $nextTargetPoints = 0;
            $nextTierMembership = "Reached Target";
        }

        if(empty($selectedMembership)) {
            $selectedMembership['id'] = null;
            $selectedMembership['business_id'] = null;
            $selectedMembership['membership_name'] = null;
            $selectedMembership['minimum_order_amount_to_earn_reward'] = 0;
            $selectedMembership['minimum_points_earn_per_order'] = 0;
            $selectedMembership['amount_for_unit_rp'] = 1;
            $selectedMembership['maximum_points_per_order'] = 0;
            $selectedMembership['redeem_amount_per_unit_point'] = 0;
            $selectedMembership['minimum_order_total_to_redeem_points'] = 0;
            $selectedMembership['minimum_redeem_point'] = 0;
            $selectedMembership['maximum_redeem_point_per_order'] = 0;
            $selectedMembership['minimum_orders_to_earn_reward'] = 0;
            $selectedMembership['redemption_order_period'] = 0;
            $selectedMembership['redemption_order_period_type'] = 0;
            $selectedMembership['rp_expiry_period'] = 0;
            $selectedMembership['rp_expiry_type'] = 0;
            $selectedMembership['expires_on'] = null;
            $selectedMembership['created_at'] = null;
            $selectedMembership['updated_at'] = null;
        }

        $selectedMembership['total_points_earned'] = $totalRPEarned;
        $selectedMembership['next_target_points'] = $nextTargetPoints;
        $selectedMembership['next_target_type_name'] = $nextTierMembership;
        $selectedMembership['next_target_points_remaining'] = round($remainingTargetPoints, 2);
        $selectedMembership['current_Sales'] = round($totalSum, 2);
        $selectedMembership['target_sales'] = round($remainingTargetSum, 2);
        $selectedMembership['business_has_memberships'] = true;
        $selectedMembership['user_has_membership'] = !empty($selectedMembership->membership_name) ? true : false;

        return $selectedMembership;
        }  
    }

}
