<?php

namespace App\Services;

use GuzzleHttp\Client;
use GuzzleHttp\Exception\ClientException;
use App\Http\Controllers\AuthController;

class AuthService
{
    public function getAccessToken()
    {
        $client = new Client();

        try {
            $response = $client->post('https://api.grab.com/grabid/v1/oauth2/token', [
                'form_params' => [
                    'client_id'     => 'bbc61eb30fbc43f997e351626c8d9a32',
                    'client_secret' => '2Ny1CIjckmMYCrZ9',
                    'grant_type'    => 'client_credentials',
                    'scope'         => 'mart.partner_api'
                ],
            ]);

            // $data = json_decode($response->getBody(), true);
 
            // $accessToken = $data['access_token'];

            // return response()->json($data)->header('Content-Type', 'application/json');
            return json_decode($response->getBody(), true);
        } catch (ClientException $e) {
            // Handle the exception and get the error response
            $errorResponse = json_decode($e->getResponse()->getBody(), true);

            return response()->json(['error' => $errorResponse], $e->getCode())->header('Content-Type', 'application/json');
        } catch (\Exception $e) {
            // Handle any other exceptions
            return response()->json(['error' => $e->getMessage()], 500)->header('Content-Type', 'application/json');
        }
    }
}