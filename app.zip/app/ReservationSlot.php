<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ReservationSlot extends Model
{
    protected $fillable = [
        'slot_start_time',
        'slot_end_time',
        'business_id',
        'location_id',
    ];
}
