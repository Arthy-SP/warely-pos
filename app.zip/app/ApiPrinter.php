<?php

namespace App;

use App\PrinterCategories;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class ApiPrinter extends Model
{
    use SoftDeletes;
    
    /**
     * The attributes that aren't mass assignable.
     *
     * @var array
     */
    protected $table = 'api_printer';
    protected $guarded = ['id'];
    protected $fillable = ['name', 'connection', 'address','printer_group_id','business_location_id','print_receipt', 'remove_receipt_title', 'remove_receipt_amount_section','device_type','allow_kitchen_print','app_printer_id','master_kitchen_print_receipt','terminal_id','enable_redirection','master_print_by_printer_group','allow_reprint'];

    public static function connection_types()
    {
        $types = [
            'bluetooth' => 'Bluetooth',
            'wifi' => 'Wifi',
        ];

        return $types;
    }

    // public function printer_categories()
    // {
    //     return $this->belongsToMany(\App\PrinterCategories::class, 'api_printer_categories', 'api_printer_id', 'printer_categorie_id');
    // }

}
