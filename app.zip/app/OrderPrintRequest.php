<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class OrderPrintRequest extends Model
{
    protected $fillable = [
        'transaction_id',
        'status',
        'from_device_id',
        'to_device_id',
        'from_terminal_id',
        'to_terminal_id',
        'receipt_type',
        'user_id',
        'business_id',
        'location_id',
        'business_location_id',
        'json_data'
    ];
    
}
