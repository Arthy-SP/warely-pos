<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class CouponUsage extends Model
{
    protected $table = 'coupon_usages';

    protected $fillable = [
        'transaction_id',
        'coupon_id',
        'coupon_value',
        'coupon_type',
        'pax',
        'coupon_name',
    ];

    public function transaction()
    {
        return $this->belongsTo(Transaction::class);
    }

    public function coupon()
    {
        return $this->belongsTo(Coupon::class);
    }
}
