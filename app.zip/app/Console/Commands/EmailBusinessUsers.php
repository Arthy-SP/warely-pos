<?php

namespace App\Console\Commands;

use App\Business;
use App\BusinessLocation;
use App\Http\Controllers\API\GenerateReportController;
use Carbon\Carbon;
use App\Notifications\TestEmailNotification;
use Illuminate\Support\Facades\Mail;
use Illuminate\Http\Request;
use App\Utils\TransactionUtil;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\File;
use pdf;
use Config;
use App\Product;
use App\Category;
use App\TaxRate;
use App\Variation;
use App\Transaction;
use App\TransactionSellLine;

use Illuminate\Console\Command;
use Illuminate\Support\Facades\Storage;
use Aws\S3\S3Client;
use Aws\Exception\AwsException;


class EmailBusinessUsers extends Command
{
    protected $transactionUtil;

    protected $grtc;
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'email:business-users';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Sends a Email notification to Business Admins for Sales Alert';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct(TransactionUtil $transactionUtil, GenerateReportController $grtc)
    {
        parent::__construct();
        $this->transactionUtil = $transactionUtil;
        $grtc = $this->grtc;
    }

    /**
     * Execute the console command.
     *
     * @return mixed
    */

    public function generateCustomEmailReport(Request $request) {
        $input = $request->only([
            'business_location_id', 'date_range', 'payment_types', 'start_date', 'end_date', 'current_time'
        ]);
         
        $sells_report = $this->get_product_sales($input);
        
        if(!empty($input['business_location_id'])) {
            ini_set('memory_limit', '8000M');
            $zip = new \ZipArchive();
            $array_filter_date = explode(" - ",$input['date_range']);
            $location_details = BusinessLocation::find($input['business_location_id']);
            $business_details = Business::find($location_details->business_id);
            $user_id = "";
            $business_id = $location_details->business_id;
            $business_name = str_replace(' ', '_', $business_details->name);
            $location_id = $input['business_location_id'];
            $location_name = str_replace(' ', '_', $location_details->name);
            $transaction_status = "final";
            $created_at = "";
            
 
            $start_date_no_time = \Carbon::parse($array_filter_date[0])->format('Y-m-d');
            $end_date_no_time = \Carbon::parse($array_filter_date[1])->format('Y-m-d');
            $start_date = $input['start_date'];
            $end_date = $input['end_date'];
            //  $start_date = \Carbon::parse($array_filter_date[0])->format('Y-m-d 00:00:00');
            //  $end_date = \Carbon::parse($array_filter_date[1])->format('Y-m-d 23:59:59');
            $type = "";
            // $txt = true;
 
            $report_dtls = $this->transactionUtil->get_sales_details($user_id, $business_id, $location_id, $transaction_status, $created_at, $start_date, $end_date, $type, null, $input['payment_types'], $input['current_time']);
            
            $collection_details_result = $report_dtls['sales_result'][0]['collection_details_result'];
            $addon_discount_amount = $report_dtls['sales_result'][0]['addon_discount_amount'];
            $tax_rates_list = $report_dtls['sales_result'][0]['tax_rates_list'];

            $tax_rates = array();
            for($i = 0; $i < count($tax_rates_list); $i++) {
                if(strtolower($tax_rates_list[$i]['name']) == 'service charge' ) {
                    $service_charge = !empty($tax_rates_list[$i]['amount']) ? $tax_rates_list[$i]['amount'] : 0;
                } else if(strtolower($tax_rates_list[$i]['name']) !== 'service charge') {
                    $gst = !empty($tax_rates_list[$i]['amount']) ? $tax_rates_list[$i]['amount'] : 0;
                }
            }

            $service_charge = !empty($service_charge) ? $service_charge : 0;
            $gst = !empty($gst) ? $gst : 0;

            $htmlRows = "";
            $discountHtmlRows = "";
            //$discountTotal = 0;
            $gst_rate = 0;
 
            foreach($collection_details_result as $collection_row) {
                $htmlRows .= '
                    <tr class="odd">
                        <td style="width: 50%;">'.strtoupper($collection_row['payment_method']) .' ('.$collection_row['quantity'].')</td>
                        <td style="width: 50%; text-align: right;">'.number_format($collection_row['payment_total_amount'], 2).'</td>
                    </tr>
                ';
            }
            $salesRows = "";
            if(!empty($sells_report)){

                $salesRows = '';
                foreach ($sells_report as $sales_data) {
                    $category = $sales_data['category'];
                    $total_quantity = $sales_data['total_quantity'];
                    $subtotal = $sales_data['subtotal'];

                    $salesRows .= '
                    <table class="items" width="1000" style="font-size: 23pt; border-collapse: collapse;" cellpadding="8">
                        <thead>
                            <tr><td></td><br></tr>
                            <tr>
                                <td colspan="1" style="text-transform: uppercase;"><strong>' . $category . '</strong></td><br>
                            </tr>
                            <tr><td></td></tr>
                        </thead>
                        <tbody>
                        <tr style="width: 100%">
                        <td style="width: 1%;max-width: 100px">Qty</td>
                        <td style="width: 20%;">UP</td>
                        <td style="width: 20%;">TUP</td>
                        <td style="width: 40%;">Item</td>
                        <td style="width: 20%;">DPU</td>
                        <td style="width: 20%;">TD</td>
                        <td style="width: 20%; text-align: right;">Amount</td>
                    </tr>  
                    ';

                    foreach ($sales_data['items'] as $item) {
                        $quantity = $item['quantity'];
                        $name = $item['name'];
                        $discount = $item['discount'];
                        $total_discount = $item['quantity'] * $item['discount'];
                        $amount = $item['amount'] - ($item['discount'] * $item['quantity']);
                        $total_unit_price = number_format($item['amount'], 2);
                        $unit_price = $item['total_for_single_item']/$quantity;


                        $salesRows .= '
                        <tr style="width: 100%">
                            <td style="width: 1%;max-width: 100px">' . $quantity . '</td>
                            <td style="width: 20%;">' . round($unit_price, 2) . '</td>
                            <td style="width: 20%;">' . round($total_unit_price, 2) . '</td>
                            <td style="width: 20%;">' . $name . '</td>
                            <td style="width: 20%;">(' . round($discount, 2) . ')</td>
                            <td style="width: 20%;">(' . round($total_discount, 2) . ')</td>
                            <td style="width: 20%; text-align: right;">' . round($amount, 2) . '</td>
                        </tr>
                        ';
                    }

                    $salesRows .= '
                        <tr><td></td></tr>
                        <tr style="width: 100%">
                            <td style="width: 30%;min-width: 30%"><strong>Total Quantity:</strong> ' . $total_quantity . '</td>
                            <td style="width: 20%;min-width: 60%"></td>
                            <td style="width: 20%;min-width: 60%"></td>
                            <td style="width: 20%;min-width: 60%"></td>
                            <td style="width: 20%;min-width: 60%"></td>
                            <td style="width: 20%;min-width: 60%"></td>
                            <td align="right" style="width: 30%;min-width: 10%;text-align: right;"><strong>Subtotal:</strong> ' . $subtotal . '</td>
                        </tr>
                        </tbody>
                    </table>
                    <hr>
                    ';
                }
            } else {
                $salesRows .= "<thead>No Product data</thead>";
            }
              
            foreach($addon_discount_amount as $discount_row) {
                $discountHtmlRows .= '
                    <tr class="odd">
                        <td style="width: 50%">'.$discount_row['addon_discount_name'].'</td>
                        <td style="width: 50%; text-align: right;">'.number_format($discount_row['addon_discount_amount'], 2).'</td>
                    </tr>
                ';
            }
 
            foreach($tax_rates_list as $tax_row) {
                if($tax_row['name'] == "GST") {
                    $gst_rate = $tax_row['amount'];
                }
            }
 
            if($location_details->show_retail) {
                $service_charge_amount = 0;
                $gst_amount = ($report_dtls['sales_result'][0]['gross_sales'] - $report_dtls['sales_result'][0]['item_discount'] - $report_dtls['sales_result'][0]['discount_total']) * ($gst_rate/100);
                $net_sales = $report_dtls['sales_result'][0]['gross_sales'] - $report_dtls['sales_result'][0]['item_discount'] - $report_dtls['sales_result'][0]['discount_total'] - $gst_amount;
            } else {
                $service_charge_amount = $report_dtls['sales_result'][0]['service_charge_amount'];
                $gst_amount = $report_dtls['sales_result'][0]['tax_amount'];
                $net_sales = $report_dtls['sales_result'][0]['net_sales'];
            }
             
            $html='
                <body>
                <div id="page">
                <br><br>
                <div id="address">

                     <p>
                         <strong>'.$location_details->name.'</strong><br>
                         Address: '.$location_details->city.'<br>
                         GST REG NO: '.$location_details->uen.'<br>
                         Closing Report from '.$start_date.' to '.$end_date.'<br>
                     </p>
                 </div><!--end address-->
 
                 <div id="content">
                         <hr>
                         <strong>SALES DETAILS</strong><br>
                         <table class="items" width="1000" style="font-size: 16pt; border-collapse: collapse;" cellpadding="8">
                             <tbody>
                                 '.$htmlRows.'
                             </tbody>
                         </table>
                         <hr>
                         <table class="items" width="1000" style="font-size: 16pt; border-collapse: collapse;" cellpadding="8">
                             <tbody>
                                 <tr class="odd">
                                     <td style="width: 50%">SALES AMOUNT</td>
                                     <td style="width: 50%; text-align: right;">'.number_format($report_dtls['sales_result'][0]['collection_details_total'], 2).'</td>
                                 </tr>
                             </tbody>
                         </table>
                         <hr>
                         <table class="items" width="1000" style="font-size: 16pt; border-collapse: collapse;" cellpadding="8">
                             <tbody>
                                 <tr class="odd">
                                     <td style="width: 50%">GROSS SALES</td>
                                     <td style="width: 50%; text-align: right;">'.number_format($report_dtls['sales_result'][0]['gross_sales'], 2).'</td>
                                 </tr>
                                 <tr class="odd">
                                     <td style="width: 50%">Item Discount</td>
                                     <td style="width: 50%; text-align: right;">'.number_format($report_dtls['sales_result'][0]['item_discount'], 2).'</td>
                                 </tr>
                                 '.$discountHtmlRows.'
                                 <tr class="odd">
                                     <td style="width: 50%">DISCOUNT TOTAL</td>
                                     <td style="width: 50%; text-align: right;">'.number_format($report_dtls['sales_result'][0]['discount_total'], 2).'</td>
                                 </tr>
                             </tbody>
                         </table>
                         <hr>
                         <table class="items" width="1000" style="font-size: 16pt; border-collapse: collapse;" cellpadding="8">
                             <tbody>
                                 <tr class="odd">
                                     <td style="width: 50%">'.$service_charge.'% SVC.C</td>
                                     <td style="width: 50%; text-align: right;">'.number_format($service_charge_amount, 2).'</td>
                                 </tr>
                                 <tr class="odd">
                                     <td style="width: 50%">'.$gst.'% GST</td>
                                     <td style="width: 50%; text-align: right;">'.number_format($gst_amount, 2).'</td>
                                 </tr>
                             </tbody>
                         </table>
                         <hr>
                         <table class="items" width="1000" style="font-size: 16pt; border-collapse: collapse;" cellpadding="8">
                             <tbody>
                                 <tr class="odd">
                                     <td style="width: 50%">NET SALES</td>
                                     <td style="width: 50%; text-align: right;">'.number_format($net_sales, 2).'</td>
                                 </tr>
                             </tbody>
                         </table>
                         
                         <hr>
                     </div>
                     <br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
                     <div id="content">
                     <br><br>
                     <strong style="text-transform: uppercase">Product Z Report</strong><br><br>
                     <div>
                            <table>
                            <tr><td></td></tr>
                            <tr><td>UP: Unit Price</td></tr>
                            <tr><td>TUP: Total Unit Price</td></tr>
                            <tr><td>DPU: Discount Per Unit</td></tr>
                            <tr><td>TD: Total Discount</td></tr>
                            <tr><td></td></tr>
                            </table>
                        </div>
                        ' . $salesRows . '
                     </div>
                     
                </body>';

                $pDfFileName = "report-" . $business_name . "-" . $location_name . "-" . $start_date_no_time . ".pdf";
                
                $mpdf = new \Mpdf\Mpdf([
                    'mode' => 'utf-8', 
                    'autoScriptToLang' => true,
                    'autoLangToFont' => true,
                    'autoVietnamese' => true,
                    'autoArabic' => true,
                    'margin_top' => 8,
                    'margin_bottom' => 8,
                    'format' => 'A4'
                ]);
                $mpdf->WriteHTML($html);
                $pdfContent = $mpdf->Output('', \Mpdf\Output\Destination::STRING_RETURN);

                $bucketName = config('constants.AWS_BUCKET');
                $pdfKey = config('constants.awsS3Env') . "/sales_reports/" . $pDfFileName;  // The key (path) under which the PDF will be stored in the bucket

                \Log::info("bucketName: ". $bucketName . ' --- ' . $business_id . ' --- ' . $location_id);
                \Log::info("pdfKey: ". $pdfKey . ' --- ' . $business_id . ' --- ' . $location_id);

                $s3 = new S3Client([
                    'version' => 'latest',
                    'region' => config('constants.AWS_DEFAULT_REGION'),  // Replace with your desired region
                    'credentials' => [
                        'key' => config('constants.AWS_ACCESS_KEY_ID'),
                        'secret' => config('constants.AWS_SECRET_ACCESS_KEY'),
                    ],
                ]);

                try {
                    $result = $s3->putObject([
                        'Bucket' => $bucketName,
                        'Key' => $pdfKey,
                        'Body' => $pdfContent,
                        'ContentType' => 'application/pdf',  // Set the appropriate content type
                        // 'ACL' => 'public-read',  // Adjust ACL settings as needed
                    ]);
                    \Log::info("PDF URL: ". $result['ObjectURL'] . ' --- ' . $business_id . ' --- ' . $location_id);
                    return ["url" => $result['ObjectURL']];
                } catch (AwsException $e) {
                    \Log::info("generateCustomEmailReport Error uploading PDF to S3: " . $e->getMessage() . ' --- ' . $business_id . ' --- ' . $location_id);
                    return false;
                }
         } else {
            return false;
        }
    }

    public function get_product_sales($user_data) {
        $businessLocation = BusinessLocation::find($user_data['business_location_id']);
        if( !empty($businessLocation) && !empty($businessLocation->day_start_time)) {
            $daystartTime = $businessLocation->day_start_time;
            $dayStartTime = $daystartTime.":00:00";
            $dayendTime = $daystartTime - 1;
            $dayEndTime = $dayendTime.":59:59";
        } else {
            $dayStartTime = str_replace(' ', '', Config::get('constants.businessStartTimeDefault'));
            $dayEndTime = str_replace(' ', '', Config::get('constants.businessEndTimeDefault'));
        }
            
        try {
            $location_id = $user_data['business_location_id'];
            $transaction_status = "final";
            $created_at = "";
            
            if (!empty($user_data['start_date']) && !empty($user_data['end_date'])) {
                $start_date = $user_data['start_date'];
                $end_date = $user_data['end_date'];
            } else {
                $start_date = "";
                $end_date = "";
            }
            $type = "";
            
            $current_time = $user_data['current_time'];

            $query = Transaction::leftjoin('transaction_payments as t', 't.transaction_id', '=', 'transactions.id')
                    ->leftjoin('variations as w', 'w.product_id', '=', 'transactions.additional_discount_method')
                    ->leftjoin('tax_rates as z', 'z.id', '=', 'transactions.tax_id')
                    ->leftJoin(
                        'transactions AS SR',
                        'transactions.id',
                        '=',
                        'SR.return_parent_id'
                    )
                    ->with('sell_lines.variations.product.category')
                    ->where('transactions.location_id', $location_id)
                    ->where('transactions.type', 'sell')
                    ->where('transactions.is_direct_sale', 0)
                    ->where(function($query) {
                        $query->where('transactions.type_for_api', 'Dinein')
                                ->orWhere('transactions.type_for_api', 'Takeaway')
                                ->orWhere('transactions.type_for_api', 'Retail')
                                ->orWhere('transactions.type_for_api', 'Kiosk')
                                ->orWhere('transactions.type_for_api', 'Common');
                    });
            if (!empty($start_date) && !empty($end_date)) {
                $dateTime = explode(' ', $start_date);

                if(count($dateTime) == 2) {
                    $query->where('transactions.transaction_date', '>=', $start_date)
                        ->where('transactions.transaction_date', '<=', $end_date);
                }
                else {
                    
                    if( Config::get('constants.setBusinessTime') && !empty($businessLocation) && !empty($businessLocation->day_start_time)) {
                        $query->whereBetween('transactions.transaction_date', [$start_date, $end_date]);
                    } else {
                        $query->whereDate('transactions.transaction_date', '>=', $start_date)
                            ->whereDate('transactions.transaction_date', '<=', $end_date);
                    }
                }
            } else {
                $query->whereDate('transactions.transaction_date', '=', \Carbon::now()->format('Y-m-d 00:00:00'));
            }

            if (!empty($type)) {
                $query->where('transactions.type_for_api', $type);
            }
            
            if ($transaction_status == 'quotation') {
                $query->where('transactions.status', 'draft')
                    ->where('transactions.sub_status', 'quotation');
            } elseif ($transaction_status == 'draft') {
                $query->where('transactions.status', 'draft')
                    ->whereNull('transactions.sub_status');
            } else {
                $query->where('transactions.status', $transaction_status);
            }
            
            $transactions = $query->orderBy('transactions.created_at', 'desc')
                                ->groupBy('transactions.id')
                                ->select('transactions.*', 't.method', 't.card_type', 'w.profit_percent', 'z.amount as tax_rate_amount', DB::raw('COUNT(SR.id) as return_exists'), 'SR.refund_all')
                                ->with(['contact', 'table'])
                                ->get();

            $item;
            $category_arr = [];
            $product_report_result = [];
            
            foreach ($transactions as $key => $value) 
            {
                $final_total_for_single_item = 0;
                $final_total_line_discount_amount = 0;

                foreach ($value['sell_lines'] as $sellLinesKey => $sellLinesValue)
                {
                    $total_line_discount_amount = 0;
                    $refund_total_line_discount_amount = 0;
                    
                    if($sellLinesValue["parent_sell_line_id"] == null && $sellLinesValue["transaction_id"] == $value['id'])
                    {
                        $adons = [];
                        $total_for_single_item = 0;
                        foreach ($value['sell_lines'] as $sellLinesKey1 => $sellLinesValue1)
                        {
                            if($sellLinesValue1["parent_sell_line_id"] != null && $sellLinesValue1["parent_sell_line_id"] == $sellLinesValue['id'] && $sellLinesValue1["children_type"] == "modifier")
                            {
                                $adons[] = [
                                    'id' => !empty($sellLinesValue1['variations']->id) ? $sellLinesValue1['variations']->id : "",
                                    'name' => !empty($sellLinesValue1['variations']->name) ? $sellLinesValue1['variations']->name : "",
                                    'quantity' => !empty($sellLinesValue1["quantity"]) ? $sellLinesValue1["quantity"] : "",
                                    'amount' => !empty($sellLinesValue1['unit_price_before_discount']) ? $sellLinesValue1['unit_price_before_discount'] : "", //unit_price_before_discount
                                ];
                                if($sellLinesValue["quantity_returned"] == "0.0000" && $sellLinesValue["change_price"] == 0)
                                {
                                    //total modifier price
                                    $total_for_single_item = $total_for_single_item + $sellLinesValue1['unit_price_before_discount'];
                                }
                            }
                        }
    
                        //main item price + modifier price
                        if($sellLinesValue['weight'] > 0) {
                            $total_for_single_item = ($sellLinesValue['unit_price_before_discount'] + $total_for_single_item) * $sellLinesValue["quantity"];
                        } else {
                            $total_for_single_item = ($sellLinesValue['unit_price_before_discount'] + $total_for_single_item)* $sellLinesValue["quantity"];
                        }
    
                        if($sellLinesValue["quantity_returned"] == "0.0000")
                        {
                            $final_total_for_single_item += $total_for_single_item;
                            //calculate if line item has line discount
                            if($sellLinesValue['line_discount_type'] == "fixed")
                            {
                                $total_line_discount_amount += $sellLinesValue['line_discount_amount'];
                                $total_line_discount_amount = $total_line_discount_amount/$sellLinesValue['quantity'];
                            }
                            else if($sellLinesValue['line_discount_type'] == "percentage")
                            {
                                $total_line_discount_amount = (($sellLinesValue['line_discount_amount']/100) * $total_for_single_item) + $total_line_discount_amount;
                                $total_line_discount_amount = $total_line_discount_amount/$sellLinesValue['quantity'];
                            }
                            //calculate final total line discount amount
                            $final_total_line_discount_amount += $total_line_discount_amount;
                            
                            if((isset($sellLinesValue['variations']) && $sellLinesValue['variations'] && isset($sellLinesValue['variations']->product) && $sellLinesValue['variations']->product) && (strtolower($sellLinesValue['variations']->product->name) == 'open food' || strtolower($sellLinesValue['variations']->product->name) == 'open drinks')) {
                                $latest_product_name = $sellLinesValue['sell_line_note'];
                            } else {
                                $latest_product_name = $sellLinesValue['variations']->product->name;
                            }

                            $item = [
                                'id' => $sellLinesValue['id'],
                                'category_name' => $sellLinesValue['variations']->product->category->name,
                                'name' => $latest_product_name,
                                'quantity' => $sellLinesValue['quantity'],
                                'quantity_returned' => $sellLinesValue["quantity_returned"],
                                'amount' => $total_for_single_item,
                                'total_for_single_item' => $total_for_single_item,
                                'discount' => $total_line_discount_amount,
                                'discount_type' => $sellLinesValue["line_discount_type"],
                                'unit_price' => $sellLinesValue['unit_price_before_discount']
                            ];

                            if ($sellLinesValue['line_discount_type'] === 'percentage') {
                                $total_discount = $total_line_discount_amount * $sellLinesValue['quantity'];
                            } else {
                                $total_discount = $total_line_discount_amount;
                            }

                            $item['total_discount'] = $total_discount;

                            if ($sellLinesValue['line_discount_type'] === 'fixed') {
                                $item['discount'] = $total_line_discount_amount / $sellLinesValue['quantity'];
                            }

                            $pushItem = true;
                            $discountGroupKey = $item['discount'];

                            if (in_array($sellLinesValue['variations']->product->category->name, $category_arr)) {
                                foreach ($product_report_result as $resultKey => $productReportDetailsValue) {
                                    if ($productReportDetailsValue['category'] == $sellLinesValue['variations']->product->category->name) {
                                        foreach ($productReportDetailsValue['items'] as $productKey => $productDetailsValue) {
                                            if (
                                                strtolower($product_report_result[$resultKey]['items'][$productKey]['name']) == strtolower($latest_product_name) &&
                                                $product_report_result[$resultKey]['items'][$productKey]['discount'] == $discountGroupKey &&
                                                $product_report_result[$resultKey]['items'][$productKey]['discount_type'] == $sellLinesValue['line_discount_type'] &&
                                                $product_report_result[$resultKey]['items'][$productKey]['unit_price'] == $sellLinesValue['unit_price_before_discount']
                                            ) {
                                                // Merge with the previous entry
                                                $product_report_result[$resultKey]['items'][$productKey]['quantity'] += $sellLinesValue['quantity'];
                                                $product_report_result[$resultKey]['items'][$productKey]['quantity_returned'] += $sellLinesValue['quantity_returned'];
                                                $product_report_result[$resultKey]['items'][$productKey]['amount'] += $total_for_single_item;
                                                $product_report_result[$resultKey]['items'][$productKey]['total_for_single_item'] += $total_for_single_item;
                            
                                                // Update total_discount
                                                if ($sellLinesValue['line_discount_type'] === 'percentage') {
                                                    $total_discount = $total_line_discount_amount * $product_report_result[$resultKey]['items'][$productKey]['quantity'];
                                                } else {
                                                    $total_discount = $total_line_discount_amount;
                                                }
                                                $product_report_result[$resultKey]['items'][$productKey]['total_discount'] = $total_discount;
                            
                                                $pushItem = false;
                                                break;
                                            }
                                        }
                                        
                                        if ($pushItem) {
                                            $productItem = $product_report_result[$resultKey]['items'];
                                            array_push($productItem, $item);
                                            $product_report_result[$resultKey]['items'] = $productItem;
                                        }
                            
                                        $product_report_result[$resultKey]['total_quantity'] += $sellLinesValue['quantity'];
                                        $product_report_result[$resultKey]['subtotal'] += $total_for_single_item - ($item['discount'] * $sellLinesValue['quantity']);
                                    }
                                }
                            } else {
                                $items = [];
                                array_push($category_arr, $sellLinesValue['variations']->product->category->name);
                                array_push($items, $item);
                            
                                $product_report_result[] = [
                                    'category' => $sellLinesValue['variations']->product->category->name,
                                    'total_quantity' => $sellLinesValue['quantity'],
                                    'subtotal' => $total_for_single_item - ($item['discount'] * $item['quantity']),
                                    'items' => $items
                                ];
                            }
                        }
                    }
                }
            }
            return $product_report_result;
        } catch(\Exception $e) {
            \Log::info("get_product_sales Caught exception: " . $e->getMessage() . ' -- ' . $location_id);
        }
    }

    public function handle() {
        $businessLocations = BusinessLocation::whereNotNull('b.email_settings')
                        ->whereNotNull('business_locations.email')
                        ->join('business AS b', 'business_locations.business_id', '=', 'b.id')
                        ->select(['business_locations.email', 'b.name AS business_name', 'business_locations.name AS business_location_name', 'b.email_settings', 
                        'b.id AS business_id', 'business_locations.id AS business_location_id', 'business_locations.day_start_time'])
                        ->get();

        if( $businessLocations && count($businessLocations) ) {
            foreach ($businessLocations as $key => $businessLocation) {
                $business = Business::find($businessLocation->business_id);
                \Log::info($businessLocation->business_name.'-----'.$businessLocation->business_location_name);
                $email_settings = $business->email_settings;

                \Log::info("=====================================================================");
                if( $email_settings['mail_host'] ) {
                    if($email_settings['mail_host'] !== null) {
                        \Log::info("MAIL HOST FOUND: " . $businessLocation->business_id . " --- " . $businessLocation->business_location_id);

                        $emailSettings['email_settings'] = $business->email_settings;
                        $emailSettings['email_settings']['to'] = $businessLocation->email;
                        \Log::info("Email Address: " . $businessLocation->business_id . " --- " . $businessLocation->business_location_id . " --- " . $emailSettings['email_settings']['to']);

                        if( !empty($businessLocation) && !empty($businessLocation->day_start_time) ) {
                            $daystartTime = $businessLocation->day_start_time;
                            $dayStartTime = $daystartTime ? $daystartTime . ":00:00" : "00:00:00";
                            $dayendTime = strtotime($dayStartTime) - 1;
                            $dayEndTime = date("H:i:s", $dayendTime);
                        } else {
                            $dayStartTime = str_replace(' ', '', Config::get('constants.businessStartTimeDefault'));
                            $dayEndTime = str_replace(' ', '', Config::get('constants.businessEndTimeDefault'));
                        }

                        $current_date = Carbon::now()->format('Y-m-d');
                        $current_time = Carbon::now()->format('H:00:00');
                        
                        if( !empty($businessLocation) && isset($businessLocation->day_start_time) ) {
                            $morning6TimeStamp = strtotime($current_date . " " . $dayEndTime);
                            $dateTimeStamp = strtotime($current_date . " " . $current_time);
                            if($businessLocation->day_start_time == 0) {
                                $today = $current_date .' '.'00:00:00';
                                $tomorrow = $current_date .' '.'23:59:59';
                                $Today = $current_date;
                                $Tomorrow = $current_date;
                            } elseif( $dateTimeStamp >= $morning6TimeStamp ) {
                                $today = $current_date . ' ' .$dayStartTime;
                                $Today = $current_date;
                                $tomorrow = date('Y-m-d', strtotime($current_date .' +1 day')) . ' ' .$dayEndTime;
                                $Tomorrow = date('Y-m-d', strtotime($current_date .' +1 day'));
                            } else {
                                $today = date('Y-m-d', strtotime($current_date .' -1 day')) . ' ' .$dayStartTime;
                                $Today = date('Y-m-d', strtotime($current_date .' -1 day'));
                                $tomorrow = $current_date .' '.$dayEndTime;
                                $Tomorrow = $current_date;
                            }
                        } else {
                            $today = Carbon::today()->format('Y-m-d') . Config::get('constants.businessStartTimeDefault');
                            $Today = Carbon::today()->format('Y-m-d');
                            $tomorrow = Carbon::today()->format('Y-m-d') . Config::get('constants.businessEndTimeDefault');
                            $Tomorrow = Carbon::today()->format('Y-m-d');
                        }

                         \Log::info("today: " . $businessLocation->business_id . " --- " . $businessLocation->business_location_id . " --- " . $today);
                         \Log::info("tomorrow: " . $businessLocation->business_id . " --- " . $businessLocation->business_location_id . " --- " . $tomorrow);

                         \Log::info("Today: " . $businessLocation->business_id . " --- " . $businessLocation->business_location_id . " --- " . $Today);
                         \Log::info("Tomorrow: " . $businessLocation->business_id . " --- " . $businessLocation->business_location_id . " --- " . $Tomorrow);
                    
                        $today_date = date('m/d/Y', strtotime($today));
                        $tomorrow_date = date('m/d/Y', strtotime($tomorrow));
                        $todayOneHourAgo = date('Y-m-d H', strtotime($today . ' -1 hour'));
                        $hour = date('H', strtotime($today . ' -1 hour'));
                        //$todayOneHourAgoHour = date('H', strtotime($todayOneHourAgo));
                        $currentTime = Carbon::now()->format('H');
                        $dateRange = $today_date.' - '.$tomorrow_date;

                        $request = new \Illuminate\Http\Request([
                            'date_range' => $dateRange,
                            'payment_types' => 'All',
                            'start_date' => $today,
                            'end_date' => $tomorrow,
                            'current_time' => $current_time,
                            'business_id' => $businessLocation->business_id,
                            'business_location_id' => $businessLocation->business_location_id,
                            'business_location_name' => $businessLocation->business_location_name,
                            'business_name' => $businessLocation->business_name
                        ]);
    
                         \Log::info("Hour: " . $businessLocation->business_id . " --- " . $businessLocation->business_location_id . " --- " . $hour);
                         \Log::info("currentTime: " . $businessLocation->business_id . " --- " . $businessLocation->business_location_id . " --- " . $currentTime);
                         
                         if ($hour === $currentTime) {
                            $pdfPath = $this->generateCustomEmailReport($request);
                            if( $pdfPath && count($pdfPath) ) {
                                \Log::info("PDF Path: " . $businessLocation->business_id . " --- " . $businessLocation->business_location_id . " --- " . $pdfPath["url"]);

                                if(env('APP_ENV') == 'dev') {
                                    $appname = env('APP_ENV');
                                } elseif(env('APP_ENV') == 'stage') {
                                    $appname = env('APP_ENV');
                                } else {
                                    $appname = "";
                                }
                                
                                try {
                                    $subject = strtoupper($appname).' '.$businessLocation->business_name.', '.$businessLocation->business_location_name.', '." Closing Sale Report ". $Today;
                                    // $content = url()->full().'/sells?id='.$businessLocation->id.'&date='.$Today;
                                    $content = 'Sales report generated for '. $Today;
                                    \Notification::route('mail', $businessLocation->email)
                                                ->notify(new TestEmailNotification($emailSettings, $subject, $content, $pdfPath));                                                
                                } catch(\Exception $e) {
                                    \Log::info("Handle Caught exception: " . $e->getMessage() . " --- " . $businessLocation->business_id . " --- " . $businessLocation->business_location_id);
                                }
                            } else {
                                \Log::info('No PDF URL found' . " --- " . $businessLocation->business_id . " --- " . $businessLocation->business_location_id);
                            }
                        } 
                        else {
                            \Log::info('No records found' . " --- " . $businessLocation->business_id . " --- " . $businessLocation->business_location_id);
                        }
                    } else {
                        \Log::info('No mail host found INNER' . " --- " . $businessLocation->business_id . " --- " . $businessLocation->business_location_id);
                    }
                } else {
                    \Log::info('No mail host found OUTER' . " --- " . $businessLocation->business_id . " --- " . $businessLocation->business_location_id);
                } 
            }
        } else {
            \Log::info('No Business Location found');
        }
    }
}
?>

