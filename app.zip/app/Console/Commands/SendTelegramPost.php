<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use App\TelegramPost;
use App\TelegramToken;
use App\TelegramChannel;
use GuzzleHttp\Client;
use Illuminate\Support\Carbon;


class SendTelegramPost extends Command
{
    protected $signature = 'telegram:send-post';
    protected $description = 'Send a post to a Telegram channel with an image.';

    public function __construct()
    {
        parent::__construct();
    }

    public function handle()
    {
        \Log::info("message cron send post -" . "Start");
        $mytime = Carbon::now();
        $now = $mytime->toDateTimeString();
        $posts = TelegramPost::where('scheduled_at', '<=', $now)->where("is_sended", 0)->get();
        \Log::info("now data is -" . $posts);

        foreach ($posts as $key => $post) {
            $base_url = "https://api.telegram.org";
            $token_id = $post->bot_token_id;
            $token_data = TelegramToken::find($token_id);
            $token = $token_data->token_id;
            $channel_ids = $post->channel_id;
            $image = $post->image;
            $caption = $post->post_description;
            $bot_username = $token_data->username;
            $campaign_id = $post->campaign_id;
            
            foreach ($channel_ids as $key => $id) {
                $channel_data = TelegramChannel::find($id);
                $channel_id = $channel_data->channel_id;

                try {
                    $url = "https://t.me/".$bot_username."?start=10=".$campaign_id;
                    $client = new Client();
                    $markupButton = [
                        'inline_keyboard' => [
                            [
                                [
                                    'text' => 'Redeem Coupon', 
                                    'url' => $url
                                ],
                            ],
                        ],
                    ];
                    $response = $client->request('POST', $base_url . ":443/bot" . $token . "/sendPhoto", [
                        'multipart' => [
                            [
                                'name' => 'chat_id',
                                'contents' => $channel_id,
                            ],
                            [
                                'name' => 'photo',
                                //'contents' => fopen('https://i.pcmag.com/imagery/articles/00Cx7vFIetxCuKxQeqPf8mi-66..v1667334873.jpg', 'r'), // Replace with your image file
                                'contents' => fopen($image, 'r'), // Replace with your image file
                                'filename' => 'image.jpg',
                            ],
                            [
                                'name' => 'caption',
                                'contents' => $caption,
                            ],
                            [
                                'name' => 'parse_mode',
                                'contents' => 'HTML', // Optional: Markdown | HTML
                            ],
                            [
                                'name' => 'reply_markup',
                                'contents' => json_encode($markupButton),
                            ],
                        ],
                    ]);
                    $json = json_decode($response->getBody());
                    if ($json->ok == "true") {
                        $output = "Post send successfully";
                        \Log::info("Post Send - ".$key. "$post->id" . $output."for channel id".$channel_id);
                    } else {
                        $output = "Post sent failed";
                        \Log::info("Post Send - ".$key. "$post->id" . $output."for channel id".$channel_id);
                    }
                } catch (\Throwable $th) {
                    \Log::error("error message-".$key. "$post->id" . $th);
                }
            }
            $post_send = TelegramPost::where('id', $post->id)->update(['is_sended' => 1]);
        }
    }
}
