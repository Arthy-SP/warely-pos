<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use Illuminate\Support\Facades\Http;
use LazadaSDK\LazopClient;
use LazadaSDK\LazopRequest;
use GuzzleHttp\Client;
use Carbon\Carbon;
use App\EcommerceSettings;
use Illuminate\Support\Facades\DB;
use App\Providers\LazadaServiceProvider;
use App\Product;
class FetchLazadaData extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'fetch:lazada-data';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Fetch data from Lazada API and update the products table.';

    /**
     * Create a new command instance.
     *
     * @return void
     */

     public function __construct(LazadaServiceProvider $LazadaService)
     {
         $this->LazadaServiceProvider = $LazadaService;
         parent::__construct();
     }
    // public function __construct()
    // {
    //     parent::__construct();
    // }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
       $lz_credentials = DB::table('ecommerce_settings')->where('type','lazada')->first();
       $refresh_token = $lz_credentials->refresh_token;
       $update_at = $lz_credentials->updated_at;
       $access_token = $lz_credentials->access_token;
       $current_time = Carbon::now();
       $givenCarbon = Carbon::parse($update_at);
       $diff = $givenCarbon->diffInMinutes($current_time);
       if($diff > 15){
         $new_access = $this->LazadaServiceProvider->refreshToken($refresh_token);
         $access_token = $new_access['access_token']; 
       }
       $this->LazadaServiceProvider->getOrderdata($access_token);
       $order_ids = collect($data)->pluck('order_id')->toArray();
       $order_items = $this->LazadaServiceProvider->getOrderItem($user_token, $order_ids);
       foreach ($order_items as $item) {
           $order_item_datas = $item['order_items'];
           foreach ($order_item_datas as $order_item_data) {
               $order_item_id = $order_item_data['order_item_id'];
               $order_item_count = $order_item_data['order_item_id'];
               $products = Product::where('lazada_product_id', $order_item_id)->first();

               $location_ids = DB::table('business_locations')->where('business_id', $products->business_id)->pluck('location_id');
               if ($products) {
                   $qty_chk = DB::table('variation_location_details')->where('product_id', $products->id)->whereIn('location_id', $location_ids)->where('qty_available
                   ', '>', 0)->first();
                   $calculate_qty =  $qty_chk->qty_available - 1;
                   DB::table('variation_location_details')->where('product_id', $products->id)->where('id', $qty_chk->id)->update([
                       'qty_available' => $calculate_qty,

                   ]);
               }
           }
       }

    }
}
