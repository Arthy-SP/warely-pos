<?php

namespace App\Console\Commands;

use App\PeppolWebhookEvent;
use App\PeppolDocument;
use Illuminate\Console\Command;
use GuzzleHttp\Client;
use Exception;

class PeppolWebhook extends Command
{
    // The name and signature of the console command
    protected $signature = 'peppol:webhook';

    // The console command description
    protected $description = 'Call Peppol webhook every 2 minutes';

    public function __construct()
    {
        parent::__construct();
    }

    public function handle()
    {
        // Initialize Guzzle HTTP client
        $client = new Client();

        // Call the webhook
        $response = $client->get('https://api.storecove.com/api/v2/webhook_instances', [
            'headers' => [
                'Authorization' => 'Bearer '.'8EzJrFUTh3gKxm1FkBmq9qQ0wXpkcE-2yA_BGFA6_ag', // Replace with your API key if required
                'Content-Type'  => 'application/json',
            ],
        ]);
        
        $data = json_decode($response->getBody(), true);
        //if (isset($data['body'])) {
            $bodyData = json_decode($data['body'], true);
        //
        \Log::info("Fetching document with GUID: {$bodyData['document_guid']}");
        \Log::info('Webhook response:', $data);

        // Create webhook event
        $webhookEvent = PeppolWebhookEvent::create([
            'event_type' => $bodyData['event_type'],
            'event_group' => $bodyData['event_group'],
            'event' => $bodyData['event'],
            'document_guid' => $bodyData['document_guid'],
            'guid' => $data['guid'],
            'raw_response' => json_encode($data),
        ]);

        $documentResponse = $client->get("https://api.storecove.com/api/v2/received_documents/{$bodyData['document_guid']}/json", [
            'headers' => [
                'Authorization' => 'Bearer ' . '8EzJrFUTh3gKxm1FkBmq9qQ0wXpkcE-2yA_BGFA6_ag',
                'Content-Type' => 'application/json',
            ],
        ]);

        if ($documentResponse->getStatusCode() !== 200) {
            throw new Exception('Failed to retrieve document. Status code: ' . $documentResponse->getStatusCode());
        }

        $documentData = json_decode($documentResponse->getBody(), true);

        if (empty($documentData)) {
            throw new Exception('Invalid document response structure or empty response.');
        }

        // Save document
        PeppolDocument::create([
            'guid' => $documentData['guid'],
            'webhook_event_id' => $webhookEvent->id,
            'document_data' => json_encode($documentData),
        ]);

        $deleteResponse = $client->delete("https://api.storecove.com/api/v2/webhook_instances/{$data['guid']}", [
            'headers' => [
                'Authorization' => 'Bearer ' . '8EzJrFUTh3gKxm1FkBmq9qQ0wXpkcE-2yA_BGFA6_ag',
            ],
        ]);

        if ($deleteResponse->getStatusCode() === 200) {
            \Log::info("Webhook instance {$data['guid']} deleted successfully.");
        } else {
            \Log::warning("Failed to delete webhook instance {$data['guid']}. Status: " . $deleteResponse->getStatusCode());
        }

        $this->info('Peppol webhook and document saved successfully.');

        // if ($response->getStatusCode() === 200) {
        //     $this->info('Peppol webhook called successfully.');
        // } else {
        //     $this->error('Failed to call Peppol webhook. Status: ' . $response->getStatusCode());
        // }
    }
}
