<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use Carbon\Carbon;
use App\ProductBulkPriceSchedule;
use App\Variation;
use App\VariationGroupPrice;
use Illuminate\Support\Facades\Log;

class BulkUpdatePriceScheduleCron extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'schedule:bulk-update-prices';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Updates product prices based on active schedules';

    /**
     * Create a new command instance.
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     */
    public function handle()
{
    try {
        $currentTime = Carbon::now();
        $this->info("Cron ended at " . Carbon::now()->format('Y-m-d H:i'));
        $schedules = ProductBulkPriceSchedule::where('status', 'active')
            ->get()
            ->filter(function ($schedule) use ($currentTime) {
                $scheduleTime = Carbon::parse($schedule->schedule_date_time);
               // $this->info("Cron ended at ????" .$scheduleTime. $scheduleTime->format('Y-m-d H:i'));
                return $scheduleTime->format('Y-m-d H:i') === Carbon::now()->format('Y-m-d H:i');
            });
        foreach ($schedules as $schedule) {
            $prices = $schedule->prices; // Ensure `prices` is parsed as an array
            $variation = Variation::where('product_id', $schedule->product_id)->first();

            if ($variation) {
                $variation->default_sell_price = $prices['price'] ?? $variation->default_sell_price;
                $variation->member_price = $prices['member_price'] ?? $variation->member_price;
                $variation->save();

                $variationGroupPrices = VariationGroupPrice::where("variation_id", $variation->id)->get();
                $variationGroupPrices->each(function ($variationGroupPrice) use ($prices) {
                $groupId = $variationGroupPrice->price_group_id;
                $variationGroupPrice->price_inc_tax = $prices['groups'][$groupId] ?? $variationGroupPrice->price_inc_tax;
                $variationGroupPrice->save();
                });

                \Log::info("Updated price for product ID: {$schedule->product_id} with schedule ID: {$schedule->id}");
            } else {
                \Log::warning("No variation found for product ID: {$schedule->product_id}");
            }
        }

        $this->info('Price schedules processed successfully.');
    } catch (\Exception $e) {
        \Log::error("Error in BulkUpdatePriceScheduleCron: {$e->getMessage()}");
        $this->error('An error occurred. Check the logs for details.');
    }
}

}
