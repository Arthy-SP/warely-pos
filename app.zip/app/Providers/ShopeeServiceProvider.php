<?php

namespace App\Providers;

use Illuminate\Support\ServiceProvider;
use Illuminate\Support\Facades\Log;
use LazadaSDK\LazopClient;
use LazadaSDK\LazopRequest;
use GuzzleHttp\Client;
use Carbon\Carbon;
use Illuminate\Support\Facades\Cookie;
use App\Business;


class ShopeeServiceProvider extends ServiceProvider
{
    protected $client;
    protected $base_url = 'https://partner.test-stable.shopeemobile.com/api/v2/';
    public function __construct()
    {

        $this->client = new Client([
            'base_uri' => $this->base_url,
            'headers' => [
                'Content-Type' => 'application/json',
            ],
        ]);
    }

    public function getAcessCode()
    {

        session()->forget('shopee_access_token');
        session()->forget('shopee_access_token_expiry');
        session()->forget('shopee_refresh_token');
        session()->forget('shopee_shop_id');
       

        $host = "https://partner.test-stable.shopeemobile.com";

        $business_id = request()->session()->get('business.id');
        $business = Business::find($business_id);
        $lazada_api_settings = json_decode($business->shopee_api_settings);
        $partnerId = $lazada_api_settings->shp_app_id;
        $partnerKey = $lazada_api_settings->shp_scrt_key;
        $shopId = $lazada_api_settings->shp_shop_id;

      
        $path = "/api/v2/shop/auth_partner";
        // $path = "signin/oauth/identifier";
        $redirectUrl = "https://www.google.com/";

        $timest = time();
        $baseString = sprintf("%s%s%s", $partnerId, $path, $timest);
        $sign = hash_hmac('sha256', $baseString, $partnerKey);
        $url = sprintf("%s%s?partner_id=%s&timestamp=%s&sign=%s&redirect=%s", $host, $path, $partnerId, $timest, $sign, urlencode($redirectUrl));
        // return $this->client->execute($url);
        return $url;

        // $response = Http::get($url);

        // https://www.google.com/?code=4368665554705844546d6265695a4a75&shop_id=125041




    }

    public function getTokenShopLevel($access)
    {

        $host = "https://partner.test-stable.shopeemobile.com";
        $path = "/api/v2/auth/token/get";

        $business_id = request()->session()->get('business.id');
        $business = Business::find($business_id);
        $lazada_api_settings = json_decode($business->shopee_api_settings);
        $partnerId = $lazada_api_settings->shp_app_id;
        $partnerKey = $lazada_api_settings->shp_scrt_key;
        $shopId = (int)$lazada_api_settings->shp_shop_id;
        
        // $code ='677943445a634a73515a55667a6e7872';
        $code = $access;
       
        $timest = time();

        $body = [
            "code" => $code,
            "shop_id" => $shopId,
            "partner_id" => $partnerId,
        ];

        $baseString = sprintf("%s%s%s", $partnerId, $path, $timest);
        $sign = hash_hmac('sha256', $baseString, $partnerKey);
        $url = sprintf("%s%s?partner_id=%s&timestamp=%s&sign=%s", $host, $path, $partnerId, $timest, $sign);

        // Initialize Guzzle Client
        $client = new Client();

        try {

            $response = $client->post($url, [
                'json' => $body,
                'headers' => [
                    'Content-Type' => 'application/json',
                ]
            ]);

            $respBody = $response->getBody()->getContents();
            $ret = json_decode($respBody, true);
            return $ret; // This returns the decoded response
        } catch (\GuzzleHttp\Exception\RequestException $e) {

            if ($e->hasResponse()) {

                $errorResponse = $e->getResponse();
                $statusCode = $errorResponse->getStatusCode();
                $errorBody = $errorResponse->getBody()->getContents();
                $errorData = json_decode($errorBody, true);
                $errorMessage = $errorData['message'] ?? 'An unknown error occurred.';
                return ['error' => $errorMessage, 'status_code' => $statusCode];
            } else {
                return ['error' => 'Request failed without a response'];
            }
        }
    }
    public function refreshAccessTokenShop($token, $shop)
    {

        $host = "https://partner.test-stable.shopeemobile.com";
        $path = "/api/v2/auth/access_token/get";

        $business_id = request()->session()->get('business.id');
        $business = Business::find($business_id);
        $lazada_api_settings = json_decode($business->shopee_api_settings);
        $partnerId = (int)$lazada_api_settings->shp_app_id;
        $partnerKey = $lazada_api_settings->shp_scrt_key;
        $shopId = (int)$lazada_api_settings->shp_shop_id;

       
        $refreshToken = $token;
        $timest = time();
        $body = array("partner_id" => $partnerId, "shop_id" => $shopId, "refresh_token" => $refreshToken);
        $baseString = sprintf("%s%s%s", $partnerId, $path, $timest);
        $sign = hash_hmac('sha256', $baseString, $partnerKey);
        $url = sprintf("%s%s?partner_id=%s&timestamp=%s&sign=%s", $host, $path, $partnerId, $timest, $sign);

        // Initialize Guzzle Client
        $client = new Client();

        try {

            $response = $client->post($url, [
                'json' => $body,
                'headers' => [
                    'Content-Type' => 'application/json',
                ]
            ]);

            $respBody = $response->getBody()->getContents();
            $ret = json_decode($respBody, true);

            session()->put('shopee_acess_token', $ret['access_token']);
            session()->put('shopee_access_token_expiry', $ret['expire_in']);
            session()->put('shopee_refresh_token', $ret['refresh_token']);
            session()->put('shopee_shop_id', $ret['shop_id']);
            setcookie("refresh_token", $ret['refresh_token'], time() + $ret['expire_in'], "/", );
            setcookie("shopee_acess_token", $ret['access_token'], time() + $ret['expire_in'], "/", );
         
            // dd($_COOKIE);
            // Log::info(session()->all());
            return $ret; // This returns the decoded response
            
        } catch (\GuzzleHttp\Exception\RequestException $e) {

            if ($e->hasResponse()) {

                $errorResponse = $e->getResponse();
                $statusCode = $errorResponse->getStatusCode();
                $errorBody = $errorResponse->getBody()->getContents();
                $errorData = json_decode($errorBody, true);
                $errorMessage = $errorData['message'] ?? 'An unknown error occurred.';
                return ['error' => $errorMessage, 'status_code' => $statusCode];
            } else {
                return ['error' => 'Request failed without a response'];
            }
        }
    }
    public function shopData($token, $shop)
    {

        $host = "https://partner.test-stable.shopeemobile.com";
        $path = "/api/v2/shop/get_shop_info";

        $business_id = request()->session()->get('business.id');
        $business = Business::find($business_id);
        $lazada_api_settings = json_decode($business->shopee_api_settings);
        $partnerId = (int)$lazada_api_settings->shp_app_id;
        $partnerKey = $lazada_api_settings->shp_scrt_key;
        $shopId = (int)$lazada_api_settings->shp_shop_id;

        $access_token = $token;
        $timestamp = time();


        $tokenBaseString1 = $partnerId . $path . $timestamp . $access_token . $shopId;
        $sign = hash_hmac('sha256', $tokenBaseString1, $partnerKey, false);

        $curl = curl_init();

        curl_setopt_array($curl, array(
            CURLOPT_URL => 'https://partner.test-stable.shopeemobile.com/api/v2/shop/get_shop_info?access_token=' . $access_token . '&language=zh-hans&partner_id=' . $partnerId . '&shop_id=' . $shopId . '&sign=' . $sign . '&timestamp=' . $timestamp,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => '',
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => 'GET',
            CURLOPT_HTTPHEADER => array(
                'Content-Type: application/json'
            ),
        ));

        $response = curl_exec($curl);

        curl_close($curl);
        if ($response) {
            // Convert the JSON response to an array
            $responseArray = json_decode($response, true);  // The second parameter 'true' will return the response as an associative array
            return $responseArray;
        } else {
            return "Error: " . curl_error($curl);
        }
    }
    public function getProductCategory()
    {

        $curl = curl_init();
        $path = "/api/v2/product/get_category";
       
        $business_id = request()->session()->get('business.id');
        $business = Business::find($business_id);
        $lazada_api_settings = json_decode($business->shopee_api_settings);
        $partnerId = (int)$lazada_api_settings->shp_app_id;
        $partnerKey = $lazada_api_settings->shp_scrt_key;
        $shopId = (int)$lazada_api_settings->shp_shop_id;

        $access_token = session()->get('shopee_acess_token');
        $timest = time();
        // $timest = 1729074995;
        $shop_id = (int)env('SHOPEE_SHOP_ID');

        $tokenBaseString1 = $partnerId . $path . $timest . $access_token . $shop_id;
        $sign = hash_hmac('sha256', $tokenBaseString1, $partnerKey, false);

          // dd($sign, $sign1,$sign11);

        curl_setopt_array($curl, array(
            CURLOPT_URL => 'https://partner.test-stable.shopeemobile.com/api/v2/product/get_category?access_token=' . $access_token . '&language=zh-hans&partner_id=' . $partnerId . '&shop_id=' . $shop_id . '&sign=' . $sign . '&timestamp=' . $timest,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => '',
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => 'GET',
            CURLOPT_HTTPHEADER => array(
                'Content-Type: application/json'
            ),
        ));

        $response = curl_exec($curl);

        curl_close($curl);
        $data = json_decode($response, true);
        return $data;
    }
    public function getAttributes($category)
    {

        $curl = curl_init();
        $path = "/api/v2/product/get_attributes";
        
        $business_id = request()->session()->get('business.id');
        $business = Business::find($business_id);
        $lazada_api_settings = json_decode($business->shopee_api_settings);
        $partnerId = (int)$lazada_api_settings->shp_app_id;
        $partnerKey = $lazada_api_settings->shp_scrt_key;
        $shop_id = (int)$lazada_api_settings->shp_shop_id;

        $access_token = session()->get('shopee_acess_token');
        $timest = time();
        
        $tokenBaseString1 = $partnerId . $path . $timest . $access_token . $shop_id;
        $sign = hash_hmac('sha256', $tokenBaseString1, $partnerKey, false);
      
        curl_setopt_array($curl, array(
            CURLOPT_URL => 'https://partner.test-stable.shopeemobile.com/api/v2/product/get_attributes?access_token=' . $access_token . '&category_id='.$category.'&language=zh-hans&partner_id=' . $partnerId . '&shop_id=' . $shop_id . '&sign=' . $sign . '&timestamp=' . $timest,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => '',
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => 'GET',
            CURLOPT_HTTPHEADER => array(
                'Content-Type: application/json'
            ),
        ));

        $response = curl_exec($curl);

        curl_close($curl);
        $data = json_decode($response, true);
        return $data;
    }
    
    public function getAttributeTree($category_id)
    {

        $path = "/api/v2/product/get_attribute_tree";
        
        $business_id = request()->session()->get('business.id');
        $business = Business::find($business_id);
        $lazada_api_settings = json_decode($business->shopee_api_settings);
        $partnerId = (int)$lazada_api_settings->shp_app_id;
        $partnerKey = $lazada_api_settings->shp_scrt_key;
        $shop_id = (int)$lazada_api_settings->shp_shop_id;

        $access_token = session()->get('shopee_acess_token');
        $timest = time();
        
        $tokenBaseString1 = $partnerId . $path . $timest . $access_token . $shop_id;
        $sign = hash_hmac('sha256', $tokenBaseString1, $partnerKey, false);

        $curl = curl_init();

        curl_setopt_array($curl, array(
            CURLOPT_URL => 'https://partner.test-stable.shopeemobile.com/api/v2/product/get_attribute_tree?access_token=' . $access_token . '&category_id_list='.$category_id.'&language=zh-hans&partner_id=' . $partnerId . '&shop_id=' . $shop_id . '&sign=' . $sign . '&timestamp=' . $timest,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => '',
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => 'GET',
            CURLOPT_HTTPHEADER => array(
                'Content-Type: application/json'
            ),
        ));

        $response = curl_exec($curl);

        curl_close($curl);

        return $response;
    }
    public function getItemList()
    {

        $path = "/api/v2/product/get_item_list";
       
        $business_id = request()->session()->get('business.id');
        $business = Business::find($business_id);
        $lazada_api_settings = json_decode($business->shopee_api_settings);
        $partnerId = (int)$lazada_api_settings->shp_app_id;
        $partnerKey = $lazada_api_settings->shp_scrt_key;
        $shop_id = (int)$lazada_api_settings->shp_shop_id;

        $access_token = session()->get('shopee_acess_token');
        $timest = time();
       
        $tokenBaseString1 = $partnerId . $path . $timest . $access_token . $shop_id;
        $sign = hash_hmac('sha256', $tokenBaseString1, $partnerKey, false);

        $curl = curl_init();



        curl_setopt_array($curl, array(
            CURLOPT_URL => 'https://partner.test-stable.shopeemobile.com/api/v2/product/get_item_list?access_token=' . $access_token . '&item_status=NORMAL&offset=0&page_size=10&partner_id=' . $partnerId . '&shop_id=' . $shop_id . '&sign=' . $sign . '&timestamp=' . $timest . '&update_time_from=1611311600&update_time_to=1611311631',
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => '',
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => 'GET',
            CURLOPT_HTTPHEADER => array(
                'Content-Type: application/json'
            ),
        ));

        $response = curl_exec($curl);

        curl_close($curl);

        return $response;
    }
    public function getBrandlist($category)
    {

        $path = "/api/v2/product/get_brand_list";
       
        $business_id = request()->session()->get('business.id');
        $business = Business::find($business_id);
        $lazada_api_settings = json_decode($business->shopee_api_settings);
        $partnerId = (int)$lazada_api_settings->shp_app_id;
        $partnerKey = $lazada_api_settings->shp_scrt_key;
        $shop_id = (int)$lazada_api_settings->shp_shop_id;

        $access_token = session()->get('shopee_acess_token');
        $timest = time();

        $tokenBaseString1 = $partnerId . $path . $timest . $access_token . $shop_id;
        $sign = hash_hmac('sha256', $tokenBaseString1, $partnerKey, false);

        $curl = curl_init();


        curl_setopt_array($curl, array(
            CURLOPT_URL => 'https://partner.test-stable.shopeemobile.com/api/v2/product/get_brand_list?access_token=' . $access_token . '&category_id='.$category.'&language=zh-hans&offset=0&page_size=10&partner_id=' . $partnerId . '&shop_id=' . $shop_id . '&sign=' . $sign . '&status=1&timestamp=' . $timest,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => '',
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => 'GET',
            CURLOPT_HTTPHEADER => array(
                'Content-Type: application/json'
            ),
        ));

        $response = curl_exec($curl);

        curl_close($curl);

        $data = json_decode($response, true);
        return $data;
    }
    public function imageUpload()
    {

        $path = "/api/v2/media_space/upload_image";
       
        $business_id = request()->session()->get('business.id');
        $business = Business::find($business_id);
        $lazada_api_settings = json_decode($business->shopee_api_settings);
        $partnerId = (int)$lazada_api_settings->shp_app_id;
        $partnerKey = $lazada_api_settings->shp_scrt_key;
        $shop_id = (int)$lazada_api_settings->shp_shop_id;


        $access_token = session()->get('shopee_acess_token');
        $timest = time();
       

        $tokenBaseString1 = $partnerId . $path . $timest;
        $sign = hash_hmac('sha256', $tokenBaseString1, $partnerKey, false);

        $curl = curl_init();

        curl_setopt_array($curl, array(
            CURLOPT_URL => 'https://partner.test-stable.shopeemobile.com/api/v2/media_space/upload_image?partner_id=' . $partnerId . '&sign=' . $sign . '&timestamp=' . $timest,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => '',
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => 'POST',
            CURLOPT_POSTFIELDS => array('image' => new \CURLFILE('https://stage.warelypos.com/img/default.png') /* Replace with actual file path */),
            CURLOPT_HTTPHEADER => array(
                'Content-Type: multipart/form-data'
            ),
        ));

        $response = curl_exec($curl);

        curl_close($curl);

        return $response;
    }
    public function AddItem()
    {

        $path = "/api/v2/product/add_item";
      
        $business_id = request()->session()->get('business.id');
        $business = Business::find($business_id);
        $lazada_api_settings = json_decode($business->shopee_api_settings);
        $partnerId = (int)$lazada_api_settings->shp_app_id;
        $partnerKey = $lazada_api_settings->shp_scrt_key;
        $shop_id = (int)$lazada_api_settings->shp_shop_id;

        $access_token = session()->get('shopee_acess_token');
        $timest = time();

        $tokenBaseString1 = $partnerId . $path . $timest . $access_token . $shop_id;
        $sign = hash_hmac('sha256', $tokenBaseString1, $partnerKey, false);

        $curl = curl_init();
        // https://partner.test-stable.shopeemobile.com/api/v2/product/get_item_list?access_token='.$access_token.'&item_status=NORMAL&offset=0&page_size=10&partner_id='.$partnerId.'&shop_id='. $shop_id.'&sign='.$sign.'&timestamp='.$timest.'&update_time_from=1611311600&update_time_to=1611311631',


        curl_setopt_array($curl, array(
            CURLOPT_URL => 'https://partner.test-stable.shopeemobile.com/api/v2/product/add_item?access_token=' . $access_token . '&partner_id=' . $partnerId . '&shop_id=' . $shop_id . '&sign=' . $sign . '&timestamp=' . $timest,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => '',
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => 'POST',
            CURLOPT_POSTFIELDS => '{
             "original_price": 123.3,
             "description": "item description test",
             "weight": 1.1,
             "item_name": "Item Name Example",
             "item_status": "UNLIST",
             "dimension": {
                  "package_height": 11,
                  "package_length": 11,
                  "package_width": 11
              },
              "normal_stock": 33,
              "logistic_info": [
                  {
                      "enabled": true,
                      "is_free": true,
                      "logistic_id": 80101,
                      "shipping_fee": 23.12,
                      "size_id": 0
                  }
              ],

             "attribute_list": [
                  {
                      "attribute_id": 100002,
                      "attribute_value_list": [
                          {
                              "original_value_name": "Brand",
                              "value_id": 32142,
                              "value_unit": " kg"
                          }
                      ]
                  }
            ],
            "category_id": 102064,
            "image": {
                  "image_id_list": [
                      "sg-11134201-7r98o-m1i0vi3rgh7dc8"
                  ]
              },
              "pre_order": {
                  "days_to_ship": 3,
                  "is_pre_order": true
              },
              "item_sku": "-",
              "condition": "NEW",
              "wholesale": [
                  {
                      "max_count": 100,
                      "min_count": 1,
                      "unit_price": 28.3
                  }
              ],
              "brand": {
                  "brand_id": 1115115,
                  "original_brand_name": "kfg"
              },
              "item_dangerous": 0,
              
             "seller_stock": [
                  {
                      "location_id": "-",
                      "stock": 0
                  }
              ],
                                         
              "description_type": "normal"
              
          }',
            CURLOPT_HTTPHEADER => array(
                'Content-Type: application/json'
            ),
        ));

        $response = curl_exec($curl);

        curl_close($curl);

        return $response;
    }
    public function getOrderList()
    {

        $path = "/api/v2/order/get_order_list";
      
        $business_id = request()->session()->get('business.id');
        $business = Business::find($business_id);
        $lazada_api_settings = json_decode($business->shopee_api_settings);
        $partnerId = (int)$lazada_api_settings->shp_app_id;
        $partnerKey = $lazada_api_settings->shp_scrt_key;
        $shop_id = (int)$lazada_api_settings->shp_shop_id;

        $access_token = session()->get('shopee_acess_token');
        $timest = time();
       

        $tokenBaseString1 = $partnerId . $path . $timest . $access_token . $shop_id;
        $sign = hash_hmac('sha256', $tokenBaseString1, $partnerKey, false);

        $curl = curl_init();

        curl_setopt_array($curl, array(
            CURLOPT_URL => 'https://partner.test-stable.shopeemobile.com/api/v2/order/get_order_list?access_token=' . $access_token . '&cursor=%22%22&order_status=READY_TO_SHIP&page_size=20&partner_id=' . $partnerId . '&response_optional_fields=order_status&shop_id=' . $shop_id . '&sign=' . $sign . '&time_from=1607235072&time_range_field=create_time&time_to=1608271872&timestamp=' . $timest,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => '',
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => 'GET',
            CURLOPT_HTTPHEADER => array(
                'Content-Type: application/json'
            ),
        ));

        $response = curl_exec($curl);

        curl_close($curl);
        return  $response;
    }
    public function getLogistic($session_acess_token){
       
        $business_id = request()->session()->get('business.id');
        $business = Business::find($business_id);
        $lazada_api_settings = json_decode($business->shopee_api_settings);
        $partnerId = (int)$lazada_api_settings->shp_app_id;
        $partnerKey = $lazada_api_settings->shp_scrt_key;
        $shop_id = (int)$lazada_api_settings->shp_shop_id;

        $access_token = $session_acess_token;
        $path = "/api/v2/logistics/get_channel_list";
        // $path = "/api/v2/logistics/list";
        $timest = time();

        $tokenBaseString1 = $partnerId . $path . $timest . $access_token . $shop_id;
        $sign = hash_hmac('sha256', $tokenBaseString1, $partnerKey, false);

        $curl = curl_init();
        curl_setopt_array($curl, array(
            CURLOPT_URL => 'https://partner.test-stable.shopeemobile.com/api/v2/logistics/get_channel_list?access_token=' . $access_token . '&partner_id=' . $partnerId . '&shop_id=' . $shop_id . '&sign=' . $sign . '&timestamp=' . $timest,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => '',
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => 'GET',
            CURLOPT_HTTPHEADER => array(
                'Content-Type: application/json'
            ),
        ));

        $response = curl_exec($curl);

        curl_close($curl);
        dd($response) ;


        
    }
}
