<?php

namespace App\Providers;

use Illuminate\Support\ServiceProvider;

use LazadaSDK\LazopClient;
use LazadaSDK\LazopRequest;
use GuzzleHttp\Client;
use Carbon\Carbon;
use App\EcommerceSettings;
use Illuminate\Support\Facades\DB;
use App\Business;
// Your code here


class LazadaServiceProvider extends ServiceProvider
{
    protected $client;
    public function __construct()
    {

        $this->client = new LazopClient('https://api.lazada.com/rest', '130577', '0sdBFSt3qaacsKCbClIRewmoJHDWavTG');
    }

    public function getLazadaCode()
    {
        https: //auth.lazada.com/oauth/authorize?response_type=code&force_auth=true&redirect_uri=https://www.fabulousnaturals.com/&client_id=130703

    }
    public function getCategoryTree()
    {
        // $app_id = env('LAZADA_API_KEY');
        // $secret = env('LAZADA_API_SECRET_KEY');
        $url = env('LAZADA_API_SANDBOX_URL');

        $business_id = request()->session()->get('business.id');
        $business = Business::find($business_id);
        $lazada_api_settings = json_decode($business->lazada_api_settings);
        $secret = $lazada_api_settings->lazada_api_secret_key;
        $app_id = $lazada_api_settings->lazada_api_key;

        $c = new LazopClient($url, $app_id, $secret);
        $request = new LazopRequest('/category/tree/get', 'GET');
        $request->addApiParam('language_code', 'en_US');
        $res = $c->execute($request);
        $array = json_decode($res, true);
        return response()->json($array);
    }
 
    public function getAcessToken($code)
    {
        // $app_id = env('LAZADA_API_KEY');
        // $secret = env('LAZADA_API_SECRET_KEY');
        $url = env('LAZADA_API_SANDBOX_URL');
        $business_id = request()->session()->get('business.id');
        $business = Business::find($business_id);
        $lazada_api_settings = json_decode($business->lazada_api_settings);
        $secret = $lazada_api_settings->lazada_api_secret_key;
        $app_id = $lazada_api_settings->lazada_api_key;

        $timeStamp = $this->msectime();

        $options = [
            'app_key' => $app_id,
            'timestamp' => $timeStamp,
            'sign_method' => 'sha256',
            'code' => $code,
            'dateStart' => '2021-11-01',
            'dateEnd' => '2021-11-15',
            'offerId' => 'YOUR_OFFER_ID', // Replace with actual offer ID
            'limit' => 10,
            'page' => 1,
        ];

        $signature = $this->generateSign('/auth/token/create', $options, $secret);
        $options['sign'] = $signature;

        $url = "https://api.lazada.com.my/rest/auth/token/create";


        $client = new \GuzzleHttp\Client();
        try {
            // Send the GET request
            $response = $client->request('GET', $url, [
                'query' => $options
            ]);
            $values = [
                "access_token" => "50000201032qBWtaazKuCnSdUpfXGcp9NV0hijSiyhUy1b97aa769ExErR5bzSVp",
                "country" => "sg",
                "refresh_token" => "50001200d329xtrwoqEZYlWgKqcsTeWhDTApuzlhgNK119116f99dStFfZd6z7zs",
                "account_platform" => "seller_center",
                "refresh_expires_in" => 2592000,
                "expires_in" => 604800,
                "account" => "LzdOp_SG_test@163.com",
                "code" => "0",
                "request_id" => "2141152817298494830135343",
            ];

            // Get the response body
            $body = $response->getBody()->getContents();
            $tokens = json_decode($body, true);

            return $tokens;
            // return $values;

        } catch (RequestException $e) {
            // Handle the exception
            return [
                'error' => true,
                'message' => $e->getMessage(),
                'response' => $e->getResponse() ? $e->getResponse()->getBody()->getContents() : null,
            ];
        }
    }

    public function refreshToken($refresh_token)
    {
        // $app_id = env('LAZADA_API_KEY');
        // $secret = env('LAZADA_API_SECRET_KEY');
        $url = env('LAZADA_API_SANDBOX_URL');
        $business_id = request()->session()->get('business.id');
        $business = Business::find($business_id);
        $lazada_api_settings = json_decode($business->lazada_api_settings);
        $secret = $lazada_api_settings->lazada_api_secret_key;
        $app_id = $lazada_api_settings->lazada_api_key;

        $c = new LazopClient($url, $app_id, $secret);
        $request = new LazopRequest('/auth/token/refresh');
        $request->addApiParam('refresh_token', $refresh_token);
        $new_refresh = $c->execute($request);
        $data = json_decode($new_refresh, true);

        if (isset($data['code']) && $data['code'] == 0) {
            $refresh_token = $data['refresh_token'];
            $acess = $data['access_token'];
            $accessTokenExpiry = Carbon::now()->addSeconds($data['expires_in']);
            $refreshTokenExpiry = Carbon::now()->addSeconds($data['refresh_expires_in']);

            DB::beginTransaction();
            $insertData = [
                'access_token' => $acess,
                'acess_expiry_seconds' => $data['expires_in'],
                'refresh_token' => $refresh_token,
                'refresh_expiry_seconds' => $data['refresh_expires_in'],
                'type' => 'lazada',
                'created_at' => now(),
                'updated_at' => now(),
            ];
            if (DB::table('ecommerce_settings')->where('type', 'lazada')->get()->count() > 0) {
                DB::table('ecommerce_settings')->update([
                    'access_token' => $acess,
                    'acess_expiry_seconds' => $data['expires_in'],
                    'refresh_token' => $refresh_token,
                    'refresh_expiry_seconds' => $data['refresh_expires_in'],
                    'updated_at' => now(),

                ]);
            } else {
                DB::table('ecommerce_settings')->insert($insertData);
            }

            DB::commit();
            session()->put([
                'lazada_acess_token' =>  $acess,
                'access_token_expiry' => $accessTokenExpiry,
                'lazada_refresh_token' => $refresh_token,
                'refresh_token_expiry' => $refreshTokenExpiry,
                'lazada_country' => $data['country'],
                'lazada_account' => $data['account'],
                'lazada_seller_id' => $data['country_user_info_list'][0]['seller_id'],

            ]);
        } else {
            session()->forget('lazada_refresh_token');
        }


        return  $data;
    }
    public function GetBrandByPages($acess_token)
    {

        // $app_id = env('LAZADA_API_KEY');
        // $secret = env('LAZADA_API_SECRET_KEY');
        $url = env('LAZADA_API_SANDBOX_URL');

        $user_token = $acess_token;

        $business_id = request()->session()->get('business.id');
        $business = Business::find($business_id);
        $lazada_api_settings = json_decode($business->lazada_api_settings);
        $secret = $lazada_api_settings->lazada_api_secret_key;
        $app_id = $lazada_api_settings->lazada_api_key;
        // new code

        $c = new LazopClient($url, $app_id, $secret);
        $allBrands = [];
        $startRow = 0;
        $pageSize = 100;
        $allData = [];
        do {
            $request = new LazopRequest('/brands/get');
            // $request = new LazopRequest('/category/brands/query');
            $request->addApiParam('startRow', $startRow);
            $request->addApiParam('pageSize', $pageSize);

            $response = $c->execute($request);
            $data = json_decode($response, true);

            // Check if brands exist in the response
            if (isset($data['data']['module']) && is_array($data['data']['module'])) {
                $allData = array_merge($allData, $data['data']['module']);
                $startRow += $pageSize; // Increment to the next batch
            } else {
                break; // Break the loop if there's no more data
            }
            // dd($allData);exit;
        } while (count($data['brands']) === $pageSize); // Continue until less than pageSize results are returned


    }
    public function getProductList()
    {
        $app_id = env('LAZADA_API_KEY');
        $secret = env('LAZADA_API_SECRET_KEY');
        $url = env('LAZADA_API_SANDBOX_URL');
        $user_token = session()->get('lazada_acess_token');

   
        //  using SDK starts
        $c = new LazopClient($url, '130703', '5LkQtXXYaGc1wGyCvQ7dKT86BmHXJ4nV');
        $request = new LazopRequest('/products/get', 'GET');
        // $request->addApiParam('filter','live');
        // $request->addApiParam('update_before','2024-09-01T00:00:00+0800');
        // $request->addApiParam('create_before','2024-09-01T00:00:00+0800');
        $request->addApiParam('offset', '0');
        // $request->addApiParam('create_after','2010-01-01T00:00:00+0800');
        // $request->addApiParam('update_after','2010-01-01T00:00:00+0800');
        $request->addApiParam('limit', '10');
        $request->addApiParam('options', '1');
        // $request->addApiParam('sku_seller_list',' [\"39817:01:01\", \"Apple 6S Black\"]');
        // $ss = var_dump($c->execute($request, $user_token));
        $ss = $c->execute($request, $user_token);
        return $ss;
        //  using SDK Ends
    }
    public function getConversionReport()
    {
        // $app_id = env('LAZADA_API_KEY');
        // $secret = env('LAZADA_API_SECRET_KEY');
        $url = env('LAZADA_API_SANDBOX_URL');
        $user_token = session()->get('lazada_acess_token');
        $business_id = request()->session()->get('business.id');
        $business = Business::find($business_id);
        $lazada_api_settings = json_decode($business->lazada_api_settings);
        $secret = $lazada_api_settings->lazada_api_secret_key;
        $app_id = $lazada_api_settings->lazada_api_key;

        $timeStamp = $this->msectime();

        $options = [
            'app_key' => $app_id,
            'timestamp' => $timeStamp,
            'sign_method' => 'sha256',
            'userToken' => $user_token,
            'access_token' => $user_token,
            'dateStart' => '2021-11-01',
            'dateEnd' => '2021-11-15',
            'offerId' => 'YOUR_OFFER_ID', // Replace with actual offer ID
            'limit' => 10,
            'page' => 1,
        ];

        $signature = $this->generateSign('/marketing/conversion/report', $options, $secret);

        $options['sign'] = $signature;

        $url = "https://api.lazada.com.my/rest/marketing/conversion/report";

        // Send the GET request
        $response = Http::get($url, $options);

        return $response;
    }
    public function GetSellerItemLimit()
    {

        // $app_id = env('LAZADA_API_KEY');
        // $secret = env('LAZADA_API_SECRET_KEY');
        $url = env('LAZADA_API_SANDBOX_URL');
        $user_token = session()->get('lazada_acess_token');
        $business_id = request()->session()->get('business.id');
        $business = Business::find($business_id);
        $lazada_api_settings = json_decode($business->lazada_api_settings);
        $secret = $lazada_api_settings->lazada_api_secret_key;
        $app_id = $lazada_api_settings->lazada_api_key;

        $timeStamp = $this->msectime();

        $options = [
            'app_key' => $app_id,
            'timestamp' => $timeStamp,
            'sign_method' => 'sha256',
            'userToken' => $user_token,
            'access_token' => $user_token,
            'dateStart' => '2021-11-01',
            'dateEnd' => '2021-11-15',
            'offerId' => 'YOUR_OFFER_ID', // Replace with actual offer ID
            'limit' => 10,
            'page' => 1,
        ];

        $signature = $this->generateSign('/product/seller/item/limit', $options, $secret);

        $options['sign'] = $signature;

        $url = "https://api.lazada.com.my/rest/product/seller/item/limit";

        // Send the GET request
        $response = Http::get($url, $options);

        return $response;
    }

    public function createProduct($payload, $token)
    {
        // $apiKey = env('LAZADA_API_KEY');
        // $secretKey = env('LAZADA_API_SECRET_KEY');
        $url = env('LAZADA_API_SANDBOX_URL');
        $business_id = request()->session()->get('business.id');
        $business = Business::find($business_id);
        $lazada_api_settings = json_decode($business->lazada_api_settings);
        $secretKey = $lazada_api_settings->lazada_api_secret_key;
        $apiKey = $lazada_api_settings->lazada_api_key;
        $user_token = $token;

        $c = new LazopClient($url, $apiKey, $secretKey);
        $request = new LazopRequest('/product/create');
        $request->addApiParam('payload', $payload);
        $st = $c->execute($request, $user_token);

        return $st;
    }
    private function hmac_sha256($data, $key)
    {
        return hash_hmac('sha256', $data, $key);
    }

    private function msectime()
    {
        return round(microtime(true) * 1000);
    }

    private function generateSign($apiName, $params, $secret)
    {
        ksort($params);
        $stringToBeSigned = $apiName;

        foreach ($params as $k => $v) {
            // $stringToBeSigned .= "$k$v";

            if (is_array($v)) {

                $stringToBeSigned .= $this->flattenArray($v);
                // $stringToBeSigned .= $k . implode('', $v);
            } else {
                $stringToBeSigned .= "$k$v";
            }
        }

        return strtoupper($this->hmac_sha256($stringToBeSigned, $secret));
    }

    public function ImageUpload($img = '')
    {

        // $apiKey = env('LAZADA_API_KEY');
        // $secretKey = env('LAZADA_API_SECRET_KEY');
        $url = env('LAZADA_API_SANDBOX_URL');

        $business_id = request()->session()->get('business.id');
        $business = Business::find($business_id);
        $lazada_api_settings = json_decode($business->lazada_api_settings);
        $secretKey = $lazada_api_settings->lazada_api_secret_key;
        $apiKey = $lazada_api_settings->lazada_api_key;

        $user_token = session()->get('lazada_acess_token');
        $c = new LazopClient($url, $apiKey, $secretKey);
        $request = new LazopRequest('/image/migrate');
        $img = asset('uploads\img' . $img);
        $request->addApiParam('payload', '<?xml version="1.0" encoding="UTF-8" ?> <Request><Image><Url>https://stage.warelypos.com/img/default.png</Url></Image> </Request>');
        // var_dump($c->execute($request, $user_token));

        $st = $c->execute($request, $user_token);
        $arrayData = json_decode($st, true);
        if ($arrayData['code'] == 0) {
            $img_url = $arrayData['data']['image']['url'];
        } else {
            $img_url = '';
        }
        return  $img_url;
    }
    public function UpdateProduct($payload)
    {
        // $apiKey = env('LAZADA_API_KEY');
        // $secretKey = env('LAZADA_API_SECRET_KEY');
        $url = env('LAZADA_API_SANDBOX_URL');
        $business_id = request()->session()->get('business.id');
        $business = Business::find($business_id);
        $lazada_api_settings = json_decode($business->lazada_api_settings);
        $secretKey = $lazada_api_settings->lazada_api_secret_key;
        $apiKey = $lazada_api_settings->lazada_api_key;

        $user_token = session()->get('lazada_acess_token');

        $c = new LazopClient($url, $apiKey, $secretKey);
        $request = new LazopRequest('/product/update');
        $request->addApiParam('payload', $payload);
        $st = $c->execute($request, $user_token);
        // $st = $c->execute($request, $user_token);
      
        return $st;
    }

    public function getOrderdata($acess_token)
    {
        // $apiKey = env('LAZADA_API_KEY');
        // $secretKey = env('LAZADA_API_SECRET_KEY');
        $url = env('LAZADA_API_SANDBOX_URL');

        $business_id = request()->session()->get('business.id');
        $business = Business::find($business_id);
        $lazada_api_settings = json_decode($business->lazada_api_settings);
        $secretKey = $lazada_api_settings->lazada_api_secret_key;
        $apiKey = $lazada_api_settings->lazada_api_key;

        $update_before = Carbon::now('Asia/Singapore')->format('Y-m-d\TH:i:sP');
        $created_after = Carbon::now('Asia/Singapore')->subMinute(2)->format('Y-m-d\TH:i:sP');

        $user_token = $acess_token ?? '';
        $c = new LazopClient($url, $apiKey, $secretKey);
        $request = new LazopRequest('/orders/get', 'GET');
        $request->addApiParam('update_before', $update_before);
        $request->addApiParam('sort_direction', 'DESC');
        $request->addApiParam('offset', '0');
        $request->addApiParam('limit', '30');
        // $request->addApiParam('update_after','2017-02-10T09:00:00+08:00');
        $request->addApiParam('sort_by', 'updated_at');
        // $request->addApiParam('created_before','2018-02-10T16:00:00+08:00');
        $request->addApiParam('created_after', $created_after);
        // $request->addApiParam('status', 'shipped');
        $response = $c->execute($request, $user_token);

        $data = json_decode($response, true);

        return $data['data']['orders'];
    }
    public function getOrderItem($acess_token, $order_ids)
    {
        // $apiKey = env('LAZADA_API_KEY');
        // $secretKey = env('LAZADA_API_SECRET_KEY');
        $url = env('LAZADA_API_SANDBOX_URL');

        $business_id = request()->session()->get('business.id');
        $business = Business::find($business_id);
        $lazada_api_settings = json_decode($business->lazada_api_settings);
        $secretKey = $lazada_api_settings->lazada_api_secret_key;
        $apiKey = $lazada_api_settings->lazada_api_key;

        $orderIdsString = '[' . implode(',', $order_ids) . ']';

        $user_token = $acess_token;

        $c = new LazopClient($url, $apiKey, $secretKey);
        $request = new LazopRequest('/orders/items/get', 'GET');
        $request->addApiParam('order_ids', $orderIdsString);
        $response = $c->execute($request, $user_token);

        $data = json_decode($response, true);

        return $data['data'];
    }


    public function getCategories($categories)
    {
        $result = [];

        foreach ($categories as $category) {
            if (isset($category['children']) && is_array($category['children'])) {
                $result[] = [
                    'name' => $category['name'],
                    'category_id' => $category['category_id'],
                    'children' => $this->getCategories($category['children'])  // Call recursively
                ];
            } else {
                $result[] = [
                    'name' => $category['name'],
                    'category_id' => $category['category_id']
                ];
            }
        }
        dd($categories);
        return $result;
    }
    public function removeProduct($skuIdsJson)
    {
        // $apiKey = env('LAZADA_API_KEY');
        // $secretKey = env('LAZADA_API_SECRET_KEY');
        $url = env('LAZADA_API_SANDBOX_URL');
        $accessToken = session()->get('lazada_acess_token');

        $business_id = request()->session()->get('business.id');
        $business = Business::find($business_id);
        $lazada_api_settings = json_decode($business->lazada_api_settings);
        $secretKey = $lazada_api_settings->lazada_api_secret_key;
        $apiKey = $lazada_api_settings->lazada_api_key;


        $c = new LazopClient($url, $apiKey, $secretKey);
        $request = new LazopRequest('/product/remove');
        $request->addApiParam('seller_sku_list', '[\"test00111\",\"test00222\",\"test00333\"]');
        $request->addApiParam('sku_id_list', $skuIdsJson);
        $response = $c->execute($request, $accessToken);
        $data = json_decode($response, true);
        return $data;
    }
    public function GetCategoryAttribute($cat_id)
    {
      
        // $apiKey = env('LAZADA_API_KEY');
        // $secretKey = env('LAZADA_API_SECRET_KEY');
        $url = env('LAZADA_API_SANDBOX_URL');
        
        $accessToken = session()->get('lazada_acess_token');
        $business_id = request()->session()->get('business.id');
        $business = Business::find($business_id);
        $lazada_api_settings = json_decode($business->lazada_api_settings);
        $secretKey = $lazada_api_settings->lazada_api_secret_key;
        $apiKey = $lazada_api_settings->lazada_api_key;


        $c = new LazopClient($url, $apiKey, $secretKey);
        $request = new LazopRequest('/category/attributes/get', 'GET');
        $request->addApiParam('primary_category_id', $cat_id);
        $request->addApiParam('language_code', 'en_US');
        $response = $c->execute($request, $accessToken);
        $json_data = json_decode($response, true);
        $data= $json_data['data'];


        $mandatoryAttributes = array_filter($data, function($item) {
            return isset($item['is_mandatory']) && $item['is_mandatory'] == 1 && isset($item['attribute_type']) && $item['attribute_type'] == 'normal';
        });
        
        // if($data['code'] ==0){
        //     $name = $data['data']
        // }
       
        return $mandatoryAttributes;
    }
}
