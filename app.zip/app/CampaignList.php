<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class CampaignList extends Model
{
    //
    protected $casts = [
        'location_id' => 'array'
    ];
    protected $guarded = [];
}
