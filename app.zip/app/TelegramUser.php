<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class TelegramUser extends Model
{
    use SoftDeletes;
    //
    protected $guarded = ['id'];
    public function channels(){
        return $this->belongsToMany(TelegramChannel::class, 'telegram_user_telegram_channels')->where('type', 'channel')->withPivot('old_status', 'new_status', 'referred_by', 'action_taken_by');
    }

    public function groups(){
        return $this->belongsToMany(TelegramChannel::class, 'telegram_user_telegram_channels')->where('type', 'supergroup')->withPivot('old_status', 'new_status', 'referred_by', 'action_taken_by');
    }

    public function referral_channels(){
        return $this->belongsToMany(TelegramChannel::class, 'telegram_user_telegram_channels')->withPivot('referral_by', 'referral_to', 'status');
    }
}
