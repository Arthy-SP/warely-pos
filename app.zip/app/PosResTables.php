<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class PosResTables extends Model
{
    /**
     * The attributes that aren't mass assignable.
     *
     * @var array
     */
    protected $guarded = ['id'];
    protected $table = 'pos_res_tables';
    protected $fillable = ['transaction_id', 'res_table_id', 'pax','seated', 'app_order_id', 'manage_queue_id', 'is_parent'];
    
    public function transaction()
    {
        return $this->belongsTo(\App\Transaction::class);
    }

    public function table()
    {
        return $this->belongsTo(\App\Restaurant\ResTable::class, 'res_table_id');
    }
}