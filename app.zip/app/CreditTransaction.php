<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class CreditTransaction extends Model
{
        protected $fillable = [
            'transaction_type', 'payment_type', 'amount', 'remark', 'business_id', 'location_id', 'credit_id', 'transaction_id', 'balance_credit', 'credit_promo_id', 'is_void', 'void_reason'
        ];
    
        protected $casts = [
            'transaction_id' => 'integer',
            'credit_id' => 'integer',
        ];
    
        public function credit()
        {
            return $this->belongsTo(Credit::class, 'credit_id'); 
        }
    
    
}
