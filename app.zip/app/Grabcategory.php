<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Grabcategory extends Model
{
    protected $fillable = ['name', 'parent_id', 'product_id', 'grab_id']; 

    public function parent()
    {
        return $this->belongsTo(Grabcategory::class, 'parent_id');
    }

    public function children()
    {
        return $this->hasMany(Grabcategory::class, 'parent_id');
    }

    public function product()
    {
        return $this->belongsTo(Product::class, 'product_id'); 
    }
}
