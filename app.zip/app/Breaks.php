<?php
namespace App;

use Illuminate\Database\Eloquent\Model;

class Breaks extends Model
{
    protected $table = 'breaks';

    protected $fillable = [
        'session_id',
        'break_start_time',
        'break_end_time',
        'user_id',
        'business_id',
        'location_id',
        'terminal_id',
    ];
}
