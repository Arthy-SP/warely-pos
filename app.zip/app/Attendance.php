<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Attendance extends Model
{
    protected $fillable = [
        'attendee_user_id',
        'user_id',
        'clockin_time',
        'clockout_time',
        'is_on_break',
        'business_id',
        'location_id',
        'terminal_id',
        'clockin_date',
        'clockout_date',
        'last_activity_at'
    ];
}

