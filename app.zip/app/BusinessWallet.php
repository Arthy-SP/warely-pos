<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;


class BusinessWallet extends Model
{
    use SoftDeletes;

    protected $table = 'business_wallets';

    protected $fillable = [
        'balance',
        'status',
        'remark',
        'business_id',
        "service_charge",
        'created_by'
    ];
}
