<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class DisplayImages extends Model
{
    use SoftDeletes;

    /**
     * The attributes that aren't mass assignable.
     *
     * @var array
     */
    protected $guarded = ['id'];

    protected $appends = ['image_url'];

    /**
     * Get the queue display image.
     *
     * @return string
     */
    public function getImageUrlAttribute()
    {
        if (!empty($this->image)) {
            // $image_url = asset('/uploads/img/' . rawurlencode($this->image));
            $image_url = config('constants.awsS3BaseUrl') . "/" . config('constants.awsS3Env') . "/display_images/" . $this->image;
        } else {
            $image_url = asset('/img/default.png');
        }
        return $image_url;
    }
    
    /**
    * Get the queue display image path.
    *
    * @return string
    */
    public function getImagePathAttribute()
    {
        if (!empty($this->image)) {
            // $image_path = public_path('uploads') . '/' . config('constants.product_img_path') . '/' . $this->image;
            $image_path = config('constants.awsS3BaseUrl') . "/" . config('constants.awsS3Env') . "/display_images/" . $this->image;
        } else {
            $image_path = null;
        }
        return $image_path;
    }
}
