<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
class NfcCard extends Model
{
    use SoftDeletes;
    
    protected $fillable = [
        'card_no', 'status', 'balance', 'remark', 'business_id', 'location_id', 'nfc_meta_data', 'sr_no','is_verified','user_id','created_at',
        'updated_at'
    ];


    public function transactions()
    {
        return $this->hasMany(NfcTransaction::class, 'nfc_card_id');
    }

}
