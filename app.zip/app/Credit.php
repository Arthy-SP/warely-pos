<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;


class Credit extends Model
{
    use SoftDeletes;
    protected $table = 'credits';

    protected $fillable = [
        'phone_number', 'status', 'balance', 'remark', 'business_id', 'location_id', 'contact_id'
    ];
}
