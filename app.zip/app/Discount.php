<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Discount extends Model
{
    /**
     * The attributes that should be mutated to dates.
     *
     * @var array
     */
    protected $dates = ['starts_at', 'ends_at'];

    protected $appends = ['category_name', 'categories', 'locations'];


    /**
     * The attributes that aren't mass assignable.
     *
     * @var array
     */
    protected $guarded = ['id'];

    protected $casts = [
        'category_id' => 'array',
        'location_id' => 'array',
    ];

    protected $category_ids = [];
    protected $location_ids = [];
    public function variations()
    {
        return $this->belongsToMany(\App\Variation::class, 'discount_variations', 'discount_id', 'variation_id');
    }

    public function getCategoryNameAttribute()
    {
        // $categories = $this->categories(); 
        // return $categories->isNotEmpty() ? $categories->pluck('name')->implode(', ') : null;
        return null;
    }

    public function getLocationsAttribute()
    {
        $locationIds = is_array($this->location_ids) ? $this->location_ids : json_decode($this->location_ids, true);

        if (empty($locationIds)) {
            return []; // Return an empty array if no IDs are found
        }

        if (!is_array($locationIds)) {
            $locationIds = is_null($locationIds) ? [] : [$locationIds];
        }

        return BusinessLocation::whereIn('id', $locationIds)->select('name', 'id')->get()->toArray();
    }

    
    public function getCategoriesAttribute()
    {
        // Ensure category_ids is decoded correctly
        $categoryIds = is_array($this->category_ids) ? $this->category_ids : json_decode($this->category_ids, true);

        if (empty($categoryIds)) {
            return []; // Return an empty array if no IDs are found
        }

        if (!is_array($categoryIds)) {
            $categoryIds = is_null($categoryIds) ? [] : [$categoryIds];
        }

        
        // Fetch categories from the database and return as an array
        return Category::whereIn('id', $categoryIds)->select('id', 'name')->get()->toArray();
    }


    public function getCategoryIdAttribute()
    {
        // Check if `category_id` is already an array or needs decoding
        $this->category_ids = is_array($this->attributes['category_id'])
            ? $this->attributes['category_id']
            : json_decode($this->attributes['category_id'], true) ?? [];

        return null; // Always return null for this accessor
    }

    public function getLocationIdAttribute()
    {
        // Check if `category_id` is already an array or needs decoding
        $this->location_ids = is_array($this->attributes['location_id'])
            ? $this->attributes['location_id']
            : json_decode($this->attributes['location_id'], true) ?? [];

        return null; // Always return null for this accessor
    }


    // public function categories()
    // {
    //     if (empty($this->category_ids)) {
    //         return collect(); // Return an empty collection if no category IDs are set
    //     }
    //     // Fetch and return categories as a collection
    //     return Category::whereIn('id', $this->category_ids)->select('id', 'name')->get()->toArray();
    // }
}
