<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

use App\Category;
use App\Product;

class PrinterCategories extends Model
{
    use SoftDeletes;

    /**
     * The attributes that aren't mass assignable.
     *
     * @var array
     */
    protected $guarded = ['id'];

    public static function forDropdown($business_id, $show_select = true)
    {
        $query = PrinterCategories::where('business_id', $business_id);

        $printers = $query->pluck('name', 'id');
        if ($show_select) {
            $printers->prepend(__('messages.please_select'), '');
        }
        return $printers;
    }

    // public static function productModifiersDropdown($business_id, $show_select = true)
    // {
    //     $query = Product::where('business_id', $business_id)
    //         ->where('type', 'modifier');

    //     $modifiers = $query->pluck('name', 'id');
    //     if ($show_select) {
    //         $modifiers->prepend(__('messages.please_select'), '');
    //     }
    //     return $modifiers;
    // }

    public function product_category()
    {
        return $this->belongsToMany(\App\Category::class, 'api_printer_categories', 'printer_group_id', 'product_categories_id');
    }

    public function productModifiers()
    {
        // return $this->belongsToMany(\App\Product::class, 'api_printer_modifiers', 'printer_group_id', 'product_modifiers_id');
        return $this->belongsToMany(\App\Variation::class, 'api_printer_modifiers', 'printer_group_id', 'product_modifiers_id');
    }

    public function products()
    {
        return $this->belongsToMany(\App\Product::class, 'api_printer_products', 'printer_group_id', 'product_id');
    }

}
