<?php
namespace App\Http\Middleware;

use Closure;
use App\Queue\QueueSchema;

class CheckQueueSettings
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle($request, Closure $next)
    {
        $req_data = $request->only('business_id', 'location_id');
        $queue_schemas = QueueSchema::where('queue_schemas.business_id', $req_data['business_id'])
                                    ->where('queue_schemas.location_id', $req_data['location_id'])
                                    ->select('queue_schemas.id')
                                    ->get();

        if( ! count($queue_schemas) ) {
            return response()->json([
                'success' => false,
                'errorMessage' => "Missing queue configuration"
            ], 200);
        }

        return $next($request);
    }
}

?>