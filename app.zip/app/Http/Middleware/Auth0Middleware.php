<?php

namespace App\Http\Middleware;

use Closure;
use Auth0\SDK\JWTVerifier;

class Auth0Middleware
{
    public function handle($request, Closure $next)
    {
        $token = $request->bearerToken();

        $verifier = new JWTVerifier([
            'supported_algs' => ['RS256'],
            'valid_audiences' => [config('services.auth0.client_id')],
            'authorized_iss' => [config('services.auth0.domain')],
        ]);

        try {
            $decoded = $verifier->verifyAndDecode($token);
            // Token is valid
            return response()->json(['valid' => true]);
        } catch (\Exception $e) {
            // Token is invalid
            return response()->json(['valid' => false]);
        }
    }
}
