<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Contracts\Validation\Validator;
use Illuminate\Http\Exceptions\HttpResponseException as HttpResponse;

class QueueRegisterRequest extends FormRequest
{
    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'business_id' => 'required',
            'location_id' => 'required',
            'country_code' => 'required|max:6',
            'mobile_number' => 'required|max:15',
            'first_name' => 'required|max:255',
            'last_name' => 'required|max:255',
            'queue_pax' => 'required|integer',
            'salutation' => 'required'
        ];
    }
    protected function failedValidation(Validator $validator)
    {
        $res = [
            "success" => false,
            "message" => $validator->errors()->first()
        ];
        throw new HttpResponse(response()->json($res, 400));
    }
}
