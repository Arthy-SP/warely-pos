<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Contracts\Validation\Validator;
use Illuminate\Http\Exceptions\HttpResponseException as HttpResponse;

class CurrentQueueRequest extends FormRequest
{
    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'business_id' => 'required',
            'location_id' => 'required'
        ];
    }
    
    protected function failedValidation(Validator $validator)
    {
        $res = [
            "success" => false,
            "message" => $validator->errors()->first()
        ];
        throw new HttpResponse(response()->json($res, 400));
    }
}
