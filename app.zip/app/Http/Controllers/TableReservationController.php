<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Http\Response;
use App\Models\RestaurantReservation;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\DB;
use App\TableReservation;
use App\TableQrToken;
use App\User;
use App\ResTables;
use App\Restaurant\Booking;
use App\BusinessLocation;
use App\CustomerMembership;
use Carbon\Carbon;
use App\Utils\Util;
use Illuminate\Routing\Controller;
use Yajra\DataTables\Facades\DataTables;

class TableReservationController extends Controller
{
    protected $commonUtil;

    public function __construct(Util $commonUtil)
    {
        $this->commonUtil = $commonUtil;
    }

    public function index() {
        $business_id = request()->session()->get('user.business_id');
        $business_locations = BusinessLocation::forDropdown($business_id); 
        
        if(request()->ajax()) {
            $reservations = TableReservation::where('table_reservations.business_id', $business_id)
            ->leftJoin('res_tables', 'table_reservations.table_id', '=', 'res_tables.id')
            ->leftJoin('business_locations', 'table_reservations.location_id', '=', 'business_locations.id')
            ->select([
                'table_reservations.id',
                DB::raw('CONCAT(table_reservations.first_name, " ", table_reservations.last_name) as name'),
                'table_reservations.phone', 
                'table_reservations.email', 
                DB::raw('DATE(table_reservations.booking_date) as booking_date'),
                'table_reservations.slot_id', 
                'table_reservations.business_id', 
                'table_reservations.location_id', 
                'table_reservations.terminal_id', 
                'table_reservations.table_id', 
                'table_reservations.status', 
                'table_reservations.pax', 
                'res_tables.name as table_name',
                'business_locations.name as location_name'
            ]);
        
            return Datatables::of($reservations)
                ->addColumn(
                    'action',
                    function ($row) use ($business_id) {
                        $html = '<div class="btn-group">
                            <button type="button" class="btn btn-info dropdown-toggle btn-xs" data-toggle="dropdown" aria-expanded="false">' . __("messages.actions") . '<span class="caret"></span><span class="sr-only">Toggle Dropdown</span></button>
                            <ul class="dropdown-menu dropdown-menu-left" role="menu">';
                        
                        if (auth()->user()->can('product.view')) {
                            $html .= '<li><a href="' . action('CustomerMembershipController@show', [$row->id]) . '" class="view-reservation"><i class="fa fa-eye"></i> ' . __("messages.view") . '</a></li>';
                        }
                        
                        if (auth()->user()->can('product.update')) {
                            $html .= '<li><a href="' . action('CustomerMembershipController@edit', [$row->id]) . '" class="edit-reservation"><i class="glyphicon glyphicon-edit"></i> ' . __("messages.edit") . '</a></li>';
                        }
                        
                        if (auth()->user()->can('product.delete')) {
                            $html .= '<li><a href="' . action('CustomerMembershipController@destroy', [$row->id]) . '" class="delete-reservation"><i class="fa fa-trash"></i> ' . __("messages.delete") . '</a></li>';
                        }
                        
                        $html .= '</ul></div>';
                        return $html;
                    }
                )
                ->rawColumns(['action', 'first_name'])
                ->make(true);
        }
        
        return view('reservations.index', compact('business_locations'));
    }

    public function save_table_bookings(Request $request)
    {
        $user_id = $request->input('user_id');
        $token = $request->input('token');
        
        $input = $request->only([
            'first_name', 'last_name', 'contact_id', 'phone', 'booking_date',
            'business_id', 'location_id', 'table_id', 'pax', 'booking_start', 'booking_end', 'booking_status'
        ]);

        if (isset($token)) {
            $result = User::checkUserToken($token, $user_id);

            if ($result) {
                try {
                    if (!isset($input['booking_start']) || !isset($input['booking_end'])) {
                        return response()->json(['success' => false, 'msg' => 'Invalid booking start or end date'], 200);
                    }

                    try {
                        $booking_start = Carbon::parse($input['booking_start']);
                        $booking_end = Carbon::parse($input['booking_end']);

                        if ($booking_start->isPast() || $booking_end->isPast()) {
                            return response()->json(["success" => false, "msg" => "You can't book a table for a past time."], 200);
                        }
                    } catch (\Exception $e) {
                        return response()->json(['success' => false, 'msg' => 'Invalid date format'], 200);
                    }

                    if ($booking_end <= $booking_start) {
                        return response()->json(['success' => false, 'msg' => 'Booking end time must be after booking start time'], 200);
                    }

                    $query = Booking::where('business_id', $input['business_id'])
                                ->where('location_id', $input['location_id'])
                                ->where('table_id', $input['table_id'])
                                ->where(function ($q) use ($booking_start, $booking_end) {
                                    $q->where(function ($subQuery) use ($booking_start, $booking_end) {
                                        $subQuery->where('booking_start', '<', $booking_end)
                                                 ->where('booking_end', '>', $booking_start);
                                    });
                                });

                    $existing_booking = $query->first();

                    if (is_null($existing_booking)) {
                        $input['booking_start'] = $booking_start;
                        $input['booking_end'] = $booking_end;

                        $reservation = Booking::create($input);
        
                        $output = [
                            'success' => true,
                            'msg' => __("lang_v1.booking_success"),
                            'result' => $reservation
                        ];
                        return response()->json($output, 200);
                    } else {
                        $output = [
                            'success' => false,
                            'msg' => __("Already booked.")
                        ];
                        return response()->json($output, 200);
                    }
                } catch (\Exception $e) {
                    \Log::emergency("File:" . $e->getFile(). "Line:" . $e->getLine(). "Message:" . $e->getMessage());
                    
                    $output = [
                        'success' => false,
                        'msg' => __("messages.something_went_wrong")
                    ];
                    return response()->json($output, 200);
                }
            } else {
                return response()->json(['errorMessage' => 'Invalid token.'], 200);
            }
        } else {
            return response()->json(['errorMessage' => 'Invalid token.'], 200);
        }
    }
    
    public function update_table_bookings(Request $request)
    {
        $user_id = $request->input('user_id');
        $token = $request->input('token');
        
        $input = $request->only(['first_name','last_name','contact_id','phone','booking_date','business_id','location_id','table_id','pax','booking_start','booking_end','booking_status','id']);

        if (isset($token)) {
            $result = User::checkUserToken($token, $user_id);

            if ($result) {
                try {

                    if (!isset($input['booking_start']) || !isset($input['booking_end'])) {
                        return response()->json(['success' => false, 'msg' => 'Invalid booking start or end date'], 200);
                    }

                    try {
                        $booking_start = Carbon::parse($input['booking_start']);
                        $booking_end = Carbon::parse($input['booking_end']);
                    } catch (\Exception $e) {
                        return response()->json(['success' => false, 'msg' => 'Invalid date format'], 200);
                    }

                    if ($booking_start->isPast() || $booking_end->isPast()) {
                        return response()->json(["success" => false, "msg" => "You can't book a table for a past time."], 200);
                    }
                    
                    if ($booking_end <= $booking_start) {
                        return response()->json(['success' => false, 'msg' => 'Booking end time must be after booking start time'], 200);
                    }

                    $query = Booking::where('business_id', $input['business_id'])
                                ->where('location_id', $input['location_id'])
                                ->where('table_id', $input['table_id'])
                                ->where(function ($q) use ($booking_start, $booking_end) {
                                    $q->where(function ($subQuery) use ($booking_start, $booking_end) {
                                        $subQuery->where('booking_start', '<', $booking_end)
                                                 ->where('booking_end', '>', $booking_start);
                                    });
                                });

                    $existing_booking = $query->first();

                    if (is_null($existing_booking) || $existing_booking->id == $input['id']) {
                
                        $input['booking_start'] = $booking_start;
                        $input['booking_end'] = $booking_end;

                        $reservation = Booking::find($input['id']);
                        $reservation->update($input);

                        $output = [
                            'success' => true,
                            'msg' => __("lang_v1.update_booking_success"),
                            'data' => $reservation
                        ];

                        return response()->json($output, 200);
                    } else {

                        $output = ['success' => false,'msg' => __("Already booked.")];
                        return response()->json($output, 200);
                    }
                    
                } catch (\Exception $e) {
                    \Log::emergency("File:" . $e->getFile(). " Line:" . $e->getLine(). " Message:" . $e->getMessage());

                    $output = [
                        'success' => false,
                        'msg' => __("messages.something_went_wrong")
                    ];

                    return response()->json($output, 200);
                }
            } else {
                return response()->json(['errorMessage' => 'Invalid token.'], 200);
            }
        } else {
            return response()->json(['errorMessage' => 'Invalid token.'], 200);
        }
    }

    public function delete_table_bookings(Request $request)
    {
        $input = $request->only(['token', 'user_id', 'booking_id']);

        if (isset($input['token'])) {
            $result = User::checkUserToken($input['token'], $input['user_id']);

            if ($result) {
                try {
                    $bookingId = $input['booking_id'];
                    $reservation = Booking::find($bookingId);

                    $reservation->delete();

                    $output = [
                        'success' => true,
                        'msg' => __("lang_v1.delete_table_booking")
                    ];

                    return response()->json($output, 200);
                } catch (\Exception $e) {
                    \Log::emergency("File:" . $e->getFile(). " Line:" . $e->getLine(). " Message:" . $e->getMessage());

                    $output = [
                        'success' => false,
                        'msg' => __("messages.something_went_wrong")
                    ];

                    return response()->json($output, 200);
                }
            } else {
                return response()->json(['errorMessage' => 'Invalid token.'], 200);
            }
        } else {
            return response()->json(['errorMessage' => 'Invalid token.'], 200);
        }
    }

    public function get_all_reservations_list(Request $request)
    {
        $input = $request->only(['token', 'user_id', 'business_id', 'location_id', 'current_time', 'current_date']);

        if (isset($input['token'])) {
            $result = User::checkUserToken($input['token'], $input['user_id']);

            if ($result) {
                try {

                    $reservations = Booking::where('bookings.business_id', $input['business_id'])
                                            ->where('bookings.location_id', $input['location_id'])
                                            ->whereIn('bookings.booking_status', ['waiting', 'booked'])
                                            ->leftJoin('res_tables', 'bookings.table_id', '=', 'res_tables.id')
                                            ->select([
                                                'bookings.*',  
                                                'res_tables.name as table_name'
                                            ])
                                            ->get();

                    $output = [
                        'success' => true,
                        'data' => $reservations
                    ];

                    return response()->json($output, 200);
                } catch (\Exception $e) {
                    \Log::emergency("File:" . $e->getFile(). " Line:" . $e->getLine(). " Message:" . $e->getMessage());

                    $output = [
                        'success' => false,
                        'msg' => __("messages.something_went_wrong")
                    ];

                    return response()->json($output, 200);
                }
            } else {
                return response()->json(['errorMessage' => 'Invalid token.'], 200);
            }
        } else {
            return response()->json(['errorMessage' => 'Invalid token.'], 200);
        }
    }
}
