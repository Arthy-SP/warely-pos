<?php

namespace App\Http\Controllers\Queue;

use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Illuminate\Routing\Controller;
use Datatables;
use App\BusinessLocation;
use App\Queue\QueueSettings;

class QueueSettingsController extends Controller
{
    /**
     * Display a listing of the resource.
     * @return Response
     */
    public function index()
    {
        if (!auth()->user()->can('access_tables')) {
            abort(403, 'Unauthorized action.');
        }

       if (request()->ajax()) {
            $business_id = request()->session()->get('user.business_id');

            $queueSettings = QueueSettings::where('queue_settings.business_id', $business_id)
                               ->join('business_locations AS BL', 'queue_settings.location_id', '=', 'BL.id')
                               ->select(['BL.name as location', 'queue_settings.skip_queue_limit',
                               'queue_settings.description', 'queue_settings.id', 'BL.website', 'queue_settings.location_id']);

            return Datatables::of($queueSettings)
               ->addColumn(
                   'action',
                   '@role("Admin#' . $business_id . '")
                   <button data-href="{{action(\'Queue\QueueSettingsController@edit\', [$id])}}" class="btn btn-xs btn-primary edit_queue_setting_button"><i class="glyphicon glyphicon-edit"></i> @lang("messages.edit")</button>
                       &nbsp;
                   @endrole'
               )
               ->removeColumn('id')
               ->removeColumn('location_id')
               ->escapeColumns(['location_id'])
               ->make(true);
       }

       return view('queue.queue_settings.index');
    }

    /**
     * Show the form for creating a new resource.
     * @return Response
     */
    public function create()
    {
        if (!auth()->user()->can('access_tables')) {
            abort(403, 'Unauthorized action.');
        }

        $business_id = request()->session()->get('user.business_id');
        $business_locations = BusinessLocation::forDropdown($business_id);

        return view('queue.queue_settings.create')
            ->with(compact('business_locations'));
    }

    /**
     * Store a newly created resource in storage.
     * @param  Request $request
     * @return Response
     */
    public function store(Request $request)
    {
        if (!auth()->user()->can('access_tables')) {
            abort(403, 'Unauthorized action.');
        }

        try {
            $input = $request->only(['skip_queue_limit', 'description', 'location_id']);
            $business_id = $request->session()->get('user.business_id');

            $queueSettings = QueueSettings::where('business_id', $business_id)
                                            ->where('location_id', $input["location_id"])
                                            ->first();
            if( $queueSettings && !empty($queueSettings) && count($queueSettings) ) {
                $output = ['success' => false,
                            'msg' => "Setting already exists for selected business location"
                        ];
            } else {
                $input['business_id'] = $business_id;
                $input['created_by'] = $request->session()->get('user.id');
                
                $queueSetting = QueueSettings::create($input);

                $output = ['success' => true,
                                'data' => $queueSetting,
                                'msg' => __("lang_v1.added_success")
                            ];
        }   
        } catch (\Exception $e) {
            \Log::emergency("File:" . $e->getFile(). "Line:" . $e->getLine(). "Message:" . $e->getMessage());
            
            $output = ['success' => false,
                            'msg' => __("messages.something_went_wrong")
                        ];
        }

        return $output;
    }

    /**
     * Show the specified resource.
     * @return Response
     */
    public function show()
    {
        if (!auth()->user()->can('access_tables')) {
            abort(403, 'Unauthorized action.');
        }

        return view('queue.queue_settings.show');
    }

    /**
     * Show the form for editing the specified resource.
     * @return Response
     */
    public function edit($id)
    {
        if (!auth()->user()->can('access_tables')) {
            abort(403, 'Unauthorized action.');
        }

        if (request()->ajax()) {
            $business_id = request()->session()->get('user.business_id');

            $queue_setting = QueueSettings::where('queue_settings.business_id', $business_id)
                               ->join('business_locations AS BL', 'queue_settings.location_id', '=', 'BL.id')
                               ->select(['BL.name as location', 'queue_settings.skip_queue_limit',
                               'queue_settings.description', 'queue_settings.id', 'BL.website', 'queue_settings.location_id'])
                               ->find($id);
            
            return view('queue.queue_settings.edit')->with(compact('queue_setting'));
        }
    }

    /**
     * Update the specified resource in storage.
     * @param  Request $request
     * @return Response
     */
    public function update(Request $request, $id)
    {
        if (!auth()->user()->can('access_tables')) {
             abort(403, 'Unauthorized action.');
        }

        if (request()->ajax()) {
            try {
                $input = $request->only(['skip_queue_limit', 'description']);
                $business_id = $request->session()->get('user.business_id');

                $queueSetting = QueueSettings::where('business_id', $business_id)->findOrFail($id);
                $queueSetting->skip_queue_limit = $input['skip_queue_limit'];
                $queueSetting->description = $input['description'];
                $queueSetting->updated_by = $request->session()->get('user.id');
                $queueSetting->save();

                $output = ['success' => true,
                            'msg' => __("lang_v1.updated_success")
                            ];
            } catch (\Exception $e) {
                \Log::emergency("File:" . $e->getFile(). "Line:" . $e->getLine(). "Message:" . $e->getMessage());
            
                $output = ['success' => false,
                            'msg' => __("messages.something_went_wrong")
                        ];
            }

            return $output;
        }
    }

    /**
     * Remove the specified resource from storage.
     * @return Response
     */
    public function destroy($id)
    {
        if (!auth()->user()->can('access_tables')) {
            abort(403, 'Unauthorized action.');
        }

        if (request()->ajax()) {
            try {
                $business_id = request()->user()->business_id;
                $queueSetting = QueueSettings::where('business_id', $business_id)->findOrFail($id);
                $queueSetting->delete();

                $output = ['success' => true,
                            'msg' => __("lang_v1.deleted_success")
                            ];
            } catch (\Exception $e) {
                \Log::emergency("File:" . $e->getFile(). "Line:" . $e->getLine(). "Message:" . $e->getMessage());
            
                $output = ['success' => false,
                            'msg' => __("messages.something_went_wrong")
                        ];
            }

            return $output;
        }
    }
}