<?php

namespace App\Http\Controllers\Queue;

use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Illuminate\Routing\Controller;
use Datatables;
use App\BusinessLocation;
use App\Queue\QueueSchema;
use App\Queue\QueuePaxCategories;

class QueueSchemaController extends Controller
{
    /**
     * Display a listing of the resource.
     * @return Response
     */
    public function index()
    {
        if (!auth()->user()->can('access_tables')) {
            abort(403, 'Unauthorized action.');
        }

       if (request()->ajax()) {
            $business_id = request()->session()->get('user.business_id');

            $queueSchema = QueueSchema::where('queue_schemas.business_id', $business_id)
                               ->join('business_locations AS BL', 'queue_schemas.location_id', '=', 'BL.id')
                               ->join('queue_pax_categories AS PC', 'queue_schemas.pax_category_id', '=', 'PC.id')
                               ->select(['BL.name as location', 'PC.description as pax_range', 'PC.start_from as start_from', 'PC.end_to as end_to',
                               'queue_schemas.prefix', 'queue_schemas.start', 'queue_schemas.end',
                               'queue_schemas.pax_range_start', 'queue_schemas.pax_range_end',
                               'queue_schemas.estimated_wait_time', 'queue_schemas.pax_category_id',
                               'queue_schemas.description', 'queue_schemas.id', 'BL.website', 'queue_schemas.location_id']);

            return Datatables::of($queueSchema)
               ->addColumn(
                   'action',
                   '@role("Admin#' . $business_id . '")
                   <button data-href="{{action(\'Queue\QueueSchemaController@edit\', [$id])}}" class="btn btn-xs btn-primary edit_queue_schema_button"><i class="glyphicon glyphicon-edit"></i> @lang("messages.edit")</button>
                       &nbsp;
                   @endrole
                   @role("Admin#' . $business_id . '")
                       <button data-href="{{action(\'Queue\QueueSchemaController@destroy\', [$id])}}" class="btn btn-xs btn-danger delete_queue_schema_button"><i class="glyphicon glyphicon-trash"></i> @lang("messages.delete")</button>
                   @endrole'
               )
               ->removeColumn('id')
               ->removeColumn('location_id')
               ->escapeColumns(['location_id'])
               ->make(true);
       }

       return view('queue.queue_schema.index');
    }

    /**
     * Show the form for creating a new resource.
     * @return Response
     */
    public function create()
    {
        if (!auth()->user()->can('access_tables')) {
            abort(403, 'Unauthorized action.');
        }

        $business_id = request()->session()->get('user.business_id');
        $business_locations = BusinessLocation::forDropdown($business_id);
        $pax_categories = QueuePaxCategories::forDropdown($business_id);

        return view('queue.queue_schema.create')
            ->with(compact('business_locations', 'pax_categories'));
    }

    /**
     * Store a newly created resource in storage.
     * @param  Request $request
     * @return Response
     */
    public function store(Request $request)
    {
        if (!auth()->user()->can('access_tables')) {
            abort(403, 'Unauthorized action.');
        }

        try {
            $input = $request->only(['prefix', 'start', 'end', 'estimated_wait_time', 'description', 'pax_category_id', 'location_id']);
            $business_id = $request->session()->get('user.business_id');
            $input['business_id'] = $business_id;
            $input['created_by'] = $request->session()->get('user.id');
            
            $queueSchema = QueueSchema::create($input);

            $output = ['success' => true,
                            'data' => $queueSchema,
                            'msg' => __("lang_v1.added_success")
                        ];
        } catch (\Exception $e) {
            \Log::emergency("File:" . $e->getFile(). "Line:" . $e->getLine(). "Message:" . $e->getMessage());
            
            $output = ['success' => false,
                            'msg' => __("messages.something_went_wrong")
                        ];
        }

        return $output;
    }

    /**
     * Show the specified resource.
     * @return Response
     */
    public function show()
    {
        if (!auth()->user()->can('access_tables')) {
            abort(403, 'Unauthorized action.');
        }

        return view('queue.queue_schema.show');
    }

    /**
     * Show the form for editing the specified resource.
     * @return Response
     */
    public function edit($id)
    {
        if (!auth()->user()->can('access_tables')) {
            abort(403, 'Unauthorized action.');
        }

        if (request()->ajax()) {
            $business_id = request()->session()->get('user.business_id');

            $queue_schema = QueueSchema::where('queue_schemas.business_id', $business_id)
                               ->join('business_locations AS BL', 'queue_schemas.location_id', '=', 'BL.id')
                               ->join('queue_pax_categories AS PC', 'queue_schemas.pax_category_id', '=', 'PC.id')
                               ->select(['BL.name as location', 'PC.description as pax_range', 'PC.start_from as start_from', 'PC.end_to as end_to',
                               'queue_schemas.prefix', 'queue_schemas.start', 'queue_schemas.end',
                               'queue_schemas.pax_range_start', 'queue_schemas.pax_range_end',
                               'queue_schemas.estimated_wait_time', 'queue_schemas.pax_category_id',
                               'queue_schemas.description', 'queue_schemas.id', 'BL.website', 'queue_schemas.location_id'])
                               ->find($id);

            $pax_categories = QueuePaxCategories::forDropdown($business_id);
            
            return view('queue.queue_schema.edit')->with(compact('queue_schema', 'pax_categories'));
        }
    }

    /**
     * Update the specified resource in storage.
     * @param  Request $request
     * @return Response
     */
    public function update(Request $request, $id)
    {
        if (!auth()->user()->can('access_tables')) {
             abort(403, 'Unauthorized action.');
        }

        if (request()->ajax()) {
            try {
                $input = $request->only(['prefix', 'start', 'end', 'pax_category_id', 'estimated_wait_time', 'description']);
                $business_id = $request->session()->get('user.business_id');

                $queueSchema = QueueSchema::where('business_id', $business_id)->findOrFail($id);
                
                $queueSchema->prefix = $input['prefix'];
                $queueSchema->start = $input['start'];
                $queueSchema->end = $input['end'];
                $queueSchema->pax_category_id = $input['pax_category_id'];
                $queueSchema->estimated_wait_time = $input['estimated_wait_time'];
                $queueSchema->description = $input['description'];
                $queueSchema->updated_by = $request->session()->get('user.id');
                $queueSchema->save();

                $output = ['success' => true,
                            'msg' => __("lang_v1.updated_success")
                            ];
            } catch (\Exception $e) {
                \Log::emergency("File:" . $e->getFile(). "Line:" . $e->getLine(). "Message:" . $e->getMessage());
            
                $output = ['success' => false,
                            'msg' => __("messages.something_went_wrong")
                        ];
            }

            return $output;
        }
    }

    /**
     * Remove the specified resource from storage.
     * @return Response
     */
    public function destroy($id)
    {
        if (!auth()->user()->can('access_tables')) {
            abort(403, 'Unauthorized action.');
        }

        if (request()->ajax()) {
            try {
                $business_id = request()->user()->business_id;
                $queueSchema = QueueSchema::where('business_id', $business_id)->findOrFail($id);
                $queueSchema->delete();

                $output = ['success' => true,
                            'msg' => __("lang_v1.deleted_success")
                            ];
            } catch (\Exception $e) {
                \Log::emergency("File:" . $e->getFile(). "Line:" . $e->getLine(). "Message:" . $e->getMessage());
            
                $output = ['success' => false,
                            'msg' => __("messages.something_went_wrong")
                        ];
            }

            return $output;
        }
    }
}