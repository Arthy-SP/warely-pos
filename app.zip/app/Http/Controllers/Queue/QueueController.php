<?php

namespace App\Http\Controllers\Queue;

use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Illuminate\Routing\Controller;
use App\Utils\Util;
use Datatables;
use App\BusinessLocation;

class QueueController extends Controller
{
    /**
     * All Utils instance.
     *
     */
    protected $util;

    /**
     * Constructor
     *
     * @param Util $util
     * @return void
     */
    public function __construct(Util $util)
    {
        $this->util = $util;
    }

    /**
     * Show the form for creating a new resource.
     * @return Response
     */
    public function generateQR()
    {
        if (!auth()->user()->can('access_tables')) {
            abort(403, 'Unauthorized action.');
        }

        $business_id = request()->session()->get('user.business_id');
        $business_locations = BusinessLocation::forDropdown($business_id);

        $qrAppBaseUrl = config("constants.QR_APP_URL");

        return view('queue.generate_qr.index')
            ->with(compact('business_locations', 'business_id', 'qrAppBaseUrl'));
    }

    /**
     * Show the form for creating a new resource.
     * @return Response
     */
    public function generateLinks()
    {
        if (!auth()->user()->can('access_tables')) {
            abort(403, 'Unauthorized action.');
        }

        $business_id = request()->session()->get('user.business_id');
        $business_locations = BusinessLocation::forDropdown($business_id);
        $qrAppBaseUrl = config("constants.QR_APP_URL");
        
        return view('queue.generate_links.index')
            ->with(compact('business_locations', 'business_id', 'qrAppBaseUrl'));

    }

}