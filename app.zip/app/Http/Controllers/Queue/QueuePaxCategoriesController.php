<?php

namespace App\Http\Controllers\Queue;

use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Illuminate\Routing\Controller;
use Datatables;
use App\Queue\QueuePaxCategories;

class QueuePaxCategoriesController extends Controller
{
    /**
     * Display a listing of the resource.
     * @return Response
     */
    public function index()
    {
        if (!auth()->user()->can('access_tables')) {
            abort(403, 'Unauthorized action.');
        }

        if (request()->ajax()) {
            $business_id = request()->session()->get('user.business_id');
        
            $paxCategories = QueuePaxCategories::where('queue_pax_categories.business_id', $business_id)
                                        ->select(['queue_pax_categories.start_from', 'queue_pax_categories.end_to', 
                                        'queue_pax_categories.description', 'queue_pax_categories.id']);
            
            return Datatables::of($paxCategories)
               ->addColumn(
                   'action',
                   '@role("Admin#' . $business_id . '")
                   <button data-href="{{action(\'Queue\QueuePaxCategoriesController@edit\', [$id])}}" class="btn btn-xs btn-primary edit_pax_categories_button"><i class="glyphicon glyphicon-edit"></i> @lang("messages.edit")</button>
                       &nbsp;
                   @endrole
                   @role("Admin#' . $business_id . '")
                       <button data-href="{{action(\'Queue\QueuePaxCategoriesController@destroy\', [$id])}}" class="btn btn-xs btn-danger delete_pax_categories_button"><i class="glyphicon glyphicon-trash"></i> @lang("messages.delete")</button>
                   @endrole'
               )
               ->removeColumn('id')
               ->make(true);
       }

       return view('queue.pax_categories.index');
    }

    /**
     * Show the form for creating a new resource.
     * @return Response
     */
    public function create()
    {
        if (!auth()->user()->can('access_tables')) {
            abort(403, 'Unauthorized action.');
        }

        return view('queue.pax_categories.create');
    }

    /**
     * Store a newly created resource in storage.
     * @param  Request $request
     * @return Response
     */
    public function store(Request $request)
    {
        if (!auth()->user()->can('access_tables')) {
            abort(403, 'Unauthorized action.');
        }

        try {
            $input = $request->only(['start_from', 'end_to', 'description']);
            $business_id = request()->session()->get('user.business_id');
            $input['created_by'] = $request->session()->get('user.id');
            $input['business_id'] = $business_id;
            
            $paxCategory = QueuePaxCategories::create($input);

            $output = ['success' => true,
                            'data' => $paxCategory,
                            'msg' => __("lang_v1.added_success")
                        ];
        } catch (\Exception $e) {
            \Log::emergency("File:" . $e->getFile(). "Line:" . $e->getLine(). "Message:" . $e->getMessage());
            
            $output = ['success' => false,
                            'msg' => __("messages.something_went_wrong")
                        ];
        }

        return $output;
    }

    /**
     * Show the specified resource.
     * @return Response
     */
    public function show()
    {
        if (!auth()->user()->can('access_tables')) {
            abort(403, 'Unauthorized action.');
        }

        return view('queue.pax_categories.show');
    }

    /**
     * Show the form for editing the specified resource.
     * @return Response
     */
    public function edit($id)
    {
        if (!auth()->user()->can('access_tables')) {
            abort(403, 'Unauthorized action.');
        }

        if (request()->ajax()) {
            $business_id = request()->session()->get('user.business_id');
            $pax_category = QueuePaxCategories::where('business_id', $business_id)->find($id);
            
            return view('queue.pax_categories.edit')->with(compact('pax_category'));
        }
    }

    /**
     * Update the specified resource in storage.
     * @param  Request $request
     * @return Response
     */
    public function update(Request $request, $id)
    {
        if (!auth()->user()->can('access_tables')) {
             abort(403, 'Unauthorized action.');
        }

        if (request()->ajax()) {
            try {
                $input = $request->only(['start_from', 'end_to', 'description']);
                $business_id = $request->session()->get('user.business_id');
                $paxCategory = QueuePaxCategories::where('business_id', $business_id)->findOrFail($id);
                
                $paxCategory->start_from = $input['start_from'];
                $paxCategory->end_to = $input['end_to'];
                $paxCategory->description = $input['description'];
                $paxCategory->updated_by = $request->session()->get('user.id');
                $paxCategory->save();

                $output = ['success' => true,
                            'msg' => __("lang_v1.updated_success")
                            ];
            } catch (\Exception $e) {
                \Log::emergency("File:" . $e->getFile(). "Line:" . $e->getLine(). "Message:" . $e->getMessage());
            
                $output = ['success' => false,
                            'msg' => __("messages.something_went_wrong")
                        ];
            }

            return $output;
        }
    }

    /**
     * Remove the specified resource from storage.
     * @return Response
     */
    public function destroy($id)
    {
        if (!auth()->user()->can('access_tables')) {
            abort(403, 'Unauthorized action.');
        }

        if (request()->ajax()) {
            try {
                $business_id = request()->user()->business_id;
                $paxCategory = QueuePaxCategories::where('business_id', $business_id)->findOrFail($id);
                $paxCategory->delete();

                $output = ['success' => true,
                            'msg' => __("lang_v1.deleted_success")
                            ];
            } catch (\Exception $e) {
                \Log::emergency("File:" . $e->getFile(). "Line:" . $e->getLine(). "Message:" . $e->getMessage());
            
                $output = ['success' => false,
                            'msg' => __("messages.something_went_wrong")
                        ];
            }

            return $output;
        }
    }
}