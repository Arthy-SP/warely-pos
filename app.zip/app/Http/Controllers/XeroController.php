<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use GuzzleHttp\Client;
use Illuminate\Support\Facades\Validator;
use GuzzleHttp\Exception\RequestException;
use Illuminate\Support\Facades\Session;
use App\Product;
use App\Business;
use App\BusinessLocation;
use App\XeroSyncStatus;
use App\Transaction;
use App\TransactionSellLines;

class XeroController extends Controller
{
    public function index(Request $request){
        if (!auth()->user()->can('business_settings.access')) {
            abort(403, 'Unauthorized action.');
        }

        if ($request->has('code')) {
            $authorizationCode = $request->query('code');

            session()->put('xero_authorization_code', $authorizationCode);
        }
        $business_id = request()->session()->get('user.business_id');
        $business = Business::where('id', $business_id)
                            ->select('xero_client_id', 'xero_secret_key')    
                            ->first();

        $locations = BusinessLocation::forDropdown($business_id, true);
        $locations = ['' => __('All Locations')] + $locations->toArray();

        return view('xero.index', compact('business', 'locations'));
    }

    public function getSelectedLocation(Request $request)
    {
        $locationId = $request->input('location_id');

        Session::put('selected_location_id', $locationId);
        
        return response()->json(['success' => true]);
    }

    // public function setLocationSession(Request $request)
    // {
    //     $locationId = $request->input('location_id');
    //     session(['location_id' => $locationId]);
    //     return response()->json(['message' => 'Session key set successfully']);
    // }

    public function unsetLocationSession()
    {
        \Log::info('Unsetting location session...');
    
        // Unset the session key for selected_location_id
        Session::forget('selected_location_id');
    
        \Log::info('Location session unset successfully.');
    }

    public function authorizeWithXero($clientId)
    {
        $location_id = Session::get('selected_location_id');
        
        $authorizationUrl = "https://login.xero.com/identity/connect/authorize" .
        "?response_type=code" .
        "&client_id=" . $clientId .
        "&redirect_uri=https://dev.warelypos.com/xero-settings" .
        "&scope=openid accounting.attachments accounting.attachments.read accounting.budgets.read accounting.contacts accounting.contacts.read accounting.journals.read accounting.reports.read accounting.reports.tenninetynine.read accounting.settings accounting.settings.read accounting.transactions accounting.transactions.read assets assets.read files files.read payroll.employees payroll.employees.read payroll.payruns payroll.payruns.read payroll.payslip payroll.payslip.read payroll.settings payroll.settings.read payroll.timesheets payroll.timesheets.read projects projects.read" .
        "&state=123";

        return redirect()->away($authorizationUrl);
    }

    public static function getAccessToken($business_id, $authorizationCode)
    {
        $business = Business::select('xero_client_id', 'xero_secret_key')->first();

        $xeroClientId = $business->xero_client_id;
        $xeroSecretKey = $business->xero_secret_key;

        $encodedKey = $xeroClientId.':'.$xeroSecretKey;
        $encodedString = base64_encode($encodedKey);
        //dd($encodedString);
        $authorizationCode = session('xero_authorization_code');

        // \Log::info($authorizationCode);
        
        try {
            $client = new Client();
            // dump($encodedString, $authorizationCode);

            $response = $client->post('https://identity.xero.com/connect/token', [
                'headers' => [
                    'authorization' => 'Basic MjRGM0E2RDA3MzM5NDIyRDg3NkU1M0JEOTIzNjc1NEU6cUlneDVKbmV4U3d4TkFXREF2S3BtbEVzZGpzNTN3dndDVGdBanoxMmdTX3lCSE5T',
                    'Content-Type' => 'application/x-www-form-urlencoded'           
                ],
                'form_params' => [
                    'grant_type' => 'authorization_code',
                    'code' => $authorizationCode,
                    'redirect_uri' => 'https://dev.warelypos.com/xero-settings'
                ],
            ]);
            
            return $response->getBody()->getContents();

        } catch (RequestException $e) {
            \Log::error('Xero API Exception: ' . $e->getMessage());

            // Return an error response or handle it as needed
            return response()->json(['error' => 'An error occurred.'], 500);
        }
    }

    public function syncProducts(Request $request) {

        $authorizationCode = Session::get('xero_authorization_code');
        
    }

    public static function syncProductsToXero($business_id, $lastProcessedProductId = null)
    {
        $business_id = request()->session()->get('user.business_id');
        $authorizationCode = Session::get('xero_authorization_code');
        $location_id = Session::get('selected_location_id');
        //dd($location_id);
        try {

            $lastSyncStatus = XeroSyncStatus::where('record_type', 'product')
            ->orderBy('last_synced_at', 'desc')
            ->first();

            $lastProcessedProductId = $lastSyncStatus ? $lastSyncStatus->last_processed_product_id : null;
            
            $query = $query = Product::query()->join('variations', 'products.id', '=', 'variations.product_id')
            ->select('products.*', 'variations.default_purchase_price', 'variations.default_sell_price');

            if ($lastProcessedProductId !== null) {
                $query->where('products.id', '>', $lastProcessedProductId);
            }

            $query->where('type', '!=', 'modifier');
            $query->where('products.deleted_at', null); 

            $products = $query->limit(5)->get(); 
            
            if ($products->isEmpty()) {
                return response()->json(['message' => 'All products synced.'], 200);
            }

            $responseBody = json_decode(self::getAccessToken($business_id, $authorizationCode), true);
            $accessToken = $responseBody['access_token'];
            //dd($responseBody);
            \Log::info($accessToken);
            $client = new Client();

            foreach ($products as $product) {
                // $data = [
                //     'Code' => $product['sku'],
                //     'Description' => 'Sell me',
                //     'PurchaseDescription' => 'Purchase me',
                //     'PurchaseDetails' => [
                //         'UnitPrice' => '100',
                //         'COGSAccountCode' => '300',
                //         'TaxType' => 'OUTPUT',
                //     ],
                //     'SalesDetails' => [
                //         'UnitPrice' => '100',
                //         'AccountCode' => '260',
                //         'TaxType' => 'OUTPUT',
                //     ],
                //     'Name' => $product['name'],
                //     'InventoryAssetAccountCode' => '630',
                //     'IsSold' => true,
                //     'IsPurchased' => true,
                // ]; 
                // dd($product);
                $data = [
                        "Code" => $product->sku, 
                        "Name" => $product->name, 
                        "Description" => "2011 Merino Sweater - LARGE", 
                        "PurchaseDescription" => "2011 Merino Sweater - LARGE",
                        "PurchaseDetails" => [
                        "UnitPrice" => $product->default_purchase_price
                    ], 
                    "SalesDetails" => [
                        "UnitPrice" => $product->default_sell_price
                    ] 
                ]; 

            $response = $client->post('https://api.xero.com/api.xro/2.0/Items', [
                'headers' => [
                    'Authorization' => 'Bearer '.$accessToken,
                    'Content-Type' => 'application/json',
                    'xero-tenant-id' => '3584bc5b-3f16-45c1-bd91-9eb83d7d8afc'
                ],
                'json' => $data,
            ]);

                // Handle response as needed
            $xeroItem = json_decode($response->getBody(), true);
        }

            $lastProcessedProductId = $products->last()->id;
            XeroSyncStatus::create([
                'record_type' => 'product',
                'last_synced_at' => now(),
                'sync_status' => 'synced',
                'last_processed_product_id' => $lastProcessedProductId, 
                'error_message' => null,
                'retry_count' => 0
            ]);

            $output = [
                'success' => 1,
                'msg' => __('product.product_added_success')
            ];

            return redirect()->route('xero-settings.index')->with('status', $output);   

        } catch (\Exception $e) {
            \Log::error('Xero API Exception: ' . $e->getMessage());
            return $e->getMessage();
                    // Return an error response or handle it as needed
            return response()->json(['error' => 'An error occurred while syncing products to Xero.'], 500);
        }
    }

    public static function syncOrdersToXero($lastProcessedProductId = null)
    {
        $business_id = request()->session()->get('user.business_id');
        $authorizationCode = Session::get('xero_authorization_code');
        $location_id = 2;
        try {

            $lastSyncStatus = XeroSyncStatus::where('record_type', 'product')
            ->orderBy('last_synced_at', 'desc')
            ->first();

            $lastProcessedProductId = $lastSyncStatus ? $lastSyncStatus->last_processed_product_id : null;
                    
            $transactions = Transaction::leftJoin('transaction_sell_lines', 'transactions.id', '=', 'transaction_sell_lines.transaction_id')
                ->leftJoin('products', 'transaction_sell_lines.product_id', '=', 'products.id')
                ->with(['sell_lines' => function ($query) {
                    $query->with('product');
                }])
                ->where('transactions.business_id', $business_id)
                ->where('location_id', $location_id)
                ->where('transactions.type', 'sell')
                ->where('transactions.is_direct_sale', 0)
                ->limit(2)
                ->get();
            
            $xeroApiResponse = [];

            $client = new Client();
            $responseBody = json_decode(self::getAccessToken($business_id, $authorizationCode), true);
            $accessToken = $responseBody['access_token'];

            \Log::info($accessToken);
            $invoices = [];

            foreach ($transactions as $transaction) {

                $invoice = [
                    'Type' => 'ACCREC',
                    'Contact' => [
                        'ContactID' => '93891792-87a4-47e1-b76b-93902008ca90'
                    ],
                    'DateString' => $transaction->created_at->toDateTimeString(),
                    'DueDateString' => $transaction->due_date->toDateTimeString(),
                    'ExpectedPaymentDate' => $transaction->created_at->toDateTimeString(),
                    'Reference' => 'Mayank',
                    'CurrencyCode' => 'SGD',
                    'Status' => 'SUBMITTED',
                    'LineAmountTypes' => 'Inclusive',
                    'SubTotal' => $transaction->final_total,
                    'TotalTax' => 0,
                    'Total' => $transaction->final_total,
                    'LineItems' => []
                ];

                foreach ($transaction->sell_lines as $sellLine) {
                    $product = Product::find($sellLine->product_id);
                    //dump($product->name);
                    if ($product) {
                        $name = $product->name;
                    } else {
                        $name = null; 
                    }

                    $lineItem = [
                        'ItemCode' => '0118',
                        'Description' => $name,
                        'Quantity' => $sellLine->quantity,
                        'UnitAmount' => $sellLine->unit_price,
                        'TaxType' => 'OUTPUT', 
                        'TaxAmount' => $sellLine->item_tax,
                        'LineAmount' => $sellLine->unit_price_inc_tax,
                        'AccountCode' => '200'
                    ];
                    $invoice['LineItems'][] = $lineItem;
                }
                $invoices[] = $invoice;
                $data = ['Invoices' => $invoices];
                // dump(json_encode($data)); die;
                $response = $client->post('https://api.xero.com/api.xro/2.0/Invoices', [
                    'headers' => [
                        'Authorization' => 'Bearer ' . $accessToken, 
                        'Content-Type' => 'application/json',
                        'xero-tenant-id' => '3584bc5b-3f16-45c1-bd91-9eb83d7d8afc'

                    ],
                    'json' => $data,
                ]);
                //dump($response->getBody(), true);die;
                //dd(json_decode($response->getBody(), true));  
                // \Log::info($response->getBody(), true);
                $xeroApiResponse[] = json_decode($response->getBody()->getContents(), true);

            }
            return $xeroApiResponse;
        } catch (Exception $e) {
            // Handle any exceptions
            return ['error' => $e->getMessage()];
        }
    }

    public static function createXeroItem($request, $sku, $business_id)
    {
        $data = [
            'Code' => $sku,
            'Description' => 'Sell me',
            'PurchaseDescription' => 'Purchase me',
            'PurchaseDetails' => [
                'UnitPrice' => $request->input('single_dpp'),
                'COGSAccountCode' => '300',
                'TaxType' => 'OUTPUT',
            ],
            'SalesDetails' => [
                'UnitPrice' => $request->input('single_dsp'),
                'AccountCode' => '260',
                'TaxType' => 'OUTPUT',
            ],
            'Name' => $request->input('name'),
            'InventoryAssetAccountCode' => '630',
            'IsSold' => true,
            'IsPurchased' => true,
        ]; 

        $responseBody = json_decode(self::getAccessToken($business_id), true);

        $accessToken = $responseBody['access_token'];

        try {
            $client = new Client();

            $response = $client->post('https://api.xero.com/api.xro/2.0/Items', [
                'headers' => [
                    'Authorization' => 'Bearer '.$accessToken,
                    'Content-Type' => 'application/json',
                ],
                'json' => $data,
            ]);

            // Return the Xero API response
            return json_decode($response->getBody(), true);
        } catch (\Exception $e) {
            \Log::error('Xero API Exception: ' . $e->getMessage());

            // Return an error response or handle it as needed
            return response()->json(['error' => 'An error occurred.'], 500);
        }
    }

    public static function getXeroItem($sku)
    {
        $itemCode = $sku;

        $responseBody = json_decode(self::getAccessToken(), true);        
        $accessToken = $responseBody['access_token'];

        $client = new Client();

        try {
            $response = $client->get("https://api.xero.com/api.xro/2.0/Items/{$itemCode}", [
                'headers' => [
                    'Authorization' => 'Bearer '.$accessToken,
                    'Content-Type' => 'application/json',
                ]
            ]);
            $responseContent = $response->getBody()->getContents();

            $jsonData = json_decode($responseContent, true);

            if ($jsonData !== null) {
                return response()->json($jsonData, 200);
            } else {
                return response()->json(['error' => 'Failed to decode JSON response.'], 500);
            }            
        } catch (\Exception $e) {
            // Handle Guzzle exceptions or other errors
            return response()->json(['error' => $e->getMessage()], 500);
        }
    }

    public static function updateXeroItem($input, $price_details)
    {
        $itemCode = $input['sku'];
        $response = self::getXeroItem($itemCode);
        $xeroItemData = $response->getData(true);
        $itemId = $xeroItemData['Items'][0]['ItemID'];
        //dd($input);
        $data = [
            'Code' => $itemCode,
            'Description' => 'Sell me',
            'PurchaseDescription' => 'Purchase me',
            'PurchaseDetails' => [
                'UnitPrice' => $price_details['single_dpp'],
                'COGSAccountCode' => '300',
                'TaxType' => 'OUTPUT',
            ],
            'SalesDetails' => [
                'UnitPrice' => $price_details['single_dsp'],
                'AccountCode' => '260',
                'TaxType' => 'OUTPUT',
            ],
            'Name' => $input['name'],
            'InventoryAssetAccountCode' => '630',
            'IsSold' => true,
            'IsPurchased' => true,
        ]; 

        $responseBody = json_decode(self::getAccessToken(), true);
        $accessToken = $responseBody['access_token'];

        try {
            $client = new Client();

            $response = $client->post("https://api.xero.com/api.xro/2.0/Items/{$itemId}", [
                'headers' => [
                    'Authorization' => 'Bearer '.$accessToken,
                    'Content-Type' => 'application/json',
                ],
                'json' => $data,
            ]);

            return json_decode($response->getBody(), true);
        } catch (\Exception $e) {
            \Log::error('Xero API Exception: ' . $e->getMessage());

            return response()->json(['error' => 'An error occurred.'], 500);
        }
    }


    public static function createXeroInvoices($input, $invoice_no)
    {
        $finalTotal = $input['final_total'];
        $subTotal = $input['total_before_tax'];
        $totalTax = $finalTotal - $subTotal;
        $taxType = ($input['is_inclusive_gst_applied'] == true) ? "Inclusive" : "Exclusive";
        $status = ($input['status'] == 'final') ? "AUTHORISED" : "DRAFT";

        $originalDate = $input['transaction_date'];
        $dateTime = new \DateTime($originalDate);

        $transactionDate = $dateTime->format('Y-m-d\TH:i:s');

        $data = [
                    "Type" => "ACCREC",
                    "Contact" => [
                        "ContactID" => "0d5274b2-5c53-44c9-ba1e-fa3e619fa0e7",
                    ],
                    "DateString" => $transactionDate,
                    "DueDateString" => $transactionDate,
                    "ExpectedPaymentDate" => $transactionDate,
                    "InvoiceNumber" => $invoice_no,
                    "Reference" => "Ref:MYNK6",
                    "CurrencyCode" => "USD",
                    "Status" => $status,
                    "LineAmountTypes" => $taxType,
                    "SubTotal" => $subTotal,
                    "TotalTax" => $totalTax,
                    "Total" => $finalTotal
        ];

        foreach ($input['products'] as $product) {

            $product_details = Product::where('id', $product['product_id'])
                ->where('type', '!=', 'modifier')
                ->first();

            $data['LineItems'][] = [
                "ItemCode" => !empty($product['sku']) ? $product['sku'] : $product_details['sku'],
                "Description" => $product_details['name'],
                "Quantity" => $product['quantity'],
                "UnitAmount" => $product['unit_price'],
                "TaxType" => "OUTPUT",
                "TaxAmount" => "0.00",
                "LineAmount" => $product['unit_price'] * $product['quantity'],
                "AccountCode" => "200"
            ];
        }

        $responseBody = json_decode(self::getAccessToken(), true);
        $accessToken = $responseBody['access_token'];

        try {
            $client = new Client();

            $response = $client->post('https://api.xero.com/api.xro/2.0/Invoices', [
                'headers' => [
                    'Authorization' => 'Bearer '.$accessToken,
                    'Content-Type' => 'application/json',
                ],
                'json' => $data,
            ]);

            // Return the Xero API response
            return json_decode($response->getBody(), true);
        } catch (\Exception $e) {
            \Log::error('Xero API Exception: ' . $e->getMessage());

            // Return an error response or handle it as needed
            return response()->json(['error' => 'An error occurred.'], 500);
        }
    }

}