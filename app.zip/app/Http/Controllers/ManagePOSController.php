<?php

namespace App\Http\Controllers;

use App\BusinessLocation;
use App\ManagePosDevice;
use Carbon\Carbon;
use App\User;
use Datatables;
use GuzzleHttp\Client;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use App\Terminal;
use App\OrderPrintRequest;
use Config;
use Aws\S3\S3Client;
use Aws\Exception\AwsException;
use Google\Auth\OAuth2;

class ManagePOSController extends Controller
{
    protected $managePosDevice;

    public function __construct(ManagePosDevice $managePosDevice)
    {
        $this->managePosDevice = $managePosDevice;
    }

    public function index()
    {
        $user = request()->user();
        $business_id = $user->business_id;
    
        if(request()->ajax()){
            $location_id = request()->input('location_id', null);
            $posDevices = managePosDevice::where('business_id', $business_id);
    
            if($location_id) {
                $posDevices->where('business_location_id', $location_id);
            }
    
            $posDevices = $posDevices->select('id','device_name','device_id',\DB::raw("IF(is_master, 'Yes', 'No') as is_master_display"));
            return Datatables::of($posDevices)
                ->addColumn(
                    'action',
                    '@can("printer. Update")
                    <a href="{{action(\'ManagePOSController@edit\', [$id])}}" class="btn btn-xs btn-primary"><i class="glyphicon glyphicon-edit"></i> @lang("messages.edit")</a>
                        &nbsp;
                    @endcan
                    '
                )
                ->removeColumn('id')
                ->escapeColumns('action')
                ->make(false);
        }
    
        $locations = BusinessLocation::forDropdown($business_id, true);
        $locations = ['' => __('All Locations')] + $locations->toArray();
    
        return view('manage_pos_device.index', compact('locations'));
    }


    
    public function save(Request $request)
    {
        $input = $request->all();

        if(isset($input['token']))
        { 
            $result = User::checkUserToken($input['token'], $input['user_id']);

            if($result)
            {
                
                $output = $this->savePosDevice($input);
                return $output;
            }
            else
            {
                return["errorMessage"=>'Invalid token.'];
            }
        }
        else
        {
            return["errorMessage"=>'Invalid token.'];
        }
    }

    public function savePosDevice2($input)
    {
        try {
            $existingDevice = $this->managePosDevice
                ->where('device_id', $input['device_id'])
                ->orWhere('device_name', $input['device_name'])
                ->first();
            
            if ($existingDevice) {
                if ($existingDevice->device_name == $input['device_name'] && $existingDevice->device_id == $input['device_id']) {
                    // If device_name and device_id already exists, update the record
                    $existingDevice->device_name = $input['device_name'];
                    $existingDevice->device_type = $input['device_type'];
                    $existingDevice->device_fcm_token = $input['device_fcm_token'];
                    $existingDevice->save();
                } elseif ($existingDevice->device_id == $input['device_id'] && $existingDevice->device_name != $input['device_name']) {
                    // If device_id exists but device_name is different, update the device_name
                    $existingDevice->device_name = $input['device_name'];
                    $existingDevice->save();
                } else {
                    // If device_name exists but device_id is different, return an error response
                    return response()->json(['status' => 'error', 'message' => 'Device name already exists']);
                }
            } else {
                // If device_id and device_name both are new, create a new record
                $newDevice = $this->managePosDevice->create([
                    'device_name' => $input['device_name'],
                    'device_id' => $input['device_id'],
                    'device_type' => $input['device_type'],
                    'business_id' => $input['business_id'],
                    'business_location_id' => $input['business_location_id'],
                    'device_fcm_token' => $input['device_fcm_token'],
                    'is_master' => 0,
                ]);
    
                // If this is the first device for this business_location_id, set it as the master device
                $existingDevices = $this->managePosDevice
                    ->where('business_location_id', $input['business_location_id'])
                    ->get();
                
                if ($existingDevices->count() == 1) {
                    $newDevice->is_master = 1;
                    $newDevice->save();
                }
            }
    
            // Return a success response with is_master_device field
            $is_master_device = $existingDevice ? ($existingDevice->is_master == 1 ? true : false) : false;
            return response()->json(['status' => 'success', 'is_master_device' => $is_master_device]);
        } catch (\Exception $e) {
            // Handle the exception as appropriate (e.g. log it, return an error response)
            return response()->json(['status' => 'error', 'message' => $e->getMessage()]);
        }
    }

    public function savePosDevice($input)
    {
        try {
            // Find any existing device with the same device_id and device_name for this user_id, business_id and business_location_id
            $existingDevice = $this->managePosDevice
                ->where('user_id', $input['user_id'])
                ->where('business_id', $input['business_id'])
                ->where('business_location_id', $input['business_location_id'])
                ->where('device_id', $input['device_id'])
                ->first();
                
            /*
            ->where(function ($query) use ($input) {
                $query->where('device_id', $input['device_id'])
                    // ->orWhere('device_name', $input['device_name']);
            })
            */
        
            if ($existingDevice) {
                if ($existingDevice->device_id == $input['device_id'] && $existingDevice->device_name == $input['device_name']) {
                    // If device_name and device_id already exists, update the record
                    $existingDevice->device_name = $input['device_name'];
                    $existingDevice->device_type = $input['device_type'];
                    $existingDevice->device_fcm_token = $input['device_fcm_token'];
                    $existingDevice->business_id = $input['business_id'];
                    $existingDevice->business_location_id = $input['business_location_id'];
                    $existingDevice->user_id = $input['user_id'];
                    $existingDevice->save();
                } elseif ($existingDevice->device_id == $input['device_id'] && $existingDevice->device_name != $input['device_name']) {
                    // If device_id exists but device_name is different, update the device_name
                    $deviceWithSameName = $this->managePosDevice
                        ->where('device_name', $input['device_name'])
                        ->where('business_location_id', $input['business_location_id'])
                        ->where('user_id', $input['user_id'])
                        ->where('business_id', $input['business_id'])
                        ->first();
        
                    if ($deviceWithSameName) {
                        return response()->json(['status' => 'error', 'message' => 'Device name already exists']);
                    } else {
                        $existingDevice->device_name = $input['device_name'];
                        $existingDevice->save();
                    }
                } else {
                    // If device_name exists but device_id is different, return an error response
                    return response()->json(['status' => 'error', 'message' => 'Device name already exists']);
                }
            } else {
                // If device_id exists but device_name is different, update the device_name
                $deviceWithSameName = $this->managePosDevice
                ->where('device_name', $input['device_name'])
                ->where('business_location_id', $input['business_location_id'])
                ->where('user_id', $input['user_id'])
                ->where('business_id', $input['business_id'])
                ->first();
                if($deviceWithSameName) {
                    return response()->json(['status' => 'error', 'message' => 'Device name already exists']);
                } else {
                    // If device_id and device_name both are new, create a new record
                    $newDevice = $this->managePosDevice->create([
                        'device_name' => $input['device_name'],
                        'device_id' => $input['device_id'],
                        'device_type' => $input['device_type'],
                        'business_id' => $input['business_id'],
                        'business_location_id' => $input['business_location_id'],
                        'device_fcm_token' => $input['device_fcm_token'],
                        'is_master' => 0,
                        'user_id' => $input['user_id']
                    ]);
            
                    // If this is the first device for this business_location_id, set it as the master device
                    $existingDevices = $this->managePosDevice
                        ->where('business_location_id', $input['business_location_id'])
                        ->where('user_id', $input['user_id'])
                        ->where('business_id', $input['business_id'])
                        ->get();
            
                    if ($existingDevices->count() == 1) {
                        $newDevice->is_master = 1;
                        $newDevice->save();
                    }
                }
            }

            // Return a success response with is_master_device field
            $is_master_device = $existingDevice ? ($existingDevice->is_master == 1 ? true : false) : false;
            return response()->json(['status' => 'success', 'is_master_device' => $is_master_device]);
        } catch (\Exception $e) {
            // Handle the exception as appropriate (e.g. log it, return an error response)
            return response()->json(['status' => 'error', 'message' => $e->getMessage()]);
        }
    }


    public function edit($id)
    {
        if (!auth()->user()->can('access_commission')) {
             abort(403, 'Unauthorized action.');
        }

        $business_id = request()->session()->get('user.business_id');
        $pos = $this->managePosDevice::find($id);
        
        $business_location = BusinessLocation::where('business_id', $business_id)
                                          ->where('id', $pos->business_location_id)
                                          ->first();

        return view('manage_pos_device.edit')->with(compact('pos', 'business_location'));
    }

    public function update(Request $request, $id)
    {
        try {
    
            $input = $request->only(['device_name', 'is_master', 'business_location_id']);
            $business_id = $request->session()->get('user.business_id');
            $business_location_id = $input['business_location_id'];
            $is_master = !empty($input['is_master']) ? $input['is_master'] : "";
            // Validate input
            if (empty($input['device_name'])) {
                $output = [
                    'success' => false,
                    'msg' => __("Device name cannot be empty")
                ];
                return redirect()->back()->with('status', $output);
            }

            
            // Check if device_name already exists
            $existingDevice = $this->managePosDevice::where('device_name', $input['device_name'])
                                                    ->where('id', '!=', $id)
                                                    ->first();
            if ($existingDevice) {
                $output = [
                    'success' => false,
                    'msg' => __("Device name already exists")
                ];
                return redirect()->back()->with('status', $output);
            }
    
            $managePosDevice = $this->managePosDevice::findOrFail($id);
    
            if ($is_master) {
                // Update all other devices of the same business_location_id to false
                $this->managePosDevice::where('business_location_id', $business_location_id)
                                        ->where('id', '!=', $id)
                                        ->update(['is_master' => false]);
            }
    
            $managePosDevice->fill($input)->save();
    
            //Add product locations
    
            $output = [
                'success' => true,
                'msg' => __("Field updated successfully")
            ];
        } catch (\Exception $e) {
            \Log::emergency("File:" . $e->getFile(). "Line:" . $e->getLine(). "Message:" . $e->getMessage());
    
            $output = [
                'success' => false,
                'msg' => __("messages.something_went_wrong")
            ];
        }
    
        return redirect()->secure(url('manage-pos-device', [], true))->with('status', $output);
    }


    public function destroy($id)
    {
        if (!auth()->user()->can('tax_rate.delete')) {
            abort(403, 'Unauthorized action.');
        }

        if (request()->ajax()) {
            try {
                //update group tax amount
                $posDevice = $this->managePosDevice::where('id', $id);
                                    $posDevice->delete();
 
                    $output = ['success' => true,
                                'msg' => __("POS Device deleted successfully")
                                ];

            } catch (\Exception $e) {
                \Log::emergency("File:" . $e->getFile(). "Line:" . $e->getLine(). "Message:" . $e->getMessage());
            
                $output = ['success' => false,
                            'msg' => __("messages.something_went_wrong")
                        ];
            }

            return $output;
        }
    }

    public function get_pos_device(Request $request) {
        
        $input = $request->all();

        $result = User::checkUserToken($input['token'], $input['user_id']);
        
        if($result)
        {
            
            try {

                $deviceId = $request->input('device_id');
                $location_id = $request->input('business_location_id');
                $business_id = $request->input('business_id');

                $devices = managePosDevice::where('device_id', $deviceId)
                                            ->where('business_location_id', $location_id)
                                            ->where('business_id', $business_id)
                                            ->get();
                
                return response()->json($devices);

            } catch (\Throwable $th) {

                return response()->json(['error' => $th->getMessage()], 500);

            }
        }
        else
        {
            return["errorMessage"=>'Invalid token.'];
        }
    }
    
    public function delete_pos_device(Request $request)
    {
        $input = $request->all();

        $result = User::checkUserToken($input['token'], $input['user_id']);
        
        if($result)
        {
            
            try {

                $device_id = $request->input('device_id');
                $posDevice = $this->managePosDevice->where('device_id', $device_id)->first();
                
                if ($posDevice) {
                    $posDevice->delete();
                    return response()->json(['status' => 'success']);
                } else {
                    return response()->json(['status' => 'error', 'message' => 'Device not found.']);
                }

            } catch (\Throwable $th) {

                return response()->json(['error' => $th->getMessage()], 500);

            }
        }
        else
        {
            return["errorMessage"=>'Invalid token.'];
        }
        
    }
    
    public function send_print_request(Request $request)
    {
        $input = $request->all();
    
        $result = User::checkUserToken($input['token'], $input['user_id']);
    
        if($result)
        {
            // Get the request parameters
            $transaction_id = $request->input('transaction_id');
            $status = $request->input('status');
            $device_id = !empty($request->input('device_id')) ? $request->input('device_id') : "";
            $receipt_type = $request->input('receipt_type');
            $user_id = $request->input('user_id');
            $business_id = $request->input('business_id');
            $location_id = $request->input('location_id');
            $business_location_id = $request->input('business_location_id');
            $json_data = !empty($request->input('json_data')) ? $request->input('json_data') : "";
    
            // Fetch the FCM token for the device ID
            $device = $this->managePosDevice->select('device_fcm_token', 'device_name')
                                            // ->where('device_id', $device_id)
                                            ->where('is_master', 1)
                                            ->where('business_id', $business_id)
                                            ->where('business_location_id', $business_location_id)
                                            ->first();
            if(!empty($device_id)) {
                $device_sub = $this->managePosDevice->select( 'device_name')
                                ->where('device_id', $device_id)
                                ->where('is_master', 0)
                                ->where('business_id', $business_id)
                                ->where('business_location_id', $business_location_id)
                                ->first();
            
                $device_sub_name = !empty($device_sub->device_name) ? $device_sub->device_name : "";

            } else {
                $device_sub_name = "";
            }            
            
            if ($device) {
                $fcm_token = $device->device_fcm_token;
                $device_name = $device->device_name;
                // Now you can use $fcm_token and $device_name in your CURL request
            } else {
                // Handle device not found error
            }
            
            if(empty($fcm_token)){
                return response()->json(['message' => 'Fcm Token not found']);
            }
            
            try {
                // Send the POST request to FCM server
                $client = new Client();
                $response = $client->post('https://fcm.googleapis.com/fcm/send', [
                    'headers' => [
                        'Authorization' => 'key=AAAAC1EQ6G4:APA91bHjcZ8gLrFatBsh7ttZoe6VH07IFzS2UxvykIVYrg_ngrxpRngSYIoUnWy0QqCcL7IGC_n7hmKsQSk82jfhXzInUsPxUdrBIpMqLQbb8u5XYz40nik95DNokU1FBZ85w3lJ9B_y',
                        'Content-Type' => 'application/json',
                    ],
                    'json' => [
                        'to' => $fcm_token,
                        'data' => [
                            'order_print_request' => [
                                'transaction_id' => $transaction_id,
                                'status' => $status,
                                'from' => $device_sub_name,
                                'receipt_type' => $receipt_type,
                                'json_data' => $json_data
                            ],
                        ],
                    ],
                ]);
    
                $responseBody = json_decode($response->getBody());
                $statusCode = $response->getStatusCode();
    
                if($responseBody->success) {
                    return response()->json(['status' => 'success'], $statusCode);
                } else {
                    return response()->json(['status' => 'failed'], $statusCode);
                }
            } catch (\Exception $e) {
                // Handle the FCM request exception
                return response()->json(['status' => 'failed', 'message' => 'FCM request failed with error: ' . $e->getMessage()], 500);
            }
        }
        else
        {
            return ["errorMessage"=>'Invalid token.'];
        }
    }

    public function send_qrcode_print_request(Request $request)
    {
        $input = $request->all();
        $accessToken = $this->getAccessToken();

        $result = User::checkUserToken($input['token'], $input['user_id']);
    
        if($result)
        {
            // Get the request parameters
            $qr_url = $request->input('qr_url');
            $table_names = $request->input('table_names');
            $pax = $request->input('pax');
            $device_id = !empty($request->input('device_id')) ? $request->input('device_id') : "";
            $user_id = $request->input('user_id');
            $business_id = $request->input('business_id');
            $location_id = $request->input('location_id');
            $business_location_id = $request->input('business_location_id');
            $json_data = !empty($request->input('json_data')) ? $request->input('json_data') : "";

            $device = Terminal::where('terminals.business_id', $business_id)
                                ->where('terminals.terminal_type', 'primary')
                                ->where('terminals.status', 'active')
                                ->where('terminals.location_id', $business_location_id)
                                ->whereNull('terminals.deleted_at')
                                ->select(['terminals.id','terminals.name', 'terminals.unique_id', 'terminals.fcm_token', 'terminals.device_name', 'terminals.device_id',
                                'terminals.status', 'terminals.created_at', 'terminals.updated_at', 'terminals.deleted_at',
                                'terminals.last_logged_in', 'terminals.id', 'terminals.location_id', 'terminals.business_id', 'terminals.terminal_type'])
                                ->first();

            if ($device) {
                $fcm_token = $device->fcm_token;
                $device_name = $device->device_name;
                // Now you can use $fcm_token and $device_name in your CURL request
            } else {
                // Handle device not found error
            }
            
            if(empty($fcm_token)){
                return response()->json(['message' => 'Fcm Token not found']);
            }
            
            try {

                $encoded_json_data = json_encode($json_data);
                // Send the POST request to FCM server
                $client = new Client();
                $response = $client->post('https://fcm.googleapis.com/v1/projects/warely-29140/messages:send', [
                    'headers' => [
                        'Authorization' => 'Bearer ' . $accessToken,
                        'Content-Type' => 'application/json',
                    ],
                    'json' => [
                        'message' => [
                            'token' => $fcm_token,
                            'data' => [
                                // Have to remove this unnecessary code after testing 

                                //'order_print_request' => [
                                    // 'id' => $transaction_id,
                                    // 'status' => $status,
                                    // 'from' => $device_sub_name,
                                    // 'receipt_type' => $receipt_type,
                                    'notification_type' => 'table_qr_print',
                                    'json_data' => $encoded_json_data,
                                //],
                                ],
                        ],
                    ],
                ]);
    
                $responseBody = json_decode($response->getBody());
                $statusCode = $response->getStatusCode();
    
                if($statusCode == 200) {
                    return response()->json(['status' => 'success'], $statusCode);
                } else {
                    return response()->json(['status' => 'failed'], $statusCode);
                }
            } catch (\Exception $e) {
                // Handle the FCM request exception
                return response()->json(['status' => 'failed', 'message' => 'FCM request failed with error: ' . $e->getMessage()], 500);
            }
        }
        else
        {
            return ["errorMessage"=>'Invalid token.'];
        }
    }
    
    public function updatePosDeviceApi(Request $request)
    {
        $input = $request->all();

        if(isset($input['token']))
        { 
            $result = User::checkUserToken($input['token'], $input['user_id']);

            if($result)
            {
                
                $output = $this->updatePosDevice($input);
                return $output;
            }
            else
            {
                return["errorMessage"=>'Invalid token.'];
            }
        }
        else
        {
            return["errorMessage"=>'Invalid token.'];
        }
    }
    
    public function updatePosDevice($input)
    {
        try {
            // Find any existing device with the same device_id and device_name for this user_id, business_id and business_location_id
            $existingDevice = $this->managePosDevice
                ->where('device_id', $input['device_id'])
                ->first();
                
            if ($existingDevice) {
                $existingDevice->device_fcm_token = $input['device_fcm_token'];
                $existingDevice->save();
            }

            // Return a success response with is_master_device field
            return response()->json(['status' => 'success']);
        } catch (\Exception $e) {
            // Handle the exception as appropriate (e.g. log it, return an error response)
            return response()->json(['status' => 'error', 'message' => $e->getMessage()]);
        }
    }

    public function get_order_print_requests(Request $request)
    {    
        try {
            $print_request_id = $request->input('print_request_id');
            $print_request_order_data = OrderPrintRequest::where('id', $print_request_id)
                            ->first();
            return response()->json($print_request_order_data);
        }
        catch (\Exception $e) {

            return response()->json(['status' => 'failed', 'message' => 'something went wrong'], 500);
        }
            
    }
      public function get_all_order_print_requests(Request $request)
    {
        try {
            $business_id = $request->input('business_id');
            $location_id = $request->input('location_id');
            $terminal_id = $request->input('terminal_id');
            $created_at = $request->input('created_at');
            $current_time = $request->input('current_time');
            $today = "";
            $tomorrow = "";
            
            $businessLocation = BusinessLocation::find($location_id);
            if (!empty($businessLocation) && !empty($businessLocation->day_start_time)) {
                $daystartTime = $businessLocation->day_start_time;
                $dayStartTime = $daystartTime . ":00:00";
                $dayendTime = $daystartTime - 1;
                $dayEndTime = $dayendTime . ":59:59";
            } else {
                $dayStartTime = str_replace(' ', '', Config::get('constants.businessStartTimeDefault'));
                $dayEndTime = str_replace(' ', '', Config::get('constants.businessEndTimeDefault'));
            }
    
            if (isset($dayStartTime) && !empty($businessLocation) && !empty($businessLocation->day_start_time) && !empty($current_time) && !empty($created_at)) {
                $morning6TimeStamp = strtotime($created_at . $dayEndTime);
                $dateTimeStamp = strtotime($created_at . " " . $current_time);
                if ($dateTimeStamp >= $morning6TimeStamp) {
                    $today = $created_at . ' ' . $dayStartTime;
                    $tomorrow = date('Y-m-d', strtotime($created_at . ' +1 day')) . ' ' . $dayEndTime;
                } else {
                    $today = date('Y-m-d', strtotime($created_at . ' -1 day')) . ' ' . $dayStartTime;
                    $tomorrow = $created_at . ' ' . $dayEndTime;
                }
            } else {
                $today = $created_at . Config::get('constants.businessStartTimeDefault');
                $tomorrow = $created_at . Config::get('constants.businessEndTimeDefault');
            }
           
            $print_request_order_data = OrderPrintRequest::where('business_id', $business_id)
                                                        ->where('location_id', $location_id)
                                                        ->where('to_terminal_id', $terminal_id)
                                                        ->whereBetween('created_at', [$today, $tomorrow])
                                                        ->orderBy('created_at', 'desc')
                                                         ->get();
            
                                                        
            return response()->json($print_request_order_data);
        } 
        catch (\Exception $e) {

            return response()->json(['status' => 'failed', 'message' => 'something went wrong'], 500);
        }
    }

    public function delete_print_requests(Request $request)
    {
        try {
            $business_id = $request->input('business_id');
            $location_id = $request->input('location_id');
            $terminal_id = $request->input('terminal_id');
            $deletedRows = OrderPrintRequest::where('business_id', $business_id)
                                            ->where('location_id', $location_id)
                                            ->where('to_terminal_id', $terminal_id)
                                            ->delete();
            if($deletedRows){
                return response()->json(['status' => 'success',  'message' => 'Deleted successfully.']);
            }   
            else{
                return response()->json(['status' =>'failed', 'message' => 'Print request not found.']);
            }                             
        } 
        catch (\Exception $e) {
            return response()->json(['status' => 'failed', 'message' => 'something went wrong'], 500);
        }
    }

    private function getAccessToken()
    {
        $serviceAccountFile = config('constants.awsS3BaseUrl') . "/" . config('constants.awsS3Env') . "/fcm/" . rawurlencode("warely-29140-firebase-adminsdk-yg05w-8e7ff8db41.json");
        $serviceAccountData = json_decode(file_get_contents($serviceAccountFile), true);
        
        if($serviceAccountData == null) {
            $serviceAccountFile = storage_path('warely-29140-firebase-adminsdk-yg05w-8e7ff8db41.json');
            $serviceAccountData = json_decode(file_get_contents($serviceAccountFile), true);
        }
        
        $clientEmail = $serviceAccountData['client_email'] ?? null;
        $privateKey = $serviceAccountData['private_key'] ?? null;

        if (!$clientEmail || !$privateKey) {
            throw new \Exception('Client email or private key is missing in the service account file.');
        }
        
        $scopes = ['https://www.googleapis.com/auth/cloud-platform'];

        $oauth2 = new OAuth2([
            'issuer' => $clientEmail,
            'sub' => $clientEmail,
            'audience' => 'https://oauth2.googleapis.com/token', // Correct audience
            'signingKey' => $privateKey,
            'signingAlgorithm' => 'RS256',
            'scope' => $scopes,
        ]);

        //$tokenCredentialUri = $oauth2->getTokenCredentialUri();
        $tokenCredentialUri = $serviceAccountData['token_uri'] ?? null;

        if (filter_var($tokenCredentialUri, FILTER_VALIDATE_URL) === false) {
            throw new \Exception('Invalid tokenCredentialUri: ' . $tokenCredentialUri);
        }

        $jwt = $oauth2->toJwt();
        $client = new Client();
        $response = $client->post($tokenCredentialUri, [
            'form_params' => [
                'grant_type' => 'urn:ietf:params:oauth:grant-type:jwt-bearer',
                'assertion' => $jwt,
            ]
        ]);

        $token = json_decode($response->getBody()->getContents(), true);

        if (isset($token['access_token'])) {
            return $token['access_token'];
        } else {
            throw new \Exception('Failed to obtain access token: ' . json_encode($token));
        }

    }

    public function send_order_print_request_terminal(Request $request)
    {
        $input = $request->all();
        $accessToken = $this->getAccessToken();
                
            $transaction_id = $request->input('transaction_id');
            $status = $request->input('status');
            $device_id = !empty($request->input('device_id')) ? $request->input('device_id') : "";
            $receipt_type = $request->input('receipt_type');
            $user_id = $request->input('user_id');
            $business_id = $request->input('business_id');
            $location_id = $request->input('location_id');
            $terminal_id = $request->input('terminal_id');
            
            $business_location_id = $request->input('business_location_id');
            $json_data = !empty($request->input('json_data')) ? $request->input('json_data') : "";
    
            // Fetch the FCM token for the device ID
            $device = Terminal::where('terminals.business_id', $business_id)
                            ->where('terminals.terminal_type', 'primary')
                            ->where('terminals.status', 'active')
                            ->where('terminals.location_id', $business_location_id)
                            ->whereNull('terminals.deleted_at')
                            ->select(['terminals.id','terminals.name', 'terminals.unique_id', 'terminals.fcm_token', 'terminals.device_name', 'terminals.device_id',
                            'terminals.status', 'terminals.created_at', 'terminals.updated_at', 'terminals.deleted_at',
                            'terminals.last_logged_in', 'terminals.id', 'terminals.location_id', 'terminals.business_id', 'terminals.terminal_type'])
                            ->first();

            
            if ($device) {
                $fcm_token = $device->fcm_token;
                $device_name = $device->device_name;
            } else {
                // Handle device not found error
            }
            
            if(empty($fcm_token)){
                return response()->json(['message' => 'Fcm Token not found']);
            }
            
            $order_print_request = OrderPrintRequest::create([
                'transaction_id' => $transaction_id,
                'status' => $status,
                'from_device_id' => $device_id,
                'to_device_id'=>$device ? $device->device_id :'',
                'receipt_type' => $receipt_type,
                'user_id' => $user_id,
                'business_id' => $business_id,
                'location_id' => $location_id,
                'business_location_id' => $business_location_id,
                'from_terminal_id' => $terminal_id,
                'to_terminal_id'=>$device? $device->id :'',
                'json_data' => $json_data
            ]);
            
            $json_data_decoded = json_decode($json_data, true);

    
            $jsonData= [
                'id' => $order_print_request->id,
                'invoice_no' => $json_data_decoded['invoice_no'],
                'type' => $json_data_decoded['type'],
                'receipt_type' => $json_data_decoded['receipt_type'],
                'received_time'=> \Carbon::now()->format('Y-m-d H:i:s')
            ];
            $transaction_id = !empty($transaction_id) ? $transaction_id : "";
            $status = !empty($status) ? $status : "";

            $encoded_json_data = json_encode($jsonData);
            $escaped_json_data = addslashes($encoded_json_data);

            $final_encoded_json_data = '"' . $escaped_json_data . '"';

            try {
                // Send the POST request to FCM server
                $client = new Client();
                $response = $client->post('https://fcm.googleapis.com/v1/projects/warely-29140/messages:send', [
                    'headers' => [
                        'Authorization' => 'Bearer ' . $accessToken,
                        'Content-Type' => 'application/json',
                    ],
                    'json' => [
                        'message' => [
                            'token' => $fcm_token,
                            'data' => [
                                // Have to remove this unnecessary code after testing 

                                //'order_print_request' => [
                                    // 'id' => $transaction_id,
                                    // 'status' => $status,
                                    // 'from' => $device_sub_name,
                                    // 'receipt_type' => $receipt_type,
                                    'notification_type' => 'order_print',
                                    'json_data' => $final_encoded_json_data,
                                //],
                                ],
                        ],
                    ],
                ]);
    
                $responseBody = json_decode($response->getBody());
                
                $statusCode = $response->getStatusCode();

    
                if($statusCode == 200) {
                    return response()->json(['status' => 'success'], $statusCode);
                } else {
                    return response()->json(['status' => 'failed'], $statusCode);
                }
            } catch (\Exception $e) {
                return response()->json(['status' => 'failed', 'message' => 'FCM request failed with error: ' . $e->getMessage()], 200);
            }
    }
}