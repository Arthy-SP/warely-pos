<?php

namespace App\Http\Controllers;

use App\VariationTemplate;
use App\VariationValueTemplate;
use App\ProductVariation;
use App\Variation;

use Illuminate\Http\Request;

use Yajra\DataTables\Facades\DataTables;
use DB;

class RetailVariationTemplateController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        if (request()->ajax()) {
            $business_id = request()->session()->get('user.business_id');

            $variations = VariationTemplate::where('business_id', $business_id)
                        ->where('type', 'retail')
                        ->with(['values'])
                        ->select('id', 'name', DB::raw("(SELECT COUNT(id) FROM product_variations WHERE product_variations.variation_template_id=variation_templates.id) as total_pv"));

            return Datatables::of($variations)
                ->editColumn('values', function ($data) {
                    $values_arr = [];
                    foreach ($data->values as $attr) {
                        $values_arr[] = $attr->name;
                    }
                    return implode(', ', $values_arr);
                })
                ->editColumn('value', function ($data) {
                    $values_arr = [];
                    foreach ($data->values as $attr) {
                        $values_arr[] = $attr->value;
                    }
                    return implode(', ', $values_arr);
                })
                ->removeColumn('id')
                ->removeColumn('total_pv')
                ->addColumn(
                    'action',
                    '<button data-href="{{action(\'RetailVariationTemplateController@edit\', [$id])}}" class="btn btn-xs btn-primary edit_retail_variation_button"><i class="glyphicon glyphicon-edit"></i> @lang("messages.edit")</button>
                        &nbsp;
                        @if(empty($total_pv))
                        <button data-href="{{action(\'RetailVariationTemplateController@destroy\', [$id])}}" class="btn btn-xs btn-danger delete_variation_button"><i class="glyphicon glyphicon-trash"></i> @lang("messages.delete")</button>
                        @endif'
                )
                ->rawColumns(['action'])
                ->make(true);
        }
        return view('retail_variation.index');
    }


    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('retail_variation.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        try {
            // Validate and get input
            $input = $request->only(['name']);
            $input['type'] = 'retail'; 
            $input['business_id'] = $request->session()->get('user.business_id');
            $variation = VariationTemplate::create($input);

            // Create variation values
            $names = $request->input('variation_names');
            $values = $request->input('variation_values');

            $data = [];
            foreach ($names as $index => $name) {
                if (!empty($name)) {
                    $data[] = [
                        'name' => $name,
                        'value' => isset($values[$index]) ? $values[$index] : null
                    ];
                }
            }

            if (!empty($data)) {
                
                    $variation->values()->createMany($data);
                
            }

            $output = [
                'success' => true,
                'data' => $variation,
                'msg' => 'Variation added successfully'
            ];
        } catch (\Exception $e) {
            \Log::emergency("File:" . $e->getFile() . " Line:" . $e->getLine() . " Message:" . $e->getMessage());
            
            $output = [
                'success' => false,
                'msg' => 'Something went wrong, please try again'
            ];
        }

        return $output;
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\VariationTemplate  $variationTemplate
     * @return \Illuminate\Http\Response
     */
    public function show(VariationTemplate $variationTemplate)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        if (request()->ajax()) {
            $business_id = request()->session()->get('user.business_id');
            $variation = VariationTemplate::where('business_id', $business_id)
                            ->with(['values'])->find($id);

            return view('retail_variation.edit')
                ->with(compact('variation'));
        }
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
   public function update(Request $request, $id)
    {
        if ($request->ajax()) {
            try {
                $input = $request->only(['name']);
                $business_id = $request->session()->get('user.business_id');
    
                $variation = VariationTemplate::where('business_id', $business_id)->findOrFail($id);
    
                // Update variation name
                if ($variation->name != $input['name']) {
                    $variation->name = $input['name'];
                    $variation->save();
    
                    ProductVariation::where('variation_template_id', $variation->id)
                                    ->update(['name' => $variation->name]);
                }
    
                $existing_values = $variation->values->keyBy('id')->toArray();
    
                // Update existing variation values
                $updated_ids = [];
                if (!empty($request->input('edit_variation_names'))) {
                    $names = $request->input('edit_variation_names');
                    $values = $request->input('edit_variation_values');
    
                    foreach ($names as $key => $name) {
                        if (!empty($name) && !empty($values[$key])) {
                            $variation_val = VariationValueTemplate::find($key);
                            $variation_val->name = $name;
                            $variation_val->value = $values[$key];
                            $variation_val->save();
                            
                            // Track updated IDs
                            $updated_ids[] = $key;
    
                            // Update related variations
                            Variation::where('variation_value_id', $key)
                                ->update(['name' => $name]);
                        }
                    }
                }
    
                // Delete variation values that were removed
                $deleted_ids = array_diff(array_keys($existing_values), $updated_ids);
                if (!empty($deleted_ids)) {
                    VariationValueTemplate::destroy($deleted_ids);
                    Variation::whereIn('variation_value_id', $deleted_ids)->delete();
                }
    
                // Add new variation values
                if (!empty($request->input('variation_names'))) {
                    $names = $request->input('variation_names');
                    $values = $request->input('variation_values');
                    foreach ($names as $index => $name) {
                        if (!empty($name) && !empty($values[$index])) {
                            $variation->values()->create(['name' => $name, 'value' => $values[$index]]);
                        }
                    }
                }
    
                $output = ['success' => true,
                            'msg' => 'Variation updated successfully'
                            ];
            } catch (\Exception $e) {
                \Log::emergency("File:" . $e->getFile() . " Line:" . $e->getLine() . " Message:" . $e->getMessage());
            
                $output = ['success' => false,
                            'msg' => 'Something went wrong, please try again'
                        ];
            }
    
            return $output;
        }
    }
    

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        if (request()->ajax()) {
            try {
                $business_id = request()->session()->get('user.business_id');

                $variation = VariationTemplate::where('business_id', $business_id)->findOrFail($id);
                $variation->delete();

                $output = ['success' => true,
                            'msg' => 'Category deleted succesfully'
                            ];
            } catch (\Eexception $e) {
                \Log::emergency("File:" . $e->getFile(). "Line:" . $e->getLine(). "Message:" . $e->getMessage());
            
                $output = ['success' => false,
                            'msg' => 'Something went wrong, please try again'
                        ];
            }

            return $output;
        }
    }
}
