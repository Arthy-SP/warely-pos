<?php

namespace App\Http\Controllers;

use App\BusinessLocation;
use App\Campaign;
use App\TelegramChannel;
use App\TelegramToken;
use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Illuminate\Support\Facades\Input;


use App\Business;
use App\User;
use DB;
use Redirect;
use Yajra\DataTables\Facades\DataTables;
use GuzzleHttp\Client;

class TelegramController extends Controller {
    /**
     * Display a listing of the resource.
     * @return Response
     */
    public function index() {
        if(!auth()->user()->can('telegram_channel.view')) {
            abort(403, 'Unauthorized action.');
        }

        $business_id = request()->session()->get('user.business_id');
        // dd($business_id);
        $telegram_channels = TelegramChannel::where('telegram_channels.business_id', $business_id)
            ->leftjoin(
                'business_locations as bl',
                'telegram_channels.location_id',
                '=',
                'bl.id'
            )
            ->select(['telegram_channels.id', 'telegram_channels.name', 'channel_id', 'type', 'telegram_channels.location_id', 'bl.name as business_location_name']);

        return DataTables::of($telegram_channels)
            ->addColumn(
                'action',
                '<button data-href ="{{action(\'TelegramController@edit\', ["id" => $id])}}" class="btn btn-primary btn-xs btn-primary edit_telegram_channel_or_group_button"><i class="glyphicon glyphicon-edit"></i>
                    @lang( "messages.edit")
                    </button>
                    <button data-href ="{{action(\'TelegramController@destroy\',[$id])}}" class="btn btn-danger btn-xs delete_telegram_channel_or_group_button"> <i class="glyphicon glyphicon-trash"></i> @lang("messages.delete")</button>'
            )
            ->editColumn('id', function ($row) {
                return $row->id;
            })
            ->editColumn('name', function ($row) {
                return $row->name;
            })
            ->editColumn('type', function ($row) {
                if($row->type == 'channel'){
                    return 'Channel';
                }else{
                    return 'Group';
                }
            })
            ->rawColumns(['action'])
            ->make(true);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create() {
        if(!auth()->user()->can('telegram_channel.create')) {
            abort(403, 'Unauthorized action.');
        }

        $business_id = request()->session()->get('user.business_id');
        $business_locations = BusinessLocation::where('business_id', $business_id)
            ->get()
            ->pluck('name', 'id');
        return view('telegram_channel.create')->with(compact('business_locations'));
    }

    public function store(Request $request) {
        if(!auth()->user()->can('telegram_channel.create')) {
            abort(403, 'Unauthorized action.');
        }
        try {
            $business_id = $request->session()->get('user.business_id');
            $token = TelegramToken::where('business_id', $business_id)->value('token_id');
            $input = $request->only(['name', 'channel_id']);
            $input['business_id'] = $business_id;
            $input['location_id'] = !empty($request->business_location_id) ? $request->business_location_id : 0;
            if(empty($token)){
                $output = [
                    'success' => false,
                    'msg' => 'Telegram bot token not found please add first bot.'
                ];
                return $output;
            }
            
            $jsonResponse = $this->checkTelegramChannel($request->input('channel_id'), $token);
            $data = $jsonResponse->getData();
            
            if(isset($data->status) && $data->status === true) {
                if(!TelegramChannel::where('channel_id', Input::get('channel_id'))->exists()) {
                    $input['channel_int_id'] = $data->channel_info->id;
                    $input['type'] = $data->channel_info->type;
                    TelegramChannel::create($input);
                    $output = [
                        'success' => 1,
                        'msg' => 'Successfully added'
                    ];
                } else {
                    $output = [
                        'success' => 0,
                        'msg' => 'This telegram channel already exist.'
                    ];
                }
            } else {
                $output = [
                    'success' => false,
                    'msg' => 'This is not a valid channel/group id.'
                ];
            }
        } catch (\Exception $e) {
            \Log::emergency("File:".$e->getFile()."Line:".$e->getLine()."Message:".$e->getMessage());

            $output = ['success' => 0,
                'msg' => __("messages.something_went_wrong")
            ];
        }
        return $output;

    }

    public function edit($id) {
        if(!auth()->user()->can('telegram_channel.update')) {
            abort(403, 'Unauthorized action.');
        }
        if(request()->ajax()) {
            $business_id = request()->session()->get('user.business_id');
            $telegram_channel = TelegramChannel::where('business_id', $business_id)->find($id);

            $business_locations = BusinessLocation::where('business_id', $business_id)
                ->get()
                ->pluck('name', 'id');

            return view('telegram_channel.edit')
                ->with(compact('telegram_channel', 'business_locations'));
        }
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, $id) {
        if(!auth()->user()->can('telegram_channel.update')) {
            abort(403, 'Unauthorized action.');
        }
        try {
            $business_id = $request->session()->get('user.business_id');
            $token = TelegramToken::where('business_id', $business_id)->value('token_id');
            
            if(empty($token)){
                $output = [
                    'success' => false,
                    'msg' => 'Telegram bot token not found please add first bot.'
                ];
                return $output;
            }
            
            $telegram_channel = TelegramChannel::where('business_id', $business_id)->findOrFail($id);
            $telegram_channel->name = $request->input('name');
            $telegram_channel->location_id = !empty($request->business_location_id) ? $request->business_location_id : 0;
            $jsonResponse = $this->checkTelegramChannel($request->input('channel_id'), $token);
            $data = $jsonResponse->getData();
            if(isset($data->status) && $data->status === true) {
                if($telegram_channel->channel_id != $request->input('channel_id') && TelegramChannel::where([['channel_id', $request->input('channel_id')], ['business_id', $business_id]])->exists()) {
                    $output = [
                        'success' => false,
                        'msg' => 'This telegram channel already exist.'
                    ];
                } else {
                    $telegram_channel->channel_id = $request->input('channel_id');
                    $telegram_channel->channel_int_id = $data->channel_info->id;
                    $telegram_channel->type = $data->channel_info->type;
                    $telegram_channel->save();
                    $output = [
                        'success' => true,
                        'msg' => 'Telegram channel/group successfully updated'
                    ];
                }
            } else {
                $output = [
                    'success' => false,
                    'msg' => 'This is not a valid channel/group id.'
                ];
            }
        } catch (\Exception $e) {
            \Log::emergency("File:".$e->getFile()."Line:".$e->getLine()."Message:".$e->getMessage());
            $output = ['success' => false,
                'msg' => __("messages.something_went_wrong")
            ];
        }
        return $output;
    }

    public function destroy($id) {

        if(!auth()->user()->can('telegram_channel.delete')) {
            abort(403, 'Unauthorized action.');
        }

        if(request()->ajax()) {
            try {
                $business_id = request()->user()->business_id;

                $t_channel = TelegramChannel::where('business_id', $business_id)->findOrFail($id);
                $t_channel->delete();

                $output = ['success' => true,
                    'msg' => __("superadmin::lang.deleted_success")
                ];
            } catch (\Exception $e) {
                \Log::emergency("File:".$e->getFile()."Line:".$e->getLine()."Message:".$e->getMessage());

                $output = ['success' => false,
                    'msg' => __("messages.something_went_wrong")
                ];
            }
            return $output;
        }
    }

    public function checkTelegramChannel($channelId, $token) {
        try {
            $client = new Client();
            $response = $client->get("https://api.telegram.org/bot{$token}/getChat", [
                'query' => ['chat_id' => $channelId],
            ]);

            $result = json_decode($response->getBody(), true);

            // Check if the API call was successful and the response contains valid channel information
            if($response->getStatusCode() == 200 && isset($result['result']['id'])) {
                return response()->json(['status' => true, 'channel_info' => $result['result']]);
            }

            // Channel is not valid
            return response()->json(['valid' => false, 'message' => 'Invalid Telegram channel.']);
        } catch (\Exception $e) {
            // Handle exceptions (e.g., network issues, invalid token, etc.)
            return response()->json(['valid' => false, 'message' => $e->getMessage()]);
        }
    }
}