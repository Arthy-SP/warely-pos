<?php

namespace App\Http\Controllers;

use App\BusinessLocation;
use App\TelegramToken;
use GuzzleHttp\Client;
use Illuminate\Http\Request;
use Yajra\DataTables\Facades\DataTables;

class TelegramTokenController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        if (!auth()->user()->can('telegram.view') && !auth()->user()->can('telegram.create')) {
            abort(403, 'Unauthorized action.');
        }
        if (request()->ajax()) {
            $business_id = request()->session()->get('user.business_id');

            $telegram_tokens = TelegramToken::where('telegram_tokens.business_id', $business_id)
                                            ->leftjoin(
                                                'business_locations as bl',
                                                'telegram_tokens.location_id',
                                                '=',
                                                'bl.id'
                                            )
                                        ->select(['telegram_tokens.id', 'telegram_tokens.name', 'token_id', 'telegram_tokens.location_id', 'bl.name as business_location_name']);
            return DataTables::of($telegram_tokens)
                ->addColumn(
                    'action',
                    '@can("telegram_token.update")
                    <button data-href="{{action(\'TelegramTokenController@edit\', [$id])}}" class="btn btn-xs btn-primary edit_telegram_token_button"><i class="glyphicon glyphicon-edit"></i> @lang("messages.edit")</button>
                        &nbsp;
                    @endcan
                    @can("telegram_token.delete")
                        <button data-href="{{action(\'TelegramTokenController@destroy\', [$id])}}" class="btn btn-xs btn-danger delete_telegram_token_button"><i class="glyphicon glyphicon-trash"></i> @lang("messages.delete")</button>
                    @endcan'
                )
                // ->removeColumn('id')
                ->rawColumns([0, 2])
                ->make(true);
        }

        return view('telegram.index');
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        if (!auth()->user()->can('telegram.create')) {
            abort(403, 'Unauthorized action.');
        }
        $business_id = request()->session()->get('user.business_id');
        $business_locations = BusinessLocation::where('business_id', $business_id)
                            ->get()
                            ->pluck('name', 'id');
        return view('telegram.create')
            ->with(compact('business_locations'));
        
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        if (!auth()->user()->can('telegram.create')) {
            abort(403, 'Unauthorized action.');
        }

        try {
            $input = $request->only(['name', 'token_id']);
            $input['business_id'] = $request->session()->get('user.business_id');
            $input['created_by'] = $request->session()->get('user.id');
            $input['location_id'] = !empty($request->business_location_id) ? $request->business_location_id : 0;
            
            $isToken = $this->checkBotTokenIsValid($input['token_id']);
            $input['username']= $isToken;
            if(!empty($isToken)){
                $bot_token = TelegramToken::create($input);
                $output = [
                            'success' => true,
                            'data' => $bot_token,
                            'msg' => __("telegram_token.added_success")
                        ];
            }else{
                $output = ['success' => false,
                    'msg' => "Invalid token id please check again."
                ];
            }
        } catch (\Exception $e) {
            \Log::emergency("File:" . $e->getFile(). "Line:" . $e->getLine(). "Message:" . $e->getMessage());
            $output = ['success' => false,
                            'msg' => __("messages.something_went_wrong")
                        ];
        }

        return $output;
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\TelegramToken  $telegramToken
     * @return \Illuminate\Http\Response
     */
    public function show(TelegramToken $telegramToken)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\TelegramToken  $telegramToken
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        if(!auth()->user()->can('telegram.update')){
            abort(403, 'Unauthorized action');
        }

        if(request()->ajax()){
            $business_id=request()->session()->get('user.business_id');
            $telegram_token = TelegramToken::where('business_id', $business_id)->find($id);

            $business_locations = BusinessLocation::where('business_id', $business_id)
                            ->get()
                            ->pluck('name', 'id');
            
            return view('telegram.edit')
                ->with(compact('telegram_token', 'business_locations'));
        }
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\TelegramToken  $telegramToken
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        if (!auth()->user()->can('telegram.update')) {
            abort(403, 'Unauthorized action.');
        }
        if (request()->ajax()) {
            try {
                $input = $request->only(['name', 'token_id']);
                $business_id = $request->session()->get('user.business_id');

                $telegram_token = TelegramToken::where('business_id', $business_id)->findOrFail($id);
                $telegram_token->name = $input['name'];
                $telegram_token->token_id = $input['token_id'];
                $telegram_token->location_id = !empty($request->business_location_id) ? $request->business_location_id : 0;
                $isToken = $this->checkBotTokenIsValid($input['token_id']);
                $telegram_token->username = $isToken;
                if(!empty($isToken)){
                    $telegram_token->save();
                    $output = [
                                'success' => true,
                                'data' =>  $telegram_token,
                                'msg' => __("telegram_token.updated_success")
                            ];
                }else{
                    $output = [
                        'success' => false,
                        'msg' => "Invalid token id please check again."
                    ];
                }
            } catch (\Exception $e) {
                \Log::emergency("File:" . $e->getFile(). "Line:" . $e->getLine(). "Message:" . $e->getMessage());
            
                $output = ['success' => false,
                            'msg' => __("messages.something_went_wrong")
                        ];
            }

            return $output;
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\TelegramToken  $telegramToken
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        if (!auth()->user()->can('tax_rate.delete')) {
            abort(403, 'Unauthorized action.');
        }

        if (request()->ajax()) {
            try {
                if (is_numeric($id)) {
                    $business_id = request()->user()->business_id;

                    $tax_rate = TelegramToken::where('business_id', $business_id)->findOrFail($id);
                    $tax_rate->delete();

                    $output = ['success' => true,
                                'msg' => __("telegram_token.deleted_success")
                                ];
                } else {
                    $output = ['success' => false,
                                'msg' => __("telegram_token.can_not_be_deleted")
                                ];
                }
            } catch (\Exception $e) {
                \Log::emergency("File:" . $e->getFile(). "Line:" . $e->getLine(). "Message:" . $e->getMessage());
            
                $output = ['success' => false,
                            'msg' => __("messages.something_went_wrong")
                        ];
            }
            return $output;
        }
    }

    public function checkBotTokenIsValid($botToken)
    {
        $client = new Client();
        try {
            $response = $client->get("https://api.telegram.org/bot$botToken/getMe");
            $data = json_decode($response->getBody(), true);

            if (isset($data['ok']) && $data['ok'] === true) {
                $botUsername = $data['result']['username'];
                return $botUsername;
            }
        } catch (\Exception $e) {
            \Log::info('Error Data----' . $e->getMessage());
        }
    }
}
