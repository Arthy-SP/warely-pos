<?php

namespace App\Http\Controllers;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\DB;
use App\Services\TwilioOTPService;
use App\Utils\TransactionUtil;
use Illuminate\Http\Request;
use App\CreditTransaction;
use App\BusinessLocation;
use Carbon\Carbon;
use Datatables;
use App\Credit;
use App\User;

class CreditReportController extends Controller
{
    public function __construct() {

    }
    public function index()
    {
        if (!auth()->user()->can('access_tables')) {
            abort(403, 'Unauthorized action.');
        }

        $business_id = request()->session()->get('user.business_id');
        $business_locations = BusinessLocation::forDropdown($business_id);
        if (request()->ajax()) {
            $location_id = request()->get('location_id', null);               
            $transactions = CreditTransaction::select(DB::raw('DATE(credit_transactions.created_at) as date'), DB::raw('SUM(credit_transactions.amount) as total_amount'), DB::raw('SUM(cp.promo_amount) as total_promo_amount'))
                                ->leftjoin('credit_promos AS cp', 'credit_transactions.credit_promo_id', '=', 'cp.id')
                                ->where('credit_transactions.business_id', $business_id)
                                ->where('credit_transactions.is_void', '!=', 1)
                                ->where('credit_transactions.transaction_type', 'credit')
                                ->whereNotIn('credit_transactions.remark', ['Order Refund']);
                                if (!empty($location_id) && $location_id != 'none') {
                                    $transactions->where('credit_transactions.location_id', $location_id);
                                }
                                $transactions->orderBy('credit_transactions.created_at', 'desc')
                                ->orderBy('date', 'desc') // Order by date in ascending order
                                ->groupBy(DB::raw('DATE(credit_transactions.created_at)'));

            return Datatables::of($transactions)
                ->addColumn('action', function ($transactions) use ($business_id) {
                    $transactionsButton = '';
                    $location_id = request()->get('location_id', null);
                    if (auth()->user()->can("Admin#" . $business_id)) {
                        $transactionsButton = '<a href="' . action('CreditReportController@show', [$transactions->date, 'location_id' => $location_id]) . '" class="btn btn-xs btn-primary " style= "margin-right: 5px"><i class="fa fa-eye"></i> Show</a>';
                    }
                    return $transactionsButton;
                })
                ->addColumn(
                    'total_topup_amount',
                    '<div style="white-space: nowrap;">@format_currency($total_amount - $total_promo_amount)</div>'
                )
                ->addColumn(
                    'total_promo_amount',
                    '<div style="white-space: nowrap;">@format_currency($total_promo_amount)</div>'
                )
                ->addColumn(
                    'total_amount',
                    '<div style="white-space: nowrap;">@format_currency($total_amount)</div>'
                )
                ->removeColumn('id')
                ->rawColumns(['action', 'date', 'amount', 'total_amount', 'total_topup_amount', 'total_promo_amount'])
                ->make(true);
       }

       return view('credits_reports.index')->with(compact("business_locations"));;
    }

    /**
     * Show the specified resource.
     * @return Response
     */
    public function show($date, $location_id = null)
    {
        if (!auth()->user()->can('account.access')) {
            abort(403, 'Unauthorized action.');
        }
        $business_id = request()->session()->get('user.business_id');

        if($date) {
            $business_locations = BusinessLocation::forDropdown($business_id);
            $credit_topup = CreditTransaction::select(DB::raw('DATE(credit_transactions.created_at) as date'), DB::raw('SUM(credit_transactions.amount) as total_amount'), DB::raw('SUM(cp.promo_amount) as total_promo_amount'))
                                ->leftjoin('credit_promos AS cp', 'credit_transactions.credit_promo_id', '=', 'cp.id')
                                ->where('credit_transactions.business_id', $business_id)
                                ->whereBetween('credit_transactions.created_at', [$date . " 00:00:00", $date . " 23:59:59"])
                                ->where('credit_transactions.transaction_type', 'credit')
                                ->where('credit_transactions.is_void', '!=', 1)
                                ->whereNotIn('credit_transactions.remark', ['Order Refund'])
                                ->groupBy(DB::raw('DATE(credit_transactions.created_at)'))
                                ->orderBy('date', 'desc') // Order by date in ascending order
                                ->first();

            $payment_methods = CreditTransaction::select('credit_transactions.payment_type', DB::raw('SUM(credit_transactions.amount) as total_amount'))
                                ->where('credit_transactions.business_id', $business_id)
                                ->where('credit_transactions.is_void', '!=', 1)
                                ->whereBetween('credit_transactions.created_at', [$date . " 00:00:00", $date . " 23:59:59"])
                                ->where('credit_transactions.transaction_type', 'credit')
                                ->whereNotIn('credit_transactions.remark', ['Order Refund'])
                                ->groupBy('credit_transactions.payment_type')
                                ->get();

            if (request()->ajax()) { 
                $location_id = $location_id ? $location_id : request()->get('location_id', null);               
                $creditTransactions = CreditTransaction::where('credit_transactions.business_id', $business_id)
                                    ->join('credits AS c', 'credit_transactions.credit_id', '=', 'c.id')
                                    ->leftjoin('credit_promos AS cp', 'credit_transactions.credit_promo_id', '=', 'cp.id')
                                    ->whereBetween('credit_transactions.created_at', [$date . " 00:00:00", $date . " 23:59:59"])
                                    ->where('credit_transactions.transaction_type', 'credit')
                                    ->whereNotIn('credit_transactions.remark', ['Order Refund']);

                                // Adding filter based on location ID if it's not empty
                                if (!empty($location_id) && $location_id != 'none') {
                                    $creditTransactions->where('credit_transactions.location_id', $location_id);
                                }

               $creditTransactions->select([
                       'credit_transactions.payment_type', 
                       'credit_transactions.amount', 
                       'credit_transactions.remark', 
                       'credit_transactions.credit_id', 
                       'credit_transactions.created_at', 
                       'cp.amount AS actual_amount', 
                       'cp.promo_amount',
                       'credit_transactions.void_reason',
                       'credit_transactions.is_void', 
                       'credit_transactions.location_id',
                       'c.phone_number'
                   ])
                   ->orderBy("credit_transactions.created_at", 'desc');

                return Datatables::of($creditTransactions)
                ->addColumn(
                    'topup_amount',
                    '<div style="white-space: nowrap;">@format_currency($amount - $promo_amount)</div>'
                )
                ->addColumn(
                    'promo_amount',
                    '<div style="white-space: nowrap;">@format_currency($promo_amount)</div>'
                )
                ->addColumn(
                    'amount',
                    '<div style="white-space: nowrap;">@format_currency($amount)</div>'
                )
                ->filterColumn('phone_number', function ($query, $keyword) {
                    $query->where(function ($q) use ($keyword) {
                        $q->where('c.phone_number', 'like', "%{$keyword}%");
                    });
                })
                ->rawColumns(['transaction_type', 'payment_type', 'amount', 'remark', 'credit_id', 'created_at', 'phone_number', 'actual_amount', 'promo_amount', 'topup_amount', 'void_reason','is_void'])
                ->make(true);
            }

            return view('credits_reports.transactions')->with(compact('date', 'credit_topup', "payment_methods","business_locations","location_id"));
        } else {
            return redirect()->route('credit/reports');
        }
    }


    public function creditTopupList(Request $request) {
        $request->validate([
            'token' => 'required|string',
            'user_id' => 'required|string',
            'business_id' => 'required|string'
        ]);

        $user_id = $request->input('user_id');
        $user_token = $request->input('token');
        $business_id = $request->input('business_id');
        $location_id = $request->input('location_id');

        if (!User::checkUserToken($user_token, $user_id)) {
            return response()->json(['errorMessage' => 'Invalid token.'], 200);
        }

        $transactions = CreditTransaction::select(DB::raw('DATE(credit_transactions.created_at) as date'), DB::raw('SUM(credit_transactions.amount) as total_amount'), DB::raw('SUM(cp.promo_amount) as total_promo_amount'))
                                ->leftjoin('credit_promos AS cp', 'credit_transactions.credit_promo_id', '=', 'cp.id')
                                ->where('credit_transactions.business_id', $business_id)
                                ->where('credit_transactions.is_void', '!=', 1)
                                ->where('credit_transactions.transaction_type', 'credit')
                                ->where('credit_transactions.location_id', $location_id)
                                ->whereNotIn('credit_transactions.remark', ['Order Refund'])
                                ->groupBy(DB::raw('DATE(credit_transactions.created_at)'))
                                ->orderBy("credit_transactions.created_at", 'desc')
                                ->orderBy('date', 'desc') // Order by date in ascending order
                                ->get();

        if (!$transactions) {
            return response()->json(['errorMessage' => 'Credit Topup list not found.'], 200);
        }
        return response()->json($transactions, 200);
    }
    public function creditTopupTransactions(Request $request) {
        $request->validate([
            'token' => 'required|string',
            'user_id' => 'required|string',
            'business_id' => 'required|string',
            'date' => 'required|string'
        ]);

        $user_id = $request->input('user_id');
        $user_token = $request->input('token');
        $business_id = $request->input('business_id');
        $date = $request->input('date');
        $is_location_wise = $request->input('is_location_wise') ? true : false;
        $location_id = $request->input('location_id');

        if (!User::checkUserToken($user_token, $user_id)) {
            return response()->json(['errorMessage' => 'Invalid token.'], 200);
        }

        $query = CreditTransaction::where('credit_transactions.business_id', $business_id)
                                    ->join('credits AS c', 'credit_transactions.credit_id', '=', 'c.id')
                                    ->leftjoin('credit_promos AS cp', 'credit_transactions.credit_promo_id', '=', 'cp.id')
                                    ->leftJoin('users AS u', function($join) {
                                        $join->on(DB::raw('CONVERT(c.phone_number USING utf8mb4)'), '=', DB::raw('CONVERT(u.contact_number USING utf8mb4)'))
                                             ->on(DB::raw('CONVERT(c.business_id USING utf8mb4)'), '=', DB::raw('CONVERT(u.business_id USING utf8mb4)'));
                                    })                                    
                                    ->whereBetween('credit_transactions.created_at', [$date . " 00:00:00", $date . " 23:59:59"])
                                    ->where('credit_transactions.transaction_type', 'credit')
                                    ->where('credit_transactions.location_id', $location_id)
                                    ->whereNotIn('credit_transactions.remark', ['Order Refund']);
                                    
        $transactions = $query->select(['credit_transactions.payment_type', 'credit_transactions.amount', 'credit_transactions.remark','credit_transactions.void_reason','credit_transactions.is_void', 'credit_transactions.credit_id', 'credit_transactions.created_at', 
                            'c.phone_number', 'u.username','u.first_name', 'u.last_name', 
                            DB::raw('IF(cp.promo_amount IS NULL, 0.00, cp.promo_amount) as promo_amount'),
                            DB::raw('IF(cp.promo_amount IS NULL, credit_transactions.amount, credit_transactions.amount - cp.promo_amount) as topup_amount')])
                            ->orderBy('credit_transactions.created_at', 'desc') // Order by date in ascending order
                            ->get();
        $transactions->transform(function ($transaction) {
            $transaction->is_void = (bool) $transaction->is_void;
            return $transaction;
        });

        $query_topup = CreditTransaction::select(DB::raw('DATE(credit_transactions.created_at) as date'), DB::raw('SUM(credit_transactions.amount) as total_amount'), DB::raw('SUM(cp.promo_amount) as total_promo_amount'))
                                ->leftjoin('credit_promos AS cp', 'credit_transactions.credit_promo_id', '=', 'cp.id')
                                ->where('credit_transactions.business_id', $business_id)
                                ->where('credit_transactions.is_void', '!=', 1)
                                ->whereBetween('credit_transactions.created_at', [$date . " 00:00:00", $date . " 23:59:59"])
                                ->where('credit_transactions.transaction_type', 'credit')
                                ->where('credit_transactions.location_id', $location_id)
                                ->whereNotIn('credit_transactions.remark', ['Order Refund'])
                                ->groupBy(DB::raw('DATE(credit_transactions.created_at)'))
                                ->orderBy('credit_transactions.created_at', 'desc') // Order by date in ascending order
                                ->orderBy('date', 'desc'); // Order by date in ascending order
 
        $credits_topup = $query_topup->first();

        if (!$transactions) {
            return response()->json(['errorMessage' => 'Credits Topup transactions not found.'], 200);
        }

        if(!empty($credits_topup)) {
            $total_amount = round($credits_topup->total_amount, 2);
            $total_promo_amount = round($credits_topup->total_promo_amount, 2);
            $total_topup_amount = round($total_amount - $total_promo_amount, 2);
            $credits_topup->total_topup_amount = number_format($total_topup_amount, 2, '.', '');

        }
        else{
            $credits_topup = (object) [
                'date' => $date,
                'total_amount' => '0.00',
                'total_promo_amount' => '0.00',
                'total_topup_amount' => '0.00',
            ];
        }
        
        $response = [
            "transactions" => $transactions,
            "credits_topup" => $credits_topup
        ];
        return response()->json($response, 200);
    }
}