<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class Auth0Controller extends Controller
{
    public function secured()
    {
        return response()->json(['message' => 'Successfully accessed secured resource']);
    }
}
