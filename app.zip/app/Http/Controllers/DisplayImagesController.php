<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Illuminate\Routing\Controller;
use App\DisplayImages;
use App\Utils\Util;
use Datatables;
use App\BusinessLocation;

class DisplayImagesController extends Controller
{
    /**
     * All Utils instance.
     *
     */
    protected $util;

    /**
     * Constructor
     *
     * @param Util $util
     * @return void
     */
    public function __construct(Util $util)
    {
        $this->util = $util;
    }

    /**
     * Display a listing of the resource.
     * @return Response
     */
    public function index()
    {
        if (!auth()->user()->can('access_tables')) {
            abort(403, 'Unauthorized action.');
        }

        $business_id = request()->session()->get('user.business_id');
        $business_locations = BusinessLocation::forDropdown($business_id);

        $image_types = config('constants.DISPLAY_IMAGE_TYPE');
        $status_values = config('constants.DISPLAY_IMAGE_STATUS');
        $orientation = config('constants.DISPLAY_IMAGE_ORIENTATION');

        if (request()->ajax()) {

            $displayImages = DisplayImages::where('display_images.business_id', $business_id)
                               ->join('business_locations AS BL', 'display_images.location_id', '=', 'BL.id')
                               ->select(['BL.name as location', 'display_images.image', 'display_images.id', 'BL.website', 'display_images.location_id'
                               , 'display_images.image_type', 'display_images.status', 'display_images.orientation']);

            return Datatables::of($displayImages)
                ->editColumn('image', function ($row) {
                    return '<div style="display: flex;"><img src="' . $row->image_url . '" alt="Display image" class="product-thumbnail-small"></div>';
                })
               ->addColumn(
                   'action',
                   '@role("Admin#' . $business_id . '")
                   <button data-href="{{action(\'DisplayImagesController@edit\', [$id])}}" class="btn btn-xs btn-primary edit_display_image_button"><i class="glyphicon glyphicon-edit"></i> @lang("messages.edit")</button>
                       &nbsp;
                   @endrole
                   @role("Admin#' . $business_id . '")
                       <button data-href="{{action(\'DisplayImagesController@destroy\', [$id])}}" class="btn btn-xs btn-danger delete_display_image_button"><i class="glyphicon glyphicon-trash"></i> @lang("messages.delete")</button>
                   @endrole'
               )
               ->removeColumn('id')
               ->removeColumn('location_id')
               ->escapeColumns(['location_id'])
               ->rawColumns(['action', 'image'])
               ->make(true);
        }

        return view('display_images.index')
            ->with(compact('business_locations', 'image_types', 'status_values', 'orientation'));
    }

    /**
     * Store a newly created resource in storage.
     * @param  Request $request
     * @return Response
     */
    public function store(Request $request) {
        if (!auth()->user()->can('product.create')) {
            abort(403, 'Unauthorized action.');
        }

        try {
            $display_images = [];
            $input = $request->only(['image', 'location_id', 'image_type', 'orientation']);

            $display_images['image'] = $this->util->uploadFileOnAWSS3($request, 'image', 'display_images', 'image');
            $display_images['created_by'] = $request->session()->get('user.id');
            $display_images['location_id'] = $input['location_id'];
            $display_images['orientation'] = $input['orientation'];
            $display_images['image_type'] = implode(',', $input['image_type']);
            $business_id = $request->session()->get('user.business_id');
            $display_images['business_id'] = $business_id;
            
            DisplayImages::create($display_images);

            $output = ['success' => 1,
                            'msg' => __('lang_v1.added_success')
                        ];
        } catch (\Exception $e) {
            \Log::emergency("File:" . $e->getFile(). "Line:" . $e->getLine(). "Message:" . $e->getMessage());
            
            $output = ['success' => 0,
                            'msg' => __("messages.something_went_wrong")
                        ];
        }

        return redirect('display-images');
    }

    /**
     * Remove the specified resource from storage.
     * @return Response
     */
    public function destroy($id)
    {
        if (!auth()->user()->can('access_tables')) {
            abort(403, 'Unauthorized action.');
        }

        if (request()->ajax()) {
            try {
                $business_id = request()->user()->business_id;
                $display_image = DisplayImages::findOrFail($id);
                $display_image->delete();

                $output = ['success' => true,
                            'msg' => __("lang_v1.deleted_success")
                            ];
            } catch (\Exception $e) {
                \Log::emergency("File:" . $e->getFile(). "Line:" . $e->getLine(). "Message:" . $e->getMessage());
            
                $output = ['success' => false,
                            'msg' => __("messages.something_went_wrong")
                        ];
            }

            return $output;
        }
    }

    /**
     * Show the form for editing the specified resource.
     * @return Response
     */
    public function edit($id)
    {
        if (!auth()->user()->can('access_tables')) {
            abort(403, 'Unauthorized action.');
        }

        if (request()->ajax()) {
            $business_id = request()->session()->get('user.business_id');
            $display_image = DisplayImages::where('business_id', $business_id)->find($id);
            $image_types = config('constants.DISPLAY_IMAGE_TYPE');
            $status_values = config('constants.DISPLAY_IMAGE_STATUS');
            $orientation = config('constants.DISPLAY_IMAGE_ORIENTATION');
            
            return view('display_images.edit')->with(compact('display_image', 'image_types', 'status_values', 'orientation'));
        }
    }

    /**
     * Update the specified resource in storage.
     * @param  Request $request
     * @return Response
     */
    public function update(Request $request, $id)
    {
        if (!auth()->user()->can('access_tables')) {
             abort(403, 'Unauthorized action.');
        }

        if (request()->ajax()) {
            try {
                $input = $request->only(['image_type', 'status', 'orientation']);
                $business_id = $request->session()->get('user.business_id');
                $display_image = DisplayImages::where('business_id', $business_id)->findOrFail($id);
                
                $display_image->image_type = implode(',', $input['image_type']);
                $display_image->status = $input['status'];
                $display_image->orientation = $input['orientation'];
                $display_image->updated_by = $request->session()->get('user.id');
                $display_image->save();

                $output = ['success' => true,
                            'msg' => __("lang_v1.updated_success")
                            ];
            } catch (\Exception $e) {
                \Log::emergency("File:" . $e->getFile(). "Line:" . $e->getLine(). "Message:" . $e->getMessage());
            
                $output = ['success' => false,
                            'msg' => __("messages.something_went_wrong")
                        ];
            }

            return $output;
        }
    }

}