<?php

namespace App\Http\Controllers;

use App\CustomerMembership;
use Illuminate\Http\Request;
use Datatables;
use Illuminate\Support\Facades\DB;
use App\Business;
use App\Utils\ContactUtil;
use App\Services\GetCustomerMembership;
use App\Transaction;
use App\BusinessLocation;
use Carbon\Carbon;


class CustomerMembershipController extends Controller
{
    protected $contactUtil;

    public function __construct(
       
        ContactUtil $contactUtil,
        GetCustomerMembership $GetCustomerMembership

    ) {
        $this->contactUtil = $contactUtil;
        $this->GetCustomerMembership = $GetCustomerMembership;

    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        if (!auth()->user()->can('access_tables')) {
            abort(403, 'Unauthorized action.');
        }

        $business_id = request()->session()->get('user.business_id');

        if (request()->ajax()) {
            
            $customer_memberships = CustomerMembership::where('customer_memberships.business_id', $business_id)
                                                        ->select([
                                                            'customer_memberships.membership_name',
                                                            'customer_memberships.id',
                                                            DB::raw('ROUND(customer_memberships.minimum_order_amount_to_earn_reward, 2) AS minimum_order_amount_to_earn_reward'),
                                                            DB::raw('ROUND(customer_memberships.minimum_orders_to_earn_reward, 2) AS minimum_orders_to_earn_reward'),
                                                            DB::raw('ROUND(customer_memberships.minimum_points_earn_per_order, 2) AS minimum_points_earn_per_order'),
                                                            DB::raw('ROUND(customer_memberships.maximum_points_per_order, 2) AS maximum_points_per_order'),
                                                            DB::raw('ROUND(customer_memberships.redeem_amount_per_unit_point, 2) AS redeem_amount_per_unit_point'),
                                                            DB::raw('ROUND(customer_memberships.minimum_order_total_to_redeem_points, 2) AS minimum_order_total_to_redeem_points'),
                                                            DB::raw('ROUND(customer_memberships.minimum_redeem_point, 2) AS minimum_redeem_point'),
                                                            DB::raw('ROUND(customer_memberships.maximum_redeem_point_per_order, 2) AS maximum_redeem_point_per_order'),
                                                            DB::raw('ROUND(customer_memberships.amount_for_unit_rp, 2) AS amount_for_unit_rp'),
                                                            DB::raw('ROUND(customer_memberships.minimum_order_total_to_earn_points, 2) AS minimum_order_total_to_earn_points'),
                                                            'customer_memberships.redemption_order_period',
                                                            'customer_memberships.redemption_order_period_type',
                                                            'customer_memberships.rp_expiry_period',
                                                            'customer_memberships.rp_expiry_type',
                                                            'customer_memberships.business_id',
                                                            'customer_memberships.created_at'
                                                        ]);

            
            return Datatables::of($customer_memberships)
            ->addColumn(
                'action',
                '@role("Admin#' . $business_id . '")
                <a href="{{action(\'CustomerMembershipController@edit\', [$id])}}" class="btn btn-xs btn-primary edit_membership_button"><i class="glyphicon glyphicon-edit"></i> @lang("messages.edit")</a>
                    &nbsp;
                @endrole
                @role("Admin#' . $business_id . '")
                <a href="{{action(\'CustomerMembershipController@show\', [$id])}}" class="btn btn-xs btn-primary view_membership_button"><i class="glyphicon glyphicon-eye-open"></i> @lang("messages.view")</a>
                    &nbsp;
                @endrole
                @role("Admin#' . $business_id . '")
                    <button data-href="{{action(\'CustomerMembershipController@destroy\', [$id])}}" class="btn btn-xs btn-danger delete_membership_button"><i class="glyphicon glyphicon-trash"></i> @lang("messages.delete")</button>
                @endrole'
            )
            ->rawColumns(['action', 'membership_name', 'minimum_order_amount_to_earn_reward', 'minimum_orders_to_earn_reward', 'minimum_points_earn_per_order', 'maximum_points_per_order', 'redeem_amount_per_unit_point', 'minimum_order_total_to_redeem_points', 'minimum_redeem_point', 'maximum_redeem_point_per_order'])
            ->make(true);
    }

    return view('customer_membership.index');
    }


    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    
    public function create()
    {
        if (!auth()->user()->can('business_settings.access')) {
            abort(403, 'Unauthorized action.');
        }

        $business_id = request()->session()->get('user.business_id');

        return view('customer_membership.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        if (!auth()->user()->can('business_settings.access')) {
            abort(403, 'Unauthorized action.');
        }
        $business_id = request()->session()->get('user.business_id');

        try {
            
            $existingMembership = CustomerMembership::where('business_id', $business_id)
            ->where('membership_name', $request->input('membership_name'))
            ->exists();

            if ($existingMembership) {
                return [
                    'success' => false,
                    'message' => __("Membership name already exists.")
                ];
            }
            
            $input = $request->only([
                'membership_name', 
                'minimum_order_amount_to_earn_reward', 
                'minimum_orders_to_earn_reward', 
                'minimum_points_earn_per_order',
                'maximum_points_per_order',
                'amount_for_unit_rp',
                'redeem_amount_per_unit_point',
                'minimum_order_total_to_redeem_points',
                'minimum_redeem_point',
                'maximum_redeem_point_per_order',
                'redemption_order_period',
                'redemption_order_period_type',
                'rp_expiry_period',
                'rp_expiry_type',
                'minimum_order_total_to_earn_points'
            ]);

            $business_id = $request->session()->get('user.business_id');
            $input['business_id'] = $business_id;
        
            CustomerMembership::create($input);
            $output = [
                'success' => true,
                'message' => __("Membership Added")
            ];
        } catch (\Exception $e) {
            \Log::emergency("File:" . $e->getFile(). "Line:" . $e->getLine(). "Message:" . $e->getMessage());
            
            $output = [
                'success' => false,
                'message' => __("messages.something_went_wrong")
            ];
        }

        //return $output;
        return redirect('membership')->with($output);
    }

    /**
     * Show the form for editing the specified resource.
     * @return Response
     */
    public function edit($id)
    {
        if (!auth()->user()->can('access_tables')) {
            abort(403, 'Unauthorized action.');
        }
  
            $business_id = request()->session()->get('user.business_id');
            $customer_memberships = CustomerMembership::where('business_id', $business_id)
                ->where('id', $id)
                ->firstOrFail();
            return view('customer_membership.edit')->with(compact('customer_memberships'));
    }

    public function show($id)
    {
        try {
            $customer_membership = CustomerMembership::findOrFail($id); 

            return view('customer_membership.view')->with(compact(
                'customer_membership'
            ));
        } catch (\Exception $e) {
            \Log::emergency("File:" . $e->getFile(). "Line:" . $e->getLine(). "Message:" . $e->getMessage());
        }
    }

    /**
     * Update the specified resource in storage.
     * @param  Request $request
     * @return Response
     */
    public function update(Request $request, $id)
    {
        if (!auth()->user()->can('access_tables')) {
            abort(403, 'Unauthorized action.');
        }

        try {
            $business_id = request()->session()->get('user.business_id');

            $existingMembership = CustomerMembership::where('business_id', $business_id)
            ->where('membership_name', $request->input('membership_name'))
            ->where('id', '!=', $id)
            ->exists();

            if ($existingMembership) {
                return [
                    'success' => false,
                    'message' => __("Membership name already exists.")
                ];
            }

            $input = $request->only([
                'membership_name', 
                'minimum_order_amount_to_earn_reward', 
                'minimum_orders_to_earn_reward', 
                'minimum_points_earn_per_order',
                'maximum_points_per_order',
                'amount_for_unit_rp',
                'redeem_amount_per_unit_point',
                'minimum_order_total_to_redeem_points',
                'minimum_redeem_point',
                'maximum_redeem_point_per_order',
                'redeemption_order_period',
                'redemption_order_period_type',
                'rp_expiry_period',
                'rp_expiry_type',
                'minimum_order_total_to_earn_points'
            ]);

            $business_id = $request->session()->get('user.business_id');

            $customer_membership = CustomerMembership::where('business_id', $business_id)
                ->findOrFail($id);

            $customer_membership->update($input);

            $output = [
                'success' => true,
                'message' => __("membership update successfully")
            ];

        } catch (\Exception $e) {
            \Log::emergency("File:" . $e->getFile(). "Line:" . $e->getLine(). "Message:" . $e->getMessage());

            $output = [
                'success' => false,
                'message' => __("messages.something_went_wrong")
            ];
        }

        return redirect('membership')->with($output);
    }
    

    /**
     * Remove the specified resource from storage.
     * @return Response
     */
    public function destroy($id)
    {
        if (!auth()->user()->can('access_tables')) {
            abort(403, 'Unauthorized action.');
        }

         if (request()->ajax()) {
            try {
                $business_id = request()->user()->business_id;
                $customer_memberships = CustomerMembership::where('business_id', $business_id)->findOrFail($id);
                $customer_memberships->delete();

                $output = ['success' => true,
                            'msg' => __("lang_v1.deleted_success")
                            ];
            } catch (\Exception $e) {
                \Log::emergency("File:" . $e->getFile(). "Line:" . $e->getLine(). "Message:" . $e->getMessage());
            
                $output = ['success' => false,
                            'msg' => __("messages.something_went_wrong")
                        ];
            }

            return $output;
         }
    }

    public function crmSettingsedit(Request $request, $id)
    {
        $business = Business::findOrFail($id);
        if ($request->ajax()) {
            return response()->json($business);
        }
        return view('customer_membership.crm_settings', compact('business'));
    }
    
    
    public function crmSettings(Request $request) {

        if (!auth()->user()->can('access_tables')) {
            abort(403, 'Unauthorized action.');
        }
        $business_id = request()->session()->get('user.business_id');
        $customerMemberships = CustomerMembership::where('business_id', $business_id)->get();

        if ($request->ajax()) {
            $data = Business::select(['id', 'rp_sales_calculation_period', 'rp_sales_calculation_period_type'])
                            ->where('id', $business_id);
            
            return DataTables::of($data)
                ->addColumn('action', function ($row) {
                    return '<button type="button" class="btn btn-primary edit-button" data-id="' . $row->id . '">Edit</button>';
                })
                ->make(true);
        }
        return view('customer_membership.crm_settings')->with(compact('customerMemberships'));
    }

    public function crmsettingsUpdate(Request $request, $id)
    {
        if (!auth()->user()->can('business_settings.access')) {
            abort(403, 'Unauthorized action.');
        }
        $business_id = request()->session()->get('user.business_id');
        
        try {
            $validated = $request->validate([
                'rp_sales_calculation_period' => 'nullable|integer',
                'rp_sales_calculation_period_type' => 'nullable|in:month,year',
                'rp_expiry_period' => 'nullable|integer',
                'rp_expiry_period_type' => 'nullable|in:month,year',
                'expiry_type' => 'nullable|in:static,dynamic',
            ]);
            $business = Business::findOrFail($business_id);
            $business->update([
                'rp_sales_calculation_period' => $validated['rp_sales_calculation_period'],
                'rp_sales_calculation_period_type' => $validated['rp_sales_calculation_period_type'],
                'rp_expiry_period' => $validated['rp_expiry_period'],
                'rp_expiry_type' => $validated['rp_expiry_period_type'],
                'points_expiry_type' => $validated['expiry_type'],
            ]);
            foreach ($request->input('memberships', []) as $membershipData) {
                if (!empty($membershipData['id'])) {
                    $membership = CustomerMembership::where('id', $membershipData['id'])
                        ->where('business_id', $business_id)
                        ->first();
            
                    if ($membership) {
                        $membership->update([
                            'membership_name' => $membershipData['membership_name'],
                            'minimum_order_amount_to_earn_reward' => $membershipData['minimum_order_amount_to_earn_reward'],
                            //'max_amount' => $membershipData['max_amount'], // Update max_amount too
                        ]);
                    }
                }
            }

            $output = [
                'success' => true,
                'message' => __("CRM Settings added successfully")
            ];

        } catch (\Exception $e) {
            \Log::emergency("File:" . $e->getFile(). "Line:" . $e->getLine(). "Message:" . $e->getMessage());

            $output = [
                'success' => false,
                'message' => __("messages.something_went_wrong")
            ];
        }
        return redirect('crm-settings')->with($output);
        // return redirect()->route('customer_membership.crm_settings')->with('success', 'CRM Settings created successfully.');
    }
    
    public function getRemaningOrnearestExpriyPoint($business_id, $contact_id)
    {
        $businessDetails  = Business::where('id', $business_id)
            ->select('points_expiry_type', 'rp_expiry_period', 'rp_expiry_type')
            ->first();
    
        $transactions = Transaction::where('contact_id', $contact_id)
            ->where("business_id", $business_id)
            ->where('rp_earned', '!=', 0);
    
        $remainingPoints = $transactions->orderBy('created_at', 'DESC')
            ->first("rp_earned");
    
        $nearestExpirePoint = $transactions->get()->map(function ($transaction) use ($businessDetails) {
            $rp_expiry_period = $businessDetails->rp_expiry_period;
            $rp_expiry_type = $businessDetails->rp_expiry_type;

            $created_at = Carbon::parse($transaction->created_at);
            $expiry_date = null;
    
            if ($rp_expiry_type === 'month') {
                $expiry_date = $created_at->addMonths($rp_expiry_period)->toDateString();
            } elseif ($rp_expiry_type === 'year') {
                $expiry_date = $created_at->addYears($rp_expiry_period)->toDateString();
            }
            return [
            'expiry_date' => $expiry_date,
            "points" => number_format($transaction->rp_earned, 2)
            ];
        })
        ->filter(function ($item) {
            return Carbon::parse($item['expiry_date'])->greaterThanOrEqualTo(Carbon::now());
        })
        ->sortBy('expiry_date') 
        ->take(3) 
        ->values(); 
        
        return [
            'remainingPoints' => $remainingPoints,
            'nearestExpirePoint' => $nearestExpirePoint
        ];
    }
    

    public function pointsTransactions(Request $request)
    {
        if (!auth()->user()->can('customer.view') && !auth()->user()->can('customer.view_own')) {
            abort(403, 'Unauthorized action.');
        }
    
        $business_id = request()->session()->get('user.business_id');
        if ($request->ajax()) {        
            $location_id = $request->location_id;
            $start_date = $request->start_date ?? now()->startOfMonth()->toDateString();
            $end_date = $request->end_date ?? now()->endOfMonth()->toDateString();
            $customers = $this->contactUtil->getCRMContactQuery($business_id, 'customer', $location_id, $start_date, $end_date)->get();
            $customerDetails = [];
            foreach ($customers as $contact) {
                $customer_details = $this->GetCustomerMembership->getCustomerMembership($contact->id, $business_id);
                $customerDetails[] = [
                    "id" => $contact->id,
                    "first_name" => $contact->first_name,
                    "last_name" => $contact->last_name,
                    "full_name" => $contact->first_name . ' ' . $contact->last_name, 
                    "total_rp" => $contact->total_rp,
                    "mobile" => $contact->mobile,
                    "tier" => $customer_details["membership_name"]
                ];
            }
            return DataTables::of($customerDetails)
            ->addColumn('action', function ($row) {
                return '<a href="recent-points-transactions/'.$row["id"].'" class="btn btn-sm btn-primary">History</a>';
            })
            ->rawColumns(['action'])
            ->make(true);
        }
        $business_locations = BusinessLocation::forDropdown($business_id, false);
        return view('customer_membership.points_transactions', compact('customerDetails', "business_locations"));
    }

    public function recentPointsTransactions(Request $request, $contact_id)
    {
        if (!auth()->user()->can('customer.view') && !auth()->user()->can('customer.view_own')) {
            abort(403, 'Unauthorized action.');
        }    
        $business_id = request()->session()->get('user.business_id');
        $businessDetails  = Business::where('id', $business_id)
        ->select('points_expiry_type')
        ->first(); 
        $points = $this->getRemaningOrnearestExpriyPoint($business_id, $contact_id);
        if ($request->ajax()) {
            $transaction_type = $request->transaction_type;
            $transactions = Transaction::with('contact')
                ->where('contact_id', $contact_id)
                ->where("business_id", $business_id)
                ->orderBy('created_at', 'desc')
                ->get()
                ->flatMap(function ($transaction) use ($transaction_type, $business_id) {
                    $rows = [];
                    $customer_details = $this->GetCustomerMembership->getCustomerMembership($transaction->contact_id, $business_id);
                    $rp_expiry_period = $customer_details->rp_expiry_period;
                    $rp_expiry_type = $customer_details->rp_expiry_type;
                    if ($transaction->rp_earned != 0 && (!$transaction_type || $transaction_type === 'Earned')) {
                    $created_at = Carbon::parse($transaction->created_at);
                        // Calculate expiry date based on type
                        if ($rp_expiry_type === 'month') {
                            $expiry_date = $created_at->addMonths($rp_expiry_period)->toDateString();
                        } elseif ($rp_expiry_type === 'year') {
                            $expiry_date = $created_at->addYears($rp_expiry_period)->toDateString();
                        } 
                    $rows[] = [
                        'invoice_no' => $transaction->invoice_no,
                        "tier" => $customer_details->membership_name,
                        //'full_name' => $transaction->contact->first_name . ' ' . $transaction->contact->last_name,
                        'type' => 'Earned',
                        'final_total' => $transaction->final_total,
                        'points' => $transaction->rp_earned,
                        'date' => $transaction->created_at->format('Y-m-d H:i:s'),
                        "expiry_date" => $expiry_date
                    ];
                    }
                    if ($transaction->rp_redeemed != 0 && (!$transaction_type || $transaction_type === 'Redeemed')) {
                        $rows[] = [
                            'invoice_no' => $transaction->invoice_no,
                            "tier" => $customer_details->membership_name,
                           // 'full_name' => $transaction->contact->first_name . ' ' . $transaction->contact->last_name,
                            'type' => 'Redeemed',
                            'final_total' => $transaction->final_total,
                            'points' => $transaction->rp_redeemed,
                            'date' => $transaction->created_at->format('Y-m-d H:i:s'),
                            "expiry_date" => "-"
                        ];
                    }
    
                    return $rows;
                });
            return DataTables::of($transactions)
                ->rawColumns(['action'])
                ->make(true);
        }    
        return view('customer_membership.points_history', compact("points",'contact_id'));
    }

    public function recentAllTransactions(Request $request)
    {
        if (!auth()->user()->can('customer.view') && !auth()->user()->can('customer.view_own')) {
            abort(403, 'Unauthorized action.');
        }    
        $business_id = request()->session()->get('user.business_id');
        $business_locations = BusinessLocation::forDropdown($business_id, false);
    
        if ($request->ajax()) {
            $transaction_type = $request->transaction_type;
            $transactions = Transaction::with('contact')
                ->where("business_id", $business_id)
                ->when($request->location_id, function ($query, $location_id) {
                    return $query->where('location_id', $location_id);
                })
                ->when($request->start_date && $request->end_date, function ($query) use ($request) {
                    return $query->whereBetween('created_at', [$request->start_date, $request->end_date]);
                })
                ->orderBy('created_at', 'desc')
                ->get()
                ->flatMap(function ($transaction) use ($transaction_type) {
                    $rows = [];
                    if ($transaction->rp_earned != 0 && (!$transaction_type || $transaction_type === 'Earned')) {
                    $rows[] = [
                        'invoice_no' => $transaction->invoice_no,
                        'mobile' => $transaction->contact->mobile,
                        'full_name' => $transaction->contact->first_name . ' ' . $transaction->contact->last_name,
                        'type' => 'Earned',
                        'final_total' => $transaction->final_total,
                        'points' => $transaction->rp_earned,
                        'date' => $transaction->created_at->format('Y-m-d H:i:s'),
                    ];
                    }
                    if ($transaction->rp_redeemed != 0 && (!$transaction_type || $transaction_type === 'Redeemed')) {
                        $rows[] = [
                            'invoice_no' => $transaction->invoice_no,
                            'mobile' => $transaction->contact->mobile,
                            'full_name' => $transaction->contact->first_name . ' ' . $transaction->contact->last_name,
                            'type' => 'Redeemed',
                            'final_total' => $transaction->final_total,
                            'points' => $transaction->rp_redeemed,
                            'date' => $transaction->created_at->format('Y-m-d H:i:s'),
                        ];
                    }
    
                    return $rows;
                });
            return DataTables::of($transactions)->make(true);
        }
    
        return view('customer_membership.transation_history', compact("business_locations"));
    }
    

}
