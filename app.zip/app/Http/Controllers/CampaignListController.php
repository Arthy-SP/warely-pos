<?php

namespace App\Http\Controllers;
use App;
use PDF;
use SimpleSoftwareIO\QrCode\Facades\QrCode;
use App\Campaign;
use App\Couponsystem;
use App\CouponLayout;
use App\BusinessLocation;
use App\CampaignList;
use App\Utils\Util;
use Illuminate\Http\Request;
use Datatables;
use Carbon;
class CampaignListController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        if (!auth()->user()->can('couponsystem.access')) {
            abort(403, 'Unauthorized action.');
        }
        if (request()->ajax()) {
            $coupon_id = request()->input('coupon_id');
            $campaign_id = request()->input('id');
            $status = request()->input('status');
            $start_date = request()->input('start_d');
            $end_date = request()->input('end');
            
            $business_id = request()->session()->get('user.business_id');
            $CampaignList = CampaignList::where('business_id', $business_id);
            
            if($coupon_id > 0) {
                $CampaignList->where('coupon_id', $coupon_id);
            }
            if($campaign_id > 0) {
                $CampaignList->where('campaign_id', $campaign_id);
            }
            $date = Carbon::now()->format('Y-m-d H:i:s');
            if($status != ""){
                if($status == 3){
                    $CampaignList->where('status', '<=' ,$status)->where('expiry_date', '<=', $date);
                }else{
                    $CampaignList->where('status', $status);
                }
            }
            if($start_date > 0 && $end_date >0){
                if($status == 1){
                    $CampaignList->whereBetween('issue_date', [$start_date, $end_date]);
                }elseif($status == 2){
                    $CampaignList->whereBetween('redeem_date', [$start_date, $end_date]);
                }elseif($status == 3){
                    $CampaignList->whereBetween('expiry_date', [$start_date, $end_date]);
                }else{
                    // dd($CampaignList->get());
                    // $CampaignList->whereBetween('created_at', [$start_date, $end_date]);
                    // dd($CampaignList->get());
                }
            }
            
            $CampaignList = $CampaignList->select(['id','qr_sn','issue_date','expiry_date','redeem_date','status','business_id','layout_id','coupon_id','campaign_id']);
            // dd($CampaignList);
            return Datatables::of($CampaignList)
                ->addColumn(
                    'action',
                        '<button type="button" data-href="{{action(\'CampaignListController@destroy\', [$id])}}" class="btn btn-xs btn-danger delete_barcode_button" ><i class="glyphicon glyphicon-trash"></i> @lang("messages.delete")</button>&nbsp;
                        <a href="{{action(\'CampaignListController@show\', [$id])}}" class="btn btn-xs btn-success"><i class="glyphicon glyphicon-eye-open"></i> View</a>
                        '
                )
                ->editColumn('qr_sn', function ($row) {
                    return 'QR-'.$row->business_id.$row->layout_id.$row->coupon_id.$row->campaign_id.$row->id;
                })
                ->editColumn('status', function ($row) {
                    $arrayStatus = array("0"=>"AVAILABLE",'1'=>'ISSUED','2'=>'REDEEM','3'=>'EXPIRED');
                    $dropdown = '<select class="StatusSelect">';
                    foreach($arrayStatus as $key=>$value) {
                        if($key == $row['status']){
                            $selected = 'selected';
                        } else {
                            $selected = '';
                        }
                        $dropdown .= '<option data-id="'.$row->id.'" '.$selected.' value="'.$key.'">'.$value.'</option>';
                    }
                    return $dropdown;
                })
                ->removeColumn('business_id')
                ->removeColumn('layout_id')
                ->removeColumn('coupon_id')
                ->removeColumn('campaign_id')
                ->rawColumns([6,5])
                ->make(false);
        }
        $campaign_id = $_REQUEST['id'];
        $coupon_id = $_REQUEST['coupon_id'];
        $campaign = campaign::find($campaign_id);
        return view('campaign_list.index')->with(compact('campaign_id','campaign','coupon_id'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }
    public function updatestatus(Request $request) {
        if (request()->ajax()) {
            try {
                
                $input = $request->only(['cid', 'val']);
                $CampaignList = CampaignList::find($input['cid']);
                $Couponsystem = Couponsystem::find($CampaignList->coupon_id);
                $data['status'] = $input['val'];
                if($input['val'] == 1)
                {
                    $data['issue_date'] = date('Y-m-d H:i:s');
                    $data['expiry_date'] = date('Y-m-d H:i:s',strtotime('+'.$Couponsystem->expiry_day.' days'));
                } elseif($input['val'] == 2) {
                    $data['redeem_date'] = date('Y-m-d H:i:s');
                }elseif($input['val'] == 0) {
                    $data['issue_date'] = '000-00-00 00:00:00';
                    $data['expiry_date'] = '000-00-00 00:00:00';
                    $data['redeem_date'] = '000-00-00 00:00:00';
                }else{
                    $data['expiry_date'] = date('Y-m-d H:i:s');
                }
                $data['qr_sn'] = 'QR-'.$CampaignList->business_id.$CampaignList->layout_id.$CampaignList->coupon_id.$CampaignList->campaign_id.$CampaignList->id;
                CampaignList::where('id', $input['cid'])->update($data);
                $output = ['success' => 1,
                'msg' => 'successfully updated'];
             } catch (\Exception $e) {
                \Log::emergency("File:" . $e->getFile(). "Line:" . $e->getLine(). "Message:" . $e->getMessage());
            
                    $output = ['success' => 0,
                           'msg' => __("messages.something_went_wrong")
                       ];
            } 

            return $output;
        }
    }
    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\CampaignList  $campaignList
     * @return \Illuminate\Http\Response
     */
    public function show(CampaignList $campaignList)
    {
        $campaign = campaign::find($campaignList->campaign_id);
        $Couponsystem = Couponsystem::find($campaign->coupon_id);
        $findTxt = array('{coupon_name}','{coupon_qty}','{coupon_value}','{min_purchase}','{min_pax}','{expiry_date}','{QR_SN}');
        $replaceTxt = array($Couponsystem->coupon_name,$campaign->coupon_qty,$Couponsystem->coupon_value,$Couponsystem->min_purchase,$Couponsystem->min_pax,$campaignList->expiry_date,$campaignList->qr_sn);
        $CouponsystemLayoutFront = str_replace($findTxt,$replaceTxt,$Couponsystem->front_image);
        $CouponsystemLayoutBack =  str_replace($findTxt,$replaceTxt,$Couponsystem->back_image);
        $jsonQr = json_encode(array('CampaignListId'=>$campaignList->id,"coupon_name"=>$Couponsystem->coupon_name,"coupon_id"=>$campaign->coupon_id,"campaign_id"=>$campaign->id,'coupon_value'=>$Couponsystem->coupon_value,'min_purchase'=>$Couponsystem->min_purchase,'expiry_date'=>$campaignList->expiry_date,'min_pax'=>$Couponsystem->min_pax));
        return view('campaign_list.view')
        ->with(compact('campaign','Couponsystem','CouponsystemLayoutFront','CouponsystemLayoutBack','jsonQr'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\CampaignList  $campaignList
     * @return \Illuminate\Http\Response
     */
    public function edit(CampaignList $campaignList)
    {
        if (!auth()->user()->can('couponsystem.access')) {
            abort(403, 'Unauthorized action.');
        }

        $business_id = request()->session()->get('user.business_id');
        $campaign = campaign::find($campaignList->campaign_id);
        $coupon_id = Couponsystem::where('business_id', $business_id)
                            ->pluck('coupon_name', 'id');
        return view('campaign_list.edit')
            ->with(compact('campaignList','coupon_id','campaign'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\CampaignList  $campaignList
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, CampaignList $campaignList)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\CampaignList  $campaignList
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        
        if (request()->ajax()) {
            try {
                $barcode = CampaignList::find($id);
                    $barcode->delete();
                    $output = ['success' => true,
                                'msg' => 'successfully deleted'
                                ];
             } catch (\Exception $e) {
                \Log::emergency("File:" . $e->getFile(). "Line:" . $e->getLine(). "Message:" . $e->getMessage());
            
                $output = ['success' => false,
                            'msg' => __("messages.something_went_wrong")
                        ];
            } 

            return $output;
        }
    }

    public function urlImage($id){
        $campaignList = CampaignList::find($id);
        $campaign = Campaign::find($campaignList->campaign_id);
        $Couponsystem = Couponsystem::find($campaign->coupon_id);
        $string = explode('"backQrCode" src="', $Couponsystem->back_image);
        $oldqr = explode('" alt=', $string[1])[0];
        $jsonQr = json_encode(array("coupon_id"=>$campaign->coupon_id,'coupon_value'=>$Couponsystem->coupon_value,'min_purchase'=>$Couponsystem->min_purchase,'expiry_date'=>$campaignList->expiry_date,'min_pax'=>$Couponsystem->min_pax));
        $qr = 'data:image/png;base64, '.base64_encode(QrCode::format('png')->size(250)->generate($jsonQr));
        $findTxt = array('{coupon_name}','{coupon_qty}','{coupon_value}','{min_purchase}','{min_pax}','{expiry_date}','{qr_sn}','frontqrcodeimage',$oldqr);
        $replaceTxt = array($Couponsystem->coupon_name,$campaign->coupon_qty,$Couponsystem->coupon_value,$Couponsystem->min_purchase,$Couponsystem->min_pax,$campaignList->expiry_date,$campaignList->qr_sn, $qr,$qr);
        $CouponsystemLayoutFront = str_replace($findTxt,$replaceTxt,$Couponsystem->front_image);
        $CouponsystemLayoutBack =  str_replace($findTxt,$replaceTxt,$Couponsystem->back_image);
        
        $snappy = App::make('snappy.pdf');
        $pdf = PDF::loadView('campaign.coupon_view', array("CouponsystemLayoutFront"=>$CouponsystemLayoutFront,"CouponsystemLayoutBack"=>$CouponsystemLayoutBack, "qr" => $qr));
        $pdf->save(public_path('coupons/'.$campaign->coupon_id.'.pdf'));
        $file_path = public_path('coupons/'.$campaign->coupon_id.'.pdf');
        return $file_path;

    }
}
