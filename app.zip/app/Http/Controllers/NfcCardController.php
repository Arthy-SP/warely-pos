<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\User;
use App\NfcCard;
use App\NfcTransaction;
use App\BusinessLocation;
use App\NfcCardNumbers;
use Carbon\Carbon;
use App\TaxRate;
use Datatables;
use Illuminate\Support\Facades\DB;
use App\Utils\TransactionUtil;
use App\NfcPromos;
use App\Product;
use App\Unit;
use App\Category;
use App\ProductVariation;
use App\TransactionSellLine;
use App\Variation;
use App\VariationGroupPrice;
use App\VariationLocationDetails;
use App\Utils\ProductUtil;
use App\PosResTables;
use App\Restaurant\ResTable;
use App\Queue\QueueTable;
use GuzzleHttp\Client;
use App\TableQrToken;
use Stripe;
use Config;
use App\Utils\BusinessUtil;
use App\Utils\CashRegisterUtil;



use App\Services\TwilioOTPService;

class NfcCardController extends Controller
{
    protected $transactionUtil;
    protected $twilioOtpService;
    protected $productUtil;
    protected $businessUtil;
    protected $cashRegisterUtil;
    

    public function __construct(
        TransactionUtil $transactionUtil,
        TwilioOTPService $twilioOtpService,
        ProductUtil $productUtil,
        BusinessUtil $businessUtil,
        CashRegisterUtil $cashRegisterUtil

    ) {
        $this->transactionUtil = $transactionUtil;
        $this->twilioOtpService = $twilioOtpService;
        $this->productUtil = $productUtil;
        $this->businessUtil = $businessUtil;
        $this->cashRegisterUtil = $cashRegisterUtil;

    }

    public function index()
    {
        if (!auth()->user()->can('access_tables')) {
            abort(403, 'Unauthorized action.');
        }

        $business_id = request()->session()->get('user.business_id');
        $nfcCardNumbers = NfcCardNumbers::where('nfc_card_numbers.business_id', $business_id)->get();

        if (request()->ajax()) {
            
            $nfc_card_numbers = NfcCardNumbers::where('nfc_card_numbers.business_id', $business_id)
                                    ->select(['nfc_card_numbers.display_number', 'nfc_card_numbers.id', 'nfc_card_numbers.prefix', 'nfc_card_numbers.start_from']);
            
            return Datatables::of($nfc_card_numbers)
               ->addColumn(
                   'action',
                   '@role("Admin#' . $business_id . '")
                   <button data-href="{{action(\'NfcCardController@edit\', [$id])}}" class="btn btn-xs btn-primary edit_nfc_card_button"><i class="glyphicon glyphicon-edit"></i> @lang("messages.edit")</button>
                       &nbsp;
                   @endrole'
               )
               ->removeColumn('id')
               ->make(true);
       }

       return view('nfc_card_numbers.index')->with(compact('nfcCardNumbers'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        if (!auth()->user()->can('invoice_settings.access')) {
            abort(403, 'Unauthorized action.');
        }

        $business_id = request()->session()->get('user.business_id');
        $business_locations = BusinessLocation::forDropdown($business_id);

        return view('nfc_card_numbers.create')
            ->with(compact('business_locations'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        if (!auth()->user()->can('invoice_settings.access')) {
            abort(403, 'Unauthorized action.');
        }

        try {
            $input = $request->only(['display_number', 'prefix', 'start_from']);
            
            $business_id = $request->session()->get('user.business_id');
            $input['business_id'] = $business_id;

            $nfcCard = NfcCardNumbers::where('business_id', $business_id)
                                        ->whereNull('deleted_at')
                                        ->get();
            

            if( $nfcCard->isEmpty() ) {
                NfcCardNumbers::create($input);
                $output = ['success' => true,
                                'message' => __("invoice.added_success")
                            ];
            } else {
                $output = ['success' => false,
                            'message' => "Check number for selected business location is already created. You can edit the setting"
                        ];
            }
        } catch (\Exception $e) {
            \Log::emergency("File:" . $e->getFile(). "Line:" . $e->getLine(). "Message:" . $e->getMessage());
            
            $output = ['success' => false,
                            'message' => __("messages.something_went_wrong")
                        ];
        }

        return $output;
    }

    /**
     * Show the form for editing the specified resource.
     * @return Response
     */
    public function edit($id)
    {
        if (!auth()->user()->can('access_tables')) {
            abort(403, 'Unauthorized action.');
        }

        if (request()->ajax()) {
            $business_id = request()->session()->get('user.business_id');
            $nfcCard = NfcCardNumbers::where('business_id', $business_id)->find($id);
            
            return view('nfc_card_numbers.edit')->with(compact('nfcCard'));
        }
    }

    /**
     * Update the specified resource in storage.
     * @param  Request $request
     * @return Response
     */
    public function update(Request $request, $id)
    {
        if (!auth()->user()->can('access_tables')) {
             abort(403, 'Unauthorized action.');
        }

        if (request()->ajax()) {
            try {
                $input = $request->only(['prefix']);
                $business_id = $request->session()->get('user.business_id');
                $checkNumber = NfcCardNumbers::where('business_id', $business_id)->findOrFail($id);
                $checkNumber->prefix = $input['prefix'];
                $checkNumber->save();
                $output = ['success' => true,
                            'message' => __("lang_v1.updated_success")
                            ];
            } catch (\Exception $e) {
                \Log::emergency("File:" . $e->getFile(). "Line:" . $e->getLine(). "Message:" . $e->getMessage());
            
                $output = ['success' => false,
                            'message' => __("messages.something_went_wrong")
                        ];
            }

            return $output;
        }
    }

    public function list()
    {
        if (!auth()->user()->can('access_tables')) {
            abort(403, 'Unauthorized action.');
        }

        if (request()->ajax()) {
            $business_id = request()->session()->get('user.business_id');
            
            $nfcCardNumbers = NfcCard::where('nfc_cards.business_id', $business_id)
                                    ->select(['nfc_cards.card_no', 'nfc_cards.balance', 'nfc_cards.remark', 'nfc_cards.nfc_meta_data', 
                                    'nfc_cards.sr_no', 'nfc_cards.status', 'nfc_cards.id', 'nfc_cards.name', 'nfc_cards.phone', 'nfc_cards.ic_number',
                                    DB::raw("CASE nfc_cards.is_verified WHEN '0' THEN 'No' ELSE 'Yes' END AS is_verified")]);
            
                return Datatables::of($nfcCardNumbers)
                ->addColumn(
                    'balance',
                    '<div style="white-space: nowrap;">@format_currency($balance)</div>'
                )
                ->addColumn('status', function ($nfcCardNumbers) use ($business_id) {
                    return ucfirst($nfcCardNumbers->status);
                })
                ->addColumn('action', function ($nfcCardNumbers) use ($business_id) {
                    $activateButton = '<button data-href="' . action('NfcCardController@activateCard', [$nfcCardNumbers->id]) . '" class="btn btn-xs btn-success activate_nfc_card_button"><i class="glyphicon glyphicon-ok"></i> Activate</button>  <br>';
                    $deactivateButton = '<button data-href="' . action('NfcCardController@deactivateCard', [$nfcCardNumbers->id]) . '" class="btn btn-xs btn-danger deactivate_nfc_card_button"><i class="glyphicon glyphicon-remove"></i> Deactivate</button> <br>';
                    
                    // Show the appropriate button based on the status
                    $buttonToShow = ($nfcCardNumbers->status == 'active') ? $deactivateButton : $activateButton;
                    
                    // Return the buttons along with the Transactions button
                    $transactionsButton = '';
                    $editForm = '';
                    if (auth()->user()->can("Admin#" . $business_id)) {
                        $transactionsButton = '<a href="' . action('NfcCardController@card_transactions', [$nfcCardNumbers->card_no]) . '" class="btn btn-xs btn-primary " style= " width: 100px; height: 20px; margin-right: 5px"><i class="fa fas fa-list-alt"></i> Transactions</a> <br>';
                        $editForm =  '<button data-href="' . action('NfcCardController@editNfcCardDetails', [$nfcCardNumbers->id]) . '"class="btn btn-xs btn-primary nfc_card_edit_details_form "  data-container=".check_numbers_modal"><i class="glyphicon glyphicon-edit" style="margin-right: 0px;"></i> Edit</button>';
                    }
    
                    return $transactionsButton . $buttonToShow . $editForm;
                })
                ->rawColumns(['action', 'card_no', 'status', 'balance', 'remark', 'nfc_meta_data', 'is_verified', 'sr_no', 'id', 'name', 'phone', 'ic_number'])
                ->removeColumn('id')
                ->make(true);
        }
        return view('nfc_card_numbers.list');
    }

    public function card_transactions(Request $request, $card_no)
    {
        if (!auth()->user()->can('access_tables')) {
            abort(403, 'Unauthorized action.');
        }
        $business_id = request()->session()->get('user.business_id');
        $nfcCard = NfcCard::where('nfc_cards.business_id', $business_id)
                        ->where('nfc_cards.card_no', $card_no)
                        ->select(['nfc_cards.card_no', 'nfc_cards.status', 'nfc_cards.balance', 'nfc_cards.remark', 'nfc_cards.nfc_meta_data', 
                        'nfc_cards.is_verified', 'nfc_cards.sr_no', 'nfc_cards.id', DB::raw("CASE nfc_cards.is_verified WHEN '0' THEN 'No' ELSE 'Yes' END AS is_verified_value")])
                        ->first();
        if( $nfcCard ) {
            if (request()->ajax()) {
                $nfcCardTransactions = NfcTransaction::where('nfc_transactions.business_id', $business_id)
                                    ->where('nfc_transactions.nfc_card_id', $nfcCard->id)
                                    ->select([DB::raw("CASE nfc_transactions.transaction_type WHEN 'debit' THEN 'Debit' ELSE 'Credit' END AS transaction_type"), 'nfc_transactions.payment_method', 'nfc_transactions.amount', 'nfc_transactions.remark', 'nfc_transactions.nfc_card_id', 'nfc_transactions.created_at', 'nfc_transactions.id', 'nfc_transactions.is_void','nfc_transactions.void_reason'])
                                    ->orderBy("id", 'desc');   

                $start_date = $request->input('start_date');
                $end_date = $request->input('end_date');
    
                if (!empty($start_date) && !empty($end_date)) {
                    $start_date = date('Y-m-d 00:00:00', strtotime($start_date));
                    $end_date = date('Y-m-d 23:59:59', strtotime($end_date));

                    $nfcCardTransactions->whereBetween('nfc_transactions.created_at', [$start_date, $end_date]);
                }

                $transaction_type = request()->get('transaction_type', null);
                if (!empty($transaction_type)) {
                    $nfcCardTransactions->where('nfc_transactions.transaction_type', $transaction_type);
                }
                    return Datatables::of($nfcCardTransactions, $business_id)
                ->addColumn('action', function ($nfcCardTransactions){
                    $voidButton='';
                    if (str_contains(strtolower($nfcCardTransactions->remark), "top-up done") && $nfcCardTransactions->is_void != 1) {
                        $voidButton = '<button data-href="' . action('NfcCardController@getReason', [$nfcCardTransactions->id]) . '" class="btn btn-xs btn-danger btn-modal" data-container=".check_numbers_modal" style="color: white; width: 50px; height: 20px;"><i class="glyphicon glyphicon"></i>Void</button>';
                    }
                     else if(str_contains(strtolower($nfcCardTransactions->remark), "top-up done") && $nfcCardTransactions->is_void == 1) {
                        $voidButton = '<button data-href="" class="btn btn-xs" disabled style="color: black; background-color: gray;"><i class="glyphicon glyphicon"></i>Voided</button>';
                    }
                    else{   
                        $voidButton = '';
                    }
                    
                    return $voidButton;
                })
                ->addColumn(
                    'amount',
                    '<div style="white-space: nowrap;">@format_currency($amount)</div>'
                ) 
                ->removeColumn('id')
                ->rawColumns(['action', 'transaction_type', 'payment_method', 'amount', 'remark', 'nfc_card_id','void_reason', 'created_at'])
                ->make(true);
            }
            return view('nfc_card_numbers.transactions')->with(compact('nfcCard'));
        } else {
            return redirect()->route('nfc/list');
        }
    }

    public function deleteCard($id)
    {
        if (!auth()->user()->can('invoice_settings.access')) {
            abort(403, 'Unauthorized action.');
        }

        if (request()->ajax()) {
            try {
                $nfcCard = NfcCard::find($id);
                $nfcCard->delete();
                $output = [
                    'success' => true,
                    'message' => __("invoice.deleted_success")
                ];
            } catch (\Exception $e) {
                \Log::emergency("File:" . $e->getFile(). "Line:" . $e->getLine(). "Message:" . $e->getMessage());
            
                $output = ['success' => false,
                            'message' => __("messages.something_went_wrong")
                        ];
            }

            return $output;
        }
    }

    public function getNfcCardDetails(Request $request)
    {
        $request->validate([
            'token' => 'required|string',
            'user_id' => 'required|string',
            'card_no' => 'required|string',
            'sr_no' => 'required|string',
            'business_id' => 'required|string'
        ]);

        $user_id = $request->input('user_id');
        $user_token = $request->input('token');
        $card_no = $request->input('card_no');
        $sr_no = $request->input('sr_no');
        $business_id = $request->input('business_id');

        if (!User::checkUserToken($user_token, $user_id)) {
            return response()->json(['errorMessage' => 'Invalid token.'], 200);
        }

        $nfcCard = NfcCard::where('card_no', $card_no)
                           ->where('sr_no', $sr_no)
                           ->where('business_id', $business_id)
                           ->where('is_verified','=',1)
                           ->first();

        if (!$nfcCard) {
            // Old card detail after transfer with new one
            $oldNfcCard = NfcCard::where('card_no', $card_no)
                           ->where('business_id', $business_id)
                           ->first();
            if($oldNfcCard){
                $oldNfcCard->remark = "This card is no longer available";
                $oldNfcCard->is_verified = false;
                $oldNfcCard->status = "blocked";
                return response()->json($oldNfcCard, 200);
            }
            else{
                return response()->json(['errorMessage' => 'Card not found.'], 200);
            }
        }
        if( $nfcCard ) {
            $nfcCard->is_verified = $nfcCard->is_verified ? true : false;
        }
        return response()->json($nfcCard, 200);
    }

    public function registerNfcCard(Request $request)
    {
        try {
            $request->validate([
                'balance' => 'required|numeric',
                'business_id' => 'required|exists:business,id',
                'nfc_meta_data' => 'nullable|json',
                'token' => 'required|string',
                'user_id' => 'required|exists:users,id',
                'remark' => 'nullable|string',
                'sr_no'  => 'required|string',
                'additional_card_no' => 'nullable|string',
                'location_id' => 'nullable|string'
            ]);

            // Token check
            if (!User::checkUserToken($request->input('token'), $request->input('user_id'))) {
                return response()->json(['errorMessage' => 'Invalid token.'], 200);
            }

            // Check if the provided sr_no already exists in the database
            $existingCard = NfcCard::where('sr_no', $request->input('sr_no'))
                                    ->where('business_id', $request->input('business_id'))
                                    ->first();
            // && $existingCard['sr_no'] != '0472C6FAB10F90'
            if ($existingCard) {
                $existingCard->is_verified = $existingCard->is_verified ? true : false;
                return response()->json([
                    'message' => 'Card with the provided serial number already exists.',
                    "data" => $existingCard
                ], 200);
            }

            // Generate card_no
            $card_no = $this->transactionUtil->getNfcNumber($request->input('business_id'), $request->input('location_id'));
            if( $card_no ) {
                $existingCardNumber = NfcCard::where('card_no', $card_no)
                                            ->where('business_id', $request->input('business_id'))
                                            ->first();
                if ($existingCardNumber) {
                    return response()->json(['errorMessage' => 'Card already registered'], 200);
                }
            } else {
                return response()->json(['errorMessage' => 'NFC configuration missing. Please contact administrator'], 200);
            }

            if (!empty($request->input('additional_card_no'))) {
                $card_no = $card_no.$request->input('additional_card_no');
            }
            // Begin a database transaction
            DB::beginTransaction();

            // Create the NFC card entry
            $nfcCard = NfcCard::create([
                'card_no' => $card_no,
                'balance' => $request->input('balance'),
                'remark' => $request->input('remark'),
                'business_id' => $request->input('business_id'),
                'nfc_meta_data' => $request->input('nfc_meta_data'),
                'status' => 'active',
                'sr_no' => $request->input('sr_no'),
                'location_id' => $request->input('location_id'),
                'user_id' => $request->input('user_id')
            ]);

            if( $request->input('balance') && $request->input('balance') > 0 ) {
                NfcTransaction::create([
                    'nfc_card_id' => $nfcCard->id,
                    'transaction_type' => 'credit',
                    'payment_method' => $request->input('payment_method'), 
                    'amount' => $request->input('balance'),
                    'remark' => 'Card Registration Top-up',
                    'business_id' => $request->input('business_id'),
                    'location_id' => $request->input('location_id'),
                    'user_id' => $request->input('user_id')

                ]);
            }

            // Commit the transaction
            DB::commit();

            $nfcCardDetails = NfcCard::where('card_no', $card_no)
                           ->where('sr_no', $request->input('sr_no'))
                           ->where('business_id', $request->input('business_id'))
                           ->first();
            if( $nfcCardDetails ) {
                $nfcCardDetails->is_verified = $nfcCardDetails->is_verified ? true : false;
            }

            return response()->json(['data' => $nfcCardDetails], 201);
        } catch (\Illuminate\Database\QueryException $e) {
            DB::rollback();

            if ($e->errorInfo[1] == 1062) {
                return response()->json(['errorMessage' => 'Card with the provided Serial number already exists.'], 200);
            }
            return response()->json(['errorMessage' => 'Database errorMessage.'], 500);
        } catch (\Exception $e) {
            return response()->json(['errorMessage' => $e->getMessage()], 500);
        }
    }

    public function rechargeNfcCard(Request $request)
    {
        try {
            $request->validate([
                'card_id' => 'required|int',
                'amount' => 'required|numeric',
                'payment_method' => 'required|string',
                'business_id' => 'required|exists:business,id',
                'token' => 'required|string',
                'user_id' => 'required|exists:users,id',
                'remark' => 'nullable|string',
                'location_id' => 'nullable|string'
            ]);

            if (!User::checkUserToken($request->input('token'), $request->input('user_id'))) {
                return response()->json(['errorMessage' => 'Invalid token.'], 200);
            }

            $nfcCard = NfcCard::where('id', $request->input('card_id'))
                                ->where('business_id', $request->input('business_id'))
                                ->where('is_verified', 1)
                                ->where('status', 'active')
                                ->first();

            if (!$nfcCard) {
                return response()->json(['errorMessage' => 'Card not found.'], 200);
            }

            $previous_amount = 0;
            $topup_amount = 0;
            $promo_amount = 0;
            $available_balance = 0;
            $remark = "";
            $txn_amount = 0;
            if($request->input('amount')) {
                $isPromoApplied = false;
                $nfcPromo = NfcPromos::where('business_id', $request->input('business_id'))
                            ->where('amount', $request->input('amount'))
                            ->where(function ($query) {
                                $query->where('expiry_date', '>=', now()->format('Y-m-d'))
                                    ->orWhereNull('expiry_date');
                            })
                            ->where('status', 'active')
                            ->whereNull('deleted_at')
                            ->first();
                if( $nfcPromo ) {
                    $nfcPromoTxn = NfcTransaction::where('business_id', $request->input('business_id'))
                            ->where('nfc_promo_id', $nfcPromo->id)
                            ->where('is_void', '!=', 1)
                            ->where('nfc_card_id', $request->input('card_id'))
                            ->first();

                        $isPromoApplied = true;
                        $newBalance = $nfcCard->balance + $nfcPromo->nfc_amount;
                        $txn_amount = $nfcPromo->nfc_amount;
                        $previous_amount = $nfcCard->balance;
                        $topup_amount = $nfcPromo->amount;
                        $promo_amount = $nfcPromo->promo_amount;
                        $available_balance = $newBalance;
                        $topup_amount = $request->input('amount');
                        $remark = 'Top-up Done (Promo ' . $nfcPromo->promo_amount . ' applied)';
                        
                } else {
                    $isPromoApplied = false;
                    $newBalance = $nfcCard->balance + $request->input('amount');
                    $txn_amount = $request->input('amount');
                    $previous_amount = $nfcCard->balance;
                    $available_balance = $newBalance;
                    $topup_amount = $request->input('amount');
                    $remark = 'Top-up Done';
                }

                $nfcCard->update(['balance' => $newBalance]);

                $transaction = [
                    'transaction_type' => 'credit', 
                    'payment_method' => $request->input('payment_method'),
                    'amount' => $txn_amount,
                    'remark' => $remark,
                    'business_id' => $request->input('business_id'),
                    'nfc_card_id' => $nfcCard->id,
                    'nfc_promo_id' => ($isPromoApplied) ? (isset($nfcPromo) && $nfcPromo && $nfcPromo->id ? $nfcPromo->id : null) : null,
                    'location_id' => $request->input('location_id'),
                    'user_id' => $request->input('user_id')
                ];
                NfcTransaction::create($transaction);
            }

            return response()->json([
                'message' => 'NFC card recharged successfully.', 
                'previous_amount' => $previous_amount ."",
                'topup_amount' => $topup_amount ."",
                'promo_amount' => $promo_amount ."",
                'available_balance' => $available_balance .""
            ], 200);
        } catch (QueryException $e) {
            return response()->json(['errorMessage' => 'Database errorMessage.'], 200);
        } catch (\Exception $e) {
            return response()->json(['errorMessage' => $e->getMessage()], 200);
        }
    }
    
    public function getNfcCardTransactions(Request $request)
    {
        try {
            $request->validate([
                'card_id' => 'required|int',
                'token' => 'required|string',
                'business_id' => 'required',
                'user_id' => 'required|exists:users,id',
            ]);
            $card_id = $request->input('card_id');

            if (!User::checkUserToken($request->input('token'), $request->input('user_id'))) {
                return response()->json(['errorMessage' => 'Invalid token.'], 200);
            }

            $nfcCard = NfcCard::where('id', $card_id)
                                ->where('business_id', $request->input('business_id'))
                                ->first();
            if (!$nfcCard) {
                return response()->json(['errorMessage' => 'Card not found.'], 200);
            }
            
            $transactions = NfcTransaction::select(
                'nfc_transactions.*',
                DB::raw('IFNULL(nfc_promos.promo_amount, 0) as promo_amount'),
                DB::raw('CAST(IFNULL(nfc_transactions.amount, 0) - IFNULL(nfc_promos.promo_amount, 0) as DECIMAL(10,2)) as topup_amount'),
               )
            ->where('nfc_card_id', $card_id)
            ->leftJoin('nfc_promos', 'nfc_transactions.nfc_promo_id', '=', 'nfc_promos.id')
            ->orderBy('nfc_transactions.created_at', 'desc')
            ->get();
            $transactions->transform(function ($transaction) {
                $transaction->is_void = (bool) $transaction->is_void;
                return $transaction;
            });
            return response()->json(['transactions' => $transactions], 200);
        } catch (QueryException $e) {
            return response()->json(['errorMessage' => 'Database error.'], 200);
        } catch (\Exception $e) {
            return response()->json(['errorMessage' => $e->getMessage()], 200);
        }
    }

    public function udpateNfcCardDetails(Request $request)
    {
        try {
            $request->validate([
                'card_id' => 'required|int',
                'token' => 'required|string',
                'user_id' => 'required|exists:users,id',
                'business_id' => 'required|exists:business,id',
                'remark' => 'nullable|string',
                'location_id' => 'required|exists:business_locations,id',
                'nfc_meta_data' => 'nullable|json',
                'status'    => 'nullable|string'
            ]);

            $card_id = $request->input('card_id');
            $nfc_meta_data = $request->input('nfc_meta_data');
            $card_status = !empty($request->input('status')) ? $request->input('status') : "";
            $remark = !empty($request->input('remark')) ? $request->input('remark') : "";

            if (!User::checkUserToken($request->input('token'), $request->input('user_id'))) {
                return response()->json(['errorMessage' => 'Invalid token.'], 200);
            }

            $nfcCard = NfcCard::where('id', $card_id)
                                ->where('business_id', $request->input('business_id'))
                                ->first();
            if (!$nfcCard) {
                return response()->json(['errorMessage' => 'Card not found.'], 200);
            }
            if ($request->has('name')) {
                $nfcCard->name = $request->input('name') ? $request->input('name'):"";
            }
            if ($request->has('phone')) {
                $nfcCard->phone = $request->input('phone') ? $request->input('phone') :"";
            }
            if ($request->has('ic_number')) {
                $nfcCard->ic_number = $request->input('ic_number') ? $request->input('ic_number') :"";
            }
            if ($request->has('status')) {
                $nfcCard->status = $request->input('status') ? $request->input('status') : "";
            }
            if ($request->has('nfc_meta_data')) {
                $nfcCard->nfc_meta_data = $request->input('nfc_meta_data');
            }
            if ($request->has('remark')) {
                $nfcCard->remark = $request->input('remark') ? $request->input('remark') : " ";
            }
            
            $nfcCard->update();    
            return response()->json(['message' => 'Card updated successfully.'], 200);
            
        } catch (QueryException $e) {
            return response()->json(['errorMessage' => 'Database error.'], 500);
        } catch (\Exception $e) {
            return response()->json(['errorMessage' => $e->getMessage()], 500);
        }
    
    }

    // This API is used in Register & Transfer case
    public function verifyNfcCard(Request $request) {
        try {
            $request->validate([
                'sr_no' => 'required|string',
                'card_no' => 'required|string',
                'business_id' => 'required',
                'user_id' => 'required'
            ]);

            if (!User::checkUserToken($request->input('token'), $request->input('user_id'))) {
                return response()->json(['errorMessage' => 'Invalid token.'], 200);
            }

            $nfcCard = NfcCard::where('card_no', $request->input('card_no'))
                                ->where('sr_no', $request->input('sr_no'))
                                ->where('business_id', $request->input('business_id'))
                                ->first();
            if (!$nfcCard) {
                return response()->json(['errorMessage' => 'Card not found.'], 200);
            }
            // Update the card owner info
            $nfcCard->name = $request->input('name')?$request->input('name'):$nfcCard->name;
            $nfcCard->phone = $request->input('phone')?$request->input('phone'):$nfcCard->phone;
            $nfcCard->ic_number = $request->input('ic_number')?$request->input('ic_number'):$nfcCard->ic_number;
            
            $nfcCard->is_verified = 1;
            $nfcCard->status= 'active';
            $nfcCard->save();
            if( $nfcCard ) {
                $nfcCard->is_verified = $nfcCard->is_verified ? true : false;
            }
            return response()->json($nfcCard, 200);
        } catch (QueryException $e) {
            return response()->json(['errorMessage' => 'Database error.'], 500);
        } catch (\Exception $e) {
            return response()->json(['errorMessage' => $e->getMessage()], 500);
        }
    }

    public function activateCard($id)
    {
        if (!auth()->user()->can('invoice_settings.access')) {
            abort(403, 'Unauthorized action.');
        }
    
        if (request()->ajax()) {
            try {
                $reactivationDate = Carbon::now();
                $formattedDate = $reactivationDate->format('d M, D \a\t h:i A');
                $message = "Card reactivated on";
                $remark = $message . ' ' . $formattedDate;
                $nfcCard = NfcCard::find($id);
    
                if ($nfcCard) {
                    // Assuming 'status' is the column in the database representing the card status
                    $nfcCard->update(['status' => 'active', 'remark' => $remark]);
    
                    $output = [
                        'success' => true,
                        'message' => __("invoice.activated_success"),
                    ];
                } else {
                    $output = [
                        'success' => false,
                        'message' => __("invoice.card_not_found"),
                    ];
                }
            } catch (\Exception $e) {
                \Log::emergency("File:" . $e->getFile() . "Line:" . $e->getLine() . "Message:" . $e->getMessage());
    
                $output = [
                    'success' => false,
                    'message' => __("messages.something_went_wrong"),
                ];
            }
    
            return $output;
        }
    }

    public function deactivateCard($id)
    {
        if (!auth()->user()->can('invoice_settings.access')) {
            abort(403, 'Unauthorized action.');
        }
    
        if (request()->ajax()) {
            try {
                $nfcCard = NfcCard::find($id);
    
                if ($nfcCard) {
                    // Assuming 'status' is the column in the database representing the card status
                    $nfcCard->update(['status' => 'blocked','remark' => 'Card Deactivated']);
    
                    $output = [
                        'success' => true,
                        'message' => __("invoice.blocked"),
                    ];
                } else {
                    $output = [
                        'success' => false,
                        'message' => __("invoice.card_not_found"),
                    ];
                }
            } catch (\Exception $e) {
                \Log::emergency("File:" . $e->getFile() . "Line:" . $e->getLine() . "Message:" . $e->getMessage());
    
                $output = [
                    'success' => false,
                    'message' => __("messages.something_went_wrong"),
                ];
            }
    
            return $output;
        }
    }
   

    public function getReason($id){
        $voidReasons = [
            'Incorrect Amount' => 'Incorrect Amount',
            'Duplicate Transaction' => 'Duplicate Transaction',
            'Customer Cancelled' => 'Customer Cancelled',
            'Technical Issue' => 'Technical Issue',
            'Other'   => 'Other',
        ];
        
        return view('nfc_card_numbers.partials.voidtransaction')->with(compact('voidReasons', 'id'));        
    }

    public function void_transaction(Request $request, $id){
        if (request()->ajax()) {
            try {
                $reason = $request->input('custom_reason') == null ? $request->input('reason') : $request->input('custom_reason');
                $transactionData = NfcTransaction::join('nfc_cards', 'nfc_transactions.nfc_card_id', '=', 'nfc_cards.id')
                    ->where('nfc_transactions.id', $id)
                    ->select('nfc_transactions.*', 'nfc_cards.balance')
                    ->first();
        
                if ($transactionData) {
                    if ($transactionData->balance < $transactionData->amount) {
                        $output = [
                            'success' => false,
                            'message' => "Insufficient balance",
                        ];
                        return $output;
                    }
                    
                    $balance = $transactionData->balance - $transactionData->amount;
                    NfcCard::where('id', $transactionData->nfc_card_id)->update(['balance' => $balance]);
        
                    NfcTransaction::where('id', $id)->update(['is_void' => 1, 'void_reason'=>  $reason]);
        
                    $output = [
                        'success' => true,
                        'message' => "Transaction voided",
                    ];
                } else {
                    $output = [
                        'success' => false,
                        'message' => "Transaction not found",
                    ];
                }
            } catch (\Exception $e) {
                \Log::emergency("File:" . $e->getFile() . "Line:" . $e->getLine() . "Message:" . $e->getMessage());
                $output = [
                    'success' => false,
                    'message' => __("messages.something_went_wrong"),
                ];
            }

            return $output;
        }
    }

    public function voidTopupTransaction(Request $request){        
        $request->validate([
            'token' => 'required|string',
            'user_id' => 'required|string',
            'transaction_id' => 'required',
            'reason' => 'required|string'
        ]);
        $user_data = $request->only('transaction_id', 'token', 'user_id','reason');
        if (isset($user_data['token'])) {
            $result = User::checkUserToken($user_data['token'], $user_data['user_id']);
            if ($result) {
                try {
                    $transactionData = NfcTransaction::join('nfc_cards', 'nfc_transactions.nfc_card_id', '=', 'nfc_cards.id')
                        ->where('nfc_transactions.id', $user_data['transaction_id'])
                        ->select('nfc_transactions.*', 'nfc_cards.balance')
                        ->first();
                    if ($transactionData) {
                        if($transactionData->balance<$transactionData->amount){ 
                            return response()->json(['errorMessage' => 'Insufficient balance to void the transaction.'], 200);
                        }
                        $balance = $transactionData->balance - $transactionData->amount;
                        NfcCard::where('id', $transactionData->nfc_card_id)->update(['balance' => $balance]);
    
                        NfcTransaction::where('id', $user_data['transaction_id'])->update(['is_void' => 1,'void_reason'=>$user_data['reason']]);
                        return response()->json(['message' => 'Transaction voided successfully.'], 200);
                    } else {
                        return response()->json(['errorMessage' => 'Transaction not found.'], 200);
                    }
                } catch (\Exception $e) {
                    \Log::emergency("File:" . $e->getFile() . "Line:" . $e->getLine() . "Message:" . $e->getMessage());
                    $msg = trans("messages.something_went_wrong");
                    return response()->json(['errorMessage' => 'Something went wrong.'], 500);
                }
            } else {
                return response()->json(['errorMessage' => 'Invalid token..'], 200);
            }
        } else {
            return response()->json(['errorMessage' => 'Invalid token..'], 200);
        }
    }
    public function nfcCardSearch(Request $request)
    {
        $request->validate([
            'token' => 'required',
            'user_id' => 'required',
            'business_id' => 'required'
        ]);
        
        $searchTerm = $request->input('search_term');
        if (empty(trim($searchTerm))) {
            return response()->json(['errorMessage' => 'No matching NFC cards found.'], 200);
        }

        if (!User::checkUserToken($request->input('token'), $request->input('user_id'))) {
            return response()->json(['errorMessage' => 'Invalid token.'], 200);
        }
        $searchResults = NfcCard::where('business_id',$request->input('business_id'))
             ->where(function ($query) use ($searchTerm) {
            $query->where('card_no', 'like', '%' . $searchTerm . '%')
                ->orWhere('sr_no', 'like', '%' . $searchTerm . '%')
                ->orWhere('name', 'like', '%' . $searchTerm . '%')
                ->orWhere('phone', 'like', '%' . $searchTerm . '%')
                ->orWhere('ic_number', 'like', '%' . $searchTerm . '%');
        })->get();
        
        if ($searchResults->isEmpty()) {
            return response()->json(['errorMessage' => 'No matching NFC cards found.'], 200);
        }
        $searchResults->transform(function ($result) {
            $result->is_verified = (bool) $result->is_verified;
            return $result;
        });
        return response()->json($searchResults, 200);
    }
    public function nfcCardTransfer(Request $request)
    {
        try {
            $request->validate([
                'token' => 'required',
                'user_id' => 'required',
                'card_id' => 'required',
                'sr_no' => 'required',
                'nfc_meta_data' => 'nullable|json',
                'remark' => 'nullable|string',
                'business_id' => 'required',
            ]);
        
            if (!User::checkUserToken($request->input('token'), $request->input('user_id'))) {
                return response()->json(['errorMessage' => 'Invalid token.'], 200);
            }
            $remark = !empty($request->input('remark')) ? $request->input('remark') : "";
            $nfc_data = $request->only('card_id', 'sr_no', 'nfc_meta_data','business_id');

            $nfc_card = NfcCard::where('id', $nfc_data['card_id'])
            ->where('business_id', $nfc_data['business_id'])
            ->first();
        
            if (!$nfc_card) {
                return response()->json(['errorMessage' => 'NFC card not found.'], 200);
            }

            $existingCardWithSrNo = NfcCard::where('sr_no', $nfc_data['sr_no'])->first();
            if($existingCardWithSrNo && $existingCardWithSrNo->id !== $nfc_card->id) {
                return response()->json(['errorMessage' => 'Card is already exist with this serial number.'], 200);
            }
            $nfc_card->update([
                'sr_no' => $nfc_data['sr_no'],
                'is_verified' => 0,
                'nfc_meta_data'=> $nfc_data['nfc_meta_data'],
                'remark' => $remark,
                'status'=>'deactivate' // Card transferred but not verified.
            ]);

            if( $nfc_card ) {
                $nfc_card->is_verified = $nfc_card->is_verified ? true : false;
            }
        
            return response()->json($nfc_card, 200);
        
        } catch (\Exception $e) {
            \Log::error("Error in nfcCardTransfer: " . $e->getMessage());
            return response()->json(['errorMessage' => 'Something went wrong.'], 500);
        }
    }
    public function editNfcCardDetails($id){
        if (!auth()->user()->can('access_tables')) {
            abort(403, 'Unauthorized action.');
        }
            if (request()->ajax()) {
            $nfcCard = NfcCard::where('id', $id)
            ->first();
            return view('nfc_card_numbers.partials.editnfc')->with(compact('nfcCard', 'id'));        
        }
    }
    public function updateCardDetail(Request $request, $id)
    {
        if (!auth()->user()->can('access_tables')) {
             abort(403, 'Unauthorized action.');
        }
        $card_data = $request->only('name', 'phone','ic_number');
         if (request()->ajax()) {
            try {
                $nfcCard = NfcCard::where('id', $id)->first();
                $nfcCard->name = $card_data['name'];
                $nfcCard->phone = $card_data['phone'];
                $nfcCard->ic_number = $card_data['ic_number'];
             $nfcCard->save();
                $output = ['success' => true,
                            'message' => __("lang_v1.updated_success")
                            ];
            } catch (\Exception $e) {
                \Log::emergency("File:" . $e->getFile(). "Line:" . $e->getLine(). "Message:" . $e->getMessage());
            
                $output = ['success' => false,
                            'message' => __("messages.something_went_wrong")
                        ];
            }
         return $output;
        }
    }
    public function get_nfc_card_details(Request $request)
    {
        $request->validate([
            'card_no' => 'required|string',
            'sr_no' => 'required|string',
            'business_id' => 'required|string'
        ]);

        $card_no = $request->input('card_no');
        $sr_no = $request->input('sr_no');
        $business_id = $request->input('business_id');

        $nfcCard = NfcCard::where('card_no', $card_no)
                           ->where('sr_no', $sr_no)
                           ->where('business_id', $business_id)
                           ->where('is_verified','=',1)
                           ->first();

        if (!$nfcCard) {
            // Old card detail after transfer with new one
            $oldNfcCard = NfcCard::where('card_no', $card_no)
                           ->where('business_id', $business_id)
                           ->first();
            if($oldNfcCard){
                $oldNfcCard->remark = "This card is no longer available";
                $oldNfcCard->is_verified = false;
                $oldNfcCard->status = "blocked";
                return response()->json($oldNfcCard, 200);
            }
            else{
                return response()->json(['errorMessage' => 'The requested card could not be found'], 200);
            }
        }
        if( $nfcCard ) {
            $nfcCard->is_verified = $nfcCard->is_verified ? true : false;
        }
        return response()->json($nfcCard, 200);
    }

    function sendOtp (Request $request){
        $request->validate([
            'phone' => 'required|string',
            'business_id' => 'required|exists:business,id',
            'nfc_card_id' => 'required'
        ]);
        try{
            $allowedNumbers = ["+6599999999"]; 
            $result= false;
            $nfcCard = NfcCard::where('id', $request->input('nfc_card_id'))
            ->where('phone', $request->input('phone'))
            ->where('business_id', $request->input('business_id'))
            ->first();
            if(empty($nfcCard)){
                return response()->json(['errorMessage' => 'There is no Nfc Card associated with provided number', "success"=>false], 200);
            }
            if (in_array($request->input('phone'), $allowedNumbers)) {
              $result = true;
            }
            else{
                $result = $this->twilioOtpService->sendOTPWithTwilio($request->input('phone'));
            }
            if($result){
                return response()->json(['message' => 'Otp sent successfully', "success"=>true], 200);
            }
            else{
                return response()->json(['errorMessage' => 'something went wrong', "success"=>false], 200);
            }
    
        } catch (QueryException $e) {
                return response()->json(['errorMessage' => 'Database Error.'], 200);
        } catch (\Exception $e) {
                return response()->json(['errorMessage' => $e->getMessage()], 200);
        }
    }

    function verifyOtp(Request $request){
        $request->validate([
            'phone' => 'required|string',
            'business_id' => 'required|exists:business,id',
            'otp'=>'required',
            'nfc_card_id' => 'required'
        ]);
        try{
            $allowedNumbers = ["+6599999999"]; 
            $result = [];
            if (in_array($request->input('phone'), $allowedNumbers)) {
                if($request->input('otp') == '123456')
                {
                    $result['success'] = true;
                }
                else{
                    return response()->json(['errorMessage' => "Invalid Otp", "success"=>false], 200);
                }
            }
            else{
                $result = $this->twilioOtpService->verifyOTPWithTwilio($request->input('phone'), $request->input('otp'));
            }
            if($result['success']){
                $nfcCard = NfcCard::where('id', $request->input('nfc_card_id'))
                                    ->where('phone', $request->input('phone'))
                                    ->where('business_id', $request->input('business_id'))
                                    ->first();
                if($nfcCard)
                {
                    $nfcCard->is_verified = $nfcCard->is_verified? true:false;
                }                   
                return response()->json($nfcCard, 200);
            }
            else{
                return response()->json(['errorMessage' => $result['message'], "success"=>false], 200);
            }
        } catch (QueryException $e) {
                return response()->json(['errorMessage' => 'Database Error.', "success"=>false], 200);
        } catch (\Exception $e) {
                return response()->json(['errorMessage' => $e->getMessage(), "success"=>false], 200);
        }

    }
    public function createNfcTransaction() {
        if (!auth()->user()->can('access_tables')) {
            abort(403, 'Unauthorized action.');
        } 
    
        $business_id = request()->session()->get('user.business_id');
        $nfc_data = NfcCard::where('business_id', $business_id)->get()->mapWithKeys(function ($item) {
            return [$item->id => ['card_no' => $item->card_no, 'created_at' => $item->created_at]];
        });
        $business_locations = BusinessLocation::forDropdown($business_id);
    
        return view('nfc_card_numbers.create_nfc_transaction')->with(compact('nfc_data', 'business_locations'));
    }

    public function create_transaction(Request $request) {
        if ($request->ajax()) {
            try {
                // Define payment methods mapping
                $paymentMethods = [
                    'DEBIT_CREDIT_CARD' => 'Debit/Credit Card',
                    'NFC_CARD' => 'NFC Card',
                    'CARD' => 'Card',
                    'CASH' => 'Cash',
                    'CREDIT' => 'Credits',
                    'PAY_NOW' => 'PayNow',
                    'CREDITS_POINT' => 'Credits'
                ];
                
                // Retrieve the submitted data
                $data = $request->all();
                $user_id = $request->session()->get('user.id');
                $product_variation = 0;
                $category_data = 0;
                $unit_data = 0;
                $product = 0;

                if (isset($data['payment_method']) && isset($paymentMethods[$data['payment_method']])) {
                    $data['payment_method'] = $paymentMethods[$data['payment_method']];
                }
    
                // Retrieve the NFC card
                $nfcCard = NfcCard::findOrFail($data['nfcCard_id']);
                

                if ($data['transaction_type'] == 'debit') {
                    if (isset($data['transaction_date']) && !empty($data['transaction_date'])) {
                    
                        $transaction_date = Carbon::createFromFormat('d-m-Y H:i:s', $data['transaction_date']);
                    } else {
                        $transaction_date =\Carbon\Carbon::now();
                    }
                    $category_data = Category::where('business_id', $nfcCard->business_id)
                                            ->where('name', 'nfc')
                                            ->where('short_code', 'nfc201')
                                            ->first();
                    if(empty($category_data))
                    {
                        $category_data = Category::create([
                            'name' => 'nfc',
                            'business_id' => $nfcCard->business_id,
                            'short_code' => 'nfc201',
                            'parent_id' => 0,
                            'created_by' => 0,
                            'created_at' =>$transaction_date->format('Y-m-d H:i:s'),
                            'updated_at' =>$transaction_date->format('Y-m-d H:i:s'),
                            'category_type'=> 'product'
                        ]);
                    } 
                    $unit_data = Unit::where('business_id', $nfcCard->business_id)
                                       ->where('short_name', 'Pc(s)')
                                       ->where('actual_name', 'Pieces')->first();
                    if(empty($unit_data))
                    {
                        $unit_data = Unit::create([
                            'actual_name' => 'Pieces',
                            'business_id' => $nfcCard->business_id,
                            'short_name' => 'Pc(s)',
                            'created_at' =>$transaction_date->format('Y-m-d H:i:s'),
                            'updated_at' =>$transaction_date->format('Y-m-d H:i:s'),
                        ]);
                    }
                    $product = Product::where('business_id', $nfcCard->business_id)
                                            ->where('unit_id', $unit_data->id)
                                            ->where('category_id', $category_data->id)->first();

                    if(empty($product)){
                        $product= Product::create([
                            'name' => 'NFC Transaction', 
                            'business_id' => $nfcCard->business_id,
                            'type' => 'single', // Adjust this depending on your product type
                            'unit_id' => $unit_data->id,
                            'category_id' => $category_data->id,
                            'sku' => '', 
                            'enable_stock' => 0,
                            'tax_type' => 'inclusive',
                            'created_by' => $user_id, // Adjust based on the current user or process
                            'created_at' => $transaction_date->format('Y-m-d H:i:s'),
                            'updated_at' => $transaction_date->format('Y-m-d H:i:s'),
                        ]);

                        $sku = $this->productUtil->generateProductSku($product->id);
                        $product->sku = $sku;
                        $product->save();                                        
                        $this->productUtil->createSingleProductVariation($product->id, $product->sku, 0, 0, 0, 0, 0, [], 0);
                        $product_variation = Variation::where('product_id', $product->id)->first();
                        $business_locations = BusinessLocation::where('business_id', $nfcCard->business_id)->get();

                        if ($business_locations) {
                            foreach ($business_locations as $location) {
                                $existing_product_location = DB::table('product_locations')
                                       ->where('product_id', $product->id)
                                       ->where('location_id', $location->id)
                                       ->first();
        
                                    if (empty($existing_product_location)) {
                                        DB::table('product_locations')->insert([
                                            'product_id' => $product->id,
                                            'location_id' => $location->id,
                                        ]);
                                    }
                            }
                        }
                     }
                     else{
                        $product_variation = Variation::where('product_id', $product->id)->first();
                    }
                                   
                    $new_balance = $nfcCard->balance - $data['amount'];
                    $sell_line_note =  $data['remark'];
                    $data['remark'] = 'Card Spent '.$data['remark'];

                } else if ($data['transaction_type'] == 'credit') {
                    $previous_amount = 0;
                    $topup_amount = 0;
                    $promo_amount = 0;
                    $available_balance = 0;
                    $remark = "";
                    $txn_amount = 0;
                    $isPromoApplied = false;
                    $nfcPromo = NfcPromos::where('business_id', $nfcCard->business_id)
                                ->where('amount', $data['amount'])
                                ->where(function ($query) {
                                    $query->where('expiry_date', '>=', now()->format('Y-m-d'))
                                        ->orWhereNull('expiry_date');
                                })
                                ->where('status', 'active')
                                ->whereNull('deleted_at')
                                ->first();
                    if( $nfcPromo ) {
    
                            $isPromoApplied = true;
                            $newBalance = $nfcCard->balance + $nfcPromo->nfc_amount;
                            $txn_amount = $nfcPromo->nfc_amount;
                            $previous_amount = $nfcCard->balance;
                            $topup_amount = $nfcPromo->amount;
                            $promo_amount = $nfcPromo->promo_amount;
                            $available_balance = $newBalance;
                            $topup_amount = $data['amount'];
                            $remark = 'Top-up Done (Promo ' . $nfcPromo->promo_amount . ' applied). '.$data['remark'];
                            $data['remark']= $remark;
                            $data['amount']= $txn_amount;
                    } else {
                        $isPromoApplied = false;
                        $newBalance = $nfcCard->balance + $data['amount'];
                        $txn_amount = $data['amount'];
                        $previous_amount = $nfcCard->balance;
                        $available_balance = $newBalance;
                        $topup_amount = $data['amount'];
                        $remark = 'Top-up Done. '.$data['remark'];
                        $data['remark']= $remark;
                       
                    }

                    $new_balance = $newBalance;
                }
                if (isset($data['transaction_date']) && !empty($data['transaction_date'])) {
                    
                    $transaction_date = Carbon::createFromFormat('d-m-Y H:i:s', $data['transaction_date']);
                } else {
                    $transaction_date =\Carbon\Carbon::now();
                }
                if ($new_balance < 0) {
                    return response()->json(['success' => false, 'message' => __('Insufficient balance')]);
                }
             
                DB::beginTransaction();
                $transaction = NfcTransaction::create([
                    'transaction_type' => $data['transaction_type'],
                    'payment_method' => $data['payment_method'],
                    'amount' => $data['amount'],
                    'remark' => $data['remark'],
                    'business_id' => $nfcCard->business_id,
                    'nfc_card_id' => $nfcCard->id,
                    'location_id' => $data['business_location_id'],
                    'user_id' => $nfcCard->user_id,
                    'created_at' =>$transaction_date->format('Y-m-d H:i:s'),
                    'updated_at' =>$transaction_date->format('Y-m-d H:i:s'),
                    'is_manual_transaction' => 1
                ]);
    
                if(!empty($transaction) && $data['transaction_type'] == 'debit'){
                    $input = [
                        "extra_tag" => "",
                        "rp_redeemed" => 0.0,
                        "total_discount_amount" => 0.0,
                        "contact_id" => 2,
                        "user_id"=>$user_id,
                        "location_id" => $data['business_location_id'],
                        "products" => [
                            [
                                "sell_line_note" => $sell_line_note,
                                "line_discount_amount" => 0.0,
                                "product_unit_id" => $product->unit_id,
                                "modifier" => [],
                                "enable_stock" => 0,
                                "item_tax" => 0,
                                "sub_unit_id" => 0,
                                "product_id" => $product->id,
                                "serve_later_quantity" => 0,
                                "added_by_qr" => false,
                                "modifier_set_id" => [],
                                "tag" => "",
                                "sku" => $product->sku,
                                "quantity" => 1.0,
                                "base_unit_multiplier" => 0,
                                "combo" => [],
                                "weight" => "",
                                "unit_price_before_discount" => $data['amount'],
                                "unit_price" => $data['amount'],
                                "tax_id" => "",
                                "product_type" => "single",
                                "unit_price_inc_tax" => $data['amount'],
                                "user_id" => $user_id,
                                "line_discount_type" => "null",
                                "variation_id" => $product_variation->id,
                                "order_placed_by" => false,
                                "change_price" => 1.0,
                                "weight_price" => 0.0,
                                "modifier_quantity" => [],
                                "modifier_price" => []
                            ]
                        ],
                        "is_inclusive_gst_applied" => true,
                        "rp_redeemed_amount" => 0.0,
                        "tag_number" => "",
                        "payment" => [
                            [
                                "amount" => $data['amount'],
                                "card_type" => "NFC Card",
                                "credit_amount" => 0.0,
                                "credit_id" => 0,
                                "method" => "card",
                                "nfc_card_id" => 0,
                                "payment_gateway_response" => "null",
                                "payment_id" => ""
                            ]
                        ],
                        "total_before_tax" => $data['amount'],
                        "terminal_id" => "0",
                        "commission_type" => "",
                        "cash_received_amount" => "0.0",
                        "pax" => "",
                        "amount_rounding_method" => "0",
                        "discount_type_modal" => "percentage",
                        "service_charges" => 0,
                        "discount_type" => "percentage",
                        "is_takeaway_complete" => 1,
                        "cash_change_amount" => "0.0",
                        "tax_rate_id" => 0,
                        "res_table_id" => [],
                        "final_total" => $data['amount'],
                        "tax_calculation_amount" => 0.0,
                        "deposit" => "NaN",
                        "round_off_amount" => 0.0,
                        "tip_amount" => 0.0,
                        "business_id" => $nfcCard->business_id,
                        "business_location_id" => $data['business_location_id'],
                        "rp_unit_per_amount" => 0.0,
                        "order_platform" => "pos",
                        "type_for_api" => "Takeaway",
                        "status" => "final"
                    ];
                   
                    $output = $this->saveOrder($input);
                }
                // Update the balance in the nfc_cards table
                $nfcCard->balance = $new_balance;
                $nfcCard->save();
                

                // Commit transaction
                DB::commit();
    
                // Return success response
                return response()->json(['success' => true, 'message' => __('Transaction successful')]);
    
            } catch (\Exception $e) {
                // Rollback transaction on error
                DB::rollBack();
    
                // Log the exception
                \Log::emergency("File: " . $e->getFile() . " Line: " . $e->getLine() . " Message: " . $e->getMessage());
    
                // Return error response
                return response()->json(['success' => false, 'message' => __("messages.something_went_wrong")], 500);
            }
        }
    }
    
    function saveOrder($input)
    {
        $is_direct_sale = false;
        try {

            
            if (!empty($input['products'])) {
                $business_id = $input['business_id'];
                $transaction_id = (isset($input['transaction_id']) && $input['transaction_id']) ? $input['transaction_id'] : 0;
                $user_id = $input['user_id'];
                $contact_id = $input['contact_id'];
                $app_order_id = isset($input['app_order_id']) ? $input['app_order_id'] : "";

                //$app_item_line_id = isset($input['products'][0]['app_item_line_id']) ? $input['products'][0]['app_item_line_id'] : "";

                if (!empty($input['products'][0]['modifier_app_ids'])) {
                    $modifiers_app_ids = array_column($input['products'], 'modifier_app_ids');
                } else {
                    $modifiers_app_ids = "";
                }
                $discount = [
                    'discount_type' => $input['discount_type'],
                    'discount_amount' => $input['discount_amount']
                ];

                if (isset($input['delivery_charges'])) {
                    $delivery_charges = $input['delivery_charges'];
                } else {
                    $delivery_charges = 0;
                }

                $invoice_total = $this->productUtil->newCalculateInvoiceTotal($input['products'], $input['tax_rate_id'], $discount, $input['service_charges'], true, $delivery_charges);
                //return $invoice_total;
               
                DB::beginTransaction();

                if ($input['type_for_api'] == "Pickup" || $input['type_for_api'] == "Delivery") {
                    if (strtolower($input['payment'][0]['method']) == "card" && strtolower($input['payment'][0]['card_type']) != "paynow") {
                        $stripeRespond = $this->stripePost($input);
                    }
                }

                if (empty($input['transaction_date'])) {
                    $input['transaction_date'] = \Carbon::now();
                } else {
                    $input['transaction_date'] = $this->productUtil->uf_date($input['transaction_date'], true);
                }

                $input['is_suspend'] = isset($input['is_suspend']) && 1 == $input['is_suspend'] ? 1 : 0;
                if ($input['is_suspend']) {
                    $input['sale_note'] = !empty($input['additional_notes']) ? $input['additional_notes'] : null;
                }
                //transactions table
                if ($transaction_id) {
                    $transaction = $this->transactionUtil->updateSellTransaction($transaction_id, $business_id, $input, $invoice_total, $user_id, $app_order_id);
                } else {
                   
                    $transaction = $this->transactionUtil->createSellTransaction($business_id, $input, $invoice_total, $user_id);
                }
                //transaction_sell_lines table


                if (!empty($transaction->invoice_no)) {
                    $invoice_resp = $transaction->invoice_no;
                } else {
                    $invoice_resp = "";
                }

                if (!empty($transaction->order_check_no)) {
                    $order_check_no = $transaction->order_check_no;
                } else {
                    $order_check_no = "";
                }

                $business_details = $this->businessUtil->getDetails($business_id);
                if (in_array("modifiers", $business_details->enabled_modules)) {
                    $isModuleEnabled = true;
                } else {
                    $isModuleEnabled = false;
                }
                $this->transactionUtil->createOrUpdateSellLines($transaction, $input['products'], $input['location_id'], $app_order_id, $modifiers_app_ids, $user_id, false, null, [], true, $isModuleEnabled);

                $is_credit_sale = isset($input['is_credit_sale']) && $input['is_credit_sale'] == 1 ? true : false;
                //transaction_payments table
                if (!$transaction->is_suspend && !empty($input['payment']) && !$is_credit_sale) {
                    // Need to implement the coupon for the pos orders

                    if($input['is_pay_first'])
                    {

                        $transaction_payment = $this->digital_ordering_stripe_payment_for_payfirst($input, $transaction);
                        if($transaction_payment['status'] == 'failed')
                        {
                            return $output = [ 'errorMessage' => $transaction_payment['msg'],
                                                'status' => 'failed'
                                                ];
                        }
                        else{
                            $transaction_payment = $transaction_payment['data']; 
                        }
                    }
                    else{
                         $transaction_payment = $this->transactionUtil->createOrUpdatePaymentLines($transaction, $input['payment'], $app_order_id, $business_id, $user_id);
                    }
                }

                //Check for final and do some processing.
                if ($input['status'] == 'final' && $input['type_for_api'] != "Pickup" && $input['type_for_api'] != "Delivery") {
                    //update product stock
                    foreach ($input['products'] as $product) {
                        $decrease_qty = $this->productUtil
                            ->num_uf($product['quantity']);
                        if (!empty($product['base_unit_multiplier'])) {
                            $decrease_qty = $decrease_qty * $product['base_unit_multiplier'];
                        }

                        if ($product['enable_stock']) {
                            $this->productUtil->decreaseProductQuantity(
                                $product['product_id'],
                                $product['variation_id'],
                                $input['location_id'],
                                $decrease_qty
                            );
                        }

                        if ($product['product_type'] == 'combo') {
                            //Decrease quantity of combo as well.
                            $this->productUtil
                                ->decreaseProductQuantityCombo(
                                    $product['combo'],
                                    $input['location_id']
                                );
                        }
                    }

                    //Add payments to Cash Register
                    if (!$is_direct_sale && !$transaction->is_suspend && !empty($input['payment']) && !$is_credit_sale) {
                        //cash_register_transactions table
                        $this->cashRegisterUtil->addSellPayments($transaction, $input['payment'], $input['user_id']);
                    }

                    $debitOrder = $this->transactionUtil->debitOrderBalance($input);
                    if ($debitOrder == false) {
                        return response()->json(['errorMessage' => 'Insufficient NFC Card Balance.'], 200);
                    }

                    $debitOrderAmount = $this->transactionUtil->debitOrderBalanceFromCredit($input, $transaction->id);
                    if ($debitOrderAmount == false) {
                        return response()->json(['errorMessage' => 'Insufficient Credit Balance.'], 200);
                    }
                }

                if($input['status'] == 'final') {
                    if ($business_details->enable_rp == 1) {
                        $redeemed = !empty($input['rp_redeemed']) ? $input['rp_redeemed'] : 0;
                        $this->transactionUtil->updateCustomerRewardPoints($contact_id, $transaction->rp_earned, 0, $redeemed);
                    }
                } 

                //Update payment status
                $payment_status = $this->transactionUtil->updatePaymentStatus($transaction->id, $transaction->final_total);

                //$transaction->payment_status = $payment_status;

                if ($input['type_for_api'] == "Pickup" || $input['type_for_api'] == "Delivery") {
                    //update contact info
                    if (strtolower($input['payment'][0]['method']) == "card") {
                        $contact = Contact::where('id', $input['contact_id'])->firstOrFail();
                        $update_contact_data = [
                            'first_name' => !empty($input['first_name']) ? $input['first_name'] : null,
                            'last_name' => !empty($input['last_name']) ? $input['last_name'] : null,
                            'address_line_1' => !empty($input['billing_address']) ? $input['billing_address'] : null,
                            'city' => !empty($input['city']) ? $input['city'] : null,
                            'zip_code' => !empty($input['zip_code']) ? $input['zip_code'] : null,
                            'country' => !empty($input['country']) ? $input['country'] : null,
                            'mobile' => !empty($input['phone']) ? $input['phone'] : null,
                            'email' => !empty($input['email']) ? $input['email'] : null,
                            'accept_term_and_cond' => isset($input['accept_term_and_cond']) ? $input['accept_term_and_cond'] : 0,
                            'occasional_offers' => isset($input['occasional_offers']) ? $input['occasional_offers'] : 0
                        ];
                        $contact->fill($update_contact_data);
                        $contact->update();
                    }

                    //update user info
                    // $user = User::where('id', $input['user_id'])->firstOrFail();
                    // $update_user_data = [
                    //     'first_name' => !empty($input['first_name']) ? $input['first_name'] : null,
                    //     'last_name' => !empty($input['last_name']) ? $input['last_name'] : null,
                    //     'gender' => !empty($input['gender']) ? $input['gender'] : null,
                    //     //'contact_number' => !empty($input['phone']) ? $input['phone'] : null
                    // ];
                    // $user->fill($update_user_data);
                    // $user->update();

                    //save_delivery_details
                    $save_delivery_details = [
                        'transaction_id' => $transaction->id,
                        'd_date' => !empty($input['d_date']) ? $input['d_date'] : null,
                        'd_time' => !empty($input['d_time']) ? $input['d_time'] : null,
                    ];

                    if (!empty($input['d_address'])) {
                        $save_delivery_details['d_address'] = $input['d_address'];
                    }

                    if (!empty($input['outlet'])) {
                        $save_delivery_details['outlet'] = $input['outlet'];
                    }

                    $delivery_details = DeliveryDetails::create($save_delivery_details);

                    //$stripeRespond = $this->stripePost($input);

                    if (strtolower($input['payment'][0]['method']) == "card" && strtolower($input['payment'][0]['card_type']) != "paynow") {
                        $transaction_payment = TransactionPayment::where('transaction_id', $transaction->id)->first();
                        $transaction_payment->stripe_respond = json_encode($stripeRespond['data']['respond']);
                        $transaction_payment->stripe_status = $stripeRespond['data']['status'];
                        $transaction_payment->save();
                    }
                }

                DB::commit();

                if ($input['type_for_api'] == "Pickup" || $input['type_for_api'] == "Delivery") {
                    $order_sent = Carbon::createFromFormat('Y-m-d H:i:s', $transaction->created_at)->format('H:i A');
                    $output = ['msg' => "Sale order is added.", 'transaction_id' => $transaction->id, 'ref_no' => $transaction->ref_no, 'order_no' => $transaction->order_no, 'order_sent' => $order_sent, 'invoice_no' => $invoice_resp];
                } else {
                    $output = ['msg' => "Sale order is added.", 'transaction_id' => $transaction->id, 'invoice_no' => $invoice_resp, 'order_check_no' => $order_check_no, 'order_status' => $input['status'], 'status' =>'success'];
                }
                //return($input['transaction_date']);
            } else {
                DB::rollBack();
                $output = [
                    'errorMessage' => trans("messages.something_went_wrong")
                ];
            }
        } catch (\Exception $e) {
            DB::rollBack();
            \Log::emergency("File:" . $e->getFile() . "Line:" . $e->getLine() . "Message:" . $e->getMessage());
            $msg = trans("messages.something_went_wrong");

            if (get_class($e) == \App\Exceptions\PurchaseSellMismatch::class) {
                $msg = $e->getMessage();
            }
            if (get_class($e) == \App\Exceptions\AdvanceBalanceNotAvailable::class) {
                $msg = $e->getMessage();
            }

            $error_message = "File: " . $e->getFile(). " | Line: " . $e->getLine(). " | Message: " . $e->getMessage();
            // $this->util->sendErrorLogOnMSTeam($error_message);

            $output = [
                'errorMessage' => $msg
            ];
        }

        return $output;
    }
}
