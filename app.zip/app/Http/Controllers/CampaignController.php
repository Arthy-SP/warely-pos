<?php

namespace App\Http\Controllers;

use App\Campaign;
use App\Couponsystem;
use App\CouponLayout;
use App\BusinessLocation;
use App\CampaignList;
use App\Utils\Util;
use App\Product;
use App\Category;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Datatables;
use File;
use Illuminate\Support\Facades\Storage;

class CampaignController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        if (!auth()->user()->can('couponsystem.access')) {
            abort(403, 'Unauthorized action.');
        }

        if (request()->ajax()) {
            $business_id = request()->session()->get('user.business_id');

            $barcodes = Campaign::where('business_id', $business_id)
                        ->select(['id','name', 'coupon_qty','coupon_id']);

            return Datatables::of($barcodes)
                ->addColumn(
                    'action',
                    '<a href="{{action(\'CampaignController@edit\', [$id])}}" class="btn btn-xs btn-primary"><i class="glyphicon glyphicon-edit"></i> @lang("messages.edit")</a>
                        &nbsp;
                        <button type="button" data-href="{{action(\'CampaignController@destroy\', [$id])}}" class="btn btn-xs btn-danger delete_barcode_button" ><i class="glyphicon glyphicon-trash"></i> @lang("messages.delete")</button>&nbsp;
                        <a href="{{action(\'CampaignController@show\', [$id])}}" class="btn btn-xs btn-success"><i class="glyphicon glyphicon-eye-open"></i> View</a>
                        <a href="campaign-list?id={{$id}}&coupon_id={{$coupon_id}}" class="btn btn-xs btn-success"><i class="glyphicon glyphicon-eye-open"></i> List Coupons</a>
                        '
                )
                ->removeColumn('coupon_id')
                ->rawColumns([3])
                ->make(false);
        }

        return view('campaign.index');
    }


    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        if (!auth()->user()->can('couponsystem.access')) {
            abort(403, 'Unauthorized action.');
        }
        $business_id = request()->session()->get('user.business_id');
        $coupon_id = Couponsystem::where('business_id', $business_id)
                            ->pluck('coupon_name', 'id');

        $business_locations = BusinessLocation::where('business_id', $business_id)->pluck('name', 'id');
        $all_products = Product::where('business_id', $business_id)->pluck('name','id');
        $categories = Category::where('business_id', $business_id)->pluck('name','id');
        return view('campaign.create')->with(compact('coupon_id', 'business_locations', 'all_products', 'categories'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        if (!auth()->user()->can('couponsystem.access')) {
            abort(403, 'Unauthorized action.');
        }

        try {
            $business_id = $request->session()->get('user.business_id');
            $input = $request->only(['coupon_id', 'name', 'coupon_qty', 'coupon_password', 'location_id', 'campaign_link', 'campaign_description', 'term_and_conditions', 'each_user_coupon_limit', 'campaign_type', 'target_type', "start_date", "end_date"]);
            $Campaign = Couponsystem::find($input['coupon_id']);
            $input['location_id'] = $request->location_ids;
            $input['layout_id'] = $Campaign->layout_id;
            $input['start_date'] = date('Y-m-d',strtotime($input['start_date']));
            $input['end_date'] = date('Y-m-d', strtotime($input['end_date']));
            $input['expiry_date'] = date('Y-m-d',strtotime('+'.$Campaign->expiry_day.' days'));
            
            $input['business_id'] = $business_id;
                if($request->hasFile('image')){
                    $upload_image = $this->uploadImageAws($request);
                }
            if($request->target_type == 'Products') {
                $request->products = array_filter($request->products);
                $input['campaign_product_ids'] = json_encode($request->products);
                $input['campaign_category_ids'] = null;
            } else {
                $request->categories = array_filter($request->categories);
                $input['campaign_category_ids'] = json_encode($request->categories);
                $input['campaign_product_ids'] = null;
            }
            $input['image'] = !empty($upload_image)? $upload_image:'null';
            $barcode = Campaign::create($input);
            for($i=1;$i<=$input['coupon_qty'];$i++) {
                $data['business_id']=$business_id;
                $data['location_id']=$input['location_id'];
                $data['coupon_id']=$input['coupon_id'];
                $data['layout_id']=$input['layout_id'];
                $data['campaign_id'] = $barcode->id;
                $data['status'] = 0;
                CampaignList::create($data);    
            }
            $output = ['success' => 1,
                            'msg' => 'successfully added'
            ];
          } catch (\Exception $e) {
            \Log::emergency("File:" . $e->getFile(). "Line:" . $e->getLine(). "Message:" . $e->getMessage());
            
            $output = ['success' => 0,
                            'msg' => __("messages.something_went_wrong")
                        ];
        } 
        return redirect('campaign')->with('status', $output); 
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Campaign  $campaign
     * @return \Illuminate\Http\Response
     */
    public function show(Campaign $campaign)
    {
        
        $Couponsystem = Couponsystem::find($campaign->coupon_id);
        $findTxt = array('{coupon_name}','{coupon_qty}','{coupon_value}','{min_purchase}','{min_pax}');
        $replaceTxt = array($Couponsystem->coupon_name,$campaign->coupon_qty,$Couponsystem->coupon_value,$Couponsystem->min_purchase,$Couponsystem->min_pax);
        $CouponsystemLayoutFront = str_replace($findTxt,$replaceTxt,$Couponsystem->front_image);
        // dd($CouponsystemLayoutFront);
        $CouponsystemLayoutBack =  str_replace($findTxt,$replaceTxt,$Couponsystem->back_image);
        $jsonQr = json_encode(array("coupon_name"=>$Couponsystem->coupon_name,"coupon_id"=>$campaign->coupon_id,"campaign_id"=>$campaign->id,'coupon_value'=>$Couponsystem->coupon_value,'min_purchase'=>$Couponsystem->min_purchase,'expiry_date'=>$campaign->expiry_date,'min_pax'=>$Couponsystem->min_pax));
        return view('campaign.view')
        ->with(compact('campaign','Couponsystem','CouponsystemLayoutFront','CouponsystemLayoutBack','jsonQr'));
    }
    public function getcampaigns() {
        print_r($_REQUEST);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Campaign  $campaign
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        if (!auth()->user()->can('couponsystem.access')) {
            abort(403, 'Unauthorized action.');
        }

        $business_id = request()->session()->get('user.business_id');
        $campaign = Campaign::where('business_id', $business_id)->find($id);
        $coupon_id = Couponsystem::where('business_id', $business_id)
                            ->pluck('coupon_name', 'id');
        
        $campaign->campaign_product_ids = json_decode($campaign->campaign_product_ids, true);
        $campaign->campaign_category_ids = json_decode($campaign->campaign_category_ids, true);
        $products = Product::where('business_id', $business_id)->pluck('name','id');
        $categories = Category::where('business_id', $business_id)->pluck('name','id');
        $start_date = Carbon::parse($campaign->start_date)->format('Y-m-d');
        $end_date = Carbon::parse($campaign->end_date)->format('Y-m-d');
        $business_location = BusinessLocation::where('business_id', $business_id)->pluck('name', 'id');
        return view('campaign.edit')
            ->with(compact('campaign','coupon_id', 'business_location', 'products', 'categories', "start_date", "end_date"));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Campaign  $campaign
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Campaign $campaign)
    {
        if (!auth()->user()->can('couponsystem.access')) {
            abort(403, 'Unauthorized action.');
        }

        try {
            $input = $request->only(['coupon_id', 'name', 'coupon_qty', 'coupon_password', 'channel_id', 'campaign_link', 'campaign_description', 'term_and_conditions', 'each_user_coupon_limit', 'campaign_type', 'target_type', "start_date", "end_date"]);
            $input['location_id'] = json_encode($request->location_ids);
            
            if($request->target_type == 'Products') {
                $request->products = array_filter($request->products);
                $input['campaign_product_ids'] = json_encode($request->products);
                $input['campaign_category_ids'] = null;
            } else {
                $request->categories = array_filter($request->categories);
                $input['campaign_category_ids'] = json_encode($request->categories);
                $input['campaign_product_ids'] = null;
            }
            $input['start_date'] = date('Y-m-d',strtotime($input['start_date']));
            $input['end_date'] = date('Y-m-d', strtotime($input['end_date']));
            $business_id = $request->session()->get('user.business_id');
            // if($request->hasFile('image')){
            //     $upload_image = $this->uploadImageAws($request);
            // }
            // $input['image'] = !empty($upload_image)? $upload_image:'null';
            $barcode = Campaign::where('id', $campaign->id)->update($input);
            $output = [
                        'success' => 1,
                        'msg' => 'successfully updated'
                      ];
       } catch (\Exception $e) {
            \Log::emergency("File:" . $e->getFile(). "Line:" . $e->getLine(). "Message:" . $e->getMessage());
            
            $output = ['success' => 0,
                           'msg' => __("messages.something_went_wrong")
                       ];
        } 
        return redirect('campaign')->with('status', $output);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Campaign  $campaign
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
     
        
        if (request()->ajax()) {
            try {
                $barcode = Campaign::find($id);
                    $barcode->delete();
                    $output = ['success' => true,
                                'msg' => 'successfully deleted'
                                ];
             } catch (\Exception $e) {
                \Log::emergency("File:" . $e->getFile(). "Line:" . $e->getLine(). "Message:" . $e->getMessage());
            
                $output = ['success' => false,
                            'msg' => __("messages.something_went_wrong")
                        ];
            } 

            return $output;
        }
    }
    
    public function uploadImageAws($request)
    {
        if ($request->hasFile('image')) {
            $file = $request->file('image');
            $extension = $file->getClientOriginalExtension(); // you can also use file name
            $fileName = time() . '.' . $extension;
            $s3DestinationPath = config('constants.awsS3Env') . '/campaign_image/' . $fileName;
            
            // Upload the file to S3
            Storage::disk('s3')->put($s3DestinationPath, file_get_contents($file));
            // You can also specify access permissions like 'public' if needed
            Storage::disk('s3')->setVisibility($s3DestinationPath, 'public');
            $s3FileUrl = Storage::disk('s3')->url($s3DestinationPath);
            return $s3FileUrl;
        }
    }

    public function uploadImageLocal($request)
    {
        if ($request->hasFile('image')) {
            $file = $request->file('image');
            $extension = $file->getClientOriginalExtension(); // you can also use file name
            $fileName = time() . '.' . $extension;
            $path = public_path() . '/campaign_image';

            $file_path = url('campaign_image/' . $fileName);
            if (!file_exists($path)) {
                    File::makeDirectory($path, $mode = 0777, true, true);
                }
            $upload = $file->move($path, $fileName);
            return $upload;
        }
    }

}
