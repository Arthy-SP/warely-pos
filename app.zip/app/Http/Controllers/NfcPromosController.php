<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\NfcPromos;
use App\BusinessLocation;
use Datatables;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;
use Carbon\Carbon;


class NfcPromosController extends Controller
{
    public function __construct() {

    }

    public function index()
    {
        if (!auth()->user()->can('access_tables')) {
            abort(403, 'Unauthorized action.');
        }

        $business_id = request()->session()->get('user.business_id');

        if (request()->ajax()) {
            
            $nfc_promos = NfcPromos::where('nfc_promos.business_id', $business_id)
                                    ->select(['nfc_promos.title', 'nfc_promos.id', 'nfc_promos.amount', 'nfc_promos.promo_amount', 'nfc_promos.expiry_date', 'nfc_promos.status', 'nfc_promos.number_of_usage', 'nfc_promos.business_id', 'nfc_promos.location_id', 'nfc_promos.created_at', 'nfc_promos.nfc_amount', DB::raw("CASE nfc_promos.status WHEN 'active' THEN 'Activated' ELSE 'Deactivated' END AS status")]);
            
            return Datatables::of($nfc_promos)
               ->addColumn(
                   'action',
                   '@role("Admin#' . $business_id . '")
                   <button data-href="{{action(\'NfcPromosController@edit\', [$id])}}" class="btn btn-xs btn-primary edit_nfc_promo_button"><i class="glyphicon glyphicon-edit"></i> @lang("messages.edit")</button>
                       &nbsp;
                   @endrole
                   @role("Admin#' . $business_id . '")
                       <button data-href="{{action(\'NfcPromosController@destroy\', [$id])}}" class="btn btn-xs btn-danger delete_nfc_promo_button"><i class="glyphicon glyphicon-trash"></i> @lang("messages.delete")</button>
                   @endrole'
               )
               ->addColumn(
                    'amount',
                    '<div style="white-space: nowrap;">@format_currency($amount)</div>'
                )
                ->addColumn(
                    'promo_amount',
                    '<div style="white-space: nowrap;">@format_currency($promo_amount)</div>'
                )
                ->addColumn(
                    'nfc_amount',
                    '<div style="white-space: nowrap;">@format_currency($nfc_amount)</div>'
                )
               ->removeColumn('id')
               ->rawColumns(['action', 'title', 'amount', 'promo_amount', 'status', 'nfc_amount'])
               ->make(true);
       }

       return view('nfc_promos.index');
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        if (!auth()->user()->can('invoice_settings.access')) {
            abort(403, 'Unauthorized action.');
        }

        $business_id = request()->session()->get('user.business_id');
        $business_locations = BusinessLocation::forDropdown($business_id);

        return view('nfc_promos.create')
            ->with(compact('business_locations'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        if (!auth()->user()->can('invoice_settings.access')) {
            abort(403, 'Unauthorized action.');
        }

        try {
            // Define validation rules
            $rules = [
                'title' => 'required|string|max:255',
                'amount' => 'required|regex:/^\d+(\.\d{1,2})?$/',
                'promo_amount' => 'required|regex:/^\d+(\.\d{1,2})?$/'
            ];

            // Define custom error messages if needed
            $messages = [
                'title.required' => 'The title field is required.',
                'amount.required' => 'The topup amount field is required.',
                'amount.regex' => 'The field must be a number with up to two decimal points.',
                'promo_amount.required' => 'The extra amount field is required.',
                'promo_amount.regex' => 'The field must be a number with up to two decimal points.',
            ];

            // Perform validation
            $validator = Validator::make($request->all(), $rules, $messages);

            // Check if validation fails
            if ($validator->fails()) {
                return redirect()->back()->withErrors($validator)->withInput();
            }
            if(empty($request->input('amount')) || $request->input('amount') < 1){
                return [
                    'success' => false,
                    'message' => __('Topup amount should be at least one.')
                ];
            }
            
            $input = $request->only(['title', 'amount', 'promo_amount', 'expiry_date']);
            $business_locations = $request->only(['business_locations']);

            $business_id = $request->session()->get('user.business_id');
            $nfcPromo = NfcPromos::where('business_id', $business_id)
                            ->where('amount', $input['amount'])
                            ->where('status', 'active')
                            ->where('location_id', $business_locations['business_locations'])
                            ->whereNull('deleted_at')
                            ->first();
            if( $nfcPromo ) {
                $output = [
                    'success' => false,
                    'message' => "Promo with " . $input['amount'] . " Amount is already exists"
                ];
            } else {
                $input['business_id'] = $business_id;
                $input['nfc_amount'] = $input["amount"] + $input["promo_amount"];
                $input['expiry_date'] = Carbon::createFromFormat('d-m-Y', $input['expiry_date'])->format('Y-m-d');
                $input['location_id']= $business_locations['business_locations'];
                NfcPromos::create($input);
                $output = [
                    'success' => true,
                    'message' => __("invoice.added_success")
                ];
            }
        } catch (\Exception $e) {
            \Log::emergency("File:" . $e->getFile(). "Line:" . $e->getLine(). "Message:" . $e->getMessage());
            
            $output = [
                'success' => false,
                'message' => __("messages.something_went_wrong")
            ];
        }

        return $output;
    }

    /**
     * Show the form for editing the specified resource.
     * @return Response
     */
    public function edit($id)
    {
        if (!auth()->user()->can('access_tables')) {
            abort(403, 'Unauthorized action.');
        }

        if (request()->ajax()) {
            $business_id = request()->session()->get('user.business_id');
            $nfcPromo = NfcPromos::join('business_locations', 'nfc_promos.location_id', '=', 'business_locations.id')
            ->where('nfc_promos.business_id', $business_id)
            ->where('nfc_promos.id', $id)
            ->select('nfc_promos.*', 'business_locations.name as location_name', 'business_locations.location_id as location_id')
            ->first();
        
            $location = $nfcPromo ? $nfcPromo->location_name.'('.$nfcPromo->location_id.')' : '';
            $nfcPromo['business_locations']= $location ; 
            return view('nfc_promos.edit')->with(compact('nfcPromo'));
        }
    }

    /**
     * Update the specified resource in storage.
     * @param  Request $request
     * @return Response
     */
    public function update(Request $request, $id)
    {
        if (!auth()->user()->can('access_tables')) {
             abort(403, 'Unauthorized action.');
        }

        // Define validation rules
        $rules = [
            'title' => 'required|string|max:255'
        ];

        // Define custom error messages if needed
        $messages = [
            'title.required' => 'The title field is required.'
        ];

        // Perform validation
        $validator = Validator::make($request->all(), $rules, $messages);

        // Check if validation fails
        if ($validator->fails()) {
            return redirect()->back()->withErrors($validator)->withInput();
        }

        if (request()->ajax()) {
            try {
                $input = $request->only(['title', 'amount', 'promo_amount', 'status','expiry_date']);
                $input['expiry_date'] = Carbon::createFromFormat('d-m-Y', $input['expiry_date'])->format('Y-m-d');
                $business_id = $request->session()->get('user.business_id');

                $nfcPromo = NfcPromos::where('business_id', $business_id)->findOrFail($id);
                $nfcPromo->title = $input['title'];
                $nfcPromo->status = $input['status'];
                $nfcPromo->expiry_date = $input['expiry_date'];
                $nfcPromo->save();
                $output = [
                    'success' => true,
                    'message' => __("lang_v1.updated_success")
                ];
            } catch (\Exception $e) {
                \Log::emergency("File:" . $e->getFile(). "Line:" . $e->getLine(). "Message:" . $e->getMessage());
            
                $output = ['success' => false,
                            'message' => __("messages.something_went_wrong")
                        ];
            }

            return $output;
        }
    }

    /**
     * Remove the specified resource from storage.
     * @return Response
     */
    public function destroy($id)
    {
        if (!auth()->user()->can('access_tables')) {
            abort(403, 'Unauthorized action.');
        }

        if (request()->ajax()) {
            try {
                $business_id = request()->user()->business_id;
                $nfcPromo = NfcPromos::where('business_id', $business_id)->findOrFail($id);
                $nfcPromo->delete();

                $output = ['success' => true,
                            'msg' => __("lang_v1.deleted_success")
                            ];
            } catch (\Exception $e) {
                \Log::emergency("File:" . $e->getFile(). "Line:" . $e->getLine(). "Message:" . $e->getMessage());
            
                $output = ['success' => false,
                            'msg' => __("messages.something_went_wrong")
                        ];
            }

            return $output;
        }
    }
}