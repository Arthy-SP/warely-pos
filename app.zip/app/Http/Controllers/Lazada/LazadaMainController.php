<?php

namespace App\Http\Controllers\Lazada;

use Illuminate\Support\Facades\Log;
use Illuminate\Http\Request;

use Illuminate\Routing\Controller;
use App\Providers\LazadaServiceProvider;
use App\Product;

use Illuminate\Support\Facades\Artisan;
use Yajra\DataTables\Facades\DataTables;
use App\Brands;
use App\Business;
use App\BusinessLocation;
use App\Category;
use App\Media;
use App\ProductVariation;
use App\PurchaseLine;
use App\SellingPriceGroup;
use App\TaxRate;
use App\Unit;
use App\Grabcategory;
use App\Utils\ModuleUtil;
use App\Utils\ProductUtil;
use App\Variation;
use App\VariationGroupPrice;
use App\VariationLocationDetails;
use App\VariationTemplate;
use App\Warranty;
use App\Services\AuthService;
use Carbon\Carbon;
use Illuminate\Support\Facades\DB;


class LazadaMainController extends Controller


{
    protected $productUtil;
    protected $moduleUtil;
 
    private $barcode_types;
    public function __construct(LazadaServiceProvider $LazadaService, ProductUtil $productUtil)
    {
        $this->LazadaServiceProvider = $LazadaService;
        $this->productUtil = $productUtil;
    }


    public function apiSettings()
    {
        $business_id = request()->session()->get('business.id');

        $default_settings = [
            'lazada_api_key' => '',
            'lazada_api_secret_key' => '',
           
        ];

     

        $business = Business::find($business_id);

        $locations = BusinessLocation::forDropdown($business_id);
        if (!empty($business->lazada_api_settings)) {
            $default_settings = json_decode($business->lazada_api_settings, true);
        }

        // $cron_job_command = $this->moduleUtil->getCronJobCommand();
  

        return view('lazada.api_settings')
                ->with(compact( 'default_settings','locations',   'business'));
    }
    public function updateSettings(Request $request)
    {
        $business_id = request()->session()->get('business.id');

         
        
        try {
            $input = $request->except('_token');
           
            $business = Business::find($business_id);
            $business->lazada_api_settings = json_encode($input);
          
            $business->save();

            $output = ['success' => 1,
                            'msg' => trans("lang_v1.updated_succesfully")
                        ];
        } catch (\Exception $e) {
            \Log::emergency("File:" . $e->getFile(). "Line:" . $e->getLine(). "Message:" . $e->getMessage());

            $output = ['success' => 0,
                            'msg' => trans("messages.something_went_wrong")
                        ];
        }

        return redirect()->back()->with(['status' => $output]);
    }

    public function index(Request $request)
    {
        
        $business_id = request()->session()->get('business.id');
        $business = Business::find($business_id);
        $lazada_api_settings = json_decode($business->lazada_api_settings);
        $secret_key = $lazada_api_settings->lazada_api_secret_key;
        $api_key = $lazada_api_settings->lazada_api_key;
       
        $new_access = '';
        $data['cat'] = [];
        $code = @$request->query('code');
        $session_acess_token = $request->session()->get('lazada_acess_token');
        $session_refresh_token = $request->session()->get('lazada_refresh_token');
        $accessTokenExpiry = $request->session()->get('access_token_expiry');
        $refreshTokenExpiry = $request->session()->get('refresh_token_expiry');

        if ($accessTokenExpiry && Carbon::now()->greaterThan($accessTokenExpiry)) {

            $new_access = $this->LazadaServiceProvider->refreshToken($session_refresh_token);
        }

        if (empty(session('lazada_refresh_token'))  && $code != '') {

            $access_token = '';
            $refresh_token = '';
            if (isset($code) && $code != '') {
                $get_access = $this->LazadaServiceProvider->getAcessToken($code);

                if (isset($get_access['code']) && $get_access['code'] == 0) {
                    $refresh_token = $get_access['refresh_token'];
                    $new_access = $this->LazadaServiceProvider->refreshToken($refresh_token);
                    $access_token = $new_access['access_token'];

                    $data['lazada_account'] = $new_access['account'];
                    $data['lazada_country'] = $new_access['country'];
                    $data['lazada_seller_id'] =  $new_access['country_user_info_list'][0]['seller_id'];
                }
            }
        } else {
            $data['lazada_account'] = $request->session()->get('lazada_account');
            $data['lazada_country'] = $request->session()->get('lazada_country');
            $data['lazada_seller_id'] =  $request->session()->get('lazada_seller_id');
        }

        if (empty(session('lazada_refresh_token'))  && $code == '') {
            // return redirect('https://auth.lazada.com/oauth/authorize?response_type=code&force_auth=true&redirect_uri=https://www.fabulousnaturals.com/&client_id=130703');

            return view('redirect-view', compact('https://auth.lazada.com/oauth/authorize?response_type=code&force_auth=true&redirect_uri=https://www.fabulousnaturals.com/&client_id='.$api_key));
        }

        $lazada_product = Product::where('lazada_product_id', '!=', null)->get()->count();
        $lazada_images = Product::where('lazada_img_id', '!=', null)->get()->count();
        $product_count = Product::get()->count();

        $data['total_products'] = $product_count;
        $data['lzd_products_count'] = $lazada_product;
        $data['lzd_img_count'] = $lazada_images;


        $response = $this->LazadaServiceProvider->getCategoryTree();
        $categories = $response->getData(true);
        $data['cat'] = $categories['data'];
        $data['acess'] = $new_access['access_token'];
        return view('lazada.index', ['data' => $data]);
    }


    public function getAcessToken()
    {


        $response = $this->LazadaServiceProvider->getAcessToken();


        dd($response['code']);
    }

    public function refreshToken(Request $request)
    {

        $response = $this->LazadaServiceProvider->refreshToken('50001000333bBCracyQeQjiGPxuyadZm1EMThTriAiDtA1e8cfeb3OvzDfKiwZJu');


        if (isset($response['code']) && $response['code'] == 0) {
            $refresh_token = $response['refresh_token'];
            $acess = $response['access_token'];
            $accessTokenExpiry = Carbon::now()->addSeconds($response['expires_in']);
            $refreshTokenExpiry = Carbon::now()->addSeconds($response['refresh_expires_in']);

            $request->session()->put([
                'lazada_acess_token' =>  $acess,
                'access_token_expiry' => $accessTokenExpiry,
                'lazada_refresh_token' => $refresh_token,
                'refresh_token_expiry' => $refreshTokenExpiry,

            ]);
        } else {
            session()->forget('lazada_refresh_token');
        }

        Log::info(session()->all());

        dd($response);
    }



    public function AddProduct(Request $request)
    {
        // return view('lazada.add_product');
        $action = 'add';
        $business_id = request()->session()->get('user.business_id');
        $selling_price_group_count = SellingPriceGroup::countSellingPriceGroups($business_id);
        $categories = Category::forDropdown($business_id, 'product');

        $brands = Brands::forDropdown($business_id);

        $units = Unit::forDropdown($business_id);

        $tax_dropdown = TaxRate::forBusinessDropdown($business_id, false);
        $taxes = $tax_dropdown['tax_rates'];

        $business_locations = BusinessLocation::forDropdown($business_id);
        $business_locations->prepend(__('lang_v1.none'), 'none');

        $lazada_category = $this->LazadaServiceProvider->getCategoryTree();
        $lazada_cat = $lazada_category->getData(true);

        return view('lazada.add_product')
            ->with(compact(

                'categories',
                'brands',
                'units',
                'taxes',
                'business_locations',
                'show_manufacturing_data',
                'lazada_cat',
                'action'
            ));
    }
    public function UpdateProduct(Request $request)
    {
        // return view('lazada.add_product');
        $action = 'update';
        $business_id = request()->session()->get('user.business_id');
        $selling_price_group_count = SellingPriceGroup::countSellingPriceGroups($business_id);
        $categories = Category::forDropdown($business_id, 'product');

        $brands = Brands::forDropdown($business_id);

        $units = Unit::forDropdown($business_id);

        $tax_dropdown = TaxRate::forBusinessDropdown($business_id, false);
        $taxes = $tax_dropdown['tax_rates'];

        $business_locations = BusinessLocation::forDropdown($business_id);
        $business_locations->prepend(__('lang_v1.none'), 'none');

        $lazada_category = $this->LazadaServiceProvider->getCategoryTree();
        $lazada_cat = $lazada_category->getData(true);

        return view('lazada.update_product')
            ->with(compact(

                'categories',
                'brands',
                'units',
                'taxes',
                'business_locations',
                'show_manufacturing_data',
                'lazada_cat',
                'action'
            ));
    }

    public function retail_product_list()
    {
        if (!auth()->user()->can('product.view') && !auth()->user()->can('product.create')) {
            abort(403, 'Unauthorized action.');
        }
        $business_id = request()->session()->get('user.business_id');

        $selling_price_group_count = SellingPriceGroup::countSellingPriceGroups($business_id);

        if (request()->ajax()) {
            $query = Product::with(['media'])
                ->leftJoin('brands', 'products.brand_id', '=', 'brands.id')
                ->join('units', 'products.unit_id', '=', 'units.id')
                ->leftJoin('categories as c1', 'products.category_id', '=', 'c1.id')
                ->leftJoin('categories as c2', 'products.sub_category_id', '=', 'c2.id')
                ->leftJoin('tax_rates', 'products.tax', '=', 'tax_rates.id')
                ->leftJoin('variations as v', 'v.product_id', '=', 'products.id')
                ->leftJoin('variation_group_prices as vgrp', 'vgrp.variation_id', '=', 'v.id')
                ->leftJoin('variation_location_details as vld', 'vld.variation_id', '=', 'v.id')
                ->where('products.business_id', $business_id)
                ->where('products.type', 'retail')
                ->where('vgrp.price_group_id', '=', 17);

            // ->where('parent_product','=', 'null');

            //Filter by location
            $location_id = request()->get('location_id', null);
            $action = request()->get('action', null);
            if (isset($action) && $action == 'add') {
                $query->where('products.lazada_product_id', '=', null);
            } else if (isset($action) && $action == 'update') {
                $query->where('products.lazada_product_id', '!=', null)->where('lazada_update_status', 2);
            } else if (isset($action) && $action == 'delete') {
                $query->where('products.lazada_product_id', '!=', null);
            }
            $permitted_locations = auth()->user()->permitted_locations();

            if (!empty($location_id) && $location_id != 'none') {
                $selling_price_group_id = BusinessLocation::where('id', $location_id)->select('selling_price_group_id')->first()->selling_price_group_id;

                $query->leftJoin('variation_group_prices as vgp', function ($join) use ($selling_price_group_id) {
                    $join->on('v.id', '=', 'vgp.variation_id')
                        ->where('vgp.price_group_id', '=', $selling_price_group_id);
                });

                if ($permitted_locations == 'all' || in_array($location_id, $permitted_locations)) {
                    $query->whereHas('product_locations', function ($query) use ($location_id) {
                        $query->where('product_locations.location_id', '=', $location_id);
                    });

                    $query->select(
                        'products.id',
                        'products.name as product',
                        'products.sequence as sequence',
                        'products.type',
                        'c1.name as category',
                        'c2.name as sub_category',
                        'units.actual_name as unit',
                        'brands.name as brand',
                        'tax_rates.name as tax',
                        'products.sku',
                        'products.image',
                        'products.enable_stock',
                        'products.is_inactive',
                        'products.not_for_selling',
                        'products.product_custom_field1',
                        'products.product_custom_field2',
                        'products.product_custom_field3',
                        'products.product_custom_field4',
                        'v.id as variation_id',
                        'vgrp.price_group_id',
                        'vgrp.price_inc_tax as lazada_price',

                        // SUM only for the specified location
                        DB::raw('SUM(CASE WHEN vld.location_id = ' . $location_id . ' THEN vld.qty_available ELSE 0 END) as current_stock'),
                        DB::raw('MAX(v.sell_price_inc_tax) as max_price'),
                        DB::raw('MIN(v.sell_price_inc_tax) as min_price'),
                        DB::raw('MAX(v.dpp_inc_tax) as max_purchase_price'),
                        DB::raw('MIN(v.dpp_inc_tax) as min_purchase_price')
                    );
                } else {
                    $query->doesntHave('product_locations');
                }
            } elseif ($location_id == 'none') {
                $query->doesntHave('product_locations');
            } else {
                if ($permitted_locations != 'all') {
                    $query->whereHas('product_locations', function ($query) use ($permitted_locations) {
                        $query->whereIn('product_locations.location_id', $permitted_locations);
                    });
                } else {
                    $query->with('product_locations');
                }

                $query->select(
                    'products.id',
                    'products.name as product',
                    'products.sequence as sequence',
                    'products.type',
                    'c1.name as category',
                    'c2.name as sub_category',
                    'units.actual_name as unit',
                    'brands.name as brand',
                    'tax_rates.name as tax',
                    'products.sku',
                    'products.image',
                    'products.enable_stock',
                    'products.is_inactive',
                    'products.not_for_selling',
                    'products.product_custom_field1',
                    'products.product_custom_field2',
                    'products.product_custom_field3',
                    'products.product_custom_field4',
                    'v.id as variation_id',
                    'vgrp.price_group_id',
                    'vgrp.price_inc_tax as lazada_price',
                    DB::raw('SUM(vld.qty_available) as current_stock'),
                    DB::raw('MAX(v.sell_price_inc_tax) as max_price'),
                    DB::raw('MIN(v.sell_price_inc_tax) as min_price'),
                    DB::raw('MAX(v.dpp_inc_tax) as max_purchase_price'),
                    DB::raw('MIN(v.dpp_inc_tax) as min_purchase_price')
                );
            }

            $products = $query->groupBy('products.id');

            $type = request()->get('type', null);
            if (!empty($type)) {
                $products->where('products.type', $type);
            }

            if (!empty($location_id) && $location_id != 'none') {
                $query->addSelect('vgp.price_inc_tax as selling_group_price');
            }

            $category_id = request()->get('category_id', null);
            if (!empty($category_id)) {
                $products->where('products.category_id', $category_id);
            }

            $brand_id = request()->get('brand_id', null);
            if (!empty($brand_id)) {
                $products->where('products.brand_id', $brand_id);
            }

            $unit_id = request()->get('unit_id', null);
            if (!empty($unit_id)) {
                $products->where('products.unit_id', $unit_id);
            }

            $tax_id = request()->get('tax_id', null);
            if (!empty($tax_id)) {
                $products->where('products.tax', $tax_id);
            }

            $active_state = request()->get('active_state', null);
            if ($active_state == 'active') {
                $products->Active();
            }
            if ($active_state == 'inactive') {
                $products->Inactive();
            }
            $not_for_selling = request()->get('not_for_selling', null);
            if ($not_for_selling == 'true') {
                $products->ProductNotForSales();
            }




            if (!empty(request()->get('repair_model_id'))) {
                $products->where('products.repair_model_id', request()->get('repair_model_id'));
            }

            return Datatables::of($products)
                ->addColumn('product_locations', function ($row) use ($location_id) {
                    if ($location_id == 'none' || empty($location_id)) {
                        // If 'none' is selected or no location is specified, show all locations as a comma-separated list
                        return $row->product_locations->pluck('name')->implode(', ');
                    } else {
                        // If a specific location is selected, show only that location
                        $location = $row->product_locations->firstWhere('id', $location_id);
                        return $location ? $location->name : '';
                    }
                })


                ->editColumn('product', function ($row) {
                    $product = $row->is_inactive == 1 ? $row->product . ' <span class="label bg-gray">' . __("lang_v1.inactive") . '</span>' : $row->product;

                    $product = $row->not_for_selling == 1 ? $product . ' <span class="label bg-gray">' . __("lang_v1.not_for_selling") .
                        '</span>' : $product;

                    return $product;
                })
                ->editColumn('sequence', function ($row) {
                    return $row->sequence;
                })
                ->editColumn('image', function ($row) use ($business_id, $location_id) {
                    return '<div style="display: flex;"><img src="' . $row->image_url . '" alt="Product image" class="product-thumbnail-small"></div>';
                })
                ->editColumn('type', '@lang("lang_v1." . $type)')
                ->addColumn('mass_delete', function ($row) {
                    return  '<input type="checkbox" class="row-select" value="' . $row->id . '">';
                })

                ->filterColumn('products.sku', function ($query, $keyword) {
                    $query->whereHas('variations', function ($q) use ($keyword) {
                        $q->where('sub_sku', 'like', "%{$keyword}%");
                    })
                        ->orWhere('products.sku', 'like', "%{$keyword}%");
                })

                ->rawColumns(['image', 'sequence', 'mass_delete', 'product', 'category'])
                ->make(true);
        }



        $categories = Category::forDropdown($business_id, 'product');

        $brands = Brands::forDropdown($business_id);

        $units = Unit::forDropdown($business_id);

        $tax_dropdown = TaxRate::forBusinessDropdown($business_id, false);
        $taxes = $tax_dropdown['tax_rates'];

        $business_locations = BusinessLocation::forDropdown($business_id);
        $business_locations->prepend(__('lang_v1.none'), 'none');

        if ($this->moduleUtil->isModuleInstalled('Manufacturing') && (auth()->user()->can('superadmin') || $this->moduleUtil->hasThePermissionInSubscription($business_id, 'manufacturing_module'))) {
            $show_manufacturing_data = true;
        } else {
            $show_manufacturing_data = false;
        }

        //list product screen filter from module
        $pos_module_data = $this->moduleUtil->getModuleData('get_filters_for_list_product_screen');

        $is_woocommerce = $this->moduleUtil->isModuleInstalled('Woocommerce');

        return view('lazada.product_list_table')
            ->with(compact(
                'rack_enabled',
                'categories',
                'brands',
                'units',
                'taxes',
                'business_locations',
                'show_manufacturing_data',
                'pos_module_data',
                'is_woocommerce'
            ));
    }


    public function UploadProductToLazada(Request $request)
    {
        // dd($request->all());exit;

        $token =  session()->get('lazada_acess_token');
        $action = $request->input('action');

        $primary_cat = '';
        if (!empty($request->input('leaf_cat_id'))) {
            $primary_cat = $request->input('leaf_cat_id');
        } else if (!empty($request->input('child_cat_id'))) {
            $primary_cat = $request->input('child_cat_id');
        } else {
            $primary_cat = $request->input('sub_cat_id');
        }

        if (!empty($request->input('selected_products'))) {
            $business_id = $request->session()->get('user.business_id');

            $selected_products = explode(',', $request->input('selected_products'));

            $products = Product::select('products.*', DB::raw('SUM(vld.qty_available) as current_stock'))
                ->whereIn('products.id', $selected_products)
                ->leftJoin('variations as v', 'v.product_id', '=', 'products.id')
                ->leftJoin('variation_location_details as vld', 'vld.variation_id', '=', 'v.id')
                ->where('products.business_id', $business_id)
                ->where('products.type', 'retail')
                ->groupBy('products.id')
                ->get();
            $new_atri_labels = $request->input('atri_label');
            $new_atribute = $request->input('atribute');
            $label = [];
            foreach ($new_atri_labels as $key => $val) {
                $label[$new_atri_labels[$key]] = $new_atribute[$key];
            }

            $new_option_lbl = $request->input('option_label');
            $new_option_atrbt = $request->input('option_atribute');
            $new_option = [];
            foreach ($new_option_lbl as $key => $val) {
                $new_option[$new_option_lbl[$key]] = $new_option_atrbt[$key];
            }

            if (isset($action) && $action == 'add') {
                $sucess = 0;
                foreach ($products as $product) {
                    $variation_id = Variation::where('product_id', $product->id)->pluck('id')->toArray();
                    $sell_grp = SellingPriceGroup::where('description', 'is_lazada')->first();
                    $price = VariationGroupPrice::where('price_group_id', $sell_grp->id)->whereIn('variation_id', $variation_id)->first();

                    $atribute = [
                        "name" => $product->name,
                        "description" => $product->product_description,
                        "model" => "test",
                        "waterproof" => "Waterproof",
                        "short_description" => "cm x 1efgtecm<br /><brfwefgtek",
                        "Hazmat" => "None",
                        "material" => "Leather",
                        "laptop_size" => "11 - 12 inches",
                        "delivery_option_sof" => "No",
                        "name_engravement" => "Yes",
                        "gift_wrapping" => "No",
                        "preorder_enable" => "No",
                        "preorder_days" => "25",
                    ];
                    $lazada_img = $this->LazadaServiceProvider->ImageUpload($product->image);
                    $cat_attribute = $this->LazadaServiceProvider->GetCategoryAttribute($primary_cat);



                    $arrayVar = [
                        "Request" => [
                            "Product" => [
                                "PrimaryCategory" => $primary_cat,
                                "Images" => ["Image" => [$lazada_img]],
                                "Attributes" => $merged_attributes = array_merge($atribute, $label, $new_option),
                                "Skus" => [
                                    "Sku" => [
                                        [
                                            "SellerSku" => $product->sku,
                                            "quantity" => $product->current_stock < 0 ? 0 : $product->current_stock,
                                            "price" => intval($price->price_inc_tax),
                                            // "special_price" => "33",
                                            // "special_from_date" => "2022-06-20 17:18:31",
                                            // "special_to_date" => "2025-03-15 17:18:31",
                                            "package_height" => "10",
                                            "package_length" => "10",
                                            "package_width" => "10",
                                            "package_weight" => "0.5",
                                            // "package_content" => "laptop bag",
                                            // "Images" => ["Image" => ["https://images.app.goo.gl/gp8XavUSrXzViyJ97"]]
                                            // "Images" => ["Image" => ["https://my-live-02.slatic.net/p/47b6cb07bd8f80aa3cc34b180b902f3e.jpg"]],
                                        ],
                                    ],
                                ],
                            ],
                        ],
                    ];

                    $payload = json_encode($arrayVar);

                    $response = $this->LazadaServiceProvider->createProduct($payload, $token);

                    $arrayData = json_decode($response, true);

                    if ($arrayData['code'] == 0) {
                        $sucess = 1;
                        $lazada_product_id = $arrayData['data']['item_id'];
                        $lazada_sku_id = $arrayData['data']['sku_list'][0]['sku_id'];

                        DB::beginTransaction();

                        $products = Product::where('id', $product->id)
                            ->update([
                                'lazada_product_id' => $lazada_product_id,
                                'lzd_sku_seller_id' => $lazada_sku_id,
                                'lazada_img_id' => $lazada_img ?? ''
                            ]);

                        DB::commit();
                    } else {
                        $sucess = 0;
                    }
                }
                if ($sucess == 1) {
                    $output = [
                        'success' => 1,
                        'msg' => __("lang_v1.updated_success")
                    ];
                } else {
                    $message = $arrayData['detail'][0]['message'] ?? $arrayData['message'];
                    $output = [
                        'success' => 0,
                        'msg' => __("messages.something_went_wrong")
                    ];
                }
                return  $output;
            } else if (isset($action) && $action == 'update') {

                $sucess = 0;
                foreach ($products as $product) {

                    $lazada_img = $this->LazadaServiceProvider->ImageUpload($product->image);

                    $variation_id = Variation::where('product_id', $product->id)->pluck('id')->toArray();
                    $sell_grp = SellingPriceGroup::where('description', 'is_lazada')->first();
                    $price = VariationGroupPrice::where('price_group_id', $sell_grp->id)->whereIn('variation_id', $variation_id)->first();

                    $arrayVar = [
                        "Request" => [
                            "Product" => [
                                "ItemId" => $product->lazada_product_id,
                                "PrimaryCategory" => $primary_cat,
                                "Images" => ["Image" => [$lazada_img]],
                                "Attributes" => [
                                    "name" => $product->name,
                                    "description" => $product->product_description,
                                    "brand" => "No Brand",
                                ],
                                "Skus" => [
                                    "Sku" => [
                                        [
                                            "SkuId" => $product->lzd_sku_seller_id,
                                            "SellerSku" => $product->sku,
                                            "quantity" => $product->current_stock < 0 ? 0 : $product->current_stock,
                                            "price" => intval($price->price_inc_tax),
                                            // "special_price" => "100",
                                            "package_height" => "10",
                                            "package_length" => "10",
                                            "package_width" => "10",
                                            "package_weight" => "0.5",

                                        ],
                                    ],
                                ],
                            ],
                        ],
                    ];

                    $payload = json_encode($arrayVar);

                    $response = $this->LazadaServiceProvider->UpdateProduct($payload, $token);
                    $arrayData = json_decode($response, true);

                    if ($arrayData['code'] == 0) {
                        $sucess = 1;
                        $lazada_product_id = $arrayData['data']['item_id'];
                        $lazada_sku_id = $arrayData['data']['sku_list'][0]['sku_id'];

                        DB::beginTransaction();

                        $products = Product::where('id', $product->id)
                            ->update(['lazada_update_status' => '1', 'lazada_img_id' => $lazada_img ?? '']);

                        DB::commit();
                    } else {
                        $sucess = 0;
                    }
                }
                if ($sucess == 1) {
                    $output = [
                        'success' => 1,
                        'msg' => __("lang_v1.updated_success")
                    ];
                } else {
                    $message = $arrayData['detail'][0]['message'] ?? $arrayData['message'];
                    $output = [
                        'success' => 0,
                        'msg' => __("messages.something_went_wrong")
                    ];
                }
                return  $output;
            } else if (isset($action) && $action == 'delete') {
                $skuIds = [];
                $sucess = 0;
                foreach ($products as $product) {
                    $lzd_sku_id =  $product->lzd_sku_seller_id;
                    $lzd_item_id =  $product->lazada_product_id;

                    $skuIds[] = "SkuId_" . $lzd_item_id . "_" . $lzd_sku_id;


                    $skuIdsJson = json_encode($skuIds);
                    $lzd_remove_pdct = $this->LazadaServiceProvider->removeProduct($skuIdsJson);

                    if (isset($lzd_remove_pdct['code']) && $lzd_remove_pdct['code'] == 0) {
                        $sucess = 1;
                        DB::beginTransaction();

                        $products = Product::where('id', $product->id)
                            ->update(['lazada_update_status' => '1', 'lazada_img_id' => Null, 'lzd_sku_seller_id' => Null, 'lazada_product_id' => Null]);

                        DB::commit();
                    } else {
                        $sucess = 0;
                    }
                }
                if ($sucess == 1) {
                    $output = [
                        'success' => 1,
                        'msg' => __("lang_v1.updated_success")
                    ];
                } else {
                    $output = [
                        'success' => 0,
                        'msg' => __("messages.something_went_wrong")
                    ];
                }
                return  $output;
            }
        }
    }

    public function DeleteProduct(Request $request)
    {

        $action = 'delete';
        $business_id = request()->session()->get('user.business_id');
        $selling_price_group_count = SellingPriceGroup::countSellingPriceGroups($business_id);
        $categories = Category::forDropdown($business_id, 'product');

        $brands = Brands::forDropdown($business_id);

        $units = Unit::forDropdown($business_id);

        $tax_dropdown = TaxRate::forBusinessDropdown($business_id, false);
        $taxes = $tax_dropdown['tax_rates'];

        $business_locations = BusinessLocation::forDropdown($business_id);
        $business_locations->prepend(__('lang_v1.none'), 'none');

        $lazada_category = $this->LazadaServiceProvider->getCategoryTree();
        $lazada_cat = $lazada_category->getData(true);

        return view('lazada.update_product')
            ->with(compact(

                'categories',
                'brands',
                'units',
                'taxes',
                'business_locations',
                'show_manufacturing_data',
                'lazada_cat',
                'action'
            ));
    }

    public function RemoveProductFromLazada(Request $request)
    {

        dd($request->all());
    }



    public function testdata()
    {
        $user_token = session()->get('lazada_acess_token');

        $data = $this->LazadaServiceProvider->getOrderdata($user_token);

        $order_ids = collect($data) ->whereNotIn('status', ['canceled','returned'])->pluck('order_id')->toArray();
       
        $order_items = $this->LazadaServiceProvider->getOrderItem($user_token, $order_ids);
        foreach ($order_items as $item) {
            $order_item_datas = $item['order_items'];
            foreach ($order_item_datas as $order_item_data) {
                $order_item_id = $order_item_data['order_item_id'];
                $order_item_count = $order_item_data['order_item_id'];
                $products = Product::where('lazada_product_id', $order_item_id)->first();

                // $location_ids = DB::table('business_locations')->where('business_id', $products->business_id)->pluck('location_id');
                $location_ids = DB::table('business_locations')->where('business_id', $products->business_id)->first();
                // if ($products) {
                //     $qty_chk = DB::table('variation_location_details')->where('product_id', $products->id)->whereIn('location_id', $location_ids)->where('qty_available
                //     ', '>', 0)->first();
                //     $calculate_qty =  $qty_chk->qty_available - 1;
                //     DB::table('variation_location_details')->where('product_id', $products->id)->where('id', $qty_chk->id)->update([
                //         'qty_available' => $calculate_qty,

                //     ]);
                // }
                $payment_timestamp = $order_item_data['payment_time']; // Millisecond timestamp
                $timestampInSeconds = $timestamp / 1000; // Convert milliseconds to seconds

                $date = Carbon::createFromTimestamp($timestampInSeconds)->format('Y-m-d H:i:s');
               
               $variation = Variation::where('product_id',$products->id)->first();
               $decrease_qty = $this->productUtil
               ->num_uf(1);


                    $transaction_data['product_type'] = 'retail';
                    $transaction_data['sell_line_note'] = null;
                    $transaction_data['product_id'] = $products->id;
                    $transaction_data['variation_id'] = $variation->id;
                    $transaction_data['location_id'] = $location_ids->location_id;
                    $transaction_data['enable_stock'] = '1';
                    $transaction_data['quantity'] = 1;
                    $transaction_data['product_unit_id'] = null;
                    $transaction_data['sub_unit_id'] = null;
                    $transaction_data['base_unit_multiplier'] = '1';
                    $transaction_data['unit_price'] =  $order_item_data['paid_price'];
                    $transaction_data['line_discount_amount'] = null;
                    $transaction_data['line_discount_type'] = null;
                    $transaction_data['item_tax'] = $order_item_data['tax_amount'];
                    $transaction_data['tax_id'] = null;
                    $transaction_data['unit_price_inc_tax'] = null;
                
                    $this->productUtil->decreaseProductQuantity(
                        $transaction_data['product_id'],
                        $transaction_data['variation_id'],
                        $transaction_data['location_id'],
                        $decrease_qty
                    );
            }
        }
        
    }

    public function getCatAttributes(Request $request)
    {
        $primary_cat = $request->input('child_cat_id');

        $cat_attribute = $this->LazadaServiceProvider->GetCategoryAttribute($primary_cat);

        return $cat_attribute;
    }
    public function triggerCronJob()
    {
        // Run the artisan command manually
        Artisan::call('fetch:lazada-data');

        return response()->json([
            'message' => 'Cron job triggered successfully.'
        ]);
    }
}
