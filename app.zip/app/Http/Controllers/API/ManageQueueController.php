<?php

namespace App\Http\Controllers\API;

use Illuminate\Http\Request;
use Illuminate\Http\Response;
use App\Http\Controllers\Controller;
use App\PosResTables;
use App\Queue\ManageQueue;
use App\DisplayImages;
use App\Queue\QueuePaxCategories;
use App\Queue\QueueTable;
use App\Queue\QueueSchema;
use App\Queue\QueueSettings;
use Illuminate\Support\Facades\DB;
use App\Utils\Util;
use App\Http\Requests\QueueRegisterRequest;
use App\Http\Requests\QueueCallRequest;
use App\Http\Requests\QueueSkipRequest;
use App\Http\Requests\DisplayImagesRequest;
use App\Http\Requests\AssignQueueTableRequest;
use App\Http\Requests\ReQueueRequest;
use App\Http\Requests\MissedQueueRequest;
use App\Http\Requests\CurrentQueueRequest;
use App\Http\Requests\MissedQueueListRequest;
use App\Http\Requests\QueueListRequest;
use App\Transaction;
use App\User;
use App\TransactionSellLine;

class ManageQueueController extends Controller
{
    /**
     * All Utils instance.
     *
     */
    protected $util;

    /**
     * Constructor
     *
     * @param Util $util
     * @return void
     */
    public function __construct(Util $util)
    {
        $this->util = $util;
    }

    public function register(QueueRegisterRequest $request) {
        $req_data = $request->only('business_id', 'location_id', 'country_code', 'mobile_number', 'first_name', 'last_name', 'queue_pax', 'salutation');

        try {
            DB::beginTransaction();
            $query = "SELECT qpc.description as pax_range, qpc.start_from as start_from, qpc.end_to as end_to,
            qs.prefix, qs.start, qs.end, qs.estimated_wait_time,
            qs.description, qs.id as queue_schema_id
            FROM queue_schemas qs 
            JOIN queue_pax_categories qpc ON qs.pax_category_id = qpc.id 
            WHERE qs.business_id = " . $req_data['business_id'] . "
            AND qs.location_id = " . $req_data['location_id'] . "
            AND qs.deleted_at IS NULL 
            AND qpc.business_id = " . $req_data['business_id'] . "
            AND qpc.deleted_at IS NULL 
            AND " . $req_data['queue_pax'] . " BETWEEN qpc.start_from AND qpc.end_to 
            ORDER BY qs.id LIMIT 1;";

            $queueSchema = DB::select($query);

            if( !empty($queueSchema) && count(($queueSchema)) ) {

                $queue_schema_id = (isset($queueSchema) && !empty($queueSchema)) ? $queueSchema[0]->queue_schema_id : "";

                // Fetch Last Member in a Queue
                $lastMemeberInQueue = ManageQueue::where('business_id', $req_data['business_id'])
                                                ->where('location_id', $req_data['location_id'])
                                                ->where('queue_schema_id', $queue_schema_id)
                                                ->orderBy('id', 'DESC')
                                                ->first();

                $req_data['queue_schema_id'] = $queue_schema_id;

                if( (isset($lastMemeberInQueue) && !empty($lastMemeberInQueue)) && $lastMemeberInQueue['queue_number'] == $queueSchema[0]->end ) {
                    $req_data['queue_number'] = (isset($lastMemeberInQueue) && !empty($lastMemeberInQueue)) ? $queueSchema[0]->start : 1;
                } else {
                    $req_data['queue_number'] = (isset($lastMemeberInQueue) && !empty($lastMemeberInQueue)) ? $lastMemeberInQueue['queue_number'] + 1 : 1;
                }
                $req_data['queue_order'] = 1;
                $queue_token = $this->util->random_strings(16);
                $req_data['queue_token'] = $queue_token;
                ManageQueue::create($req_data);

                $queueDetails = ManageQueue::where('manage_queue.business_id', $req_data['business_id'])
                                        ->where('manage_queue.location_id', $req_data['location_id'])
                                        ->where('manage_queue.queue_token', $queue_token)
                                        ->join('queue_schemas AS qc', 'manage_queue..queue_schema_id', '=', 'qc.id')
                                        ->join('business AS B', 'manage_queue.business_id', '=', 'B.id')
                                        ->join('business_locations AS BL', 'manage_queue.location_id', '=', 'BL.id')
                                        ->select('qc.id as qc_id', 'qc.prefix', 'qc.start', 'qc.end', 'qc.estimated_wait_time', 'qc.description', 'manage_queue.queue_number', 
                                        'manage_queue.queue_pax', 'manage_queue.mobile_number', 'manage_queue.first_name', 'manage_queue.salutation', 
                                        'manage_queue.last_name', 'manage_queue.queue_order', 'manage_queue.status', 'manage_queue.sms_status', 
                                        'manage_queue.country_code', 'manage_queue.queue_token', 
                                        'B.name as business_name', 
                                        'BL.name as location_name', 'BL.city as city', 'BL.state as state', 'BL.country as country')
                                        ->first();

                $memeberQueueDetails = [];
                if( isset($queueDetails) && !empty($queueDetails) ) {

                    $firstMemberInAQueue = DB::select("SELECT CONCAT('" . $queueDetails->prefix . "', '', queue_number)  AS queue_number, queue_number as qnumber
                        FROM manage_queue 
                        WHERE business_id = " . $req_data['business_id'] . "
                        AND location_id = " . $req_data['location_id'] . "
                        AND queue_schema_id = " . $queueDetails->qc_id . "
                        AND deleted_at IS NULL 
                        AND status = 'assigned'
                        ORDER BY updated_at DESC LIMIT 1");
                    $current_queue_number = (isset($firstMemberInAQueue) && $firstMemberInAQueue && count($firstMemberInAQueue)) ? $firstMemberInAQueue[0]->queue_number : "no one";
                        
                    $memeberQueueDetails['prefix'] = $queueDetails->prefix;
                    $memeberQueueDetails['start'] = $queueDetails->start;
                    $memeberQueueDetails['end'] = $queueDetails->end;
                    $memeberQueueDetails['estimated_wait_time'] = $queueDetails->estimated_wait_time;
                    $memeberQueueDetails['description'] = $queueDetails->description;
                    $memeberQueueDetails['queue_number'] = $queueDetails->queue_number;
                    $memeberQueueDetails['queue_pax'] = $queueDetails->queue_pax;
                    $memeberQueueDetails['mobile_number'] = $queueDetails->mobile_number;
                    $memeberQueueDetails['first_name'] = $queueDetails->first_name;
                    $memeberQueueDetails['last_name'] = $queueDetails->last_name;
                    $memeberQueueDetails['country_code'] = $queueDetails->country_code;
                    $memeberQueueDetails['queue_order'] = $queueDetails->queue_order;
                    $memeberQueueDetails['status'] = $queueDetails->status;
                    $memeberQueueDetails['sms_status'] = $queueDetails->sms_status;
                    $memeberQueueDetails['queue_token'] = $queueDetails->queue_token;
                    $memeberQueueDetails['queue'] = $queueDetails->prefix . "" . $queueDetails->queue_number;
                    $memeberQueueDetails['salutation'] = $queueDetails->salutation;

                    $addressParts = [];
                    if($queueDetails->city)
                        $addressParts[] = $queueDetails->city;
                    if($queueDetails->state)
                        $addressParts[] = $queueDetails->state;
                    if($queueDetails->country)
                        $addressParts[] = $queueDetails->country;
                        
                    $store_address = implode(", ", $addressParts);

                    // Send a message on WhatsApp START
                    if(config('constants.awsS3Env') == 'dev') {
                        if( $queueDetails->mobile_number == '99999999') { // Ashish
                            $to_phone = "+919893038093";
                        } elseif( $queueDetails->mobile_number == '99999998' ) { // Ayushi
                            $to_phone = "+918959482829";
                        } elseif( $queueDetails->mobile_number == '99999997' ) { // Raj Kumar
                            $to_phone = "+918962720727";
                        } elseif( $queueDetails->mobile_number == '99999996' ) { // FCP
                            $to_phone = "+919754178790";
                        } elseif( $queueDetails->country_code == '+65' ) { // +65
                            $to_phone = $queueDetails->country_code . "" . $queueDetails->mobile_number;
                        }
                    } elseif(config('constants.awsS3Env') == 'stage') {
                        if( $queueDetails->mobile_number == '99999999') { // Ashish
                            $to_phone = "+919893038093";
                        } elseif( $queueDetails->mobile_number == '99999998' ) { // Ayushi
                            $to_phone = "+918959482829";
                        } elseif( $queueDetails->mobile_number == '99999997' ) { // Raj Kumar
                            $to_phone = "+918962720727";
                        } elseif( $queueDetails->mobile_number == '99999996' ) { // FCP
                            $to_phone = "+919754178790";
                        } elseif( $queueDetails->country_code == '+65' ) { // +65
                            $to_phone = $queueDetails->country_code . "" . $queueDetails->mobile_number;
                        }
                    } elseif(config('constants.awsS3Env') == 'prod') {
                        if( $queueDetails->mobile_number == '99999999') { // Ashish
                            $to_phone = "+919893038093";
                        } elseif( $queueDetails->mobile_number == '99999998' ) { // Ayushi
                            $to_phone = "+918959482829";
                        } elseif( $queueDetails->mobile_number == '99999997' ) { // Raj Kumar
                            $to_phone = "+918962720727";
                        } elseif( $queueDetails->mobile_number == '99999996' ) { // FCP
                            $to_phone = "+919754178790";
                        } elseif( $queueDetails->country_code == '+65' ) { // +65
                            $to_phone = $queueDetails->country_code . "" . $queueDetails->mobile_number;
                        }
                    } else {
                        $to_phone = $queueDetails->country_code . "" . $queueDetails->mobile_number;
                    }

                    if( $to_phone ) {
                        $parameters = [
                            ['type' => 'text', 'text' => $queueDetails->first_name . " " . $queueDetails->last_name], // Name
                            ['type' => 'text', 'text' => $queueDetails->prefix . "" . $queueDetails->queue_number], // Queue Number
                            ['type' => 'text', 'text' => $queueDetails->queue_pax], // PAX
                            ['type' => 'text', 'text' => $queueDetails->location_name], // Store Name
                            ['type' => 'text', 'text' => $store_address], // Store Address
                            ['type' => 'text', 'text' => $current_queue_number] // Current Queue Number
                        ];

                        $components = [];
                        $components[0] = [
                            "type" => "body",
                            "parameters" => $parameters
                        ];
                        $components[1] = [
                            "type" => "button",
                            "sub_type" => "url",
                            "index" => 0,
                            "parameters" => [['type' => 'text', 'text' => "?location_id=" . $req_data['location_id'] . "&business_id=" . $req_data['business_id'] . "&queue_token=" . $queueDetails->queue_token]]
                        ];
                        // /queue-detail

                        $this->util->sendWhatsAppMessage($to_phone, config('constants.WA_QUEUE_REGISTRATION_TEMPLATE'), $components);
                    }
                    // Send a message on WhatsApp END
                }

                DB::commit();

                return[
                    'success' => true,
                    'data' => $memeberQueueDetails,
                    'message' => "You are registered in a queue successfully"
                ];
            } else {
                return response()->json([
                    'success' => false,
                    'errorMessage' => "Can not serve for PAX size " . $req_data['queue_pax'] . " at this moment."
                ], 200);
            }
        } catch (\Exception $e) {
            DB::rollBack();

            \Log::emergency("File:" . $e->getFile(). "Line:" . $e->getLine(). "Message:" . $e->getMessage());
                $msg = __('messages.something_went_wrong');
            
            $output = [
                'success' => false,
                'errorMessage' => $msg,
                'message' => $msg
            ];

            return $output;
        }
    }

    public function fetchDetails(Request $request) {
        $req_data = $request->only('business_id', 'location_id', 'queue_token');

        $queueDetails = ManageQueue::where('manage_queue.business_id', $req_data['business_id'])
                                    ->where('manage_queue.location_id', $req_data['location_id'])
                                    ->where('manage_queue.queue_token', $req_data['queue_token'])
                                    ->whereNull('manage_queue.deleted_at')
                                    ->leftJoin('queue_schemas AS qc', 'manage_queue.queue_schema_id', '=', 'qc.id')
                                    ->leftJoin('queue_table AS qt', 'manage_queue.id', '=', 'qt.manage_queue_id')
                                    ->leftJoin('res_tables AS rt', 'qt.res_table_id', '=', 'rt.id')
                                    ->select('qc.prefix', 'qc.start', 'qc.end', 'qc.estimated_wait_time', 'qc.description', 
                                    'manage_queue.queue_number', 'manage_queue.queue_pax', 'manage_queue.mobile_number', 
                                    'manage_queue.first_name', 'manage_queue.salutation', 'manage_queue.last_name', 
                                    'manage_queue.queue_order', 'manage_queue.status', 'manage_queue.sms_status', 
                                    'manage_queue.country_code', 'manage_queue.queue_token', 'manage_queue.id', 
                                    'rt.id as table_id', 'rt.name as table_name', 'rt.description as table_description')
                                    ->first();

        $memeberQueueDetails = [];
        if( isset($queueDetails) && !empty($queueDetails) ) {
            $memeberQueueDetails['prefix'] = $queueDetails->prefix;
            $memeberQueueDetails['start'] = $queueDetails->start;
            $memeberQueueDetails['end'] = $queueDetails->end;
            $memeberQueueDetails['estimated_wait_time'] = $queueDetails->estimated_wait_time;
            $memeberQueueDetails['description'] = $queueDetails->description;
            $memeberQueueDetails['queue_number'] = $queueDetails->queue_number;
            $memeberQueueDetails['queue_pax'] = $queueDetails->queue_pax;
            $memeberQueueDetails['mobile_number'] = $queueDetails->mobile_number;
            $memeberQueueDetails['first_name'] = $queueDetails->first_name;
            $memeberQueueDetails['last_name'] = $queueDetails->last_name;
            $memeberQueueDetails['country_code'] = $queueDetails->country_code;
            $memeberQueueDetails['queue_order'] = $queueDetails->queue_order;
            $memeberQueueDetails['status'] = $queueDetails->status;
            $memeberQueueDetails['sms_status'] = $queueDetails->sms_status;
            $memeberQueueDetails['queue_token'] = $queueDetails->queue_token;
            $memeberQueueDetails['queue'] = $queueDetails->prefix . "" . $queueDetails->queue_number;
            $memeberQueueDetails['salutation'] = $queueDetails->salutation;
            $memeberQueueDetails['queue_id'] = $queueDetails->id;

            if( $queueDetails->table_id ) 
                $memeberQueueDetails['table_id'] = $queueDetails->table_id;
            if( $queueDetails->table_name ) 
                $memeberQueueDetails['table_name'] = $queueDetails->table_name;
            if( $queueDetails->table_description ) 
                $memeberQueueDetails['table_description'] = $queueDetails->table_description;
        }
       
        return[
            'success' => true,
            'data' => $memeberQueueDetails,
            'message' => "Queue details"
        ];
    }

    public function displayImages(DisplayImagesRequest $request) {
        $req_data = $request->only('business_id', 'location_id', 'image_type');

        $displayImages = DisplayImages::where('display_images.business_id', $req_data['business_id'])
                                ->where('display_images.location_id', $req_data['location_id'])
                                ->where('display_images.status', 'Active')
                                ->whereRaw("FIND_IN_SET(?, image_type)", [$req_data['image_type']])
                                ->whereNull('display_images.deleted_at')
                                ->join('business_locations AS BL', 'display_images.location_id', '=', 'BL.id')
                                ->select(['BL.name as location', 'display_images.image', 'display_images.id', 'BL.website', 'display_images.location_id'
                                , 'display_images.image_type' , 'display_images.status', 'display_images.orientation'])
                                ->get();
        return[
            'success' => true,
            'data' => $displayImages,
            'message' => "Display Images"
        ];
    }

    public function fetchCurrentQueue(CurrentQueueRequest $request) {
        $input = $request;
        try {
            $current_queue = [];
            $average_wating_time = 0;
            $queueSchemas = QueueSchema::where('queue_schemas.business_id', $input['business_id'])
                        ->where('queue_schemas.location_id', $input['location_id'])
                        ->whereNull('queue_schemas.deleted_at')
                        ->join('business_locations AS BL', 'queue_schemas.location_id', '=', 'BL.id')
                        ->join('queue_pax_categories AS PC', 'queue_schemas.pax_category_id', '=', 'PC.id')
                        ->select(['BL.name as location', 'PC.description as pax_range', 'PC.start_from as pax_range_start_from', 'PC.end_to as pax_range_end_to',
                            'queue_schemas.prefix', 'queue_schemas.start', 'queue_schemas.end',
                            'queue_schemas.estimated_wait_time', 'queue_schemas.description', 'queue_schemas.id'])
                        ->get();
            
            if($queueSchemas && !empty($queueSchemas)) {
                $total_queues = count($queueSchemas);
                $total_waiting_time = 0;

                $queue_wise_data = [];                
                foreach ($queueSchemas as $key => $queueSchema) {
                    $query ="SELECT COUNT(*) AS total_queue_tokens 
                        FROM manage_queue
                        WHERE business_id = " . $input['business_id'] . " 
                        AND deleted_at IS NULL 
                        AND location_id = " . $input['location_id'] . "
                        AND status IN ('pending', 'called', 'requeue') 
                        AND queue_schema_id = " . $queueSchema['id'] . "";
                    $membersInAQueue = DB::select($query);
                    if( $membersInAQueue && count($membersInAQueue) ) {
                        $total_waiting_time += ( $membersInAQueue[0]->total_queue_tokens ) * $queueSchema['estimated_wait_time'];

                        $temp_queue_wise_data = [
                            'prefix' => $queueSchema['prefix'],
                            "totalQueueTokens" => $membersInAQueue[0]->total_queue_tokens,
                            "estimatedWaitTime" => $queueSchema['estimated_wait_time']
                        ];
                    }

                    $firstMemberInAQueue = DB::select("SELECT queue_pax, mobile_number, first_name, last_name, salutation, queue_order, status, sms_status, queue_token, country_code,
                    CONCAT('" . $queueSchema['prefix'] . "', '', queue_number)  AS queue_number, queue_number as qnumber,
                    queue_number * " . $queueSchema['estimated_wait_time'] . "  AS estimated_wait_time 
                    FROM manage_queue 
                    WHERE business_id = " . $input['business_id'] . "
                    AND location_id = " . $input['location_id'] . "
                    AND queue_schema_id = " . $queueSchema['id'] . "
                    AND deleted_at IS NULL 
                    AND status = 'assigned'
                    ORDER BY updated_at DESC LIMIT 1");

                    $temp = [
                        'id' => $queueSchema['id'],
                        'location' => $queueSchema['location'],
                        'pax_range' => $queueSchema['pax_range'],
                        'pax_range_start_from' => $queueSchema['pax_range_start_from'],
                        'pax_range_end_to' => $queueSchema['pax_range_end_to'],
                        'prefix' => $queueSchema['prefix'],
                        'start' => $queueSchema['start'],
                        'end' => $queueSchema['end'],
                        'estimated_wait_time' => $queueSchema['estimated_wait_time'],
                        'description' => $queueSchema['description'],
                        'registration' => (isset($firstMemberInAQueue) && $firstMemberInAQueue && count($firstMemberInAQueue)) ? $firstMemberInAQueue[0] : null
                    ];
                    $current_queue[] = $temp;

                    $queue_wise_data[] = $temp_queue_wise_data;
                }

                $average_wating_time = $total_waiting_time / $total_queues;
            }
            return [
                "currentQueue" => $current_queue,
                "averageWatingTime" => round((number_format((float)$average_wating_time, 2, '.', ''))/5) * 5,
                "totalWaitingTime" => $total_waiting_time,
                "totalQueues" => $total_queues,
                "queueWiseData" => $queue_wise_data
            ];
        } catch (\Exception $e) {
            \Log::emergency("File:" . $e->getFile(). "Line:" . $e->getLine(). "Message:" . $e->getMessage());
            $msg = __('messages.something_went_wrong');

            $output = [
                'errorMessage' => $msg
            ];
            return $output;
        }
    }
  
    public function fetchQueueList(QueueListRequest $request) {
        $input = $request;
        if(isset($input['token'])) {
            $result = User::checkUserToken($input['token'], $input['user_id']);
            if($result) {
                try {
                    $queueList = [];
                    $queueSchemas = QueueSchema::where('queue_schemas.business_id', $input['business_id'])
                    ->where('queue_schemas.location_id', $input['location_id'])
                    ->whereNull('queue_schemas.deleted_at')
                    ->join('business_locations AS BL', 'queue_schemas.location_id', '=', 'BL.id')
                    ->join('queue_pax_categories AS PC', 'queue_schemas.pax_category_id', '=', 'PC.id')
                    ->select(['BL.name as location', 'PC.description as pax_range', 'PC.start_from as pax_range_start_from', 'PC.end_to as pax_range_end_to',
                        'queue_schemas.prefix', 'queue_schemas.start', 'queue_schemas.end',
                        'queue_schemas.estimated_wait_time', 'queue_schemas.description', 'queue_schemas.id'])
                    ->get();
                    foreach ($queueSchemas as $key => $queueSchema) {
                        $membersInAQueue = DB::select("SELECT ROW_NUMBER() OVER (ORDER BY id) AS row_num, queue_pax, mobile_number, first_name, salutation, last_name, queue_order, status, sms_status, queue_token, country_code,
                        CONCAT('" . $queueSchema['prefix'] . "', '', queue_number)  AS queue_number, queue_number as qnumber, 
                        ( ROW_NUMBER() OVER (ORDER BY id) * " . $queueSchema['estimated_wait_time'] . ") AS estimated_wait_time, id as queue_id,
                        created_at, updated_at
                        FROM manage_queue 
                        WHERE business_id = " . $input['business_id'] . " 
                        AND location_id = " . $input['location_id'] . " 
                        AND status IN ('pending', 'called', 'requeue')
                        AND deleted_at IS NULL 
                        AND queue_schema_id = " . $queueSchema['id'] . "");
                        
                        $temp = [
                            'id' => $queueSchema['id'],
                            'location' => $queueSchema['location'],
                            'pax_range' => $queueSchema['pax_range'],
                            'pax_range_start_from' => $queueSchema['pax_range_start_from'],
                            'pax_range_end_to' => $queueSchema['pax_range_end_to'],
                            'prefix' => $queueSchema['prefix'],
                            'start' => $queueSchema['start'],
                            'end' => $queueSchema['end'],
                            'estimated_wait_time' => $queueSchema['estimated_wait_time'],
                            'description' => $queueSchema['description'],
                            'registrations' => $membersInAQueue
                        ];
                        $queueList[] = $temp;
                    }
                    return $queueList;
                } catch (\Exception $e) {
                    \Log::emergency("File:" . $e->getFile(). "Line:" . $e->getLine(). "Message:" . $e->getMessage());
                    $msg = __('messages.something_went_wrong');

                    $output = [
                        'errorMessage' => $msg
                    ];
                    return $output;
                }
            } else {
                return["errorMessage"=>'Invalid token.'];
            }
        } else {
            return["errorMessage"=>'Invalid token.'];
        }
    }

    public function call(QueueCallRequest $request) {
        $req_data = $request;
        if(isset($req_data['token'])) {
            $result = User::checkUserToken($req_data['token'], $req_data['user_id']);
            if($result) {
                try {
                    DB::beginTransaction();

                    ManageQueue::where('business_id', $req_data['business_id'])
                                        ->where('location_id', $req_data['location_id'])
                                        ->whereIn('queue_token', $req_data['queue_tokens'])
                                        ->update(['status' => 'called']);

                    DB::commit();

                    return[
                        'success' => true,
                        'message' => "Queue called"
                    ];
                } catch (\Exception $e) 
                {
                    DB::rollBack();
        
                    \Log::emergency("File:" . $e->getFile(). "Line:" . $e->getLine(). "Message:" . $e->getMessage());
                        $msg = __('messages.something_went_wrong');
                    
                    $output = [
                        'success' => false,
                        'errorMessage' => $msg,
                        'message' => $msg
                    ];
        
                    return $output;
                }
            } else {
                return["errorMessage"=>'Invalid token.'];
            }
        } else {
            return["errorMessage"=>'Invalid token.'];
        }
    }

    public function skip(QueueSkipRequest $request) {
        $req_data = $request;
        if(isset($req_data['token'])) {
            $result = User::checkUserToken($req_data['token'], $req_data['user_id']);
            if($result) {
                try {
                    $queueSetting = QueueSettings::where('business_id', $req_data['business_id'])
                                                ->where('location_id', $req_data['location_id'])
                                                ->first();

                    $skip_queue_limit = 0;
                    if( $queueSetting && !empty($queueSetting) ) {
                        $skip_queue_limit = $queueSetting['skip_queue_limit'];
                    }
                                                
                    if( $skip_queue_limit > 0 && $skip_queue_limit < count($req_data['queue_tokens']) ) {
                        return response()->json([
                            'success' => false,
                            'errorMessage' => "Only " . $skip_queue_limit . " tokens can be skipped at a time."
                        ], 200);
                    } else {

                        DB::beginTransaction();

                        ManageQueue::where('business_id', $req_data['business_id'])
                                            ->where('location_id', $req_data['location_id'])
                                            ->whereIn('queue_token', $req_data['queue_tokens'])
                                            ->update(['status' => 'missed']);

                        DB::select("CALL deleteMissedQueueTokens(" . $req_data['business_id'] . ", " . $req_data['location_id'] . ", " . $skip_queue_limit . ")");

                        DB::commit();

                        return[
                            'success' => true,
                            'message' => "Queue skipped"
                        ];
                    }
                } catch (\Exception $e) 
                {
                    DB::rollBack();
        
                    \Log::emergency("File:" . $e->getFile(). "Line:" . $e->getLine(). "Message:" . $e->getMessage());
                        $msg = __('messages.something_went_wrong');
                    
                    $output = [
                        'success' => false,
                        'errorMessage' => $msg,
                        'message' => $msg
                    ];
        
                    return $output;
                }
            } else {
                return["errorMessage"=>'Invalid token.'];
            }
        } else {
            return["errorMessage"=>'Invalid token.'];
        }
    }

    public function assignQueueToTable(AssignQueueTableRequest $request) {
        $req_data = $request;

        if( count($req_data["queue_ids"]) !== count($req_data["table_ids"]) ) {
            return response()->json([
                'success' => false,
                'errorMessage' => 'Length of Queue and Table IDs array must be same'
            ], 200);
        } else {
            if(isset($req_data['token'])) {
                $result = User::checkUserToken($req_data['token'], $req_data['user_id']);
                if($result) {
                    try {
                        DB::beginTransaction();
                        
                        if( isset( $req_data["queue_ids"] ) && $req_data["queue_ids"] && isset( $req_data["table_ids"] ) && $req_data["table_ids"] ) {
                            $queueTableRequests = [];
                            foreach ($req_data["queue_ids"] as $key => $queue_id) {

                                // Assign a queue to res table
                                $temp = [
                                    "business_id" => $req_data['business_id'],
                                    "location_id" => $req_data['location_id'],
                                    "manage_queue_id" => $queue_id,
                                    "res_table_id" => $req_data["table_ids"][$key],
                                    "commission_user_id" => $req_data["commission_user_ids"][$key],
                                    'created_by' => $req_data['user_id'],
                                    'is_occupied' => 1
                                ];
                                $queueTableRequests[] = $temp;
                            }
                            QueueTable::insert($queueTableRequests);

                            // Fetch POS Res Tables and Update
                            $transaction_id = null;
                            $posResTables = PosResTables::whereIn('manage_queue_id', $req_data["queue_ids"])->get();
                            if( !empty($posResTables) && count($posResTables) ) {
                                foreach ($posResTables as $key => $posResTable) {
                                    $index = array_search($posResTable->manage_queue_id, $req_data["queue_ids"]);
                                    $transaction_id = $posResTable->transaction_id;

                                    PosResTables::where('manage_queue_id', $posResTable->manage_queue_id)
                                                ->where('transaction_id', $transaction_id)
                                                ->update(['res_table_id' => $req_data["table_ids"][$index]]);

                                    Transaction::where('id', $transaction_id)
                                                ->update(['status' => 'draft']);

                                    TransactionSellLine::where('transaction_id', $transaction_id)
                                                        ->update(['user_id' => $req_data["commission_user_ids"][$index]]);
                                }
                            }

                            // Update queue status to "assigned"
                            ManageQueue::where('business_id', $req_data['business_id'])
                            ->where('location_id', $req_data['location_id'])
                            ->whereIn('id', $req_data["queue_ids"])
                            ->update(['status' => 'assigned']);

                            // Send a message on WhatsApp START
                            foreach ($req_data["queue_ids"] as $index => $queue_id) {
                                $query = "SELECT mq.first_name, mq.last_name, mq.mobile_number, mq.country_code, mq.queue_token, qs.prefix, mq.queue_number, mq.status, b.name, bl.name as location_name, 
                                    rt.name as table_name, mq.queue_pax, bl.city as city, bl.state as state, bl.country as country
                                    FROM queue_table qt 
                                    JOIN business b ON qt.business_id = b.id 
                                    JOIN business_locations bl ON qt.location_id = bl.id 
                                    JOIN manage_queue mq ON qt.manage_queue_id = mq.id 
                                    JOIN res_tables rt ON qt.res_table_id = rt.id 
                                    JOIN queue_schemas qs ON mq.queue_schema_id = qs.id
                                    WHERE qt.business_id = " . $req_data['business_id'] . " 
                                    AND qt.location_id = " . $req_data['location_id'] . " 
                                    AND qt.res_table_id = " . $req_data["table_ids"][$index] . " 
                                    AND qt.manage_queue_id = " . $queue_id . " 
                                    LIMIT 1;";
                                $memberDetail = DB::select($query);
                                if( isset($memberDetail) && $memberDetail && count($memberDetail) == 1 ) {
                                    $addressParts = [];
                                    if($memberDetail[0]->city)
                                        $addressParts[] = $memberDetail[0]->city;
                                    if($memberDetail[0]->state)
                                        $addressParts[] = $memberDetail[0]->state;
                                    if($memberDetail[0]->country)
                                        $addressParts[] = $memberDetail[0]->country;

                                    $store_address = implode(", ", $addressParts);

                                    $to_phone = $memberDetail[0]->country_code . "" . $memberDetail[0]->mobile_number;

                                    // Send a message on WhatsApp START
                                    if(config('constants.awsS3Env') == 'dev') {
                                        if( $memberDetail[0]->mobile_number == '99999999') { // Ashish
                                            $to_phone = "+919893038093";
                                        } elseif( $memberDetail[0]->mobile_number == '99999998' ) { // Ayushi
                                            $to_phone = "+918959482829";
                                        } elseif( $memberDetail[0]->mobile_number == '99999997' ) { // Raj Kumar
                                            $to_phone = "+918962720727";
                                        } elseif( $memberDetail[0]->mobile_number == '99999996' ) { // FCP
                                            $to_phone = "+919754178790";
                                        }  elseif( $memberDetail[0]->country_code == '+65' ) { // +65
                                            $to_phone = $memberDetail[0]->country_code . "" . $memberDetail[0]->mobile_number;
                                        }
                                    } elseif(config('constants.awsS3Env') == 'stage') {
                                        if( $memberDetail[0]->mobile_number == '99999999') { // Ashish
                                            $to_phone = "+919893038093";
                                        } elseif( $memberDetail[0]->mobile_number == '99999998' ) { // Ayushi
                                            $to_phone = "+918959482829";
                                        } elseif( $memberDetail[0]->mobile_number == '99999997' ) { // Raj Kumar
                                            $to_phone = "+918962720727";
                                        } elseif( $memberDetail[0]->mobile_number == '99999996' ) { // FCP
                                            $to_phone = "+919754178790";
                                        }  elseif( $memberDetail[0]->country_code == '+65' ) { // +65
                                            $to_phone = $memberDetail[0]->country_code . "" . $memberDetail[0]->mobile_number;
                                        }
                                    } elseif(config('constants.awsS3Env') == 'prod') {
                                        if( $memberDetail[0]->mobile_number == '99999999') { // Ashish
                                            $to_phone = "+919893038093";
                                        } elseif( $memberDetail[0]->mobile_number == '99999998' ) { // Ayushi
                                            $to_phone = "+918959482829";
                                        } elseif( $memberDetail[0]->mobile_number == '99999997' ) { // Raj Kumar
                                            $to_phone = "+918962720727";
                                        } elseif( $memberDetail[0]->mobile_number == '99999996' ) { // FCP
                                            $to_phone = "+919754178790";
                                        }  elseif( $memberDetail[0]->country_code == '+65' ) { // +65
                                            $to_phone = $memberDetail[0]->country_code . "" . $memberDetail[0]->mobile_number;
                                        }
                                    } else {
                                        $to_phone = $memberDetail[0]->country_code . "" . $memberDetail[0]->mobile_number;
                                    }
                                    
                                    if( $to_phone ) {
                                        $parameters = [
                                            ['type' => 'text', 'text' => $memberDetail[0]->first_name . " " . $memberDetail[0]->last_name], // Name
                                            ['type' => 'text', 'text' => $memberDetail[0]->prefix . "" . $memberDetail[0]->queue_number], // Queue Number
                                            ['type' => 'text', 'text' => $memberDetail[0]->queue_pax], // PAX
                                            ['type' => 'text', 'text' => $memberDetail[0]->location_name], // Store Name
                                            ['type' => 'text', 'text' => $store_address], // Store Address
                                            ['type' => 'text', 'text' => $memberDetail[0]->table_name] // Table Name
                                        ];

                                        $components = [];
                                        $components[0] = [
                                            "type" => "body",
                                            "parameters" => $parameters
                                        ];
                                        // $components[1] = [
                                        //     "type" => "button",
                                        //     "sub_type" => "url",
                                        //     "index" => 0,
                                        //     "parameters" => [['type' => 'text', 'text' => "/"]]
                                        // ];

                                        $this->util->sendWhatsAppMessage($to_phone, config('constants.WA_QUEUE_TABLE_ASSIGN_TEMPLATE'), $components);
                                    }
                                }
                                // Send a message on WhatsApp END
                            }

                            DB::commit();

                            return[
                                'success' => true,
                                'message' => "Queue Table assigned",
                                'transaction_id' => "" . $transaction_id
                            ];
                        } else {
                            return response()->json([
                                'success' => false,
                                'errorMessage' => 'Queue and Table IDs array are required'
                            ], 200);
                        }
                    } catch (\Exception $e) 
                    {
                        DB::rollBack();
            
                        \Log::emergency("File:" . $e->getFile(). "Line:" . $e->getLine(). "Message:" . $e->getMessage());
                            $msg = __('messages.something_went_wrong');
                        
                        $output = [
                            'success' => false,
                            'errorMessage' => $msg,
                            'message' => $msg
                        ];
            
                        return $output;
                    }
                } else {
                    return["errorMessage"=>'Invalid token.'];
                }
            } else {
                return["errorMessage"=>'Invalid token.'];
            }
        }
    }

    public function shortenUrl() {
        try {
            $builder = new \AshAllenDesign\ShortURL\Classes\Builder();
            $long_url = "https://dev.qr.warelypos.com/start-order?table_id=8&uid=2.0&table_name=T5&pax=3&business_id=2&location_id=2.0&token=4QzxINpXdrG7RUWmnk8mMxOBK6ufm7U9MtYgGrnBspmLAPdF7HricYu8WXaF";
            $shortURLObject = $builder->destinationUrl($long_url)->make();
            return[
                'success' => true,
                'message' => "Shorten URL",
                'data' => $shortURLObject
            ];
        } catch (\Exception $e) {
            \Log::emergency("File:" . $e->getFile(). "Line:" . $e->getLine(). "Message:" . $e->getMessage());
                $msg = __('messages.something_went_wrong');
            
            $output = [
                'success' => false,
                'errorMessage' => $msg,
                'message' => $msg
            ];
            return $output;
        }
    }

    public function reQueueToTable(ReQueueRequest $request) {
        $req_data = $request;
        if(isset($req_data['token'])) {
            $result = User::checkUserToken($req_data['token'], $req_data['user_id']);
            if($result) {
                try {
                    DB::beginTransaction();

                    ManageQueue::where('business_id', $req_data['business_id'])
                                        ->where('location_id', $req_data['location_id'])
                                        ->where('status', 'missed')
                                        ->whereIn('queue_token', $req_data['queue_tokens'])
                                        ->update(['status' => 'requeue']);

                    DB::commit();

                    return[
                        'success' => true,
                        'message' => "Re-queue successful"
                    ];
                } catch (\Exception $e) 
                {
                    DB::rollBack();
        
                    \Log::emergency("File:" . $e->getFile(). "Line:" . $e->getLine(). "Message:" . $e->getMessage());
                        $msg = __('messages.something_went_wrong');
                    
                    $output = [
                        'success' => false,
                        'errorMessage' => $msg,
                        'message' => $msg
                    ];
        
                    return $output;
                }
            } else {
                return["errorMessage"=>'Invalid token.'];
            }
        } else {
            return["errorMessage"=>'Invalid token.'];
        }
    }

    public function fetchMissedQueue(MissedQueueRequest $request) {
        $input = $request;
        try {
            $query = "SELECT mq.queue_pax, mq.mobile_number, mq.first_name, mq.last_name, mq.queue_order, mq.status, mq.sms_status, mq.queue_token, mq.country_code,
            CONCAT(qs.prefix, '', mq.queue_number) AS queue_number, mq.queue_number as qnumber, qs.estimated_wait_time as ewt, mq.queue_number * qs.estimated_wait_time AS estimated_wait_time,
            mq.id as queue_id
            FROM manage_queue as mq
            JOIN queue_schemas as qs ON mq.queue_schema_id = qs.id
            WHERE mq.business_id = " . $input['business_id'] . " 
            AND mq.location_id = " . $input['location_id'] . " 
            AND mq.deleted_at IS NULL 
            AND mq.status IN ('missed');";
            $queueList = DB::select($query);
            return $queueList;
        } catch (\Exception $e) {
            \Log::emergency("File:" . $e->getFile(). "Line:" . $e->getLine(). "Message:" . $e->getMessage());
            $msg = __('messages.something_went_wrong');

            $output = [
                'errorMessage' => $msg
            ];
            return $output;
        }
    }

    public function fetchMissedQueueList(MissedQueueListRequest $request) {
        $input = $request;
        if(isset($input['token'])) {
            $result = User::checkUserToken($input['token'], $input['user_id']);
            if($result) {
                try {
                    $queueList = [];
                    $queueSchemas = QueueSchema::where('queue_schemas.business_id', $input['business_id'])
                    ->where('queue_schemas.location_id', $input['location_id'])
                    ->whereNull('queue_schemas.deleted_at')
                    ->join('business_locations AS BL', 'queue_schemas.location_id', '=', 'BL.id')
                    ->join('queue_pax_categories AS PC', 'queue_schemas.pax_category_id', '=', 'PC.id')
                    ->select(['BL.name as location', 'PC.description as pax_range', 'PC.start_from as pax_range_start_from', 'PC.end_to as pax_range_end_to',
                        'queue_schemas.prefix', 'queue_schemas.start', 'queue_schemas.end',
                        'queue_schemas.estimated_wait_time', 'queue_schemas.description', 'queue_schemas.id'])
                    ->get();
                    foreach ($queueSchemas as $key => $queueSchema) {
                        $membersInAQueue = DB::select("SELECT ROW_NUMBER() OVER (ORDER BY id) AS row_num, queue_pax, mobile_number, first_name, last_name, salutation, queue_order, status, sms_status, queue_token, country_code,
                        CONCAT('" . $queueSchema['prefix'] . "', '', queue_number)  AS queue_number, queue_number as qnumber, 
                        ( ROW_NUMBER() OVER (ORDER BY id) * " . $queueSchema['estimated_wait_time'] . ") AS estimated_wait_time, id as queue_id,
                        created_at, updated_at
                        FROM manage_queue 
                        WHERE business_id = " . $input['business_id'] . " 
                        AND location_id = " . $input['location_id'] . " 
                        AND deleted_at IS NULL 
                        AND status IN ('missed')
                        AND queue_schema_id = " . $queueSchema['id'] . "");
                        
                        $temp = [
                            'id' => $queueSchema['id'],
                            'location' => $queueSchema['location'],
                            'pax_range' => $queueSchema['pax_range'],
                            'pax_range_start_from' => $queueSchema['pax_range_start_from'],
                            'pax_range_end_to' => $queueSchema['pax_range_end_to'],
                            'prefix' => $queueSchema['prefix'],
                            'start' => $queueSchema['start'],
                            'end' => $queueSchema['end'],
                            'estimated_wait_time' => $queueSchema['estimated_wait_time'],
                            'description' => $queueSchema['description'],
                            'registrations' => $membersInAQueue
                        ];
                        $queueList[] = $temp;
                    }
                    return $queueList;
                } catch (\Exception $e) {
                    \Log::emergency("File:" . $e->getFile(). "Line:" . $e->getLine(). "Message:" . $e->getMessage());
                    $msg = __('messages.something_went_wrong');

                    $output = [
                        'errorMessage' => $msg
                    ];
                    return $output;
                }
            } else {
                return["errorMessage"=>'Invalid token.'];
            }
        } else {
            return["errorMessage"=>'Invalid token.'];
        }
    }
}