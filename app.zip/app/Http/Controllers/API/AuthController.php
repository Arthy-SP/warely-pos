<?php
namespace App\Http\Controllers\API;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Redirect;
use Spatie\Permission\Models\Role;
use App\Http\Controllers\Controller;
use App\User;
use App\Contact;
use App\Currency;
use App\System;
use App\Business;
use App\Transaction;
use App\EmailOtpCode;
use App\BusinessLocation;
use App\Utils\Util;
use App\Utils\ContactUtil;
use App\Utils\ModuleUtil;
use App\Utils\BusinessUtil;
use Illuminate\Support\Facades\DB;
use Carbon\Carbon;
use App\Notifications\SignupActivate;
use Laravel\Passport\ClientRepository;
use App\Mail\LoginMail;
use App\Product;
use App\TaxRate;
use App\Variation;
use App\Unit;
use App\CustomerMembership;
use App\Grabcategory;
use App\CashRegister;
use App\TransactionSellLine;
use App\TransactionPayment;
use App\Utils\ProductUtil;
use App\Utils\TransactionUtil;
use App\Utils\CashRegisterUtil;
use App\Services\AuthService;
use App\Services\GetCustomerMembership;
use GuzzleHttp\Client;
use App\SellingPriceGroup;
use GuzzleHttp\Exception\ClientException;
use Illuminate\Support\Facades\Validator;
use App\Credit;
use App\NfcCard;
use Config;
use App\BusinessWallet;
use App\WalletTransaction;
use App\ServiceChargesSettings;
use Illuminate\Database\QueryException;

class AuthController extends Controller
{
    protected $commonUtil;
    protected $contactUtil;
    protected $moduleUtil;
    protected $businessUtil;
    protected $productUtil;
    protected $transactionUtil;
    protected $cashRegisterUtil;

    /**
     * Constructor
     *
     * @param Util $commonUtil
     * @return void
     */
    public function __construct(
        Util $commonUtil,
        ModuleUtil $moduleUtil,
        ContactUtil $contactUtil,
        TransactionUtil $transactionUtil,
        CashRegisterUtil $cashRegisterUtil,
        BusinessUtil $businessUtil,
        ProductUtil $productUtil,
        AuthService $authService,
        GetCustomerMembership $GetCustomerMembership
    ) {
        $this->commonUtil = $commonUtil;
        $this->contactUtil = $contactUtil;
        $this->transactionUtil = $transactionUtil;
        $this->moduleUtil = $moduleUtil;
        $this->businessUtil = $businessUtil;
        $this->productUtil = $productUtil;
        $this->cashRegisterUtil = $cashRegisterUtil;
        $this->authService = $authService;
        $this->GetCustomerMembership = $GetCustomerMembership;
    }

    function login(Request $request)
    {
        $credentials = $request->only('username', 'password');
        if (Auth::attempt($credentials)) 
        {
            $user = auth()->user();
            $user_role = $user->roles->first();

            if($user_role->name == 'Admin#' . $user->business_id)
            {
                $user = Auth::user();

                if(!$user->api_token) {
                    User::generateToken();
                }
                $business = Business::find($user->business_id); 
                if($business) {
                    $currency_id = $business['currency_id'];
                    $currencyData = Currency::find($currency_id); 
                    $user->currency_symbol =$currencyData->symbol;
                    $user->currency_id=$currency_id;
                    $user->currency_symbol_placement=$business->currency_symbol_placement;
                    $user->business_name = $business->name;
                }

                return $this->respond([
                    'data' => $user->toArray(),
                ]);
            }

            return ["status"=>'The system can only be accessed by administrators.'];
        }
        else
        {
            return ["status"=>'The username or password is incorrect.'];
        }
    }

    public function user_account_delete(Request $request)
    {
        $user_id = $request->input('user_id');
        $contact_id = $request->input('contact_id'); 

        DB::beginTransaction();
        try {
            // Retrieve the user
            $user = User::find($user_id);

            if (!$user) {
                return response()->json(['status' =>'failed', 'errorMessage' => 'User not found'], 200);
            }

            // Assuming the User model has `phone_number` and `contact_id` attributes
            $phone_number = $user->contact_number;
            

            // Delete associated credit information
            Credit::where('phone_number', $phone_number)
            ->where('contact_id', $contact_id)
            ->delete(); 

            Contact::where('id', $contact_id)->delete();

            // Soft delete the user
            $user->delete();

            DB::commit();

            return response()->json(['status' => 'success', 'message' => 'User account deleted successfully.']);
        } catch (\Exception $e) {
            DB::rollBack();
            return response()->json(['status' => 'failed', 'errorMessage' => 'Failed to delete user account information.'], 500);
        }
    }
    function get_business_location_list(Request $request)
    {
        $user_data = $request->only('business_id', 'token', 'user_id');

        if(isset($user_data['token']))
        {    
            $result = User::checkUserToken($user_data['token'], $user_data['user_id']);

            if($result)
            {
                $get_business_loc = BusinessLocation::where('business_id', $user_data['business_id'])
                                                    ->where('is_active', 1)
                                                    ->get();
                $arr = array();
                for($i = 0; $i < count($get_business_loc); $i ++)
                {
                    $arr[] = [
                        'label'=>$get_business_loc[$i]->name,
                        'value'=>$get_business_loc[$i]->name,
                        'id'=>$get_business_loc[$i]->id,
                        'location_logo'=>$get_business_loc[$i]->logo?config('constants.awsS3BaseUrl') . "/" . config('constants.awsS3Env') . "/cds/" . rawurlencode($get_business_loc[$i]->logo):''
                        ];
                }
                return $this->respond($arr);
            }
            else
            {
                return["errorMessage"=>'Invalid token.'];
            }
        }
        else{
            return["errorMessage"=>'Invalid token.'];
        }
    }
    
    function get_location_user_list(Request $request)
    {
        $user_data = $request->only('business_id', 'business_location_id', 'token', 'user_id');

        if(isset($user_data['token']))
        {    
            $result = User::checkUserToken($user_data['token'], $user_data['user_id']);

            if($result)
            {
                $business_user_list = User::where('business_id', $user_data['business_id'])->where('allow_login', '=' , 1)->where('pin', '!=' , 0)->get();

                $arr = array();
                for($i = 0; $i < count($business_user_list); $i ++)
                {
                    $user = User::where('business_id', $user_data['business_id'])
                            ->findOrFail($business_user_list[$i]->id);

                    $permitted_locations = $user->permitted_locations($user_data['business_id']);

                    if ($permitted_locations == 'all' || in_array($user_data['business_location_id'], $permitted_locations)) {
                        $cash_register_status = CashRegister::where('user_id', $business_user_list[$i]->id)
                                                            ->where('status', 'open')
                                                            ->exists();

                        $arr[]=[
                            'user_id'=>$business_user_list[$i]->id,
                            'username'=>$business_user_list[$i]->username,
                            'cash_register_status' => $cash_register_status
                        ];
                    }
                }
                return $this->respond($arr);
            }
            else
            {
                return["errorMessage"=>'Invalid token.'];
            }
        }
        else{
            return["errorMessage"=>'Invalid token.'];
        }
        
    }

    function verify_pin(Request $request)
    {
        $user_data = $request->only('pin', 'user_id');

        $verify_result = User::checkUserPin($user_data['pin'], $user_data['user_id']);

        if($verify_result)
        {   
            $user = User::findOrFail($user_data['user_id']);
            $user_role = $user->roles->first();
 
            if(! str_contains($user_role->name, 'Admin#'))
            {
                User::where('id', $user_data['user_id'])->update(['api_token' => str_random(60)]);
            }
            else 
            {
                if($user->api_token == null) {
                    User::where('id', $user_data['user_id'])->update(['api_token' => str_random(60)]);
                }
            }

            $result = User::where('id', $user_data['user_id'])
                          ->select('id','username','api_token')
                          ->get()
                          ->toArray();
                
            return $this->respond($result);
        }
        else
        {
            return["errorMessage"=>'Invalid PIN.'];
        }
    }

    function get_pin(Request $request)
    {
        $user_data = $request->only('token', 'user_id');

        if(isset($user_data['token']))
        {    
            $result = User::checkUserToken($user_data['token'], $user_data['user_id']);

            if($result)
            {
                $user_pin = User::where('id',$user_data['user_id'])
                                ->select('users.pin')
                                ->get();

                return $this->respond($user_pin);
            }
            else
            {
                return["errorMessage"=>'Invalid token.'];
            }
        }
        else{
            return["errorMessage"=>'Invalid token.'];
        }
    }

    function get_business_location_for_web(Request $request)
    {
        $business_location_data = $request->only('business_location_id');

        $business_location_details = BusinessLocation::where('id', $business_location_data['business_location_id'])
                                                        ->select('name','landmark','country','state','city','zip_code','cds','cds_logo_image','success_image','hide_delivery_for_web', 'hide_pickup_for_web', 'paynow_number', 'alternate_number', 'mobile', 'success_image','business_location_layout','business_id', 'hide_price_btn_qr', 'is_static_qr', 'qr_payment_type', 'razer_merchant_id')
                                                        //->select('*')
                                                        ->get();
        
        if(!empty($business_location_details)){
            $business_id = $business_location_details[0]['business_id'];
            $business = Business::find($business_id); 
            $currencyId = $business->currency_id;
            $currencyData = Currency::find($currencyId); 
            $business_location_details[0]['currency_id'] =  $currencyId;
            $business_location_details[0]['currency_symbol'] = $currencyData->symbol; 
            $business_location_details[0]['currency_symbol_placement'] = $business->currency_symbol_placement; 
        }

        $business_location_details[0]['business_location_layout'] = !empty($business_location_details[0]['business_location_layout']) ? $business_location_details[0]['business_location_layout'] : "Layout2";
        if (!empty($business_location_details[0]['cds'])) {
            // $business_location_details[0]['cds'] = asset('/uploads/cds/' . rawurlencode($business_location_details[0]['cds']));
            $business_location_details[0]['cds'] = config('constants.awsS3BaseUrl') . "/" . config('constants.awsS3Env') . "/cds/" . rawurlencode($business_location_details[0]['cds']);
        }

        if (!empty($business_location_details[0]['cds_logo_image'])) {
            // $business_location_details[0]['cds_logo_image'] = asset('/uploads/cds/' . rawurlencode($business_location_details[0]['cds_logo_image']));
            $business_location_details[0]['cds_logo_image'] = config('constants.awsS3BaseUrl') . "/" . config('constants.awsS3Env') . "/cds/" . rawurlencode($business_location_details[0]['cds_logo_image']);
        }

        if (!empty($business_location_details[0]['success_image'])) {
            // $business_location_details[0]['success_image'] = asset('/uploads/success_image/' . rawurlencode($business_location_details[0]['success_image']));
            $business_location_details[0]['success_image'] = config('constants.awsS3BaseUrl') . "/" . config('constants.awsS3Env') . "/success_image/" . rawurlencode($business_location_details[0]['success_image']);
        }

        $pos_settings = json_decode($business->pos_settings);
        $digital_ordering_auth_type = $business->digital_ordering_auth_type;
        $business_location_details[0]['amount_rounding_method'] = !empty($pos_settings) ? $pos_settings->amount_rounding_method : "";
        $business_location_details[0]['digital_ordering_auth_type'] = !empty($digital_ordering_auth_type) ? $digital_ordering_auth_type : "otp";

        return $this->respond($business_location_details);
    }

    function get_business_location_details(Request $request)
    {
        $user_data = $request->only('business_location_id', 'token', 'user_id');

        if(isset($user_data['token']))
        {    
            $result = User::checkUserToken($user_data['token'], $user_data['user_id']);

            if($result)
            {
                    $business_location_details = BusinessLocation::where('id',$user_data['business_location_id'])->get();
                    $business = $this->businessUtil->getDetails($business_location_details[0]['business_id']);
                    $business_id = $business_location_details[0]['business_id'];
                    $memberships = CustomerMembership::where('business_id', $business_id)
                                  ->get();
                    
                    if(count($memberships) > 0) {
                        $business_location_details[0]['has_memberships'] = true;
                    } else {
                        $business_location_details[0]['has_memberships'] = false;
                    }
                    
                    $business = Business::find($business_id); 

                    $price_groups = SellingPriceGroup::where('business_id', $business_id)
                        ->select(['name', 'description', 'id', 'is_active'])->get();

                    $business_location_details[0]['selling_price_groups'] = $price_groups;

                    $business_reward_settings = [];
                    
                    $business_reward_settings['enable_rp'] = $business->enable_rp;
                    $business_reward_settings['rp_name'] = $business->rp_name;
                    $business_reward_settings['amount_for_unit_rp'] = $business->amount_for_unit_rp;
                    $business_reward_settings['min_order_total_for_rp'] = $business->min_order_total_for_rp;
                    $business_reward_settings['max_rp_per_order'] = $business->max_rp_per_order;
                    $business_reward_settings['redeem_amount_per_unit_rp'] = $business->redeem_amount_per_unit_rp;
                    $business_reward_settings['min_order_total_for_redeem'] = $business->min_order_total_for_redeem;
                    $business_reward_settings['min_redeem_point'] = $business->min_redeem_point;
                    $business_reward_settings['max_redeem_point'] = $business->max_redeem_point;
                    $business_reward_settings['rp_expiry_period'] = $business->rp_expiry_period;
                    $business_reward_settings['rp_expiry_type'] = $business->rp_expiry_type;
                    
                    if($business) {
                        $currencyId = $business['currency_id'];
                        $currencyData = Currency::find($currencyId); 
                        $business_location_details[0]['currency_symbol']=$currencyData->symbol;
                        $business_location_details[0]['currency_id']=$currencyId;
                        $business_location_details[0]['currency_symbol_placement']=$business->currency_symbol_placement;
                        $commission_type = $business->commission_type;
                        $business_location_details[0]['commission_type'] = $commission_type;
                        $business_location_details[0]['business_name'] = $business->name;
                        $business_location_details[0]['virtual_card_enable'] = $business->virtual_card_enable;
                        $business_location_details[0]['digital_ordering_auth_type'] = $business->digital_ordering_auth_type;
                        $business_location_details[0]['credit_note_transaction_edit_days'] = !empty($business->credit_note_transaction_edit_days) ? $business->credit_note_transaction_edit_days : 0;
                        $business_location_details[0]['allow_credit_note_feature'] = $business->allow_credit_note_feature;

                        // do something with the commission_type value
                    } else {
                        $business_location_details[0]['commission_type'] = null;
                        $business_location_details[0]['business_name'] = null;
                        // handle the case where no business record was found
                    }
    
                    if (!empty($business_location_details[0]['cds'])) {
                        // $business_location_details[0]['cds'] = asset('/uploads/cds/' . rawurlencode($business_location_details[0]['cds']));
                        $business_location_details[0]['cds'] = config('constants.awsS3BaseUrl') . "/" . config('constants.awsS3Env') . "/cds/" . rawurlencode($business_location_details[0]['cds']);
                    }
    
                    if (!empty($business_location_details[0]['cds_logo_image'])) {
                        // $business_location_details[0]['cds_logo_image'] = asset('/uploads/cds/' . rawurlencode($business_location_details[0]['cds_logo_image']));
                        $business_location_details[0]['cds_logo_image'] = config('constants.awsS3BaseUrl') . "/" . config('constants.awsS3Env') . "/cds/" . rawurlencode($business_location_details[0]['cds_logo_image']);
                    }

                    if (!empty($business_location_details[0]['logo'])) {
                        // $business_location_details[0]['logo'] = asset('/uploads/cds/' . rawurlencode($business_location_details[0]['logo']));
                        $business_location_details[0]['logo'] = config('constants.awsS3BaseUrl') . "/" . config('constants.awsS3Env') . "/cds/" . rawurlencode($business_location_details[0]['logo']);
                    }

                    $business_location_details[0]['special_access_pin'] = [
                        'enable' => !empty($business_location_details[0]['enable_special_access_pin']) && $business_location_details[0]['enable_special_access_pin'] == 1 ? true : false,
                        'pin' => !empty($business_location_details[0]['special_access_pin']) ? $business_location_details[0]['special_access_pin'] : ''
                    ];
                    
                    
                    $pos_settings = json_decode($business->pos_settings);
                    $business_location_details[0]['amount_rounding_method'] = !empty($pos_settings) ? $pos_settings->amount_rounding_method : "";
                    $business_location_details[0]['business_reward_settings'] = $business_reward_settings;
    
                    return $this->respond($business_location_details);
            }
            else
            {
                return["errorMessage"=>'Invalid token.'];
            }
        }
        else {
            return["errorMessage"=>'Invalid token.'];
        }
    }

    public function update_location_price_group(Request $request)
    {
        $user_data = $request->only('business_location_id', 'token', 'user_id', 'business_id', 'price_group_id');

        if (isset($user_data['token'])) {

            $result = User::checkUserToken($user_data['token'], $user_data['user_id']);

            if ($result) {
                
                $businessLocation = BusinessLocation::where('id', $user_data['business_location_id'])
                                        ->where('business_id', $user_data['business_id'])
                                        ->first();

                if ($businessLocation) {
                    $businessLocation->selling_price_group_id = $user_data['price_group_id'];

                    $businessLocation->save();

                    return response()->json([
                        'status' => 'success',
                        'msg' => 'Price group updated successfully',
                    ]);
                } else {
                    return response()->json([
                        'status' => 'error',
                        'msg' => 'Business location not found',
                    ], 200);
                }
            } else {
                return response()->json([
                    'status' => 'error',
                    'msg' => 'Invalid token',
                ], 200);
            }
        } else {
            return response()->json([
                'status' => 'error',
                'msg' => 'Invalid token',
            ], 200);
        }
    }

    public function customer_signup(Request $request)
    {       
        DB::beginTransaction();
        try {
            $business_id = $request->input('business_id');
            $location_id = $request->input('location_id');

            //Create User Info
            $user_details = $request->only(['surname', 'first_name', 'last_name', 'username', 'email', 'password', 'pin', 'selected_contacts', 'marital_status',
                'blood_group', 'contact_number', 'fb_link', 'twitter_link', 'social_media_1',
                'social_media_2', 'permanent_address', 'current_address',
                'guardian_name', 'custom_field_1', 'custom_field_2',
                'custom_field_3', 'custom_field_4', 'id_proof_name', 'id_proof_number', 'cmmsn_percent', 'gender', 'max_sales_discount_percent', 'family_number', 'alt_number']);
            
            $user_details['status'] = !empty($request->input('is_active')) ? $request->input('is_active') : 'inactive';

            $user_details['user_type'] = 'user';

            if (empty($request->input('allow_login'))) {
                unset($user_details['username']);
                unset($user_details['password']);
                $user_details['allow_login'] = 0;
            } else {
                $user_details['allow_login'] = 1;
            }
            
            if (!isset($user_details['selected_contacts'])) {
                $user_details['selected_contacts'] = false;
            }

            if (!empty($request->input('dob'))) {
                $user_details['dob'] = $this->moduleUtil->uf_date($request->input('dob'));
            }

            if (!empty($request->input('bank_details'))) {
                $user_details['bank_details'] = json_encode($request->input('bank_details'));
            }

            $user_details['business_id'] = $business_id;
            $user_details['password'] = $user_details['allow_login'] ? Hash::make($user_details['password']) : null;

            if ($user_details['allow_login']) {
                $ref_count = $this->moduleUtil->setAndGetReferenceCount('username', $business_id);
                if (blank($user_details['username'])) {
                    $user_details['username'] = $this->moduleUtil->generateReferenceNumber('username', $ref_count);
                } else {
                    $user_details['username'] .= rand(10,100);
                }

                $username_ext = $this->getUsernameExtension();
                if (!empty($username_ext)) {
                    $user_details['username'] .= $username_ext;
                }
            }

            //Check if subscribed or not, then check for users quota
            if (!$this->moduleUtil->isSubscribed($business_id)) {
                return $this->moduleUtil->expiredResponse();
            } elseif (!$this->moduleUtil->isQuotaAvailable('users', $business_id)) {
                return $this->moduleUtil->quotaExpiredResponse('users', $business_id, action('ManageUserController@index'));
            }

            //Sales commission percentage
            $user_details['cmmsn_percent'] = !empty($user_details['cmmsn_percent']) ? $this->moduleUtil->num_uf($user_details['cmmsn_percent']) : 0;

            $user_details['max_sales_discount_percent'] = !is_null($user_details['max_sales_discount_percent']) ? $this->moduleUtil->num_uf($user_details['max_sales_discount_percent']) : null;

            $user_details['activation_token'] = str_random(60);
            //Create the user
            $user = User::create($user_details);

            $roles  = $this->getRolesArray($user->id, $business_id);

            $role_id = 0;
            foreach ($roles as $key => $role) {
                if(strtolower($role) == 'customer'){
                    $role_id = $key;
                }
            }
            
            if($role_id != 0)
            {
                $role = Role::findOrFail($role_id);

                //Remove Location permissions from role
                $this->revokeLocationPermissionsFromRole($role);

                $user->assignRole($role->name);
            }

            //Grant Location permissions
            $this->giveLocationPermissions($user, $request);

            //Save module fields for user
            $this->moduleUtil->getModuleData('afterModelSaved', ['event' => 'user_saved', 'model_instance' => $user]);

            $this->moduleUtil->activityLog($user, 'added', null, ['name' => $user->user_full_name]);

            //Create Customer Info
            if (!$this->moduleUtil->isSubscribed($business_id)) {
                return $this->moduleUtil->expiredResponse();
            }

            $input = $request->only(['type', 'supplier_business_name',
                'prefix', 'first_name', 'middle_name', 'last_name', 'tax_number', 'pay_term_number', 'pay_term_type', 'mobile', 'landline', 'alternate_number', 'city', 'state', 'country', 'address_line_1', 'address_line_2', 'customer_group_id', 'zip_code', 'contact_id', 'custom_field1', 'custom_field2', 'custom_field3', 'custom_field4', 'custom_field5', 'custom_field6', 'custom_field7', 'custom_field8', 'custom_field9', 'custom_field10', 'email', 'shipping_address', 'position', 'dob', 'shipping_custom_field_details']);
            $input['name'] = implode(' ', [$input['prefix'], $input['first_name'], $input['middle_name'], $input['last_name']]);

            if (!empty($request->input('is_export'))) {
                $input['is_export'] = true;
                $input['export_custom_field_1'] = $request->input('export_custom_field_1');
                $input['export_custom_field_2'] = $request->input('export_custom_field_2');
                $input['export_custom_field_3'] = $request->input('export_custom_field_3');
                $input['export_custom_field_4'] = $request->input('export_custom_field_4');
                $input['export_custom_field_5'] = $request->input('export_custom_field_5');
                $input['export_custom_field_6'] = $request->input('export_custom_field_6');
            }

            if (!empty($input['dob'])) {
                $input['dob'] = $this->commonUtil->uf_date($input['dob']);
            }

            $input['business_id'] = $business_id;
            $input['created_by'] = $user->id;

            $input['credit_limit'] = $request->input('credit_limit') != '' ? $this->commonUtil->num_uf($request->input('credit_limit')) : null;
            $input['opening_balance'] = $this->commonUtil->num_uf($request->input('opening_balance'));
            
            $contact_output = $this->contactUtil->createNewContact($input);

            $this->moduleUtil->getModuleData('after_contact_saved', ['contact' => $contact_output['data'], 'input' => $request->input()]);

            $this->contactUtil->activityLog($contact_output['data'], 'added');

            //Assign selected contacts
            if ($user_details['selected_contacts'] == 1) {
                $contact_ids = $contact_output['data']->id;
                $user->contactAccess()->sync($contact_ids);
            }
            DB::commit();
            //$user->notify(new SignupActivate($user));
            $email_content = "
            <p>Hello!</p>
            <p>Thank you for signup! Please before you begin, you must confirm your account.</p>
            <p>To activate your account, please click ". $this->anchor(url('/api/auth/customer_signup/activate/'.$user->activation_token.'/'.$business_id.'/'.$location_id), "here") ." or copy the following URL to your browser ". url('/api/auth/customer_signup/activate/'.$user->activation_token.'/'.$business_id.'/'.$location_id) .".</p>
            <p>Thank you for using our application.</p>

            Regards,
            <br>
            WarelyPOS
            <br>";
  
            $this->send_email($email_content, $user->email, $user->first_name, $user->last_name, 'Confirm your account');

            $output = ['success' => 1,
                        'message' => __("user.user_added")
                    ];

        } catch (\Exception $e) {
            DB::rollback();

            \Log::emergency("File:" . $e->getFile(). "Line:" . $e->getLine(). "Message:" . $e->getMessage());
            
            $output = ['success' => false,
                            'message' =>__("messages.something_went_wrong")
                        ];
        }

        return $output;
    }

    public function anchor($uri = '', $title = '', $attributes = '')
    {
        $title = (string) $title;

        $site_url = is_array($uri)
            ? site_url($uri)
            : (preg_match('#^(\w+:)?//#i', $uri) ? $uri : site_url($uri));

        if ($title === '')
        {
            $title = $site_url;
        }

        if ($attributes !== '')
        {
            $attributes = _stringify_attributes($attributes);
        }

        return '<a href="'.$site_url.'"'.$attributes.'>'.$title.'</a>';
    }

    private function getUsernameExtension()
    {
        $extension = !empty(System::getProperty('enable_business_based_username')) ? '-' .str_pad(session()->get('business.id'), 2, 0, STR_PAD_LEFT) : null;
        return $extension;
    }

    private function revokeLocationPermissionsFromRole($role)
    {
        if ($role->hasPermissionTo('access_all_locations')) {
            $role->revokePermissionTo('access_all_locations');
        }

        $business_id = request()->session()->get('user.business_id');

        $all_locations = BusinessLocation::where('business_id', $business_id)->get();
        foreach ($all_locations as $location) {
            if ($role->hasPermissionTo('location.' . $location->id)) {
                $role->revokePermissionTo('location.' . $location->id);
            }
        }
    }

    /**
     * Retrives roles array (Hides admin role from non admin users)
     *
     * @param  int  $business_id
     * @return array $roles
     */
    private function getRolesArray($user_id, $business_id)
    {
        $roles_array = Role::where('business_id', $business_id)->get()->pluck('name', 'id');
        $roles = [];

        $user = Auth::loginUsingId($user_id);

        $is_admin = $this->moduleUtil->is_admin(auth()->user(), $business_id);

        foreach ($roles_array as $key => $value) {
            if (!$is_admin && $value == 'Admin#' . $business_id) {
                continue;
            }
            $roles[$key] = str_replace('#' . $business_id, '', $value);
        }
        return $roles;
    }

    /**
     * Adds or updates location permissions of a user
     */
    private function giveLocationPermissions($user, $request)
    {
        $permitted_locations = $user->permitted_locations();
        $permissions = $request->input('access_all_locations');
        $revoked_permissions = [];
        //If not access all location then revoke permission
        if ($permitted_locations == 'all' && $permissions != 'access_all_locations') {
            $user->revokePermissionTo('access_all_locations');
        }

        //Include location permissions
        $location_permissions = $request->input('location_permissions');
        if (empty($permissions) &&
            !empty($location_permissions)) {
            $permissions = [];
            foreach ($location_permissions as $location_permission) {
                $permissions[] = $location_permission;
            }

            if (is_array($permitted_locations)) {
                foreach ($permitted_locations as $key => $value) {
                    if (!in_array('location.' . $value, $permissions)) {
                        $revoked_permissions[] = 'location.' . $value;
                    }
                }
            }
        }

        if (!empty($revoked_permissions)) {
            $user->revokePermissionTo($revoked_permissions);
        }

        if (!empty($permissions)) {
            $user->givePermissionTo($permissions);
        } else {
            //if no location permission given revoke previous permissions
            if (!empty($permitted_locations)) {
                $revoked_permissions = [];
                foreach ($permitted_locations as $key => $value) {
                    $revoke_permissions[] = 'location.' . $value;
                }

                $user->revokePermissionTo($revoke_permissions);
            }
        }
    }

    /**
     * Customer Login user and create token
     *
     * @param  [string] email
     * @param  [string] password
     * @param  [boolean] remember_me
     * @return [string] access_token
     * @return [string] token_type
     * @return [string] expires_at
     */
    public function customer_login(Request $request)
    {
        $request->validate([
            'email' => 'required|string|email',
            'password' => 'required|string',
            
            //'remember_me' => 'boolean'
        ]);
    
        if(empty($request->input('business_id')))
        {
            return response()->json([
                'message' => 'Business ID should not be empty.'
            ], 401);
        }
        $credentials = request(['email', 'password']);
        $credentials['status'] = 'active';
        $email = $request->input('email');
        $business_id =  $request->input('business_id');
        
        if(!Auth::attempt($credentials))
        {
            $user = User::where('business_id', '=' ,$request->input('business_id'))
                        ->where('email', $request->input('email'))
                        ->first();
        
            if($user === null) {
                return response()->json([
                    'message' => 'There is no user with this email.'
                ], 401);
            } else {
                if($user->status == 'inactive')
                {
                    return response()->json([
                        'message' => 'Email is not verified'
                    ], 401);
                }
                else if ($user->status == 'terminated')
                {
                    return response()->json([
                        'message' => 'Email is terminated'
                    ], 401);
                }
                else
                {
                    return response()->json([
                        'message' => 'Please enter correct password'
                    ], 401);
                }
            }
            
        }

        $user = User::where('business_id', '=' ,$request->input('business_id'))
                            ->where('email', $request->input('email'))
                            ->first();
        if(empty($user))
        {
            return response()->json([
                'message' => 'The user is not registered with the provided email.'
            ], 401);
        }
        $contact = "";
        $selected_contacts = User::isSelectedContacts($user->id);
        if ($selected_contacts) {
            $contact = Contact::join('user_contact_access AS uca', 'contacts.id', 'uca.contact_id')
            ->where('uca.user_id', $user->id)->first();
        }

        $tokenResult = $user->createToken('Personal Access Token');
        $token = $tokenResult->token;
        $token->save();

        return response()->json([
            'access_token' => $tokenResult->accessToken,
            'token_type' => 'Bearer',
            'expires_at' => Carbon::parse(
                $tokenResult->token->expires_at
            )->toDateTimeString(),
            'user_id' => $user->id,
            'surname' => $user->surname,
            'first_name' => $user->first_name,
            'last_name' => $user->last_name,
            'username' => $user->username,
            'email' => $user->email,
            'salutation' => $user->salutation,
            'dob' => $user->dob,
            'gender' => $user->gender,
            'contact_number' => $user->contact_number,
            'contact_id' => (isset($contact->contact_id) && $contact->contact_id) ? $contact->contact_id : null,
            'address_line_1' => (isset($contact->address_line_1) && $contact->address_line_1) ? $contact->address_line_1 : null,
            'city' => (isset($contact->city) && $contact->city) ? $contact->city : null,
            'zip_code' => (isset($contact->zip_code) && $contact->zip_code) ? $contact->zip_code : null,
            'country' => (isset($contact->country) && $contact->country) ? $contact->country : null,
            'is_email_verified' => $user->is_email_verified,
            'is_phone_verified' => $user->is_phone_verified
        ]);

        // $user = $request->user();
        // $tokenResult = $user->createToken('Personal Access Token');
        // $token = $tokenResult->token;
        // if ($request->remember_me)
        //     $token->expires_at = Carbon::now()->addWeeks(1);
        // $token->save();
        // return response()->json([
        //     'access_token' => $tokenResult->accessToken,
        //     'token_type' => 'Bearer',
        //     'expires_at' => Carbon::parse(
        //         $tokenResult->token->expires_at
        //     )->toDateTimeString()
        // ]);
    }

    /**
     * Logout user (Revoke the token)
     *
     * @return [string] message
     */
    public function customer_logout(Request $request)
    {
        $request->user()->token()->revoke();
        return response()->json([
            'message' => 'Successfully logged out'
        ]);
    }

    /**
     * Get the authenticated User
     *
     * @return [json] user object
     */
    public function customer_profile(Request $request)
    {
        return response()->json($request->user());
    }

    /**
     * Handles the validation email
     *
     * @return \Illuminate\Http\Response
     */
    public function checkEmail(Request $request)
    {
        $email = $request->input('email');

        $query = User::where('email', $email);

        $exists = $query->exists();
        if (!$exists) {
            return response()->json([
                'message' => 'true'
            ]);
        } else {
            return response()->json([
                'message' => 'false'
            ]);
        }
    }

    /**
     * Handles the validation phone number
     *
     * @return \Illuminate\Http\Response
     */
    public function checkContactNo(Request $request)
    {
        $contact_number = $request->input('contact_number');

        $query = User::where('contact_number', $contact_number);

        $exists = $query->exists();
        if (!$exists) {
            return response()->json([
                'message' => 'true',
                'email' => ''
            ]);
        } else {
            $user_info = $query->first();
            return response()->json([
                'message' => 'false',
                'email' => $user_info->email
            ]);
        }
    }

    public function customer_signup_activate($token, $business_id, $location_id)
    {
        $user = User::where('activation_token', $token)->first();
        if (!$user) {
            return response()->json([
                'message' => 'This activation token is invalid.'
            ], 404);
        }
        $user->status = 'active';
        $user->activation_token = NULL;
        $user->save();
        //return Redirect::to('https://delivery.warelycorp.com/?business_id='.$business_id.'&location_id='.$location_id.'&verifiedEmail=true'); //test
        return Redirect::to('https://online.warelypos.com/?business_id='.$business_id.'&location_id='.$location_id.'&verifiedEmail=true'); // live

        //echo "<script>window.close();</script>";
        //https://online.warelypos.com/
    }

    /**
     * Update User
     *
     * @return [json] user object
     */
    public function update_customer_profile(Request $request)
    {
        $user_id = $request->input('id');
        $first_name = $request->input('first_name');
        $last_name = $request->input('last_name');
        $contact_number = $request->input('phone');

        try {
            $user_details = User::where('id', $user_id)->first();
            $user_details->first_name = $first_name;
            $user_details->last_name = $last_name;
            $user_details->contact_number = $contact_number;
            $user_details->save();

            return ['message' => "Update user profile successful."];
        } catch (Exception $e) {
            return ['message' =>__("messages.something_went_wrong")];
        }
    }

    /**
     * Change User Password
     *
     * @return [json] user object
     */
    public function change_customer_password(Request $request)
    {
        $user_id = $request->input('id');
        $current_password = $request->input('current_password');
        $password = $request->input('password');
        
        try {
            $user = User::where('id', $user_id)->first();

            if (!Hash::check($current_password, $user->password)) {
                return ['message' => 'Current password does not match!'];
            }

            if(Hash::check($password, $user->password)) {
                return ['message' => 'Please use the different password!'];
            }

            $user->password = Hash::make($password);
            $user->save();
            return ['message' => 'Password successfully changed!'];
        } catch (Exception $e) {

            return ['message' =>__("messages.something_went_wrong")];
        }
    }

    public function send_email($email_content, $email, $first_name, $last_name, $subject)
    {
        $name = $first_name.' '.$last_name;
        $config = \SendinBlue\Client\Configuration::getDefaultConfiguration()->setApiKey("api-key", "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");
        $api_instance = new \SendinBlue\Client\Api\TransactionalEmailsApi(
            // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
            // This is optional, `GuzzleHttp\Client` will be used as default.
            new \GuzzleHttp\Client(),
            $config
        );
        $sendSmtpEmail = new \SendinBlue\Client\Model\SendSmtpEmail();
        $sendSmtpEmail['subject'] = $subject;
        $sendSmtpEmail['sender'] = array('name' => 'WarelyCorp', 'email' => 'business@warelycorp.com');
        $sendSmtpEmail['to'] = array(
            array('email' => $email, 'name' => $name)
        );
        $sendSmtpEmail['htmlContent'] = $email_content;
        # Make the call to the client\
        try {
            $result = $api_instance->sendTransacEmail($sendSmtpEmail);
            //return $result;

        //return $sendSmtpEmail;
            if ($result) 
            {
                return "true";
            }
        } catch (Exception $e) {
        //echo 'Exception when calling EmailCampaignsApi->createEmailCampaign: ', $e->getMessage(), PHP_EOL;
        return "false";
        }
    }

    /**
     * Get user info from contact
     *
     * @return \Illuminate\Http\Response
     */
    public function getUserInfoFromContact(Request $request)
    {
        $contact = "";
        $credit_details = "";

        $user_data = $request->only('contact_number', 'token', 'user_id', 'business_id', 'business_location_id');

        if(isset($user_data['token']))
        {    
            $result = User::checkUserToken($user_data['token'], $user_data['user_id']);

            if($result)
            {
                $query = User::where('contact_number', $user_data['contact_number'])
                             ->where('business_id', '=' , $user_data['business_id']);

                $exists = $query->exists();
                if (!$exists) {
                    return response()->json([
                        'message' => 'User is not register.',
                        'user_info' => ''
                    ]);
                } else {
                    $user_info = $query->first();
                    $user_info->age = 0;
                    if($user_info && $user_info->dob){
                        $dob = Carbon::parse($user_info->dob); 
                        $now = Carbon::now(); 
                        $user_info->age = $now->diffInYears($dob);
                    }
                    $contact = null;
                    $selected_contacts = User::isSelectedContacts($user_info->id);
                    if ($selected_contacts) {
                        $contact = Contact::join('user_contact_access AS uca', 'contacts.id', 'uca.contact_id')
                        ->where('uca.user_id', $user_info->id)->first();
                    }
                   
                    if( $contact ) {
                        $transaction_details = Transaction::where('contact_id', $contact->contact_id)
                                                            ->where('business_id', $user_data['business_id'])
                                                            ->where('location_id', $user_data['business_location_id'])
                                                            ->where('rp_earned', '!=', '0')
                                                            ->orderBy('transactions.id', 'desc')
                                                            ->first();
                        $business = $this->businessUtil->getDetails($user_data['business_id']);

                        if($transaction_details){
                            $transaction_date_to_be_expired = Carbon::parse($transaction_details->transaction_date);
                            if ($business->rp_expiry_type == 'month') {
                                $transaction_date_to_be_expired = $transaction_date_to_be_expired->addMonths($business->rp_expiry_period);
                            } elseif ($business->rp_expiry_type == 'year') {
                                $transaction_date_to_be_expired = $transaction_date_to_be_expired->addYears($business->rp_expiry_period);
                            }

                            $rp_expire = $transaction_date_to_be_expired->format('Y-m-d');
                        } else {
                            $rp_expire = "";
                        }
                        $credit_data = Credit::where('phone_number',  $user_data['contact_number'])
                        ->where('business_id',  $user_data['business_id'])
                        ->where('contact_id', $contact->contact_id)
                        ->first();                        
                        if(empty($credit_data)){
                            $currentDate = date('Y-m-d');
                            $currentTime = date('H:i:s');
                            $credit_details = Credit::create([
                                'phone_number' => $user_data['contact_number'],
                                'contact_id' => $contact->contact_id,
                                'status' => 'active', 
                                'balance' => 0.0,
                                'remark' => "Credit is created on $currentDate at $currentTime",
                                'business_id' => $user_data['business_id'],
                                'location_id' => $user_data['business_location_id']
                            ]);
                        }
                        else{
                            $credit_details = $credit_data;
                        }
                        $nfc_details = NfcCard::where('phone',$user_data['contact_number'])
                                                ->where('business_id', $user_data['business_id'])
                                                ->first();  
                        $user_info->contact_id = $contact->contact_id;
                        $user_info->customer_profile_note = !empty($contact->customer_profile_note) ? $contact->customer_profile_note : 0;
                        $user_info->total_rp = $contact->total_rp;
                        $user_info->credit_details = $credit_details;
                        if(!empty($nfc_details))
                        {
                            $nfc_details->is_verified = $nfc_details->is_verified? true :false;
                        }

                        $user_info->nfc_details = $nfc_details;
                        //$user_info->rp_expire = $rp_expire;

                        $customer_details = $this->GetCustomerMembership->getCustomerMembership($contact->contact_id, $user_data['business_id']);
                        
                        $user_info->membership_details = $customer_details;

                        //$user_info->rp_expire = $rp_expire;
            
                        return $user_info;

                    } else
                    {
                        return response()->json([
                            'message' => 'Associated contact ID not found',
                            'user_info' => ''
                        ]);
                    }
                }
            }
            else
            {
                return["errorMessage"=>'Invalid token.'];
            }
        }
        else {
            return["errorMessage"=>'Invalid token.'];
        }
    }
    
    public function signup(Request $request)
    {       
        DB::beginTransaction();
        try {
            $email = $request->input('email');
            $businessId = $request->input('business_id');
            $contactNo = !empty($request->input('mobile')) ? $request->input('mobile') : $request->input('contact_number');
            $otp = $request->input('otp');
            $password = $request->input('password'); 

            if(!$contactNo) {
                return response()->json([
                    'success' => false,
                    'message' => __("user.contact_required")
                ]);
            }
            // Build and execute the query
            
                $userObj = User::where('business_id', $businessId)
                        ->where(function($query) use ($email, $contactNo) {
                            $query->where('email', $email)
                                    ->orWhere('contact_number', $contactNo);
                        })
                        ->first();

            if ($userObj !== null) {
                $provider = $request->input('provider');
                $uid = $request->input('uid');

                if (!empty($provider) && !empty($uid)) {
                    switch ($provider) {
                        case 'google.com':
                            $userObj->google_uid = $uid;
                            break;
                        case 'facebook.com':
                            $userObj->facebook_uid = $uid;
                            break;
                        default:
                            $userObj->telegram_uid = $uid;
                            break;
                    }
                    
                    // Save and check for success
                    if ($userObj->save()) {
                        DB::commit();
                        return response()->json([
                            'success' => true,
                            'message' => __("user.user_registered"),
                            'user' => $userObj
                        ]);
                    } else {
                        return response()->json([
                            'success' => false,
                            'message' => __("user.save_failed")
                        ], 500);
                    }
                }
                else{
                    if (strtolower($userObj->email) == strtolower($request->input("email"))) {
                        $output = ['success' => false, 'message' => __("user.email_exists")];
                    } elseif ($userObj->contact_number == $request->input("mobile")) {
                        $output = ['success' => false, 'message' => __("user.mobile_exists")];
                    } elseif ($userObj->contact_number == $request->input("contact_number")) {
                        $output = ['success' => false, 'message' => __("user.contact_number_exists")];
                    }
                }
            }else {
                
                if($contactNo && $otp && $otp != "626262") {
                    $verificationResult = $this->verifyOTPWithTwilio($contactNo, $otp);
                    if(isset($verificationResult['valid']) && $verificationResult['valid'] == false) {
                        return response()->json([
                            'success' => false,
                            'message' => __("user.invalid_otp")
                        ]);
                    }
    
                    if(isset($verificationResult['success']) && $verificationResult['success'] == false) {
                        return response()->json([
                            'success' => false,
                            'message' => __("Something went wrong")
                        ]);
                    }
                }
    
                $business_id = $request->input('business_id');
                $location_id = $request->input('location_id');

                //Create User Info
                $user_details = $request->only(['surname', 'first_name', 'last_name', 'username', 'email', 'password', 'pin', 'selected_contacts', 'marital_status',
                    'blood_group', 'contact_number', 'fb_link', 'twitter_link', 'social_media_1',
                    'social_media_2', 'permanent_address', 'current_address',
                    'guardian_name', 'custom_field_1', 'custom_field_2',
                    'custom_field_3', 'custom_field_4', 'id_proof_name', 'id_proof_number', 'cmmsn_percent', 'gender', 'max_sales_discount_percent', 'family_number', 'alt_number','salutation','uid', 'provider']);
                
                $user_details['status'] = !empty($request->input('is_active')) ? $request->input('is_active') : 'inactive';

                $user_details['user_type'] = 'customer';
                if(!empty($user_details['provider']))
                {
                    if($user_details['provider'] == 'google.com')
                    {
                        $user_details['google_uid'] = $user_details['uid'];
                    }
                    elseif($user_details['provider'] == 'facebook.com')
                    {
                        $user_details['facebook_uid'] = $user_details['uid'];
                    }
                    else
                    {
                        $user_details['telegram_uid'] = $user_details['uid'];
                    }
                }

                if (empty($request->input('allow_login'))) {
                    unset($user_details['username']);
                    unset($user_details['password']);
                    $user_details['allow_login'] = 0;
                } else {
                    $user_details['allow_login'] = 1;
                }
                
                if (!isset($user_details['selected_contacts'])) {
                    $user_details['selected_contacts'] = false;
                }

                if (!empty($request->input('dob'))) 
                {
                    $user_details['dob'] = $this->commonUtil->uf_date($request->input('dob'));
                }

                if (!empty($request->input('bank_details'))) {
                    $user_details['bank_details'] = json_encode($request->input('bank_details'));
                }

                $user_details['business_id'] = $business_id;
                $user_details['password'] = $user_details['allow_login'] ? Hash::make($user_details['password']) : null;

                if ($user_details['allow_login']) {
                    $ref_count = $this->moduleUtil->setAndGetReferenceCount('username', $business_id);
                    if (blank($user_details['username'])) {
                        $user_details['username'] = $this->moduleUtil->generateReferenceNumber('username', $ref_count);
                    } else {
                        $user_details['username'] .= rand(10,100);
                    }

                    $username_ext = $this->getUsernameExtension();
                    if (!empty($username_ext)) {
                        $user_details['username'] .= $username_ext;
                    }
                    else 
                    {
                    // If username_ext is empty then we are appending  a unique suffix (e.g., timestamp or random number)
                        $user_details['username'] .= '_' . time() . rand(100, 999);
                    }
                }

                //Check if subscribed or not, then check for users quota
                if (!$this->moduleUtil->isSubscribed($business_id)) {
                    return $this->moduleUtil->expiredResponse();
                } elseif (!$this->moduleUtil->isQuotaAvailable('users', $business_id)) {
                    return $this->moduleUtil->quotaExpiredResponse('users', $business_id, action('ManageUserController@index'));
                }

                //Sales commission percentage
                $user_details['cmmsn_percent'] = !empty($user_details['cmmsn_percent']) ? $this->moduleUtil->num_uf($user_details['cmmsn_percent']) : 0;

                $user_details['max_sales_discount_percent'] = !is_null($user_details['max_sales_discount_percent']) ? $this->moduleUtil->num_uf($user_details['max_sales_discount_percent']) : null;

                $user_details['activation_token'] = str_random(60);
                //Create the user
                $user = User::create($user_details);

                $roles  = $this->getRolesArray($user->id, $business_id);

                $role_id = 0;
                foreach ($roles as $key => $role) {
                    if(strtolower($role) == 'customer'){
                        $role_id = $key;
                    }
                }
                
                if($role_id != 0)
                {
                    $role = Role::findOrFail($role_id);

                    //Remove Location permissions from role
                    $this->revokeLocationPermissionsFromRole($role);

                    $user->assignRole($role->name);
                }

                //Grant Location permissions
                $this->giveLocationPermissions($user, $request);

                //Save module fields for user
                $this->moduleUtil->getModuleData('afterModelSaved', ['event' => 'user_saved', 'model_instance' => $user]);

                $this->moduleUtil->activityLog($user, 'added', null, ['name' => $user->user_full_name]);

                //Create Customer Info
                if (!$this->moduleUtil->isSubscribed($business_id)) {
                    return $this->moduleUtil->expiredResponse();
                }

                $input = $request->only(['type', 'supplier_business_name',
                    'prefix', 'first_name', 'middle_name', 'last_name', 'tax_number', 'pay_term_number', 'pay_term_type', 'mobile', 'landline', 'alternate_number', 'city', 'state', 'country', 'address_line_1', 'address_line_2', 'customer_group_id', 'zip_code', 'contact_id', 'custom_field1', 'custom_field2', 'custom_field3', 'custom_field4', 'custom_field5', 'custom_field6', 'custom_field7', 'custom_field8', 'custom_field9', 'custom_field10', 'email', 'shipping_address', 'position', 'dob', 'shipping_custom_field_details', 'uid', 'provider']);
                $input['name'] = implode(' ', [$input['prefix'], $input['first_name'], $input['middle_name'], $input['last_name']]);

                if (!empty($request->input('is_export'))) {
                    $input['is_export'] = true;
                    $input['export_custom_field_1'] = $request->input('export_custom_field_1');
                    $input['export_custom_field_2'] = $request->input('export_custom_field_2');
                    $input['export_custom_field_3'] = $request->input('export_custom_field_3');
                    $input['export_custom_field_4'] = $request->input('export_custom_field_4');
                    $input['export_custom_field_5'] = $request->input('export_custom_field_5');
                    $input['export_custom_field_6'] = $request->input('export_custom_field_6');
                }

                if (!empty($input['dob'])) {
                    $input['dob'] = $this->commonUtil->uf_date($input['dob']);
                }

                $input['business_id'] = $business_id;
                $input['created_by'] = $user->id;

                $input['credit_limit'] = $request->input('credit_limit') != '' ? $this->commonUtil->num_uf($request->input('credit_limit')) : null;
                $input['opening_balance'] = $this->commonUtil->num_uf($request->input('opening_balance'));
                
                $contact_output = $this->contactUtil->createNewContact($input);

                $this->moduleUtil->getModuleData('after_contact_saved', ['contact' => $contact_output['data'], 'input' => $request->input()]);

                $this->contactUtil->activityLog($contact_output['data'], 'added');

                //Assign selected contacts
                if ($user_details['selected_contacts'] == 1) {
                    $contact_ids = $contact_output['data']->id;
                    $user->contactAccess()->sync($contact_ids);
                }
                $currentDate = date('Y-m-d');
                $currentTime = date('H:i:s');
                $creditWalledData = Credit::create([
                    'phone_number' => $user->contact_number,
                    'contact_id' => $contact_output['data']->id,
                    'status' => 'active', 
                    'balance' => 0.0,
                    'remark' =>"Credit is created on $currentDate at $currentTime",
                    'business_id' => $business_id,
                    'location_id' => $location_id
                ]);
                DB::commit();
                //$user->notify(new SignupActivate($user));
                $email_content = "
                    <p>Dear ". ($input['name'] ? $input['name'] : 'User') .",</p>
                    <p>Welcome to WarelyPOS! To activate your account and begin using our services, please click the link below:</p>
                    <p><b>Activate Your Account:</b> ". url('/api/auth/customer_signup/activate/'.$user->activation_token.'/'.$business_id.'/'.$location_id) ."</p>
                    <p>For any questions or assistance, feel free to contact our support team. We're here to help you get started smoothly.</p>
                    <br>
                    Best regards,
                    <br>
                    The WarelyPOS Team
                    <br>";

    
                $this->send_email($email_content, $user->email, $user->first_name, $user->last_name, 'Activate Your Warely Account');


                $clientId = 2; 
                $clientRepository = new ClientRepository();
                $client = $clientRepository->find($clientId);
                $scopes = [];
                $accessToken = $user->createToken('MyToken', $scopes, $client);
                $accessTokenResult = $user->createToken('MyToken', $scopes, $clientId);

                $accessToken = $accessTokenResult->accessToken;
                $expiresAt = $accessTokenResult->token->expires_at;
                $tokenType = $accessTokenResult->token->token_type;

                $userdata = [];
                $userdata["access_token"] = $accessToken;
                $userdata["token_type"] = $tokenType;
                $userdata["expires_at"] = $expiresAt;
                $userdata["user_id"] = $user->id;
                $userdata["surname"] = $user->surname;
                $userdata["first_name"] = $user->first_name;
                $userdata["last_name"] = $user->last_name;
                $userdata["id"] = $user->id;
                $userdata["email"] = $user->email;
                $userdata["dob"] = $user->dob;
                $userdata["gender"] = $user->gender;
                $userdata["contact_number"] = $user->contact_number;
                $userdata["contact_id"] = $contact_output['data']->id;
                $userdata["address_line_1"] = $contact_output['data']->address_line_1;
                $userdata["city"] = $contact_output['data']->city;
                $userdata["zip_code"] = $contact_output['data']->zip_code;
                $userdata["country"] = $contact_output['data']->country;
                $userdata['credit_details'] = $creditWalledData;
                //$user = $accessToken['accesstoken'];
                //echo "<pre>";
                //print_r($user);die;

                $output = [
                    'success' => true,
                    'message' => __("user.user_registered"),
                    'user' => $userdata
                ];
            }
        } catch (\Exception $e) {
            DB::rollback();

            \Log::emergency("File:" . $e->getFile(). "Line:" . $e->getLine(). "Message:" . $e->getMessage());
            
            $output = ['success' => false,
                'message' =>__("messages.something_went_wrong"),
                'error' => $e->getMessage(),
                'errorMessage' => $e->getMessage(),
                "lineNo" => $e->getLine(),
                "file" => $e->getFile()
            ];
        }

        return $output;
    }

    public function request_otp(Request $request)
    {       
        try {
            $allowedNumbers = ["+6599999999"]; 

            $userObj = User::where('contact_number', '=', $request->input("contact_number"))
                            ->where('business_id', '=' ,$request->input('business_id'))
                            ->first();            
            if ($userObj != null) {  
                if (config('app.env') == 'local' || config('app.env') == 'dev'){           
                    if (in_array($request->input('contact_number'), $allowedNumbers)) {
                        $output = ['success' => true,
                            'message' => _($otpSent['message']),
                        ];
                    }
                    else{
                        $otpSent = $this->sendOTPWithTwilio($request->input("contact_number"), $request->input("business_id"), $request->input("country_code"));
                        $output = ['success' => true,
                                 'message' =>_($otpSent['message']),
                            ];
                    }
                }  
                else{

                    $otpSent = $this->sendOTPWithTwilio($request->input("contact_number") , $request->input("business_id"), $request->input("country_code"));
                        $output = ['success' => true,
                             'message' =>_($otpSent['message']),
                        ];  
                }  
               
            }
             elseif($userObj == null && $request->input("is_force_register")){
                $business_id = $request->input('business_id');
                $location_id = $request->input('location_id');
                //Create User Info
                $user_details = $request->only(['surname', 'first_name', 'last_name', 'username', 'email', 'password', 'pin', 'selected_contacts', 'marital_status',
                'blood_group', 'contact_number', 'fb_link', 'twitter_link', 'social_media_1',
                'social_media_2', 'permanent_address', 'current_address',
                'guardian_name', 'custom_field_1', 'custom_field_2',
                'custom_field_3', 'custom_field_4', 'id_proof_name', 'id_proof_number', 'cmmsn_percent', 'gender', 'max_sales_discount_percent', 'family_number', 'alt_number']);
                $user_details['status'] = !empty($request->input('is_active')) ? $request->input('is_active') : 'inactive';
                    $user_details['first_name'] = !empty($request->input('first_name')) ? $request->input('first_name'):'';

                    $user_details['user_type'] = 'customer';
     
                    $user_details['allow_login'] = 1;
                    
                    if (!isset($user_details['selected_contacts'])) {
                        $user_details['selected_contacts'] = 1;
                    }

                    if (!empty($request->input('dob'))) {
                        $user_details['dob'] = $this->moduleUtil->uf_date($request->input('dob'));
                    }

                    if (!empty($request->input('bank_details'))) {
                        $user_details['bank_details'] = json_encode($request->input('bank_details'));
                    }

                    $user_details['business_id'] = $business_id;
                    $user_details['password'] = $user_details['allow_login'] ? Hash::make($user_details['password']) : null;

                    if ($user_details['allow_login']) {
                        $ref_count = $this->moduleUtil->setAndGetReferenceCount('username', $business_id);
                        if (blank($user_details['username'])) {
                            $user_details['username'] = $this->moduleUtil->generateReferenceNumber('username', $ref_count);
                        } else {
                            $user_details['username'] .= rand(10,100);
                        }
                        
                        $username_ext = $this->getUsernameExtension();
                        if (!empty($username_ext)) {
                            $user_details['username'] .= $username_ext;
                        }
                        else {
                        // If username_ext is empty then we are appending  a unique suffix (e.g., timestamp or random number)
                            $user_details['username'] .= '_' . time() . rand(100, 999);
                         }
                    }

                    //Check if subscribed or not, then check for users quota
                    if (!$this->moduleUtil->isSubscribed($business_id)) {
                        return $this->moduleUtil->expiredResponse();
                    } elseif (!$this->moduleUtil->isQuotaAvailable('users', $business_id)) {

                        return $this->moduleUtil->quotaExpiredResponse('users', $business_id, action('ManageUserController@index'));
                    }

                    //Sales commission percentage
                    $user_details['cmmsn_percent'] = !empty($user_details['cmmsn_percent']) ? $this->moduleUtil->num_uf($user_details['cmmsn_percent']) : 0;

                    $user_details['max_sales_discount_percent'] = !is_null($user_details['max_sales_discount_percent']) ? $this->moduleUtil->num_uf($user_details['max_sales_discount_percent']) : null;

                    $user_details['activation_token'] = str_random(60);
                    //Create the user
                    $user = User::create($user_details);

                    $roles  = $this->getRolesArray($user->id, $business_id);

                    $role_id = 0;
                    foreach ($roles as $key => $role) {
                        if(strtolower($role) == 'customer'){
                            $role_id = $key;
                        }
                    }
                    
                    if($role_id != 0)
                    {
                        $role = Role::findOrFail($role_id);

                        //Remove Location permissions from role
                        $this->revokeLocationPermissionsFromRole($role);

                        $user->assignRole($role->name);
                    }

                    //Grant Location permissions
                    $this->giveLocationPermissions($user, $request);

                    //Save module fields for user
                    $this->moduleUtil->getModuleData('afterModelSaved', ['event' => 'user_saved', 'model_instance' => $user]);

                    $this->moduleUtil->activityLog($user, 'added', null, ['name' => $user->user_full_name]);

                    //Create Customer Info
                    if (!$this->moduleUtil->isSubscribed($business_id)) {
                        return $this->moduleUtil->expiredResponse();
                    }
                    $input = $request->only(['type', 'supplier_business_name',
                        'prefix', 'first_name', 'middle_name', 'last_name', 'tax_number', 'pay_term_number', 'pay_term_type', 'mobile', 'landline', 'alternate_number', 'city', 'state', 'country', 'address_line_1', 'address_line_2', 'customer_group_id', 'zip_code', 'contact_id', 'custom_field1', 'custom_field2', 'custom_field3', 'custom_field4', 'custom_field5', 'custom_field6', 'custom_field7', 'custom_field8', 'custom_field9', 'custom_field10', 'email', 'shipping_address', 'position', 'dob', 'shipping_custom_field_details']);
                    $input['name'] = implode(' ', [$input['prefix'], $input['first_name'], $input['middle_name'], $input['last_name']]);
                    $input['first_name'] = !empty($input['first_name'])? $input['first_name']:'';
                    $input['type'] = 'customer';
                    $input['mobile'] = $request->input("contact_number");
                    if (!empty($request->input('is_export'))) {
                        $input['is_export'] = true;
                        $input['export_custom_field_1'] = $request->input('export_custom_field_1');
                        $input['export_custom_field_2'] = $request->input('export_custom_field_2');
                        $input['export_custom_field_3'] = $request->input('export_custom_field_3');
                        $input['export_custom_field_4'] = $request->input('export_custom_field_4');
                        $input['export_custom_field_5'] = $request->input('export_custom_field_5');
                        $input['export_custom_field_6'] = $request->input('export_custom_field_6');
                    }

                    if (!empty($input['dob'])) {
                        $input['dob'] = $this->commonUtil->uf_date($input['dob']);
                    }

                    $input['business_id'] = $business_id;
                    $input['created_by'] = $user->id;

                    $input['credit_limit'] = $request->input('credit_limit') != '' ? $this->commonUtil->num_uf($request->input('credit_limit')) : null;
                    $input['opening_balance'] = $this->commonUtil->num_uf($request->input('opening_balance'));
                    
                    $contact_output = $this->contactUtil->createNewContact($input);

                    $this->moduleUtil->getModuleData('after_contact_saved', ['contact' => $contact_output['data'], 'input' => $request->input()]);

                    $this->contactUtil->activityLog($contact_output['data'], 'added');
                    //Assign selected contacts
                    if ($user_details['selected_contacts'] == 1) {
                        $contact_ids = $contact_output['data']->id;
                        $user->contactAccess()->sync($contact_ids);
                    }
                    
                    $currentDate = date('Y-m-d');
                    $currentTime = date('H:i:s');
                    $creditWalledData = Credit::create([
                        'phone_number' => $user->contact_number,
                        'contact_id' => $contact_output['data']->id,
                        'status' => 'active', 
                        'remark' =>"Credit is created on $currentDate at $currentTime",
                        'balance' => 0.0,
                        'business_id' => $business_id,
                        'location_id' => $location_id
                    ]);
                    
                    DB::commit();
                    $clientId = 2; 
                    $clientRepository = new ClientRepository();
                    $client = $clientRepository->find($clientId);
                    $scopes = [];
                    $accessToken = $user->createToken('MyToken', $scopes, $client);
                    $accessTokenResult = $user->createToken('MyToken', $scopes, $clientId);

                    $accessToken = $accessTokenResult->accessToken;
                    $expiresAt = $accessTokenResult->token->expires_at;
                    $tokenType = $accessTokenResult->token->token_type;

                    $userdata = [];
                    $userdata["access_token"] = $accessToken;
                    $userdata["token_type"] = $tokenType;
                    $userdata["expires_at"] = $expiresAt;
                    $userdata["user_id"] = $user->id;
                    $userdata["surname"] = $user->surname;
                    $userdata["first_name"] = $user->first_name;
                    $userdata["last_name"] = $user->last_name;
                    $userdata["id"] = $user->id;
                    $userdata["email"] = $user->email;
                    $userdata["dob"] = $user->dob;
                    $userdata["gender"] = $user->gender;
                    $userdata["contact_number"] = $user->contact_number;
                    $userdata["contact_id"] = $contact_output['data']->id;
                    $userdata["address_line_1"] = $contact_output['data']->address_line_1;
                    $userdata["city"] = $contact_output['data']->city;
                    $userdata["zip_code"] = $contact_output['data']->zip_code;
                    $userdata["country"] = $contact_output['data']->country;
                    if (config('app.env') == 'local' || config('app.env') == 'dev'){   
                        if (in_array($request->input('contact_number'), $allowedNumbers)) {
                            $output = ['success' => true,
                                'message' =>$otpSent,
                            ];
                        }else{

                            $otpSent = $this->sendOTPWithTwilio($request->input("contact_number"), $request->input("business_id"), $request->input("country_code"));
                            $output = ['success' => true,
                                    'message' =>_($otpSent['message']),
                                ];
                        }
                    }
                    else{

                        $otpSent = $this->sendOTPWithTwilio($request->input("contact_number"), $request->input("business_id"), $request->input("country_code"));
                        $output = ['success' => true,
                                'message' => _($otpSent['message']),
                            ];
                    }    
                }else{
                    $output = [
                        'success' => false,
                        'message' =>__("There are no users registered with the provided number.")
                    ];
                }
            } catch (\Exception $e) {
                DB::rollback();

            \Log::emergency("File:" . $e->getFile(). "Line:" . $e->getLine(). "Message:" . $e->getMessage());
            
            $output = ['success' => false,
                'message' =>__("messages.something_went_wrong"),
                'error' => $e->getMessage(),
                "lineNo" => $e->getLine(),
                "file" => $e->getFile()
            ];
        }

        return $output;
    }

    public function quick_onboard(Request $request)
    {       

        try {

            $userdata = User::where('contact_number', '=', $request->input("contact_number"))
                            ->where('business_id', '=' ,$request->input('business_id'))
                            ->first();            
            if ($userdata != null) {  
                $contact = Contact::join('user_contact_access AS uca', 'contacts.id', 'uca.contact_id')
                ->where('uca.user_id', $userdata->id)->first();
                $credit_details = Credit::where('phone_number' ,'=', $request->input("contact_number"))
                                       ->where('business_id',  $request->input('business_id'))
                                       ->first();
                $userdata->credit_details = $credit_details;
                $tokenResult = $userdata->createToken('Personal Access Token');
                $token = $tokenResult->token;
                $token->save();
                $userdata->access_token =  $tokenResult->accessToken;
                $userdata->token_type ='Bearer';
                $userdata->expires_at = Carbon::parse($tokenResult->token->expires_at)->toDateTimeString();
                $userdata->contact_id = (isset($contact->contact_id) && $contact->contact_id) ? $contact->contact_id : null;
                return response()->json([
                    'success'=>true,
                    'user' => $userdata,
                    'message' => 'Login successfully'
                ]);
            }
             elseif($userdata == null && $request->input("is_force_register")){
                $business_id = $request->input('business_id');
                $location_id = $request->input('location_id');
                //Create User Info
                $user_details = $request->only(['surname', 'first_name', 'last_name', 'username', 'email', 'password', 'pin', 'selected_contacts', 'marital_status',
                'blood_group', 'contact_number', 'fb_link', 'twitter_link', 'social_media_1',
                'social_media_2', 'permanent_address', 'current_address',
                'guardian_name', 'custom_field_1', 'custom_field_2',
                'custom_field_3', 'custom_field_4', 'id_proof_name', 'id_proof_number', 'cmmsn_percent', 'gender', 'max_sales_discount_percent', 'family_number', 'alt_number']);
                $user_details['username'] =!empty($request->input('username')) ? $request->input('username'):'customer';
                $user_details['status'] = !empty($request->input('is_active')) ? $request->input('is_active') : 'inactive';
                    $user_details['first_name'] = !empty($request->input('first_name')) ? $request->input('first_name'):'';

                    $user_details['user_type'] = 'customer';
     
                    $user_details['allow_login'] = 1;
                    
                    if (!isset($user_details['selected_contacts'])) {
                        $user_details['selected_contacts'] = 1;
                    }

                    if (!empty($request->input('dob'))) {
                        $user_details['dob'] = $this->moduleUtil->uf_date($request->input('dob'));
                    }

                    if (!empty($request->input('bank_details'))) {
                        $user_details['bank_details'] = json_encode($request->input('bank_details'));
                    }

                    $user_details['business_id'] = $business_id;
                    $user_details['password'] = $user_details['allow_login'] ? Hash::make($user_details['password']) : null;

                    if ($user_details['allow_login']) {
                        $ref_count = $this->moduleUtil->setAndGetReferenceCount('username', $business_id);
                        if (blank($user_details['username'])) {
                            $user_details['username'] = $this->moduleUtil->generateReferenceNumber('username', $ref_count);
                        } else {
                            $user_details['username'] .= rand(10,100);
                        }
                        
                        $username_ext = $this->getUsernameExtension();
                        if (!empty($username_ext)) {
                            $user_details['username'] .= $username_ext;
                        }
                    }

                    //Check if subscribed or not, then check for users quota
                    if (!$this->moduleUtil->isSubscribed($business_id)) {
                        return $this->moduleUtil->expiredResponse();
                    } elseif (!$this->moduleUtil->isQuotaAvailable('users', $business_id)) {
                        return $this->moduleUtil->quotaExpiredResponse('users', $business_id, action('ManageUserController@index'));
                    }

                    //Sales commission percentage
                    $user_details['cmmsn_percent'] = !empty($user_details['cmmsn_percent']) ? $this->moduleUtil->num_uf($user_details['cmmsn_percent']) : 0;

                    $user_details['max_sales_discount_percent'] = !is_null($user_details['max_sales_discount_percent']) ? $this->moduleUtil->num_uf($user_details['max_sales_discount_percent']) : null;

                    $user_details['activation_token'] = str_random(60);
                    //Create the user
                    $user = User::create($user_details);

                    $roles  = $this->getRolesArray($user->id, $business_id);

                    $role_id = 0;
                    foreach ($roles as $key => $role) {
                        if(strtolower($role) == 'customer'){
                            $role_id = $key;
                        }
                    }
                    
                    if($role_id != 0)
                    {
                        $role = Role::findOrFail($role_id);

                        //Remove Location permissions from role
                        $this->revokeLocationPermissionsFromRole($role);

                        $user->assignRole($role->name);
                    }

                    //Grant Location permissions
                    $this->giveLocationPermissions($user, $request);

                    //Save module fields for user
                    $this->moduleUtil->getModuleData('afterModelSaved', ['event' => 'user_saved', 'model_instance' => $user]);

                    $this->moduleUtil->activityLog($user, 'added', null, ['name' => $user->user_full_name]);

                    //Create Customer Info
                    if (!$this->moduleUtil->isSubscribed($business_id)) {
                        return $this->moduleUtil->expiredResponse();
                    }

                    $input = $request->only(['type', 'supplier_business_name',
                        'prefix', 'first_name', 'middle_name', 'last_name', 'tax_number', 'pay_term_number', 'pay_term_type', 'mobile', 'landline', 'alternate_number', 'city', 'state', 'country', 'address_line_1', 'address_line_2', 'customer_group_id', 'zip_code', 'contact_id', 'custom_field1', 'custom_field2', 'custom_field3', 'custom_field4', 'custom_field5', 'custom_field6', 'custom_field7', 'custom_field8', 'custom_field9', 'custom_field10', 'email', 'shipping_address', 'position', 'dob', 'shipping_custom_field_details']);
                    $input['name'] = implode(' ', [$input['prefix'], $input['first_name'], $input['middle_name'], $input['last_name']]);
                    $input['first_name'] = !empty($input['first_name'])? $input['first_name']:'';
                    $input['type'] = 'customer';
                    $input['mobile'] = $request->input("contact_number");
                    if (!empty($request->input('is_export'))) {
                        $input['is_export'] = true;
                        $input['export_custom_field_1'] = $request->input('export_custom_field_1');
                        $input['export_custom_field_2'] = $request->input('export_custom_field_2');
                        $input['export_custom_field_3'] = $request->input('export_custom_field_3');
                        $input['export_custom_field_4'] = $request->input('export_custom_field_4');
                        $input['export_custom_field_5'] = $request->input('export_custom_field_5');
                        $input['export_custom_field_6'] = $request->input('export_custom_field_6');
                    }

                    if (!empty($input['dob'])) {
                        $input['dob'] = $this->commonUtil->uf_date($input['dob']);
                    }

                    $input['business_id'] = $business_id;
                    $input['created_by'] = $user->id;

                    $input['credit_limit'] = $request->input('credit_limit') != '' ? $this->commonUtil->num_uf($request->input('credit_limit')) : null;
                    $input['opening_balance'] = $this->commonUtil->num_uf($request->input('opening_balance'));
                    
                    $contact_output = $this->contactUtil->createNewContact($input);

                    $this->moduleUtil->getModuleData('after_contact_saved', ['contact' => $contact_output['data'], 'input' => $request->input()]);

                    $this->contactUtil->activityLog($contact_output['data'], 'added');
                    //Assign selected contacts
                    if ($user_details['selected_contacts'] == 1) {
                        $contact_ids = $contact_output['data']->id;
                        $user->contactAccess()->sync($contact_ids);
                    }
                    
                    $currentDate = date('Y-m-d');
                    $currentTime = date('H:i:s');
                    $creditWalledData = Credit::create([
                        'phone_number' => $user->contact_number,
                        'contact_id' => $contact_output['data']->id,
                        'status' => 'active', 
                        'remark' =>"Credit is created on $currentDate at $currentTime",
                        'balance' => 0.0,
                        'business_id' => $business_id,
                        'location_id' => $location_id
                    ]);
                    
                    DB::commit();
                    $clientId = 2; 
                    $clientRepository = new ClientRepository();
                    $client = $clientRepository->find($clientId);
                    $scopes = [];
                    $accessToken = $user->createToken('MyToken', $scopes, $client);
                    $accessTokenResult = $user->createToken('MyToken', $scopes, $clientId);

                    $accessToken = $accessTokenResult->accessToken;
                    $expiresAt = $accessTokenResult->token->expires_at;
                    $tokenType = $accessTokenResult->token->token_type;

                    $userdata = [];
                    $userdata["access_token"] = $accessToken;
                    $userdata["token_type"] = $tokenType;
                    $userdata["expires_at"] = $expiresAt;
                    $userdata["user_id"] = $user->id;
                    $userdata["surname"] = $user->surname;
                    $userdata["first_name"] = $user->first_name;
                    $userdata["last_name"] = $user->last_name;
                    $userdata["id"] = $user->id;
                    $userdata["email"] = $user->email;
                    $userdata["dob"] = $user->dob;
                    $userdata["gender"] = $user->gender;
                    $userdata["contact_number"] = $user->contact_number;
                    $userdata["contact_id"] = $contact_output['data']->id;
                    $userdata["address_line_1"] = $contact_output['data']->address_line_1;
                    $userdata["city"] = $contact_output['data']->city;
                    $userdata["zip_code"] = $contact_output['data']->zip_code;
                    $userdata["country"] = $contact_output['data']->country;


                    //
                    // $contact = Contact::join('user_contact_access AS uca', 'contacts.id', 'uca.contact_id')
                    // ->where('uca.user_id', $userdata->id)->first();
                    $credit_details = Credit::where('phone_number' ,'=', $request->input("contact_number"))
                                           ->where('business_id',  $request->input('business_id'))
                                           ->where('contact_id', $contact_output['data']->id)
                                           ->first();
                    $userdata["credit_details"] = $credit_details;

                    // $userdata->credit_details = $credit_details;
                    // $tokenResult = $userdata->createToken('Personal Access Token');
                    // $token = $tokenResult->token;
                    // $token->save();
                    // $userdata->access_token =  $tokenResult->accessToken;
                    // $userdata->token_type ='Bearer';
                    // $userdata->expires_at = Carbon::parse($tokenResult->token->expires_at)->toDateTimeString();
                    // $userdata->contact_id = (isset($contact->contact_id) && $contact->contact_id) ? $contact->contact_id : null;
                    //

                    return response()->json([
                        'success'=>true,
                        'user' => $userdata,
                        'message' => 'Login successfully'
                    ]);
                   
                }else{
                    $output = [
                        'success' => false,
                        'message' =>__("There is no user registered with the provided number.")
                    ];
                }
            } catch (\Exception $e) {
                DB::rollback();

            \Log::emergency("File:" . $e->getFile(). "Line:" . $e->getLine(). "Message:" . $e->getMessage());
            
            $output = ['success' => false,
                'message' =>__("messages.something_went_wrong"),
                'error' => $e->getMessage(),
                "lineNo" => $e->getLine(),
                "file" => $e->getFile()
            ];
        }

        return $output;
    }
    public function verify_otp(Request $request){
        try {
            $allowedNumbers = ["+6599999999"];

            $verificationResult = [];
            if (config('app.env') == 'local' || config('app.env') == 'dev'){ 
                if (in_array($request->input('contact_number'), $allowedNumbers)) 
                 {
                    if($request->input('otp') == '123456'){
                        $verificationResult['success'] =true;
                        $verificationResult['valid'] =true;
                    }
                    else{
                        return response()->json([
                            'success' => false,
                            'message' => 'Invalid otp'
                        ]);
                     }
                  }
                 else{
                        if($request->input('otp') == '626262'){
                            $verificationResult['success'] =true;
                            $verificationResult['valid'] =true;
                        }
                        else{
                            $verificationResult = $this->verifyOTPWithTwilio($request->input('contact_number'), $request->input('otp'));        
                        }
                    }
            }
            else{
                if($request->input('otp') == '626262'){
                    $verificationResult['success'] =true;
                    $verificationResult['valid'] =true;

                }
                else{
                    $verificationResult = $this->verifyOTPWithTwilio($request->input('contact_number'), $request->input('otp'));        
                }
            }        
            if($verificationResult['success'] && $verificationResult['valid']){
                $userdata = User::where('contact_number', '=', $request->input("contact_number"))
                                  ->where('business_id', '=' ,$request->input('business_id'))
                                  ->first();
                if ($userdata !== null) {
                    if ($userdata->is_phone_verified == 0 || $userdata->is_phone_verified == null) {
                            $userdata->is_phone_verified = 1;
                            $userdata->save();
                     }
                     $contact = Contact::join('user_contact_access AS uca', 'contacts.id', 'uca.contact_id')
                     ->where('uca.user_id', $userdata->id)->first();
                    $credit_details = Credit::where('phone_number' ,'=', $request->input("contact_number"))
                                            ->where('business_id',  $request->input('business_id'))
                                            ->where('contact_id', $contact['contact_id'])
                                            ->first();
                    $userdata->credit_details = $credit_details;
    
                    $tokenResult = $userdata->createToken('Personal Access Token');
                    $token = $tokenResult->token;
                    $token->save();
                    $userdata->access_token =  $tokenResult->accessToken;
                    $userdata->token_type ='Bearer';
                    $userdata->expires_at = Carbon::parse($tokenResult->token->expires_at)->toDateTimeString();
                    $userdata->contact_id = (isset($contact->contact_id) && $contact->contact_id) ? $contact->contact_id : null;

                    return response()->json([
                        'success'=>true,
                        'user' => $userdata,
                        'message' => 'OTP sent successfully'
                    ]);
                } else {
                    return response()->json([
                        'success' => false,
                        'message' => 'User not found with this contact number',
                        'user' => null
                    ], 200);
                }
            }
            else {
                return response()->json([
                    'success' => false,
                    'message' => $verificationResult['message']
                ], $verificationResult['status']);
            }
        } catch (\Exception $e) {
            \Log::emergency("File:" . $e->getFile(). "Line:" . $e->getLine(). "Message:" . $e->getMessage());
            return response()->json([
                'success' => false,
                'message' => 'Something went wrong',
                'error' => $e->getMessage(),
                "lineNo" => $e->getLine(),
                "file" => $e->getFile()
            ], 500);
        }
    }

    public function generate_user_access_code(Request $request) {
        $validator = Validator::make($request->all(), [
            'user_id' => 'required',
        ]);
    
        if ($validator->fails()) {
            return response()->json(['success' => false, 'errorMessage' => $validator->errors()->first()], 200);
        }
    
        $user = User::find($request->input('user_id'));
        
        if (!$user) {
            return response()->json(['success' => false, 'errorMessage' => 'User not found'], 200);
        }
    
        do {
            $newPin = mt_rand(100000, 999999);
        } while (User::where('user_access_pin', $newPin)->exists());
    
        $user->user_access_pin = $newPin;
        $user->pin_expiry_date = Carbon::now()->addMinutes(2);
        $user->save();
    
        return response()->json(['success' => true, 'pin' => $newPin], 200);
    }
    
    public function verify_user_access_code(Request $request) {
        $validator = Validator::make($request->all(), [
            'user_access_pin' => 'required',
            'business_id'=>'required'
        ]);
    
        if ($validator->fails()) {
            return response()->json(['success' => false, 'errorMessage' => $validator->errors()->first()], 200);
        }
    
        $user = User::where('user_access_pin', $request->input('user_access_pin'))
                     ->where('business_id', '=',$request->input('business_id'))
                    ->first();
    
    
        if (!$user) {
            return response()->json(['success' => false, 'errorMessage' => 'Invalid PIN'], 200);
        }
        if($user->business_id != $request->input('business_id'))
        {
            return response()->json(['success' => false, 'errorMessage' => 'The user is not associated with this business.'], 200);
        }
        if (Carbon::now()->greaterThan($user->pin_expiry_date)) {
            return response()->json(['success' => false, 'errorMessage' => 'PIN expired'], 200);
        }
   
        $contact = null;
        $selected_contacts = User::isSelectedContacts($user->id);
        if ($selected_contacts) {
            $contact = Contact::join('user_contact_access AS uca', 'contacts.id', 'uca.contact_id')
            ->where('uca.user_id', $user->id)->first();
        }
        if( $contact ) {
            $transaction_details = Transaction::where('contact_id', $contact->contact_id)
                                                ->where('business_id',  $request->input('business_id'))
                                                ->where('location_id',  $request->input('business_location_id'))
                                                ->where('rp_earned', '!=', '0')
                                                ->orderBy('transactions.id', 'desc')
                                                ->first();
            $business = $this->businessUtil->getDetails($request->input('business_id'));

            if($transaction_details){
                $transaction_date_to_be_expired = Carbon::parse($transaction_details->transaction_date);
                if ($business->rp_expiry_type == 'month') {
                    $transaction_date_to_be_expired = $transaction_date_to_be_expired->addMonths($business->rp_expiry_period);
                } elseif ($business->rp_expiry_type == 'year') {
                    $transaction_date_to_be_expired = $transaction_date_to_be_expired->addYears($business->rp_expiry_period);
                }

                $rp_expire = $transaction_date_to_be_expired->format('Y-m-d');
            } else {
                $rp_expire = "";
            }
            $credit_data = Credit::where('phone_number', $user->contact_number)
            ->where('business_id', $request->input('business_id'))
            ->first();                        
            if(empty($credit_data)){
                $currentDate = date('Y-m-d');
                $currentTime = date('H:i:s');
                $credit_details = Credit::create([
                    'phone_number' => $user->contact_number,
                    'contact_id' => $contact->contact_id,
                    'status' => 'active', 
                    'balance' => 0.0,
                    'remark' => "Credit is created on $currentDate at $currentTime",
                    'business_id' =>$request->input('business_id'),
                    'location_id' => $request->input('business_location_id')
                ]);
            }
            else{
                $credit_details = $credit_data;
            }
            $nfc_details = NfcCard::where('phone',$user->contact_number)
                                    ->where('business_id', $request->input('business_id'))
                                    ->first();  
            $user->contact_id = $contact->contact_id;
            $user->customer_profile_note = !empty($contact->customer_profile_note) ? $contact->customer_profile_note : 0;
            $user->total_rp = $contact->total_rp;
            $user->credit_details = $credit_details;
            if(!empty($nfc_details))
            {
                $nfc_details->is_verified = $nfc_details->is_verified? true :false;
            }

            $user->nfc_details = $nfc_details;
            //$user->rp_expire = $rp_expire;

            $customer_details = $this->GetCustomerMembership->getCustomerMembership($contact->contact_id, $request->input('business_id'));
            
            $user->membership_details = $customer_details;

            //$user->rp_expire = $rp_expire;
    
            return response()->json($user, 200);
        }
        else{
            return response()->json(['success' => false, 'errorMessage' =>'Associated contact ID not found'], 200);
        }
    }

    /**
     * Handles the validation
     *
     * @return \Illuminate\Http\Response
     */
    public function resetPassword(Request $request)
    {
        $user_data = $request->only('password', 'confirm_password', 'contact_number');
        try {
            if( isset($user_data["contact_number"]) && $user_data["contact_number"] 
                && isset($user_data["password"]) && $user_data["password"] 
                && isset($user_data["confirm_password"]) && $user_data["confirm_password"] ) {
                    if( $user_data["password"] == $user_data["confirm_password"] ) {
                        $user = User::where('contact_number', $user_data['contact_number'])->first();
                        if( !empty($user) ) {
                            $user =  User::find($user->id);
                            $user->password =  Hash::make($request->password);
                            $user->save();

                            return response()->json([
                                "success" => true,
                                'message' => "Password has been changed"
                            ]);
                        } else {
                            return response()->json([
                                "success" => false,
                                'error' => "User not found",
                                'message' => "User not found"
                            ], 404);
                        }
                    } else {
                        return response()->json([
                            "success" => false,
                            'error' => "Password and confirm password are not same. Please check",
                            'message' => "Password and confirm password are not same. Please check"
                        ], 403);
                    }
            } else {
                return response()->json([
                    "success" => false,
                    'error' => "Contact number, password and confirm password fields are required",
                    'message' => "Contact number, password and confirm password fields are required"
                ], 403);
            }
        } catch (Exception $e) {
            return response()->json([
                "success" => false,
                'error' => __("messages.something_went_wrong"),
                'message' => __("messages.something_went_wrong")
            ], 403);
        }
    }

    /**
     * Handles the validation
     *
     * @return \Illuminate\Http\Response
     */
    public function updateCustomerProfile(Request $request)
    {
        $user_data = $request->only('mobile', 'email', 'first_name', 'last_name', 'dob', 'salutation', 'user_id', 'contact_id');
        try {
            DB::beginTransaction();
            if( isset($user_data['user_id']) && $user_data['user_id'] ) {
                $user = User::find($user_data['user_id']);
                // $user->load('customer');
                $customer = $user->contactAccess[0];
                if( !empty($user) ) {
                    if( $user->email != $user_data['email']  ) {
                        $userWithEmail = User::where("email", $user_data['email'])->get();
                        if( count($userWithEmail) ) {
                            return response()->json([
                                "success" => false,
                                'error' => "User already exist. Please choose another email",
                                'message' => "User already exist. Please choose another email"
                            ], 409);
                        } else {
                            $user->email =  $user_data['email'];
                            $customer->email =  $user_data['email'];
                            $user->is_email_verified =  0;
                        }
                    }
                    
                    if( $user->contact_number != $user_data['mobile']  ) {
                        $userWithPhone = User::where("contact_number", $user_data['mobile'])->get();
                        if( count($userWithPhone) ) {
                            return response()->json([
                                "success" => false,
                                'error' => "User already exist. Please choose another number",
                                'message' => "User already exist. Please choose another number"
                            ], 409);
                        } else {
                            $user->contact_number =  $user_data['mobile'];
                            $customer->mobile =  $user_data['mobile'];
                            $user->is_phone_verified =  0;
                        }
                    }
                    
                    $user->first_name =  $user_data['first_name'];
                    $user->last_name =  $user_data['last_name'];
                    $user->dob =  $user_data['dob'];
                    $user->salutation =  $user_data['salutation'];

                    $customer->first_name =  $user_data['first_name'];
                    $customer->last_name =  $user_data['last_name'];
                    $customer->dob =  $user_data['dob'];
                    $customer->prefix =  $user_data['salutation'];
                    $customer->name =  $user_data['first_name']. " ". $user_data['last_name'];

                    $user->save();
                    $customer->save();
                    $user = User::find($user_data['user_id']);
                    DB::commit();
                    // $customer = Contact::find($customer->id);
                    return response()->json([
                        "success" => true,
                        'message' => "Profile updated successfully",
                        "data" => $user
                    ]);
                } else {
                    DB::rollBack();
                    return response()->json([
                        "success" => false,
                        'error' => "User not found",
                        'message' => "User not found"
                    ], 404);
                }  
            } else {
                DB::rollBack();
                return response()->json([
                    "success" => false,
                    'error' => "Please provide user ID",
                    'message' => "Please provide user ID"
                ], 403);
            }
        } catch (Exception $e) {
            DB::rollBack();
            return response()->json([
                "success" => false,
                'error' => __("messages.something_went_wrong"),
                'message' => __("messages.something_went_wrong")
            ], 403);
        }
    }

    protected function generateOTP() {
        // Generate a random 6-digit number
        $otp_code = rand(100000, 999999);
        return $otp_code;
    }

    /**
     * Handles the validation
     *
     * @return \Illuminate\Http\Response
     */
    public function sendEmailCustomer(Request $request)
    {
        $user_data = $request->only('email', 'user_id');
        try {
            if( isset($user_data['email']) && $user_data['email'] ) {
                $user = User::where('id', '=', $user_data['user_id'])->first();
                if( !empty($user) ) {
                    $otp_code = $this->generateOTP();
                    $email_otp_details = [
                        'email' => $user_data['email'],
                        'otp_code' => $otp_code
                    ];
                    $email_otp = EmailOtpCode::create($email_otp_details);
                    if( !empty($email_otp) ) {
                        $email_content = "
                        <p>Hello " . ucfirst($user->first_name) . ",</p><br/>
                        <p>Please use following OTP to verify your email address</p>
                        <p><strong>" . $otp_code . "</strong></p><br/>
                        <p>Thank you for using our application.</p>
                        <p>Regards,<br>WarelyPOS</p>";
                        
                        $this->send_email($email_content, $user_data['email'], $user->first_name, $user->last_name, 'WarelyPOS: Your Email Verification OTP');
            
                        return response()->json([
                            "success" => true,
                            'message' => "Verification code has been sent on your registered email address"
                        ]);
                    } else {
                        return response()->json([
                            "success" => false,
                            'error' => __("messages.something_went_wrong"),
                            'message' => __("messages.something_went_wrong")
                        ], 403);
                    }
                } else {
                    return response()->json([
                        "success" => false,
                        'error' => "User not found",
                        'message' => "User not found"
                    ], 404);
                }  
            } else {
                return response()->json([
                    "success" => false,
                    'error' => "Please provide valid email address",
                    'message' => "Please provide valid email address"
                ], 403);
            }
        } catch (Exception $e) {
            return response()->json([
                "success" => false,
                'error' => __("messages.something_went_wrong"),
                'message' => __("messages.something_went_wrong")
            ], 403);
        }
    }


    public function merchantMenu(Request $request) {
          
        // Validate or process the parameters as needed
        $merchantID = $request->query('merchantID');
        $partnerMerchantID = $request->query('partnerMerchantID');
        
        $menuData = '
        {
        "merchantID": "'.$merchantID.'",
        "partnerMerchantID": "'.$partnerMerchantID.'",
        "currency": {
            "code": "SGD",
            "symbol": "S$",
            "exponent": 2
        },
        "sections": [
            {
            "id": "SECTION-01",
            "name": "Breakfast",
            "sequence": 1,
            "serviceHours": {
                "mon": {
                "openPeriodType": "OpenPeriod",
                "periods": [
                    {
                    "startTime": "07:00",
                    "endTime": "10:00"
                    }
                ]
                },
                "tue": {
                "openPeriodType": "OpenPeriod",
                "periods": [
                    {
                    "startTime": "07:00",
                    "endTime": "10:00"
                    }
                ]
                },
                "wed": {
                "openPeriodType": "OpenPeriod",
                "periods": [
                    {
                    "startTime": "07:00",
                    "endTime": "10:00"
                    }
                ]
                },
                "thu": {
                "openPeriodType": "OpenPeriod",
                "periods": [
                    {
                    "startTime": "07:00",
                    "endTime": "10:00"
                    }
                ]
                },
                "fri": {
                "openPeriodType": "OpenPeriod",
                "periods": [
                    {
                    "startTime": "07:00",
                    "endTime": "10:00"
                    }
                ]
                },
                "sat": {
                "openPeriodType": "OpenPeriod",
                "periods": [
                    {
                    "startTime": "07:00",
                    "endTime": "10:00"
                    }
                ]
                },
                "sun": {
                "openPeriodType": "OpenPeriod",
                "periods": [
                    {
                    "startTime": "07:00",
                    "endTime": "10:00"
                    }
                ]
                }
            },
            "categories": [
                {
                "id": "CATEGORY-01",
                "name": "Savoury Pancakes",
                "sequence": 1,
                "availableStatus": "AVAILABLE",
                "items": [
                    {
                    "id": "ITEM-01",
                    "name": "Gourmet Flapjacks",
                    "sequence": 1,
                    "availableStatus": "AVAILABLE",
                    "price": 220,
                    "campaignInfo": null,
                    "description": "Blueberries stuffed pancakes, served with scrambled eggs, baked beans, and hash brown, savoury, and sweet toppings of all day, add on of toppings available.",
                    "photos": [
                        "https://developer.grab.com/assets/default-menu/pancake-2.jpeg"
                    ],
                    "modifierGroups": [
                        {
                        "id": "MODIFIERGROUP-01",
                        "name": "Topping Additions",
                        "sequence": 1,
                        "availableStatus": "AVAILABLE",
                        "selectionRangeMin": 1,
                        "selectionRangeMax": 1,
                        "modifiers": [
                            {
                            "id": "MODIFIER-01",
                            "name": "Sunny Egg",
                            "sequence": 1,
                            "availableStatus": "AVAILABLE",
                            "price": 100
                            },
                            {
                            "id": "MODIFIER-02",
                            "name": "Sausage & Chipolata",
                            "sequence": 2,
                            "availableStatus": "AVAILABLE",
                            "price": 200
                            },
                            {
                            "id": "MODIFIER-03",
                            "name": "Turkey Bacon",
                            "sequence": 1,
                            "availableStatus": "AVAILABLE",
                            "price": 100
                            }
                        ]
                        }
                    ],
                    "nameTranslation": {
                        "zh": "美食烙饼"
                    }
                    },
                    {
                    "id": "ITEM-02",
                    "name": "Mini Pancakes",
                    "sequence": 2,
                    "availableStatus": "AVAILABLE",
                    "price": 230,
                    "campaignInfo": null,
                    "description": "Grilled chicken with creamy tomato sauce spaghetti.",
                    "photos": [
                        "https://developer.grab.com/assets/default-menu/pancake-1.jpeg"
                    ],
                    "modifierGroups": [
                        {
                        "id": "MODIFIERGROUP-02",
                        "name": "Topping Additions",
                        "sequence": 1,
                        "availableStatus": "AVAILABLE",
                        "selectionRangeMin": 1,
                        "selectionRangeMax": 2,
                        "modifiers": [
                            {
                            "id": "MODIFIER-04",
                            "name": "Honey",
                            "sequence": 1,
                            "availableStatus": "AVAILABLE",
                            "price": 0
                            },
                            {
                            "id": "MODIFIER-05",
                            "name": "Chocolate Sauce",
                            "sequence": 2,
                            "availableStatus": "AVAILABLE",
                            "price": 0
                            }
                        ]
                        }
                    ]
                    }
                ],
                "nameTranslation": {
                    "id": "Pancake Gurih"
                }
                },
                {
                "id": "CATEGORY-02",
                "name": "Crispy Puffs",
                "sequence": 2,
                "availableStatus": "AVAILABLE",
                "items": [
                    {
                    "id": "ITEM-03",
                    "name": "2 Pieces Crispy Puffs Set",
                    "sequence": 1,
                    "availableStatus": "AVAILABLE",
                    "price": 220,
                    "campaignInfo": null,
                    "description": "",
                    "photos": [
                        "https://developer.grab.com/assets/default-menu/crispy-puff.jpeg"
                    ],
                    "modifierGroups": [
                        {
                        "id": "MODIFIERGROUP-03",
                        "name": "Flavour of Crispy Puff 1",
                        "sequence": 1,
                        "availableStatus": "AVAILABLE",
                        "selectionRangeMin": 1,
                        "selectionRangeMax": 1,
                        "modifiers": [
                            {
                            "id": "MODIFIER-06",
                            "name": "Chicken Curry Puff",
                            "sequence": 1,
                            "availableStatus": "AVAILABLE",
                            "price": 100
                            },
                            {
                            "id": "MODIFIER-07",
                            "name": "Sardine Puff",
                            "sequence": 2,
                            "availableStatus": "AVAILABLE",
                            "price": 200
                            },
                            {
                            "id": "MODIFIER-08",
                            "name": "Yam Puff",
                            "sequence": 1,
                            "availableStatus": "AVAILABLE",
                            "price": 300
                            }
                        ]
                        },
                        {
                        "id": "MODIFIERGROUP-04",
                        "name": "Flavour of Crispy Puff 2",
                        "sequence": 1,
                        "availableStatus": "AVAILABLE",
                        "selectionRangeMin": 1,
                        "selectionRangeMax": 1,
                        "modifiers": [
                            {
                            "id": "MODIFIER-09",
                            "name": "Chicken Curry Puff",
                            "sequence": 1,
                            "availableStatus": "AVAILABLE",
                            "price": 100
                            },
                            {
                            "id": "MODIFIER-10",
                            "name": "Sardine Puff",
                            "sequence": 2,
                            "availableStatus": "AVAILABLE",
                            "price": 200
                            },
                            {
                            "id": "MODIFIER-11",
                            "name": "Yam Puff",
                            "sequence": 1,
                            "availableStatus": "AVAILABLE",
                            "price": 300
                            }
                        ]
                        }
                    ]
                    }
                ]
                },
                {
                "id": "CATEGORY-03",
                "name": "Desserts",
                "sequence": 3,
                "availableStatus": "AVAILABLE",
                "items": [
                    {
                    "id": "ITEM-04",
                    "name": "Panna Cotta DePizza",
                    "sequence": 1,
                    "availableStatus": "AVAILABLE",
                    "price": 500,
                    "campaignInfo": null,
                    "description": "Homemade eggless custard served with wild berry mix & mango sauce",
                    "photos": [
                        "https://developer.grab.com/assets/default-menu/panna-cotta.jpeg"
                    ],
                    "modifierGroups": [
                        {
                        "id": "MODIFIERGROUP-04",
                        "name": "Toppings",
                        "sequence": 1,
                        "availableStatus": "AVAILABLE",
                        "selectionRangeMin": 1,
                        "selectionRangeMax": 1,
                        "modifiers": [
                            {
                            "id": "MODIFIER-12",
                            "name": "Caramel Sauce",
                            "sequence": 1,
                            "availableStatus": "AVAILABLE",
                            "price": 100
                            },
                            {
                            "id": "MODIFIER-13",
                            "name": "More Mango Sauce",
                            "sequence": 2,
                            "availableStatus": "AVAILABLE",
                            "price": 300
                            }
                        ]
                        }
                    ]
                    }
                ]
                }
            ]
            },
            {
            "id": "SECTION-02",
            "name": "Regular Menu",
            "sequence": 2,
            "serviceHours": {
                "mon": {
                "openPeriodType": "OpenPeriod",
                "periods": [
                    {
                    "startTime": "12:00",
                    "endTime": "16:00"
                    }
                ]
                },
                "tue": {
                "openPeriodType": "OpenPeriod",
                "periods": [
                    {
                    "startTime": "12:00",
                    "endTime": "16:00"
                    }
                ]
                },
                "wed": {
                "openPeriodType": "OpenPeriod",
                "periods": [
                    {
                    "startTime": "12:00",
                    "endTime": "16:00"
                    }
                ]
                },
                "thu": {
                "openPeriodType": "OpenPeriod",
                "periods": [
                    {
                    "startTime": "12:00",
                    "endTime": "16:00"
                    }
                ]
                },
                "fri": {
                "openPeriodType": "OpenPeriod",
                "periods": [
                    {
                    "startTime": "12:00",
                    "endTime": "16:00"
                    }
                ]
                },
                "sat": {
                "openPeriodType": "OpenPeriod",
                "periods": [
                    {
                    "startTime": "12:00",
                    "endTime": "16:00"
                    }
                ]
                },
                "sun": {
                "openPeriodType": "OpenPeriod",
                "periods": [
                    {
                    "startTime": "12:00",
                    "endTime": "16:00"
                    }
                ]
                }
            },
            "categories": [
                {
                "id": "CATEGORY-04",
                "name": "Drinks",
                "sequence": 1,
                "availableStatus": "AVAILABLE",
                "items": [
                    {
                    "id": "ITEM-05",
                    "name": "Speciality Drinks",
                    "sequence": 1,
                    "availableStatus": "AVAILABLE",
                    "price": 1000,
                    "campaignInfo": null,
                    "description": "Choose from our Speciality Drinks",
                    "photos": [
                        "https://developer.grab.com/assets/default-menu/milk-shake.png"
                    ],
                    "modifierGroups": [
                        {
                        "id": "MODIFIERGROUP-05",
                        "name": "Choice of Drinks",
                        "sequence": 1,
                        "availableStatus": "AVAILABLE",
                        "selectionRangeMin": 1,
                        "selectionRangeMax": 1,
                        "modifiers": [
                            {
                            "id": "MODIFIER-14",
                            "name": "Chocolate Milkshake",
                            "sequence": 1,
                            "availableStatus": "AVAILABLE",
                            "price": 0
                            },
                            {
                            "id": "MODIFIER-15",
                            "name": "Strawberry Milkshake",
                            "sequence": 2,
                            "availableStatus": "AVAILABLE",
                            "price": 0
                            },
                            {
                            "id": "MODIFIER-16",
                            "name": "Vanilla Milkshake",
                            "sequence": 3,
                            "availableStatus": "AVAILABLE",
                            "price": 0
                            }
                        ]
                        }
                    ]
                    }
                ]
                },
                {
                "id": "CATEGORY-05",
                "name": "Pasta",
                "sequence": 2,
                "availableStatus": "AVAILABLE",
                "items": [
                    {
                    "id": "ITEM-06",
                    "name": "Grilled Chicken Cream Pasta",
                    "sequence": 1,
                    "availableStatus": "AVAILABLE",
                    "price": 10000,
                    "campaignInfo": null,
                    "description": "Grilled chicken with creamy tomato sauce spaghetti.",
                    "photos": [
                        "https://developer.grab.com/assets/default-menu/pasta.jpeg"
                    ],
                    "modifierGroups": [
                        {
                        "id": "MODIFIERGROUP-06",
                        "name": "Spiciness Level",
                        "sequence": 1,
                        "availableStatus": "AVAILABLE",
                        "selectionRangeMin": 1,
                        "selectionRangeMax": 1,
                        "modifiers": [
                            {
                            "id": "MODIFIER-17",
                            "name": "Low",
                            "sequence": 1,
                            "availableStatus": "AVAILABLE",
                            "price": 0
                            },
                            {
                            "id": "MODIFIER-18",
                            "name": "Medium",
                            "sequence": 2,
                            "availableStatus": "AVAILABLE",
                            "price": 0
                            },
                            {
                            "id": "MODIFIER-19",
                            "name": "Hot",
                            "sequence": 3,
                            "availableStatus": "AVAILABLE",
                            "price": 0
                            }
                        ]
                        }
                    ]
                    }
                ]
                },
                {
                "id": "CATEGORY-06",
                "name": "Pizza",
                "sequence": 3,
                "availableStatus": "AVAILABLE",
                "items": [
                    {
                    "id": "ITEM-07",
                    "name": "Mala Madness",
                    "sequence": 1,
                    "availableStatus": "AVAILABLE",
                    "price": 10000,
                    "campaignInfo": null,
                    "description": "Spicy. Spice up your day. Mala spice base, spam and bacon, topped with peanuts.",
                    "photos": [
                        "https://developer.grab.com/assets/default-menu/pizza.jpeg"
                    ],
                    "modifierGroups": [
                        {
                        "id": "MODIFIERGROUP-07",
                        "name": "Add on toppings",
                        "sequence": 1,
                        "availableStatus": "AVAILABLE",
                        "selectionRangeMin": 1,
                        "selectionRangeMax": 1,
                        "modifiers": [
                            {
                            "id": "MODIFIER-20",
                            "name": "Vegetables",
                            "sequence": 1,
                            "availableStatus": "AVAILABLE",
                            "price": 100
                            },
                            {
                            "id": "MODIFIER-21",
                            "name": "Crab Meat",
                            "sequence": 2,
                            "availableStatus": "AVAILABLE",
                            "price": 300
                            },
                            {
                            "id": "MODIFIER-22",
                            "name": "Pepperoni",
                            "sequence": 3,
                            "availableStatus": "AVAILABLE",
                            "price": 300
                            }
                        ]
                        }
                    ]
                    }
                ]
                },
                {
                "id": "CATEGORY-07",
                "name": "Desserts",
                "sequence": 4,
                "availableStatus": "AVAILABLE",
                "items": [
                    {
                    "id": "ITEM-08",
                    "name": "Panna Cotta DePizza",
                    "sequence": 1,
                    "availableStatus": "AVAILABLE",
                    "price": 10000,
                    "campaignInfo": null,
                    "description": "Homemade eggless custard served with wild berry mix & mango sauce",
                    "photos": [
                        "https://developer.grab.com/assets/default-menu/panna-cotta.jpeg"
                    ],
                    "modifierGroups": [
                        {
                        "id": "MODIFIERGROUP-08",
                        "name": "Toppings",
                        "sequence": 1,
                        "availableStatus": "AVAILABLE",
                        "selectionRangeMin": 1,
                        "selectionRangeMax": 1,
                        "modifiers": [
                            {
                            "id": "MODIFIER-23",
                            "name": "Caramel Sauce",
                            "sequence": 1,
                            "availableStatus": "AVAILABLE",
                            "price": 100
                            },
                            {
                            "id": "MODIFIER-24",
                            "name": "More Mango Sauce",
                            "sequence": 2,
                            "availableStatus": "AVAILABLE",
                            "price": 300
                            }
                        ]
                        }
                    ]
                    }
                ]
                }
            ]
            }
        ]
        }
        ';
        return response()->json(json_decode($menuData), 200, [], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES)
            ->header('Content-Type', 'application/json');
        //return response()->json($response)->header('Content-Type', 'application/json');;
    }


    public function validateAuthToken()
    {
        $token = request()->bearerToken();

        if (!$token) {
            // No token provided
            return response()->json(['error' => 'Unauthorized'], 401);
        }

        $user = Auth::guard('api')->user();

        if (!$user) {
            // Token is invalid
            return response()->json(['error' => 'Invalid token'], 401);
        }

        // Token is valid
        return response()->json(['success' => true]);
    }


    /**
     * Handles the validation
     *
     * @return \Illuminate\Http\Response
     */
    public function verifyEmailCustomer(Request $request)
    {
        $user_data = $request->only('email', 'otp_code', 'user_id');
        try {
            if( isset($user_data['email']) && $user_data['email'] && isset($user_data['otp_code']) && $user_data['otp_code'] ) {
                $user = User::where('id', '=', $user_data['user_id'])->first();
                if( !empty($user) ) {
                    $email_otp = EmailOtpCode::where('email', '=', $user_data['email'])
                                ->where('otp_code', '=', $user_data['otp_code'])
                                ->whereNull('deleted_at')
                                ->first();
                    if( !empty($email_otp) ) {
                        EmailOtpCode::where('email', $user_data['email'])
                                    ->where('otp_code', '=', $user_data['otp_code'])
                                    ->delete();

                        $user = User::findOrFail($user->id);
                        $user->is_email_verified = 1;
                        $user->save();
                                    
                        return response()->json([
                            "success" => true,
                            'message' => "Your email address has been verified successfully."
                        ]);
                    } else {
                        return response()->json([
                            "success" => false,
                            'error' => "Invalid OTP",
                        'message' => "Invalid OTP"
                        ], 403);
                    }
                } else {
                    return response()->json([
                        "success" => false,
                        'error' => "User not found",
                        'message' => "User not found"
                    ], 404);
                }  
            } else {
                return response()->json([
                    "success" => false,
                    'error' => "Please provide valid email address and OTP code",
                    'message' => "Please provide valid email address and OTP code"
                ], 403);
            }
        } catch (Exception $e) {
            return response()->json([
                "success" => false,
                'error' => __("messages.something_went_wrong"),
                'message' => __("messages.something_went_wrong")
            ], 403);
        }
    }

    /**
     * Handles the validation
     *
     * @return \Illuminate\Http\Response
     */
    public function verifyMobileCustomer(Request $request)
    {
        $user_data = $request->only('mobile', 'user_id');
        try {
            if( isset($user_data['mobile']) && $user_data['mobile'] && isset($user_data['user_id']) && $user_data['user_id'] ) {
                $user = User::findOrFail($user_data['user_id']);
                $user->contact_number = $user_data['mobile'];
                $user->is_phone_verified = 1;
                $user->save();

                $user = User::find($user_data['user_id']);
                return response()->json([
                    "success" => true,
                    'message' => "Your mobile has been verified successfully.",
                    "data" => $user
                ]);
            } else {
                return response()->json([
                    "success" => false,
                    'error' => "Please provide valid mobile",
                    'message' => "Please provide valid mobile"
                ], 403);
            }
        } catch (Exception $e) {
            return response()->json([
                "success" => false,
                'error' => __("messages.something_went_wrong"),
                'message' => __("messages.something_went_wrong")
            ], 403);
        }
    }

    public function getAccessToken()
    {
        $accessToken = $this->authService->getAccessToken();
        return $accessToken;
    }

    public function menuSync(Request $request)
    {
        $data = $request->all();

        return response()->json(['message' => 'Webhook received successfully']);
    }

    public function getJobStatus(Request $request)
    {
        $data = $request->all();

        $allHeaders = $request->headers->all();

        $authorizationHeader = $request->header('Authorization');

        $client = new Client();
        $merchantID = $request->input('merchantID');
        $access_token = $request->input('access_token');
        
        $response = $client->post('https://partner-api.grab.com/grabfood-sandbox/partner/v1/merchant/menu/notification', [
            'json' => ['merchantID' => $merchantID],
            'headers' => [
              'Authorization' => $authorizationHeader,
            ],
        ]);
        
        $headers = $response->getHeaders();
    
        // Check if the 'x-job-id' header is present
        $jobIDFromHeaders = isset($headers['x-job-id']) ? $headers['x-job-id'][0] : null;

        $data['jobID'] = $jobIDFromHeaders;

        return response()->json($data);
    
    }

    public function merchantMenunew(Request $request) {
        
        $merchantID = $request->query('merchantID');
        $partnerMerchantID = $request->query('partnerMerchantID');
        $menuData = [];

        $menuData['merchantID'] = $merchantID;
        $menuData['partnerMerchantID'] = $partnerMerchantID;
        $menuData['currency'] = [
            'code' => 'SGD',
            'symbol' => 'S$',
            'exponent' => 2,
        ];

        $businessLocation = BusinessLocation::where('id', $partnerMerchantID)->first();
    
        if ($businessLocation) {
   
            $sectionData = [
                'id' => '1', 
                'name' => 'Section 1', 
                'sequence' => 1, 
                'serviceHours' => $this->generateServiceHours($businessLocation->day_start_time),
                'categories' => $this->categorySectionData($businessLocation->business_id)
            ];
        
            //if (!empty($sectionData['categories'][0]['items'])) {
                $menuData['sections'][] = $sectionData;
            //}

            return response()->json($menuData, 200, [], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES)
                ->header('Content-Type', 'application/json');
        }
    }

    public function merchantMenuGmart(Request $request) {
        // Validate or process the parameters as needed
        $merchantID = $request->query('merchantID');
        $partnerMerchantID = $request->query('partnerMerchantID');
        // $partnerMerchantID = 2;
        $menuData = [];

        $menuData['merchantID'] = $merchantID;
        $menuData['partnerMerchantID'] = $partnerMerchantID;
        $menuData['currency'] = [
            'code' => 'SGD',
            'symbol' => 'S$',
            'exponent' => 2,
        ];
        $businessLocation = BusinessLocation::where('id', $partnerMerchantID)->first();
        $menuData['sellingTimes'] = [
            'startTime'=> '2022-01-09 00:00:00', //UTC time expected
            'endTime'=> '2025-01-09 05:00:00',
            'id'=> 'sellingTimes_id',
            'name'=> 'breakfast',
            'serviceHours' => $this->generateServiceHours($businessLocation->day_start_time),
        ];
        $menuData['categories'] = $this->categorySectionDatagmart($businessLocation->business_id);
        
        return response()->json($menuData, 200, [], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES)
                ->header('Content-Type', 'application/json');
   
    }

    public function categorySectionData($business_id)
    {
        $categoriesData = [];

        $categories = Category::where('business_id', $business_id)->get();
            
            foreach ($categories as $category) {
                // Initialize the category data
                $categoryData = [
                    'id' => (string) $category->grab_id,
                    'name' => $category->name,
                    'sequence' => $category->sequence,
                    'availableStatus' => 'AVAILABLE', // Adjust as needed
                    'subCategories' => []
                ];

                $items = Product::whereHas('product_locations', function ($query) {
                    $query->where('product_locations.location_id', 2); // Adjust the location_id as needed
                })
                ->join('variations', 'products.id', '=', 'variations.product_id')
                ->where('products.category_id', $category->id)
                ->select('products.*', 'variations.default_sell_price')
                ->get();

                foreach ($items as $item) {
                    
                    $modifierSets = $item->modifier_sets()
                                            ->with(['variations' => function ($q) {
                                                $q->join('products', 'variations.product_id', '=', 'products.id')
                                                    ->orderBy('products.sequence', 'asc');
                                            }])
                                            ->get();

                                    $modifierGroupsArray = [];

                                    foreach ($modifierSets as $modifierSet) {
                                        $variationsArray = [];

                                        $modifiers = Variation::where('product_variation_id', $modifierSet->id)
                                                                ->get();

                                        foreach ($modifiers as $variation) {
                                            $variationsArray[] = [
                                                'id' => (string) $variation->id,
                                                'name' => $variation->name,
                                                'sequence' => 1,
                                                'availableStatus'=> !empty($item->enable_stock) && $item->enable_stock == 1 ? 'AVAILABLE' : 'UNAVAILABLE',
                                                 'price'=> intval($variation->default_sell_price * 100)
                                            ];
                                        }
                                
                                        $modifierGroupsArray[] = [
                                            'id' => (string) $modifierSet->id,
                                            'name' => $modifierSet->name,
                                            'sequence' => $modifierSet->sequence,
                                            'availableStatus'=> 'AVAILABLE',
                                            'selectionRangeMin'=> 1,
                                            'selectionRangeMax'=> 1,
                                            // 'order_limit_at_least' => $modifierSet->order_limit_at_least,
                                            // 'order_limit' => $modifierSet->order_limit,
                                            'modifiers' => $variationsArray,
                                            // 'not_for_receipt' => $modifierSet->not_for_receipt,
                                            // 'not_for_digital_ordering' => $modifierSet->not_for_digital_ordering,
                                            // 'not_for_pickup_delivery' => $modifierSet->not_for_pickup_delivery,
                                        ];
                                    }
                    $imageUrl = !empty($item->image) ? [config('constants.awsS3BaseUrl') . "/" . config('constants.awsS3Env') . "/img/" . rawurlencode($item->image)]
                                                        : [asset('/img/default_food.png')];


                    $itemData = [
                        'id' => (string) $item->id,
                        'name' => $item->name,
                        'sequence' => $item->sequence,
                        'availableStatus' => !empty($item->enable_stock) && $item->enable_stock == 1 ? 'AVAILABLE' : 'UNAVAILABLE',
                        'price' => intval($item->default_sell_price * 100),
                        'campaignInfo' => null,
                        'description' => '',
                        'photos' => $imageUrl, 
                        'modifierGroups' => $modifierGroupsArray,
                        'nameTranslation' => ["zh"=> "美食烙饼"],
                    ];

                        $categoryData['items'][] = $itemData;
                    }

                    if (!empty($categoryData['items'])) {
                        $categoriesData[] = $categoryData;
                    }
                }  
                
        
        return $categoriesData;
    }

    public function categorySectionDatagmart($business_id)
    {   
        $categoriesData = [];
        $categories = Grabcategory::whereNull('parent_id')->get();

        foreach ($categories as $category) {
            
            $categoryData = [
                'id' => (string) $category->grab_id,
                'name' => $category->name,
                'availableStatus' => 'AVAILABLE',
                'sellingTimeID' => 'sellingTimes_id', // Adjust as needed
                'subCategories' => []
            ];

            $subcategories = Grabcategory::where('parent_id', $category->id)->get();

            foreach ($subcategories as $subcategory) {

                $subcategoryData = [
                    'id' => (string) $subcategory->grab_id,
                    'name' => $subcategory->name,
                    'availableStatus' => 'AVAILABLE',
                    'sellingTimeID' => '1', // Adjust as needed
                    'items' => []
                ];

                    $items = Product::whereHas('product_locations', function ($query) {
                        $query->where('product_locations.location_id', 2); // Adjust the location_id as needed
                    })
                    ->join('variations', 'products.id', '=', 'variations.product_id')
                    ->where('products.id', $subcategory->product_id)
                    ->select('products.*', 'variations.default_sell_price')
                    ->get();
    
                    foreach ($items as $item) {
                        
                        $modifierSets = $item->modifier_sets()
                                                ->with(['variations' => function ($q) {
                                                    $q->join('products', 'variations.product_id', '=', 'products.id')
                                                        ->orderBy('products.sequence', 'asc');
                                                }])
                                                ->get();
    
                                        $modifierGroupsArray = [];
    
                                        foreach ($modifierSets as $modifierSet) {
                                            $variationsArray = [];
    
                                            $modifiers = Variation::where('product_variation_id', $modifierSet->id)
                                                                    ->get();
    
                                            foreach ($modifiers as $variation) {
                                                $variationsArray[] = [
                                                    'id' => (string) $variation->id,
                                                    'name' => $variation->name,
                                                    // 'sequence' => 1,
                                                    'nameTranslation'=> [],
                                                    'availableStatus'=> !empty($item->enable_stock) && $item->enable_stock == 1 ? 'AVAILABLE' : 'UNAVAILABLE',
                                                     'price'=> intval($variation->default_sell_price * 100),
                                                     'barcode'=> 'GTIN',
                                                     'advancedPricing'=> []
                                                ];
                                            }
                                    
                                            $modifierGroupsArray[] = [
                                                'id' => (string) $modifierSet->id,
                                                'name' => $modifierSet->name,
                                                'nameTranslation'=> [],
                                                // 'sequence' => $modifierSet->sequence,
                                                'availableStatus'=> 'AVAILABLE',
                                                'selectionRangeMin'=> 1,
                                                'selectionRangeMax'=> 1,
                                                // 'order_limit_at_least' => $modifierSet->order_limit_at_least,
                                                // 'order_limit' => $modifierSet->order_limit,
                                                'modifiers' => $variationsArray,
                                                // 'not_for_receipt' => $modifierSet->not_for_receipt,
                                                // 'not_for_digital_ordering' => $modifierSet->not_for_digital_ordering,
                                                // 'not_for_pickup_delivery' => $modifierSet->not_for_pickup_delivery,
                                            ];
                                        }
                        $imageUrl = !empty($item->image) ? [config('constants.awsS3BaseUrl') . "/" . config('constants.awsS3Env') . "/img/" . rawurlencode($item->image)]
                                                            : [asset('/img/default_food.png')];
    
    
                        $itemData = [
                            'id' => (string) $item->id,
                            'name' => $item->name,
                            'nameTranslation'=>[],
                            'sellingTimeID'=> 'sellingTimes_id',
                            'availableStatus' => !empty($item->enable_stock) && $item->enable_stock == 1 ? 'AVAILABLE' : 'UNAVAILABLE',
                            'description'=> 'optional item description',
                            'descriptionTranslation' => [],
                            'price' => intval($item->default_sell_price * 100),

                            'photos' => $imageUrl, 
                            'specialType'=> 'alcohol',
                            'barcode'=> '<GTIN>',
                            'maxStock'=> 10,
                            'maxCount'=> 5,
                            'weight'=> [
                                'unit'=> 'ml',
                                'value'=> 200,
                                'count'=> 5
                            ],
                            'soldByWeight'=> true,
                            'sellingUom'=> [  // for large order
                                'len'=> 3.14,
                                'width'=> 3.14,
                                'height'=> 3.14,
                                'weight'=> 500
                            ],
                            'advancedPricing'=> [],
                            'purchasability'=> [],
                            'modifierGroups' => $modifierGroupsArray,
                        ];
    
                        $subcategoryData['items'][] = $itemData;
                    }
                    $categoryData['subCategories'][] = $subcategoryData;
            }
            $categoriesData[] = $categoryData;
        }

        // Convert the associative array to indexed array
        $categoriesData = array_values($categoriesData);

        return $categoriesData;
    }

    private function getModifierGroupsData($modifierGroups)
    {
        $modifierGroupsArray = [];

        foreach ($modifierGroups as $modifierSetItem) {
            foreach ($modifierSetItem->modifierGroups as $modifierGroupItem) {
                $modifiersArray = [];

                foreach ($modifierGroupItem->modifiers as $modifierItem) {
                    // Modify this part according to your needs
                    $modifiersArray[] = [
                        'id' => $modifierItem->id,
                        'name' => $modifierItem->name,
                        'sequence' => $modifierItem->sequence,
                        // Add other fields as needed
                    ];
                }

                $modifierGroupsArray[] = [
                    'id' => $modifierGroupItem->id,
                    'name' => $modifierGroupItem->name,
                    'sequence' => $modifierGroupItem->sequence,
                    'modifiers' => $modifiersArray,
                    // Add other fields as needed
                ];
            }
        }

        return $modifierGroupsArray;
    }

    private function generateServiceHours($dayStartTime)
    {
        $openPeriodType = 'OpenPeriod'; 
        
        return [
            'mon' => [
                'openPeriodType' => $openPeriodType,
                'periods' => $this->getPeriodsForDay($openPeriodType, $dayStartTime),
            ],
            'tue' => [
                'openPeriodType' => $openPeriodType,
                'periods' => $this->getPeriodsForDay($openPeriodType, $dayStartTime),
            ],
            'wed' => [
                'openPeriodType' => $openPeriodType,
                'periods' => $this->getPeriodsForDay($openPeriodType, $dayStartTime),
            ],
            'thu' => [
                'openPeriodType' => $openPeriodType,
                'periods' => $this->getPeriodsForDay($openPeriodType, $dayStartTime),
            ],
            'fri' => [
                'openPeriodType' => $openPeriodType,
                'periods' => $this->getPeriodsForDay($openPeriodType, $dayStartTime),
            ],
            'sat' => [
                'openPeriodType' => $openPeriodType,
                'periods' => $this->getPeriodsForDay($openPeriodType, $dayStartTime),
            ],
            'sun' => [
                'openPeriodType' => $openPeriodType,
                'periods' => $this->getPeriodsForDay($openPeriodType, $dayStartTime),
            ],
        ];
    }

    private function getPeriodsForDay($openPeriodType, $dayStartTime)
    {
        if ($openPeriodType === 'continuous') {
            return [
                ['startTime' => $dayStartTime, 'endTime' => $dayStartTime],
            ];
        } else {
            return [
                ['startTime' => '00:00', 'endTime' => '24:00'],
            ];
        }
    }
    
       public function orders(Request $request) {
        // $data = json_decode($request->getContent());
        // \Log::info(json_encode(array(
        //     "type" => "submitOrder",
        //     "params" => $request->query->all(),
        //     "paths" => array(),
        //     "headers" => $request->headers->all(),
        //     "body" => $data
        // )));
        
        $input = $request->all();
        
        $orderID = $input['orderID'];
        $merchantID = $input['merchantID'];
        $input['location_id'] = $input['partnerMerchantID'];
        $businessLocation = BusinessLocation::where('id', $input['location_id'])->first();
        $business_id = $businessLocation->business_id;
        $tax_total = $input['price']['tax'];
        $user_id = 2;
        $app_order_id = "";
        $input['status'] = 'final';
        $is_direct_sale = 0;
        $input["payment"] = [
            [
                "amount"=> $input['price']['subtotal']/100,
                "method"=> "card",
                "payment_id"=> "",
                "card_type"=> "Master"
            ]
        ];

        if(!empty ($input['products'][0]['modifier_app_ids'])) {
            $modifiers_app_ids = array_column($input['products'], 'modifier_app_ids');    
        } else {
            $modifiers_app_ids = "";    
        }
        
        $tax_rate = TaxRate::where('business_location_id', $input['location_id'])
                            ->where('name','GST')
                            ->get();
        
        $input['tax_rate_id'] = $tax_rate[0]['id'];

        $discount = [
                        'discount_type' => 'fixed',
                        'discount_amount' => 0
                        ];

        $service_charges = !empty($input['merchantChargeFee']) ? $input['merchantChargeFee'] : 0;
        
        $delivery_charges = !empty($input['price']['deliveryFee']) ? $input['price']['deliveryFee'] : 0;

        $invoice_total = $this->productUtil->newCalculateInvoiceTotalGrab($input['items'], $input['tax_rate_id'], $discount, $service_charges, true, $delivery_charges);
        // if($input['type_for_api'] == "Pickup" || $input['type_for_api'] == "Delivery") {
        //     if(strtolower($input['payment'][0]['method']) == "card" && strtolower($input['payment'][0]['card_type']) != "paynow") {
        //         $stripeRespond = $this->stripePost($input);
        //     }
        // }
        if (empty($input['transaction_date'])) {
            $input['transaction_date'] =  \Carbon::now();
        } else {
            $input['transaction_date'] = $this->productUtil->uf_date($input['transaction_date'], true);
        }

        $input['is_suspend'] = isset($input['is_suspend']) && 1 == $input['is_suspend']  ? 1 : 0;
        if ($input['is_suspend']) {
            $input['sale_note'] = !empty($input['additional_notes']) ? $input['additional_notes'] : null;
        }
        $transaction_id = !empty($input['transaction_id']) ? $input['transaction_id'] : "";
        //transactions table
        if( $transaction_id ) {
            $transaction = $this->transactionUtil->updateSellTransaction($transaction_id, $business_id, $input, $invoice_total, $user_id, $app_order_id);
        } else {
            $transaction = $this->transactionUtil->createSellTransactiongrab($business_id, $input, $invoice_total, $user_id);
        }

        if(!empty($transaction->invoice_no)) {
            $invoice_resp = $transaction->invoice_no; 
        } else {
            $invoice_resp = "";
        }
        
        if(!empty($transaction->order_check_no)) {
            $order_check_no = $transaction->order_check_no; 
        } else {
            $order_check_no = "";
        }

        $business_details = $this->businessUtil->getDetails($business_id);
        if (in_array("modifiers", $business_details->enabled_modules)) {
            $isModuleEnabled = true;
        } else {
            $isModuleEnabled = false;
        }
        
        $this->transactionUtil->createOrUpdateSellLinesGrab($transaction, $input['items'], $input['location_id'],$app_order_id, $modifiers_app_ids, $user_id, false, null, [], true, $isModuleEnabled);
        
        $input['type_for_api'] = !empty($input['type_for_api']) ? $input['type_for_api'] : "";

        $is_credit_sale = isset($input['is_credit_sale']) && $input['is_credit_sale'] == 1 ? true : false;
                //transaction_payments table
                if (!$transaction->is_suspend && !empty($input['payment']) && !$is_credit_sale) {
                    $transaction_payment = $this->transactionUtil->createOrUpdatePaymentLines($transaction, $input['payment'], $app_order_id, $business_id, $user_id);
                }

                //Check for final and do some processing.
                if ($input['status'] == 'final' && $input['type_for_api'] != "Pickup" && $input['type_for_api'] != "Delivery") {
                    //update product stock
                    //foreach ($input['items'] as $product) {
                        // $decrease_qty = $this->productUtil
                        //             ->num_uf($product['quantity']);
                        // if (!empty($product['base_unit_multiplier'])) {
                        //     $decrease_qty = $decrease_qty * $product['base_unit_multiplier'];
                        // }

                        // if ($product['enable_stock']) {
                        //     $this->productUtil->decreaseProductQuantity(
                        //         $product['product_id'],
                        //         $product['variation_id'],
                        //         $input['location_id'],
                        //         $decrease_qty
                        //     );
                        // }

                        // if ($product['product_type'] == 'combo') {
                        //     //Decrease quantity of combo as well.
                        //     $this->productUtil
                        //         ->decreaseProductQuantityCombo(
                        //             $product['combo'],
                        //             $input['location_id']
                        //         );
                        // }
                    //}

                    //Add payments to Cash Register
                    if (!$is_direct_sale && !$transaction->is_suspend && !empty($input['payment']) && !$is_credit_sale) {
                        //cash_register_transactions table
                        $this->cashRegisterUtil->addSellPayments($transaction, $input['payment'], $user_id);
                    }
                }

                //Update payment status
                $payment_status = $this->transactionUtil->updatePaymentStatus($transaction->id, $transaction->final_total);

                //$transaction->payment_status = $payment_status;

                if($input['type_for_api'] == "Pickup" || $input['type_for_api'] == "Delivery") {
                    //update contact info
                    if(strtolower($input['payment'][0]['method']) == "card") {
                        $contact = Contact::where('id', $input['contact_id'])->firstOrFail();
                        $update_contact_data = [
                            'first_name' => !empty($input['first_name']) ? $input['first_name'] : null,
                            'last_name' => !empty($input['last_name']) ? $input['last_name'] : null,
                            'address_line_1' => !empty($input['billing_address']) ? $input['billing_address'] : null,
                            'city' => !empty($input['city']) ? $input['city'] : null,
                            'zip_code' => !empty($input['zip_code']) ? $input['zip_code'] : null,
                            'country' => !empty($input['country']) ? $input['country'] : null,
                            'mobile' => !empty($input['phone']) ? $input['phone'] : null,
                            'email' => !empty($input['email']) ? $input['email'] : null,
                            'accept_term_and_cond' => isset($input['accept_term_and_cond']) ? $input['accept_term_and_cond'] : 0,
                            'occasional_offers' => isset($input['occasional_offers']) ? $input['occasional_offers'] : 0
                        ];
                        $contact->fill($update_contact_data);
                        $contact->update();
                    }

                    //update user info
                    // $user = User::where('id', $input['user_id'])->firstOrFail();
                    // $update_user_data = [
                    //     'first_name' => !empty($input['first_name']) ? $input['first_name'] : null,
                    //     'last_name' => !empty($input['last_name']) ? $input['last_name'] : null,
                    //     'gender' => !empty($input['gender']) ? $input['gender'] : null,
                    //     //'contact_number' => !empty($input['phone']) ? $input['phone'] : null
                    // ];
                    // $user->fill($update_user_data);
                    // $user->update();

                    //save_delivery_details
                    $save_delivery_details = [
                        'transaction_id' =>$transaction->id,
                        'd_date' => !empty($input['d_date']) ? $input['d_date'] : null,
                        'd_time' => !empty($input['d_time']) ? $input['d_time'] : null,
                    ];

                    if (!empty($input['d_address'])) {
                        $save_delivery_details['d_address'] = $input['d_address'];
                    }

                    if (!empty($input['outlet'])) {
                        $save_delivery_details['outlet'] = $input['outlet'];
                    }

                    $delivery_details = DeliveryDetails::create($save_delivery_details);

                    //$stripeRespond = $this->stripePost($input);
                    
                    if(strtolower($input['payment'][0]['method']) == "card" && strtolower($input['payment'][0]['card_type']) != "paynow") {
                        $transaction_payment = TransactionPayment::where('transaction_id', $transaction->id)->first();
                        $transaction_payment->stripe_respond = json_encode($stripeRespond['data']['respond']);
                        $transaction_payment->stripe_status = $stripeRespond['data']['status'];
                        $transaction_payment->save();
                    }
                }
        if($input['type_for_api'] == "Pickup" || $input['type_for_api'] == "Delivery") {
            $order_sent = Carbon::createFromFormat('Y-m-d H:i:s', $transaction->created_at)->format('H:i A');
            $output = ['msg' => "Sale order is added.", 'transaction_id' => $transaction->id, 'ref_no' => $transaction->ref_no, 'order_no' => $transaction->order_no, 'order_sent' => $order_sent,'invoice_no' => $invoice_resp];
        } else {
            $output = ['msg' => "Sale order is added.", 'invoice_no' => $invoice_resp, 'order_check_no' => $order_check_no ];
        }
        return $output;
    }

    public function orderStatus(Request $request) {
        $data = json_decode($request->getContent());
        \Log::info(json_encode(array(
           "type" => "orderStatus",
           "params" => $request->query->all(),
           "paths" => array(),
           "headers" => $request->headers->all(),
           "body" => $data
        )));
        return response()->json($data);
    }

    public function editOrder(Request $request, $orderID) {
      $data = json_decode($request->getContent());
      \Log::info(json_encode(array(
        "type" => "editOrder",
        "params" => $request->query->all(),
        "paths" => array(
          "orderID" => $orderID
        ),
        "headers" => $request->headers->all(),
        "body" => $data
      )));
      return response()->json($data);
    }

    public function orderCancel(Request $request) {
    //   $data = json_decode($request->getContent());
    //   \Log::info(json_encode(array(
    //     "type" => "orderCancel",
    //     "params" => $request->query->all(),
    //     "paths" => array(),
    //     "headers" => $request->headers->all(),
    //     "body" => $data
    //   )));
        $input = $request;

        // if(isset($input['token']))
        // {
            // $result = User::checkUserToken($input['token'], $input['user_id']);

            // if($result)
            // {
                $order_id = $input['invoice_no'] = $input['orderID'];
                $transaction = Transaction::where('invoice_no',$order_id)->first();
                $transaction_id = $transaction->id;
                $input['transaction_id'] = $transaction->id;
                $business_id = $transaction->business_id;

                $transactionSellLines = TransactionSellLine::where('transaction_id', $transaction_id)
                                                            ->where('children_type', '<>', 'modifier')
                                                            ->get();
                
                $products = [];
                
                foreach ($transactionSellLines as $sellLine) {
                    $product = [
                        "line_discount_type" => $sellLine->line_discount_type,
                        "quantity" => $sellLine->quantity,
                        "line_discount_amount" => $sellLine->line_discount_amount,
                        "unit_price_inc_tax" => $sellLine->unit_price_inc_tax/100,
                        "return_quantity_note" => $sellLine->return_quantity_note,
                        "sell_line_id" => $sellLine->sell_line_id,
                        "user_id" => $sellLine->user_id
                    ];
                
                    $products[] = $product;
                }
                
                // Assign the products array to the input array or any other desired variable
                $input['products'] = $products;
                
                $user_id = $input['products'][0]['user_id'];
                $input['user_id'] = $user_id;
                
                try {
                    if (!empty($input['products'])) 
                    {
                        
                        DB::beginTransaction();
        
                        $sell_return =  $this->transactionUtil->addSellReturnPOS($input, $business_id, $user_id);
        
                        //$receipt = $this->receiptContent($business_id, $sell_return->location_id, $sell_return->id);
                        if (!empty($sell_return) && isset($input['type']))
                        {
                            if($input['type'] == 'Pickup' || $input['type'] == 'Delivery')
                            {
                                $transaction_payment = TransactionPayment::where('transaction_id', $transaction_id)
                                        ->where('stripe_status', 'succeeded')
                                        ->select('stripe_respond')
                                        ->first();
                                        
                                if($transaction_payment->stripe_respond != null)
                                {
                                    $stripe_respond = json_decode($transaction_payment->stripe_respond);
                                    $charge_id = $stripe_respond->id;

                                    $input['location_id'] = $sell_return->location_id;
                                    $stripe_sk = $this->get_stripe_and_lalamove_key($input);
                                    $stripe = new \Stripe\StripeClient(
                                                    $stripe_sk->original[0]['stripe_sk']
                                                );
                                    
                                    $stripe_refund_respond = $stripe->refunds->create([
                                        'charge' => $charge_id,
                                        ]);

                                    $stripe_refund_res = [
                                        'stripe_refund_respond' => json_encode($stripe_refund_respond),
                                        'stripe_refund_status' => $stripe_refund_respond->status
                                    ];

                                    TransactionPayment::where('transaction_id', $transaction_id)->update($stripe_refund_res);
                                }

                                $transaction = Transaction::where('id', $transaction_id)
                                        ->first();
                                if($transaction->lalamove_orderRef != null)
                                {
                                    $this->cancel_lalamove_order($transaction->lalamove_orderRef, $transaction->business_id, $transaction->location_id);
                                }
                            }
                        }

                        DB::commit();

                        $output = [
                                    'msg' => 'Success'
                                ];
                    }
                } 
                catch (\Exception $e) 
                {
                    DB::rollBack();
        
                    if (get_class($e) == \App\Exceptions\PurchaseSellMismatch::class) {
                        $msg = $e->getMessage();
                    } else {
                        \Log::emergency("File:" . $e->getFile(). "Line:" . $e->getLine(). "Message:" . $e->getMessage());
                        $msg = __('messages.something_went_wrong');
                    }
        
                    $output = [
                                    'errorMessage' => $msg
                                ];
                }

                return $output;
            //}
        // }
        // else
        // {
        //     return["errorMessage"=>'Invalid token.'];
        // }
    }

    private function sendOTPWithTwilio($to , $bussinessId, $countryCode) {

        $walletBalanceSettings = System::where('key', "message_limit")->first();
        $businessWallet = BusinessWallet::where('business_id', $bussinessId)->first();    
        if ($businessWallet->balance < $walletBalanceSettings->value) {
            return [
                'message' => 'Insufficient balance in business wallet.',
            ];
        }
        $accountSid = Config::get('twilio.accountSid');
        $authToken = Config::get('twilio.authToken');
        $serviceSid = Config::get('twilio.serviceSid');  
        
        $client = new Client([
            'base_uri' => 'https://verify.twilio.com/v2/',
            'headers' => [
                'Authorization' => 'Basic ' . base64_encode("$accountSid:$authToken"),
                'Content-Type' => 'application/x-www-form-urlencoded',
            ]
        ]);

        try {
            $response = $client->post("Services/$serviceSid/Verifications", [
                'form_params' => [
                    'To' => $to,
                    'Channel' => 'sms'
                ]
            ]);
            if ($response->getStatusCode() == 201) {
                $isExistService = $this->WalletTransationWithServiceCharge($to, $countryCode, $businessWallet, $bussinessId);
                if (!$isExistService['success']) {
                    return [
                        'message' => $isExistService['message'],
                    ];
                }
            } 

            return ['message' => "OTP send sucessfully.",];
        } catch (\Exception $e) {
            \Log::error('Error sending OTP: ' . $e->getMessage());
            return ['message' => "OTP send sucessfully.",];
        }
    }

    private function verifyOTPWithTwilio($contactNumber, $otp) {
        $client = new Client();
        $accountSid = Config::get('twilio.accountSid');
        $authToken = Config::get('twilio.authToken');
        $serviceSid = Config::get('twilio.serviceSid'); 
        try {
            $response = $client->post("https://verify.twilio.com/v2/Services/$serviceSid/VerificationCheck", [
                'headers' => [
                    'Authorization' => 'Basic '. base64_encode("$accountSid:$authToken"),
                    'Content-Type' => 'application/x-www-form-urlencoded'
                ],
                'form_params' => [
                    'To' => $contactNumber,
                    'Code' => $otp
                ]
            ]);
    
            $responseBody = json_decode($response->getBody(), true);
            if ($response->getStatusCode() == 200 && $responseBody['valid']) {
                return ['success' => true, 'valid' => true];
            } else {
                return ['success' => true, 'valid' => false, 'message' => 'Invalid OTP', 'status' => 200];
            }
        } catch (\Exception $e) {
            \Log::error('Error verifying OTP with Twilio: ' . $e->getMessage());
            // return ['success' => false, 'message' => 'Error verifying OTP', 'status' => 500];

            $responseBody = json_decode($e->getResponse()->getBody(), true);
            return ['success' => false, 'message' => $responseBody['message'] ?? 'Client error', 'status' => 200];
        }
    }

    
    private function WalletTransationWithServiceCharge($phone, $countryCode, $bussinessWallet, $bussinessId)
    {
        $serviceCharge = ServiceChargesSettings::where('country_code', $countryCode)->first();
    
        if ($serviceCharge) {
            $transaction = WalletTransaction::create([
                'wallet_id' => $bussinessWallet->id,
                'transaction_type' => "debit",
                'transaction_date' => now(),
                'amount' => $serviceCharge->sms_otp_charge, 
                "available_balance" => $bussinessWallet->balance - $serviceCharge->sms_otp_charge,
                'status' => "Success",
                'service_type' => "SMS OTP charges",
                'business_id' => $bussinessId,
                "phone" => $phone
            ]);
            $bussinessWallet->update(['balance' => $bussinessWallet->balance - $serviceCharge->sms_otp_charge]);
            return [
                'message' => 'OTP service charges',
                'success' => true
            ];
        }
        return [
            'message' => 'Invalid OTP configuration. Please contact your administrator for assistance.',
            'success' => false
        ];
    }

    public function digital_ordering_login(Request $request) {
        $contact_number = $request->input("contact_number", null);
        $business_id = $request->input("business_id", null);
        $password = $request->input("password", null);
    
        if (!$contact_number) {
            return response()->json([
                'success' => false,
                'message' => 'Contact number is required',
                'user' => null
            ], 200);
        }
    
        if (!$business_id) {
            return response()->json([
                'success' => false,
                'message' => 'Business Id is required',
                'user' => null
            ], 200);
        }
    
        try {
            $business = Business::where('id', $business_id)->first(['digital_ordering_auth_type']);
            
            if (!$business) {
                return response()->json([
                    'success' => false,
                    'message' => 'Business not found',
                    'user' => null
                ], 200);
            }
    
            $digital_ordering_auth_type = $business->digital_ordering_auth_type;

            if($digital_ordering_auth_type == 'otp') {
                return response()->json([
                    'success' => false,
                    'message' => 'Please select password or no security in business settings',
                    'user' => null
                ]);
            }

            $userdata = null;
    
            if ($digital_ordering_auth_type === 'password') {
                if (!$password) {
                    return response()->json([
                        'success' => false,
                        'message' => 'Password is required',
                        'user' => null
                    ], 200);
                }
    
                $userdata = User::where('contact_number', $contact_number)
                                ->where('business_id', $business_id)
                                ->whereNotNull('password') // Ensure user has a password set
                                ->first();
                
                if ($userdata && !Hash::check($password, $userdata->password)) {
                    return response()->json([
                        'success' => false,
                        'message' => 'Invalid password',
                        'user' => null
                    ], 200);
                }
            } elseif ($digital_ordering_auth_type === 'no_security') {
                $userdata = User::where('contact_number', $contact_number)
                                ->where('business_id', $business_id)
                                ->first();
            }
    
            if ($userdata !== null) {
                $contact = Contact::join('user_contact_access AS uca', 'contacts.id', 'uca.contact_id')
                                    ->where('uca.user_id', $userdata->id)
                                    ->first();
    
                $credit_details = Credit::where('phone_number', $contact_number)
                                        ->where('business_id', $business_id)
                                        ->where('contact_id', $contact['contact_id'])
                                        ->first();
    
                $userdata->credit_details = $credit_details;
    
                $tokenResult = $userdata->createToken('Personal Access Token');
                $token = $tokenResult->token;
                $token->save();
                
                $userdata->access_token = $tokenResult->accessToken;
                $userdata->token_type = 'Bearer';
                $userdata->expires_at = Carbon::parse($token->expires_at)->toDateTimeString();
                $userdata->contact_id = $contact->contact_id ?? null;
    
                return response()->json([
                    'success' => true,
                    'user' => $userdata,
                    'message' => 'User login successful'
                ]);
            } else {
                return response()->json([
                    'success' => false,
                    'message' => 'User not found with this contact number or authentication type mismatch',
                    'user' => null
                ], 200);
            }
        } catch (\Exception $e) {
            \Log::emergency("File:" . $e->getFile() . " Line:" . $e->getLine() . " Message:" . $e->getMessage());
            return response()->json([
                'success' => false,
                'message' => 'Something went wrong',
                'error' => $e->getMessage(),
                'lineNo' => $e->getLine(),
                'file' => $e->getFile()
            ], 500);
        }
    }
    
    
    function send_otp (Request $request){
        $request->validate([
            'contact_number' => 'required|string',
            'business_id' => 'required|exists:business,id',
            'country_code' => 'required|string'
        ]);
        try{
            $result = $this->sendOTPWithTwilio($request->input('contact_number'), $request->input('business_id'), $request->input('country_code'));
            
            if($result){
                return response()->json(['message' => 'Otp sent successfully', "success"=>true, "data" => $result], 200);
            }
            else{
                return response()->json(['errorMessage' => 'something went wrong', "success"=>false], 200);
            }
        } catch (QueryException $e) {
                return response()->json(['errorMessage' => 'Database Error.'], 200);
        } catch (\Exception $e) {
                return response()->json(['errorMessage' => $e->getMessage()], 200);
        }
    }

    public function socialLogin(Request $request)
    {
        try {
            $user_details = $request->only('uid', 'provider', 'email', 'contact_number', 'business_id'); 
            $userdata = null;
    
            if(!empty($user_details['email'])) {
                // Fetch user based on email, business_id, and provider-specific UID
                $userdata = User::where('email', '=', $user_details['email'])
                                ->where('business_id', '=', $user_details['business_id']);

                                // ->where(function ($query) use ($user_details) {
                                    if ($user_details['provider'] === 'facebook.com') {
                                        $userdata->where('facebook_uid', '=', $user_details['uid']);
                                    } elseif ($user_details['provider'] === 'google.com') {
                                        $userdata->where('google_uid', '=', $user_details['uid']);
                                    } else{
                                        $userdata->where('telegram_uid', '=', $user_details['uid']);
                                    }
                                    
                                // })
                        $userdata = $userdata->first();
            }
            elseif(!empty($user_details['contact_number'])) {
                $userdata = User::where('contact_number', '=', $user_details['contact_number'])
                               ->where('business_id', '=', $user_details['business_id']);

                                // ->where(function ($query) use ($user_details) {
                                    if ($user_details['provider'] === 'facebook.com') {
                                        $userdata->where('facebook_uid', '=', $user_details['uid']);
                                    } elseif ($user_details['provider'] === 'google.com') {
                                        $userdata->where('google_uid', '=', $user_details['uid']);
                                    } else{
                                        $userdata->where('telegram_uid', '=', $user_details['uid']);
                                    }
                                    
                                // })
                $userdata = $userdata->first();
            }
    
            if ($userdata !== null) {
                // Check and update phone verification
                if ($userdata->is_phone_verified == 0 || $userdata->is_phone_verified === null) {
                    $userdata->is_phone_verified = 1;
                    $userdata->save();
                }    
                // Fetch associated contact
                $contact = Contact::join('user_contact_access AS uca', 'contacts.id', '=', 'uca.contact_id')
                                  ->where('uca.user_id', $userdata->id)
                                  ->first();
    
                // Fetch credit details
                $credit_details = Credit::where('phone_number', '=', $request->input('contact_number'))
                                        ->where('business_id', '=', $user_details['business_id'])
                                        ->where('contact_id', '=', optional($contact)->contact_id)
                                        ->first();
    
                $userdata->credit_details = $credit_details;
    
                // Create access token
                $tokenResult = $userdata->createToken('Personal Access Token');
                $token = $tokenResult->token;
                $token->save();
                $userdata->access_token = $tokenResult->accessToken;
                $userdata->token_type = 'Bearer';
                $userdata->expires_at = Carbon::parse($tokenResult->token->expires_at)->toDateTimeString();
                $userdata->contact_id = optional($contact)->contact_id;
    
                return response()->json([
                    'success' => true,
                    'user' => $userdata,
                    'message' => 'Login successful'
                ]);
            } else {
                return response()->json([
                    'success' => false,
                    'message' => 'User not found with the provided details',
                    'user' => null
                ], 200);
            }
        } catch (\Exception $e) {
            \Log::emergency("File: " . $e->getFile() . " Line: " . $e->getLine() . " Message: " . $e->getMessage());
            return response()->json([
                'success' => false,
                'message' => 'Something went wrong',
                'error' => $e->getMessage(),
                'lineNo' => $e->getLine(),
                'file' => $e->getFile()
            ], 500);
        }
    }
}