<?php

namespace App\Http\Controllers\API;

use DB;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\BusinessLocation;
use App\User;
use App\CashRegister;
use App\Product;
use App\Category;
use App\TaxRate;
use App\Variation;
use App\Transaction;
use App\TransactionSellLine;
use App\ApiPrinter;
use App\PrinterCategories;
use App\Utils\ProductUtil;
use App\Utils\TransactionUtil;
use App\Utils\CashRegisterUtil;
use App\Utils\ContactUtil;
use App\Utils\BusinessUtil;

class ApiPrinterController extends Controller
{
    /**
     * All Utils instance.
     *
     */
    protected $contactUtil;
    protected $productUtil;
    protected $transactionUtil;
    protected $cashRegisterUtil;
    protected $businessUtil;

    /**
     * Constructor
     *
     * @param ProductUtils $product
     * @return void
     */
    public function __construct(
        ContactUtil $contactUtil,
        ProductUtil $productUtil,
        TransactionUtil $transactionUtil,
        CashRegisterUtil $cashRegisterUtil,
        BusinessUtil $businessUtil
    ) {
        $this->contactUtil = $contactUtil;
        $this->productUtil = $productUtil;
        $this->transactionUtil = $transactionUtil;
        $this->cashRegisterUtil = $cashRegisterUtil;
        $this->businessUtil = $businessUtil;
        $this->dummyPaymentLine = ['method' => 'cash', 'amount' => 0, 'note' => '', 'card_transaction_number' => '', 'card_number' => '', 'card_type' => '', 'card_holder_name' => '', 'card_month' => '', 'card_year' => '', 'card_security' => '', 'cheque_number' => '', 'bank_account_number' => '',
        'is_return' => 0, 'transaction_no' => ''];
    }

    function get_connection_list(Request $request)
    { 
        $user_data = $request->only('token','user_id','business_location_id', 'terminal_id');
        
        if(isset($user_data['token']))
        {
            $result = User::checkUserToken($user_data['token'], $user_data['user_id']);
            $terminal_id = !empty($user_data['terminal_id']) ? $user_data['terminal_id'] : null;

            if($result)
            {
                try {
                    $all_connection_lists = ApiPrinter::where('api_printer.business_location_id', $user_data['business_location_id'])
                                                    ->orderBy('api_printer.name', 'asc')
                                                    ->get()
                                                    ->toArray();

                    $query = ApiPrinter::where('api_printer.business_location_id', $user_data['business_location_id'])
                                      ->orderBy('api_printer.name', 'asc');

                    if (!empty($terminal_id)) {
                        $query->where(function ($query) use ($terminal_id) {
                            $query->whereNull('api_printer.terminal_id');
                            if ($terminal_id !== null) {
                                $query->orWhere('api_printer.terminal_id', '=', $terminal_id);
                            }
                        });
                    }

                    $all_connection_lists = $query->get()->toArray();
                    
                    
                    for($i=0;$i<count($all_connection_lists);$i++) 
                    {
                        if($all_connection_lists[$i]['allow_reprint'] == null && $all_connection_lists[$i]['allow_reprint'] !== 0) {
                            $all_connection_lists[$i]['allow_reprint'] = $all_connection_lists[$i]['print_receipt'];
                        } else {
                            $all_connection_lists[$i]['allow_reprint'] = $all_connection_lists[$i]['allow_reprint'];
                        }

                        $categories = Category::join('api_printer_categories','api_printer_categories.product_categories_id','=','categories.id')
                                                ->join('printer_categories','printer_categories.id','=','api_printer_categories.printer_group_id')
                                                ->where('printer_categories.id',$all_connection_lists[$i]['printer_group_id'])
                                                ->select('categories.id')
                                                ->get()
                                                ->toArray();
                        // if($categories['allow_kitchen_print'] == 1) {
                        //     $categories['allow_kitchen_print'] = 'true';
                        // } else {
                        //     $categories['allow_kitchen_print'] = 'false';
                        // }
                        
                        $categories_array = array();

                        for($j=0;$j<count($categories);$j++) 
                        {
                            $categories_array[$j] = $categories[$j]['id'];
                        }

                        $all_connection_lists[$i]['categories'] = $categories_array;

                        // $modifiers = Product::join('api_printer_modifiers', 'api_printer_modifiers.product_modifiers_id', '=', 'products.id')
                        //                     ->join('printer_categories', 'printer_categories.id', '=', 'api_printer_modifiers.printer_group_id')
                        //                     ->where('printer_categories.id', $all_connection_lists[$i]['printer_group_id'])
                        //                     ->select('products.id')
                        //                     ->get()
                        //                     ->toArray();

                        $modifiers = Variation::join('api_printer_modifiers', 'api_printer_modifiers.product_modifiers_id', '=', 'variations.id')
                                            ->join('printer_categories', 'printer_categories.id', '=', 'api_printer_modifiers.printer_group_id')
                                            ->where('printer_categories.id', $all_connection_lists[$i]['printer_group_id'])
                                            ->select('variations.id')
                                            ->get()
                                            ->toArray();
                                
                        $modifiers_array = [];
                
                        for ($k = 0; $k < count($modifiers); $k++) {
                            $modifiers_array[$k] = $modifiers[$k]['id'];
                        }
                
                        $all_connection_lists[$i]['modifiers'] = $modifiers_array;

                        $products = Product::join('api_printer_products', 'api_printer_products.product_id', '=', 'products.id')
                                            ->join('printer_categories', 'printer_categories.id', '=', 'api_printer_products.printer_group_id')
                                            ->where('printer_categories.id', $all_connection_lists[$i]['printer_group_id'])
                                            ->select('products.id')
                                            ->get()
                                            ->toArray();
                                
                        $products_array = [];
                
                        for ($k = 0; $k < count($products); $k++) {
                            $products_array[$k] = $products[$k]['id'];
                        }
                
                        $all_connection_lists[$i]['products'] = $products_array;
                    }

                    if(count($all_connection_lists)<=0) {
                        $all_connection_lists = ["errorMessage"=>'Device not found.'];
                    }
                } catch(\Exception $e) {
                    $all_connection_lists = ["errorMessage"=>'Device not found.'];
                }
                return $this->respond($all_connection_lists);
            }
            else
            {
                return["errorMessage"=>'Invalid token.'];
            }
        }
        else{
            return["errorMessage"=>'Invalid token.'];
        }
    }

    function get_printer_category(Request $request)
    {
        $user_data = $request->only('token','user_id','business_location_id');

        if(isset($user_data['token']))
        {
            $result = User::checkUserToken($user_data['token'], $user_data['user_id']);

            if($result)
            {
                try {
                    $printer_categories = PrinterCategories::where('printer_categories.location_id',$user_data['business_location_id'])
                                                    ->get()
                                                    ->toArray();
                    
                    for($i=0;$i<count($printer_categories);$i++) 
                    {
                        $categories = Category::join('api_printer_categories','api_printer_categories.product_categories_id','=','categories.id')
                                                ->join('printer_categories','printer_categories.id','=','api_printer_categories.printer_group_id')
                                                ->where('printer_categories.id',$printer_categories[$i]['id'])
                                                ->select('categories.id')
                                                ->get()
                                                ->toArray();
                        
                        $categories_array = array();

                        for($j=0;$j<count($categories);$j++) 
                        {
                            $categories_array[$j] = $categories[$j]['id'];
                        }

                        $printer_categories[$i]['categories'] = $categories_array;

                        // $modifiers = Product::join('api_printer_modifiers', 'api_printer_modifiers.product_modifiers_id', '=', 'products.id')
                        //                     ->join('printer_categories', 'printer_categories.id', '=', 'api_printer_modifiers.printer_group_id')
                        //                     ->where('printer_categories.id', $printer_categories[$i]['id'])
                        //                     ->select('products.id')
                        //                     ->get()
                        //                     ->toArray();

                        $modifiers = Variation::join('api_printer_modifiers', 'api_printer_modifiers.product_modifiers_id', '=', 'variations.id')
                                            ->join('printer_categories', 'printer_categories.id', '=', 'api_printer_modifiers.printer_group_id')
                                            ->where('printer_categories.id', $printer_categories[$i]['id'])
                                            ->select('variations.id')
                                            ->get()
                                            ->toArray();
                                            $modifiers_array = [];

                        for ($k = 0; $k < count($modifiers); $k++) {
                            $modifiers_array[$k] = $modifiers[$k]['id'];
                        }
                
                        $printer_categories[$i]['modifiers'] = $modifiers_array;
                        
                        $modifiers_array = [];

                        for ($k = 0; $k < count($modifiers); $k++) {
                            $modifiers_array[$k] = $modifiers[$k]['id'];
                        }
                
                        $printer_categories[$i]['modifiers'] = $modifiers_array;

                        $products = Product::join('api_printer_products', 'api_printer_products.product_id', '=', 'products.id')
                                            ->join('printer_categories', 'printer_categories.id', '=', 'api_printer_products.printer_group_id')
                                            ->where('printer_categories.id', $printer_categories[$i]['id'])
                                            ->select('products.id')
                                            ->get()
                                            ->toArray();
                        $products_array = [];

                        for ($k = 0; $k < count($products); $k++) {
                            $products_array[$k] = $products[$k]['id'];
                        }
                
                        $printer_categories[$i]['products'] = $products_array;
                        
                        $products_array = [];

                        for ($k = 0; $k < count($products); $k++) {
                            $products_array[$k] = $products[$k]['id'];
                        }
                
                        $printer_categories[$i]['products'] = $products_array;
                    }

                    if(count($printer_categories)<=0) {
                        $printer_categories = ["errorMessage"=>'Device not found.'];
                    }
                } catch(\Exception $e) {
                    $printer_categories = ["errorMessage"=>'Device not found.'];
                }

                return $this->respond($printer_categories);
            }
            else
            {
                return["errorMessage"=>'Invalid token.'];
            }
        }
        else{
            return["errorMessage"=>'Invalid token.'];
        }
    }

    function get_printer_category_by_id($input)
    {
        $user_data = $input;

        try {
            $printer_categories = PrinterCategories::where('printer_categories.location_id',$user_data['business_location_id'])
                                            ->get()
                                            ->toArray();
            
            for($i=0;$i<count($printer_categories);$i++) 
            {
                $categories = Category::join('api_printer_categories','api_printer_categories.product_categories_id','=','categories.id')
                                        ->join('printer_categories','printer_categories.id','=','api_printer_categories.printer_group_id')
                                        ->where('printer_categories.id',$printer_categories[$i]['id'])
                                        ->select('categories.id')
                                        ->get()
                                        ->toArray();
                
                $categories_array = array();

                for($j=0;$j<count($categories);$j++) 
                {
                    $categories_array[$j] = $categories[$j]['id'];
                }

                $printer_categories[$i]['categories'] = $categories_array;

                $modifiers = Product::join('api_printer_modifiers', 'api_printer_modifiers.product_modifiers_id', '=', 'products.id')
                                    ->join('printer_categories', 'printer_categories.id', '=', 'api_printer_modifiers.printer_group_id')
                                    ->where('printer_categories.id', $printer_categories[$i]['id'])
                                    ->select('products.id')
                                    ->get()
                                    ->toArray();
                                    $modifiers_array = [];

                for ($k = 0; $k < count($modifiers); $k++) {
                    $modifiers_array[$k] = $modifiers[$k]['id'];
                }
        
                $printer_categories[$i]['modifiers'] = $modifiers_array;
                
                $modifiers_array = [];

                for ($k = 0; $k < count($modifiers); $k++) {
                    $modifiers_array[$k] = $modifiers[$k]['id'];
                }
        
                $printer_categories[$i]['modifiers'] = $modifiers_array;
            }

            if(count($printer_categories)<=0) {
                $printer_categories = ["errorMessage"=>'Device not found.'];
            }
        } catch(\Exception $e) {
            $printer_categories = ["errorMessage"=>'Device not found.'];
        }

        return $this->respond($printer_categories);
            
        
    }

    function get_connection(Request $request)
    { 
        $user_data = $request->only('token','user_id','business_location_id','api_printer_id');

        if(isset($user_data['token']))
        {
            $result = User::checkUserToken($user_data['token'], $user_data['user_id']);

            if($result)
            {
                try {
                    $connection = ApiPrinter::join('printer_categories','printer_categories.id','=','api_printer.printer_group_id')
                                            ->select('api_printer.*','printer_categories.id AS printer_group_id')
                                            ->where('api_printer.id', $user_data['api_printer_id'])
                                            ->get()
                                            ->toArray();

                    // $printer_categories =  PrinterCategories::join('api_printer_categories','api_printer_categories.printer_categorie_id','=','printer_categories.id')
                    //                                         ->where('api_printer_categories.api_printer_id',$user_data['api_printer_id'])
                    //                                         ->select('printer_categories.*')
                    //                                         ->get()
                    //                                         ->toArray();

                    // $connection[0]['printer_categories'] = $printer_categories;

                    if(count($connection)<=0) {
                        $connection = ["errorMessage"=>'Device not found.'];
                    }
                } catch(\Exception $e) {
                    $connection = ["errorMessage"=>'Device not found.'];
                }

                return $this->respond($connection);
            }
            else
            {
                return["errorMessage"=>'Invalid token.'];
            }
        }
        else{
            return["errorMessage"=>'Invalid token.'];
        }
    }

    function create_connection(Request $request)
    { 
        $user_data = $request->only('token', 'user_id', 'business_location_id', 'name', 'connection', 'address', 'printer_group_id', 'device_type', 'allow_kitchen_print', 'print_receipt', 'app_printer_id', 'terminal_id', 'enable_redirection', 'master_print_by_printer_group', 'allow_reprint');
        $master_kitchen_print_receipt = !empty($request->input('master_kitchen_print_receipt')) ? $request->input('master_kitchen_print_receipt') : 0;
        $app_printer_id = !empty($user_data['app_printer_id']) ? $user_data['app_printer_id'] : "";
        $terminal_id = !empty($user_data['terminal_id']) ? $user_data['terminal_id'] : "";
        
        if(isset($user_data['token']))
        {
            $result = User::checkUserToken($user_data['token'], $user_data['user_id']);
                
            if($user_data['allow_kitchen_print'] == 'true'){
                $allow_kitchen_print = 1;
            } else {
                $allow_kitchen_print = 0;
            }

            if(!empty($user_data['master_print_by_printer_group'])) {
                $master_print_by_printer_group = $user_data['master_print_by_printer_group'];
            } else {
                $master_print_by_printer_group = 0;
            }
            
            if($result)
            {
                try {
                    $apiPrinter = ApiPrinter::where("business_location_id", $user_data['business_location_id'])
                                ->where(
                                    function($query) use ($user_data) {
                                      return $query
                                             ->where("name", $user_data['name'])
                                             ->orWhere("address", $user_data['address']);
                                })
                                ->first();

                    if( empty($apiPrinter) ) {
                        $connection = ApiPrinter::create([
                            'name' => $user_data['name'],
                            'connection' => $user_data['connection'],
                            'address' => $user_data['address'],
                            'business_location_id' => $user_data['business_location_id'],
                            'printer_group_id' => $user_data['printer_group_id'],
                            'device_type' => $user_data['device_type'],
                            'allow_kitchen_print' => $user_data['allow_kitchen_print'],
                            'print_receipt' => $user_data['print_receipt'],
                            'master_kitchen_print_receipt'=>$master_kitchen_print_receipt,
                            'app_printer_id' => $app_printer_id,
                            'terminal_id' => $terminal_id,
                            'enable_redirection' => $user_data['enable_redirection'],
                            'master_print_by_printer_group' => $master_print_by_printer_group,
                            'allow_reprint' => $user_data['allow_reprint']
                        ]);
                    } else {
                        $connection = ["errorMessage" => 'Printer is already exists with provided name and address.'];
                    }

                    // //Add product locations
                    // $printer_categories = $user_data['printer_categories'];
                    // if (!empty($printer_categories)) {
                    //     $connection->printer_categories()->sync($printer_categories);
                    // }

                } catch(\Exception $e) {
                    $connection = ["errorMessage"=>'Creation Failed.'];
                }

                return $this->respond($connection);
            }
            else
            {
                return["errorMessage"=>'Invalid token.'];
            }
        }
        else{
            return["errorMessage"=>'Invalid token.'];
        }
    }

    function update_connection(Request $request)
    { 
        $user_data = $request->only('token','user_id', 'business_location_id', 'api_printer_id','name','connection','address','printer_group_id','device_type','allow_kitchen_print','print_receipt','app_printer_id', 'terminal_id', 'enable_redirection','master_print_by_printer_group', 'allow_reprint');
        $master_kitchen_print_receipt = !empty($request->input('master_kitchen_print_receipt')) ? $request->input('master_kitchen_print_receipt') : 0;
        $app_printer_id = !empty($user_data['app_printer_id']) ? $user_data['app_printer_id'] : "";
        $terminal_id = !empty($user_data['terminal_id']) ? $user_data['terminal_id'] : "";

        if(isset($user_data['token']))
        {
            $result = User::checkUserToken($user_data['token'], $user_data['user_id']);

            if($user_data['allow_kitchen_print'] == 'true'){
                $allow_kitchen_print = 1;
            } else {
                $allow_kitchen_print = 0;
            }

            if(!empty($user_data['master_print_by_printer_group'])) {
                $master_print_by_printer_group = $user_data['master_print_by_printer_group'];
            } else {
                $master_print_by_printer_group = 0;
            }

            if($result)
            {
                $connection = [];
                try {
                    if ( isset($user_data['app_printer_id']) && $user_data['app_printer_id'] && !empty($user_data['app_printer_id'])) {
                        $apiPrinter = ApiPrinter::where("business_location_id", $user_data['business_location_id'])
                                ->whereNotIn("app_printer_id", [$user_data['app_printer_id']])
                                ->where(
                                    function($query) use ($user_data) {
                                      return $query
                                             ->where("name", $user_data['name'])
                                             ->orWhere("address", $user_data['address']);
                                })
                                ->first();
                        if( empty($apiPrinter) ) {
                            $connection = ApiPrinter::where('app_printer_id', $user_data['app_printer_id'])
                                                    ->update([
                                                        'name' => $user_data['name'],
                                                        'connection' => $user_data['connection'],
                                                        'address' => $user_data['address'],
                                                        'printer_group_id' => $user_data['printer_group_id'],
                                                        'device_type' => $user_data['device_type'],
                                                        'allow_kitchen_print' => $user_data['allow_kitchen_print'],
                                                        'print_receipt' => $user_data['print_receipt'],
                                                        'master_kitchen_print_receipt'=>$master_kitchen_print_receipt,
                                                        'terminal_id' => $terminal_id,
                                                        'enable_redirection' => $user_data['enable_redirection'],
                                                        'master_print_by_printer_group' => $master_print_by_printer_group,
                                                        'allow_reprint' => $user_data['allow_reprint']
                                                    ]);
                        } else {
                            $connection = ["errorMessage" => 'Printer is already exists with provided name and address.'];
                        }
                    } elseif (isset($user_data['api_printer_id']) && $user_data['api_printer_id'] && !empty($user_data['api_printer_id'])) {
                        $apiPrinter = ApiPrinter::where("business_location_id", $user_data['business_location_id'])
                                            ->whereNotIn("id", [$user_data['api_printer_id']])
                                            ->where(
                                                function($query)  use ($user_data) {
                                                  return $query
                                                         ->where("name", $user_data['name'])
                                                         ->orWhere("address", $user_data['address']);
                                            })
                                            ->first();
                                            
                        if(empty($apiPrinter) ) {
                                $connection = ApiPrinter::where('id', $user_data['api_printer_id'])
                                                        ->update([
                                                            'name' => $user_data['name'],
                                                            'connection' => $user_data['connection'],
                                                            'address' => $user_data['address'],
                                                            'printer_group_id' => $user_data['printer_group_id'],
                                                            'device_type' => $user_data['device_type'],
                                                            'allow_kitchen_print' => $user_data['allow_kitchen_print'],
                                                            'print_receipt' => $user_data['print_receipt'],
                                                            'enable_redirection' => $user_data['enable_redirection'],
                                                            'master_kitchen_print_receipt' => $master_kitchen_print_receipt,
                                                            'master_print_by_printer_group' => $master_print_by_printer_group,
                                                            'allow_reprint' => $user_data['allow_reprint']
                                                        ]);
                        } else {
                            $connection = ["errorMessage" => 'Printer is already exists with provided name and address.'];
                        } 
                    } else {
                        // handle error case here, such as throwing an exception or returning an error response
                    }
                    
                } catch(\Exception $e) {
                    \Log::info($e->getMessage());
                    $connection = ["errorMessage"=>'Device not found.'];
                }

                return $this->respond($connection);
            }
            else
            {
                return["errorMessage"=>'Invalid token.'];
            }
        }
        else{
            return["errorMessage"=>'Invalid token.'];
        }
    }

    function delete_connection(Request $request)
    { 
        $user_data = $request->only('token','user_id','api_printer_id','name','connection','address','app_printer_id');

        if(isset($user_data['token']))
        {
            $result = User::checkUserToken($user_data['token'], $user_data['user_id']);

            if($result)
            {
                try {
                    if (!empty($user_data['app_printer_id'])) {
                        $connection = ApiPrinter::where('app_printer_id', $user_data['app_printer_id'])
                                                ->firstOrFail();
                        $connection->delete();
                        
                    } elseif (!empty($user_data['api_printer_id'])) {
                        $connection = ApiPrinter::where('id', $user_data['api_printer_id'])
                                                ->findOrFail($user_data['api_printer_id']);                         
                        $connection->delete();
                    } else {
                        // handle error case here, such as throwing an exception or returning an error response
                    }
                    
                } catch (\Exception $e) {
                    $connection = ["errorMessage"=>'Device not found.'];
                }

                return $this->respond($connection);
            }
            else
            {
                return["errorMessage"=>'Invalid token.'];
            }
        }
        else{
            return["errorMessage"=>'Invalid token.'];
        }
    }
}
