<?php

namespace App\Http\Controllers\Api;

use App\Business;
use App\TelegramChannel;
use App\TelegramUserTelegramChannel;
use FontLib\TrueType\Collection;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\TelegramUser;
use Illuminate\Support\Facades\Validator;
use DB;
use Maatwebsite\Excel\Facades\Excel;
use App\Exports\ReferralExport;
use File;

class TelegramUserController extends Controller
{
    protected $telegramUser;

    public function __construct(TelegramUser $telegramUser)
    {
        $telegramUser = $this->telegramUser;
    }

    public function getTelegramUser($user_id)
    {
        $user = TelegramUser::with('channels', 'groups')->where('user_id', $user_id)->select('id', 'user_id', 'first_name', 'last_name', 'user_name', 'mobile', 'l_longitude', 'l_latitude', 'created_at', 'updated_at')->get();
        if ($user->count() > 0) {
            $output = [
                'status' => 1,
                'msg' => 'User data access successfully',
                'telegram_user' => $user[0],
            ];
        } else {
            $output = [
                'status' => 0,
                'msg' => 'User not found',
            ];
        }
        return response()->json($output, 200);
    }

    public function getAllUserList()
    {
        $user = TelegramUser::select('id', 'user_id', 'first_name', 'last_name', 'user_name', 'mobile', 'l_longitude', 'l_latitude', 'created_at', 'updated_at')->get();
        if ($user->count() > 0) {
            $output = [
                'status' => 1,
                'telegram_user' => $user,
            ];
        }
        return response()->json($output, 200);
    }

    public function storeTelegramUser(Request $request)
    {

        // Define the validation rules
        $validator = Validator::make($request->all(), [
            'user_id' => 'required|numeric',
            'first_name' => 'required|string|max:255',
        ]);

        if ($validator->fails()) {
            return response()->json(['status' => 0, 'msg' => 'Validation failed', 'errors' => $validator->errors()], 400);
        }
        $user = TelegramUser::where('user_id', $request->user_id)->get();

        if ($user->count() > 0) {
            $output = [
                'status' => 0,
                'msg' => 'user already exist.',
            ];
            return response()->json($output, 200);
        }

        $user = TelegramUser::create($request->all());
        if ($user) {
            $output = [
                'status' => 1,
                'msg' => 'user created successfully.',
            ];
        } else {
            $output = [
                'status' => 0,
                'msg' => 'Something went wrong. Please try again',
            ];
        }
        return response()->json($output, 200);
    }

    public function updateTelegramUser(Request $request)
    {

        // Define the validation rules
        $validator = Validator::make($request->all(), [
            'user_id' => 'required|numeric',
        ]);

        if ($validator->fails()) {
            return response()->json(['status' => 0, 'msg' => 'Validation failed', 'errors' => $validator->errors()], 400);
        }
        $user_input = [];

        if ($request->first_name != null) {
            $user_input['first_name'] = $request->first_name;
        }
        if ($request->last_name != null) {
            $user_input['last_name'] = $request->last_name;
        }
        if ($request->user_name != null) {
            $user_input['user_name'] = $request->user_name;
        }
        if ($request->mobile != null) {
            $user_input['mobile'] = $request->mobile;
        }
        if ($request->l_longitude != null) {
            $user_input['l_longitude'] = $request->l_longitude;
        }
        if ($request->l_latitude != null) {
            $user_input['l_latitude'] = $request->l_latitude;
        }

        $user = TelegramUser::where('user_id', request()->user_id)->update($user_input);
        if ($user) {
            $output = [
                'status' => 1,
                'msg' => 'user updated successfully.',
            ];
        } else {
            $output = [
                'status' => 0,
                'msg' => 'User not found. Please try again',
            ];
        }
        return response()->json($output, 200);
    }


    public function addUserChannelStatus(Request $request)
    {
        $input = request()->only(['user_id', 'channel_id', 'old_status', 'new_status', 'action_taken_by']);
        $validator = Validator::make($request->all(), [
            'user_id' => 'required|numeric',
        ]);

        if ($validator->fails()) {
            return response()->json(['status' => 0, 'msg' => 'Validation failed', 'errors' => $validator->errors()], 400);
        }

        $user_id = $input['user_id'];
        $channel_id = $input['channel_id'];
        $old_status = $input['old_status'];
        $new_status = $input['new_status'];
        
        if ($old_status === "referral_joining" && $new_status === "member") {
            do {
                $lucky_draw_number = $this->generateLuckyDraw();
                $existing_number = TelegramUserTelegramChannel::where('lucky_draw_number', $lucky_draw_number)->value('lucky_draw_number');
            } while ($existing_number);
        }
        $action_taken_by = $input['action_taken_by'];
        $telegramChannel = TelegramChannel::where('channel_int_id', $channel_id)->first();

        try {
            // if(!empty($channel_id)){
            //     TelegramChannel::where('id', $telegramChannel->id)->update([ "channel_int_id" => $channel_id ]);
            // }
        } catch (\Exception $e) {
            \Log::error($e->getMessage());
        }
        if ($telegramChannel) {
            $user = TelegramUser::where('user_id', $user_id)->first();
            if (!$user) {
                return response()->json([
                    'status' => 0,
                    'msg' => 'Invalid user id please check again.'
                ]);
            }
            $id = $user->id;
            $data = [
                $id => [
                    "old_status" => $old_status,
                    "new_status" => $new_status,
                    "action_taken_by" => $action_taken_by,
                ]
            ];
            if (isset($lucky_draw_number) && $lucky_draw_number !== null) {
                $data[$id]["lucky_draw_number"] = $lucky_draw_number;
            }
            $telegramChannel->users()->syncWithoutDetaching($data);
            $output = [
                "status" => 1,
                "msg" => "User channel status updated successfully"
            ];
        } else {
            $output = [
                "status" => 0,
                "msg" => "Invalid channel id please check again."
            ];
        }
        return $output;
    }

    public function generateLuckyDraw(){
        $firstPart = 88; // Generate a random number between 10 and 99
        $secondPart = str_pad(rand(0, 999999), 6, '0', STR_PAD_LEFT); // Generate a 6-digit number and pad with leading zeros if necessary
        $generate_random_number = sprintf("%d-%06d", $firstPart, $secondPart);
        return $generate_random_number;
    }

    public function updateUserChannelStatus(Request $request)
    {
        $input = request()->only(['user_id', 'channel_id', 'old_status', 'new_status', 'action_taken_by']);

        $user_id = $input['user_id'];
        $channel_id = $input['channel_id'];
        $old_status = $input['old_status'];
        $new_status = $input['new_status'];
        $action_taken_by = $input['action_taken_by'];

        $telegramChannel = TelegramChannel::where('channel_id', $channel_id)->first();

        $user = TelegramUser::where('user_id', $user_id)->first();
        $u_id = $user->id;
        $data = [
            $u_id => ["old_status" => $old_status, "new_status" => $new_status, "action_taken_by" => $action_taken_by]
        ];
        // $telegramChannel->users()->attach($u_id, ["old_status"=>$old_status, "new_status"=>$new_status, "action_taken_by"=>$action_taken_by]);
        $telegramChannel->users()->syncWithoutDetaching($data);
    }

    public function getUserChannelStatus($id)
    {
        $user = TelegramUser::where('user_id', $id)->with('channels', 'groups')->get();
        if ($user->count() > 0) {
            $output = [
                'status' => 1,
                'msg' => 'User data access successfully',
                'telegram_user' => $user[0],
            ];
        } else {
            $output = [
                'status' => 0,
                'msg' => 'User not found',
            ];
        }
        return response()->json($output, 200);
    }

    public function telegramInviteUser(Request $request)
    {
        $input = request()->only(['referral_by', 'referral_to', 'channel_id', 'status']);
        $validator = Validator::make($request->all(), [
            'referral_to' => 'required|numeric',
            'referral_by' => 'required|numeric',
            'channel_id' => 'required',
        ]);

        if ($validator->fails()) {
            return response()->json(['status' => 0, 'msg' => 'Validation failed', 'errors' => $validator->errors()], 400);
        }
        
        $user_id = $input['referral_to'];
        $channel_id = $input['channel_id'];
        $referred_to = $input['referral_to'];
        $referred_by = $input['referral_by'];
        $status = $input['status'];
    

        $telegramChannel = TelegramChannel::where('channel_int_id', $channel_id)->first();
        if ($telegramChannel) {
            $referral_to_user = TelegramUser::where('user_id', $user_id)->first();
            if (!$referral_to_user) {
                return response()->json([
                    'status' => 0,
                    'msg' => 'Invalid user id please check again.'
                ]);
            }
            $id = $referral_to_user->id;
            $data = [
                $id => [
                    "referred_to" => $referred_to,
                    "referred_by" => $referred_by,
                    "new_status" => $status,
                ]
            ];
            $telegramChannel->users()->syncWithoutDetaching($data);
            $output = [
                "status" => 1,
                "msg" => "referral successfully"
            ];
        } else {
            $output = [
                "status" => 0,
                "msg" => "Invalid channel id please check again."
            ];
        }
        return $output;
    }

    public function getUserInviteList($id)
    {
        $user = TelegramUser::with('referral_channels')->where('user_id', $id)->limit(200)->get();
        if ($user->count() > 0) {
            $output = [
                'status' => 1,
                'msg' => 'User data access successfully',
                'telegram_user' => $user,
            ];
        } else {
            $output = [
                'status' => 0,
                'msg' => 'User not found',
            ];
        }
        return response()->json($output, 200);
    }

    public function getSingleUserInviteList(Request $request)
    {
        $user_invite_list = TelegramUserTelegramChannel::with('user')->where('referred_by', $request->referral_user_id)->where('telegram_channel_id', $request->channel_id)->limit(200)->get();
        if ($user_invite_list->count() > 0) {
            $output = [
                'status' => 1,
                'msg' => 'User data access successfully',
                'telegram_user' => $user_invite_list,
            ];
        } else {
            $output = [
                'status' => 0,
                'msg' => 'User not found',
            ];
        }
        return response()->json($output, 200);
    }

    public function getAllBusiness($channel_id)
    {
        $channel_configured_business = TelegramChannel::with(['all_channel_businesses' => function ($query) {
            $query->groupBy('business_id');
        }])->where('id', $channel_id)->get();
        
        if ($channel_configured_business->count() > 0) {
            $output = [
                'status' => 1,
                'msg' => 'Channel attached business access successfully',
                'channel_businesses' => $channel_configured_business,
            ];
        } else {
            $output = [
                'status' => 0,
                'msg' => 'Data not found',
            ];
        }
        return response()->json($output, 200);
    }

    public function channelBusinessLocation($channel_id=null, $business_id=null)
    {
        $business_locations = TelegramChannel::with(['channel_locations' => function ($query) {
                $query->groupBy('id');
            }
        ])->find($channel_id);

        if ($business_locations->count() > 0) {
            $output = [
                'status' => 1,
                'msg' => 'Channel attached business locations access successfully',
                'channel_businesses' => $business_locations,
            ];
        } else {
            $output = [
                'status' => 0,
                'msg' => 'Data not found',
            ];
        }
        return response()->json($output, 200);
    }

    public function getCampaigns(Request $request)
    {
        $channel_id = $request->channel_id;
        $location_id = $request->location_id;
        // dd($channel_id, $location_id);

        $campaigns = TelegramChannel::with(['channel_campaigns' => function ($query) use ($location_id) {
            $query->where('campaign_telegrams.location_id', $location_id);
        }])->find($channel_id);

        if ($campaigns->count() > 0) {
            $output = [
                'status' => 1,
                'msg' => 'Channel attached business locations access successfully',
                'channel_businesses' => $campaigns,
            ];
        } else {
            $output = [
                'status' => 0,
                'msg' => 'Data not found',
            ];
        }
        return response()->json($output, 200);
    }


    public function deleteNfcCard($business_id, $card_no, $sr_no){
        try{
            $record = DB::table('nfc_cards')
            ->where('business_id', $business_id)
            ->where('card_no', $card_no)
            ->where('sr_no', $sr_no)
            ->delete();
            if($record){
                $output = [
                    "status" => 1,
                    "message" => "Record Deleted Successfully."
                ];
            }else {
                $output = [
                    "status" => 0,
                    "message" => "Record Not found."
    
                ];
            }
        }catch(\Exception $e){
            $output = [
                "status" => 0,
                "message" => "Something went wrong."

            ];
        }
        return $output;

    }

    public function hitBot(Request $request){
        $input = file_get_contents('php://input');
        $data = json_decode($input);
        $chat_id = $data->message->chat->id;
        $text=$data->message->text;
        $text=$text." webhook Reply";
        $token = "";
        $url = "https://api.telegram.org/bot<token>/sendMessage?text=$text&chat_id=$chat_id";
        file_get_contents($url);
    }

    public function leaderBoardData(Request $request){

        try {
            $channel_id = TelegramChannel::where('channel_int_id', $request->only('channel_id'))->value('id');
            if(!empty($channel_id)){
                // $results = TelegramUserTelegramChannel::selectRaw('
                // ROW_NUMBER() OVER (ORDER BY COUNT(*) DESC) AS serial_number,
                // CONCAT(
                //     COALESCE(telegram_users.first_name, ""),
                //     CASE WHEN telegram_users.first_name IS NOT NULL AND telegram_users.last_name IS NOT NULL THEN " " ELSE "" END,
                //     COALESCE(telegram_users.last_name, "")
                // ) AS full_name,
                // telegram_users.user_name,    
                // COUNT(*) AS invite
                // ')
                // ->join('telegram_users', 'telegram_user_telegram_channels.referred_by', '=', 'telegram_users.user_id')
                // ->where('new_status', 'member')
                // ->where('old_status', 'referral_joining')
                // ->where('telegram_channel_id', $channel_id)
                // ->whereNotNull('referred_by')
                // ->groupBy('referred_by')
                // ->orderByDesc('invite')
                // ->limit(30)
                // ->get();

                $results = DB::table(DB::raw("
                            (SELECT 
                            ROW_NUMBER() OVER (ORDER BY COUNT(*) DESC) AS serial_number, 
                                CONCAT(
                                    COALESCE(telegram_users.first_name, ''),
                                    CASE WHEN telegram_users.first_name IS NOT NULL AND telegram_users.last_name IS NOT NULL THEN ' ' ELSE '' END,
                                    COALESCE(telegram_users.last_name, '')
                                ) AS full_name,
                                telegram_users.user_name,
                                COUNT(*) AS invite
                            FROM 
                                telegram_user_telegram_channels
                            JOIN 
                                telegram_users ON telegram_user_telegram_channels.referred_by = telegram_users.user_id
                            WHERE 
                                new_status = 'member'
                                AND old_status = 'referral_joining'
                                AND telegram_channel_id = $channel_id
                                AND referred_by IS NOT NULL
                            GROUP BY 
                                referred_by
                            ORDER BY 
                                invite DESC, user_id ASC
                            LIMIT 30
                        ) AS ranked_results"))
                        ->orderBy('serial_number')
                        ->get();
                
                // Export the data to Excel
                $fileName = 'leader_board.xlsx';
                $file_path = url('leader_board/' . $fileName);

                if (!file_exists($file_path)) {
                    File::makeDirectory($file_path, $mode = 0777, true, true);
                }
                Excel::store(new ReferralExport($results), 'leader_board/'.$fileName);
                $url = asset('uploads/leader_board/'.$fileName);
                
                // $s3DestinationPath = config('constants.awsS3Env') . '/lader-board/' . $fileName;
                
                // Excel::store(new ReferralExport($results), $s3DestinationPath);
                // $url = Storage::disk('s3')->url($s3DestinationPath);
                // $url = asset('leader_board/'.$fileName);
                
                if($url){
                    $output = [
                        "status" => 1,
                        "message" => "LeaderBoard record access successfully.",
                        "url" => $url
                    ];
                }else{
                    $output = [
                        "status" => 0,
                        "message" => "LeaderBoard record not available.",
                    ];
                }
        
            }else{
                $output = [
                    "status" => 0,
                    "message" => "Invalid channel id.",
                ];
            }
        } catch (\Throwable $th) {
            $output = [
                "status" => 0,
                "message" => "Something went wrong."

            ];
        }

        return $output;
    }

    public function uploadImageLocal($request)
    {
        if ($request->hasFile('image')) {
            $file = $request->file('image');
            $extension = $file->getClientOriginalExtension(); // you can also use file name
            $fileName = time() . '.' . $extension;
            
            $path = public_path() . '/post_image';
            $file_path = url('post_image/' . $fileName);
            if (!file_exists($path)) {
                File::makeDirectory($path, $mode = 0777, true, true);
            }
            $upload = $file->move($path, $fileName);
            return $file_path;
        }
    }

}