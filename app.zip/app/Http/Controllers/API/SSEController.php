<?php

namespace App\Http\Controllers\API;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\User;

use Illuminate\Support\Facades\DB;
use Symfony\Component\HttpFoundation\StreamedResponse;
use App\Restaurant\ResTable;
use App\Queue\QueueSchema;
use App\Http\Requests\CurrentQueueRequest;
use Carbon\Carbon;

// PHP-FPM SSE Example: push messages to client

class SSEController extends Controller {

    public function __construct() {
    }

    public function getOrderData($input) {
        $data = DB::table('transactions')
                ->where('business_id', $input['business_id'])
                ->where('location_id', $input['location_id'])
                ->where('sent', 0)
                ->get();
        return $data;
    }

    public function getPickupData($input) {
        $data = DB::table('transactions')
                ->where('business_id', $input['business_id'])
                ->where('location_id', $input['location_id'])
                ->where('pickup_sent', 0)
                ->get();
        return $data;
    }

    public function getOrderDataByRowCount($input) { // for tablet
        $all_location_table = ResTable::leftjoin('pos_res_tables', function ($leftjoin) {
                    $leftjoin->on('res_tables.id', '=', 'pos_res_tables.res_table_id')
                         ->where('pos_res_tables.seated', '=', 1)
                         ->whereDate('pos_res_tables.created_at','>=', Carbon::today());
                })
              ->select('pos_res_tables.seated')
              ->where('res_tables.location_id', $input['location_id'])
              ->where('pos_res_tables.seated', '=', 1)
              ->get()
              ->toArray();

        return count($all_location_table);
    }

    public function getPendingOrderDataByRowCount($input) { // for POS
        // count row dine in order with pending_order = 1
        $data = DB::table('transactions')
                ->where('business_id', $input['business_id'])
                ->where('location_id', $input['location_id'])
                ->where('type_for_api', 'Dinein')
                ->where('pending_order', '=', 1)
                ->get()
                ->toArray();

        return count($data);
    }

    public function getPickupDataByRowCount($input) {
        $data = DB::table('transactions')
                ->where('business_id', $input['business_id'])
                ->where('location_id', $input['location_id'])
                ->where('type_for_api', 'Pickup')
                ->get()
                ->toArray();

        return count($data);
    }

    public function getDeliveryStatusByRowCount($input) {
        $all_delivery_status = DB::table('transactions')
                                ->where('business_id', $input['business_id'])
                                ->where('location_id', $input['location_id'])
                                ->where('type_for_api', 'Delivery')
                                ->whereNotNull('lalamove_status')
                                ->select('lalamove_status')
                                ->get()
                                ->toArray();

        // echo json_encode(array_column($all_delivery_status, 'lalamove_status'));
        $lump_all_delivery_status = array_column($all_delivery_status, 'lalamove_status');
        $count_all_delivery_status = array_count_values($lump_all_delivery_status);

        return $count_all_delivery_status;
    }
    
    // for POS System purpose 
    function sentOrders(Request $request) {

        $input = $request;
        $orderData = [];

        if(isset($input['token'])) {
            $result = User::checkUserToken($input['token'], $input['user_id']);

            if($result) {

                $data = array();

                $orderData = $this->getOrderData($input);
                $pickupData = $this->getPickupData($input);

                if(count($orderData) > 0 || count($pickupData) > 0) {

                    $data[] = [
                        'orderData'  => $orderData,
                        'pickupData' => $pickupData,
                    ];

                    $response = new StreamedResponse();
                    $response->setCallback(function () use ($data) {
                        echo 'data: ' . json_encode($data) . "\n\n";
                        flush();
                        usleep(200000);
                    });

                    $response->headers->set('Content-Type', 'text/event-stream');
                    $response->headers->set('X-Accel-Buffering', 'no');
                    $response->headers->set('Cach-Control', 'no-cache');
                    $response->send();

                    if(connection_aborted()) {
                        exit();
                    }

                    // update sent status
                    foreach ($orderData as $order) {
                        DB::table('transactions')->where('id', $order->id)->update(['sent' => 1]);
                    }

                    foreach ($pickupData as $pickup) {
                        DB::table('transactions')->where('id', $pickup->id)->update(['pickup_sent' => 1]);
                    }
                }
                return ($data);
            } 
            else { return["errorMessage"=>'Invalid token.']; }
        } 
        else { return["errorMessage"=>'Invalid token.']; }
    }

    // using count row to send trigger refresh updated orders (Tablet)
    function checkUpdateOrders(Request $request) {
        // echo json_encode($request);

        $input = $request;
        $orderData = [];

        if(isset($input['token'])) {
            $result = User::checkUserToken($input['token'], $input['user_id']);

            if($result) {
                $data = array();
                
                $orderDataRowCount = $this->getOrderDataByRowCount($input);

                // get front end current data row count, then send message to front end if row count not same (backend !== front end)
                if((int)$input['orderDataRowCount'] !== (int)$orderDataRowCount) {
                    $data[] = [
                        'orderDataRowCount'  => $orderDataRowCount
                    ];

                    $response = new StreamedResponse();
                    $response->setCallback(function () use ($data) {
                        echo 'data: ' . json_encode($data) . "\n\n";
                        flush();
                        usleep(200000);
                    });

                    $response->headers->set('Content-Type', 'text/event-stream');
                    $response->headers->set('X-Accel-Buffering', 'no');
                    $response->headers->set('Cach-Control', 'no-cache');
                    $response->send();

                    if(connection_aborted()) {
                        exit();
                    }
                }
                return ($data);
            } 
            else { return["errorMessage"=>'Invalid token.']; }
        } 
        else { return["errorMessage"=>'Invalid token.']; }
    }

    function checkUpdateAllOrders(Request $request) {
        $input = $request;
        $orderData = [];

        if(isset($input['token'])) {
            $result = User::checkUserToken($input['token'], $input['user_id']);

            if($result) {
                $data = array();
                
                $orderDataRowCount = $this->getPendingOrderDataByRowCount($input);
                $pickUpDataRowCount = $this->getPickupDataByRowCount($input);

                // get front end current data row count, then send message to front end if row count not same (backend !== front end)
                if((int)$input['orderDataRowCount'] !== (int)$orderDataRowCount || (int)$input['pickUpDataRowCount'] !== (int)$pickUpDataRowCount) {
                    $data[] = [
                        'orderDataRowCount'  => $orderDataRowCount,
                        'pickUpDataRowCount' => $pickUpDataRowCount,
                        'time' => date('h:i:s'),
                        'id' => rand(10, 100)
                    ];

                    $response = new StreamedResponse();
                    $response->setCallback(function () use ($data) {
                        echo 'data: ' . json_encode($data) . "\n\n";
                        ob_flush();
                        flush();
                        usleep(200000);
                    });

                    $response->headers->set('Content-Type', 'text/event-stream');
                    $response->headers->set('X-Accel-Buffering', 'no');
                    $response->headers->set('Cach-Control', 'no-cache');
                    $response->send();

                    if(connection_aborted()) {
                        exit();
                    }
                }
                return ($data);
            } 
            else { return["errorMessage"=>'Invalid token.']; }
        } 
        else { return["errorMessage"=>'Invalid token.']; }
    }

    public function stream() {

        $random_string = chr(rand(65, 90)) . chr(rand(65, 90)) . chr(rand(65, 90));
        $data = [
            'message' => $random_string,
            'name' => $random_string,
            'time' => date('h:i:s'),
            'id' => rand(10, 100),
        ];
        
        $response = new StreamedResponse();
        $response->setCallback(function () use ($data){

             echo 'data: ' . json_encode($data) . "\n\n";
             ob_flush();
             flush();
             //sleep(10);
             usleep(200000);
        });

        $response->headers->set('Content-Type', 'text/event-stream');
        $response->headers->set('X-Accel-Buffering', 'no');
        $response->headers->set('Cach-Control', 'no-cache');
        $response->send();


        if (connection_aborted()) {
            exit();
        }
    }

    public function fetchCurrentQueue(CurrentQueueRequest $request) {
        $input = $request;
        try {
            $current_queue = [];
            $average_wating_time = 0;
            $queueSchemas = QueueSchema::where('queue_schemas.business_id', $input['business_id'])
                        ->where('queue_schemas.location_id', $input['location_id'])
                        ->whereNull('queue_schemas.deleted_at')
                        ->join('business_locations AS BL', 'queue_schemas.location_id', '=', 'BL.id')
                        ->join('queue_pax_categories AS PC', 'queue_schemas.pax_category_id', '=', 'PC.id')
                        ->select(['BL.name as location', 'PC.description as pax_range', 'PC.start_from as pax_range_start_from', 'PC.end_to as pax_range_end_to',
                            'queue_schemas.prefix', 'queue_schemas.start', 'queue_schemas.end',
                            'queue_schemas.estimated_wait_time', 'queue_schemas.description', 'queue_schemas.id'])
                        ->get();
            
            if($queueSchemas && !empty($queueSchemas)) {
                $total_queues = count($queueSchemas);
                $total_waiting_time = 0;

                $queue_wise_data = [];                
                foreach ($queueSchemas as $key => $queueSchema) {
                    $query ="SELECT COUNT(*) AS total_queue_tokens 
                        FROM manage_queue
                        WHERE business_id = " . $input['business_id'] . " 
                        AND deleted_at IS NULL 
                        AND location_id = " . $input['location_id'] . "
                        AND status IN ('pending', 'called', 'requeue') 
                        AND queue_schema_id = " . $queueSchema['id'] . "";
                    $membersInAQueue = DB::select($query);
                    if( $membersInAQueue && count($membersInAQueue) ) {
                        $total_waiting_time += ( $membersInAQueue[0]->total_queue_tokens ) * $queueSchema['estimated_wait_time'];

                        $temp_queue_wise_data = [
                            'prefix' => $queueSchema['prefix'],
                            "totalQueueTokens" => $membersInAQueue[0]->total_queue_tokens,
                            "estimatedWaitTime" => $queueSchema['estimated_wait_time']
                        ];
                    }

                    $firstMemberInAQueue = DB::select("SELECT queue_pax, mobile_number, first_name, last_name, salutation, queue_order, status, sms_status, queue_token, country_code,
                    CONCAT('" . $queueSchema['prefix'] . "', '', queue_number)  AS queue_number, queue_number as qnumber,
                    queue_number * " . $queueSchema['estimated_wait_time'] . "  AS estimated_wait_time 
                    FROM manage_queue 
                    WHERE business_id = " . $input['business_id'] . "
                    AND location_id = " . $input['location_id'] . "
                    AND queue_schema_id = " . $queueSchema['id'] . "
                    AND deleted_at IS NULL 
                    AND status = 'assigned'
                    ORDER BY updated_at DESC LIMIT 1");

                    $temp = [
                        'id' => $queueSchema['id'],
                        'location' => $queueSchema['location'],
                        'pax_range' => $queueSchema['pax_range'],
                        'pax_range_start_from' => $queueSchema['pax_range_start_from'],
                        'pax_range_end_to' => $queueSchema['pax_range_end_to'],
                        'prefix' => $queueSchema['prefix'],
                        'start' => $queueSchema['start'],
                        'end' => $queueSchema['end'],
                        'estimated_wait_time' => $queueSchema['estimated_wait_time'],
                        'description' => $queueSchema['description'],
                        'registration' => (isset($firstMemberInAQueue) && $firstMemberInAQueue && count($firstMemberInAQueue)) ? $firstMemberInAQueue[0] : null
                    ];
                    $current_queue[] = $temp;

                    $queue_wise_data[] = $temp_queue_wise_data;
                }
                
                if($total_queues > 0) {
                    $average_wating_time = $total_waiting_time / $total_queues;    
                } else {
                    $average_wating_time = $total_waiting_time;
                }
            }

            $query = "SELECT mq.queue_pax, mq.mobile_number, mq.first_name, mq.last_name, mq.queue_order, mq.status, mq.sms_status, mq.queue_token, mq.country_code,
            CONCAT(qs.prefix, '', mq.queue_number) AS queue_number, mq.queue_number as qnumber, qs.estimated_wait_time as ewt, mq.queue_number * qs.estimated_wait_time AS estimated_wait_time,
            mq.id as queue_id
            FROM manage_queue as mq
            JOIN queue_schemas as qs ON mq.queue_schema_id = qs.id
            WHERE mq.business_id = " . $input['business_id'] . " 
            AND mq.location_id = " . $input['location_id'] . " 
            AND mq.deleted_at IS NULL 
            AND mq.status IN ('missed');";
            $missedQueueList = DB::select($query);

            $data[] = [
                "currentQueue" => $current_queue,
                "averageWatingTime" => round((number_format((float)$average_wating_time, 2, '.', ''))/5) * 5,
                "totalWaitingTime" => $total_waiting_time,
                "totalQueues" => $total_queues,
                "queueWiseData" => $queue_wise_data,
                "missedQueueData" => $missedQueueList
            ];

            $response = new StreamedResponse();
            $response->setCallback(function () use ($data) {
                echo 'data: ' . json_encode($data) . "\n\n";
                ob_flush();
                flush();
                usleep(200000);
            });

            $response->headers->set('Content-Type', 'text/event-stream');
            $response->headers->set('X-Accel-Buffering', 'no');
            $response->headers->set('Cach-Control', 'no-cache');
            $response->send();

            if(connection_aborted()) {
                exit();
            }
            return ($data);
        } catch (\Exception $e) {
            \Log::emergency("File:" . $e->getFile(). "Line:" . $e->getLine(). "Message:" . $e->getMessage());
            $msg = __('messages.something_went_wrong');

            $output = [
                'errorMessage' => $msg
            ];
            return $output;
        }
    }

    function checkUpdateDeliveryStatus(Request $request) {
        $input = $request;
        $orderData = [];

        if(isset($input['token'])) {
            $result = User::checkUserToken($input['token'], $input['user_id']);
            
            if($result) {
                $data = array();
                
                $deliveryStatusRowCount = $this->getDeliveryStatusByRowCount($input);
                $FE_deliveryStatusRowCount = (array)json_decode($input['deliveryStatusRowCount']);

                // get front end current data row count, then send message to front end if row count not same (backend !== front end)
                if(strcmp(json_encode($deliveryStatusRowCount), json_encode($FE_deliveryStatusRowCount))) {
                    $data[] = [
                        'deliveryStatusRowCount'  => $deliveryStatusRowCount
                    ];

                    $response = new StreamedResponse();
                    $response->setCallback(function () use ($data) {
                        echo 'data: ' . json_encode($data) . "\n\n";
                        flush();
                        usleep(500000);
                    });

                    $response->headers->set('Content-Type', 'text/event-stream');
                    $response->headers->set('X-Accel-Buffering', 'no');
                    $response->headers->set('Cach-Control', 'no-cache');
                    $response->send();

                    if(connection_aborted()) {
                        exit();
                    }
                }
                return ($data);
            } 
            else { return["errorMessage"=>'Invalid token.']; }
        } 
        else { return["errorMessage"=>'Invalid token.']; }

        // sleep(15);
    }
    
}

