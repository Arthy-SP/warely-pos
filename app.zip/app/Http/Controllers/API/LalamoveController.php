<?php

namespace App\Http\Controllers\API;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\BusinessLocation;
use App\Transaction;
use Carbon\Carbon;

class LalamoveController extends Controller {

    function getQuotation(Request $request) {
        $quotation_data = $request->only('business_id', 'cust_lat', 'cust_lng','cust_add', 'cust_name', 'cust_phone', 'cust_remark');

        $business_locations = BusinessLocation::where('business_id', $quotation_data['business_id'])
                                            ->where('is_active', 1)
                                            ->get();
        // Put your key and secret here
        // $key = "99dedb31c79c8aa20d75662866f48ce5"; // put your lalamove API key here
        // $secret = "h0SMij8vAT+aaGAaKGwRJxXNjI7Pw+Ie+DcfjzGq7VHQKtzsI1JnPHDHB2+zV6ru"; // put your lalamove API secret here
        $time = time() * 1000;
        $lalamoveBaseURL = config('constants.lalamoveBaseURL');
        //$lalamoveBaseURL = "https://rest.sandbox.lalamove.com"; // URl to Lalamove Sandbox API
        //$lalamoveBaseURL = "https://rest.lalamove.com";
        $method = 'POST';
        $path = '/v2/quotations';
        $region = 'SG_SIN';

        $charges = [];

        foreach($business_locations as $valueKey => $value)
        {
            $onemap_api = "https://developers.onemap.sg/commonapi/search?searchVal=".$value['zip_code']."&returnGeom=Y&getAddrDetails=Y";

            $key = $value['lalamove_pk']; // put your lalamove API key here
            $secret = $value['lalamove_sk']; // put your lalamove API secret here

            $onemap_curl = curl_init();
            curl_setopt_array($onemap_curl, array(
                CURLOPT_URL => $onemap_api,
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_ENCODING => '',
                CURLOPT_MAXREDIRS => 10,
                CURLOPT_TIMEOUT => 3,
                CURLOPT_FOLLOWLOCATION => true,
                CURLOPT_HEADER => false, // Enable this option if you want to see what headers Lalamove API returning in response
                CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
                CURLOPT_CUSTOMREQUEST => 'GET',
                CURLOPT_HTTPHEADER => array(
                    "Content-type: application/json; charset=utf-8",
                    "Accept: application/json",
                ),
            ));

            $onemap_response = curl_exec($onemap_curl);
            $onemap_err = curl_error($onemap_curl);
            $onemap_httpCode = curl_getinfo($onemap_curl, CURLINFO_HTTP_CODE);
            curl_close($onemap_curl);

            if($onemap_httpCode == "200")
            {
                $onemap_response = json_decode($onemap_response);

                // Please, find information about body structure and passed values here https://developers.lalamove.com/#get-quotation
                $body = '{
                    "serviceType": "MOTORCYCLE",
                    "specialRequests": [],
                    "requesterContact": {
                        "name": "'.$value['name'].'",
                        "phone": "'.$value['mobile'].'"
                    },
                    "stops": [
                        {
                            "location": {
                                "lat": "'.$onemap_response->results[0]->LATITUDE.'",
                                "lng": "'.$onemap_response->results[0]->LONGTITUDE.'"
                            },
                            "addresses": {
                                "en_SG": {
                                    "displayString": "'.$value['city'].'",
                                    "market": "'.$region.'"
                                }
                            }
                        },
                        {
                            "location": {
                                "lat": "'.$quotation_data['cust_lat'].'", 
                                "lng": "'.$quotation_data['cust_lng'].'"
                            },
                            "addresses": {
                                "en_SG": {
                                    "displayString": "'.$quotation_data['cust_add'].'",
                                    "market": "'.$region.'"
                                }
                            }
                        }
                    ],
                    "deliveries": [
                        {
                            "toStop": 1,
                            "toContact": {
                                "name": "'.$quotation_data['cust_name'].'",
                                "phone": "'.$quotation_data['cust_phone'].'"
                            },
                            "remarks": "'.$quotation_data['cust_remark'].'"
                        }
                    ]
                }';

                $rawSignature = "{$time}\r\n{$method}\r\n{$path}\r\n\r\n{$body}";
                $signature = hash_hmac("sha256", $rawSignature, $secret);
                $startTime = microtime(true);
                $token = $key.':'.$time.':'.$signature;

                $curl = curl_init();
                curl_setopt_array($curl, array(
                    CURLOPT_URL => $lalamoveBaseURL.$path,
                    CURLOPT_RETURNTRANSFER => true,
                    CURLOPT_ENCODING => '',
                    CURLOPT_MAXREDIRS => 10,
                    CURLOPT_TIMEOUT => 3,
                    CURLOPT_FOLLOWLOCATION => true,
                    CURLOPT_HEADER => false, // Enable this option if you want to see what headers Lalamove API returning in response
                    CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
                    CURLOPT_CUSTOMREQUEST => 'POST',
                    CURLOPT_POSTFIELDS => $body,
                    CURLOPT_HTTPHEADER => array(
                        "Content-type: application/json; charset=utf-8",
                        "Authorization: hmac ".$token, // A unique Signature Hash has to be generated for EVERY API call at the time of making such call.
                        "Accept: application/json",
                        "X-LLM-Market: {$region}" // Please note to which city are you trying to make API call
                    ),
                ));

                $response = curl_exec($curl);
                $err = curl_error($curl);
                $httpCode = curl_getinfo($curl, CURLINFO_HTTP_CODE);
                curl_close($curl);

                if(!empty($value["custom_field1"]))
                {
                    $open_close_time = explode(' - ', $value["custom_field1"]);
                    $is_open = Carbon::now()->between(
                            Carbon::parse($open_close_time[0]), 
                            Carbon::parse($open_close_time[1])
                    );
                    
                    if($is_open) {
                        if(!empty($value["custom_field3"])) {
                            $custom_field3 = json_decode($value["custom_field3"]);
                            if(count($custom_field3) == 2) {
                                $now = Carbon::now();
                                $start = Carbon::createFromTimeString($custom_field3[0][1]);
                                $end = Carbon::createFromTimeString($custom_field3[1][0]);
            
                                if ($now->between($start, $end)) {
                                    $is_open = false;
                                }
                            }
                        }
                    }
                    
                    $query = BusinessLocation::leftJoin(
                        'store_status AS SS',
                        'business_locations.id',
                        '=',
                        'SS.location_id'
                    )
                    ->where('SS.location_id', $value["id"])
                    ->where('SS.active', 1);
            
                    $store_status = $query->orderBy('SS.created_at', 'desc')
                                        ->select('SS.*')
                                        ->get();
                                        
                    if($is_open) {
                        if(empty(json_decode($store_status))) {
                            $is_open = true;
                        } else {
                            $is_open = false;
                        }
                    }
                    
                    $value["is_open"] = $is_open;
                    $value["open_time"] = $open_close_time[0];
                    $value["close_time"] = $open_close_time[1];
                }
                else
                {
                    $value["is_open"] = false;
                    $value["open_time"] = "";
                    $value["close_time"] = "";
                }

                $charges[] = [
                    'id' => $value['id'],
                    'name' => $value['name'],
                    'address' => $value['city'],
                    'phone' => $value['mobile'],
                    'custom_field1' => $value['custom_field1'],
                    'custom_field2' => $value['custom_field2'],
                    'custom_field3' => $value['custom_field3'],
                    'is_open' => $value["is_open"],
                    'open_time' => $value["open_time"],
                    'close_time' => $value["close_time"],
                    'lat' => $onemap_response->results[0]->LATITUDE,
                    'lng' => $onemap_response->results[0]->LONGTITUDE,
                    'charges' => json_decode($response)
                ];
            }
        }
        return $charges;
    }

    function placeOrder(Request $request) {
        $order_data = $request->only('transaction_id', 'business_id', 'location_id', 'outlet_lat', 'outlet_lng',
                                    'outlet_add', 'cust_lat', 
                                    'cust_lng', 'cust_add', 
                                    'cust_name', 'cust_phone', 
                                    'cust_remark', 'quoted_fee', 'quoted_currency');

        // Put your key and secret here
        // $key = "99dedb31c79c8aa20d75662866f48ce5"; // put your lalamove API key here
        // $secret = "h0SMij8vAT+aaGAaKGwRJxXNjI7Pw+Ie+DcfjzGq7VHQKtzsI1JnPHDHB2+zV6ru"; // put your lalamove API secret here

        $lalamove_result = BusinessLocation::where('business_id', $order_data['business_id'])
                                  ->where('id', $order_data['location_id'])
                                  ->select('name', 'mobile', 'lalamove_pk','lalamove_sk')
                                  ->get()
                                  ->toArray();
        $requesterName = $lalamove_result[0]['name'];
        $requesterContact = $lalamove_result[0]['mobile'];
        $key = $lalamove_result[0]['lalamove_pk']; // put your lalamove API key here
        $secret = $lalamove_result[0]['lalamove_sk']; // put your lalamove API secret here

        $time = time() * 1000;
        $lalamoveBaseURL = config('constants.lalamoveBaseURL');
        //$lalamoveBaseURL = "https://rest.sandbox.lalamove.com"; // URl to Lalamove Sandbox API
        //$lalamoveBaseURL = "https://rest.lalamove.com";
        $method = 'POST';
        $path = '/v2/orders';
        $region = 'SG_SIN';

        // Please, find information about body structure and passed values here https://developers.lalamove.com/#get-quotation
        $body = '{
            "serviceType": "MOTORCYCLE",
            "specialRequests": [],
            "requesterContact": {
                "name": "'.$requesterName.'",
                "phone": "'.$requesterContact.'"
            },
            "stops": [
                {
                    "location": {
                        "lat": "'.$order_data['outlet_lat'].'",
                        "lng": "'.$order_data['outlet_lng'].'"
                    },
                    "addresses": {
                        "en_SG": {
                            "displayString": "'.$order_data['outlet_add'].'",
                            "market": "'.$region.'"
                        }
                    }
                },
                {
                    "location": {
                        "lat": "'.$order_data['cust_lat'].'", 
                        "lng": "'.$order_data['cust_lng'].'"
                    },
                    "addresses": {
                        "en_SG": {
                            "displayString": "'.$order_data['cust_add'].'",
                            "market": "'.$region.'"
                        }
                    }
                }
            ],
            "deliveries": [
                {
                    "toStop": 1,
                    "toContact": {
                        "name": "'.$order_data['cust_name'].'",
                        "phone": "'.$order_data['cust_phone'].'"
                    },
                    "remarks": "'.$order_data['cust_remark'].'"
                }
            ],
            "quotedTotalFee": {
                "amount": "'.$order_data['quoted_fee'].'",
                "currency": "'.$order_data['quoted_currency'].'"
            }
        }';

        $rawSignature = "{$time}\r\n{$method}\r\n{$path}\r\n\r\n{$body}";
        $signature = hash_hmac("sha256", $rawSignature, $secret);
        $startTime = microtime(true);
        $token = $key.':'.$time.':'.$signature;

        $curl = curl_init();
        curl_setopt_array($curl, array(
            CURLOPT_URL => $lalamoveBaseURL.$path,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => '',
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 3,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HEADER => false, // Enable this option if you want to see what headers Lalamove API returning in response
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => 'POST',
            CURLOPT_POSTFIELDS => $body,
            CURLOPT_HTTPHEADER => array(
                "Content-type: application/json; charset=utf-8",
                "Authorization: hmac ".$token, // A unique Signature Hash has to be generated for EVERY API call at the time of making such call.
                "Accept: application/json",
                "X-LLM-Market: {$region}" // Please note to which city are you trying to make API call
            ),
        ));

        $response = json_decode(curl_exec($curl));
        $http_code = curl_getinfo($curl, CURLINFO_HTTP_CODE);
        curl_close($curl);
        //return $response->orderRef;
        if(isset($response->orderRef))
        {
            $transaction = Transaction::where('id', $order_data['transaction_id'])
                                        ->firstOrFail();
            $lalamove_result = [
                'lalamove_orderRef' => $response->orderRef,
                'lalamove_status' => "ASSIGNING_DRIVER",
                'lalamove_result' => json_encode($response)
            ];
            $transaction->fill($lalamove_result);
            $transaction->update();
        }

        return json_encode($response);

        // echo "Total elapsed http request/response time in milliseconds: ".floor((microtime(true) - $startTime)*1000)."\r\n";
        // echo "Authorization: hmac ".$token."\r\n";
        // echo 'Status Code: '. $http_code."\r\n";
        // echo 'Returned data: '.$response."\r\n";
    }
}

