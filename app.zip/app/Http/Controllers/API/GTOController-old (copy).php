<?php

namespace App\Http\Controllers\API;


use Carbon\Carbon;
use Exception;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Log;
use phpseclib\Net\SFTP;

use App\BusinessLocation;
use App\Http\Controllers\Controller;
use App\Transaction;
use DB;


class GTOController extends Controller
{

    const OUTLET_LOCATIONS = [
        ['id'=> 0, 'name'=> "OrchardGateway", 'startDate'=> '12/01/2022','report_type' => 'hourly'],
        ['id'=> 1, 'name'=> "Vivocity", 'startDate'=> '01/01/2023','report_type' => 'hourly'],
        ['id'=> 2, 'name'=> "Thomson Plaza", 'startDate'=> '12/01/2022','report_type' => 'hourly'],
        ['id'=> 3, 'name'=> "Jem", 'startDate'=> '12/01/2022','report_type' => 'hourly'],
        ['id'=> 4, 'name'=> "Suntec", 'startDate'=> '03/16/2023','report_type' => 'hourly'],
        ['id'=> 5, 'name'=> "PLQ", 'startDate'=> '12/01/2022','report_type' => 'hourly'],
        ['id'=> 6, 'name'=> "Hillon Mall", 'startDate'=> '05/01/2023','report_type' => 'hourly'],
        ['id'=> 7, 'name'=> "SingPost Centre", 'startDate'=> '12/01/2022','report_type' => 'hourly'],
        ['id'=> 8, 'name'=> "TWM", 'startDate'=> '06/01/2023','report_type' => 'hourly'], 
        ['id'=> 9, 'name'=> "Reality Yoga", 'startDate'=> '01/01/2024','report_type' => 'hourly'], 
        ['id'=> 10, 'name'=> "DTS MARKETING PTE LTD", 'startDate'=> '01/03/2024','report_type' => 'date_wise']
    ];
    
    /**
     * Constructor
     */
    public function __construct()
    {
    }

    public function cron_generate_GTO_files()
    {
        $now = Carbon::now();

        $location_details = BusinessLocation::whereNotNull('outlet_location_id')
            ->groupBy('business_id')
            ->groupBy('outlet_location_id')
            ->select('id', 'outlet_location_id', 'business_id', 'name', 'machine_id', 'ftp_server', 'ftp_password', 'is_sftp')
            ->selectRaw('GROUP_CONCAT(id) as locs')
            ->get();

        if (!empty($location_details)) {
            foreach ($location_details as $location_detail) {

                if (!empty($location_detail->machine_id)) {
                    $business_id = $location_detail->business_id;
                    //dd($business_id);
                    //$location_id = $location_detail->id;
                    $location_id = explode(',', $location_detail->locs);
                    // if( $location_detail->machine_id == "8000360" || $location_detail->machine_id == "30200118" ) { // IF START
                    // for($day=01; $day<=14;$day++){ // FOR START
                    //     $day = 19;
                    // $created_at = new Carbon('2023-12-'.$day.' 23:00:05');
                    $created_at = Carbon::now();

                    $reportType = self::OUTLET_LOCATIONS[$location_detail->outlet_location_id]['report_type'];

                    if ($reportType === "hourly") {
                        $transactions = Transaction::leftJoin('transaction_payments as t', 't.transaction_id', '=', 'transactions.id')
                        ->leftJoin('tax_rates as tr', 'tr.id', '=', 'transactions.tax_id')
                        ->where('transactions.business_id', $business_id)
                        ->whereIn('transactions.location_id', $location_id)
                        ->whereIn('transactions.type', array('sell', 'sell_return'))
                        ->where('transactions.status', 'final')
                        ->whereIn('transactions.payment_status', array('paid', 'partial'))
                        ->whereDate('transactions.created_at', $created_at)
                        ->select('transactions.*', 't.method', 't.card_type', 't.amount', 'tr.amount as tax_rate')
                        ->get()->groupBy(function ($date) {
                          return Carbon::parse($date->created_at)->format('H');
                        });                        
                    } elseif ($reportType === "date_wise") {
                        $transactions = Transaction::leftJoin('transaction_payments as t', 't.transaction_id', '=', 'transactions.id')
                        ->leftJoin('tax_rates as tr', 'tr.id', '=', 'transactions.tax_id')
                        ->where('transactions.business_id', $business_id)
                        ->whereIn('transactions.location_id', $location_id)
                        ->whereIn('transactions.type', array('sell', 'sell_return'))
                        ->where('transactions.status', 'final')
                        ->whereIn('transactions.payment_status', array('paid', 'partial'))
                        ->whereDate('transactions.created_at', $created_at)
                        ->select('transactions.*', 't.method', 't.card_type', 't.amount', 'tr.amount as tax_rate')
                        ->get()->groupBy(function ($date) {
                          return Carbon::parse($date->created_at)->format('d');
                        });
                    }
                    if (array_key_exists($location_detail->outlet_location_id, self::OUTLET_LOCATIONS)) {
                        $searchString = self::OUTLET_LOCATIONS[$location_detail->outlet_location_id]['name'];
                    } else {
                        $searchString = 'NA';
                    }
                    if ($searchString != 'NA') {

                        $machineId = $location_detail->machine_id; // Need to change
                        $subFolderExist = false;
                        $vivoDirectories = Storage::disk('local')->allDirectories('GTO/' . $searchString);
                        $subDirectory = 'GTO/' . $searchString . '/' . $machineId;

                        if (count($vivoDirectories) > 0) {
                            foreach ($vivoDirectories as $directoryString) {
                                if (strpos($directoryString, (string) $machineId) !== false) {
                                    $subFolderExist = true;
                                    break;
                                }
                            }

                            if ($subFolderExist) {
                                Storage::disk('local')->makeDirectory($subDirectory);
                            }
                        } else {
                            Storage::disk('local')->makeDirectory($subDirectory);
                        }

                        $today_date = Carbon::parse($created_at)->format('Ymd');
                        $subSubFolderExist = false;
                        $subDirectories = Storage::disk('local')->allDirectories($subDirectory);
                        $subSubDirectory = 'GTO/' . $searchString . '/' . $machineId . '/' . $created_at->format('Y') . '/' . $created_at->format('m');
                        if (count($subDirectories) > 0) {
                            foreach ($subDirectories as $subDirectoryString) {
                                if (strpos($subDirectoryString, $today_date) !== false) {
                                    $subSubFolderExist = true;
                                    break;
                                }
                            }

                            if ($subSubFolderExist) {
                                Storage::disk('local')->makeDirectory($subSubDirectory);
                            }
                        } else {
                            Storage::disk('local')->makeDirectory($subSubDirectory);
                        }
                        $file = $this->getFileNameForOutletLocation($subSubDirectory, $location_detail->outlet_location_id, $machineId, $created_at, $reportType);
                        if (!$file)
                            continue;
                        if($reportType == "hourly"){
                            if (count($transactions) > 0) {
                                for ($hour = 0; $hour <= 23; $hour++) {
                                    $is_matched = false;
                                    foreach ($transactions as $key => $hourlyTransactions) {
                                        if ($key == sprintf('%02d', $hour)) {
                                            $line = $this->getLineForForOutletLocation($key, $hourlyTransactions, $location_detail->outlet_location_id, $machineId, $created_at, $reportType);
                                            $is_matched = true;
                                            break;
                                        }
                                    }
                                    if (!$is_matched) {
                                        $line = $this->getLineForForOutletLocation(sprintf('%02d', $hour), [], $location_detail->outlet_location_id, $machineId, $created_at, $reportType);
                                    }
                                    $this->saveLineToFile($file, $line);
                                }
                            } else {
                                $j = 0;
                                while (sprintf('%02d', $j) != '24') {
                                    $line = $this->getLineForForOutletLocation($j, [], $location_detail->outlet_location_id, $machineId, $created_at, $reportType);
                                    $this->saveLineToFile($file, $line);
                                    $j++;
                                }
                            }
                        }else{
                            if (count($transactions) > 0) {
                                for ($day = 0; $day<1; $day++) {
                                    $is_matched = false;
                                    foreach ($transactions as $key => $dailyTransactions) {
                                        $line = $this->getLineForForOutletLocation($key, $dailyTransactions, $location_detail->outlet_location_id, $machineId, $created_at);
                                        $is_matched = true;
                                        break;
                                    }
                                    if (!$is_matched) {
                                        $line = $this->getLineForForOutletLocation(sprintf('%02d', $day), [], $location_detail->outlet_location_id, $machineId, $created_at);
                                    }
                                    $this->saveLineToFile($file, $line);
                                }
                            } else {
                                $j = 0;
                                while (sprintf('%02d', $j) != '1') {
                                    $line = $this->getLineForForOutletLocation($j, [], $location_detail->outlet_location_id, $machineId, $created_at);
                                    $this->saveLineToFile($file, $line);
                                    $j++;
                                }
                            }
                        }
                        //$this->saveToFTP($location_detail, $file);                    } else {
                        Log::error("machine id / FTP / File format not available for " . $location_detail->name . '<br/>');
                    }
                }
            }
        }
    }

    private function saveLineToFile($file_name, $line)
    {
        Storage::disk('local')->append($file_name, $line);
    }

    private function saveToFTP($location, $file)
    {
        try{
        $ftp_server = $location->ftp_server;
        $ftp_username = $location->machine_id;
        $ftp_userpass = $location->ftp_password;
        $name = basename($file);
        $file = public_path('uploads/' . $file);
        if($location->is_sftp) {
            $sftp = new SFTP($ftp_server);
            $sftp->login($ftp_username, $ftp_userpass);
            $sftp->put($name, $file, SFTP::SOURCE_LOCAL_FILE);
        }else{
            $ftp_conn = ftp_connect($ftp_server, 21);
            if($ftp_conn) {
                ftp_login($ftp_conn, $ftp_username, $ftp_userpass);
                // Enter passive mode
                ftp_pasv($ftp_conn, true);
                ftp_put($ftp_conn, $name, $file, FTP_ASCII);
                ftp_close($ftp_conn);
            }else {
                Log::error("Could not connect to $ftp_server for $location->name");
            }
        }
        
        Log::info('File '.$file .' sent to : '.$ftp_server);
        } catch(Exception $e) {
            Log::error($e->getMessage().'  with File'.$file);
        }

    }

    public function getFileNameForOutletLocation($directory, $outlet_location_id, $machineId = "XXXXXX", $date, $type=null)
    {
        
        $fileFormats = [2 => "H{MID}_{YYYYMMDD}", 3 => "{MID}_{YYYYMMDD}_{mis}", 4 => "{MID}_{YYYYMMDD}_{mis}", 5 => "H{MID}_{YYYYMMDD}", 6 => "H{MID}_{YYYYMMDD}", 8 => "H{MID}_{YYYYMMDD}", 9 => "TD_{YYYYMMDD}"];
        if(!array_key_exists($outlet_location_id, $fileFormats)){
            Log::error("file format not provided for $machineId");
             return false;
        }
        $fileNameFormat = $fileFormats[$outlet_location_id];
        $fileName = str_replace('{MID}', $machineId, $fileNameFormat);
        $fileName = str_replace('{YYYYMMDD}', $date->format('Ymd'), $fileName);
        $fileName = str_replace('{mis}', $date->format('His'), $fileName);
        $fileName = $fileName.'.txt';
        $exists = Storage::disk('local')->exists($directory.'/'.$fileName);
        
        $i=1;
        while($exists) {
            $old_file = $directory.'/'.$fileName.'.prev'.$i;
            $exists = Storage::disk('local')->exists($old_file);
            if(!$exists){
                Storage::move($directory.'/'.$fileName, $old_file); 
                break;
            }
            $i++;
        }

        return $directory.'/'.$fileName;
    }

    private function getLineForForOutletLocation($hour, $hourly_transactions, $outlet_location_id, $machineId = "XXXXXX", $date, $type=null)
    {

        $gto_sales = 0;
        $gst = 0;
        $discount = 0;
        $service_charges = 0;
        $pax = 0;
        //$date = Carbon::now();
        $cash = 0; 
        $nets = 0;
        $visa = 0; 
        $mastercard = 0;
        $amex = 0; 
        $voucher = 0;
        $others = 0;
        $outlets = array(2, 5, 6, 8); // outlets which requires card payment details separately
        
        foreach ($hourly_transactions as $transaction) {
            
            if($transaction->type=='sell'){
                $amount_before_tax = $transaction->amount - $transaction->tax_amount;
                $gto_sales += $amount_before_tax;
                $gst += $transaction->tax_amount;
                $discount += $transaction->total_discount_amount;
                $service_charges += $transaction->service_charges;
                $date = $transaction->created_at;
                $pax=1;
                if($transaction->method =='card' && in_array($outlet_location_id, $outlets)) {  //outlet_location_id check because they need informmation for card type as well
                    switch($transaction->card_type) {
                        case 'bank_transfer':
                            $nets+= $amount_before_tax;
                        break;
                        case 'visa':
                            $visa+= $amount_before_tax;
                        break;
                        case 'custom_pay_1':
                            $visa+= $amount_before_tax;
                        break;
                        case 'mastercard':
                            $mastercard+= $amount_before_tax;
                        break;
                        case 'custom_pay_2':
                            $mastercard+= $amount_before_tax;
                        break;
                        case 'master':
                            $mastercard+= $amount_before_tax;
                        break;
                        case 'amex':
                            $amex+= $amount_before_tax;
                        break;
                        case 'voucher':
                            $voucher+= $amount_before_tax;
                        break;
                        default:
                            $others+= $amount_before_tax;
                    }
                }else  if($transaction->method =='cash') {
                    $cash+= $amount_before_tax;
                }
            }else {
                $gto_sales -= ($transaction->final_total);
            }
        }
            //THOMSON PLAZA ->  MachinID | Batch ID | Date(DDMMYYYY) | Hour (00-23) | Receipt Count | GTO Sales (00.00) | GST (00.00) | Discount (00.00) | Service Charge (00.00) | No. of Pax (00) | Cash (00.00) | NETS(00.00) | Visa(00.00) | MasterCard(00.00) | Amex(00.00) | Voucher(00.00) | Others(00.00) | GST Registered (Y/N)
            //PLQ           ->  MachinID | Batch ID | Date(DDMMYYYY) | Hour (00-23) | Receipt Count | GTO Sales (00.00) | GST (00.00) | Discount (00.00) | Service Charge (00.00) | No. of Pax (00) | Cash (00.00) | NETS(00.00) | Visa(00.00) | MasterCard(00.00) | Amex(00.00) | Voucher(00.00) | Others(00.00) | GST Registered (Y/N)
            //Jem           ->  MachinID | Date(DDMMYYYY) | Batch ID | Hour (0059-2359) | Receipt Count | GTO Sales (00.00) | GST (00.00) | Discount (00.00) | No. of Pax (00)
            //Suntec City   ->  MachinID | Date(DDMMYYYY) | Batch ID | Hour (0059-2359) | Receipt Count | GTO Sales (00.00) | GST (00.00) | Discount (00.00) | No. of Pax (00)
        
        $batch_id = Carbon::createFromDate(self::OUTLET_LOCATIONS[$outlet_location_id]['startDate'])->diffInDays($date)+1;
        if($type == "hourly"){
            if(in_array($outlet_location_id, $outlets))
            return $machineId.'|'.$batch_id.'|'.$date->format('dmY') . '|'.sprintf('%02d', $hour) .'|'.count($hourly_transactions).'|'.number_format($gto_sales, 2,'.','') . '|' .number_format($gst, 2,'.','') . '|' . number_format($discount, 2,'.','') .'|'.number_format($service_charges, 2,'.','').'|'.$pax.'|'.number_format($cash, 2,'.','').'|'.number_format($nets, 2,'.','').'|'.number_format($visa, 2,'.','').'|'.number_format($mastercard, 2,'.','').'|'.number_format($amex, 2,'.','').'|'.number_format($voucher, 2,'.','').'|'.number_format($others, 2,'.','').'|'.'Y';
        else
            return $machineId . '|' . $date->format('dmY') . '|' .$batch_id. '|' . sprintf('%02d', $hour) . '59|' . count($hourly_transactions) . '|' . number_format($gto_sales, 2,'.','') . '|' . number_format($gst, 2,'.','') . '|' . number_format($discount, 2,'.','') . '|'.$pax;
        } else{
            if(in_array($outlet_location_id, $outlets))
            return $machineId.'|'.$batch_id.'|'.$date->format('Ymd') . '|'.count($hourly_transactions).'|'.number_format($gto_sales, 2,'.','') . '|' .number_format($gst, 2,'.','') . '|' . number_format($discount, 2,'.','') .'|'.number_format($service_charges, 2,'.','').'|'.$pax.'|'.number_format($cash, 2,'.','').'|'.number_format($nets, 2,'.','').'|'.number_format($visa, 2,'.','').'|'.number_format($mastercard, 2,'.','').'|'.number_format($amex, 2,'.','').'|'.number_format($voucher, 2,'.','').'|'.number_format($others, 2,'.','').'|'.'Y';
        else
            return $machineId . '|' . $date->format('Ymd') . '|' .$batch_id. '|' . count($hourly_transactions) . '|' . number_format($gto_sales, 2,'.','') . '|' . number_format($gst, 2,'.','');
        }

    }

    private function getGSTRate($year) {
        $rates = array('2022' => 7, 2023 => 8, '2024' => 9, '2025' => 10);
        return array_key_exists($year, $rates) ? $rates[$year] : 8;
    }
    
}

