<?php

namespace App\Http\Controllers\API;

use DB;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\BusinessLocation;
use App\TransactionPayment;
use App\User;
use App\CashRegister;
use App\OpenDrawerRecord;
use App\PosResTables;
use App\Transaction;
use App\Http\Controllers\CashRegisterController;
use App\Utils\CashRegisterUtil;
use App\Utils\ProductUtil;
use App\Utils\TransactionUtil;
use App\Utils\BusinessUtil;
use App\Attendance;
use Carbon\Carbon;
use Config;
use App\TableQrToken;
use App\InvoiceNumbers;
use App\Queue\QueueTable;

class CashFloatController extends Controller
{
    protected $cashRegisterController;
    protected $cashRegisterUtil;
    protected $productUtil;
    protected $transactionUtil;

    public function __construct( CashRegisterController $cashRegisterController,
        CashRegisterUtil $cashRegisterUtil, 
        ProductUtil $productUtil,
        TransactionUtil $transactionUtil )
    {
        $this->cashRegisterController = $cashRegisterController;
        $this->cashRegisterUtil = $cashRegisterUtil;
        $this->productUtil = $productUtil;
        $this->transactionUtil = $transactionUtil;
    }

    public function get_cash_float(Request $request)
    {
        $user_data = $request->only('business_location_id', 'token', 'business_id','user_id');

        if(isset($user_data['token']))
        {    
            $result = User::checkUserToken($user_data['token'], $user_data['user_id']);

            if($result)
            {
                $query = BusinessLocation::where('id', $user_data['business_location_id'])->first();
                $default_cash_float[0]['default_cash_float'] = $query->default_cash_float;
                $default_cash_float[0]['allow_lesser_cash_float_amount'] = $query->allow_lesser_cash_float_amount;
                // $default_cash_float = $query->get('default_cash_float', 'allow_lesser_cash_float_amount');

                return $this->respond($default_cash_float);
            }
            else
            {
                return["errorMessage"=>'Invalid token.'];
            }
        }
        else{
            return["errorMessage"=>'Invalid token.'];
        }
    }

    public function insert_cash_float(Request $request)
    {
        $user_data = $request->only('business_location_id', 'amount', 'started_at', 'token', 'business_id','user_id', 'ignore_default_cash_float');

        if(isset($user_data['token']))
        {    
            $result = User::checkUserToken($user_data['token'], $user_data['user_id']);

            if($result)
            {
                $query = BusinessLocation::where('id', $user_data['business_location_id']);
                $default_cash_float = $query->get()->pluck('default_cash_float')[0];

                $initial_amount = 0;
                if (!empty($request->input('amount'))) {
                    $initial_amount = $request->input('amount');
                }

                if($initial_amount < $default_cash_float && $user_data['ignore_default_cash_float'] != 1)
                {
                    return["errorMessage"=>'Cash float less than '.$default_cash_float.'.'];
                }
                else
                {
                    $user_id = $request->input('user_id');
                    $business_id = $request->input('business_id');
                    
                    // Close Previous Ones
                    // CashRegister::where([
                    //     'business_id' => $business_id,
                    //     'user_id' => $user_id,
                    //     'location_id' => $user_data['business_location_id']
                    // ])
                    // ->update([
                    //     'status'=>'close'
                    // ]);
                    
                    // Open new one
                    $register = CashRegister::create([
                        'business_id' => $business_id,
                        'user_id' => $user_id,
                        'status' => 'open',
                        'location_id' => $user_data['business_location_id'],
                        // 'started_at' => $user_data['started_at'],
                        'started_at' => date('Y-m-d H:i:s', strtotime($user_data['started_at'])),
                        'created_at' => \Carbon::now()->format('Y-m-d H:i:00')
                    ]);
                    if (!empty($initial_amount)) {
                        $register->cash_register_transactions()->create([
                            'amount' => $initial_amount,
                            'pay_method' => 'cash',
                            'type' => 'credit',
                            'transaction_type' => 'initial'
                        ]);

                        return $this->respond($register);
                    }
                }
            }
            else
            {
                return["errorMessage"=>'Invalid token.'];
            }
        }
        else{
            return["errorMessage"=>'Invalid token.'];
        }
    }

    public function get_close_sale_details(Request $request)
    {
        $user_data = $request->only('business_location_id', 'token', 'business_id','user_id', 'current_time', 'current_date');
        
        $businessLocation = BusinessLocation::find($user_data["business_location_id"]);
        if( !empty($businessLocation) && !empty($businessLocation->day_start_time) ) {
            $daystartTime = $businessLocation->day_start_time;
            $dayStartTime = $daystartTime.":00:00";
            $dayendTime = $daystartTime - 1;
            $dayEndTime = $dayendTime.":59:59";
        } else {
            $dayStartTime = str_replace(' ', '', Config::get('constants.businessStartTimeDefault'));
            $dayEndTime = str_replace(' ', '', Config::get('constants.businessEndTimeDefault'));
        }
        
        $payment_method_arr = [];
        $collection_details_result = [];
        $cash_details_result = [];
        $card_total = 0;
        $cash_total = 0;
        
        $current_time = null;
        if( isset($user_data["current_time"]) && $user_data["current_time"] ) {
            $current_time = $user_data["current_time"];
        }
        
        $current_date = null;
        if( isset($user_data["current_date"]) && $user_data["current_date"] ) {
            $current_date = $user_data["current_date"];
        }
        
        if( Config::get('constants.setBusinessTime') && !empty($businessLocation) && !empty($businessLocation->day_start_time) && !empty($current_time) && !empty($current_date) ) {
            $morning6TimeStamp = strtotime($current_date . " " . $dayEndTime);
            $dateTimeStamp = strtotime($current_date . " " . $current_time);
            if( $dateTimeStamp >= $morning6TimeStamp ) {
                $today = $current_date . ' ' .$dayStartTime;
                $tomorrow = date('Y-m-d', strtotime($current_date .' +1 day')) . ' ' .$dayEndTime;
            } else {
                $today = date('Y-m-d', strtotime($current_date .' -1 day')) . ' ' .$dayStartTime;
                $tomorrow = $current_date .' '.$dayEndTime;
            }
        } else {
            $today = Carbon::today()->format('Y-m-d') . Config::get('constants.businessStartTimeDefault');
            $tomorrow = Carbon::today()->format('Y-m-d') . Config::get('constants.businessEndTimeDefault');
        }
        
        // dd($today, $tomorrow);

        if(isset($user_data['token']))
        {    
            $result = User::checkUserToken($user_data['token'], $user_data['user_id']);

            if($result)
            {
                $query = CashRegister::leftjoin(
                    'cash_register_transactions as ct',
                    'ct.cash_register_id',
                    '=',
                    'cash_registers.id'
                )
                ->join(
                    'users as u',
                    'u.id',
                    '=',
                    'cash_registers.user_id'
                )
                ->leftJoin(
                    'business_locations as bl',
                    'bl.id',
                    '=',
                    'cash_registers.location_id'
                );

                $query->where('user_id', $user_data['user_id'])
                    ->where('cash_registers.status', 'open')
                    ->where('cash_registers.business_id', $user_data['business_id'])
                    ->where('cash_registers.location_id', $user_data['business_location_id'])
                    ->whereBetween('cash_registers.started_at', [$today, $tomorrow]);
                    
                    // ->whereDate('cash_registers.started_at', '=', \Carbon::now()->format('Y-m-d 00:00:00'));//\Carbon::now()->format('Y-m-d 00:00:00')

                $register_details = $query->orderBy('cash_registers.id', 'desc')->select(
                    'cash_registers.started_at as open_time',
                    'cash_registers.closed_at as closed_at',
                    'ct.amount'
                )->first();

                if(!empty($register_details)) {
                    $register_details->open_time = Carbon::parse($register_details->open_time)->format('d M Y, h:ia') . " - " . Carbon::now()->format('h:ia');
                
                    $payment_types = $this->productUtil->payment_types($user_data['business_location_id'], true);

                    foreach ($payment_types as $key => $paymentTypeValue) {
                        if(strtolower($paymentTypeValue) != 'cash')
                        {
                            array_push($payment_method_arr, strtolower($paymentTypeValue));
                            $collection_details_result[] = [
                                'payment_method' => strtolower($paymentTypeValue),
                                'quantity' => 0,
                                'payment_total_amount' => 0,
                            ];
                        }
                    }
                    
                    $transaction = Transaction::leftjoin('transaction_payments as t', 't.transaction_id', '=', 'transactions.id')
                                ->leftjoin('variations as w', 'w.product_id', '=', 'transactions.additional_discount_method')
                                ->leftjoin('tax_rates as z', 'z.id', '=', 'transactions.tax_id')
                                ->leftJoin(
                                    'transactions AS SR',
                                    'transactions.id',
                                    '=',
                                    'SR.return_parent_id'
                                )
                                ->with('sell_lines.variations.product')
                                ->where('transactions.business_id', $user_data['business_id'])
                                ->where('transactions.location_id', $user_data['business_location_id'])
                                ->where('transactions.type', 'sell')
                                ->where('transactions.is_direct_sale', 0)
                                // ->whereDate('transactions.transaction_date', '=', \Carbon::now()->format('Y-m-d 00:00:00'))
                                ->whereBetween('transactions.transaction_date', [$today, $tomorrow])
                                ->where('transactions.status', 'final')
                                ->orderBy('transactions.created_at', 'desc')
                                ->groupBy('transactions.id')
                                ->select('transactions.*', 't.method', 't.card_type', 'w.profit_percent', 'z.amount as tax_rate_amount', DB::raw('COUNT(SR.id) as return_exists'), 'SR.refund_all')
                                ->with(['contact', 'table'])
                                ->where(function($query) {
                                    $query->where('transactions.type_for_api', 'Dinein')
                                        ->orWhere('transactions.type_for_api', 'Takeaway')
                                        ->orWhere('transactions.type_for_api', 'Retail')
                                        ->orWhere('transactions.type_for_api', 'Kiosk')
                                        ->orWhere('transactions.type_for_api', 'Common');
                                })
                                ->get();
                                
                    $businessUtil = new BusinessUtil();
                    $business = $businessUtil->getDetails($user_data['business_id']);
                    $pos_settings = json_decode($business->pos_settings);
                
                    //return $transaction;
                    foreach ($transaction as $key => $value) {
                        $item = [];
                        $payments = [];
                        $increment = 0;
                        $final_total_for_single_item = 0;
                        $final_total_line_discount_amount = 0;
                        $service_charge_amount = 0;
                        $sellArray1 = $value['sell_lines'];
                        $finalItems = [];
                        foreach ($sellArray1->toArray() as $key => $item_sellLine) {
                            if ($item_sellLine['parent_sell_line_id'] == null) { 
                                $mainItem = $item_sellLine;
                                // dd($mainItem);
                                $mainItemPrice = $mainItem['unit_price_before_discount'];
                                foreach ($sellArray1->toArray() as $modifier) {
                                    if (!empty($modifier['parent_sell_line_id']) && $modifier['parent_sell_line_id'] == $mainItem['id'] && $item_sellLine["change_price"] == 0 && $modifier["children_type"] == "modifier") {
                                        $mainItemPrice += $modifier['unit_price_before_discount']; // Add the modifier price to the main product price
                                    }
                                }
                                // Update the main product price
                                $mainItem['unit_price_before_discount'] = $mainItemPrice;
                                // Add the updated main item to the final result array
                                $finalItems[] = $mainItem;
                            }
                        } 
                        $dineService  = $this->calculateItemTotalForDineIn($finalItems, $value['type_for_api'], $value['discount_amount'], $value['discount_type'], $value['rp_redeemed_amount'], $value['id']);

                        foreach ($value['sell_lines'] as $sellLinesKey => $sellLinesValue)
                        {
                            $total_line_discount_amount = 0;
                            
                            if($sellLinesValue["parent_sell_line_id"] == null && $sellLinesValue["transaction_id"] == $value['id'])
                            {
                                $adons = [];
                                $total_for_single_item = 0;
                                foreach ($value['sell_lines'] as $sellLinesKey1 => $sellLinesValue1)
                                {
                                    if($sellLinesValue1["parent_sell_line_id"] != null && $sellLinesValue1["parent_sell_line_id"] == $sellLinesValue['id'] && $sellLinesValue1["children_type"] == "modifier")
                                    {
                                        if( isset($sellLinesValue1['variations']) && !empty($sellLinesValue1['variations'])) {
                                            $adons[] = [
                                                'id' => $sellLinesValue1['variations']->id,
                                                'name' => $sellLinesValue1['variations']->name,
                                                'quantity' => $sellLinesValue1["quantity"],
                                                'amount' => $sellLinesValue1['unit_price_before_discount'], //unit_price_before_discount
                                            ];
                                        }
                                        if($sellLinesValue["quantity_returned"] == "0.0000" && $sellLinesValue["change_price"] == 0)
                                        {
                                            //total modifier price
                                            $total_for_single_item = $total_for_single_item + $sellLinesValue1['unit_price_before_discount'];
                                        }
                                    }
                                }

                                //main item price + modifier price
                                if($sellLinesValue['weight'] > 0) {
                                    // $total_for_single_item = ($sellLinesValue['unit_price_before_discount'] / $sellLinesValue['weight'] + $total_for_single_item) * $sellLinesValue["quantity"];
                                    $total_for_single_item = ($sellLinesValue['unit_price_before_discount'] + $total_for_single_item) * $sellLinesValue["quantity"];
                                } else {
                                    $total_for_single_item = ($sellLinesValue['unit_price_before_discount'] + $total_for_single_item)* $sellLinesValue["quantity"];
                                }

                                if($increment == 0)
                                {
                                    $total_dont_have_line_discount_amt = 0;
                                }

                                if($sellLinesValue["quantity_returned"] == "0.0000")
                                {
                                    $final_total_for_single_item += $total_for_single_item;
                                    //calculate if line item has line discount
                                    if($sellLinesValue['line_discount_type'] == "fixed")
                                    {
                                        $total_line_discount_amount += $sellLinesValue['line_discount_amount'];
                                    }
                                    else if($sellLinesValue['line_discount_type'] == "percentage")
                                    {
                                        $total_line_discount_amount = (($sellLinesValue['line_discount_amount']/100) * $total_for_single_item) + $total_line_discount_amount;
                                    }
                                    //calculate final total line discount amount
                                    $final_total_line_discount_amount += $total_line_discount_amount;
                                    //total if item dont have line discount amount
                                    if($total_line_discount_amount == 0)
                                    {
                                        $total_dont_have_line_discount_amt += $total_for_single_item;
                                    }
                                }
                                
                                $item[] = [
                                    'id' => $sellLinesValue['id'],
                                    'name' => !empty($sellLinesValue['variations']->product) ? $sellLinesValue['variations']->product->name : "",
                                    'quantity' => $sellLinesValue['quantity'],
                                    'quantity_returned' => $sellLinesValue["quantity_returned"],
                                    'amount' => $sellLinesValue['unit_price_before_discount'],
                                    'total_before_tax' => $value['total_before_tax'],
                                    'tax_amount' => $value['tax_amount'],
                                    'line_discount_type' => $sellLinesValue['line_discount_type'],
                                    'line_discount_amount' => $sellLinesValue['line_discount_amount'],
                                    'total_line_discount_amount' => $total_line_discount_amount,
                                    'total_for_single_item' => $total_for_single_item,
                                    'adons' => $adons,
                                ];

                                $increment++;
                            }
                        }

                        //calculate total discount amount and addon discount amount (e.g. Student discount)
                        if($value['discount_type'] == "fixed")
                        {
                            $discount_amount = $value['discount_amount'] + $final_total_line_discount_amount;
                            $addon_discount_amount = $value['discount_amount'];
                        }
                        else if($value['discount_type'] == "percentage")
                        {
                            $discount_amount = ($value['discount_amount'] * $total_dont_have_line_discount_amt) + $final_total_line_discount_amount;
                            $addon_discount_amount = $value['discount_amount'] * $total_dont_have_line_discount_amt;
                        }

                         //redeemed calculate 
                         if($value['rp_redeemed_amount'] > 0 && $value['return_exists'] != 1) {
                            $final_total_for_single_item = $final_total_for_single_item - $value['rp_redeemed_amount'];
                        } elseif($value['rp_redeemed_amount'] > 0 && $value['return_exists'] == 1) {
                            $rp_redeemed_amount_percent = ($value['rp_redeemed_amount'] / $value['total_before_tax']) * 100;
                            $rp_redeemed_amount = ($total_dont_have_line_discount_amt * $rp_redeemed_amount_percent) / 100;
        
                            $final_total_for_single_item = $final_total_for_single_item - $rp_redeemed_amount;
                            
                        }
                        //calculate servive charge amount
                        //$service_charge_amount = ($final_total_for_single_item - $discount_amount) * $value['service_charges'];
                        if($value['rp_redeemed_amount'] > 0) {
                            $service_charge_amount = $dineService * $value['service_charges'];  
                        } else {
                            $service_charge_amount = $dineService * $value['service_charges'];
                        }

                        $tax_amount = 0;
                        if($value['tax_id'] != null)
                        {
                            if( $value["is_inclusive_gst_applied"] )
                                $tax_amount = (($final_total_for_single_item - $discount_amount + $service_charge_amount) / (100 + $value['tax_rate_amount'] )) * $value['tax_rate_amount'];
                            else
                                $tax_amount = ($value['tax_rate_amount']/100) * ($final_total_for_single_item + $service_charge_amount - $discount_amount);
                        }
                        // $final_total = round($final_total_for_single_item, 2) + round($tax_amount, 2) - round($discount_amount, 2) + round($service_charge_amount, 2);
                        if( $value["is_inclusive_gst_applied"] )
                            $final_total = round($final_total_for_single_item, 2) - round($discount_amount, 2) + round($service_charge_amount, 2);
                        else 
                            $final_total = round($final_total_for_single_item, 2) + round($tax_amount, 2) - round($discount_amount, 2) + round($service_charge_amount, 2);
                        
                        $amount_rounding_method = $pos_settings->amount_rounding_method;
                        $payment_method = $value->method;
                        $latest_round_off_amount = $value['round_off_amount'];//$this->transactionUtil->latest_round_off_amount($payment_method, $final_total, $amount_rounding_method);
                        $final_total = round($final_total - $value['round_off_amount'], 2);
                        $voucher_amount = 0;
                        $voucher_value = 0;
                        if(!empty($value['voucher_details'])){
        
                            $item_details = $this->calculateItemTotalForVoucher($finalItems, $value['type_for_api'], $value['discount_amount'], $value['discount_type'], $value['rp_redeemed_amount'], $value['id']);
                            $voucher_details = json_decode($value['voucher_details']);
        
                            
                            $total_before_tax_amount = $item_details->filterFinalVoucherItem;
                            $voucher_service_charge =$item_details->filterFinalItemsPriceForVoucher * $value['service_charges'];
                            $total_before_tax_amount+=$voucher_service_charge;
                            
                            $voucherPercent = ($value['voucher_amount_used'] / $total_before_tax_amount) * 100;
                            $voucher_amount = $value['voucher_amount_used'];
                            $voucher_value = $voucherPercent;               
        
                            if ($value['return_exists'] == 1) {
                                $voucherAmount = ($final_total * $voucher_value) / 100;
                                $final_total =  round($final_total - $voucherAmount, 2);
                            }
                            else{
                                $voucher_data = json_decode($value['voucher_details']);
                                $final_total =  $final_total - $value['voucher_amount_used'];
                            }
        
                        }
                        if($value['return_exists'] == 1) {
                           $final_total = round($final_total + $value['round_off_amount'], 2);
                        }
                        
                        //For tip amount
                        if(!empty($value['tip_amount'])){
                            $final_total += $value['tip_amount']; 
                        }
                        
                        // For multiple payment
                        foreach($value['payment_lines'] as $payment_lines_key => $payment_line){
                            if(count($value['payment_lines']) == 1) {
                                if($final_total > 0) {
                                    $cash_received_amount = $final_total; //+ $latest_round_off_amount;
                                } else {
                                    $cash_received_amount = $final_total;
                                }
                            } else {
                                if($value['refund_all'] == 1) {
                                    $cash_received_amount = 0;
                                } else {
                                    $cash_received_amount = $payment_line['amount'];
                                }
                            }
                            $payments[] = [
                                'transaction_payment_id' => $payment_line['id'],
                                'method' => $payment_line['method'],
                                'card_type' => $payment_line['card_type'],
                                'last_4_card_digits' => $payment_line['last_4_card_digits'],
                                'received_amount' => $cash_received_amount
                            ];
                        }
                        $transaction_result[] = [
                            'id' => $value['id'],
                            'transaction_date' => $value['transaction_date'],
                            'table' => '',
                            'pax' => '',
                            'type' => $value['type'],
                            'total' => $final_total,
                            'paymentType' => $value['method'],
                            'card_type' => $value['card_type'],
                            'tax_amount' => $tax_amount,
                            'addon_discount' => ($value['profit_percent'] == null ? 0 : $value['profit_percent']),
                            'discount_type' => $value['discount_type'],
                            'discount_amount' => $discount_amount,
                            'service_charge_amount' => $service_charge_amount,
                            'tax_rate_amount' => $value['tax_rate_amount'],
                            'profit_percent' => ($value['profit_percent'] == null ? 0 : $value['profit_percent']),
                            'return_exists' => $value['return_exists'],
                            'refund_all' => $value['refund_all'],
                            'additional_discount_method' => $value['additional_discount_method'],
                            'addon_discount_amount' => $addon_discount_amount,
                            'item' => $item,
                            'payments' => $payments
                        ];
                    }

                    if(!empty($transaction_result)) {
                        foreach ($transaction_result as $key => $transactionValue) {
                            foreach ($transactionValue['payments'] as $paymentKey => $transactionPayment)
                            {
                                if($transactionPayment['method'] == "cash")
                                {
                                    if(in_array($transactionPayment['method'], $payment_method_arr))
                                    {
                                        foreach ($cash_details_result as $key => $cashDetailsValue) {
                                            if($cashDetailsValue['payment_method'] == $transactionPayment['method'])
                                            {
                                                $cash_details_result[$key]['quantity'] = $cashDetailsValue['quantity'] + 1;
                                                $cash_details_result[$key]['payment_total_amount'] += $transactionPayment['received_amount'];
                                                $cash_total += $transactionPayment['received_amount'];
                                            }
                                        }
                                    }
                                    else
                                    {
                                        array_push($payment_method_arr, $transactionPayment['method']);

                                        $cash_details_result[] = [
                                            'payment_method' => $transactionPayment['method'],
                                            'quantity' => 1,
                                            'payment_total_amount' => $transactionPayment['received_amount'],
                                        ];

                                        $cash_total += $transactionPayment['received_amount'];
                                    }
                                }
                                else
                                {
                                    if(in_array($transactionPayment['card_type'], $payment_method_arr))
                                    {
                                        foreach ($collection_details_result as $key => $collectionDetailsValue) {
                                            if($collectionDetailsValue['payment_method'] == $transactionPayment['card_type'])
                                            {
                                                $collection_details_result[$key]['quantity'] = $collectionDetailsValue['quantity'] + 1;
                                                $collection_details_result[$key]['payment_total_amount'] += $transactionPayment['received_amount'];
                                                $card_total += $transactionPayment['received_amount'];
                                            }
                                        }
                                    }
                                    // else
                                    // {
                                    //     array_push($payment_method_arr, $transactionValue['card_type']);

                                    //     $collection_details_result[] = [ 
                                    //         'payment_method' => $transactionValue['card_type'],
                                    //         'quantity' => 1,
                                    //         'payment_total_amount' => $transactionValue['final_total'],
                                    //     ];
                                    // }
                                }
                            }
                        }
                        return [
                            'open_time' => $register_details->open_time, 
                            'cash_float' => $register_details->amount, 
                            'collection_details_result' => $collection_details_result, 
                            'card_total' => $card_total, 
                            'total_cash' => $cash_total + $register_details->amount
                        ];
                    } else {
                        return ["errorMessage"=>'No transaction sales are recorded for today.'];
                    }  
                } else {
                    return ["errorMessage"=>'Today\'s sales are not available.'];
                }
            }
            else
            {
                return["errorMessage"=>'Invalid token.'];
            }
        }
        else{
            return["errorMessage"=>'Invalid token.'];
        }
    }

    function calculateItemTotalForDineIn($sellLines, $orderType = "Dinein", $globalDiscount = 0.0, $globalDiscountType = "fixed", $redeemedPoints = 0.0 , $transaction_id) {
        if (empty($sellLines)) {
            return 0.0;
        }

        // Step 5 - All Items without discount
        $allItemsWithoutDiscount = array_filter($sellLines, function($item) {
            return $item['line_discount_amount'] <= 0.0;
        });

        $allItemsWithoutDiscountPrice = array_map(function($item) {
            $quantity = $item['quantity'] ? $item['quantity'] : 1; // to do  
            return ($item['unit_price_before_discount'] ?? 0.0) * $quantity;
        }, $allItemsWithoutDiscount);

        $allItemsWithoutDiscountTotal = array_sum($allItemsWithoutDiscountPrice);

        // Step 6 - Dinein Items Weight
        $globalDiscountPrice = $globalDiscount ?? 0.0;
        $itemWeightPrice = 0.0;

        $itemWeightWithGlobalDiscount = array_map(function($item) use ($globalDiscountPrice, $allItemsWithoutDiscountTotal, $orderType ,$globalDiscountType) {
            $quantity = $item['quantity'] ? $item['quantity'] : 1; // to do  
            $itemTotal = ($item['unit_price_before_discount'] ?? 0.0)  * $quantity;
            $is_refund = $item['quantity_returned'] > 0 ? true :false; 
            if($globalDiscountType == 'fixed'){
                if( $allItemsWithoutDiscountTotal > 0.0)
                {
                     $itemWeightPrice = $itemTotal - ($itemTotal * $globalDiscountPrice) / $allItemsWithoutDiscountTotal;
                  }
                  else{
                     $itemWeightPrice = $itemTotal ;
                  }   
            }
            elseif($globalDiscountType == 'percentage'){
                    
                $itemWeightPrice = $itemTotal - ($itemTotal * $globalDiscountPrice);
                
            }
            else{

                $itemWeightPrice = $itemTotal;
            }    
            $itemTag = ($orderType === 'Takeaway') 
                ? ($item['tag'] === 'T' || $item['tag'] === '' || $item['tag'] === null ? 'T' : 'D') 
                : ($item['tag'] === 'D' || $item['tag'] === '' || $item['tag'] === null ? 'D' : 'T');
            return ['price' => $itemWeightPrice, 'tag' => $itemTag, 'is_refund' => $is_refund];
        }, $allItemsWithoutDiscount);
        
        // Step 8 - All Items with Rp Amount weight
        $itemsWithIndividualDiscount = array_filter($sellLines, function($item) {
            return $item['line_discount_amount'] > 0.0;
        });

        $itemsWithIndividualDiscount = array_map(function($item) use ($orderType) {
            $quantity = $item['quantity'] ? $item['quantity'] : 1; // to do  
            $itemPrice = ($item['unit_price_before_discount'] ?? 0.0) * $quantity ;
            $itemDiscount = ($item['line_discount_type'] === 'percentage') 
                ? $itemPrice * ($item['line_discount_amount'] / 100) 
                : $item['line_discount_amount'];
            $finalPrice = $itemPrice - $itemDiscount;
            $is_refund = $item['quantity_returned'] > 0 ? true :false; 
            $itemTag = ($orderType === 'Takeaway') 
                ? ( $item['tag'] === 'T' || $item['tag'] === '' || $item['tag'] === null ? 'T' : 'D') 
                : ($item['tag'] === 'D' || $item['tag'] === '' || $item['tag'] === null ? 'D' : 'T');
            return ['price' => $finalPrice, 'tag' => $itemTag, 'is_refund' => $is_refund];
        }, $itemsWithIndividualDiscount);

        $allItemWithUpdatedPrice = array_merge($itemsWithIndividualDiscount, $itemWeightWithGlobalDiscount);

        $allUpdatedItemPicesTotalRP = array_sum(array_column($allItemWithUpdatedPrice, 'price'));

        $rpAmount = $redeemedPoints ?? 0.0;

        $allItemsWithRpUsedAmount = array_map(function($item) use ($rpAmount, $allUpdatedItemPicesTotalRP) {
            $itemTotal = $item['price'];
            $is_refund = $item['quantity_returned'] > 0 ? true :false; 
              if( $allUpdatedItemPicesTotalRP > 0.0)
                {
                     $itemWeightPrice =  $itemTotal - ($itemTotal * $rpAmount) / $allUpdatedItemPicesTotalRP;
                  }
                  else{
                     $itemWeightPrice =  $itemTotal;
                  }   
            
            return ['price' => $itemWeightPrice, 'tag' => $item['tag'], 'is_refund' => $item['is_refund']];
        }, $allItemWithUpdatedPrice);


        $filterFinalDineinItemsForSrv = array_filter($allItemsWithRpUsedAmount, function($item) {
            return $item['tag'] !== 'T' && !$item['is_refund'];
        });

        $dineInItemsTotalForSrvChargeWithRP = array_sum(array_column(array_filter($filterFinalDineinItemsForSrv, function($item) {
            return $item['tag'] !== 'T';
        }), 'price'));


        return $dineInItemsTotalForSrvChargeWithRP;
    }

    function calculateItemTotalForVoucher($sellLines, $orderType = "Dinein", $globalDiscount = 0.0, $globalDiscountType = "fixed", $redeemedPoints = 0.0 , $transaction_id) {
        if (empty($sellLines)) {
            return 0.0;
        }

        // Step 5 - All Items without discount
        $allItemsWithoutDiscount = array_filter($sellLines, function($item) {
            return $item['line_discount_amount'] <= 0.0;
        });

        $allItemsWithoutDiscountPrice = array_map(function($item) {
            $quantity = $item['quantity'] ? $item['quantity'] : 1; // to do  
            return ($item['unit_price_before_discount'] ?? 0.0) * $quantity;
        }, $allItemsWithoutDiscount);

        $allItemsWithoutDiscountTotal = array_sum($allItemsWithoutDiscountPrice);

        // Step 6 - Dinein Items Weight
        $globalDiscountPrice = $globalDiscount ?? 0.0;
        $itemWeightPrice = 0.0;

        $itemWeightWithGlobalDiscount = array_map(function($item) use ($globalDiscountPrice, $allItemsWithoutDiscountTotal, $orderType ,$globalDiscountType) {
            $quantity = $item['quantity'] ? $item['quantity'] : 1; // to do  
            $itemTotal = ($item['unit_price_before_discount'] ?? 0.0)  * $quantity;
            $is_refund = $item['quantity_returned'] > 0 ? true :false; 
            if($globalDiscountType == 'fixed'){
                if( $allItemsWithoutDiscountTotal > 0.0)
                {
                     $itemWeightPrice = $itemTotal - ($itemTotal * $globalDiscountPrice) / $allItemsWithoutDiscountTotal;
                  }
                  else{
                     $itemWeightPrice = $itemTotal ;
                  }   
            }
            elseif($globalDiscountType == 'percentage'){
                    
                $itemWeightPrice = $itemTotal - ($itemTotal * $globalDiscountPrice);
                
            }
            else{

                $itemWeightPrice = $itemTotal;
            }    
            $itemTag = ($orderType === 'Takeaway') 
                ? ($item['tag'] === 'T' || $item['tag'] === '' || $item['tag'] === null ? 'T' : 'D') 
                : ($item['tag'] === 'D' || $item['tag'] === '' || $item['tag'] === null ? 'D' : 'T');
            return ['price' => $itemWeightPrice, 'tag' => $itemTag, 'is_refund' => $is_refund];
        }, $allItemsWithoutDiscount);
        
        // Step 8 - All Items with Rp Amount weight
        $itemsWithIndividualDiscount = array_filter($sellLines, function($item) {
            return $item['line_discount_amount'] > 0.0;
        });

        $itemsWithIndividualDiscount = array_map(function($item) use ($orderType) {
            $quantity = $item['quantity'] ? $item['quantity'] : 1; // to do  
            $itemPrice = ($item['unit_price_before_discount'] ?? 0.0) * $quantity ;
            $itemDiscount = ($item['line_discount_type'] === 'percentage') 
                ? $itemPrice * ($item['line_discount_amount'] / 100) 
                : $item['line_discount_amount'];
            $finalPrice = $itemPrice - $itemDiscount;
            $is_refund = $item['quantity_returned'] > 0 ? true :false; 
            $itemTag = ($orderType === 'Takeaway') 
                ? ( $item['tag'] === 'T' || $item['tag'] === '' || $item['tag'] === null ? 'T' : 'D') 
                : ($item['tag'] === 'D' || $item['tag'] === '' || $item['tag'] === null ? 'D' : 'T');
            return ['price' => $finalPrice, 'tag' => $itemTag, 'is_refund' => $is_refund];
        }, $itemsWithIndividualDiscount);

        $allItemWithUpdatedPrice = array_merge($itemsWithIndividualDiscount, $itemWeightWithGlobalDiscount);

        $allUpdatedItemPicesTotalRP = array_sum(array_column($allItemWithUpdatedPrice, 'price'));

        $rpAmount = $redeemedPoints ?? 0.0;

        $allItemsWithRpUsedAmount = array_map(function($item) use ($rpAmount, $allUpdatedItemPicesTotalRP) {
            $itemTotal = $item['price'];
            $is_refund = $item['quantity_returned'] > 0 ? true :false; 
              if( $allUpdatedItemPicesTotalRP > 0.0)
                {
                     $itemWeightPrice =  $itemTotal - ($itemTotal * $rpAmount) / $allUpdatedItemPicesTotalRP;
                  }
                  else{
                     $itemWeightPrice =  $itemTotal;
                  }   
            
            return ['price' => $itemWeightPrice, 'tag' => $item['tag'], 'is_refund' => $item['is_refund']];
        }, $allItemWithUpdatedPrice);
         // Voucher calculations
         $filterFinalVoucherItem = array_sum(array_column(array_filter($allItemsWithRpUsedAmount, function($item) use ($sellLineIds) {
            return $item;
        }), 'price'));

        $filterFinalItemsForVoucher =  array_filter($allItemsWithRpUsedAmount, function($item) {
            return $item['tag'] !== 'T';
        });
        $filterFinalItemsPriceForVoucher = array_sum(array_column(array_filter($filterFinalItemsForVoucher, function($item) {
            return $item['tag'] !== 'T';
        }), 'price'));
        //

        $filterFinalDineinItemsForSrv = array_filter($allItemsWithRpUsedAmount, function($item) {
            return $item['tag'] !== 'T' && !$item['is_refund'];
        });

        $dineInItemsTotalForSrvChargeWithRP = array_sum(array_column(array_filter($filterFinalDineinItemsForSrv, function($item) {
            return $item['tag'] !== 'T';
        }), 'price'));

        return (object)['dineSRV' => $dineInItemsTotalForSrvChargeWithRP, 'dineSRVRefund' => $dineInItemsTotalForSrvChargeWithRPRefund, "finalTotalRefundAmount" => $finalTotalRefundAmount, 'filterFinalVoucherItem' =>$filterFinalVoucherItem, 'filterFinalItemsPriceForVoucher'=>$filterFinalItemsPriceForVoucher];
        
    }

    public function close_sales_with_float(Request $request)
    {
        $user_data = $request->only('business_id','business_location_id', 'token','user_id','closing_amount', 'total_card_slips', 'total_cheques', 'closing_note','cash_float_json','current_date','current_time');
        if(isset($user_data['token']))
        {    
            $result = User::checkUserToken($user_data['token'], $user_data['user_id']);
            if($result)
            {
                $businessLocation = BusinessLocation::find($user_data['business_location_id']);
                if( !empty($businessLocation) && !empty($businessLocation->day_start_time) ) {
                    $daystartTime = $businessLocation->day_start_time;
                    $dayStartTime = $daystartTime.":00:00";
                    $dayendTime = $daystartTime - 1;
                    $dayEndTime = $dayendTime.":59:59";
                } else {
                    $dayStartTime = str_replace(' ', '', Config::get('constants.businessStartTimeDefault'));
                    $dayEndTime = str_replace(' ', '', Config::get('constants.businessEndTimeDefault'));
                }
                
                $current_time = null;
                if( isset($user_data["current_time"]) && $user_data["current_time"] ) {
                    $current_time = $user_data["current_time"];
                }
                
                $current_date = null;
                if( isset($user_data["current_date"]) && $user_data["current_date"] ) {
                    $current_date = $user_data["current_date"];
                    \Log::info("current_date" . $current_date);
                }

                \Log::info($businessLocation);
                \Log::info(Config::get('constants.setBusinessTime'));
                
                if( Config::get('constants.setBusinessTime') && !empty($businessLocation) && !empty($current_time) && !empty($current_date) ) {
                    $morning6TimeStamp = strtotime($current_date . " " . $dayEndTime);
                    $dateTimeStamp = strtotime($current_date . " " . $current_time);
                    if( $dateTimeStamp >= $morning6TimeStamp ) {
                        $today = $current_date . ' ' .$dayStartTime;
                        $tomorrow = date('Y-m-d', strtotime($current_date .' +1 day')) . ' ' .$dayEndTime;
                    } else {
                        $today = date('Y-m-d', strtotime($current_date .' -1 day')) . ' ' .$dayStartTime;
                        $tomorrow = $current_date .' '.$dayEndTime;
                    }
                } else {
                    $today = Carbon::today()->format('Y-m-d') . Config::get('constants.businessStartTimeDefault');
                    $tomorrow = Carbon::today()->format('Y-m-d') . Config::get('constants.businessEndTimeDefault');
                }

                \Log::info("Today" . $today);
                \Log::info("Tomorrow" . $tomorrow);
                
                try {
                    /*
                    * Disable in demo
                    */
                    // if (config('app.env') == 'demo') {
                    //     $output = ['success' => 0,
                    //                     'msg' => 'Feature disabled in demo!!'
                    //                 ];
                    //     return redirect()->action('HomeController@index')->with('status', $output);
                    // }
                    $attendance = Attendance::where('business_id', $user_data['business_id'])
                                            ->where('location_id', $user_data['business_location_id'])
                                            ->whereNull('clockout_time')
                                            ->whereBetween('created_at', [$today, $tomorrow])
                                            ->orderBy('updated_at', 'desc')
                                            ->count();
                     if($attendance > 0){
                        $msg = '';
                        if($attendance == 1)
                        {
                            $msg = 'Oops! ' . $attendance . ' member still need to clocked out';
                        }
                        else{
                            $msg = 'Oops! ' . $attendance . ' members still need to clocked out';
                        }
                        return response()->json(['status' => 'failed', 'errorMessage' => $msg , 'clocked_in_users' => $attendance ]);
                        
                    }                                

                    $closeCashRegister = null;
                    $input = $request->only(['closing_amount', 'total_card_slips', 'total_cheques', 'closing_note','denominations', 'cash_float_json']);
                    $input['closing_amount'] = $this->cashRegisterUtil->num_uf($user_data['closing_amount']);
                    $user_id = $user_data['user_id'];
                    $input['closed_at'] = \Carbon::now()->format('Y-m-d H:i:s');
                    $input['status'] = 'close';
                    $input['denominations'] = !empty($input['denominations']) ? json_encode($input['denominations']) : null;
                    $input['cash_float_json'] = !empty($input['cash_float_json']) ? json_encode($input['cash_float_json']) : null;
                    
                    $closeCashRegister = CashRegister::where('user_id', $user_id)
                                        ->where('status', 'open')
                                        ->update($input);

                    $table_records = PosResTables::join('res_tables', 'res_tables.id', '=', 'pos_res_tables.res_table_id')
                                            ->select('pos_res_tables.*','res_tables.name')
                                            ->where('res_tables.location_id', $user_data['business_location_id'])
                                            ->where('pos_res_tables.seated', 1)
                                            // ->whereDate('pos_res_tables.created_at','>=', Carbon::today())
                                            ->whereBetween('pos_res_tables.created_at', [$today, $tomorrow])
                                            ->get()
                                            ->toArray();


                    if(count($table_records) > 0)
                    {
                        for($i=0; $i < count($table_records); $i++) {
                            PosResTables::where('res_table_id', $table_records[$i]['res_table_id'])->update(['seated' => 0]);
                        }
                    }

                    // ==============================================================
                    // Clear Queues START
                    QueueTable::where('business_id', $user_data['business_id'])
                                ->where('location_id', $user_data['business_location_id'])
                                ->update(['is_occupied' => 0]);
                    // Clear Queues END
                    // ==============================================================

                    // ==============================================================
                    // Delete Expired QR Tokens START
                    TableQrToken::where('business_id', $user_data['business_id'])
                                ->where('location_id', $user_data['business_location_id'])
                                // ->where('table_qr_tokens.expired_at', '<', \Carbon::now()->format('Y-m-d H:i:s'))
                                ->delete();
                    // Delete Expired QR Tokens END
                    // ==============================================================

                    // ==============================================================
                    // RESET INVOICE NUMBER START
                    $current_datetime_timestamp = strtotime(Carbon::now()->format('Y-m-d H:i:s'));
                    $one_hour_datetime_timestamp = strtotime(date('Y-m-d H:i:s', strtotime($tomorrow . ' -1 hour')));
                    $business_closing_timestamp = strtotime(date('Y-m-d H:i:s', strtotime($tomorrow)));

                    \Log::info( "close_sales_with_float => current_datetime => ". Carbon::now()->format('Y-m-d H:i:s') );
                    \Log::info( "close_sales_with_float => one_hour_before_datetime => ". date('Y-m-d H:i:s', strtotime(date('Y-m-d H:i:s', strtotime($tomorrow . ' -1 hour')))) );
                    \Log::info( "close_sales_with_float => business_closing => ". date('Y-m-d H:i:s', strtotime(date('Y-m-d H:i:s', strtotime($tomorrow)))) );

                    $is_process = 0;
                    // If Current is in between One Hour Before Business Closing Time and Business Closing Time
                    if( $current_datetime_timestamp >= $one_hour_datetime_timestamp && $current_datetime_timestamp <= $business_closing_timestamp ) {
                        $is_process = 1;
                    }

                    // If Current is greater than Business Closing Time
                    if( $current_datetime_timestamp >= $business_closing_timestamp ) {
                        $is_process = 1;
                    }

                    if( $is_process ) {
                        $invoice_number = InvoiceNumbers::where('business_id', $user_data['business_id'])
                                        ->where('location_id', $user_data['business_location_id'])
                                        ->first();
                        if( !empty($invoice_number) ) {
                            InvoiceNumbers::where('business_id', $user_data['business_id'])
                                        ->where('location_id', $user_data['business_location_id'])
                                        ->where('id', $invoice_number->id)
                                        ->update(['display_number' => $invoice_number->start_from]);
                        }
                    }
                    // RESET INVOICE NUMBER END
                    // ==============================================================

                    return $this->respond($closeCashRegister);
                } catch (\Exception $e) {
                    \Log::info($e->getMessage());
                    $closeCashRegister = ["errorMessage"=>'Something went wrong. Unable to close sales.'];
                    return $this->respond($closeCashRegister);
                }
            }
            else
            {
                return["errorMessage"=>'Invalid token.'];
            }
        }
        else
        {
            return["errorMessage"=>'Invalid token.'];
        }
    }
    
    public function close_sales_with_float_new(Request $request)
    {
        $user_data = $request->only('business_id','business_location_id', 'token','user_id','closing_amount', 'total_card_slips', 'total_cheques', 'closing_note','cash_float_json');

        if(isset($user_data['token']))
        {    
            $result = User::checkUserToken($user_data['token'], $user_data['user_id']);
            
            $today = date('Y-m-d') . " 6:00:00";
            $tomorrow = date('Y-m-d', strtotime(' +1 day')) . " 05:59:59";

            if($result)
            {
                
                try {
                    /*
                    * Disable in demo
                    */
                    // if (config('app.env') == 'demo') {
                    //     $output = ['success' => 0,
                    //                     'msg' => 'Feature disabled in demo!!'
                    //                 ];
                    //     return redirect()->action('HomeController@index')->with('status', $output);
                    // }
                    
                    $input = $request->only(['closing_amount', 'total_card_slips', 'total_cheques', 'closing_note','denominations', 'cash_float_json']);
                    $input['closing_amount'] = $this->cashRegisterUtil->num_uf($user_data['closing_amount']);
                    $user_id = $user_data['user_id'];
                    $input['closed_at'] = \Carbon::now()->format('Y-m-d H:i:s');
                    $input['status'] = 'close';
                    $input['denominations'] = !empty($input['denominations']) ? json_encode($input['denominations']) : null;
                    $input['cash_float_json'] = !empty($input['cash_float_json']) ? json_encode($input['cash_float_json']) : null;
                    $closeCashRegister = CashRegister::where('user_id', $user_id)
                                        ->where('status', 'open')
                                        ->update($input);

                    $table_records = PosResTables::join('res_tables', 'res_tables.id', '=', 'pos_res_tables.res_table_id')
                                            ->select('pos_res_tables.*','res_tables.name')
                                            ->where('res_tables.location_id', $user_data['business_location_id'])
                                            ->where('pos_res_tables.seated', 1)
                                            ->whereBetween('pos_res_tables.created_at', [$today, $tomorrow])
                                            ->get()
                                            ->toArray();

                    if(count($table_records) > 0)
                    {
                        for($i=0; $i < count($table_records); $i++) {
                            PosResTables::where('res_table_id', $table_records[$i]['res_table_id'])->update(['seated' => 0]);
                        }
                    }

                } catch (\Exception $e) {
                    $closeCashRegister = ["errorMessage"=>'Something went wrong. Unable to close sales.'];
                }

                return $this->respond($closeCashRegister);
            }
            else
            {
                return["errorMessage"=>'Invalid token.'];
            }
        }
        else
        {
            return["errorMessage"=>'Invalid token.'];
        }
    }

    public function close_sales(Request $request)
    {
        $user_data = $request->only('business_id','business_location_id', 'token','user_id','closing_amount', 'total_card_slips', 'total_cheques', 'closing_note');

        if(isset($user_data['token']))
        {    
            $result = User::checkUserToken($user_data['token'], $user_data['user_id']);

            if($result)
            {
                
                try {
                    /*
                    * Disable in demo
                    */
                    // if (config('app.env') == 'demo') {
                    //     $output = ['success' => 0,
                    //                     'msg' => 'Feature disabled in demo!!'
                    //                 ];
                    //     return redirect()->action('HomeController@index')->with('status', $output);
                    // }
                    
                    $input = $request->only(['closing_amount', 'total_card_slips', 'total_cheques', 'closing_note','denominations']);
                    $input['closing_amount'] = $this->cashRegisterUtil->num_uf($user_data['closing_amount']);
                    $user_id = $user_data['user_id'];
                    $input['closed_at'] = \Carbon::now()->format('Y-m-d H:i:s');
                    $input['status'] = 'close';
                    $input['denominations'] = !empty($input['denominations']) ? json_encode($input['denominations']) : null;
                    $closeCashRegister = CashRegister::where('user_id', $user_id)
                                        ->where('status', 'open')
                                        ->update($input);

                    $table_records = PosResTables::join('res_tables', 'res_tables.id', '=', 'pos_res_tables.res_table_id')
                                            ->select('pos_res_tables.*','res_tables.name')
                                            ->where('res_tables.location_id', $user_data['business_location_id'])
                                            ->where('pos_res_tables.seated', 1)
                                            ->whereDate('pos_res_tables.created_at','>=', Carbon::today())
                                            ->get()
                                            ->toArray();

                    if(count($table_records) > 0)
                    {
                        for($i=0; $i < count($table_records); $i++) {
                            PosResTables::where('res_table_id', $table_records[$i]['res_table_id'])->update(['seated' => 0]);
                        }
                    }

                } catch (\Exception $e) {
                    $closeCashRegister = ["errorMessage"=>'Something went wrong. Unable to close sales.'];
                }

                return $this->respond($closeCashRegister);
            }
            else
            {
                return["errorMessage"=>'Invalid token.'];
            }
        }
        else
        {
            return["errorMessage"=>'Invalid token.'];
        }
    }
    
    public function close_sales_new(Request $request)
    {
        $user_data = $request->only('business_id','business_location_id', 'token','user_id','closing_amount', 'total_card_slips', 'total_cheques', 'closing_note');

        if(isset($user_data['token']))
        {    
            $result = User::checkUserToken($user_data['token'], $user_data['user_id']);
            $today = date('Y-m-d') . " 6:00:00";
            $tomorrow = date('Y-m-d', strtotime(' +1 day')) . " 05:59:59";
            if($result)
            {
                
                try {
                    /*
                    * Disable in demo
                    */
                    // if (config('app.env') == 'demo') {
                    //     $output = ['success' => 0,
                    //                     'msg' => 'Feature disabled in demo!!'
                    //                 ];
                    //     return redirect()->action('HomeController@index')->with('status', $output);
                    // }
                    
                    $input = $request->only(['closing_amount', 'total_card_slips', 'total_cheques', 'closing_note','denominations']);
                    $input['closing_amount'] = $this->cashRegisterUtil->num_uf($user_data['closing_amount']);
                    $user_id = $user_data['user_id'];
                    $input['closed_at'] = \Carbon::now()->format('Y-m-d H:i:s');
                    $input['status'] = 'close';
                    $input['denominations'] = !empty($input['denominations']) ? json_encode($input['denominations']) : null;
                    $closeCashRegister = CashRegister::where('user_id', $user_id)
                                        ->where('status', 'open')
                                        ->update($input);

                    $table_records = PosResTables::join('res_tables', 'res_tables.id', '=', 'pos_res_tables.res_table_id')
                                            ->select('pos_res_tables.*','res_tables.name')
                                            ->where('res_tables.location_id', $user_data['business_location_id'])
                                            ->where('pos_res_tables.seated', 1)
                                            ->whereBetween('pos_res_tables.created_at', [$today, $tomorrow])
                                            ->get()
                                            ->toArray();

                    if(count($table_records) > 0)
                    {
                        for($i=0; $i < count($table_records); $i++) {
                            PosResTables::where('res_table_id', $table_records[$i]['res_table_id'])->update(['seated' => 0]);
                        }
                    }

                } catch (\Exception $e) {
                    $closeCashRegister = ["errorMessage"=>'Something went wrong. Unable to close sales.'];
                }

                return $this->respond($closeCashRegister);
            }
            else
            {
                return["errorMessage"=>'Invalid token.'];
            }
        }
        else
        {
            return["errorMessage"=>'Invalid token.'];
        }
    }

    public function update_payment_method(Request $request)
    {
        $user_data = $request->only('token','user_id','transaction_id','transaction_payment_id','card_type');

        if(isset($user_data['token']))
        {    
            $result = User::checkUserToken($user_data['token'], $user_data['user_id']);

            if($result)
            {
                try {
                    
                    if(strtolower($user_data['card_type']) != 'cash')
                    {
                        $result = TransactionPayment::where('transaction_id', $user_data['transaction_id'])->where('id', $user_data['transaction_payment_id'])->update(['method' => 'card', 'card_type' => strtolower($user_data['card_type'])]);
                    }
                    else
                    {
                        $result = TransactionPayment::where('transaction_id', $user_data['transaction_id'])->where('id', $user_data['transaction_payment_id'])->update(['method' => 'cash', 'card_type' => 'credit']);
                    }

                } catch(\Exception $e) {
                    $result = ["errorMessage"=>'Payment not found.'];
                }

                return $this->respond($result);
            }
            else
            {
                return["errorMessage"=>'Invalid token.'];
            }
        }
        else{
            return["errorMessage"=>'Invalid token.'];
        }
    }

    public function record_open_drawer(Request $request)
    {
        $user_data = $request->only('token','user_id','business_id','location_id', 'user_id', 'amount', 'status', 'comment');

        if(isset($user_data['token']))
        {    
            $result = User::checkUserToken($user_data['token'], $user_data['user_id']);

            if($result)
            {
                try {
                    
                    $open_drawer_record = OpenDrawerRecord::create([
                        'business_id' => $user_data['business_id'],
                        'location_id' => $user_data['location_id'],
                        'user_id' => $user_data['user_id'],
                        'amount' => $user_data['amount'],
                        'status' => strtolower($user_data['status']),
                        'comment' => $user_data['comment']
                    ]);

                    return $open_drawer_record;

                } catch(\Exception $e) {
                    \Log::emergency("File:" . $e->getFile(). "Line:" . $e->getLine(). "Message:" . $e->getMessage());
                    $result = ["errorMessage"=>'Something went wrong. Please try again later.'];
                }

                return $this->respond($result);
            }
            else
            {
                return["errorMessage"=>'Invalid token.'];
            }
        }
        else{
            return["errorMessage"=>'Invalid token.'];
        }
    }
}
