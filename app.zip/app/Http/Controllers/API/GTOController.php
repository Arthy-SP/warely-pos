<?php

namespace App\Http\Controllers\API;


use Carbon\Carbon;
use Exception;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Log;
use phpseclib\Net\SFTP;
use App\BusinessOutlets;
use Illuminate\Http\Request;
use App\BusinessLocation;
use App\Http\Controllers\Controller;
use App\Transaction;
use DB;
use App\TransactionSellLine;


class GTOController extends Controller
{
    const OUTLET_FILE_FORMATS = [
        ['id'=> 0, 'name'=> "H"],
        ['id'=> 1, 'name'=> "_"],
        ['id'=> 2, 'name'=> "{MID}"],
        ['id'=> 3, 'name'=> "{DATE}"],
        ['id'=> 4, 'name'=> "{mis}"],
        ['id'=> 5, 'name'=> "TD"],
        ['id'=> 6, 'name'=> "{LOGINID}"],
        ['id'=> 7, 'name'=> "D"],
        ['id'=> 8, 'name'=> "T"],
        ['id'=> 9, 'name'=> "."],
        ['id'=> 10, 'name'=> "{SerialNo}"],

    ];
    const OUTLET_REPORT_FORMATS = [
        ['id'=> "machineId", 'name'=> "Machine id"],
        ['id'=> "batch_id", 'name'=> "Batch id"],
        ['id'=> "batch_id_one", 'name'=> "Static batch id(1)"],
        ['id'=> "date", 'name'=> "Date"],
        ['id'=> "hour", 'name'=> "Hour"],
        ['id'=> "hourmin", 'name'=> "HourMinutes"],
        ['id'=> "hourly_transactions", 'name'=> "Hourly transactions"],
        ['id'=>"gto_sales", 'name'=> "GTO sales"],
        ['id'=> "gst", 'name'=> "GST"],
        ['id'=> "discount", 'name'=> "Discount"],
        ['id'=> "service_charges", 'name'=> "Service charges"],
        ['id'=> "pax", 'name'=> "Pax"],
        ['id'=> "cash", 'name'=> "Cash"],
        ['id'=> "nets", 'name'=> "Nets"],
        ['id'=> "visa", 'name'=> "Visa"],
        ['id'=> "mastercard", 'name'=> "Mastercard"],
        ['id'=> "amex", 'name'=> "Amex"],
        ['id'=> "voucher", 'name'=> "Voucher"],
        ['id'=> "y", 'name'=> "Y"],
        ['id'=> "n", 'name'=> "N"],
        ['id'=> "FTP_login_id", 'name'=> "FTP LOGIN ID"],
        ['id'=> "gross_sales", 'name'=> "Gross Sales"],
        ['id'=> "net_sales", 'name'=> "Net sales"],
        ['id'=> "payable_amount_gst", 'name'=> "Payable amount(Include GST)"],
        ['id'=> "payable_amount", 'name'=> "Payable amount(Exclude GST)"],
        ['id'=> "GTO_Sales_Net_Sales_Inc_Service_Charge_Exc_gst", 'name'=> "GTO Sales (inc service charge, Exc GST)"],
        ['id'=> "GTO_Sales_Inc_GST_And_Service_Charge", 'name'=> "GTO Sales (inc GST and service charge)"],  
        ['id'=> "others", 'name'=> "Others"],
        ['id'=> "d", 'name'=> "D"],
        ['id'=> "t", 'name'=> "T"],
        ['id'=> ".", 'name'=> "."],
        ['id'=> "serial_no", 'name'=> "Serial No."],
        ['id'=> "gto_amount", 'name'=> "GTO amount(0's)"],

    ];

    protected $OUTLET_LOCATIONS;
    public function __construct(Request $request)
    {

        $this->OUTLET_LOCATIONS = BusinessOutlets::select('id', 'name',"date_formats",  'file_formats','report_formats', "start_date", "report_type", "serial_no", "use_pipe_for_report", "file_extension")
            ->get()
            ->toArray();
    }

    public function cron_generate_GTO_files()
    {
        $now = Carbon::now();
        $location_details = BusinessLocation::whereNotNull('outlet_location_id')
            ->groupBy('business_id')
            ->groupBy('outlet_location_id')
            ->select('id', 'outlet_location_id', 'business_id', 'name', 'machine_id', 'ftp_server', 'ftp_password','ftp_port', 'is_sftp', 'ftp_login_id', "ftp_path")

            ->selectRaw('GROUP_CONCAT(id) as locs')
            ->get();

        if (!empty($location_details)) {
            foreach ($location_details as $location_detail) {
                if (!empty($location_detail->machine_id)) {
                    $business_id = $location_detail->business_id;
                    //dd($business_id);
                    //$location_id = $location_detail->id;
                    $location_id = explode(',', $location_detail->locs);
                    // if( $location_detail->machine_id == "8000360" || $location_detail->machine_id == "30200118" ) { // IF START
                    // for($day=01; $day<=14;$day++){ // FOR START
                    //     $day = 19;
                    // $created_at = new Carbon('2023-12-'.$day.' 23:00:05');
                    $created_at = Carbon::now();
                    //get dynamic outlet report type 
                    $outlet_location_id = $location_detail->outlet_location_id; // Replace with actual ID
                    $outletId = $reportType = $fielFormats = $outltStartDate = $reportFormats = $file_date_formats = $report_date_formats = $serial_no = $use_pipe_for_report = $file_extension =  null;
                    $searchString = "NA";
                    foreach ($this->OUTLET_LOCATIONS as $outlate) {
                        if ($outlate['id'] == $outlet_location_id) {
                            $reportType = $outlate['report_type'];
                            $searchString = $outlate['name'];
                            $fielFormats = $outlate['file_formats'];
                            $file_date_formats = $outlate['date_formats'] ? $outlate['date_formats']["file"] : "ymd";
                            $report_date_formats = $outlate['date_formats'] ? $outlate['date_formats']["report"] : "ymd";
                            $outltStartDate = $outlate['start_date'];
                            $reportFormats = $outlate['report_formats'];
                            $serial_no = $outlate['serial_no'];
                            $use_pipe_for_report = $outlate['use_pipe_for_report'];
                            $outletId = $outlate["id"];
                            $outletStartDate = $outlate['start_date'];
                            $file_extension = $outlate['file_extension'];
                            break; 
                        }
                    }  
                    $serial_no = $this->generate_serial_no($outletStartDate,$now, $serial_no); 

                    if ($reportType === "hourly") {
                        $transactions = Transaction::from('transactions as t')
                        ->leftJoin('transaction_payments as tp', 'tp.transaction_id', '=', 't.id')
                        ->leftJoin('tax_rates', 't.tax_id', '=', 'tax_rates.id')
                        ->leftJoin('transactions as tr', function($join) {
                            $join->on('tr.return_parent_id', '=', 't.id')
                                ->where('tr.type', 'sell_return')
                                ->where('tr.status', 'final');
                        })
                        ->where('t.business_id', $business_id)
                        ->whereIn('t.location_id', $location_id)
                        ->whereIn('t.type', array('sell', 'sell_return'))
                        ->where('t.status', 'final')
                        ->whereDate('t.created_at', $created_at)
                        ->select('t.*','t.id as transaction_id','tp.method', 'tp.card_type', 'tp.amount','tax_rates.apply_inclusive_gst','tax_rates.amount as tax_rate',
                       // DB::raw('(t.total_before_tax  -  t.total_discount_amount - t.rp_redeemed_amount) * t.service_charges as total_service_charges')  ,    
                        DB::raw('
                        CASE 
                            WHEN tax_rates.apply_inclusive_gst = 1 THEN 
                                ((t.total_before_tax - (CASE WHEN tr.id IS NOT NULL THEN tr.total_with_modifier ELSE 0 END) - t.total_discount_amount - t.rp_redeemed_amount + ((t.total_before_tax - t.total_discount_amount - t.rp_redeemed_amount) * t.service_charges)) / (tax_rates.amount + 100)) * tax_rates.amount
                            ELSE 
                                ((t.total_before_tax - (CASE WHEN tr.id IS NOT NULL THEN tr.total_with_modifier ELSE 0 END) - t.total_discount_amount - t.rp_redeemed_amount + (t.total_before_tax - t.total_discount_amount - t.rp_redeemed_amount) * t.service_charges) * tax_rates.amount / 100)
                        END as gst
                        '),
                        DB::raw('(
                                CASE
                                    WHEN tr.id IS NOT NULL AND t.total_before_tax = tr.total_before_tax THEN 0
                                    ELSE (
                                        t.total_before_tax 
                                        - (CASE WHEN tr.id IS NOT NULL THEN tr.total_before_tax ELSE 0 END) 
                                        - (t.total_discount_amount - IF(tr.id IS NOT NULL, tr.total_discount_amount, 0))
                                        - t.rp_redeemed_amount
                                    )
                                END
                            ) as net_sales'))->get()->groupBy(function ($date) {
                                return Carbon::parse($date->created_at)->format('H');
                            });                 
                    } elseif ($reportType === "date_wise") {
                        $transactions = Transaction::from('transactions as t')
                        ->leftJoin('transaction_payments as tp', 'tp.transaction_id', '=', 't.id')
                        ->leftJoin('tax_rates', 't.tax_id', '=', 'tax_rates.id')
                        ->leftJoin('transactions as tr', function($join) {
                            $join->on('tr.return_parent_id', '=', 't.id')
                                ->where('tr.type', 'sell_return')
                                ->where('tr.status', 'final');
                        })
                        ->where('t.business_id', $business_id)
                        ->whereIn('t.location_id', $location_id)
                        ->whereIn('t.type', array('sell', 'sell_return'))
                        ->where('t.status', 'final')
                        ->whereIn('t.payment_status', array('paid', 'partial'))
                        ->whereDate('t.created_at', $created_at)
                        ->select('t.*','t.id as transaction_id','tp.method', 'tp.card_type', 'tp.amount','tax_rates.apply_inclusive_gst','tax_rates.amount as tax_rate',
                        //DB::raw('(t.total_before_tax - t.total_discount_amount - t.rp_redeemed_amount) * t.service_charges as total_service_charges')  ,
                        DB::raw('CASE WHEN tr.id IS NOT NULL THEN tr.total_before_tax ELSE 0 END as refund_total_before_tax'),
                        DB::raw('
                        CASE 
                            WHEN tax_rates.apply_inclusive_gst = 1 THEN 
                                ((t.total_before_tax - (CASE WHEN tr.id IS NOT NULL THEN tr.total_with_modifier ELSE 0 END) - t.total_discount_amount - t.rp_redeemed_amount + ((t.total_before_tax - t.total_discount_amount - t.rp_redeemed_amount) * t.service_charges)) / (tax_rates.amount + 100)) * tax_rates.amount
                            ELSE 
                                ((t.total_before_tax - (CASE WHEN tr.id IS NOT NULL THEN tr.total_with_modifier ELSE 0 END) - t.total_discount_amount - t.rp_redeemed_amount + (t.total_before_tax - t.total_discount_amount - t.rp_redeemed_amount) * t.service_charges) * tax_rates.amount / 100)
                        END as gst
                        '),
                        DB::raw('(
                                CASE
                                    WHEN tr.id IS NOT NULL AND t.total_before_tax = tr.total_before_tax THEN 0
                                    ELSE (
                                        t.total_before_tax 
                                        - (CASE WHEN tr.id IS NOT NULL THEN tr.total_before_tax ELSE 0 END) 
                                        - (t.total_discount_amount - IF(tr.id IS NOT NULL, tr.total_discount_amount, 0))
                                        - t.rp_redeemed_amount
                                    )
                                END
                            ) as net_sales')
                            ) 
                             ->get()->groupBy(function ($date) {
                                return Carbon::parse($date->created_at)->format('d');
                            }); 
                    }
                    if ($searchString != 'NA') {

                        $machineId = $location_detail->machine_id; // Need to change
                        $subFolderExist = false;
                        $vivoDirectories = Storage::disk('local')->allDirectories('GTO/' . $searchString);
                        $subDirectory = 'GTO/' . $searchString . '/' . $machineId;
                        $ftpLoginId = $location_detail->ftp_login_id;

                        if (count($vivoDirectories) > 0) {
                            foreach ($vivoDirectories as $directoryString) {
                                if (strpos($directoryString, (string) $machineId) !== false) {
                                    $subFolderExist = true;
                                    break;
                                }
                            }

                            if ($subFolderExist) {
                                Storage::disk('local')->makeDirectory($subDirectory);
                            }
                        } else {
                            Storage::disk('local')->makeDirectory($subDirectory);
                        }

                        $today_date = Carbon::parse($created_at)->format('Ymd');
                        $subSubFolderExist = false;
                        $subDirectories = Storage::disk('local')->allDirectories($subDirectory);
                        $subSubDirectory = 'GTO/' . $searchString . '/' . $machineId . '/' . $created_at->format('Y') . '/' . $created_at->format('m');
                        if (count($subDirectories) > 0) {
                            foreach ($subDirectories as $subDirectoryString) {
                                if (strpos($subDirectoryString, $today_date) !== false) {
                                    $subSubFolderExist = true;
                                    break;
                                }
                            }

                            if ($subSubFolderExist) {
                                Storage::disk('local')->makeDirectory($subSubDirectory);
                            }
                        } else {
                            Storage::disk('local')->makeDirectory($subSubDirectory);
                        }

                        $file = $this->getFileNameForOutletLocation($subSubDirectory, $file_extension, $serial_no,  $location_detail->outlet_location_id, $machineId, $ftpLoginId,  $created_at, $reportType,$fielFormats, $file_date_formats);

                        if (!$file)
                            continue;
                        if($reportType == "hourly"){
                            if (count($transactions) > 0) {
                                for ($hour = 0; $hour <= 23; $hour++) {
                                    $is_matched = false;
                                    foreach ($transactions as $key => $hourlyTransactions) {
                                        if ($key == sprintf('%02d', $hour)) {
                                            $line = $this->getLineForForOutletLocation($key, $hourlyTransactions,$report_date_formats, $use_pipe_for_report, $outletId, $serial_no, $reportFormats,$outltStartDate, $location_detail->outlet_location_id, $machineId,$ftpLoginId, $created_at, $reportType);
                                            $is_matched = true;
                                            break;
                                        }
                                    }
                                    if (!$is_matched) {
                                        $line = $this->getLineForForOutletLocation(sprintf('%02d', $hour), [], $report_date_formats, $use_pipe_for_report, $outletId, $serial_no, $reportFormats,  $outltStartDate, $location_detail->outlet_location_id, $machineId,$ftpLoginId, $created_at, $reportType);
                                    }
                                    $this->saveLineToFile($file, $line);
                                }
                            } else {
                                $j = 0;
                                while (sprintf('%02d', $j) != '24') {

                                    $line = $this->getLineForForOutletLocation($j, [], $report_date_formats, $use_pipe_for_report, $outletId,  $serial_no, $reportFormats, $outltStartDate, $location_detail->outlet_location_id, $machineId,$ftpLoginId, $created_at, $reportType);

                                    $this->saveLineToFile($file, $line);
                                    $j++;
                                }
                            }
                        }else{
                            if (count($transactions) > 0) {
                                for ($day = 0; $day<1; $day++) {
                                    $is_matched = false;
                                    foreach ($transactions as $key => $dailyTransactions) {

                                        $line = $this->getLineForForOutletLocation($key, $dailyTransactions, $report_date_formats, $use_pipe_for_report, $outletId, $serial_no,  $reportFormats, $outltStartDate, $location_detail->outlet_location_id, $machineId,$ftpLoginId, $created_at);

                                        $is_matched = true;
                                        break;
                                    }
                                    if (!$is_matched) {

                                        $line = $this->getLineForForOutletLocation(sprintf('%02d', $day), [], $report_date_formats, $outletId, $serial_no, $reportFormats,  $outltStartDate, $location_detail->outlet_location_id, $machineId,$ftpLoginId, $created_at);

                                    }
                                    $this->saveLineToFile($file, $line);
                                }
                            } else {
                                $j = 0;
                                while (sprintf('%02d', $j) != '1') {
                                    $line = $this->getLineForForOutletLocation($j, [], $report_date_formats, $use_pipe_for_report, $outletId, $serial_no,  $reportFormats, $outltStartDate, $location_detail->outlet_location_id, $machineId, $ftpLoginId, $created_at);

                                    $this->saveLineToFile($file, $line);
                                    $j++;
                                }
                            }
                        }
                        $this->saveToFTP($location_detail, $file);   
                        } else {
                        Log::error("machine id / FTP / File format not available for " . $location_detail->name . '<br/>');
                    }
                }
            }
        }
    }

    private function saveLineToFile($file_name, $line)
    {
        Storage::disk('local')->append($file_name, $line);
    }

      private function saveToFTP($location, $file)
    {
        try {
            $ftp_server = $location->ftp_server;
            $ftp_username = $location->machine_id;
            $ftp_userpass = $location->ftp_password;
            $ftp_port = $location->ftp_port ? $location->ftp_port : 21; 
            $ftp_path = $location->ftp_path ? rtrim($location->ftp_path, '/') : ""; 
            $name = basename($file);
            $file = public_path('uploads/' . $file);
            $target_path = $ftp_path ? $ftp_path . '/' . $name : $name;
        
            if ($location->is_sftp) {
                $sftp = new SFTP($ftp_server, $ftp_port);
                if ($sftp->login($ftp_username, $ftp_userpass)) {
                    try {
                        $sftp->put($target_path, $file, SFTP::SOURCE_LOCAL_FILE); 
                        Log::info('File ' . $file . ' sent to SFTP: ' . $target_path);
                    } catch (Exception $e) {
                        $sftp->put($name, $file, SFTP::SOURCE_LOCAL_FILE);
                        Log::info("Target path unavailable. File $file sent to SFTP root.");
                    }
                } else {
                    Log::error("Could not log in to SFTP server $ftp_server for $location->name");
                }
            } else {
                $ftp_conn = ftp_connect($ftp_server, $ftp_port);
                if ($ftp_conn) {
                    if (ftp_login($ftp_conn, $ftp_username, $ftp_userpass)) {
                        ftp_pasv($ftp_conn, true);
                        if ($ftp_path && ftp_chdir($ftp_conn, $ftp_path)) {
                            $ftp_upload_path = $ftp_path . '/' . $name;
                            ftp_chdir($ftp_conn, "/");
                        } else {
                            $ftp_upload_path = $name;
                            Log::info("Target path unavailable. Uploading file to FTP root.");
                        }
        
                        ftp_put($ftp_conn, $ftp_upload_path, $file, FTP_BINARY);
                        ftp_close($ftp_conn);
                        Log::info("File $file sent to FTP: $ftp_upload_path");
                    } else {
                        Log::error("Could not log in to FTP server $ftp_server for $location->name");
                    }
                } else {
                    Log::error("Could not connect to $ftp_server for $location->name");
                }
            }
        } catch (Exception $e) {
            Log::error($e->getMessage() . " with File $file");
        }
        
    }


    public function getFileNameForOutletLocation($directory,$file_extension, $serial_no,  $outlet_location_id, $machineId = "XXXXXX", $ftpLoginId, $date, $type=null, $file_formats, $file_date_formats)
    {
        $currentDate = Carbon::now();
        $fileFormatMap = array_column(self::OUTLET_FILE_FORMATS, 'name', 'id');
        $file_format_names = array_map(function($id) use ($fileFormatMap) {
            return $fileFormatMap[$id] ?? ''; 
        }, $file_formats);
        $fileNameFormat = implode('', $file_format_names);
        $fileName = str_replace('{LOGINID}', $machineId, $fileNameFormat);
        $fileName = str_replace('{MID}', $ftpLoginId, $fileName);
        $fileName = str_replace('{DATE}', $date->format($file_date_formats), $fileName);
        $fileName = str_replace('{mis}', $currentDate->format('His'), $fileName);
        $fileName = str_replace('{SerialNo}', $serial_no, $fileName);
        $file_extension = $file_extension ? ".txt" : "";
        $fileName = $fileName.$file_extension;
        $exists = Storage::disk('local')->exists($directory.'/'.$fileName);
        $i=1;
        while($exists) {
            $old_file = $directory.'/'.$fileName.'.prev'.$i;
            $exists = Storage::disk('local')->exists($old_file);
            if(!$exists){
                Storage::move($directory.'/'.$fileName, $old_file); 
                break;
            }
            $i++;
        }
        return $directory.'/'.$fileName;
    }
    private function getLineForForOutletLocation($hour, $hourly_transactions, $report_date_formats, $use_pipe_for_report, $outletId,  $serial_no = null, $reportFormats, $outltStartDate, $outlet_location_id, $machineId = "XXXXXX", $ftpLoginId, $date, $type=null)
    {
        $gto_sales = 0;
        $gst = 0;
        $discount = 0;
        $service_charges = 0;
        $pax = 0;
       //$date = Carbon::now();
        $cash = 0; 
        $nets = 0;
        $visa = 0; 
        $mastercard = 0;
        $amex = 0; 
        $voucher = 0;
        $others = 0;
        $net_sales = $gross_sales = $payable_amount_with_gst = $payable_amount = $gtoNetSalesAfterDiscBeforeGSTWithSvc = $gtoLessDiscWithGSTSvc = 0;
        $outlets = array(2, 5, 6, 8); // outlets which requires card payment details separately
        
        foreach ($hourly_transactions as $transaction) {
            
            if($transaction->type=='sell'){
                $amount_before_tax = $transaction->amount - $transaction->tax_amount;
                $gto_sales += $amount_before_tax;
                $gst += $transaction->gst;
                $discount += $transaction->total_discount_amount;
                $service_charges += $transaction->service_charges;
                $total_service_charges = ($transaction->total_before_tax - $transaction->total_discount_amount - $transaction->rp_redeemed_amount - $transaction->refund_total_before_tax)*$transaction->service_charges;//
                $date = $transaction->created_at;
                if($transaction->apply_inclusive_gst == 1){
                    $payable_amount_with_gst += round(round(($transaction->net_sales+ $total_service_charges), 2) + $transaction->tip_amount - $transaction->voucher_amount_used, 2);
                    $payable_amount = $payable_amount_with_gst;
                $gtoLessDiscWithGSTSvc +=  ($transaction->net_sales + $total_service_charges);
                } else {
                    $final_gst = (($transaction->net_sales   +  $total_service_charges) * $transaction->tax_rate) / 100;
                    $payable_amount_with_gst += round(round(($transaction->net_sales+ $total_service_charges), 2) + $final_gst +  $transaction->round_off_amount  - $transaction->voucher_amount_used + $transaction->tip_amount, 2);
                    $payable_amount += round(round(($transaction->net_sales+ $total_service_charges), 2)  +  $transaction->round_off_amount  - $transaction->voucher_amount_used + $transaction->tip_amount, 2);
                    $gtoLessDiscWithGSTSvc +=  ($transaction->net_sales+ $final_gst + $total_service_charges);

                }
               $gtoNetSalesAfterDiscBeforeGSTWithSvc += ($transaction->net_sales+ $total_service_charges);
                $net_sales += $transaction->net_sales;
                $gross_sales += ($transaction->net_sales+ $total_service_charges);
                $pax=1;
                if($transaction->method =='card') {  //outlet_location_id check because they need informmation for card type as well
                    switch($transaction->card_type) {
                        case 'bank_transfer':
                            $nets+= $amount_before_tax;
                        break;
                        case 'visa':
                            $visa+= $amount_before_tax;
                        break;
                        case 'custom_pay_1':
                            $visa+= $amount_before_tax;
                        break;
                        case 'mastercard':
                            $mastercard+= $amount_before_tax;
                        break;
                        case 'custom_pay_2':
                            $mastercard+= $amount_before_tax;
                        break;
                        case 'master':
                            $mastercard+= $amount_before_tax;
                        break;
                        case 'amex':
                            $amex+= $amount_before_tax;
                        break;
                        case 'voucher':
                            $voucher+= $amount_before_tax;
                        break;
                        default:
                            $others+= $amount_before_tax;
                    }
                }else  if($transaction->method =='cash') {
                    $cash+= $amount_before_tax;
                }
            }else {
                $gto_sales -= ($transaction->final_total);
            }
        }
        $batch_id = Carbon::createFromDate($outltStartDate)->diffInDays($date)+1;
        $variables = [
            'batch_id' => $batch_id,  
            'machineId' => $ftpLoginId,   
            'gto_sales' => number_format($gross_sales, 2, '.', ''),
            'gst' => number_format($gst, 2),
            'discount' => number_format($discount, 2, '.', ''),
            'service_charges' => number_format($service_charges, 2, '.', ''),
            "hourly_transactions" => count($hourly_transactions),
            "hour" => $hour,
            "hourmin"=>$hour."59",
            'pax' => $pax,
            'date' => $date->format($report_date_formats), 
            'cash' => number_format($cash, 2, '.', ''),
            'nets' => number_format($nets, 2, '.', ''),
            'visa' => number_format($visa, 2, '.', ''),
            'mastercard' => number_format($mastercard, 2, '.', ''),
            'amex' => number_format($amex, 2, '.', ''),
            'voucher' => number_format($voucher, 2, '.', ''),
            'y' => "Y",
            "n" => "N",
            'others' => number_format($others, 2, '.', ''),
            'net_sales' => number_format($net_sales, 2, '.', ''),
            'gross_sales' => number_format($gross_sales, 2, '.', ''),
            'payable_amount_gst' => number_format($payable_amount_with_gst, 2, '.', ''),
            'payable_amount' => number_format($payable_amount, 2, '.', ''),
            "GTO_Sales_Net_Sales_Inc_Service_Charge_Exc_gst" => $gtoNetSalesAfterDiscBeforeGSTWithSvc,
            "GTO_Sales_Inc_GST_And_Service_Charge" => $gtoLessDiscWithGSTSvc,
            "batch_id_one" => 1,
            "FTP_login_id" => $machineId,
            "d" => "D",
            "t" => "T",
            "." => ".",
            "serial_no" => $serial_no,
            "gto_amount"=> sprintf('%011.2f', $gross_sales),

        ];             
          
        $report = '';
        foreach ($reportFormats as $key) {
            if (isset($variables[$key])) {
                $report .= $variables[$key] . "|" ;
            } else {
                $report .= 'N/A|';
            }
        }
        if(!$use_pipe_for_report){
            $report = str_replace('|', '', $report);
        }else{
            $report = rtrim($report, '|');
        }
        return $report;

    }

    private function getGSTRate($year) {
        $rates = array('2022' => 7, 2023 => 8, '2024' => 9, '2025' => 10);
        return array_key_exists($year, $rates) ? $rates[$year] : 8;
    }

    public function generate_GTO_files(Request $request)
    {
        $date = $request->input("date");
        $locationId = $request->input("locationId");
        $now = Carbon::now();
        $location_details = BusinessLocation::whereNotNull('outlet_location_id')
            ->where('id', $locationId)
            ->groupBy('business_id')
            ->groupBy('outlet_location_id')
            ->select('id', 'outlet_location_id', 'business_id', 'name', 'machine_id', 'ftp_server', 'ftp_password', 'is_sftp', "ftp_login_id", "ftp_path")
            ->selectRaw('GROUP_CONCAT(id) as locs')
            ->get();

        if (!empty($location_details)) {
            foreach ($location_details as $location_detail) {
                if (!empty($location_detail->machine_id)) {
                    $business_id = $location_detail->business_id;
                    $location_id = explode(',', $location_detail->locs);
                    $created_at = new Carbon($date);
                    $outlet_location_id = $location_detail->outlet_location_id; // Replace with actual ID
                    $outletId = $reportType = $fielFormats = $outltStartDate = $reportFormats = $file_date_formats = $report_date_formats =  $serial_no = $use_pipe_for_report = $file_extension = null;
                    $searchString = "NA";
                    foreach ($this->OUTLET_LOCATIONS as $outlate) {
                        if ($outlate['id'] == $outlet_location_id) {
                            $reportType = $outlate['report_type'];
                            $searchString = $outlate['name'];
                            $fielFormats = $outlate['file_formats'];
                            $file_date_formats = $outlate['date_formats'] ? $outlate['date_formats']["file"] : "Ymd";
                            $report_date_formats = $outlate['date_formats'] ? $outlate['date_formats']["report"] : "Ymd";
                            $outltStartDate = $outlate['start_date'];
                            $reportFormats = $outlate['report_formats'];
                            $serial_no = $outlate['serial_no'];
                            $use_pipe_for_report = $outlate['use_pipe_for_report'];
                            $outletId = $outlate["id"];
                            $outletStartDate = $outlate['start_date'];
                            $file_extension = $outlate['file_extension'];
                            break; 
                        }
                    }
                    $serial_no = $this->generate_serial_no($outletStartDate,$date, $serial_no);
                    if ($reportType === "hourly") {
                        $transactions = Transaction::from('transactions as t')
                        ->leftJoin('transaction_payments as tp', 'tp.transaction_id', '=', 't.id')
                        ->leftJoin('tax_rates', 't.tax_id', '=', 'tax_rates.id')
                        ->leftJoin('transactions as tr', function($join) {
                            $join->on('tr.return_parent_id', '=', 't.id')
                                ->where('tr.type', 'sell_return')
                                ->where('tr.status', 'final');
                        })
                        ->where('t.business_id', $business_id)
                        ->whereIn('t.location_id', $location_id)
                        ->whereIn('t.type', array('sell', 'sell_return'))
                        ->where('t.status', 'final')
                        ->whereDate('t.created_at', $created_at)
                        ->select('t.*','t.id as transaction_id','tp.method', 'tp.card_type', 'tp.amount','tax_rates.apply_inclusive_gst','tax_rates.amount as tax_rate',
                        //DB::raw('(t.total_before_tax - t.total_discount_amount - t.rp_redeemed_amount) * t.service_charges as total_service_charges')  ,    
                        DB::raw('CASE WHEN tr.id IS NOT NULL THEN tr.total_before_tax ELSE 0 END as refund_total_before_tax'),
                        DB::raw('
                        CASE 
                            WHEN tax_rates.apply_inclusive_gst = 1 THEN 
                                ((t.total_before_tax - (CASE WHEN tr.id IS NOT NULL THEN tr.total_with_modifier ELSE 0 END) - t.total_discount_amount - t.rp_redeemed_amount + ((t.total_before_tax - t.total_discount_amount - t.rp_redeemed_amount) * t.service_charges)) / (tax_rates.amount + 100)) * tax_rates.amount
                            ELSE 
                                ((t.total_before_tax - (CASE WHEN tr.id IS NOT NULL THEN tr.total_with_modifier ELSE 0 END) - t.total_discount_amount - t.rp_redeemed_amount + (t.total_before_tax - t.total_discount_amount - t.rp_redeemed_amount) * t.service_charges) * tax_rates.amount / 100)
                        END as gst
                        '),
                        DB::raw('(
                                CASE
                                    WHEN tr.id IS NOT NULL AND t.total_before_tax = tr.total_before_tax THEN 0
                                    ELSE (
                                        t.total_before_tax 
                                        - (CASE WHEN tr.id IS NOT NULL THEN tr.total_before_tax ELSE 0 END) 
                                        - (t.total_discount_amount - IF(tr.id IS NOT NULL, tr.total_discount_amount, 0))
                                        - t.rp_redeemed_amount
                                    )
                                END
                            ) as net_sales'))->get()->groupBy(function ($date) {
                                return Carbon::parse($date->created_at)->format('H');
                            }); 
                    
                    } elseif ($reportType === "date_wise") {

                        $transactions = Transaction::from('transactions as t')
                        ->leftJoin('transaction_payments as tp', 'tp.transaction_id', '=', 't.id')
                        ->leftJoin('tax_rates', 't.tax_id', '=', 'tax_rates.id')
                        ->leftJoin('transactions as tr', function($join) {
                            $join->on('tr.return_parent_id', '=', 't.id')
                                ->where('tr.type', 'sell_return')
                                ->where('tr.status', 'final');
                        })
                        ->where('t.business_id', $business_id)
                        ->whereIn('t.location_id', $location_id)
                        ->whereIn('t.type', array('sell', 'sell_return'))
                        ->where('t.status', 'final')
                        ->whereIn('t.payment_status', array('paid', 'partial'))
                        ->whereDate('t.created_at', $created_at)
                        ->select('t.*','t.id as transaction_id','tp.method', 'tp.card_type', 'tp.amount','tax_rates.apply_inclusive_gst','tax_rates.amount as tax_rate',
                        //DB::raw('(t.total_before_tax  - t.total_discount_amount - t.rp_redeemed_amount) * t.service_charges as total_service_charges')  ,
                        DB::raw('CASE WHEN tr.id IS NOT NULL THEN tr.total_before_tax ELSE 0 END as refund_total_before_tax'),
                          DB::raw('
                        CASE 
                            WHEN tax_rates.apply_inclusive_gst = 1 THEN 
                                ((t.total_before_tax - (CASE WHEN tr.id IS NOT NULL THEN tr.total_with_modifier ELSE 0 END) - t.total_discount_amount - t.rp_redeemed_amount + ((t.total_before_tax - t.total_discount_amount - t.rp_redeemed_amount) * t.service_charges)) / (tax_rates.amount + 100)) * tax_rates.amount
                            ELSE 
                                ((t.total_before_tax - (CASE WHEN tr.id IS NOT NULL THEN tr.total_with_modifier ELSE 0 END) - t.total_discount_amount - t.rp_redeemed_amount + (t.total_before_tax - t.total_discount_amount - t.rp_redeemed_amount) * t.service_charges) * tax_rates.amount / 100)
                        END as gst
                    '),
                        DB::raw('(
                                CASE
                                    WHEN tr.id IS NOT NULL AND t.total_before_tax = tr.total_before_tax THEN 0
                                    ELSE (
                                        t.total_before_tax 
                                        - (CASE WHEN tr.id IS NOT NULL THEN tr.total_before_tax ELSE 0 END) 
                                        - (t.total_discount_amount - IF(tr.id IS NOT NULL, tr.total_discount_amount, 0))
                                        - t.rp_redeemed_amount
                                    )
                                END
                            ) as net_sales')
                            ) 
                             ->get()->groupBy(function ($date) {
                                return Carbon::parse($date->created_at)->format('d');
                            }); 
                    }
                    if ($searchString != 'NA') {

                        $machineId = $location_detail->machine_id; // Need to change
                        $subFolderExist = false;
                        $vivoDirectories = Storage::disk('local')->allDirectories('GTO/' . $searchString);
                        $subDirectory = 'GTO/' . $searchString . '/' . $machineId;
                        $ftpLoginId = $location_detail->ftp_login_id;

                        if (count($vivoDirectories) > 0) {
                            foreach ($vivoDirectories as $directoryString) {
                                if (strpos($directoryString, (string) $machineId) !== false) {
                                    $subFolderExist = true;
                                    break;
                                }
                            }

                            if ($subFolderExist) {
                                Storage::disk('local')->makeDirectory($subDirectory);
                            }
                        } else {
                            Storage::disk('local')->makeDirectory($subDirectory);
                        }

                        $today_date = Carbon::parse($created_at)->format('Ymd');
                        $subSubFolderExist = false;
                        $subDirectories = Storage::disk('local')->allDirectories($subDirectory);
                        $subSubDirectory = 'GTO/' . $searchString . '/' . $machineId . '/' . $created_at->format('Y') . '/' . $created_at->format('m');
                        if (count($subDirectories) > 0) {
                            foreach ($subDirectories as $subDirectoryString) {
                                if (strpos($subDirectoryString, $today_date) !== false) {
                                    $subSubFolderExist = true;
                                    break;
                                }
                            }

                            if ($subSubFolderExist) {
                                Storage::disk('local')->makeDirectory($subSubDirectory);
                            }
                        } else {
                            Storage::disk('local')->makeDirectory($subSubDirectory);
                        }

                        $file = $this->getFileNameForOutletLocation($subSubDirectory,$file_extension, $serial_no, $location_detail->outlet_location_id, $machineId,$ftpLoginId, $created_at, $reportType,$fielFormats, $file_date_formats);

                        if (!$file)
                            continue;
                        if($reportType == "hourly"){
                            if (count($transactions) > 0) {
                                for ($hour = 0; $hour <= 23; $hour++) {
                                    $is_matched = false;
                                    foreach ($transactions as $key => $hourlyTransactions) {
                                        if ($key == sprintf('%02d', $hour)) {

                                            $line = $this->getLineForForOutletLocation($key, $hourlyTransactions,$report_date_formats, $use_pipe_for_report, $outletId, $serial_no, $reportFormats,$outltStartDate, $location_detail->outlet_location_id, $machineId,$ftpLoginId, $created_at, $reportType);

                                            $is_matched = true;
                                            break;
                                        }
                                    }
                                    if (!$is_matched) {

                                        $line = $this->getLineForForOutletLocation(sprintf('%02d', $hour), [], $report_date_formats, $use_pipe_for_report, $outletId,   $serial_no, $reportFormats,  $outltStartDate, $location_detail->outlet_location_id, $machineId,$ftpLoginId, $created_at, $reportType);
                                    }
                                    $this->saveLineToFile($file, $line);
                                }
                            } else {
                                $j = 0;
                                while (sprintf('%02d', $j) != '24') {
                                    $line = $this->getLineForForOutletLocation(sprintf('%02d', $j), [], $report_date_formats, $use_pipe_for_report, $outletId,  $serial_no, $reportFormats, $outltStartDate, $location_detail->outlet_location_id, $machineId,$ftpLoginId, $created_at, $reportType);

                                    $this->saveLineToFile($file, $line);
                                    $j++;
                                }
                            }
                        }else{
                            if (count($transactions) > 0) {
                                for ($day = 0; $day<1; $day++) {
                                    $is_matched = false;
                                    foreach ($transactions as $key => $dailyTransactions) {

                                        $line = $this->getLineForForOutletLocation($key, $dailyTransactions, $report_date_formats,  $use_pipe_for_report,  $outletId,  $serial_no, $reportFormats, $outltStartDate, $location_detail->outlet_location_id, $machineId,$ftpLoginId, $created_at);

                                        $is_matched = true;
                                        break;
                                    }
                                    if (!$is_matched) {
                                        $line = $this->getLineForForOutletLocation(sprintf('%02d', $day), [], $report_date_formats,  $use_pipe_for_report, $outletId,  $serial_no, $reportFormats,  $outltStartDate, $location_detail->outlet_location_id, $machineId,$ftpLoginId, $created_at);
                                    }
                                    $this->saveLineToFile($file, $line);
                                }
                            } else {
                                $j = 0;
                                while (sprintf('%02d', $j) != '1') {
                                    $line = $this->getLineForForOutletLocation($j, [], $report_date_formats,  $use_pipe_for_report, $outletId,  $serial_no, $reportFormats, $outltStartDate, $location_detail->outlet_location_id, $machineId,$ftpLoginId, $created_at);

                                    $this->saveLineToFile($file, $line);
                                    $j++;
                                }
                            }
                        }
                        return response()->json([
                            'success' => true,
                            'file' => asset('uploads/' . $file),
                            "path" => $file
                        ]);
                        } else {
                        return response()->json([
                            'success' => true,
                            'file' => ""
                        ]);
                        Log::error("machine id / FTP / File format not available for " . $location_detail->name . '<br/>');
                    }
                }
            }
        }
    }
    public function uploadGtoSalesFile(Request $request)
    {
        $location = BusinessLocation::where('id', $request->input('locationId'))
        ->select('ftp_server', 'machine_id', 'ftp_password', 'is_sftp', "ftp_port", "ftp_path")
        ->get(); 
        $file = $request->input("file");
        $this->saveToFTP($location[0], $file);
        return response()->json([
            'success' => true,
            'message' => __("Sals file upload successfully.")
        ]);
    
    }
    public function generate_serial_no($start_date, $current_date, $serial_no){

        $start_date = Carbon::parse($start_date);
        $current_date = Carbon::parse($current_date);
         if ($serial_no !== null && $serial_no !== '') {
            $serial_no = $start_date->diffInDays($current_date);
            $serial_no = str_pad($serial_no, 3, '0', STR_PAD_LEFT);
        }
        return $serial_no;

    }
}
