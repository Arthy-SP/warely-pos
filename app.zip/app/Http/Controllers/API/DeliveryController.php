<?php
namespace App\Http\Controllers\API;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Carbon\Carbon;
use App\User;
use App\BusinessLocation;
use App\Transaction;
use App\TransactionPayment;
use App\Utils\TransactionUtil;
use Illuminate\Support\Facades\DB;

class DeliveryController extends Controller
{
    /**
     * All Utils instance.
     *
     */
    protected $transactionUtil;

    /**
     * Constructor
     *
     * @param ProductUtils $product
     * @return void
     */
    public function __construct(
        TransactionUtil $transactionUtil
    ) {
        $this->transactionUtil = $transactionUtil;
    }
    
    public function track_delivery_order(Request $request)
    {
        $business_id = $request['business_id'];
        $location_id = $request['location_id'];
        $contact_id = $request['contact_id'];

        $query = Transaction::leftJoin(
                            'transaction_payments AS TP',
                            'transactions.id',
                            '=',
                            'TP.transaction_id'
                        )
                        ->leftJoin(
                            'delivery_details AS DD',
                            'transactions.id',
                            '=',
                            'DD.transaction_id'
                        )
                        ->leftJoin(
                            'business_locations AS BL',
                            'transactions.location_id',
                            '=',
                            'BL.id'
                        )
                        ->where('transactions.business_id', $business_id)
                        ->where('transactions.location_id', $location_id)
                        ->where('transactions.contact_id', $contact_id)
                        ->where('transactions.type', 'sell')
                        ->where('transactions.type_for_api', 'Delivery')
                        ->where('transactions.status', 'final')
                        ->whereDate('transactions.created_at','=', Carbon::today());

        $track_orders = $query->orderBy('transactions.id', 'desc')
                        ->select('transactions.id as transaction_id', 'transactions.ref_no', 'TP.last_4_card_digits', 
                        'TP.card_type', 'DD.d_address', 'DD.d_date', 'DD.d_time', 'BL.mobile as business_location_mobile')
                        ->get();
        
        if(count($track_orders) == 0) {
            $track_order_result = ["errorMessage" => 'Order not found.'];
        } else {
            foreach ($track_orders as $key => $track_order) {
                $track_order['last_4_card_digits'] = "**** **** **** ".$track_order['last_4_card_digits'];
                //$track_order->last_4_card_digits = str_pad($track_order->last_4_card_digits, 16, '*', STR_PAD_LEFT);
                $track_order_result[] = $track_order;
            }
        }

        return $this->respond($track_order_result);
    }

    public function lalamove_webhook(Request $request) {
        
        // get the content of request body  
        // decode json and covert to array  
        $order = json_decode($request->getContent(), true); 

        if(!empty($order))
        {
            if($order['eventType'] == 'ORDER_STATUS_CHANGED') {
                $lalamove_id = $order['data']['order']['id'];
                $lalamove_status = $order['data']['order']['status'];
                $lalamove_previous_status = !empty($order['data']['order']['previousStatus']) ? $order['data']['order']['previousStatus'] : null;
                $transaction = Transaction::where('lalamove_orderRef', $lalamove_id)
                                            //->where('lalamove_status', $lalamove_previous_status)
                                            ->firstOrFail();
                $lalamove_result = [
                    'lalamove_status' => $lalamove_status,
                    'lalamove_result' => json_encode($order)
                ];
                $transaction->fill($lalamove_result);
                $transaction->update();

                $stripe_key_result = BusinessLocation::where('business_id', $transaction->business_id)
                                  ->where('id', $transaction->location_id)
                                  ->select('stripe_pk','stripe_sk')
                                  ->get()
                                  ->toArray();

                $this->refund_lalamove_payment($transaction->id, $lalamove_status, $lalamove_result[0]['stripe_sk']);
                // $transaction = Transaction::where('id', 2096)->firstOrFail();
                // $update_lalamove_status = [
                //     'lalamove_result' => json_encode($order)
                // ];
                // $transaction->fill($update_lalamove_status);
                // $transaction->update();
            }
        }
        return ($order);
    }

    public function cron_job_update_lalamove_status() {
        $this->transactionUtil->get_cron_job_update_lalamove_status();
        
        return "success";
    }

    public function update_lalamove_status(Request $request) 
    {
        try {
            $transaction_id = $request['transaction_id'];
            $orderRef = $request['orderRef'];
            $lalamove_status = 'ASSIGNING_DRIVER';

            $transaction = Transaction::where('id', $transaction_id)->firstOrFail();
            $update_lalamove_status = [
                'lalamove_orderRef' => $orderRef,
                'lalamove_status' => $lalamove_status
            ];
            $transaction->fill($update_lalamove_status);
            $transaction->update();

            $output = ['msg' => "Lalamove status is updated." ];

        } catch (\Exception $e) {
            DB::rollBack();
            \Log::emergency("File:" . $e->getFile(). "Line:" . $e->getLine(). "Message:" . $e->getMessage());
            $msg = trans("messages.something_went_wrong");

            $output = [
                            'errorMessage' => $msg
                        ];
        }
        return $output;
    }

    public function get_delivery_order(Request $request)
    {
        $user_data = $request->only('business_id', 'location_id', 'token','user_id');
        //return $user_data;
        if(isset($user_data['token']))
        {
            $result = User::checkUserToken($user_data['token'], $user_data['user_id']);

            if($result)
            {  
                $business_id = $user_data['business_id'];
                $location_id = $user_data['location_id'];
                $transaction_status = "final";
                $created_at = null;
                $type = "Delivery"; //All Delivery

                $query = Transaction::leftJoin(
                    'transactions AS SR',
                    'transactions.id',
                    '=',
                    'SR.return_parent_id'
                )
                ->leftJoin(
                    'delivery_details AS DD',
                    'transactions.id',
                    '=',
                    'DD.transaction_id'
                )
                ->where('transactions.business_id', $business_id)
                ->where('transactions.location_id', $location_id)
                ->where('transactions.type', 'sell')
                ->where('transactions.is_direct_sale', 0)
                ->where('transactions.type_for_api', $type)
                ->where('transactions.status', $transaction_status);

                $transactions = $query->orderBy('transactions.created_at', 'desc')
                                    ->groupBy('transactions.id')
                                    ->select('transactions.*', 'SR.refund_all', 'DD.d_time', 'DD.d_address')
                                    ->with(['contact'])
                                    ->get();
                
                return ($transactions);
            }
            else
            {
                return["errorMessage"=>'Invalid token.'];
            }
        }
        else
        {
            return["errorMessage"=>'Invalid token.'];
        }
    }
    
    public function check_status_delivery_store(Request $request)
    {
        $input = $request->only('location_id');

        $location_id = $input['location_id'];

        $query = BusinessLocation::leftJoin(
            'store_status AS SS',
            'business_locations.id',
            '=',
            'SS.location_id'
        )
        ->where('SS.location_id', $location_id)
        ->where('SS.active', 1);

        $store_status = $query->orderBy('SS.created_at', 'desc')
                            ->select('SS.*')
                            ->get();

        if(empty(json_decode($store_status))) {
            //return json_encode(empty(json_decode($store_status)));
            return $this->respond(["result" => true]);
        } else {
            return $this->respond(["result" => false]);
        }
    }
}