<?php

namespace App\Http\Controllers\API;
use App\User;
use App;
use App\CampaignTelegram;
use App\TelegramChannel;
use Nwidart\Modules\Collection;
use PDF;
use Image;
use Carbon;
use App\Product;
use App\Category;
use App\Campaign;
use App\CampaignList;
use App\CouponLayout;
use App\Couponsystem;
use GuzzleHttp\Client;
use App\Http\Controllers\Controller;
use SimpleSoftwareIO\QrCode\Facades\QrCode;
use App\Utils\ModuleUtil;
use App\Utils\ProductUtil;

use Illuminate\Http\Request;

class CouponController extends Controller
{

        /**
     * All Utils instance.
     *
     */
    protected $productUtil;
    protected $moduleUtil;

    private $barcode_types;

    /**
     * Constructor
     *
     * @param ProductUtils $product
     * @return void
     */
    public function __construct(ProductUtil $productUtil, ModuleUtil $moduleUtil)
    {
        $this->productUtil = $productUtil;
        $this->moduleUtil = $moduleUtil;

        //barcode types
        $this->barcode_types = $this->productUtil->barcode_types();
    }

    public function checkUserCouponDetail(Request $request){
        $user_id = $request->user_id;
        $campaign_id = $request->campaign_id;
        $campaign_details = Campaign::find($campaign_id, ['id', 'channel_id', 'name', 'coupon_qty']);
        if(is_null($campaign_details)){
            $output = [
                        'success' =>  0,
                        'msg' => 'Campaign id not found',
                        ];
            return response()->json($output, 200);
        }
        $channel_ids=explode(',', $campaign_details->channel_id);
        $tele_channels=TelegramChannel::whereIn('id', $channel_ids)->select('channel_id')->get();
        // dd($tele_channels);
        $channel_name="";
        foreach ($tele_channels as $key => $tele_channel) {
            if($tele_channels->last() == $tele_channel){
                $channel_name .= $tele_channel->channel_id;
            }else{
                $channel_name .= $tele_channel->channel_id.', ';
            }
        }
        $campaign_details->channel_id=$channel_name;

        $check_user = CampaignList::where([['telegram_user_id', $user_id], ['campaign_id', $campaign_id]]);   
        $issued_coupon_clone = clone $check_user;     
        
        $campaign_coupons_generated_qty = CampaignList::where([['status', '!=', 0], ['campaign_id', $campaign_id]])->count();
        $campaign_details->campaign_coupons_generated_qty = $campaign_coupons_generated_qty;

        if($check_user->get()->count()>0 || $campaign_details){
            $campaign_per_user_coupon_limit = 10;
            $couponStatusCounts = $check_user->select('status', \DB::raw('COUNT(*) as count'))
            ->groupBy('status')->pluck('count', 'status');
            
            $issued_coupon = $couponStatusCounts[1] ?? 0;
            $redeemed_coupon = $couponStatusCounts[2] ?? 0;
            $expired_coupon = $couponStatusCounts[3] ?? 0;
            
            $issued_coupon_list = $issued_coupon_clone->where('status', 1)->get();
            
            $output = [
                'success' =>  1,
                'msg' => 'User coupon details',
                'user_coupon_details' => [  "issued_coupons" => $issued_coupon,
                                            "redeemed_coupons" => $redeemed_coupon, 
                                            "expired_coupons" => $expired_coupon,
                                            "campaign_per_user_coupon_limit" => $campaign_per_user_coupon_limit ],
                'campaign_details'  => $campaign_details,
                'user_coupons' => $issued_coupon_list,
            ];
        }else{
            $output = 
                [
                'success' =>  0,
                'msg' => 'User coupon details not found',
                'user_coupon_details' => [  "Issued Coupons" => 0,
                                            "Redeemed Coupon" => 0, 
                                            "Expired Coupons" => 0 ]
                ];
        }
        return response()->json($output, 200);
    }

    public function checkUserAllCoupons(Request $request){
        $user_id = $request->user_id;
        if (is_null($user_id)) {
            $output = [
                'success' => 0,
                'msg' => 'User id not found',
            ];
            return response()->json($output, 200);
        }

        $coupons = CampaignList::where('telegram_user_id', $user_id);

        if ($coupons->count() > 0) {

            $coupon_details = clone $coupons;

            $couponStatusCounts = $coupons->select('status', \DB::raw('COUNT(*) as count'))
                ->groupBy('status')
                ->pluck('count', 'status');

            $coupon_detail = $coupon_details->get();

            $issued_coupon = $couponStatusCounts[1] ?? 0;
            $redeemed_coupon = $couponStatusCounts[2] ?? 0;
            $expired_coupon = $couponStatusCounts[3] ?? 0;

            $output = [
                'success' => 1,
                'msg' => 'User coupon details',
                'user_coupon_details' =>
                    [
                        "issued_coupons" => $issued_coupon,
                        "redeemed_coupons" => $redeemed_coupon,
                        "expired_coupons" => $expired_coupon,
                        "coupon_details" => $coupon_detail
                    ]
            ];
        } else {
            $output =
                [
                    'success' => 0,
                    'msg' => 'User coupon details not found',
                    'user_coupon_details' => [
                        "Issued Coupons" => 0,
                        "Redeemed Coupon" => 0,
                        "Expired Coupons" => 0
                    ]
                ];
        }
        return response()->json($output, 200);
    }

    public function issueCoupon(Request $request){
        $user_id = $request->user_id;
        $campaign_id = $request->campaign_id;

        $check_user = CampaignList::where([['telegram_user_id', $user_id], ['campaign_id', $campaign_id], ['status', 1]])->first();
        $coupon = CampaignList::where('campaign_id', $campaign_id)->get();
        if(count($coupon)>0){
            
            $userIssuedCoupons = $coupon->where('telegram_user_id', $user_id)
            ->where('status', 1)
            ->where('issue_date', '>=', now()->subDay())
            ->count();
            if($coupon->where('status', 0)->count()>0 && $userIssuedCoupons<3){
                try{
                    $CampaignList= CampaignList::where('telegram_user_id', 0)->where('status', 0)->where('campaign_id', $campaign_id)->first();
                    $Couponsystem = Couponsystem::find($CampaignList->coupon_id);
                    $data['status'] = 1;
                    $data['telegram_user_id']=$user_id;
                    $data['issue_date'] = date('Y-m-d H:i:s');
                    $data['expiry_date'] = date('Y-m-d H:i:s',strtotime('+'.$Couponsystem->expiry_day.' days'));
                    $data['qr_sn'] = 'QR-'.$CampaignList->business_id.$CampaignList->layout_id.$CampaignList->coupon_id.$CampaignList->campaign_id.$CampaignList->id;
                    $coupon_data = CampaignList::where('id', $CampaignList->id)->first();
                    $image_url = $this->generateCoupon($CampaignList->campaign_id, $coupon_data);
                    $data['image'] = $image_url;
                    $campaignUpdate = CampaignList::where('id', $CampaignList->id)->update($data);
                    $output = ['success' => 1,
                                'msg' => 'coupon issued successfully',
                                'url' => $image_url,
                                'coupon_code'=>$data['qr_sn'],
                            ];
                } catch (\Exception $e) {
                    \Log::emergency("File:" . $e->getFile(). "Line:" . $e->getLine(). "Message:" . $e->getMessage());
                    $output = ['success' => 0,
                            'msg' => __("messages.something_went_wrong")
                        ];
                } 
            }else{
                $output = [
                    'success' => 0,
                    'msg' => 'You have already issued 3 coupons in the last 24 hours.',
                ];
            }
            return response()->json($output, 200);
        }else{
            $output = ['success' => 0,
            'msg' => 'This Campaign offer is over please wait for new compaign offer.',
            ];
            return response()->json($output, 200);
        }
    }

    public function reissueCoupon(Request $request){
        $id = $request->id;
        try {
            $coupon = CampaignList::findOrFail($id);
            if(!empty($coupon) && $coupon->status === 1){
                $image_url = $this->generateCoupon($coupon->campaign_id, $coupon);
                $output = [ 'success' => 1,
                            'msg' => 'coupon issued successfully',
                            'url' => $image_url,
                            'coupon_code'=>$coupon->qr_sn,
                        ];
            }elseif(!empty($coupon) && $coupon->status === 2){
                $output = [ 'success' => 1,
                            'msg' => 'previously used this coupon code.',
                            'coupon_code'=>$coupon->qr_sn,
                            ];
            }elseif(!empty($coupon) && $coupon->status === 3){
                $output = [ 'success' => 1,
                            'msg' => 'Coupon code expired',
                            'coupon_code'=>$coupon->qr_sn,
                            ];
            }else{
                $output = ['success' => 0,
                            'msg' => 'This Campaign offer is over please wait for new compaign offer.',
                            ];
            }
            return response()->json($output, 200);
        } catch (\Throwable $th) {
            $output = ['success' => 0,
                                'msg' => 'Record not found. Please provide valid id.',
                                ];
            return response()->json($output, 200);
        }

    }
    
    public function getCoupon($user_id, $campaign_id, $issue=null){
        $check_user = CampaignList::where([['telegram_user_id', $user_id], ['campaign_id', $campaign_id]])->first();
                $check_avalilable_coupon =  CampaignList::where('status', 0)->where('campaign_id', $campaign_id)->count();
                if($check_user === null && $check_avalilable_coupon>0){
                    try{
                        $CampaignList= CampaignList::where('telegram_user_id', 0)->where('status', 0)->where('campaign_id', $campaign_id)->first();
                        $Couponsystem = Couponsystem::find($CampaignList->coupon_id);
                        $data['status'] = 1;
                        $data['telegram_user_id']=$user_id;
                        $data['issue_date'] = date('Y-m-d H:i:s');
                        // if($campaign_id = 1){
                        //     $current_date = Carbon::now();
                        //     $data['expiry_date'] = $current_date->endOfMonth();
                        // }else{
                        $data['expiry_date'] = date('Y-m-d H:i:s',strtotime('+'.$Couponsystem->expiry_day.' days'));
                        // }
                        $data['qr_sn'] = 'QR-'.$CampaignList->business_id.$CampaignList->layout_id.$CampaignList->coupon_id.$CampaignList->campaign_id.$CampaignList->id;
                        $compaignUpdate = CampaignList::where('id', $CampaignList->id)->update($data);
                        $coupon_data = CampaignList::where('id', $CampaignList->id)->first();
                        $image_url = $this->generateCoupon($CampaignList->campaign_id, $coupon_data);
                        $output = ['success' => 1,
                                    'status' =>  1,
                                    'msg' => 'coupon issued successfully',
                                    'url' => $image_url,
                                    'coupon_code'=>$coupon_data->qr_sn,
                                ];
                        } catch (\Exception $e) {
                        \Log::emergency("File:" . $e->getFile(). "Line:" . $e->getLine(). "Message:" . $e->getMessage());
            
                            $output = ['success' => 0,
                                    'msg' => __("messages.something_went_wrong")
                                ];
                        } 
                        // return response()->json($output, 200);

                }elseif(!empty($check_user) && $issue === 'yes'){
                    $image_url = $this->generateCoupon($campaign_id, $check_user);
                    $output = [ 'success' => 1,
                                'is_issued'=> FALSE,
                                'msg' => 'coupon issued successfully',
                                'url' => $image_url,
                                'coupon_code'=>$check_user->qr_sn,
                            ];
                }elseif(!empty($check_user) && $issue === 'no'){
                    $output = [ 'success' => 1,
                                'msg' => 'Enjoy your privious coupon code.',
                                'coupon_code'=>$check_user->qr_sn,
                                ];
                }elseif(!empty($check_user) && $check_user->status == 2){
                    $output = ['success' => 1,
                                'is_used'=> TRUE,
                                'is_issued'=> TRUE,
                                'msg' => 'Coupon has been already used.',
                                'coupon_code'=>$check_user->qr_sn,
                                ];
                }elseif(!empty($check_user) && $check_user->status == 1){
                    $output = ['success' => 1,
                                'is_issued'=> TRUE,
                                'msg' => 'Your Coupon has already been issued. Coupon ID:'.$check_user->qr_sn.'. Do you want to get previous issued coupon (Yes / No) ',
                                'coupon_code'=>$check_user->qr_sn,
                                ];
                }else{
                    $output = ['success' => 1,
                                'is_used'=> TRUE,
                                'is_issued'=> TRUE,
                                'msg' => 'This Campaign offer is over please wait for new compaign offer.',
                                ];
                }
                return response()->json($output, 200);
    }


    private function generateCoupon($id, $coupon_data){
        
        $campaignList = CampaignList::find($coupon_data->id);
        $campaign = Campaign::find($campaignList->campaign_id);
        $Couponsystem = Couponsystem::find($campaign->coupon_id);
        
        $backqr = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAMgAAADICAYAAACtWK6eAAAAAXNSR0IArs4c6QAADtNJREFUeF7t3NFy42gOg9HM+z/0TnVN7WV0VP2Z+WWHe0uDAEFCcpLe+efr6+t/X5/9v38w3un5pe/p2znt36g/f5bz0QN+fX3pAE/PL32jB/CC5qf9e8EI37fYgJx/QGxARk+8Nd+AbEDaBZ33r+q/xG9Azi943yCjJ96ab0A2IO2CzvtX9e8bZH+LNXpD+0P6qL3zzfUV5vSCpW/eocZw2r+mHug7X7GevkAtSPorXgua7i9+1au+ipe+6fql/g2Iv0MrYFrg0w+o6qt4+Tdd34DEn0E2INcGbkCmIxz71wVVvORP9xe/6lVfxUvfdH3fIPsGuXSgHnjFTwdA/TcgG5ANyIUDG5ANyAZkA/K9A/ohe/orwnR/fYVQveqreOmbro+/QWRQHfC3H7j8rf5oP7V/xUuf6on/FX8H0QI1gOppwBv/fxDxaz7pU3/VK7/w4td86l/x0qd64t+AyN75PyRKwekDTAd24wGl+eSP6kn/BkT2bkDSgW1AfEA+wetPTC9I+vSEkz71V73yCy9+zaf+FS99qif+fYPIXj8AtAAzXH/i9AFqvtP65G/SvwGRvRuQdGD7FcsH5BPcr1hXDpx+Qm9AcMHVoHcPSNWvA1d/+S/8dF3zSb/wVX/i369Y1X7j6wFowVYw+wnNJ/3CV/WJfwNS7Te+HoAWbAWzn9B80i98VZ/4NyDVfuPrAWjBVjD7Cc0n/cJX9Yl/A1LtN74egBZsBbOf0HzSL3xVn/g3INV+4+sBaMFWMPsJzSf9wlf1iX8DUu03vh6AFmwFs5/QfNIvfFWf+Dcg1X7j6wFowVYw+wnNJ/3CV/WJfwPiP3TKYC2wHoD41V946Ve98gsvftU1/yX/BmQDogNTXQeeDlTkN+qJfwOyAblxY5cf2YDAQRlUF5CeAC/4x3Li13zVH/Grv/DSr3rlF178qmv+/YoVAy6DtaB6AOJXf+GlX/XKL7z4Vdf8G5ANiG4o1XXg6UCTsv/AiX9/BtmfQeoNbkDiE7guID0B6hPkBl7z6YCEn55f/Kprvqpf/Kon/le8QSRwuv7RC3qBeTqQSlH9r/wVP/4zSBVY8XVBwld9OtDT/HU+6df8lb/iNyBv/hWxHsD0gW5A6oaG8XVBwlf5OtDT/HU+6df8lb/i9w2yb5B6Q5f4Dciovb15XZDwVaGeoKf563zSr/krf8XvG2TfIPWG9g1y5cBbPwFu/B1DT8B6XfLvNH+dT/o1f+Wv+PwGqQJO47WguuDFn97wIP+dPxQO0v9I6w3Itc3TAf+RJU+RbED6v8WaPrB3D/jU7f5I3w3IBmQ64D9yyFMkG5ANyAbkIl0bkA3IBmQDMvp7/OkD259Bpr4/3ei7b5B9g0wH/MYZPvcjejo9V/nrlOlAxDTtofRV/un+8u/R9Wruo4e7KU4HojbTHkpf5Z/uL/8eXa/mPnq4m+J0IGoz7aH0Vf7p/vLv0fVq7qOHuylOB6I20x5KX+Wf7i//Hl2v5j56uJvidCBqM+2h9FX+6f7y79H1au6jh7spTgeiNtMeSl/ln+4v/x5dr+Y+erib4nQgajPtofRV/un+8u/R9Wruo4e7KU4HojbTHkpf5Z/uL/8eXf+JPxROL1AGi18Hcrp/5Re+zq/+ta79qX+abwPiv6RrAVpgWpDIb/w/JtViWp/4VZe/wqf5NiAbkHRAus4X1DcgMLEuUAY/vb9uTPMJX+dX/1o/Ot++QfYNsgG5iPAGZAOyAdmAXL7l64HoK0Dtr68o4hd+Wp/4VT86375B9g2yAcEbRAl+97oOoD6hqj/T+tRf+uXP6f6j+tRc5r1DXQs87cG0PvXXDuXP6f6j+tRc5r1DXQs87cG0PvXXDuXP6f6j+tRc5r1DXQs87cG0PvXXDuXP6f6j+tRc5r1DXQs87cG0PvXXDuXP6f6j+tRc5r1DXQs87cG0PvXXDuXP6f6j+tRc5r1DXQs87cG0PvXXDuXP6f6j+tRc5r1DXQs87cG0PvXXDuXP6f6j+tT8j3nVgKcvQPrq/PK49pf+Wpd+9T89n/Rf6hN4A9IfEPL49AHpwKVf+NPzSf8GRBtEvS44LShqfwVc+sVR/VN/1aV/AyIHNyCXDujAZO8GRA6hrgVUg9Vf8qf5a3/pr/XT/k3r3zdIdLgesA6s9o/jES79anB6PunfgGiD+xVrv2J954DStb/F2t9i3bmRq4T9+jdINTA+4I/Dpw9A/opfeBmo/sKrLn3ir/j8+qwCZdC71+VPna8egPDS9+7zJf13zBPBnR5awjvX5U+dTf6KX3jpU3/hVZc+8Vf8vkG0oVjXAmP7r3oAwkvfu8+X9N8xTwR3emgJ71yXP3U2+St+4aVP/YVXXfrEX/H7BtGGYl0LjO33DQIDNyD1wobxG5BmcD3wit83SNsf0RsQWpRuUP4eD0gb3+hpA0YN9Hj8iqQW8kd41af9UX/p0/y1f0qvxL+iXg2YxtcZ6wI137S+yj89f+2/AcEF1QPQgdYFntZX+afnr/03IBuQdAMbED0Ch+tagJ4Q0/g6vvSrv+YTXnXpq/zqL33ir/3T00PiX1GvBkzj64x1gZpvWl/ln56/9t+A7FesdAMbkPoIingtQE+IaXwcb3/NGw2s+030Or4/zSVQAsSh/sKLX/2FF7/6Cy9+9Re+1qW/6lN/6Re/+l/iBd6AfPENUBdUD0D4WteNaH7xq7/w4lf/DYgcRj0Z/OWASZ4OQPhar/OLX/2Flz/qvwGRwxuQX/1D/AZkA5IcSE/gG8zqrxb7BpFDqMtAtdcC1V948au/8LUu/VWf+ku/+NV/3yByeL9i7Ves7xxQuva3WP4huz7BlF/1F77WdSNVn/pLv/jVn28QEUhgrWsA9Zd+9Z/GS7/0Ca/66fmkb7oufzcg8WeUZPCN7av/jRaXH9mAXDu4AdmAHP0Zowa84vUA2oBsQDYgFw5sQDYgG5ANyPcOpFfsjX8qou/4+oogfcKrLn3iF178p+tpvj/g0wZoABks/eo/jZd+6RNe9dPzSd90Xf7uV6z9irVfscpXrOkE6wkmfj0BhJ/mV/9p/eo/rU/+1/q0fr5B6gDCa0DhdQDCT/Or/7R+9Z/WJ/9rfVr/BiRu6PQB1gOp+Ghfhk/r34DEFW1AooERvgGBgTpQ+S+DhRe/+gsv/tq/4qVvuj6tf98gcYM68KMLfMHfaTRftC/Dj/r7E+ZoQDlYNU7zq/+0fvWf1qf91fq0/n2DxA2dPsB6IBUf7cvwaf0MiARoQh2Q8OJXf+HFr7r4hT+tb5pf80/X634u9b3in5pUgVqg+gtfFyR+9T+tb5pf80/X6342IHFDdQHTByp90/zR3gzX/Ilg3yC2ry5g+kClb5rfDs5+QvMn9g2I7asLmD5Q6Zvmt4Ozn9D8iX0DYvvqAqYPVPqm+e3g7Cc0f2LfgNi+uoDpA5W+aX47OPsJzZ/YNyC2ry5g+kClb5rfDs5+QvMn9tHmSdnPgesBVQ/FP91fTld+9a/zVzx/zasBPr0ugzV/PSDxT/efnk/96/wVvwHBhmSwFjx9wNP9p+dTf/mv+St+A7IB0Y0evZF64BV/dPi0mR8Cy2DJ0BNOePFP95e+yq/+df6K34DsG0Q3evRG6oFX/NHh02Z+CCyDJaM+YcU/3X96PvWv81f8BmTfILrRozdSD7ziObwIkrsPAE8/gaf7VwulT/v/1fhX/CW9LnAarwWLvx5Q7S+86pq/zvfR+A2Izsv/7WIdoBh0YMKrLn3i/9X4DYjOawOyAfGNvPUntGANV5+wtb/wqmv+Ot9H4/cNovPaN8ivDtgGZAPy0W+A+h/W24BsQDYgFzdwJyB6xfrEZj8xveBZ9e4u/zW/Ga4/If7av+qv+i75NyD+GaMeQMXrAOqBSZ/4hVe96q/6NiDYUF2QDqDWdQDT+sVf56v6q74NyAYk3XA9QJFvQORQrMtgLVj4KC/DT+sXfx2w+l/17Rtk3yDphusBinwDIodiXQZrwcJHeRl+Wr/464DV/6pv3yD7Bkk3XA9Q5B8fkDqgDNSCxC+8+FWf5ld/6fv0uvab/HvF30GSgBvbqwYIf0PC5Uc0f+VX/6r/3fHyN/m3AennoQVogVKg/sJ/el3+Jv82IP18tAAtUArUX/hPr8vf5N8GpJ+PFqAFSoH6C//pdfmb/NuA9PPRArRAKVB/4T+9Ln+TfxuQfj5agBYoBeov/KfX5W/ybwPSz0cL0AKlQP2F//S6/E3+bUB8PjJYCzLD9SfEX/tLv/iFlz71F77WL/VvQGyvFlgPRArEL7zq0i9+4cWv/sLX+gYkOqgF1gORPPELr7r0i1948au/8LW+AYkOaoH1QCRP/MKrLv3iF1786i98rW9AooNaYD0QyRO/8KpLv/iFF7/6C1/rG5DooBZYD0TyxC+86tIvfuHFr/7C1/oGJDqoBdYDkTzxC6+69ItfePGrv/C1vgGJDmqB9UAkT/zCqy794hde/OovfK1vQOCgFjR9ALW/DqTON42XftXln/Rf9t+/g/i/i6UFaIFaUO0/zV/1Cy/9qsu/xL8B2YDUA6t4BUD1Uf4NyAakHljFKwCqj/JvQDYg9cAqXgFQfZR/A7IBqQdW8QqA6qP8G5ANSD2wilcAVB/l34BsQOqBVbwCoPoo/ysCogGm6/o13qiBN4YTv1rU+Wp/4TWf9Ku/6uIXfvzvIEnAC8BagAwUvkoUv/pL33R/6RO/9Ku/6uIXfgMCh56+QOmrB6L+OjDx1/6VX/gNyAbk0oF6wBuQFMF5sBb87gus82kD6i/8u/u7b5B9g+wbRCn/rr6/xfKvef/W2//j9IRVfz3hp/tLn/ilX/1VF7/w+wbZN8i+Qf42JXfeIH/b+yk4PWH0hKv4aR+kT/yaX3jVpa/yq7/0XfJvQPwVSwuoC9YCVZc+4af1S1/lV/80/wZkA1IPVAeoA6786i99+waJP4NoAXXBWqDq0if8tH7pq/zqn+bfN8i+QeqB6gB1wJVf/aVv3yD7Bhn9LZYOUAe8AZGDw/W6oIofHu9L+sRfD1T9pa/yq7/07Rtk3yD7Brlw4DIg/wKazAh8RXV4awAAAABJRU5ErkJggg==";
        $frontqr = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAMgAAADICAYAAACtWK6eAAAAAXNSR0IArs4c6QAADtNJREFUeF7t3NFy42gOg9HM+z/0TnVN7WV0VP2Z+WWHe0uDAEFCcpLe+efr6+t/X5/9v38w3un5pe/p2znt36g/f5bz0QN+fX3pAE/PL32jB/CC5qf9e8EI37fYgJx/QGxARk+8Nd+AbEDaBZ33r+q/xG9Azi943yCjJ96ab0A2IO2CzvtX9e8bZH+LNXpD+0P6qL3zzfUV5vSCpW/eocZw2r+mHug7X7GevkAtSPorXgua7i9+1au+ipe+6fql/g2Iv0MrYFrg0w+o6qt4+Tdd34DEn0E2INcGbkCmIxz71wVVvORP9xe/6lVfxUvfdH3fIPsGuXSgHnjFTwdA/TcgG5ANyIUDG5ANyAZkA/K9A/ohe/orwnR/fYVQveqreOmbro+/QWRQHfC3H7j8rf5oP7V/xUuf6on/FX8H0QI1gOppwBv/fxDxaz7pU3/VK7/w4td86l/x0qd64t+AyN75PyRKwekDTAd24wGl+eSP6kn/BkT2bkDSgW1AfEA+wetPTC9I+vSEkz71V73yCy9+zaf+FS99qif+fYPIXj8AtAAzXH/i9AFqvtP65G/SvwGRvRuQdGD7FcsH5BPcr1hXDpx+Qm9AcMHVoHcPSNWvA1d/+S/8dF3zSb/wVX/i369Y1X7j6wFowVYw+wnNJ/3CV/WJfwNS7Te+HoAWbAWzn9B80i98VZ/4NyDVfuPrAWjBVjD7Cc0n/cJX9Yl/A1LtN74egBZsBbOf0HzSL3xVn/g3INV+4+sBaMFWMPsJzSf9wlf1iX8DUu03vh6AFmwFs5/QfNIvfFWf+Dcg1X7j6wFowVYw+wnNJ/3CV/WJfwPiP3TKYC2wHoD41V946Ve98gsvftU1/yX/BmQDogNTXQeeDlTkN+qJfwOyAblxY5cf2YDAQRlUF5CeAC/4x3Li13zVH/Grv/DSr3rlF178qmv+/YoVAy6DtaB6AOJXf+GlX/XKL7z4Vdf8G5ANiG4o1XXg6UCTsv/AiX9/BtmfQeoNbkDiE7guID0B6hPkBl7z6YCEn55f/Kprvqpf/Kon/le8QSRwuv7RC3qBeTqQSlH9r/wVP/4zSBVY8XVBwld9OtDT/HU+6df8lb/iNyBv/hWxHsD0gW5A6oaG8XVBwlf5OtDT/HU+6df8lb/i9w2yb5B6Q5f4Dciovb15XZDwVaGeoKf563zSr/krf8XvG2TfIPWG9g1y5cBbPwFu/B1DT8B6XfLvNH+dT/o1f+Wv+PwGqQJO47WguuDFn97wIP+dPxQO0v9I6w3Itc3TAf+RJU+RbED6v8WaPrB3D/jU7f5I3w3IBmQ64D9yyFMkG5ANyAbkIl0bkA3IBmQDMvp7/OkD259Bpr4/3ei7b5B9g0wH/MYZPvcjejo9V/nrlOlAxDTtofRV/un+8u/R9Wruo4e7KU4HojbTHkpf5Z/uL/8eXa/mPnq4m+J0IGoz7aH0Vf7p/vLv0fVq7qOHuylOB6I20x5KX+Wf7i//Hl2v5j56uJvidCBqM+2h9FX+6f7y79H1au6jh7spTgeiNtMeSl/ln+4v/x5dr+Y+erib4nQgajPtofRV/un+8u/R9Wruo4e7KU4HojbTHkpf5Z/uL/8eXf+JPxROL1AGi18Hcrp/5Re+zq/+ta79qX+abwPiv6RrAVpgWpDIb/w/JtViWp/4VZe/wqf5NiAbkHRAus4X1DcgMLEuUAY/vb9uTPMJX+dX/1o/Ot++QfYNsgG5iPAGZAOyAdmAXL7l64HoK0Dtr68o4hd+Wp/4VT86375B9g2yAcEbRAl+97oOoD6hqj/T+tRf+uXP6f6j+tRc5r1DXQs87cG0PvXXDuXP6f6j+tRc5r1DXQs87cG0PvXXDuXP6f6j+tRc5r1DXQs87cG0PvXXDuXP6f6j+tRc5r1DXQs87cG0PvXXDuXP6f6j+tRc5r1DXQs87cG0PvXXDuXP6f6j+tRc5r1DXQs87cG0PvXXDuXP6f6j+tRc5r1DXQs87cG0PvXXDuXP6f6j+tT8j3nVgKcvQPrq/PK49pf+Wpd+9T89n/Rf6hN4A9IfEPL49AHpwKVf+NPzSf8GRBtEvS44LShqfwVc+sVR/VN/1aV/AyIHNyCXDujAZO8GRA6hrgVUg9Vf8qf5a3/pr/XT/k3r3zdIdLgesA6s9o/jES79anB6PunfgGiD+xVrv2J954DStb/F2t9i3bmRq4T9+jdINTA+4I/Dpw9A/opfeBmo/sKrLn3ir/j8+qwCZdC71+VPna8egPDS9+7zJf13zBPBnR5awjvX5U+dTf6KX3jpU3/hVZc+8Vf8vkG0oVjXAmP7r3oAwkvfu8+X9N8xTwR3emgJ71yXP3U2+St+4aVP/YVXXfrEX/H7BtGGYl0LjO33DQIDNyD1wobxG5BmcD3wit83SNsf0RsQWpRuUP4eD0gb3+hpA0YN9Hj8iqQW8kd41af9UX/p0/y1f0qvxL+iXg2YxtcZ6wI137S+yj89f+2/AcEF1QPQgdYFntZX+afnr/03IBuQdAMbED0Ch+tagJ4Q0/g6vvSrv+YTXnXpq/zqL33ir/3T00PiX1GvBkzj64x1gZpvWl/ln56/9t+A7FesdAMbkPoIingtQE+IaXwcb3/NGw2s+030Or4/zSVQAsSh/sKLX/2FF7/6Cy9+9Re+1qW/6lN/6Re/+l/iBd6AfPENUBdUD0D4WteNaH7xq7/w4lf/DYgcRj0Z/OWASZ4OQPhar/OLX/2Flz/qvwGRwxuQX/1D/AZkA5IcSE/gG8zqrxb7BpFDqMtAtdcC1V948au/8LUu/VWf+ku/+NV/3yByeL9i7Ves7xxQuva3WP4huz7BlF/1F77WdSNVn/pLv/jVn28QEUhgrWsA9Zd+9Z/GS7/0Ca/66fmkb7oufzcg8WeUZPCN7av/jRaXH9mAXDu4AdmAHP0Zowa84vUA2oBsQDYgFw5sQDYgG5ANyPcOpFfsjX8qou/4+oogfcKrLn3iF178p+tpvj/g0wZoABks/eo/jZd+6RNe9dPzSd90Xf7uV6z9irVfscpXrOkE6wkmfj0BhJ/mV/9p/eo/rU/+1/q0fr5B6gDCa0DhdQDCT/Or/7R+9Z/WJ/9rfVr/BiRu6PQB1gOp+Ghfhk/r34DEFW1AooERvgGBgTpQ+S+DhRe/+gsv/tq/4qVvuj6tf98gcYM68KMLfMHfaTRftC/Dj/r7E+ZoQDlYNU7zq/+0fvWf1qf91fq0/n2DxA2dPsB6IBUf7cvwaf0MiARoQh2Q8OJXf+HFr7r4hT+tb5pf80/X634u9b3in5pUgVqg+gtfFyR+9T+tb5pf80/X6342IHFDdQHTByp90/zR3gzX/Ilg3yC2ry5g+kClb5rfDs5+QvMn9g2I7asLmD5Q6Zvmt4Ozn9D8iX0DYvvqAqYPVPqm+e3g7Cc0f2LfgNi+uoDpA5W+aX47OPsJzZ/YNyC2ry5g+kClb5rfDs5+QvMn9tHmSdnPgesBVQ/FP91fTld+9a/zVzx/zasBPr0ugzV/PSDxT/efnk/96/wVvwHBhmSwFjx9wNP9p+dTf/mv+St+A7IB0Y0evZF64BV/dPi0mR8Cy2DJ0BNOePFP95e+yq/+df6K34DsG0Q3evRG6oFX/NHh02Z+CCyDJaM+YcU/3X96PvWv81f8BmTfILrRozdSD7ziObwIkrsPAE8/gaf7VwulT/v/1fhX/CW9LnAarwWLvx5Q7S+86pq/zvfR+A2Izsv/7WIdoBh0YMKrLn3i/9X4DYjOawOyAfGNvPUntGANV5+wtb/wqmv+Ot9H4/cNovPaN8ivDtgGZAPy0W+A+h/W24BsQDYgFzdwJyB6xfrEZj8xveBZ9e4u/zW/Ga4/If7av+qv+i75NyD+GaMeQMXrAOqBSZ/4hVe96q/6NiDYUF2QDqDWdQDT+sVf56v6q74NyAYk3XA9QJFvQORQrMtgLVj4KC/DT+sXfx2w+l/17Rtk3yDphusBinwDIodiXQZrwcJHeRl+Wr/464DV/6pv3yD7Bkk3XA9Q5B8fkDqgDNSCxC+8+FWf5ld/6fv0uvab/HvF30GSgBvbqwYIf0PC5Uc0f+VX/6r/3fHyN/m3AennoQVogVKg/sJ/el3+Jv82IP18tAAtUArUX/hPr8vf5N8GpJ+PFqAFSoH6C//pdfmb/NuA9PPRArRAKVB/4T+9Ln+TfxuQfj5agBYoBeov/KfX5W/ybwPSz0cL0AKlQP2F//S6/E3+bUB8PjJYCzLD9SfEX/tLv/iFlz71F77WL/VvQGyvFlgPRArEL7zq0i9+4cWv/sLX+gYkOqgF1gORPPELr7r0i1948au/8LW+AYkOaoH1QCRP/MKrLv3iF1786i98rW9AooNaYD0QyRO/8KpLv/iFF7/6C1/rG5DooBZYD0TyxC+86tIvfuHFr/7C1/oGJDqoBdYDkTzxC6+69ItfePGrv/C1vgGJDmqB9UAkT/zCqy794hde/OovfK1vQOCgFjR9ALW/DqTON42XftXln/Rf9t+/g/i/i6UFaIFaUO0/zV/1Cy/9qsu/xL8B2YDUA6t4BUD1Uf4NyAakHljFKwCqj/JvQDYg9cAqXgFQfZR/A7IBqQdW8QqA6qP8G5ANSD2wilcAVB/l34BsQOqBVbwCoPoo/ysCogGm6/o13qiBN4YTv1rU+Wp/4TWf9Ku/6uIXfvzvIEnAC8BagAwUvkoUv/pL33R/6RO/9Ku/6uIXfgMCh56+QOmrB6L+OjDx1/6VX/gNyAbk0oF6wBuQFMF5sBb87gus82kD6i/8u/u7b5B9g+wbRCn/rr6/xfKvef/W2//j9IRVfz3hp/tLn/ilX/1VF7/w+wbZN8i+Qf42JXfeIH/b+yk4PWH0hKv4aR+kT/yaX3jVpa/yq7/0XfJvQPwVSwuoC9YCVZc+4af1S1/lV/80/wZkA1IPVAeoA6786i99+waJP4NoAXXBWqDq0if8tH7pq/zqn+bfN8i+QeqB6gB1wJVf/aVv3yD7Bhn9LZYOUAe8AZGDw/W6oIofHu9L+sRfD1T9pa/yq7/07Rtk3yD7Brlw4DIg/wKazAh8RXV4awAAAABJRU5ErkJggg==";
        $backqr ="";
        $frontqr = "";
        $backqrstr = explode('"backQrCode" src="', $Couponsystem->back_image);
        
        if(count($backqrstr) > 1)
        $backqr = explode('" alt=', $backqrstr[1])[0];
        
        $frontqrstr = explode('"frontQrCode" src="', $Couponsystem->front_image);
        
        if(count($frontqrstr) > 1)
        $frontqr = explode('" alt=', $frontqrstr[1])[0];
        
        $jsonQr = json_encode(array("coupon_id"=>$coupon_data->id,'channel'=>'@ShiokDeals','subscriber'=>$coupon_data->telegram_user_id));
        $qr = 'data:image/png;base64, '.base64_encode(QrCode::format('png')->size(300)->generate($jsonQr));
        $findTxt = array('{coupon_name}','{coupon_qty}','{coupon_value}','{min_purchase}','{min_pax}','{expiry_date}','{qr_sn}',$frontqr,$backqr);
        $replaceTxt = array($Couponsystem->coupon_name,$campaign->coupon_qty,$Couponsystem->coupon_value,$Couponsystem->min_purchase,$Couponsystem->min_pax,$campaignList->expiry_date,$campaignList->qr_sn, $qr,$qr);
        $CouponsystemLayoutFront = str_ireplace($findTxt,$replaceTxt,$Couponsystem->front_image);
        $CouponsystemLayoutBack =  str_ireplace($findTxt,$replaceTxt,$Couponsystem->back_image);
        
        $snappy = App::make('snappy.image');
        
        // $pdf = view('campaign.coupon_view', array("CouponsystemLayoutFront"=>$CouponsystemLayoutFront,"CouponsystemLayoutBack"=>$CouponsystemLayoutBack, "qr" => $qr))->render();
        // $snappy->setOption('width',800);
        // $snappy->generateFromHtml($pdf, public_path('generated-coupons/'. "coupon-" . $coupon_data->id . '-coupon.png'),array(), true);
        // $file_path = $this->productUtil->uploadFile(public_path('generated-coupons/'. "coupon-" . $coupon_data->id . '-coupon.png'), "coupon-" . $coupon_data->id . '-coupon.png');
        // unlink(public_path('generated-coupons/'. "coupon-" . $coupon_data->id . '-coupon.png'));

        // return $file_path;

        // $jsonQr = json_encode(array("coupon_id"=>$coupon_data->id,'channel'=>'@ShiokDeals','subscriber'=>$coupon_data->telegram_user_id));
        // $qr = 'data:image/png;base64, '.base64_encode(QrCode::format('png')->size(300)->generate($jsonQr));
        // $findTxt = array('{coupon_name}','{coupon_qty}','{coupon_value}','{min_purchase}','{min_pax}','{expiry_date}','{qr_sn}',$frontqr,$backqr);
        // $replaceTxt = array($Couponsystem->coupon_name,$campaign->coupon_qty,$Couponsystem->coupon_value,$Couponsystem->min_purchase,$Couponsystem->min_pax,$campaignList->expiry_date,$campaignList->qr_sn, $qr,$qr);
        // $CouponsystemLayoutFront = str_ireplace($findTxt,$replaceTxt,$Couponsystem->front_image);
        // $CouponsystemLayoutBack =  str_ireplace($findTxt,$replaceTxt,$Couponsystem->back_image);
        
        // $snappy = App::make('snappy.image');
        
        $pdf = view('campaign.coupon_view', array("CouponsystemLayoutFront"=>$CouponsystemLayoutFront,"CouponsystemLayoutBack"=>$CouponsystemLayoutBack, "qr" => $qr))->render();
        $snappy->setOption('width',800);
        $snappy->generateFromHtml($pdf, public_path('generated-coupons/'. "coupon-" . $coupon_data->id . '-coupon.png'),array(), true);
        $file_path = $this->productUtil->uploadFileOnS3(public_path('generated-coupons/'. "coupon-" . $coupon_data->id . '-coupon.png'), "coupon-" . $coupon_data->id . '-coupon.png');
        unlink(public_path('generated-coupons/'. "coupon-" . $coupon_data->id . '-coupon.png'));
        // $file_path = url('generated-coupons/'."coupon-".$coupon_data->id.'-coupon.png');
        return $file_path;
    }
    
    
    public function redeemCoupon(Request $request){
         
        $qr_sn = $request->input(['qr_sn']);
        $subscriber_id = $request->input(['user_id']);
        $coupon_id = $request->input(['coupon_id']);
        \Log::error("$qr_sn,  $subscriber_id,  $coupon_id");
        $date = Carbon::now();
        $current_time = $date->format('Y-m-d H:i:s');
        if(!$this->checkTelegramSubscriber($subscriber_id))
        {
                 $output=[
                    'success' => 1,
                    'msg' => 'You are not subscribed, Please Subscribe to @ShoikDeals first.' 
                ];
        }else{
            
            
        $couponData=CampaignList::where('telegram_user_id', $subscriber_id)
            ->where(function ($query) use($coupon_id, $qr_sn){
                $query->where('id', '=', $coupon_id)
                ->orWhere('qr_sn', '=' , $qr_sn)
                ->orWhere('qr_sn', '=' , $coupon_id)
                ->orWhere('id', '=' , $qr_sn)
                ->orWhere('coupon_id', '=' , $coupon_id);
            })->first();
        if(!empty($couponData)){
            if($couponData->status == 1 && $couponData->expiry_date > $current_time){
                $coupon_redeem = $couponData->update(['status'=>2, 'redeem_date'=>$current_time]);
                $output=[
                    'success' => 1,
                    'msg' => 'Coupon code applied successfully.' 
                ];
            }elseif($couponData->status == 2){
                $output=[
                    'success' => 1,
                    'msg' => 'Coupon code already redeemed.' 
                ];
            }elseif($couponData->status == 3 || $couponData->expiry_date < $current_time){
                $output=[
                    'success' => 1,
                    'msg' => 'Coupon code expired.' 
                ];
            }
        }else{
            $output=[
                'success' => 0,
                'msg' => 'Wrong coupon code. Please check again.'
            ];
        }
        }
        return $output;
    }
    
    private function checkTelegramSubscriber($telegram_id) {
        
        $client = new Client(['base_uri' => 'https://api.telegram.org']);
        try{
        $response = $client->request('GET', '/bot5549021639:AAETdf3r03u7IRm03UxqK2nfWzS8vt7jhp4/getChatMember?chat_id=@ShiokDeals&user_id='.$telegram_id);
        
        $json = json_decode($response->getBody());
        if($json->result->status =='left') return false; else return true;
        }catch (\Exception $e) {
            return false;
        }
        
    }

    public function getCampaignList($channel_id=NULL){
        try {
            if(!empty($channel_id)){
                $campaign_list= Campaign::where('channel_id', $channel_id)->select("id", "name")->get();
                if($campaign_list->count()>0){
                    $output=[
                        'success' => 1,
                        'msg' => ' Campaign list access successfully.',
                        'campaign_list' => $campaign_list
                    ];
                }else{
                    $output=[
                        'success' => 0,
                        'msg' => 'This is not an official telegram channel to access coupons.',
                        // 'campaign_list' => $campaign_list
                    ];
                }
            }else{
                $output=[
                    'success' => 0,
                    'msg' => 'Channel id not found.',
                ];
            }
            return $output;
        } catch (\Exception $e) {
            $output=[
                'success' => 0,
                'msg' => 'Something went wrong.',
                'error_msg'=>$e->getMessage(),
            ];
            return $output;
        }
    }

    public function getAllCampaignList(Request $request){
        $channel_ids = $request->telegram_channel_ids;
        try {
            if(!empty($channel_ids)){
                $campaign_data = CampaignTelegram::whereIn('telegram_channel_id', $channel_ids)->groupBy('campaign_id')->get("campaign_id");
                $campaign_list= Campaign::whereIn('id', $campaign_data)->get();
                if($campaign_list->count()>0){
                    $output=[
                        'success' => 1,
                        'msg' => ' Campaign list access successfully.',
                        'campaign_list' => $campaign_list
                    ];
                }else{
                    $output=[
                        'success' => 0,
                        'msg' => 'Campaign record not found'
                    ];
                }
            }else{
                $output=[
                    'success' => 0,
                    'msg' => 'Channel id not found.',
                ];
            }
            return $output;
        } catch (\Exception $e) {
            $output=[
                'success' => 0,
                'msg' => 'Something went wrong.',
                'error_msg'=>$e->getMessage(),
            ];
            return $output;
        }
    }

    public function getTelegramChannelList(){
        $channel_name= TelegramChannel::where('type', 'channel')->get();
        $group_name= TelegramChannel::where('type', 'supergroup')->get();

        $channels_groups = Collection::make([ 'channels'=> $channel_name, 'groups'=> $group_name ]);

        if($channel_name->count()>0){
            $output=[
                'success' => 1,
                'msg' => 'Telegram channel list access successfully.',
                // 'channel_list' => $channel_name,
                'channel_group_list' => $channels_groups,
            ];
        }else{
            $output=[
                'success' => 0,
                'msg' => 'Telegram channels not available.'
            ];
        }
        return $output;
    }

    public function getTelegramGroupList(){
        $group_name= TelegramChannel::where('type', 'supergroup')->get();
        if($group_name->count()>0){
            $output=[
                'success' => 1,
                'msg' => 'Telegram group list access successfully.',
                'group_list' => $group_name
            ];
        }else{
            $output=[
                'success' => 0,
                'msg' => 'Telegram groups not available.'
            ];
        }
        return $output;
    }

    public function getCampaign($id=null){
        try {
            if(!empty($id)){
                $campaign= Campaign::find($id);
                if($campaign){
                    $output=[
                        'success' => 1,
                        'msg' => ' Campaign data access successfully.',
                        'campaign_list' => $campaign
                    ];
                }else{
                    $output=[
                        'success' => 1,
                        'msg' => ' Campaign data not found.',
                        'campaign_list' => $campaign
                    ];
                }
                }else{
                $output=[
                    'success' => 0,
                    'msg' => 'Campaign id not found.',
                ];
            }
            return $output;
        } catch (\Exception $e) {
            $output=[
                'success' => 0,
                'msg' => 'Something went wrong.',
                'error_msg'=>$e->getMessage(),
            ];
            return $output;
        }
    }

    public function get_all_coupons(Request $request) {
        $user_data = $request->only('business_location_id', 'business_id');

        try {
            $currentDate = Carbon::now();

            $couponsList = Couponsystem::where('business_id', $user_data['business_id'])
                                    ->whereDate('start_date', '<=', $currentDate)
                                    ->whereDate('end_date', '>=', $currentDate)
                                    ->get()
                                    ->makeHidden(['front_image', 'back_image']);

            return response()->json([
                'success' => true,
                'result' => $couponsList
            ], 200);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'errorMessage' => 'Error retrieving coupons'
            ], 200);
        }
    }

    public function get_campaign_coupons(Request $request) {
        $user_data = $request->only('business_location_id', 'business_id', 'location_id', 'contact_id');
        
        try {

            $currentDate = Carbon::now();
            $location_id = intval($user_data['location_id']);

            $couponsList = Campaign::join('couponsystems', 'campaigns.coupon_id', '=', 'couponsystems.id')
                            ->where('campaigns.business_id', $user_data['business_id'])
                            ->whereJsonContains('campaigns.location_id', strval($location_id))
                            ->whereDate('campaigns.start_date', '<=', $currentDate)
                            ->whereDate('couponsystems.start_date', '<=', $currentDate)
                            ->whereDate('couponsystems.end_date', '>=', $currentDate)
                            ->select(
                                'campaigns.id as campaign_id',
                                'campaigns.name as campaign_name',
                                'coupon_api',
                                'campaign_type',
                                'target_type',
                                'campaign_product_ids',
                                'campaign_category_ids',
                                'campaigns.start_date as campaign_start_date',
                                'campaigns.end_date as campaign_end_date',
                                'couponsystems.*' 
                            )
                            ->get()
                            ->map(function ($item) {
                                $productIds = $item->campaign_product_ids ? json_decode($item->campaign_product_ids, true) : [];
                                $categoryIds = $item->campaign_category_ids ? json_decode($item->campaign_category_ids, true) : [];
        
                                // Fetch product names
                                $item->campaign_product_names = Product::whereIn('id', $productIds)
                                    ->pluck('name')
                                    ->toArray();
                                
                                // Fetch category names
                                $item->campaign_category_names = Category::whereIn('id', $categoryIds)
                                    ->pluck('name')
                                    ->toArray();
                                
                                $item->campaign_product_ids = $productIds;
                                $item->campaign_category_ids = $categoryIds;
                                $item->occurence_weekly_options = $item->occurence_weekly_options ? json_decode($item->occurence_weekly_options, true) : [];
                                unset($item->front_image, $item->back_image); 
                                return $item;
                            });

            return response()->json([
                'success' => true,
                'result' => $couponsList
            ], 200);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'errorMessage' => $e->getMessage()
            ], 200);
        }
    }


    public function verify_coupon(Request $request) {

        $user_data = $request->only('business_location_id', 'token', 'business_id','user_id', 'coupon_code', 'location_id');

        if(isset($user_data['token']))
        {    
            $result = User::checkUserToken($user_data['token'], $user_data['user_id']);

            if($result)
            {
                try {
                    $currentDate = Carbon::now();
                    $location_id = intval($user_data['location_id']);

                    $coupon = Campaign::join('couponsystems', 'campaigns.coupon_id', '=', 'couponsystems.id')
                                            ->where('campaigns.business_id', $user_data['business_id'])
                                            ->whereJsonContains('campaigns.location_id', strval($location_id))
                                            ->whereRaw('LOWER(couponsystems.coupon_code) = ?', [strtolower($user_data['coupon_code'])])
                                            ->whereDate('campaigns.start_date', '<=', $currentDate)
                                            ->whereDate('couponsystems.start_date', '<=', $currentDate)
                                            ->whereDate('couponsystems.end_date', '>=', $currentDate)
                                            ->select(
                                                'campaigns.id as campaign_id',
                                                'campaigns.name as campaign_name',
                                                'coupon_api',
                                                'campaign_type',
                                                'target_type',
                                                'campaign_product_ids',
                                                'campaign_category_ids',
                                                'campaigns.start_date as campaign_start_date',
                                                'campaigns.end_date as campaign_end_date',
                                                'couponsystems.*' 
                                            )
                                            ->first();

                    if(!empty($coupon)) {

                        $coupon->campaign_product_ids = $coupon->campaign_product_ids ? json_decode($coupon->campaign_product_ids, true) : [];
                        $coupon->campaign_category_ids = $coupon->campaign_category_ids ? json_decode($coupon->campaign_category_ids, true) : [];
                        $coupon->occurence_weekly_options = $coupon->occurence_weekly_options ? json_decode($coupon->occurence_weekly_options, true) : [];

                        unset($coupon->front_image, $coupon->back_image);

                        return response()->json(['success' => true, 'msg' => "Coupon successfully verified", 'result' => $coupon], 200);
                    } 

                    return response()->json(['success' => false, 'msg' => "Coupon code not found", 'result' => null], 200);

                } catch (\Exception $e) {
                    return response()->json([
                        'success' => false,
                        'errorMessage' => 'Error retrieving coupons'
                    ], 200);
                }
            }else{
                return["errorMessage"=>'Invalid token.'];
            }

        }else{
            return["errorMessage"=>'Invalid token.'];
        }
    }

}