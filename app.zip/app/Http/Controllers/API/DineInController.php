<?php

namespace App\Http\Controllers\API;

//use DB;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Carbon\Carbon;
use App\BusinessLocation;
use App\User;
use App\Restaurant\Booking;
use App\CashRegister;
use App\Product;
use App\Category;
use App\TaxRate;
use App\Variation;
use App\Contact;
use App\Transaction;
use App\TransactionSellLine;
use App\PosResTables;
use App\TableQrToken;
use App\TableReservation;
use App\Restaurant\ResTable;
use App\Restaurant\ResFloorPlan;
use App\Utils\ProductUtil;
use App\Utils\TransactionUtil;
use App\Utils\CashRegisterUtil;
use App\Utils\ContactUtil;
use App\Utils\BusinessUtil;
use Illuminate\Support\Facades\DB;
use App\ManagePosDevice;
use GuzzleHttp\Client;
use Illuminate\Support\Facades\Validator;
use Config;
use App\Queue\QueueTable;
use App\Utils\Util;

class DineInController extends Controller
{   
    /**
     * All Utils instance.
     *
     */
    protected $contactUtil;
    protected $productUtil;
    protected $transactionUtil;
    protected $cashRegisterUtil;
    protected $businessUtil;
    protected $util;
    
    /**
     * Constructor
     *
     * @param ProductUtils $product
     * @return void
     */
    public function __construct(
        ContactUtil $contactUtil,
        ProductUtil $productUtil,
        TransactionUtil $transactionUtil,
        CashRegisterUtil $cashRegisterUtil,
        BusinessUtil $businessUtil,
        Util $util
    ) {
        $this->contactUtil = $contactUtil;
        $this->productUtil = $productUtil;
        $this->transactionUtil = $transactionUtil;
        $this->cashRegisterUtil = $cashRegisterUtil;
        $this->businessUtil = $businessUtil;
        $this->util = $util;
        $this->dummyPaymentLine = ['method' => 'cash', 'amount' => 0, 'note' => '', 'card_transaction_number' => '', 'card_number' => '', 'card_type' => '', 'card_holder_name' => '', 'card_month' => '', 'card_year' => '', 'card_security' => '', 'cheque_number' => '', 'bank_account_number' => '',
        'is_return' => 0, 'transaction_no' => ''];
    }

    public function get_all_location_table_old(Request $request)
    {
        $user_data = $request->only('token','user_id','business_location_id');

        if(isset($user_data['token']))
        {
            $result = User::checkUserToken($user_data['token'], $user_data['user_id']);

            if( Config::get('constants.setBusinessTime') ) {
                $today = date('Y-m-d') . Config::get('constants.businessStartTime');
                $tomorrow = date('Y-m-d', strtotime(' +1 day')) . Config::get('constants.businessEndTime');
            } else {
                $today = date('Y-m-d') . Config::get('constants.businessStartTimeDefault');
                $tomorrow = date('Y-m-d') . Config::get('constants.businessEndTimeDefault');
            }
            
            if($result)
            {
                $result = array();

                $floor_plan = ResFloorPlan::where('res_floor_plan.location_id', $user_data['business_location_id'])
                                        ->select('res_floor_plan.id', 'res_floor_plan.name')
                                        ->get()
                                        ->toArray();
                                        
                try {
                        $all_location_table = ResTable::leftjoin('pos_res_tables', function ($leftjoin) use ($today, $tomorrow) {
                                                        $leftjoin->on('res_tables.id', '=', 'pos_res_tables.res_table_id')
                                                             ->where('pos_res_tables.seated', '=', 1)
                                                             //->whereBetween('pos_res_tables.created_at', [$today, $tomorrow]);
                                                             ->whereDate('pos_res_tables.created_at','>=', Carbon::today());
                                                    })
                                                  ->leftjoin('transactions', 'transactions.id','=','pos_res_tables.transaction_id')
                                                  //->leftjoin('transaction_sell_lines', 'transaction_sell_lines.transaction_id','=','transactions.id')
                                                  ->select('res_tables.id', 
                                                           'res_tables.name', 
                                                           'res_tables.location', 
                                                           'res_tables.description', 
                                                           'pos_res_tables.seated', 
                                                           'pos_res_tables.pax',
                                                           'pos_res_tables.transaction_id',
                                                           'transactions.status',
                                                           'transactions.pending_order'
                                                           )
                                                  ->where('res_tables.location_id', $user_data['business_location_id'])
                                                  //->groupBy('transactions.id')
                                                  ->get()
                                                  ->toArray();

                    if(count($all_location_table)<=0) {
                        $all_location_table = ["errorMessage"=>'Table not found.'];
                    }
                } catch(\Exception $e) {
                    dd($e->getMessage());
                    $all_location_table = ["errorMessage"=>'Table not found.'];
                }

                if(isset($all_location_table['errorMessage'])?false:true) {

                    $table_records = PosResTables::join('res_tables', 'res_tables.id', '=', 'pos_res_tables.res_table_id')
                                                ->select('pos_res_tables.*','res_tables.name')
                                                 ->leftjoin('transactions', 'transactions.id','=','pos_res_tables.transaction_id')
                                                ->select('pos_res_tables.*','res_tables.name','transactions.status')
                                                ->where('res_tables.location_id', $user_data['business_location_id'])
                                                //->whereBetween('pos_res_tables.created_at', [$today, $tomorrow])
                                                ->whereDate('pos_res_tables.created_at','>=', Carbon::today())
                                                //->whereBetween('pos_res_tables.created_at', [Carbon::today()->addHours(21), Carbon::tomorrow()->startOfDay()->addHours(5)->addMinutes(59)->addSeconds(59)])
                                                ->get()
                                                ->toArray();
                    $total_seat = count($all_location_table);
                    $seat_available = 0;
                    $seat_occupied = 0;

                    for($i=0; $i<$total_seat; $i++) {
                        if($all_location_table[$i]['seated'] == 1) {
                            $seat_occupied++;
                        }

                        if($all_location_table[$i]['seated'] == null) {
                            $seat_available++;
                        }

                        if($all_location_table[$i]['transaction_id'] != null) {
                            $total_serve_later_quantity = 0;
                            $sell_line = TransactionSellLine::where('transaction_id', $all_location_table[$i]['transaction_id'])
                                        ->get()
                                        ->toArray();
                            for($a=0; $a<count($sell_line); $a++) {
                                $total_serve_later_quantity += $sell_line[$a]["serve_later_quantity"];
                            }
                        } else {
                            $total_serve_later_quantity = 0;
                        }
                        $all_location_table[$i]['total_serve_later_quantity'] = $total_serve_later_quantity;

                        $table_arr = [];
                        $table_name = [];
                        //$pax = '';

                        $table_query = Transaction::leftjoin('pos_res_tables as t', 't.transaction_id', '=', 'transactions.id')
                                            ->leftjoin('res_tables as z', 'z.id', '=', 't.res_table_id')
                                            ->where('transactions.id', $all_location_table[$i]['transaction_id'])
                                            ->where('t.seated', '=', 1)
                                            ->select('t.res_table_id', 'pax', 'z.name')
                                            ->get();

                        if (!empty($table_query)){
                            foreach ($table_query as $key => $tableValue) {
                                if($tableValue['res_table_id'] != null)
                                {
                                    array_push($table_arr, $tableValue['res_table_id']);
                                    array_push($table_name, $tableValue['name']);
                                    //$pax = $tableValue['pax'];
                                }
                            }
                        }

                        $all_location_table[$i]['mergedTables'] = $table_name;
                    }

                    $result[] = [
                        'seat_available' => $seat_available,
                        'seat_occupied' => $seat_occupied,
                        'floor_plan' => $floor_plan,
                        'tables' => $all_location_table,
                        'record' => $table_records
                    ];
                }
                else {
                    $result = ["errorMessage"=>'Table not found.'];
                }

                return $this->respond($result);
            }
            else
            {
                return["errorMessage"=>'Invalid token.'];
            }
        }
        else
        {
            return["errorMessage"=>'Invalid token.'];
        }
    }
    
    public function get_all_location_table(Request $request)
    {
        $user_data = $request->only('token','user_id','business_location_id', 'current_time', 'current_date');

        if(isset($user_data['token']))
        {
            $businessLocation = BusinessLocation::find($user_data["business_location_id"]);
            if( !empty($businessLocation) && !empty($businessLocation->day_start_time) ) {
                $daystartTime = $businessLocation->day_start_time;
                $dayStartTime = $daystartTime.":00:00";
                $dayendTime = $daystartTime - 1;
                $dayEndTime = $dayendTime.":59:59";
            } else {
                $dayStartTime = str_replace(' ', '', Config::get('constants.businessStartTimeDefault'));
                $dayEndTime = str_replace(' ', '', Config::get('constants.businessEndTimeDefault'));
            }
            
            $result = User::checkUserToken($user_data['token'], $user_data['user_id']);
            
            $current_time = null;
            if( isset($user_data["current_time"]) && $user_data["current_time"] ) {
                $current_time = $user_data["current_time"];
            }
            
            $current_date = null;
            if( isset($user_data["current_date"]) && $user_data["current_date"] ) {
                $current_date = $user_data["current_date"];
            }
    
            /*
            if( Config::get('constants.setBusinessTime') ) {
                $today = date('Y-m-d') . Config::get('constants.businessStartTime');
                $tomorrow = date('Y-m-d', strtotime(' +1 day')) . Config::get('constants.businessEndTime');
            } else {
                $today = date('Y-m-d') . Config::get('constants.businessStartTimeDefault');
                $tomorrow = date('Y-m-d') . Config::get('constants.businessEndTimeDefault');
            }
            */
            // $set_time = false;
            // if ($current_time === null && $current_date === null) {
            //     $set_time = true;
            // }

            if( Config::get('constants.setBusinessTime') && !empty($businessLocation) && !empty($businessLocation->day_start_time) && !empty($current_time) && !empty($current_date) ) {
                $morning6TimeStamp = strtotime($current_date . $dayEndTime);
                $dateTimeStamp = strtotime($current_date . " " . $current_time);
                if( $dateTimeStamp >= $morning6TimeStamp ) {
                    $today = $current_date .' '.$dayStartTime;
                    $tomorrow = date('Y-m-d', strtotime($current_date .' +1 day')) .' '.$dayEndTime;
                } else {
                    $today = date('Y-m-d', strtotime($current_date .' -1 day')) .' '.$dayStartTime;
                    $tomorrow = $current_date.' '.$dayEndTime;
                }
            } else {
                $today = Carbon::today()->format('Y-m-d') . Config::get('constants.businessStartTimeDefault');
                $tomorrow = Carbon::today()->format('Y-m-d') . Config::get('constants.businessEndTimeDefault');
            }

            // dd( $today, $tomorrow );
            
            if($result)
            {
                $result = array();

                $floor_plan = ResFloorPlan::where('res_floor_plan.location_id', $user_data['business_location_id'])
                                        ->select('res_floor_plan.id', 'res_floor_plan.name')
                                        ->get()
                                        ->toArray();

                $reservations = Booking::where('bookings.location_id', $user_data['business_location_id'])
                                        ->leftJoin('res_tables', 'bookings.table_id', '=', 'res_tables.id')
                                        ->select([
                                            'bookings.*',  
                                            'res_tables.name as table_name'
                                        ])      
                                        ->whereBetween('bookings.booking_start', [$today, $tomorrow])
                                        ->get();
                
                $reservationCount = count($reservations);

                $booked_tables = Booking::where('location_id', $user_data['business_location_id'])
                                        ->whereBetween('booking_start', [$today, $tomorrow])
                                        ->pluck('table_id')
                                        ->toArray();

                try {
                    $all_location_table_parent = ResTable::leftJoin('pos_res_tables', function ($leftjoin) use ($today, $tomorrow) {
                                            $leftjoin->on('res_tables.id', '=', 'pos_res_tables.res_table_id')
                                                ->where('pos_res_tables.seated', '=', 1)
                                                ->whereBetween('pos_res_tables.created_at', [$today, $tomorrow]);
                                            // if ($set_time) {
                                            //     $leftjoin->whereDate('pos_res_tables.created_at', Carbon::today());
                                            // } else {
                                            //     $leftjoin->whereBetween('pos_res_tables.created_at', [$today, $tomorrow]);
                                            // }
                                        })
                                        ->leftJoin('transactions', 'transactions.id', '=', 'pos_res_tables.transaction_id')
                                        ->select('res_tables.id', 
                                                    'res_tables.name', 
                                                    'res_tables.location', 
                                                    'res_tables.description',
                                                    'res_tables.parent_table_id',
                                                    'pos_res_tables.seated', 
                                                    'pos_res_tables.pax',
                                                    'pos_res_tables.transaction_id',
                                                    'transactions.status',
                                                    'transactions.pending_order'
                                        )
                                        ->where('res_tables.location_id', $user_data['business_location_id'])
                                        // ->orderBy('res_tables.name')
                                        ->whereNull('res_tables.parent_table_id')
                                        ->get()
                                        ->toArray();

                    $all_location_table = [];
                    if( count($all_location_table_parent) > 0 ) {
                        foreach ($all_location_table_parent as $key => $res_table_parent) {

                            $tableQrToken = TableQrToken::where('table_id', $res_table_parent["id"])
                                    ->where('location_id', $user_data['business_location_id'])
                                    ->where('table_qr_tokens.expired_at', '>=', \Carbon::now()->format('Y-m-d H:i:s'))
                                    ->orderBy('id', 'DESC')
                                    ->first();
                            $res_table_parent["has_qr_token"] = false;
                            $res_table_parent["qr_token"] = null;
                            if( $tableQrToken && !empty($tableQrToken) ) {
                                $res_table_parent["has_qr_token"] = true;
                                $res_table_parent["qr_token"] = $tableQrToken->qr_token;
                            }

                            $res_table_parent["reserved"] = in_array($res_table_parent["id"], $booked_tables);

                            $all_location_table[] = $res_table_parent;
                            $all_location_table_child = ResTable::leftJoin('pos_res_tables', function ($leftjoin) use ($today, $tomorrow) {
                                                            $leftjoin->on('res_tables.id', '=', 'pos_res_tables.res_table_id')
                                                                ->where('pos_res_tables.seated', '=', 1)
                                                                ->whereBetween('pos_res_tables.created_at', [$today, $tomorrow]);
                                                            // if ($set_time) {
                                                            //     $leftjoin->whereDate('pos_res_tables.created_at', Carbon::today());
                                                            // } else {
                                                            //     $leftjoin->whereBetween('pos_res_tables.created_at', [$today, $tomorrow]);
                                                            // }
                                                        })
                                                        ->leftJoin('transactions', 'transactions.id', '=', 'pos_res_tables.transaction_id')
                                                        ->select('res_tables.id', 
                                                                    'res_tables.name', 
                                                                    'res_tables.location', 
                                                                    'res_tables.description',
                                                                    'res_tables.parent_table_id',
                                                                    'pos_res_tables.seated', 
                                                                    'pos_res_tables.pax',
                                                                    'pos_res_tables.transaction_id',
                                                                    'transactions.status',
                                                                    'transactions.pending_order'
                                                        )
                                                        ->where('res_tables.location_id', $user_data['business_location_id'])
                                                        ->where('res_tables.parent_table_id', $res_table_parent["id"])
                                                        // ->orderBy('res_tables.name')
                                                        ->whereNotNull('res_tables.parent_table_id')
                                                        ->get()
                                                        ->toArray();
                            
                            foreach ($all_location_table_child as &$child_table) {
                                $child_table["reserved"] = in_array($child_table["id"], $booked_tables);
                            }

                            if( count($all_location_table_child) > 0 ) {
                                $all_location_table = array_merge($all_location_table, $all_location_table_child);
                            }
                        }
                    } else {
                        $all_location_table = ["errorMessage"=>'Table not found.'];
                    }

                    // if(count($all_location_table_original)<=0) {
                    //     $all_location_table = ["errorMessage"=>'Table not found.'];
                    // }
                } catch(\Exception $e) {
                    dd($e->getMessage());
                    $all_location_table = ["errorMessage"=>'Table not found.'];
                }

                if(isset($all_location_table['errorMessage'])?false:true) {

                    $table_records = PosResTables::join('res_tables', 'res_tables.id', '=', 'pos_res_tables.res_table_id')
                                                ->select('pos_res_tables.*','res_tables.name')
                                                 ->leftjoin('transactions', 'transactions.id','=','pos_res_tables.transaction_id')
                                                ->select('pos_res_tables.*','res_tables.name','transactions.status')
                                                ->where('res_tables.location_id', $user_data['business_location_id'])
                                                ->whereBetween('pos_res_tables.created_at', [$today, $tomorrow])
                                                //->whereDate('pos_res_tables.created_at','>=', Carbon::today())
                                                //->whereBetween('pos_res_tables.created_at', [Carbon::today()->addHours(21), Carbon::tomorrow()->startOfDay()->addHours(5)->addMinutes(59)->addSeconds(59)])
                                                ->get()
                                                ->toArray();

                    $total_seat = count($all_location_table);
                    
                    $seat_available = 0;
                    $seat_occupied = 0;
                    $child_seat_available = 0;

                    for($i=0; $i<$total_seat; $i++) {
                        
                        $queueTable = QueueTable::where('res_table_id', $all_location_table[$i]['id'])
                                                ->where('is_occupied', 1)
                                                ->orderby('id', 'DESC')
                                                ->first();
                        if( $queueTable && !empty($queueTable) ) {
                            $all_location_table[$i]['queue_assigned'] = true;
                        } else {
                            $all_location_table[$i]['queue_assigned'] = false;
                        }

                        if($all_location_table[$i]['seated'] == 1) {
                            $seat_occupied++;
                        }

                        if($all_location_table[$i]['seated'] == null) {
                            $seat_available++;
                        }

                        if($all_location_table[$i]['parent_table_id'] && $all_location_table[$i]['seated'] == 0) {
                            $child_seat_available ++;
                        }

                        if( $all_location_table[$i]['transaction_id'] == null && ((isset($all_location_table[$i]['has_qr_token']) && $all_location_table[$i]['has_qr_token']) || (isset($all_location_table[$i]['queue_assigned']) && $all_location_table[$i]['queue_assigned']))  ) {
                            $seat_occupied++;
                            $seat_available--;
                        }
                        
                        if($all_location_table[$i]['transaction_id'] != null) {
                            $total_serve_later_quantity = 0;
                            $sell_line = TransactionSellLine::where('transaction_id', $all_location_table[$i]['transaction_id'])
                                        ->get()
                                        ->toArray();
                            for($a=0; $a<count($sell_line); $a++) {
                                $total_serve_later_quantity += $sell_line[$a]["serve_later_quantity"];
                            }
                        } else {
                            $total_serve_later_quantity = 0;
                        }
                        $all_location_table[$i]['total_serve_later_quantity'] = $total_serve_later_quantity;

                        $table_arr = [];
                        $table_name = [];
                        //$pax = '';

                        $table_query = Transaction::leftjoin('pos_res_tables as t', 't.transaction_id', '=', 'transactions.id')
                                            ->leftjoin('res_tables as z', 'z.id', '=', 't.res_table_id')
                                            ->where('transactions.id', $all_location_table[$i]['transaction_id'])
                                            ->where('t.seated', '=', 1)
                                            ->select('t.res_table_id', 'pax', 'z.name', 't.is_parent')
                                            ->get();
                        
                       if (!empty($table_query)) {
                            foreach ($table_query as $key => $tableValue) {
                                if ($tableValue['res_table_id'] !== null) {
                                    // Check if the table is the parent table
                                    if ($tableValue['is_parent'] == 1) {
                                        // Prepend the parent table to ensure it's at index 0
                                        array_unshift($table_arr, $tableValue['res_table_id']);
                                        array_unshift($table_name, $tableValue['name']);
                                    } else {
                                        // Push non-parent tables to the end of the array
                                        array_push($table_arr, $tableValue['res_table_id']);
                                        array_push($table_name, $tableValue['name']);
                                    }
                                }
                            }
                        }
                        $all_location_table[$i]['mergedTables'] = $table_name;
                    }

                    $result[] = [
                        'seat_available' => $seat_available - $child_seat_available,
                        'child_seat_available' =>$child_seat_available,
                        'seat_occupied' => $seat_occupied,
                        'seat_reserved' => $reservationCount,
                        'floor_plan' => $floor_plan,
                        'tables' => $all_location_table,
                        'record' => $table_records,
                        'reservations' => $reservations,
                    ];
                }
                else {
                    $result = ["errorMessage"=>'Table not found.'];
                }

                return $this->respond($result);
            }
            else
            {
                return["errorMessage"=>'Invalid token.'];
            }
        }
        else
        {
            return["errorMessage"=>'Invalid token.'];
        }
    }

    function save_dine_in_order(Request $request)
    {
        $input = $request;
        if(isset($input['token']))
        { 
            $result = User::checkUserToken($input['token'], $input['user_id']);

            if($result)
            {
                $output = $this->saveDineInOrder($input);
                return $output;
            }
            else
            {
                return["errorMessage"=>'Invalid token.'];
            }
        }
        else
        {
            return["errorMessage"=>'Invalid token.'];
        }
    }

    public function saveDineInOrder($input)
    {
        $is_direct_sale = false;
        try {
            
            if (!empty($input['products'])) 
            {
                
                $business_id = $input['business_id'];
                $user_id = $input['user_id'];
                $contact_id = $input['contact_id'];
                $send_print_request = !empty($input['send_print_request']) ? $input['send_print_request'] : "";
                $business_location_id = !empty($input['business_location_id']) ? $input['business_location_id'] : "";
                $app_order_id = isset($input['app_order_id']) ? $input['app_order_id'] : "";
                $json_data = !empty($input['json_data']) ? $input['json_data'] : "";
                
                $businessLocation = BusinessLocation::find($business_location_id);
                if( !empty($businessLocation) && !empty($businessLocation->day_start_time) ) {
                    $daystartTime = $businessLocation->day_start_time;
                    $dayStartTime = $daystartTime.":00:00";
                    $dayendTime = $daystartTime - 1;
                    $dayEndTime = $dayendTime.":59:59";
                }  else {
                    $dayStartTime = str_replace(' ', '', Config::get('constants.businessStartTimeDefault'));
                    $dayEndTime = str_replace(' ', '', Config::get('constants.businessEndTimeDefault'));
                }
                
                //$invoice_resp = "";
                // $app_item_line_id = isset($input['products'][0]['app_item_line_id']) ? $input['products'][0]['app_item_line_id'] : "";
                
                // if(!empty ($input['products'][0]['app_item_line_id'])) {
                //     $app_item_line_id = array_column($input['products'], 'app_item_line_id');    
                // } else {
                //     $app_item_line_id = "";    
                // }
                
                if(!empty ($input['products'][0]['modifier_app_ids'])) {
                    $modifiers_app_ids = array_column($input['products'], 'modifier_app_ids');    
                } else {
                    $modifiers_app_ids = "";    
                }
                
                $discount = ['discount_type' => $input['discount_type'],
                            'discount_amount' => $input['discount_amount']
                        ];

                $invoice_total = $this->productUtil->newCalculateInvoiceTotal($input['products'], $input['tax_rate_id'], $discount, $input['service_charges']);
                
                if(!empty($input['payment'])){
                    $payment_gateway_response = !empty($input['payment'][0]['payment_gateway_response']) ? $input['payment'][0]['payment_gateway_response'] : "";
                } else {
                    $payment_gateway_response = '';
                }
                DB::beginTransaction();
                        
                if (empty($input['transaction_date'])) {
                    $input['transaction_date'] =  \Carbon::now();
                } else {
                    $input['transaction_date'] = $this->productUtil->uf_date($input['transaction_date'], true);
                }

                $input['is_suspend'] = isset($input['is_suspend']) && 1 == $input['is_suspend']  ? 1 : 0;
                if ($input['is_suspend']) {
                    $input['sale_note'] = !empty($input['additional_notes']) ? $input['additional_notes'] : null;
                }
                
                $current_time = null;
                if( isset($user_data["current_time"]) && $user_data["current_time"] ) {
                    $current_time = $user_data["current_time"];
                }
                
                $current_date = null;
                if( isset($user_data["current_date"]) && $user_data["current_date"] ) {
                    $current_date = $user_data["current_date"];
                }
                
                if( Config::get('constants.setBusinessTime') && !empty($businessLocation) && !empty($businessLocation->day_start_time) && !empty($current_time) && !empty($current_date) ) {
                    $morning6TimeStamp = strtotime($current_date . " " . $dayEndTime);
                    $dateTimeStamp = strtotime($current_date . " " . $current_time);
                    if( $dateTimeStamp >= $morning6TimeStamp ) {
                        $today = $current_date . ' ' .$dayStartTime;
                        $tomorrow = date('Y-m-d', strtotime($current_date .' +1 day')) . ' ' .$dayEndTime;
                    } else {
                        $today = date('Y-m-d', strtotime($current_date .' -1 day')) . ' ' .$dayStartTime;
                        $tomorrow = $current_date .' '.$dayEndTime;
                    }
                } else {
                    $today = Carbon::today()->format('Y-m-d') . Config::get('constants.businessStartTimeDefault');
                    $tomorrow = Carbon::today()->format('Y-m-d') . Config::get('constants.businessEndTimeDefault');
                }
                
                // if( Config::get('constants.setBusinessTime') && !empty($businessLocation) && !empty($businessLocation->day_start_time) ) {
                //     $today = date('Y-m-d') .' '.$dayStartTime;
                //     $tomorrow = date('Y-m-d', strtotime(' +1 day')) .' '.$dayEndTime;
                // } else {
                //     $today = date('Y-m-d') . Config::get('constants.businessStartTimeDefault');
                //     $tomorrow = date('Y-m-d') . Config::get('constants.businessEndTimeDefault');
                // }
                // dd($today, $tomorrow);

                $posResTable = null;
                if( isset($input["res_table_id"]) && $input["res_table_id"] && count($input["res_table_id"]) ) {
                    foreach ($input["res_table_id"] as $res_table_id) {
                        
                        // $posResTable = PosResTables::leftJoin('transactions', function($join) {
                        //                             $join->on('transactions.app_order_id','=','pos_res_tables.app_order_id')
                        //                                  ->orWhere(function($query) {
                        //                                     $query->whereNull('pos_res_tables.app_order_id')
                        //                                               ->whereColumn('transactions.id', '=', 'pos_res_tables.transaction_id');
                        //                                      });
                        //                             })
                        //                     ->where('pos_res_tables.res_table_id', '=', $res_table_id)
                        //                             ->where('pos_res_tables.seated', '=', 1)
                        //                     ->whereBetween('pos_res_tables.created_at', [$today, $tomorrow])
                        //                     //->whereDate('pos_res_tables.created_at','>=', Carbon::today())
                        //                             ->first();
                        //    }
                    
                        $posResTable = PosResTables::leftjoin('transactions', function($join) {
                                                        $join->on('transactions.id', '=', 'pos_res_tables.transaction_id')
                                                            ->orWhere(function($query) {
                                                                $query->whereNull('transactions.id')
                                                                    ->whereColumn('pos_res_tables.app_order_id', '=', 'transactions.app_order_id');
                                                            });
                                                    })
                                                    ->where('pos_res_tables.res_table_id', '=', $res_table_id)
                                                    ->where('pos_res_tables.seated', '=', 1)
                                                    ->whereBetween('pos_res_tables.created_at', [$today, $tomorrow])
                                                    ->lockForUpdate()
                                                    ->first();
                    }
                }

                if($posResTable){
                    $output = [
                        'status' => 'failed',
                        'msg' => 'Table is occupied.',
                    ];
                    return $output;
                  
                    $transaction = Transaction::where(function ($query) use ($posResTable) {
                                        $query->where('app_order_id', $posResTable['app_order_id'])
                                              ->orWhere(function ($query) use ($posResTable) {
                                                  $query->whereNull('app_order_id')
                                                        ->where('id', $posResTable['transaction_id']);
                                              });
                                        })->first();
                                    
                    
                    if($transaction){
                        //duplicate table
                        $business_details = $this->businessUtil->getDetails($business_id);
                        if (in_array("modifiers", $business_details->enabled_modules)) {
                            $isModuleEnabled = true;
                        } else {
                            $isModuleEnabled = false;
                        }
                        
                        $this->transactionUtil->createOrUpdateSellLines2($transaction, $input['products'], $input['location_id'], $app_order_id, $modifiers_app_ids, $user_id, false, null, [], true, $isModuleEnabled);
                        
                        //$this->transactionUtil->updateTransactionInvoice($transaction->id, $invoice_total, $business_id);
    
                        // if (!$is_direct_sale) {
                        //     //Add change return
                        //     $change_return = $this->dummyPaymentLine;
                        //     $change_return['amount'] = $input['change_return'];
                        //     $change_return['is_return'] = 1;
                        //     $input['payment'][] = $change_return;
                        // }
    
                        $is_credit_sale = isset($input['is_credit_sale']) && $input['is_credit_sale'] == 1 ? true : false;
                        //transaction_payments table
                        if (!$transaction->is_suspend && !empty($input['payment']) && !$is_credit_sale) {
                            $this->transactionUtil->createOrUpdatePaymentLines($transaction, $input['payment'], $app_order_id, $business_id, $user_id);
                        }
    
                        //update product stock
                        foreach ($input['products'] as $product) {
                            $decrease_qty = $this->productUtil
                                        ->num_uf($product['quantity']);
                            if (!empty($product['base_unit_multiplier'])) {
                                $decrease_qty = $decrease_qty * $product['base_unit_multiplier'];
                            }
    
                            if ($product['enable_stock']) {
                                $this->productUtil->decreaseProductQuantity(
                                    $product['product_id'],
                                    $product['variation_id'],
                                    $input['location_id'],
                                    $decrease_qty
                                );
                            }
    
                            if ($product['product_type'] == 'combo') {
                                //Decrease quantity of combo as well.
                                $this->productUtil
                                    ->decreaseProductQuantityCombo(
                                        $product['combo'],
                                        $input['location_id']
                                    );
                            }
                        }
    
                        //Check for final and do some processing.
                        if ($input['status'] == 'final') {
                            //Add payments to Cash Register
                            
                            if (!$is_direct_sale && !$transaction->is_suspend && !empty($input['payment']) && !$is_credit_sale) {
                                //cash_register_transactions table
                                $this->cashRegisterUtil->addSellPayments($transaction, $input['payment'], $input['user_id'], $app_order_id);
                            }
    
                            //Check and update reward point
                            if ($business_details->enable_rp == 1) {
                                $redeemed = !empty($input['rp_redeemed']) ? $input['rp_redeemed'] : 0;
                                $this->transactionUtil->updateCustomerRewardPoints($contact_id, $transaction->rp_earned, 0, $redeemed);
                            }
                        }
                        //Update payment status
                        $payment_status = $this->transactionUtil->updatePaymentStatus($transaction->id, $transaction->final_total,$app_order_id);
    
                        $transaction->payment_status = $payment_status;
                    }
                }else{
                    
                    //transactions table
                    $transaction = $this->transactionUtil->createSellTransaction($business_id, $input, $invoice_total, $user_id);
                    
                    if(!empty($transaction->invoice_no)) {
                        $invoice_resp = $transaction->invoice_no;
                    } else {
                        $invoice_resp = "";
                    }
                    
                    if(!empty($transaction->order_check_no)) {
                        $order_check_no = $transaction->order_check_no;
                    } else {
                        $order_check_no = "";
                    }

                    if(!empty($transaction->id)) {
                        $transactionId = $transaction->id;
                    } else {
                        $transactionId = "";
                    }
                    
                    //pos_res_tables
                    
                    $pos_res_tables = $this->transactionUtil->createPosResTable($transaction, $input, $app_order_id);
                    //transaction_sell_lines table

                    $business_details = $this->businessUtil->getDetails($business_id);
                    if (in_array("modifiers", $business_details->enabled_modules)) {
                        $isModuleEnabled = true;
                    } else {
                        $isModuleEnabled = false;
                    }
                    $this->transactionUtil->createOrUpdateSellLines($transaction, $input['products'], $input['location_id'], $app_order_id, $modifiers_app_ids, $user_id, false, null, [], true, $isModuleEnabled);

                    // if (!$is_direct_sale) {
                    //     //Add change return
                    //     $change_return = $this->dummyPaymentLine;
                    //     $change_return['amount'] = $input['change_return'];
                    //     $change_return['is_return'] = 1;
                    //     $input['payment'][] = $change_return;
                    // }

                    $is_credit_sale = isset($input['is_credit_sale']) && $input['is_credit_sale'] == 1 ? true : false;
                    //transaction_payments table
                    if (!$transaction->is_suspend && !empty($input['payment']) && !$is_credit_sale) {
                        $this->transactionUtil->createOrUpdatePaymentLines($transaction, $input['payment'], $app_order_id, $business_id, $user_id );
                    }

                    //update product stock
                    foreach ($input['products'] as $product) {
                        $decrease_qty = $this->productUtil
                                    ->num_uf($product['quantity']);
                        if (!empty($product['base_unit_multiplier'])) {
                            $decrease_qty = $decrease_qty * $product['base_unit_multiplier'];
                        }

                        if ($product['enable_stock']) {
                            $this->productUtil->decreaseProductQuantity(
                                $product['product_id'],
                                $product['variation_id'],
                                $input['location_id'],
                                $decrease_qty
                            );
                        }

                        if ($product['product_type'] == 'combo') {
                            //Decrease quantity of combo as well.
                            $this->productUtil
                                ->decreaseProductQuantityCombo(
                                    $product['combo'],
                                    $input['location_id']
                                );
                        }
                    }

                    //Check for final and do some processing.
                    if ($input['status'] == 'final') {
                        //Add payments to Cash Register
                        if (!$is_direct_sale && !$transaction->is_suspend && !empty($input['payment']) && !$is_credit_sale) {
                            //cash_register_transactions table
                            $sell_payments = $this->cashRegisterUtil->addSellPayments($transaction, $input['payment'], $input['user_id']);
                            if($sell_payments == false) {
                                return response()->json(['status' => 'failed', 'msg' => 'Currently no cash registers are available, please reset your device' ]);    
                            }
                        }

                        //Check and update reward point
                        if ($business_details->enable_rp == 1) {
                            $redeemed = !empty($input['rp_redeemed']) ? $input['rp_redeemed'] : 0;
                            $this->transactionUtil->updateCustomerRewardPoints($contact_id, $transaction->rp_earned, 0, $redeemed);
                        }

                        $is_nfc_payment = !empty($input['is_nfc_payment']) ? true : false;

                        // if($is_nfc_payment === true) {
                        $debitOrder = $this->transactionUtil->debitOrderBalance($input);
                        if($debitOrder == false) {
                            return response()->json(['errorMessage' => 'Insufficient NFC Card Balance.'], 200);
                        }

                        $credit_transaction = $this->transactionUtil->debitOrderBalanceFromCredit($input, $transaction->id);
                        if($credit_transaction == false) {
                            return response()->json(['errorMessage' => 'Insufficient Credit Balance.'], 200);
                        }

                    	// }
                    }
                    //Update payment status
                    $payment_status = $this->transactionUtil->updatePaymentStatus($transaction->id, $transaction->final_total);

                    $transaction->payment_status = $payment_status;
                    
                    if($input['status'] == 'final') {
                        if(!empty($input['qr_token'])) {
                            $expired_at = \Carbon::now()->format('Y-m-d H:i:s');
                            $create_qr_token = [
                                'expired_at' => $expired_at
                            ];
                    
                            $qrTokenRecord = TableQrToken::where('qr_token', $input['qr_token'])->first();
                    
                            if ($qrTokenRecord) {
                                $qrTokenRecord->update($create_qr_token);
                            }
                        }
                    }
                      
                    if($send_print_request == true){
                    // $transaction_id = $request->input('transaction_id');
                    // $status = $request->input('status');
                       $device_id = !empty($input['device_id']) ? $input['device_id'] : "";
                    //$receipt_type = $request->input('receipt_type');
                    //$user_id = $request->input('user_id');
                    //$business_id = $request->input('business_id');
                    //$location_id = $request->input('location_id');
                    //$business_location_id = $request->input('business_location_id');
            
                    // Fetch the FCM token for the device ID
                    $device = ManagePosDevice::select('device_fcm_token', 'device_name')
                                                    // ->where('device_id', $device_id)
                                                    ->where('is_master', 1)
                                                    ->where('business_id', $business_id)
                                                    ->where('business_location_id', $business_location_id)
                                                    ->first();
                                                    
                    $device_sub = ManagePosDevice::select( 'device_name')
                                ->where('device_id', $device_id)
                                ->where('is_master', 0)
                                ->where('business_id', $business_id)
                                ->where('business_location_id', $business_location_id)
                                ->first();
                                
                    $device_sub_name = !empty($device_sub->device_name) ? $device_sub->device_name : "";
            
                    if ($device) {
                        $fcm_token = $device->device_fcm_token;
                        $device_name = $device->device_name;
                        // Now you can use $fcm_token and $device_name in your CURL request
                    } else {
                        // Handle device not found error
                    }
                    
                    if($transaction->payment_status == 'due'){
                        $payment_status = 'draft';
                    } else {
                        $payment_status = 'final';
                    }
                    
                    try {
                        // Send the POST request to FCM server
                        $client = new Client();
                        $response = $client->post('https://fcm.googleapis.com/fcm/send', [
                            'headers' => [
                                'Authorization' => 'key=AAAAC1EQ6G4:APA91bHjcZ8gLrFatBsh7ttZoe6VH07IFzS2UxvykIVYrg_ngrxpRngSYIoUnWy0QqCcL7IGC_n7hmKsQSk82jfhXzInUsPxUdrBIpMqLQbb8u5XYz40nik95DNokU1FBZ85w3lJ9B_y',
                                'Content-Type' => 'application/json',
                            ],
                            'json' => [
                                'to' => $fcm_token,
                                'data' => [
                                    'order_print_request' => [
                                        'transaction_id' => $transaction->id,
                                        'status' => $payment_status,
                                        'json_data' => $json_data,
                                        'from' => $device_sub_name,
                                        'receipt_type' => 'kitchen',
                                    ],
                                ],
                            ],
                        ]);
            
                        $responseBody = json_decode($response->getBody());
                        $statusCode = $response->getStatusCode();
            
                        // if($responseBody->success) {
                        //     return response()->json(['status' => 'success'], $statusCode);
                        // } else {
                        //     return response()->json(['status' => 'failed'], $statusCode);
                        // }
                    } catch (\Exception $e) {
                        // Handle the FCM request exception
                        return response()->json(['status' => 'failed', 'message' => 'FCM request failed with error: ' . $e->getMessage()], 500);
                    }
                }
                }    

                DB::commit();

                $output = [
                    'msg' => "Sale order is added.", 
                    'status' => 'success', 
                    'invoice_no' => !empty($invoice_resp) ? $invoice_resp : "",
                    'order_check_no' => $order_check_no,
                    'transaction_id' => $transactionId,
                    'order_status'   => $input['status']
                ];
            }
            else 
            {
                $output = [
                            'errorMessage' => trans("messages.something_went_wrong")
                        ];
            }
        } catch (\Exception $e) {
            DB::rollBack();
            \Log::emergency("File:" . $e->getFile(). "Line:" . $e->getLine(). "Message:" . $e->getMessage());

            $error_message = "File: " . $e->getFile(). " | Line: " . $e->getLine(). " | Message: " . $e->getMessage();
             if ($e->getCode() == 40001) {

                $output = [
                        'status' => 'failed',
                        'msg' => 'Table is occupied.'
                    ];
             }
             else{
                $this->util->sendErrorLogOnMSTeam($error_message);

                $msg = trans("messages.something_went_wrong");

                $output = [
                                'errorMessage' => $msg
                            ];
             }
            
        }
        return $output;
    }
	
	
    public function saveDineInOrder2($input)
    {
        $is_direct_sale = false;
        try {
            if (!empty($input['products'])) 
            {
                $business_id = $input['business_id'];
                $user_id = $input['user_id'];
                $contact_id = $input['contact_id'];

                $discount = ['discount_type' => $input['discount_type'],
                            'discount_amount' => $input['discount_amount']
                        ];
                $invoice_total = $this->productUtil->newCalculateInvoiceTotal($input['products'], $input['tax_rate_id'], $discount, $input['service_charges']);
                
                DB::beginTransaction();

                if (empty($input['transaction_date'])) {
                    $input['transaction_date'] =  \Carbon::now();
                } else {
                    $input['transaction_date'] = $this->productUtil->uf_date($input['transaction_date'], true);
                }

                $input['is_suspend'] = isset($input['is_suspend']) && 1 == $input['is_suspend']  ? 1 : 0;
                if ($input['is_suspend']) {
                    $input['sale_note'] = !empty($input['additional_notes']) ? $input['additional_notes'] : null;
                }
                //transactions table
                $transaction = $this->transactionUtil->createSellTransaction($business_id, $input, $invoice_total, $user_id);
                //pos_res_tables
                $pos_res_tables = $this->transactionUtil->createPosResTable($transaction, $input);
                //transaction_sell_lines table
                $business_details = $this->businessUtil->getDetails($business_id);
                if (in_array("modifiers", $business_details->enabled_modules)) {
                    $isModuleEnabled = true;
                } else {
                    $isModuleEnabled = false;
                }
                $this->transactionUtil->createOrUpdateSellLines($transaction, $input['products'], $input['location_id'], false, null, [], true, $isModuleEnabled);

                // if (!$is_direct_sale) {
                //     //Add change return
                //     $change_return = $this->dummyPaymentLine;
                //     $change_return['amount'] = $input['change_return'];
                //     $change_return['is_return'] = 1;
                //     $input['payment'][] = $change_return;
                // }

                $is_credit_sale = isset($input['is_credit_sale']) && $input['is_credit_sale'] == 1 ? true : false;
                //transaction_payments table
                if (!$transaction->is_suspend && !empty($input['payment']) && !$is_credit_sale) {
                    $this->transactionUtil->createOrUpdatePaymentLines($transaction, $input['payment'], $business_id, $user_id);
                }

                //update product stock
                foreach ($input['products'] as $product) {
                    $decrease_qty = $this->productUtil
                                ->num_uf($product['quantity']);
                    if (!empty($product['base_unit_multiplier'])) {
                        $decrease_qty = $decrease_qty * $product['base_unit_multiplier'];
                    }

                    if ($product['enable_stock']) {
                        $this->productUtil->decreaseProductQuantity(
                            $product['product_id'],
                            $product['variation_id'],
                            $input['location_id'],
                            $decrease_qty
                        );
                    }

                    if ($product['product_type'] == 'combo') {
                        //Decrease quantity of combo as well.
                        $this->productUtil
                            ->decreaseProductQuantityCombo(
                                $product['combo'],
                                $input['location_id']
                            );
                    }
                }

                //Check for final and do some processing.
                if ($input['status'] == 'final') {
                    //Add payments to Cash Register
                    if (!$is_direct_sale && !$transaction->is_suspend && !empty($input['payment']) && !$is_credit_sale) {
                        //cash_register_transactions table
                        $this->cashRegisterUtil->addSellPayments($transaction, $input['payment'], $input['user_id']);
                    }

                    //Check and update reward point
                    if ($business_details->enable_rp == 1) {
                        $redeemed = !empty($input['rp_redeemed']) ? $input['rp_redeemed'] : 0;
                        $this->transactionUtil->updateCustomerRewardPoints($contact_id, $transaction->rp_earned, 0, $redeemed);
                    }
                }
                //Update payment status
                $payment_status = $this->transactionUtil->updatePaymentStatus($transaction->id, $transaction->final_total);

                $transaction->payment_status = $payment_status;

                DB::commit();

                $output = ['msg' => "Sale order is added." ];
            }
            else 
            {
                $output = [
                            'errorMessage' => trans("messages.something_went_wrong")
                        ];
            }
        } catch (\Exception $e) {
            DB::rollBack();
            \Log::emergency("File:" . $e->getFile(). "Line:" . $e->getLine(). "Message:" . $e->getMessage());
            $msg = trans("messages.something_went_wrong");

            $output = [
                            'errorMessage' => $msg
                        ];
        }
        return $output;
    }

    function update_dine_in_order(Request $request)
    {
        $input = $request;
    
        if(isset($input['token']))
        { 
            $result = User::checkUserToken($input['token'], $input['user_id']);

            if($result)
            {
                try {
                    $output = $this->updateDineInOrder($input);
                } catch (\Exception $e) {
                    DB::rollBack();
                    \Log::emergency("File:" . $e->getFile(). "Line:" . $e->getLine(). "Message:" . $e->getMessage());
                    $msg = trans("messages.something_went_wrong");
        
                    $output = [
                                    'errorMessage' => $msg
                                ];
                }

                return $output;
            }
            else
            {
                return["errorMessage"=>'Invalid token.'];
            }
        }
        else
        {
            return["errorMessage"=>'Invalid token.'];
        }
    }

    public function updateDineInOrder($input)
    {
        try {
            $is_direct_sale = false;
            $isMoveTable = !empty($input['isMoveTable']) ? $input['isMoveTable'] : false;
            if (!empty($input['products'])) 
            {
                $id = $input['transaction_id'];
                $business_id = $input['business_id'];
                $user_id = $input['user_id'];
                $contact_id = $input['contact_id'];
                $delete_flag = $input['flag'];
                $pax = $input['pax'];
                $app_order_id = $input['app_order_id'];
                $app_item_line_id = isset($input['products'][0]['app_item_line_id']) ? $input['products'][0]['app_item_line_id'] : "";
                    
                if(!empty ($input['products'][0]['modifier_app_ids'])) {
                    $modifiers_app_ids = array_column($input['products'], 'modifier_app_ids');    
                } else {
                    $modifiers_app_ids = "";    
                }

                if(!empty($input['payment'])){
                    $payment_gateway_response = !empty($input['payment'][0]['payment_gateway_response']) ? $input['payment'][0]['payment_gateway_response'] : "";
                } else {
                    $payment_gateway_response = '';
                }
                    
                $discount = ['discount_type' => $input['discount_type'],
                            'discount_amount' => $input['discount_amount']
                        ];

                //$transaction_before = Transaction::find($id);
                $transaction_before = Transaction::where('id', $id)->first();
                
                $status_before =  $transaction_before->status;
            if($status_before !== 'final') {    
                
                $rp_earned_before = $transaction_before->rp_earned;
                $rp_redeemed_before = $transaction_before->rp_redeemed;
                
                $invoice_total = $this->productUtil->newCalculateInvoiceTotal($input['products'], $input['tax_rate_id'], $discount, $input['service_charges']);
                
                if (!empty($input['transaction_date'])) {
                    $input['transaction_date'] = $this->productUtil->uf_date($input['transaction_date'], true);
                }

                $input['is_suspend'] = isset($input['is_suspend']) && 1 == $input['is_suspend']  ? 1 : 0;
                if ($input['is_suspend']) {
                    $input['sale_note'] = !empty($input['additional_notes']) ? $input['additional_notes'] : null;
                }
                
                if($isMoveTable === true) {
                    $input['tag_number'] = $transaction_before->tag_number;
                }

                //Begin transaction
                DB::beginTransaction();

                $order_placed_by = (isset($input['order_placed_by']) && $input['order_placed_by']) ? $input['order_placed_by'] : 0;
                $contact_ids = (isset($transaction_before['contact_ids']) && $transaction_before['contact_ids']) ? explode(',', $transaction_before['contact_ids']) : [];
                if( $order_placed_by && !in_array($contact_id, $contact_ids) ) {
                    $contact_ids[] = $order_placed_by;
                }
                $input["contact_ids"] = implode(',', $contact_ids);
                
                $transaction = $this->transactionUtil->updateSellTransaction($id, $business_id, $input, $invoice_total, $user_id,$app_order_id);

                $pos_res_tables = $this->transactionUtil->updatePosResTable($transaction, $input, $app_order_id);

                
                if(!empty($transaction->invoice_no)) {
                    $invoice_resp = $transaction->invoice_no;
                } else {
                    $invoice_resp = "";
                }

                if(!empty($transaction->order_check_no)) {
                    $order_check_no = $transaction->order_check_no;
                } else {
                    $order_check_no = "";
                }

                //Update Sell lines
                $business_details = $this->businessUtil->getDetails($business_id);
                
                if (in_array("modifiers", $business_details->enabled_modules)) {
                    $isModuleEnabled = true;
                } else {
                    $isModuleEnabled = false;
                }

                if ( isset($input['void_item_ids']) && !empty($input['void_item_ids']) && $input['transaction_id'] && $input['transaction_id'] ) {
                    $this->void_items($input['void_item_ids'], $input['transaction_id'], $input['location_id']);
                }
                
                $deleted_lines = $this->transactionUtil->createOrUpdateSellLines($transaction, $input['products'], $input['location_id'],$app_order_id, $modifiers_app_ids, $user_id, true, $status_before, [], true, $isModuleEnabled);
                
                // 			if($delete_flag == true){
                                
                // 				$deleted_lines = $this->transactionUtil->createOrUpdateSellLines($transaction, $input['products'], $input['location_id'],$app_order_id, $modifiers_app_ids, $user_id, true, $status_before, [], true, $isModuleEnabled);
                // 			}else{
                // 				$deleted_lines = $this->transactionUtil->createOrUpdateSellLines2($transaction, $input['products'], $input['location_id'], $app_order_id, $modifiers_app_ids, $user_id, true, $status_before, [], true, $isModuleEnabled);
                // 			}
                
                // $previousTableDetails = PosResTables::where('seated', 1)
                //                                     ->where('transaction_id', $id)
                //                                     ->get()
                //                                     ->toArray();
                // echo "<pre>";
                // print_r($previousTableDetails);die;
                //Update update lines
                $is_credit_sale = isset($input['is_credit_sale']) && $input['is_credit_sale'] == 1 ? true : false;

                // $new_sales_order_ids = $transaction->sales_order_ids ?? [];
                // $sales_order_ids =array_unique(array_merge($sales_order_ids, $new_sales_order_ids));
        
                // if (!empty($sales_order_ids)) {
                //     $this->transactionUtil->updateSalesOrderStatus($sales_order_ids);
                // }
                
                if (!$is_direct_sale && !$transaction->is_suspend && !empty($input['payment']) && !$is_credit_sale) {
                    // //Add change return
                    // $change_return = $this->dummyPaymentLine;
                    // $change_return['amount'] = $input['change_return'];
                    // $change_return['is_return'] = 1;
                    // if (!empty($input['change_return_id'])) {
                    //     $change_return['id'] = $input['change_return_id'];
                    // }
                    // $input['payment'][] = $change_return;

                    $this->transactionUtil->createOrUpdatePaymentLines($transaction, $input['payment'], $app_order_id, $business_id, $user_id);

                    //Update cash register
                    $sell_payments = $this->cashRegisterUtil->updateSellPayments($status_before, $transaction, $input['payment'], $user_id,$app_order_id);
                    if($sell_payments == false) {
                        return response()->json(['status' => 'failed', 'msg' => 'Currently no cash registers are available, please reset your device' ]);    
                    }
                }

                //Check for final and do some processing.
                if ($input['status'] == 'final') {
                    //Check and update reward point
                    if ($business_details->enable_rp == 1) {

                        if($transaction->rp_redeemed == 0) {
                            $transaction->rp_redeemed = $input['rp_redeemed'];
                        }
                        $this->transactionUtil->updateCustomerRewardPoints($contact_id, $transaction->rp_earned, $rp_earned_before, $transaction->rp_redeemed, $rp_redeemed_before);

                    }

                    if( isset($input['res_table_id']) && count($input['res_table_id']) ) {
                        TableQrToken::where('business_id', $input['business_id'])
                                                    ->where('location_id', $input['business_location_id'])
                                                    ->whereIn('table_id', $input['res_table_id'])
                                                    ->update(['expired_at' => \Carbon::now()->format('Y-m-d H:i:s')]);
                    }
                    if($rp_redeemed_before > 0) {
                       if ($business_details->enable_rp == 1 ) {
                            $redeemed = !empty($input['rp_redeemed']) ? $input['rp_redeemed'] : 0;
                            // $this->transactionUtil->updateCustomerRewardPoints($contact_id, $transaction->rp_earned, 0, $redeemed);
                            $this->transactionUtil->updateCustomerRewardPoints($contact_id, 0, 0, $redeemed);
                        } 
                    }

                    $debitOrder = $this->transactionUtil->debitOrderBalance($input);
                    if($debitOrder == false) {
                        return response()->json(['errorMessage' => 'Insufficient NFC Card Balance.'], 200);
                    }
                    
                    $credit_transaction = $this->transactionUtil->debitOrderBalanceFromCredit($input, $transaction->id);
                    if($credit_transaction == false) {
                        return response()->json(['errorMessage' => 'Insufficient Credit Balance.'], 200);
                    }
                }
                
                //Update payment status
                $payment_status = $this->transactionUtil->updatePaymentStatus($transaction->id, $transaction->final_total);
                $transaction->payment_status = $payment_status;
                //return $this->productUtil->adjustProductStockForInvoice($status_before, $transaction, $input, true, $input);
                //Update product stock
                
                $this->productUtil->adjustProductStockForInvoice($status_before, $transaction, $input, true, $input);

                $not_printed_lines = TransactionSellLine::where('transaction_id', $transaction['id'])
                        ->where('printed', 0)
                        ->first();
    
                if (!empty($not_printed_lines)) {
                    Transaction::where('id', $transaction['id'])
                                    ->update(['pending_order' => 1]);
                }
                // PosResTables::where('app_order_id', $app_order_id)->update(['pax' => $pax]);
                PosResTables::where('transaction_id', $transaction['id'])->update(['pax' => $pax]);
                DB::commit();

                $output = [
                    'msg' => "Sale order is edited.", 
                    'invoice_no' => $invoice_resp , 
                    'order_check_no' => $order_check_no,
                    'transaction_id' => $id,
                    'status' => 'success',
                    'order_status' => $input['status']
                ];
                
                } else {
                    $output = ['msg' => "Unable to update table please try again", 'status' => 'failed',  'errorMessage' => "Unable to update table please try again"];
                }
            }
            else 
            {

            if($isMoveTable === true) {

                $id = !empty($input['transaction_id']) ? $input['transaction_id'] : "";
                $app_order_id = !empty($input['app_order_id']) ? $input['app_order_id'] : "";
            
                    if(isset($id)) {

                        $updated_rows = 0;
                        $tables = $input['res_table_id'];
                        if( $tables && count($tables) )
                            $updated_rows = PosResTables::whereIn('res_table_id', $tables)->update(['seated' => 0]);

                        if($updated_rows > 0) {
                            return response()->json(['status' => 1 ,'message' => 'Update successful'], 200);
                        } else {
                            return response()->json(['status' => 0 ,'message' => 'Update Failed'], 400);
                        }
                    }
                    elseif(isset($app_order_id)) {
                        $tables = $input['res_table_id'];
                        $updated_rows = 0;
                        if( $tables && count($tables) )
                            $updated_rows = PosResTables::whereIn('res_table_id', $tables)->update(['seated' => 0]);

                        if($updated_rows > 0) {
                            return response()->json(['status' => 1 ,'message' => 'Update successful'], 200);
                        } else {
                            return response()->json(['status' => 0 ,'message' => 'Update Failed'], 400);
                        }
                    } else {

                    }
                
                } else {
                $output = [
                            'errorMessage' => trans("messages.something_went_wrong")
                        ]; 
                }
            }
            
            return $output;
        } catch (\Exception $e) {
            \Log::emergency("File:" . $e->getFile() . "Line:" . $e->getLine() . "Message:" . $e->getMessage());
            $msg = trans("messages.something_went_wrong");

            $error_message = "File: " . $e->getFile(). " | Line: " . $e->getLine(). " | Message: " . $e->getMessage();
            $this->util->sendErrorLogOnMSTeam($error_message);

            return [
                'errorMessage' => $msg
            ];
        }
    }

    function update_pickup_order(Request $request)
    {
        $input = $request;
    
        if(isset($input['token']))
        { 
            $result = User::checkUserToken($input['token'], $input['user_id']);

            if($result)
            {
                try {
                    $output = $this->updatePickupOrder($input);
                } catch (\Exception $e) {
                    DB::rollBack();
                    \Log::emergency("File:" . $e->getFile(). "Line:" . $e->getLine(). "Message:" . $e->getMessage());
                    $msg = trans("messages.something_went_wrong");
        
                    $output = [
                                    'errorMessage' => $msg
                                ];
                }

                return $output;
            }
            else
            {
                return["errorMessage"=>'Invalid token.'];
            }
        }
        else
        {
            return["errorMessage"=>'Invalid token.'];
        }
    }

    function updatePickupOrder($input)
    {
        //\Log::info($input);
        $is_direct_sale = false;
        if (!empty($input['products'])) 
        {
            $id = $input['transaction_id'];
            $business_id = $input['business_id'];
            $user_id = $input['user_id'];
            $contact_id = $input['contact_id'];
            $delete_flag = $input['flag'];
            $pax = $input['pax'];
            $app_order_id = !empty($input['app_order_id']) ? $input['app_order_id'] : "";
            $discount = ['discount_type' => $input['discount_type'],
                        'discount_amount' => $input['discount_amount']
                    ];

            $app_item_line_id = isset($input['products'][0]['app_item_line_id']) ? $input['products'][0]['app_item_line_id'] : "";
                
            if(!empty ($input['products'][0]['modifier_app_ids'])) {
                $modifiers_app_ids = array_column($input['products'], 'modifier_app_ids');    
            } else {
                $modifiers_app_ids = "";    
            }

            $transaction_before = Transaction::find($id);
            $status_before =  $transaction_before->status;

            $invoice_total = $this->productUtil->newCalculateInvoiceTotal($input['products'], $input['tax_rate_id'], $discount, $input['service_charges']);
            
            if (!empty($input['transaction_date'])) {
                $input['transaction_date'] = $this->productUtil->uf_date($input['transaction_date'], true);
            }

            $input['is_suspend'] = isset($input['is_suspend']) && 1 == $input['is_suspend']  ? 1 : 0;
            if ($input['is_suspend']) {
                $input['sale_note'] = !empty($input['additional_notes']) ? $input['additional_notes'] : null;
            }

            //Begin transaction
            DB::beginTransaction();
            
            //$transaction = $this->transactionUtil->updateSellTransaction($id, $business_id, $input, $invoice_total, $user_id);
            $transaction = $this->transactionUtil->updateSellTransaction($id, $business_id, $input, $invoice_total, $user_id,$app_order_id);
            //Update Sell lines
            $business_details = $this->businessUtil->getDetails($business_id);
            if (in_array("modifiers", $business_details->enabled_modules)) {
                $isModuleEnabled = true;
            } else {
                $isModuleEnabled = false;
            }
            //$deleted_lines = $this->transactionUtil->createOrUpdateSellLines($transaction, $input['products'], $input['location_id'], true, $status_before, [], true, $isModuleEnabled);

            $deleted_lines = $this->transactionUtil->createOrUpdateSellLines($transaction, $input['products'], $input['location_id'],$app_order_id, $modifiers_app_ids, $user_id, true, $status_before, [], true, $isModuleEnabled);

            //Update update lines
            $is_credit_sale = isset($input['is_credit_sale']) && $input['is_credit_sale'] == 1 ? true : false;

            // $new_sales_order_ids = $transaction->sales_order_ids ?? [];
            // $sales_order_ids =array_unique(array_merge($sales_order_ids, $new_sales_order_ids));
    
            // if (!empty($sales_order_ids)) {
            //     $this->transactionUtil->updateSalesOrderStatus($sales_order_ids);
            // }
            
            if (!$is_direct_sale && !$transaction->is_suspend && !empty($input['payment']) && !$is_credit_sale) {
                // //Add change return
                // $change_return = $this->dummyPaymentLine;
                // $change_return['amount'] = $input['change_return'];
                // $change_return['is_return'] = 1;
                // if (!empty($input['change_return_id'])) {
                //     $change_return['id'] = $input['change_return_id'];
                // }
                // $input['payment'][] = $change_return;

                //$this->transactionUtil->createOrUpdatePaymentLines($transaction, $input['payment'], $business_id, $user_id);
                $this->transactionUtil->createOrUpdatePaymentLines($transaction, $input['payment'], $app_order_id, $business_id, $user_id);
                //Update cash register
                //$this->cashRegisterUtil->updateSellPayments($status_before, $transaction, $input['payment'], $user_id);
                $sell_payments = $this->cashRegisterUtil->updateSellPayments($status_before, $transaction, $input['payment'], $user_id,$app_order_id);

                if($sell_payments == false) {
                    return response()->json(['status' => 'failed', 'msg' => 'Currently no cash registers are available, please reset your device' ]);    
                }
            }

            //Update payment status
            $payment_status = $this->transactionUtil->updatePaymentStatus($transaction->id, $transaction->final_total);
            $transaction->payment_status = $payment_status;
            
            DB::commit();
            
            PosResTables::where('transaction_id', $transaction->id)->update(['pax' => $pax]);

            $output = ['msg' => "Sale order is edited." ];
        }
        else 
        {
            $output = [
                        'errorMessage' => trans("messages.something_went_wrong")
                    ];
        }

        return $output;
    }
    
    function updateDineInOrder2($input)
    {
        $is_direct_sale = false;
        if (!empty($input['products'])) 
        {
            $id = $input['transaction_id'];
            $business_id = $input['business_id'];
            $user_id = $input['user_id'];
            $contact_id = $input['contact_id'];
			$delete_flag = $input['flag'];
            $pax = $input['pax'];
            $discount = ['discount_type' => $input['discount_type'],
                        'discount_amount' => $input['discount_amount']
                    ];
            $app_order_id = isset($input['app_order_id']) ? $input['app_order_id'] : "";

            $transaction_before = Transaction::find($id);
            $status_before =  $transaction_before->status;

            $invoice_total = $this->productUtil->newCalculateInvoiceTotal($input['products'], $input['tax_rate_id'], $discount, $input['service_charges']);
            
            if (!empty($input['transaction_date'])) {
                $input['transaction_date'] = $this->productUtil->uf_date($input['transaction_date'], true);
            }

            $input['is_suspend'] = isset($input['is_suspend']) && 1 == $input['is_suspend']  ? 1 : 0;
            if ($input['is_suspend']) {
                $input['sale_note'] = !empty($input['additional_notes']) ? $input['additional_notes'] : null;
            }

            //Begin transaction
            DB::beginTransaction();
            
            $transaction = $this->transactionUtil->updateSellTransaction($id, $business_id, $input, $invoice_total, $user_id,$app_order_id);

            //Update Sell lines
            $business_details = $this->businessUtil->getDetails($business_id);
            if (in_array("modifiers", $business_details->enabled_modules)) {
                $isModuleEnabled = true;
            } else {
                $isModuleEnabled = false;
            }
            $deleted_lines = $this->transactionUtil->createOrUpdateSellLines($transaction, $input['products'], $input['location_id'], true, $status_before, [], true, $isModuleEnabled);

            //Update update lines
            $is_credit_sale = isset($input['is_credit_sale']) && $input['is_credit_sale'] == 1 ? true : false;

            // $new_sales_order_ids = $transaction->sales_order_ids ?? [];
            // $sales_order_ids =array_unique(array_merge($sales_order_ids, $new_sales_order_ids));
    
            // if (!empty($sales_order_ids)) {
            //     $this->transactionUtil->updateSalesOrderStatus($sales_order_ids);
            // }
            
            if (!$is_direct_sale && !$transaction->is_suspend && !empty($input['payment']) && !$is_credit_sale) {
                // //Add change return
                // $change_return = $this->dummyPaymentLine;
                // $change_return['amount'] = $input['change_return'];
                // $change_return['is_return'] = 1;
                // if (!empty($input['change_return_id'])) {
                //     $change_return['id'] = $input['change_return_id'];
                // }
                // $input['payment'][] = $change_return;

                $this->transactionUtil->createOrUpdatePaymentLines($transaction, $input['payment'], $business_id, $user_id);

                //Update cash register
                $this->cashRegisterUtil->updateSellPayments($status_before, $transaction, $input['payment'], $user_id);
            }

            //Update payment status
            $payment_status = $this->transactionUtil->updatePaymentStatus($transaction->id, $transaction->final_total);
            $transaction->payment_status = $payment_status;
            
            DB::commit();
            
            PosResTables::where('transaction_id', $transaction->id)->update(['pax' => $pax]);

            $output = ['msg' => "Sale order is edited." ];
        }
        else 
        {
            $output = [
                        'errorMessage' => trans("messages.something_went_wrong")
                    ];
        }

        return $output;
    }

    function close_table(Request $request)
    {
        
        $user_data = $request->only('app_order_id','transaction_id','table_id', 'token', 'user_id', 'business_id', 'business_location_id', 'location_id', 'delete_transaction');
        
        $user_data['app_order_id'] = isset($user_data['app_order_id']) ? $user_data['app_order_id'] : "";
        $user_data['transaction_id'] = isset($user_data['transaction_id']) ? $user_data['transaction_id'] : "";
        
        if(isset($user_data['token']))
        {    
            $result = User::checkUserToken($user_data['token'], $user_data['user_id']);

            if($result)
            {
                // ==============================================================
                // Clear Queues START
                if( $user_data['table_id'] && count($user_data['table_id']) ) {
                    QueueTable::where('business_id', $user_data['business_id'])
                                ->where('location_id', $user_data['location_id'])
                                ->whereIn('res_table_id', $user_data['table_id'])
                                ->update(['is_occupied' => 0]);
                }
                // Clear Queues END
                // ==============================================================
                
                // Delete QR Tokens START
                if( $user_data['table_id'] && count($user_data['table_id']) ) {
                    TableQrToken::where('business_id', $user_data['business_id'])
                                ->where('location_id', $user_data['location_id'])
                                ->whereIn('table_id', $user_data['table_id'])
                                ->delete();
                }
                // Delete QR Tokens END

                if($user_data['app_order_id'] == null) {
                    $updated_rows = 0;
                    $tables = $user_data['table_id'];
                    for($i=0; $i<count($tables); $i++) {
                        $updated_rows += PosResTables::where('res_table_id', $tables[$i])->update(['seated' => 0]);
                    }

                    if ($user_data['delete_transaction'] == true && $user_data['transaction_id'] != null) {
                        $this->transactionUtil->deleteSale($user_data['business_id'], $user_data['transaction_id']);
                    }

                    if($updated_rows > 0) {
                        return response()->json(['status' => 1 ,'message' => 'Update successful'], 200);
                    } else {
                        return response()->json(['status' => 0 ,'message' => 'Update Failed'], 400);
                    }
                }
                elseif($user_data['transaction_id'] == null) {
                    $tables = $user_data['table_id'];
                    $updated_rows = 0;
                    for($i=0; $i<count($tables); $i++) {
                        $updated_rows += PosResTables::where('res_table_id', $tables[$i])->update(['seated' => 0]);
                    }
                    if($updated_rows > 0) {
                        return response()->json(['status' => 1 ,'message' => 'Update successful'], 200);
                    } else {
                        return response()->json(['status' => 0 ,'message' => 'Update Failed'], 400);
                    }
                } 
                else {
                    $updated_rows = 0;
                    $updated_rows = PosResTables::where('app_order_id', $user_data['app_order_id'])
                            ->orWhere('transaction_id', $user_data['transaction_id'])
                            ->update(['seated' => 0]);
                    
                    if ($user_data['delete_transaction'] == true && $user_data['transaction_id'] != null) {
                        
                        $deleted = Transaction::where('id', $user_data['transaction_id'])
                                              ->where('business_id', $user_data['business_id'])
                                              ->where('location_id', $user_data['location_id'])
                                              ->delete();
                    }

                    if($updated_rows > 0) {
                        return response()->json(['status' => 1 ,'message' => 'Update successful'], 200);
                    } else {
                        return response()->json(['status' => 0 ,'message' => 'Update Failed'], 400);
                    }
                }

            }
            else
            {
                return["errorMessage"=>'Invalid token.'];
            }
        }
        else{
            return["errorMessage"=>'Invalid token.'];
        }
    }

    function generate_qr_token(Request $request)
    {
        $user_data = $request->only('business_id', 'location_id','table_id', 'table_name', 'pax', 'token', 'user_id', 'terminal_id');

        if(isset($user_data['token']))
        {    
            $result = User::checkUserToken($user_data['token'], $user_data['user_id']);

            if($result)
            {
                $user_id = $user_data['user_id'];
                $business_id = $user_data['business_id'];
                $business_location_id = $user_data['location_id'];
                $qr_token = str_random(60);
                $table_id = $user_data['table_id'];
                $table_name = $user_data['table_name'];
                $pax = $user_data['pax'];
                $created_at = \Carbon::now()->format('Y-m-d H:i:s');
                $expired_at = \Carbon::now()->addHours(24)->format('Y-m-d H:i:s');
                $terminal_id = !empty($user_data['terminal_id']) ? $user_data['terminal_id'] : "";

                $tableQrToken = TableQrToken::where('table_id', $table_id)
                                    ->where('table_name', $table_name)
                                    ->where('location_id', $business_location_id)
                                    ->where('business_id', $business_id)
                                    ->where('table_qr_tokens.expired_at', '>=', \Carbon::now()->format('Y-m-d H:i:s'))
                                    ->orderBy('id', 'DESC')
                                    ->first();
                if( $tableQrToken && !empty($tableQrToken) ) {
                    \Log::info('QR Token Already Exists');
                    $qr_token = $tableQrToken->qr_token;
                    $business_location = BusinessLocation::find($business_location_id);
                    $full_url = config("constants.QR_APP_URL") . '/start-order?t_id=' . $table_id . '&uid=' . $user_id . '&t_name=' . $table_name . '&pax=' . $pax . '&business_id=' . $business_id . '&location_id=' . $business_location_id . '&token=' . $qr_token . '&terminal_id='. $terminal_id;
                    $expired_at = $tableQrToken->expired_at;
                    $created_at = $tableQrToken->created_at;

                } else {
                    \Log::info('QR Token NOT Exists');
                    $full_url = $this->transactionUtil->createTableQrToken($user_id, $business_id, $business_location_id, $qr_token, $table_id, $table_name, $pax, $expired_at, $terminal_id);
                }

                $qr_url = "";
                if( $full_url ) {
                    $builder = new \AshAllenDesign\ShortURL\Classes\Builder();
                    $shortURLObject = $builder->destinationUrl($full_url)->make();

                    if( $shortURLObject && !empty($shortURLObject) )
                        $qr_url = $shortURLObject->default_short_url;
                }
                    
                return [
                    "full_url" => $full_url,
                    "qr_url" => $qr_url,
                    "expire_at" => $expired_at,
                    "created_at" => $created_at
                ];
            } else {
                return["errorMessage"=>'Invalid token.'];
            }
        } else{
            return["errorMessage"=>'Invalid token.'];
        }
    }

    public function check_qr_token(Request $request)
    {
        $qr_token_data = $request->only('user_id', 'business_id', 'location_id', 'table_id', 'table_name', 'pax', 'token');

        $user_id = $qr_token_data['user_id'];
        $business_id = $qr_token_data['business_id'];
        $location_id = $qr_token_data['location_id'];
        $table_id = $qr_token_data['table_id'];
        $table_name = $qr_token_data['table_name'];
        $pax = $qr_token_data['pax'];
        $token = $qr_token_data['token'];

        $query = TableQrToken::where('table_qr_tokens.business_id', $business_id)
                ->where('table_qr_tokens.location_id', $location_id)
                ->where('table_qr_tokens.qr_token', $token)
                ->where('table_qr_tokens.table_id', $table_id)
                ->where('table_qr_tokens.table_name', $table_name)
                ->where('table_qr_tokens.pax', $pax)
                ->where('table_qr_tokens.user_id', $user_id)
                ->where('table_qr_tokens.expired_at', '>=', \Carbon::now()->format('Y-m-d H:i:s'))
                ->orderBy('table_qr_tokens.created_at', 'desc')
                ->get();

        if(empty(json_decode($query))) {
            return $this->respond(["result" => false]);
        } else {
            return $this->respond(["result" => true]);
        }
    }

    function update_serve_later_quantity(Request $request)
    {
        $user_data = $request->only('transaction_sell_line_id', 'serve_all', 'token', 'user_id','app_item_line_id');
        
        if(isset($user_data['token']))
        {    
            $result = User::checkUserToken($user_data['token'], $user_data['user_id']);
            $transaction_sell_line_id = !empty($user_data['transaction_sell_line_id']) ? $user_data['transaction_sell_line_id'] : "";
            $app_item_line_id = !empty($user_data['app_item_line_id']) ? $user_data['app_item_line_id'] : "";

            if($result)
            {
                if($user_data['serve_all']) {
                    // for($i = 0; $i < count($transaction_sell_line_id); $i++) {
                    //     TransactionSellLine::where('id', $transaction_sell_line_id[$i])->update(['serve_later_quantity' => 0]);
                    // }
                    if(!empty($app_item_line_id)){
                        foreach ($app_item_line_id as $id) {
                            TransactionSellLine::where('app_item_line_id', $id)->update(['serve_later_quantity' => 0]);
                        }
                    } else {
                        foreach ($transaction_sell_line_id as $id) {
                            TransactionSellLine::where('id', $id)->update(['serve_later_quantity' => 0]);
                        }
                    }
                } else {
                    if(!empty($app_item_line_id)){
                        foreach ($app_item_line_id as $line_id) {
                            $transaction = TransactionSellLine::where('app_item_line_id', $line_id)->firstOrFail();
                            $serve_later_quantity = $transaction->serve_later_quantity - 1;
                            TransactionSellLine::where('id', $line_id)->update(['serve_later_quantity' => $serve_later_quantity]);
                        }
                    } else {
                        foreach ($transaction_sell_line_id as $line_id) {
                            $transaction = TransactionSellLine::where('id', $line_id)->firstOrFail();
                            $serve_later_quantity = $transaction->serve_later_quantity - 1;
                            TransactionSellLine::where('id', $line_id)->update(['serve_later_quantity' => $serve_later_quantity]);
                        }
                    }
    
                }

                return['msg' => "Serve order is updated." ];
            }
            else
            {
                return["errorMessage"=>'Invalid token.'];
            }
        }
        else{
            return["errorMessage"=>'Invalid token.'];
        }
    }

    function update_serve_later_quantity_bulk(Request $request)
    {
        $input = $request;

        if(isset($input['token']))
        { 
            $result = User::checkUserToken($input['token'], $input['user_id']);

            if($result)
            {
                $output = $this->updateServeLaterQuantityBulk($input);
                return $output;
            }
            else
            {
                return["errorMessage"=>'Invalid token.'];
            }
        }
        else
        {
            return["errorMessage"=>'Invalid token.'];
        }
    }

    public function updateServeLaterQuantityBulk($inputRequest)
    {
        try {
            if ( isset($inputRequest['orders']) && !empty($inputRequest['orders']))  {
                $orders = $inputRequest["orders"];
                DB::beginTransaction();

                foreach ($orders as $key => $input) {
                    $transaction_sell_line_id = !empty($input['transaction_sell_line_id']) ? $input['transaction_sell_line_id'] : "";
                    $app_item_line_id = !empty($input['app_item_line_id']) ? $input['app_item_line_id'] : "";
        
                    if($input['serve_all']) {
                        if(!empty($transaction_sell_line_id)){
                            foreach ($transaction_sell_line_id as $id) {
                                TransactionSellLine::where('id', $id)->update(['serve_later_quantity' => 0]);
                            }
                        } else {
                            foreach ($app_item_line_id as $id) {
                                TransactionSellLine::where('app_item_line_id', $id)->update(['serve_later_quantity' => 0]);
                            }
                        }
                    } else {
                        if(!empty($transaction_sell_line_id)){
                            $transaction = TransactionSellLine::where('id', $transaction_sell_line_id[0])->firstOrFail();
                            $serve_later_quantity = $transaction->serve_later_quantity - 1;
                            TransactionSellLine::where('id', $transaction_sell_line_id[0])->update(['serve_later_quantity' => $serve_later_quantity]);
                        } else {
                            $transaction = TransactionSellLine::where('app_item_line_id', $app_item_line_id[0])->firstOrFail();
                            $serve_later_quantity = $transaction->serve_later_quantity - 1;
                            TransactionSellLine::where('app_item_line_id', $app_item_line_id[0])->update(['serve_later_quantity' => $serve_later_quantity]);
                        }
        
                    }
                }

                DB::commit();

                $output = [
                    'status'=> 'Success',
                    'msg' => 'Order Updated successfully'
                ];
            } else {
                {
                    $output = [
                        'errorMessage' => trans("messages.something_went_wrong")
                    ];
                }
            }
        } catch (\Exception $e) {
            DB::rollBack();
            \Log::emergency("File:" . $e->getFile(). "Line:" . $e->getLine(). "Message:" . $e->getMessage());
            $msg = trans("messages.something_went_wrong");

            $output = [
                'errorMessage' => $msg,
                "error" => $e->getMessage()
            ];
        }
        return $output;
    }


    function update_pending_order(Request $request)
    {
        $user_data = $request->only('transaction_id', 'token', 'user_id', 'transaction_sell_line_id');

        if(isset($user_data['token']))
        {    
            $result = User::checkUserToken($user_data['token'], $user_data['user_id']);
            $transaction_id = $user_data['transaction_id'];
            $transaction_sell_line_id = $user_data['transaction_sell_line_id'];

            if($result)
            {
                $transaction = Transaction::where('id', $transaction_id)->update(['pending_order' => 0]);

                for($i = 0; $i < count($transaction_sell_line_id); $i++) {
                    TransactionSellLine::where('id', $transaction_sell_line_id[$i])->update(['printed' => 1]);
                }

                return['msg' => "Pending order is updated." ];
            }
            else
            {
                return["errorMessage"=>'Invalid token.'];
            }
        }
        else{
            return["errorMessage"=>'Invalid token.'];
        }
    }

    function transfer_table(Request $request)
    {
        $user_data = $request->only('transaction_id','previous_table_id','new_table_id', 'token', 'user_id','business_location_id','current_date','current_time');

        if(isset($user_data['token']))
        {    
            $result = User::checkUserToken($user_data['token'], $user_data['user_id']);

            $businessLocation = BusinessLocation::find($user_data["business_location_id"]);
            if( !empty($businessLocation) && !empty($businessLocation->day_start_time) ) {
                $daystartTime = $businessLocation->day_start_time;
                $dayStartTime = $daystartTime.":00:00";
                $dayendTime = $daystartTime - 1;
                $dayEndTime = $dayendTime.":59:59";
            } else {
                $dayStartTime = str_replace(' ', '', Config::get('constants.businessStartTimeDefault'));
                $dayEndTime = str_replace(' ', '', Config::get('constants.businessEndTimeDefault'));
            }

            $transaction = Transaction::where('id', $user_data["transaction_id"])->first();

            if ($transaction) {
                $createdAt = $transaction->created_at;   
                
                $createdAtDate = Carbon::parse($createdAt)->toDateString(); // Format: Y-m-d
                
                $createdAtTime = Carbon::parse($createdAt)->toTimeString(); 
            }

            // $current_time = null;
            // if( isset($user_data["current_time"]) && $user_data["current_time"] ) {
            //     $current_time = $user_data["current_time"];
            // }
            
            // $current_date = null;
            // if( isset($user_data["current_date"]) && $user_data["current_date"] ) {
            //     $current_date = $user_data["current_date"];
            // }

            if( Config::get('constants.setBusinessTime') && !empty($businessLocation) && !empty($businessLocation->day_start_time) && !empty($createdAtDate) && !empty($createdAtTime) ) {
                $morning6TimeStamp = strtotime($createdAtDate . $dayEndTime);
                $dateTimeStamp = strtotime($createdAtDate . " " . $createdAtTime);
                if( $dateTimeStamp >= $morning6TimeStamp ) {
                    $today = $createdAtDate .' '.$dayStartTime;
                    $tomorrow = date('Y-m-d', strtotime($createdAtDate .' +1 day')) .' '.$dayEndTime;
                } else {
                    $today = date('Y-m-d', strtotime($createdAtDate .' -1 day')) .' '.$dayStartTime;
                    $tomorrow = $createdAtDate.' '.$dayEndTime;
                }
            } else {
                $today = Carbon::today()->format('Y-m-d') . Config::get('constants.businessStartTimeDefault');
                $tomorrow = Carbon::today()->format('Y-m-d') . Config::get('constants.businessEndTimeDefault');
            }
            $app_order_id = "";
            if($result)
            {
                // $tables = array($user_data['previous_table_id']);
                // $new_tables = array($user_data['new_table_id']);
                $transaction_id = $user_data['transaction_id'];
                $tables = $user_data['previous_table_id'];
                $new_tables = $user_data['new_table_id'];
                $transaction = new \stdClass();


                
                for($i = 0; $i < count($transaction_id); $i++) {
                    
                    $previousTableDetails = PosResTables::where('res_table_id', $tables[$i])
                                                        ->where('seated', 1)
                                                        ->where('transaction_id', $transaction_id[$i])
                                                        //->whereDate('pos_res_tables.created_at','>=', Carbon::today())
                                                        ->whereBetween('pos_res_tables.created_at', [$today, $tomorrow])
                                                        ->get()
                                                        ->toArray();
                    
                    
                                                        
                    if(count($previousTableDetails) > 0) {
                        // close previous table
                        PosResTables::where('res_table_id', $tables[$i])
                                        //->whereDate('pos_res_tables.created_at','>=', Carbon::today())
                                        ->whereBetween('pos_res_tables.created_at', [$today, $tomorrow])
                                        ->update(['seated' => 0, 'transaction_id' => null]);

                        $previousTableDetails[0]['res_table_id'] = array($new_tables[$i]);
                        $transaction->id = $transaction_id[$i];
                        $pos_res_tables = $this->transactionUtil->createPosResTable($transaction, $previousTableDetails[0],$app_order_id);
                        
                    }
                }

                return['msg' => "Table transfered." ];
                // $previousTableDetails = PosResTables::where('res_table_id', $tables[0])
                //                                     ->where('seated',1)
                //                                     ->whereDate('pos_res_tables.created_at','>=', Carbon::today())
                //                                     ->get()
                //                                     ->toArray();
                
                // //$previousTableDetails = $previousTableDetails[0];
                
                // if(count($previousTableDetails) > 0) {
                //     // close previous table
                //     for($i=0; $i<count($tables); $i++) {

                //         PosResTables::where('res_table_id', $tables[$i])
                //                         ->whereDate('pos_res_tables.created_at','>=', Carbon::today())
                //                         ->update(['seated' => 0]);
                //     }

                //     for($i=0; $i<count($new_tables); $i++) {
                            
                //         $previousTableDetails['res_table_id'] = array($new_tables[$i]);
                //         $transaction->id = $user_data['transaction_id'];
                //         $pos_res_tables = $this->transactionUtil->createPosResTable($transaction, $previousTableDetails);

                //     }

                //     return['msg' => "Table transfered." ];
                // }
                // else
                // {
                //     return['msg' => "To-be-transfered table not found." ];

                // }
            }
            else
            {
                return["errorMessage"=>'Invalid token.'];
            }
        }
        else{
            return["errorMessage"=>'Invalid token.'];
        }
    }
    
    public function check_qr_dinein_preparation_time(Request $request)
    {
        $user_data = $request->only('business_location_id');

        $result = array();
        $total_seat = 0;
        try {
            $all_draft_location_table = ResTable::leftjoin('pos_res_tables', function ($leftjoin) {
                                                $leftjoin->on('res_tables.id', '=', 'pos_res_tables.res_table_id')
                                                        ->where('pos_res_tables.seated', '=', 1)
                                                        ->whereDate('pos_res_tables.created_at','>=', Carbon::today());
                                            })
                                            ->leftjoin('transactions', 'transactions.id','=','pos_res_tables.transaction_id')
                                            //->leftjoin('transaction_sell_lines', 'transaction_sell_lines.transaction_id','=','transactions.id')
                                            ->select('res_tables.id', 
                                                    'res_tables.name', 
                                                    'res_tables.location', 
                                                    'res_tables.description', 
                                                    'pos_res_tables.seated', 
                                                    'pos_res_tables.pax',
                                                    'pos_res_tables.transaction_id',
                                                    'transactions.status',
                                                    'transactions.pending_order'
                                                    )
                                            ->where('res_tables.location_id', $user_data['business_location_id'])
                                            ->where('transactions.status', '=', 'draft')
                                            ->groupBy('transactions.id')
                                            ->get()
                                            ->toArray();

            if(count($all_draft_location_table)<=0) {
                $all_draft_location_table = ["errorMessage"=>'Table not found.'];
            }
        } catch(\Exception $e) {
            $all_draft_location_table = ["errorMessage"=>'Table not found.'];
        }

        if(isset($all_draft_location_table['errorMessage'])?false:true) {

            $total_draft_seat = count($all_draft_location_table);
            $est_prep_time_minutes = $total_draft_seat * 5;
            $convert_est_prep_time_hours = sprintf('%02d',intdiv($est_prep_time_minutes, 60));
            $convert_est_prep_time_minutes = sprintf('%02d',($est_prep_time_minutes % 60));

            $result[] = [
                'all_draft_location_table' => $all_draft_location_table,
                'total_draft_seat' => $total_draft_seat,
                'est_prep_time_hours' => $convert_est_prep_time_hours,
                'est_prep_time_minutes' => $convert_est_prep_time_minutes
            ];
        }
        else {
            $result = ["errorMessage"=>'Table not found.'];
        }

        return $this->respond($result);
    }
    
    public function merge_table(Request $request)
    {
        $input = $request;
    
        if(isset($input['token']))
        { 
            $result = User::checkUserToken($input['token'], $input['user_id']);

            if($result)
            {
                foreach ($input["res_table_id"] as $res_table_id) {
                    $transaction = PosResTables::create([
                        'transaction_id' => $input["transaction_id"],
                        'res_table_id' => !empty($res_table_id) ? $res_table_id : null,
                        'pax' => !empty($input['pax']) ? $input['pax'] : 0,
                        'seated' => !empty($input['seated']) ? $input['seated'] : 0,
                    ]);
                }
        
                return ['msg' => "Tables are merged." ];
            }
            else
            {
                return["errorMessage"=>'Invalid token.'];
            }
        }
        else
        {
            return["errorMessage"=>'Invalid token.'];
        }
    }
    
    function save_dine_in_order_bulk(Request $request)
    {
        $input = $request;

        if(isset($input['token']))
        { 
            $result = User::checkUserToken($input['token'], $input['user_id']);

            if($result)
            {
                $output = $this->saveDineInOrderBulk($input);
                return $output;
            }
            else
            {
                return["errorMessage"=>'Invalid token.'];
            }
        }
        else
        {
            return["errorMessage"=>'Invalid token.'];
        }
    }

    public function saveDineInOrderBulk($inputRequest)
    {
        try {
            if ( isset($inputRequest['orders']) && !empty($inputRequest['orders']))  {
                $orders = $inputRequest["orders"];

                DB::beginTransaction();

                foreach ($orders as $key => $input) {

                    $is_direct_sale = false;
            
                    if (!empty($input['products'])) 
                    {
                        
                        $business_id = $inputRequest['business_id'];
                        $user_id = $inputRequest['user_id'];
                        $contact_id = $input['contact_id'];
                        $input['location_id'] = $inputRequest['location_id'];
                        $input['terminal_id'] = $inputRequest['terminal_id'];

                        $app_order_id = isset($input['app_order_id']) ? $input['app_order_id'] : "";
                        // $app_item_line_id = isset($input['products'][0]['app_item_line_id']) ? $input['products'][0]['app_item_line_id'] : "";
                        
                        // if(!empty ($input['products'][0]['app_item_line_id'])) {
                        //     $app_item_line_id = array_column($input['products'], 'app_item_line_id');    
                        // } else {
                        //     $app_item_line_id = "";    
                        // }
                        
                        if(!empty ($input['products'][0]['modifier_app_ids'])) {
                            $modifiers_app_ids = array_column($input['products'], 'modifier_app_ids');    
                        } else {
                            $modifiers_app_ids = "";    
                        }

                        $discount_amount = (isset($input['discount_amount']) && $input['discount_amount']) ? $input['discount_amount'] : 0;
                        $input["discount_amount"] = $discount_amount;

                        $commission_agent = (isset($input['commission_agent']) && $input['commission_agent']) ? $input['commission_agent'] : 0;
                        $input["commission_agent"] = $commission_agent;

                         $discount = ['discount_type' => $input['discount_type'],
                                    'discount_amount' => (isset($input['discount_amount']) && $input['discount_amount']) ? $input['discount_amount'] : 0
                                ];

                        $invoice_total = $this->productUtil->newCalculateInvoiceTotal($input['products'], $input['tax_rate_id'], $discount, $input['service_charges']);
                        
                        $payment_gateway_response = '';
                        if( isset($input['payment']) && !empty($input['payment'])){
                            $payment_gateway_response = !empty($input['payment'][0]['payment_gateway_response']) ? $input['payment'][0]['payment_gateway_response'] : "";
                        } else {
                            $payment_gateway_response = '';
                        }
                                
                        if (empty($input['transaction_date'])) {
                            $input['transaction_date'] =  \Carbon::now();
                        } else {
                            $input['transaction_date'] = $this->productUtil->uf_date($input['transaction_date'], true);
                        }

                        $input['is_suspend'] = isset($input['is_suspend']) && 1 == $input['is_suspend']  ? 1 : 0;
                        if ($input['is_suspend']) {
                            $input['sale_note'] = !empty($input['additional_notes']) ? $input['additional_notes'] : null;
                        }
                        
                        foreach ($input["res_table_id"] as $res_table_id) {
                            
                            $posResTable = PosResTables::leftJoin('transactions', function($join) {
                                                        $join->on('transactions.id','=','pos_res_tables.transaction_id')
                                                            ->orWhere(function($query) {
                                                                $query->whereNull('transactions.id')
                                                                    ->whereColumn('pos_res_tables.app_order_id', '=', 'transactions.app_order_id');
                                                                });
                                                        })
                                                        ->where('pos_res_tables.res_table_id', '=', $res_table_id)
                                                        ->where('pos_res_tables.seated', '=', 1)
                                                        ->whereDate('pos_res_tables.created_at','>=', Carbon::today())
                                                        ->first();      
                            }
                        
                        if($posResTable){
                        
                            $transaction = Transaction::where(function ($query) use ($posResTable) {
                                                $query->where('id', $posResTable['transaction_id'])
                                                ->orWhere(function ($query) use ($posResTable) {
                                                        $query->whereNull('id')
                                                                ->where('app_order_id', $posResTable['app_order_id']);
                                                    });
                                                })->first();
                                            
                            
                            if($transaction){
                                //duplicate table
                                $business_details = $this->businessUtil->getDetails($business_id);
                                if (in_array("modifiers", $business_details->enabled_modules)) {
                                    $isModuleEnabled = true;
                                } else {
                                    $isModuleEnabled = false;
                                }
                                
                                $this->transactionUtil->createOrUpdateSellLines2($transaction, $input['products'], $input['location_id'], $app_order_id, $modifiers_app_ids, $user_id, false, null, [], true, $isModuleEnabled);
                                
                                //$this->transactionUtil->updateTransactionInvoice($transaction->id, $invoice_total, $business_id);
            
                                // if (!$is_direct_sale) {
                                //     //Add change return
                                //     $change_return = $this->dummyPaymentLine;
                                //     $change_return['amount'] = $input['change_return'];
                                //     $change_return['is_return'] = 1;
                                //     $input['payment'][] = $change_return;
                                // }
            
                                $is_credit_sale = isset($input['is_credit_sale']) && $input['is_credit_sale'] == 1 ? true : false;
                                //transaction_payments table
                                if (!$transaction->is_suspend && !empty($input['payment']) && !$is_credit_sale) {
                                    $this->transactionUtil->createOrUpdatePaymentLines($transaction, $input['payment'], $app_order_id, $business_id, $user_id);
                                }
            
                                //update product stock
                                foreach ($input['products'] as $product) {
                                    $decrease_qty = $this->productUtil
                                                ->num_uf($product['quantity']);
                                    if (!empty($product['base_unit_multiplier'])) {
                                        $decrease_qty = $decrease_qty * $product['base_unit_multiplier'];
                                    }
            
                                    if ($product['enable_stock']) {
                                        $this->productUtil->decreaseProductQuantity(
                                            $product['product_id'],
                                            $product['variation_id'],
                                            $inputRequest['location_id'],
                                            $decrease_qty
                                        );
                                    }
            
                                    if ($product['product_type'] == 'combo') {
                                        //Decrease quantity of combo as well.
                                        $this->productUtil
                                            ->decreaseProductQuantityCombo(
                                                $product['combo'],
                                                $inputRequest['location_id']
                                            );
                                    }
                                }
            
                                //Check for final and do some processing.
                                if ($input['status'] == 'final') {
                                    //Add payments to Cash Register
                                    if (!$is_direct_sale && !$transaction->is_suspend && !empty($input['payment']) && !$is_credit_sale) {
                                        //cash_register_transactions table
                                        $this->cashRegisterUtil->addSellPayments($transaction, $input['payment'], $inputRequest['user_id']);
                                    }
            
                                    //Check and update reward point
                                    if ($business_details->enable_rp == 1) {
                                        $redeemed = !empty($input['rp_redeemed']) ? $input['rp_redeemed'] : 0;
                                        $this->transactionUtil->updateCustomerRewardPoints($contact_id, $transaction->rp_earned, 0, $redeemed);
                                    }
                                }
                                //Update payment status
                                $payment_status = $this->transactionUtil->updatePaymentStatus($transaction->id, $transaction->final_total,$app_order_id);
            
                                $transaction->payment_status = $payment_status;
                            }
                        }else{
                            
                            //transactions table
                            $transaction = $this->transactionUtil->createSellTransaction($business_id, $input, $invoice_total, $user_id);
                            //pos_res_tables
                            
                            $pos_res_tables = $this->transactionUtil->createPosResTable($transaction, $input, $app_order_id);
                            //transaction_sell_lines table

                            $business_details = $this->businessUtil->getDetails($business_id);
                            if (in_array("modifiers", $business_details->enabled_modules)) {
                                $isModuleEnabled = true;
                            } else {
                                $isModuleEnabled = false;
                            }
                            $this->transactionUtil->createOrUpdateSellLines($transaction, $input['products'], $inputRequest['location_id'], $app_order_id, $modifiers_app_ids, $user_id, false, null, [], true, $isModuleEnabled);

                            // if (!$is_direct_sale) {
                            //     //Add change return
                            //     $change_return = $this->dummyPaymentLine;
                            //     $change_return['amount'] = $input['change_return'];
                            //     $change_return['is_return'] = 1;
                            //     $input['payment'][] = $change_return;
                            // }

                            $is_credit_sale = isset($input['is_credit_sale']) && $input['is_credit_sale'] == 1 ? true : false;
                            //transaction_payments table
                            if (!$transaction->is_suspend && !empty($input['payment']) && !$is_credit_sale) {
                                $this->transactionUtil->createOrUpdatePaymentLines($transaction, $input['payment'], $app_order_id, $business_id, $user_id);
                            }

                            //update product stock
                            foreach ($input['products'] as $product) {
                                $decrease_qty = $this->productUtil
                                            ->num_uf($product['quantity']);
                                if (!empty($product['base_unit_multiplier'])) {
                                    $decrease_qty = $decrease_qty * $product['base_unit_multiplier'];
                                }

                                if ($product['enable_stock']) {
                                    $this->productUtil->decreaseProductQuantity(
                                        $product['product_id'],
                                        $product['variation_id'],
                                        $inputRequest['location_id'],
                                        $decrease_qty
                                    );
                                }

                                if ($product['product_type'] == 'combo') {
                                    //Decrease quantity of combo as well.
                                    $this->productUtil
                                        ->decreaseProductQuantityCombo(
                                            $product['combo'],
                                            $inputRequest['location_id']
                                        );
                                }
                            }

                            //Check for final and do some processing.
                            if ($input['status'] == 'final') {
                                //Add payments to Cash Register
                                if (!$is_direct_sale && !$transaction->is_suspend && !empty($input['payment']) && !$is_credit_sale) {
                                    //cash_register_transactions table
                                    $this->cashRegisterUtil->addSellPayments($transaction, $input['payment'], $inputRequest['user_id']);
                                }

                                //Check and update reward point
                                if ($business_details->enable_rp == 1) {
                                    $redeemed = !empty($input['rp_redeemed']) ? $input['rp_redeemed'] : 0;
                                    $this->transactionUtil->updateCustomerRewardPoints($contact_id, $transaction->rp_earned, 0, $redeemed);
                                }

                                $debitOrder = $this->transactionUtil->debitOrderBalance($input);
                                if($debitOrder == false) {
                                    return response()->json(['errorMessage' => 'Insufficient NFC Card Balance.'], 200);
                                }
                            }
                            //Update payment status
                            $payment_status = $this->transactionUtil->updatePaymentStatus($transaction->id, $transaction->final_total,$app_order_id);

                            $transaction->payment_status = $payment_status;

                            // Close POS Table
                            $is_table_closed = isset($input['is_table_closed']) ? $input['is_table_closed'] : "";
                            if($is_table_closed === true) {
                                $updated_rows = 0;
                                $updated_rows = PosResTables::where('app_order_id', $app_order_id)
                                                ->orWhere('transaction_id', $transaction->id)
                                                ->update(['seated' => 0]);
                            }
                        }
                    }
                }

                if ( isset($inputRequest['tables']) && !empty($inputRequest['tables']))  {
                    // Dining Tables
                    $diningTables = $inputRequest["tables"];
                    $updated_rows = 0;
                    foreach ($diningTables as $key => $diningTable) {
                        $diningTableStatus = 0;
                        if( $diningTable['status'] === 'final' || $diningTable['status'] === 'draft' )
                            $diningTableStatus = 1;

                        $updated_rows += PosResTables::where('res_table_id', $diningTable['table_id'])
                                                    ->where('seated', NULL)
                                                    ->where('transaction_id', NULL)
                                                    ->update(['seated' => $diningTableStatus]);
                    }
                }

                DB::commit();

                $output = ['msg' => "Sale orders are added." ];
            } else {
                {
                    $output = [
                        'errorMessage' => trans("messages.something_went_wrong")
                    ];
                }
            }
        } catch (\Exception $e) {
            DB::rollBack();
            \Log::emergency("File:" . $e->getFile(). "Line:" . $e->getLine(). "Message:" . $e->getMessage());
            $msg = trans("messages.something_went_wrong");

            $output = [
                'errorMessage' => $msg,
                "error" => $e->getMessage()
            ];
        }
        return $output;
    }

    function update_dine_in_order_bulk(Request $request)
    {
        $input = $request;
    
        if(isset($input['token']))
        { 
            $result = User::checkUserToken($input['token'], $input['user_id']);

            if($result)
            {
                try {
                    $output = $this->updateDineInOrderBulk($input);
                } catch (\Exception $e) {
                    DB::rollBack();
                    \Log::emergency("File:" . $e->getFile(). "Line:" . $e->getLine(). "Message:" . $e->getMessage());
                    $msg = trans("messages.something_went_wrong");
        
                    $output = [
                                    'errorMessage' => $msg
                                ];
                }

                return $output;
            }
            else
            {
                return["errorMessage"=>'Invalid token.'];
            }
        }
        else
        {
            return["errorMessage"=>'Invalid token.'];
        }
    }

    public function updateDineInOrderBulk($inputRequest)
    {
        try {
            if ( isset($inputRequest['orders']) && !empty($inputRequest['orders']))  {

                $orders = $inputRequest["orders"];

                //Begin transaction
                DB::beginTransaction();

                foreach ($orders as $key => $input) {
                    $isMoveTable = !empty($input['isMoveTable']) ? $input['isMoveTable'] : false;
                    $is_table_closed = !empty($input['is_table_closed']) ? $input['is_table_closed'] : false;

                    $is_direct_sale = false;
                    
                    if (!empty($input['products'])) 
                    {
                        $business_id = $inputRequest['business_id'];
                        $business_location_id = $inputRequest['business_location_id'];
                        $user_id = $inputRequest['user_id'];
                        $contact_id = $input['contact_id'];
                        $delete_flag = (isset($input['flag']) && $input['flag']) ? $input['flag']: "";
                        $pax = $input['pax'];
                        $app_order_id = $input['app_order_id'];
                        $app_item_line_id = isset($input['products'][0]['app_item_line_id']) ? $input['products'][0]['app_item_line_id'] : "";

                        $id = (isset($input['transaction_id']) && $input['transaction_id']) ? $input['transaction_id'] : "";
                        $res_table_id = (isset($input['res_table_id']) && $input['res_table_id']) ? $input['res_table_id'] : "";

                        $is_table_transferred = (isset($input['is_table_transferred']) && $input['is_table_transferred']) ? $input['is_table_transferred'] : false;
                        if( $is_table_transferred ) {
                            
                            $today = Carbon::today()->format('Y-m-d') . Config::get('constants.businessStartTimeDefault');
                            $tomorrow = Carbon::today()->format('Y-m-d') . Config::get('constants.businessEndTimeDefault');

                            $previousTableDetails = PosResTables::where('seated', 1)
                                                ->where('transaction_id', $id)
                                                ->whereBetween('pos_res_tables.created_at', [$today, $tomorrow])
                                                ->get()
                                                ->toArray();

                            if(!empty($previousTableDetails)) {
                                foreach ($previousTableDetails as $key => $previousTable) {
                                    // close previous table
                                    PosResTables::where('res_table_id', $previousTable['res_table_id'])
                                                    //->whereDate('pos_res_tables.created_at','>=', Carbon::today())
                                                    ->whereBetween('pos_res_tables.created_at', [$today, $tomorrow])
                                                    ->update(['seated' => 0, 'transaction_id' => null]);

                                    $pos_res_tables = $this->transactionUtil->createPosResTableNew($id, $res_table_id[$key], $app_order_id, $previousTable['pax'], $previousTable['seated']);
                                }
                            }
                        }
                            
                        if(!empty ($input['products'][0]['modifier_app_ids'])) {
                            $modifiers_app_ids = array_column($input['products'], 'modifier_app_ids');    
                        } else {
                            $modifiers_app_ids = "";
                        }
                        
                        
                        //$id = isset($app_order_id) ? $app_order_id : $id;

                        if(!empty($input['payment'])){
                            $payment_gateway_response = !empty($input['payment'][0]['payment_gateway_response']) ? $input['payment'][0]['payment_gateway_response'] : "";
                        } else {
                            $payment_gateway_response = '';
                        }
                            
                        $discount_amount = (isset($input["discount_amount"]) && $input["discount_amount"]) ? $input["discount_amount"] : 0;
                        $discount = ['discount_type' => $input['discount_type'],
                                    'discount_amount' => $discount_amount
                                ];

                        
                        if($id)
                            $transaction_before = Transaction::find($id);
                        else
                            $transaction_before = Transaction::where('app_order_id', $app_order_id)->first();
                        
                        $status_before = (isset($transaction_before) && $transaction_before) ? $transaction_before->status : "";
                        $rp_earned_before = (isset($transaction_before) && $transaction_before) ?  $transaction_before->rp_earned : "";;
                        $rp_redeemed_before = (isset($transaction_before) && $transaction_before) ?  $transaction_before->rp_redeemed : "";;
                        
                        $invoice_total = $this->productUtil->newCalculateInvoiceTotal($input['products'], $input['tax_rate_id'], $discount, $input['service_charges']);
                        
                        if (!empty($input['transaction_date'])) {
                            $input['transaction_date'] = $this->productUtil->uf_date($input['transaction_date'], true);
                        }

                        $input['is_suspend'] = isset($input['is_suspend']) && 1 == $input['is_suspend']  ? 1 : 0;
                        if ($input['is_suspend']) {
                            $input['sale_note'] = !empty($input['additional_notes']) ? $input['additional_notes'] : null;
                        }

                        
                        
                        $transaction = $this->transactionUtil->updateSellTransaction($id, $business_id, $input, $invoice_total, $user_id,$app_order_id);
                        
                        //Update Sell lines
                        $business_details = $this->businessUtil->getDetails($business_id);
                        
                        if (in_array("modifiers", $business_details->enabled_modules)) {
                            $isModuleEnabled = true;
                        } else {
                            $isModuleEnabled = false;
                        }
                        //if($delete_flag == true){
                            $deleted_lines = $this->transactionUtil->createOrUpdateSellLines($transaction, $input['products'], $inputRequest['location_id'],$app_order_id, $modifiers_app_ids, $user_id, true, $status_before, [], true, $isModuleEnabled);
                        // }else{
                        //     $deleted_lines = $this->transactionUtil->createOrUpdateSellLines2($transaction, $input['products'], $inputRequest['location_id'], $app_order_id, $modifiers_app_ids, $user_id, true, $status_before, [], true, $isModuleEnabled);
                        // }
                        
                        // $previousTableDetails = PosResTables::where('seated', 1)
                        //                                     ->where('transaction_id', $id)
                        //                                     ->get()
                        //                                     ->toArray();
                        // echo "<pre>";
                        // print_r($previousTableDetails);die;
                        //Update update lines
                        $is_credit_sale = isset($input['is_credit_sale']) && $input['is_credit_sale'] == 1 ? true : false;

                        // $new_sales_order_ids = $transaction->sales_order_ids ?? [];
                        // $sales_order_ids =array_unique(array_merge($sales_order_ids, $new_sales_order_ids));
                
                        // if (!empty($sales_order_ids)) {
                        //     $this->transactionUtil->updateSalesOrderStatus($sales_order_ids);
                        // }
                        
                        if (!$is_direct_sale && !$transaction->is_suspend && !empty($input['payment']) && !$is_credit_sale) {
                            // //Add change return
                            // $change_return = $this->dummyPaymentLine;
                            // $change_return['amount'] = $input['change_return'];
                            // $change_return['is_return'] = 1;
                            // if (!empty($input['change_return_id'])) {
                            //     $change_return['id'] = $input['change_return_id'];
                            // }
                            // $input['payment'][] = $change_return;

                            $this->transactionUtil->createOrUpdatePaymentLines($transaction, $input['payment'],$app_order_id , $business_id, $user_id);

                            //Update cash register
                            $this->cashRegisterUtil->updateSellPayments($status_before, $transaction, $input['payment'], $user_id,$app_order_id);
                        }

                        //Check for final and do some processing.
                        if ($input['status'] == 'final') {
                            //Check and update reward point
                            if ($business_details->enable_rp == 1) {
                                $this->transactionUtil->updateCustomerRewardPoints($contact_id, $transaction->rp_earned, $rp_earned_before, $transaction->rp_redeemed, $rp_redeemed_before);
                            }
                        }

                        //Update payment status
                        $payment_status = $this->transactionUtil->updatePaymentStatus($transaction->id, $transaction->final_total,$app_order_id);
                        $transaction->payment_status = $payment_status;
                        //return $this->productUtil->adjustProductStockForInvoice($status_before, $transaction, $input, true, $input);
                        //Update product stock
                        $this->productUtil->adjustProductStockForInvoice($status_before, $transaction, $input, true, $inputRequest);

                        $not_printed_lines = TransactionSellLine::where('app_order_id', $app_order_id)
                                ->where('printed', 0)
                                ->first();
            
                        if (!empty($not_printed_lines)) {
                            Transaction::where('app_order_id', $app_order_id)
                                            ->update(['pending_order' => 1]);
                        }
                        PosResTables::where('app_order_id', $app_order_id)->update(['pax' => $pax]);

                        // Close POS Table
                        $is_table_closed = isset($input['is_table_closed']) ? $input['is_table_closed'] : "";
                        if($is_table_closed === true) {
                            $updated_rows = 0;
                            $updated_rows = PosResTables::where('app_order_id', $app_order_id)
                                            ->orWhere('transaction_id', $transaction->id)
                                            ->update(['seated' => 0]);
                        }
                    }

                    if( $isMoveTable && empty($input['products']) && count($input['products']) == 0 && $is_table_closed ) {
                        $updated_rows = 0;
                        $updated_rows = PosResTables::where('app_order_id', $input['app_order_id'])
                                            ->orWhere('transaction_id', $input['transaction_id'])
                                            ->update(['seated' => 0]);
                    }
                }

                if ( isset($inputRequest['tables']) && !empty($inputRequest['tables']))  {
                    // Dining Tables
                    $diningTables = $inputRequest["tables"];
                    $updated_rows = 0;
                    foreach ($diningTables as $key => $diningTable) {
                        $diningTableStatus = 0;
                        if( $diningTable['status'] === 'final' || $diningTable['status'] === 'draft' )
                            $diningTableStatus = 1;

                        if( isset($diningTable['transaction_id']) && $diningTable['transaction_id'] != null ) {
                            $updated_rows += PosResTables::where('transaction_id', $diningTable['transaction_id'])
                                ->where('seated', 1)
                                ->update(['seated' => $diningTableStatus]);
                        } else {
                            $updated_rows += PosResTables::where('res_table_id', $diningTable['table_id'])
                                ->where('seated', 1)
                                ->update(['seated' => $diningTableStatus]);
                        }
                    }
                }
                
                DB::commit();

                $output = ['msg' => "Sale orders are edited." ];
            }
            else 
            {
                $output = [
                    'errorMessage' => trans("messages.something_went_wrong")
                ];
            }
        } catch (\Exception $e) {
            DB::rollBack();
            \Log::emergency("File:" . $e->getFile(). "Line:" . $e->getLine(). "Message:" . $e->getMessage());
            $msg = trans("messages.something_went_wrong");

            $output = [
                'errorMessage' => $msg,
                "error" => $e->getMessage()
            ];
        }
        return $output;
    }

    public function rpTransactions(Request $request) {

        $input = $request;
        $business_id = $input['business_id'];
        $contact_id = $input['contact_id'];
    
        $transactions = Transaction::where('contact_id', $contact_id)
                                    ->where('business_id', $business_id)
                                    ->orderBy('transaction_date', 'desc')
                                    // ->select('id', 'invoice_no', 'transaction_date', 'rp_redeemed', 'rp_redeemed_amount', 'rp_earned', 'final_total')
                                    ->get();


        if ($transactions->isEmpty()) {
            return response()->json(['errorMessage' => 'No transactions found for the provided contact_id.'], 200);
        }

        $transactionData = [];

        foreach ($transactions as $transaction) {
            if ($transaction->rp_earned != 0 || $transaction->rp_redeemed != 0) {
                $bill_amount = $transaction->final_total;
                if ($transaction->rp_redeemed != 0) {

                    $transactionData[] = [
                        'transaction_id' => $transaction->id,
                        'invoice_no' => $transaction->invoice_no,
                        'transaction_date' => $transaction->transaction_date,
                        'bill_amount' => $bill_amount,
                        'rp_type' => 'redeemed',
                        'rp_used' => round($transaction->rp_redeemed, 2),
                        'rp_used_amount' =>round($transaction->rp_redeemed_amount, 2),
                        'rp_expiry_date' => 'NA'
                    ];
                }

                if ($transaction->rp_earned != 0) {
                    

                    $transactionData[] = [
                        'transaction_id' => $transaction->id,
                        'invoice_no' => $transaction->invoice_no,
                        'transaction_date' => $transaction->transaction_date,
                        'bill_amount' => $bill_amount,
                        'rp_type' => 'earned',
                        'rp_used' => round($transaction->rp_earned, 2),
                        'rp_used_amount' => round($transaction->rp_earned, 2),
                        'rp_expiry_date' => 'NA'
                    ];  
                }
            }
        }

        $contact = Contact::select('total_rp')
                          ->find($contact_id);

        if (!$contact) {
            return response()->json(['errorMessage' => 'No contact found for the provided contact_id.'], 200);
        }

        return response()->json([
            'transactions' => $transactionData,
            'total_rp' => $contact->total_rp
        ]);
    }

    function void_items($items, $transaction_id, $location_id) {
        
        if (!empty($items) && count($items) > 0) {
            $deleted_lines = TransactionSellLine::where('transaction_id', $transaction_id)
                                                    ->whereIn('id', $items)
                                                    ->select('id')->get()->toArray();
            
            $combo_delete_lines = TransactionSellLine::whereIn('parent_sell_line_id', $deleted_lines)->where('children_type', 'combo')->select('id')->get()->toArray();
            $modifier_delete_lines = TransactionSellLine::whereIn('parent_sell_line_id', $deleted_lines)->where('children_type', 'modifier')->select('id')->get()->toArray();
            
            $deleted_lines = array_merge($deleted_lines, $combo_delete_lines, $modifier_delete_lines);
            
            //$adjust_qty = $status_before == 'draft' ? false : true;
            $adjust_qty = true;

            $this->transactionUtil->saveVoidSellLines($deleted_lines, $location_id, $adjust_qty);
        }
    }
}
