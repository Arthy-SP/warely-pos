<?php
namespace App\Http\Controllers\API;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Carbon\Carbon;
use App\User;
use App\BusinessLocation;
use App\Reservation;
use Illuminate\Support\Facades\DB;

class ReservationController extends Controller
{
    /**
     * Create Reservation
     *
     * @param  [int] token, user_id, prefix, name,pax, reservation_date, phobe_number, void
     * @return [json] array
     */
    public function save_reservation(Request $request)
    {
        $input = $request;

        if(isset($input['token']))
        {
            $result = User::checkUserToken($input['token'], $input['user_id']);

            if($result)
            {
                $reservation = Reservation::create([
                    'business_id' => $input['business_id'],
                    'location_id' => $input['location_id'],
                    'prefix' => $input['prefix'],
                    'name' => $input['name'],
                    'pax' => $input['pax'],
                    'reservation_date' => $input['reservation_date'],
                    'phone_number' => $input['phone_number'],
                    'deposit' => $input['deposit'],
                    'void' => $input['void']
                ]);

                return['msg' => "Reservation is added."];
            }
            else
            {
                return["errorMessage"=>'Invalid token.'];
            }
        }
        else
        {
            return["errorMessage"=>'Invalid token.'];
        }
    }

    /**
     * Get Reservation
     *
     * @return [json] array
     */
    public function get_reservation(Request $request)
    {
        $input = $request;

        if(isset($input['token']))
        {
            $result = User::checkUserToken($input['token'], $input['user_id']);

            if($result)
            {
                $reservation = Reservation::where('business_id', $input['business_id'])
                                    ->where('location_id', $input['location_id'])
                                    ->where('void', 0)
                                    ->whereDate('reservation_date','>=', Carbon::today())
                                    ->get();

                return ($reservation);
            }
            else
            {
                return["errorMessage"=>'Invalid token.'];
            }
        }
        else
        {
            return["errorMessage"=>'Invalid token.'];
        }
    }

    /**
     * Void Reservation
     *
     * @return [json] array
     */
    public function void_reservation(Request $request)
    {
        $input = $request;

        if(isset($input['token']))
        {
            $result = User::checkUserToken($input['token'], $input['user_id']);

            if($result)
            {
                $reservation = Reservation::where('id', $input['reservation_id'])->firstOrFail();
                $reservation_void = [
                    'void' => 1
                ];
                $reservation->fill($reservation_void);
                $reservation->update();

                return['msg' => "Reservation is voided."];
            }
            else
            {
                return["errorMessage"=>'Invalid token.'];
            }
        }
        else
        {
            return["errorMessage"=>'Invalid token.'];
        }
    }
    
    /**
     * Update Reservation
     *
     * @return [json] array
     */
    public function update_reservation(Request $request)
    {
        $input = $request;

        if(isset($input['token']))
        {
            $result = User::checkUserToken($input['token'], $input['user_id']);

            if($result)
            {
                $reservation = Reservation::where('id', $input['reservation_id'])->firstOrFail();
                $reservation_data = [
                    'prefix' => $input['prefix'],
                    'name' => $input['name'],
                    'pax' => $input['pax'],
                    'reservation_date' => $input['reservation_date'],
                    'phone_number' => $input['phone_number'],
                    'deposit' => $input['deposit']
                ];
                $reservation->fill($reservation_data);
                $reservation->update();

                return['msg' => "Reservation is updated."];
            }
            else
            {
                return["errorMessage"=>'Invalid token.'];
            }
        }
        else
        {
            return["errorMessage"=>'Invalid token.'];
        }
    }
}