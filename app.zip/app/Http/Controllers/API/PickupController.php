<?php
namespace App\Http\Controllers\API;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Carbon\Carbon;
use App\User;
use App\BusinessLocation;
use App\Transaction;
use App\Utils\BusinessUtil;
use Illuminate\Support\Facades\DB;

class PickupController extends Controller
{
    protected $businessUtil;

    /**
     * Constructor
     *
     * @param Util $commonUtil
     * @return void
     */
    public function __construct(
        BusinessUtil $businessUtil
    ) {
        $this->businessUtil = $businessUtil;
    }
    
    /**
     * Find pickcup store
     *
     * @param  [int] business_id
     * @return [json] business_location_list array
     */
    public function find_pickup_store(Request $request)
    {
        $business_id = $request['business_id'];
        $business_locations = BusinessLocation::where('business_id', $business_id)
                                            ->where('is_active', 1)
                                            ->get();
        $business = $this->businessUtil->getDetails($business_id);
        // echo "<pre>";
        // print_r($business_locations);die;
        $pos_settings = json_decode($business->pos_settings);
        
        $business_location_list = [];
        foreach ($business_locations as $key => $business_location) {
            $business_location_list[$key]["id"] = $business_location["id"];
            $business_location_list[$key]["name"] = $business_location["name"];
            $business_location_list[$key]["address"] = $business_location["city"];
            $business_location_list[$key]["phone"] = $business_location["mobile"];
            $business_location_list[$key]["paynow_number"] = $business_location["paynow_number"];
            $business_location_list[$key]["custom_field1"] = $business_location["custom_field1"];
            $business_location_list[$key]["custom_field2"] = json_decode($business_location["custom_field2"]);
            $business_location_list[$key]["custom_field3"] = json_decode($business_location["custom_field3"]);
            $business_location_list[$key]['amount_rounding_method'] = $pos_settings->amount_rounding_method;
            
            if(!empty($business_location->cds)) {
                // $business_location_list[$key]['cds'] = asset('/uploads/cds/' . rawurlencode($business_location->cds));
                $business_location_list[$key]['cds'] = config('constants.awsS3BaseUrl') . "/" . config('constants.awsS3Env') . "/cds/" . rawurlencode($business_location->cds);
            } else {
                $business_location_list[$key]['cds'] = "";
            }
            
            if(!empty($business_location->cds_logo_image)) {
                // $business_location_list[$key]['cds_logo_image'] = asset('/uploads/cds/' . rawurlencode($business_location->cds_logo_image));
                $business_location_list[$key]['cds_logo_image'] = config('constants.awsS3BaseUrl') . "/" . config('constants.awsS3Env') . "/cds/" . rawurlencode($business_location->cds_logo_image);
            } else {
                $business_location_list[$key]['cds_logo_image'] = "";
            }
            
            
            if(!empty($business_location["custom_field1"]))
            {
                $open_close_time = explode(' - ', $business_location["custom_field1"]);
                $is_open = Carbon::now()->between(
                        Carbon::parse($open_close_time[0]), 
                        Carbon::parse($open_close_time[1])
                );
                $business_location_list[$key]["is_open"] = $is_open;
                $business_location_list[$key]["open_time"] = $open_close_time[0];
                $business_location_list[$key]["close_time"] = $open_close_time[1];
            }
            else
            {
                $business_location_list[$key]["is_open"] = false;
                $business_location_list[$key]["open_time"] = "";
                $business_location_list[$key]["close_time"] = "";
            }
        }
        
        return response()->json([
            'business_location' => $business_location_list
        ]);
    }

    public function track_pickup_order(Request $request)
    {
        // $number =  "1122334455667788";
        // $masked =  str_pad(substr($number, -4), strlen($number), '*', STR_PAD_LEFT);
        // print $masked;
        $business_id = $request['business_id'];
        $location_id = $request['location_id'];
        $contact_id = $request['contact_id'];

        $query = Transaction::leftJoin(
                            'transaction_payments AS TP',
                            'transactions.id',
                            '=',
                            'TP.transaction_id'
                        )
                        ->leftJoin(
                            'delivery_details AS DD',
                            'transactions.id',
                            '=',
                            'DD.transaction_id'
                        )
                        ->leftJoin(
                            'business_locations AS BL',
                            'DD.outlet',
                            '=',
                            'BL.id'
                        )
                        ->where('transactions.business_id', $business_id)
                        ->where('transactions.location_id', $location_id)
                        ->where('transactions.contact_id', $contact_id)
                        ->where('transactions.type', 'sell')
                        ->where('transactions.type_for_api', 'Pickup')
                        ->where('transactions.status', 'final')
                        ->where('transactions.pickup_completed', 0)
                        ->whereDate('transactions.created_at','=', Carbon::today());

        $track_orders = $query->orderBy('transactions.id', 'desc')
                        ->select('transactions.id as transaction_id', 'transactions.ref_no', 'transactions.order_no', 'transactions.pickup_completed', 'TP.last_4_card_digits', 
                        'TP.card_type', 'DD.d_date', 'DD.d_time', 'BL.name as business_location_name', 'BL.mobile as business_location_mobile')
                        ->get();
        
        if(count($track_orders) == 0) {
            $track_order_result = ["errorMessage" => 'Order not found.'];
        } else {
            foreach ($track_orders as $key => $track_order) {
                $track_order['last_4_card_digits'] = "**** **** **** ".$track_order['last_4_card_digits'];
                //$track_order->last_4_card_digits = str_pad($track_order->last_4_card_digits, 16, '*', STR_PAD_LEFT);
                $track_order_result[] = $track_order;
            }
        }

        return $this->respond($track_order_result);
    }

    function get_pickup_order(Request $request)
    {
        $user_data = $request->only('business_id', 'location_id', 'token','user_id');
        //return $user_data;
        if(isset($user_data['token']))
        {
            $result = User::checkUserToken($user_data['token'], $user_data['user_id']);

            if($result)
            {  
                $business_id = $user_data['business_id'];
                $location_id = $user_data['location_id'];
                $transaction_status = "final";
                $created_at = null;
                $type = "Pickup"; //All Pickup

                $query = Transaction::leftJoin(
                    'transactions AS SR',
                    'transactions.id',
                    '=',
                    'SR.return_parent_id'
                )
                ->leftJoin(
                    'delivery_details AS DD',
                    'transactions.id',
                    '=',
                    'DD.transaction_id'
                )
                ->where('transactions.business_id', $business_id)
                ->where('transactions.location_id', $location_id)
                ->where('transactions.type', 'sell')
                ->where('transactions.is_direct_sale', 0)
                ->where('transactions.type_for_api', $type)
                ->where('transactions.status', $transaction_status);

                $transactions = $query->orderBy('transactions.created_at', 'desc')
                                    ->groupBy('transactions.id')
                                    ->select('transactions.*', 'SR.refund_all', 'DD.d_time')
                                    ->with(['contact'])
                                    ->get();
                
                return ($transactions);

            }
            else
            {
                return["errorMessage"=>'Invalid token.'];
            }
        }
        else
        {
            return["errorMessage"=>'Invalid token.'];
        }
    }

    public function update_pickup_completed(Request $request)
    {
        $transaction_id = $request['transaction_id'];
        $pickup_completed = $request['pickup_completed'];
        $token = $request['token'];
        $user_id = $request['user_id'];
        
        if(isset($token))
        { 
            $result = User::checkUserToken($token, $user_id);

            if($result)
            {
                try {
                    $transaction = Transaction::where('id', $transaction_id)->firstOrFail();
                    $update_complete_status = [
                        'pickup_completed' => $pickup_completed
                    ];
                    $transaction->fill($update_complete_status);
                    $transaction->update();

                    $output = ['msg' => "This pickup order is completed." ];

                } catch (\Exception $e) {
                    DB::rollBack();
                    \Log::emergency("File:" . $e->getFile(). "Line:" . $e->getLine(). "Message:" . $e->getMessage());
                    $msg = trans("messages.something_went_wrong");
        
                    $output = [
                                    'errorMessage' => $msg
                                ];
                }
                return $output;
            }
            else
            {
                return["errorMessage"=>'Invalid token.'];
            }
        }
        else
        {
            return["errorMessage"=>'Invalid token.'];
        }
    }
    
    public function check_qr_pickup_preparation_time(Request $request)
    {
        $user_data = $request->only('business_id', 'location_id');

        $result = array();
        $number_pickup_pending = 0;
        $business_id = $user_data['business_id'];
        $location_id = $user_data['location_id'];
        $transaction_status = "final";
        $created_at = null;
        $type = "Pickup"; //All Pickup

        $query = Transaction::leftjoin('transactions AS SR', function ($leftjoin) {
            $leftjoin->on('transactions.id', '=', 'SR.return_parent_id');
        })
        ->leftJoin(
            'delivery_details AS DD',
            'transactions.id',
            '=',
            'DD.transaction_id'
        )
        ->where('transactions.business_id', $business_id)
        ->where('transactions.location_id', $location_id)
        ->where('transactions.type', 'sell')
        ->where('transactions.is_direct_sale', 0)
        ->where('transactions.pickup_completed', 0)
        ->where('transactions.type_for_api', $type)
        ->where('transactions.status', $transaction_status);

        $transactions = $query->orderBy('transactions.created_at', 'desc')
                            ->groupBy('transactions.id')
                            ->select('transactions.*', 'SR.refund_all', 'DD.d_time')
                            ->get();
        
        //$number_of_transaction = count($transactions);

        for($i = 0; $i < count($transactions); $i++) {
            if($transactions[$i]['refund_all'] != 1)
            {
                $number_pickup_pending++;
            }
        }

        $est_prep_time_minutes = $number_pickup_pending * 5;
        $convert_est_prep_time_hours = sprintf('%02d',intdiv($est_prep_time_minutes, 60));
        $convert_est_prep_time_minutes = sprintf('%02d',($est_prep_time_minutes % 60));

        $result[] = [
            'number_pickup_pending' => $number_pickup_pending,
            'est_prep_time_hours' => $convert_est_prep_time_hours,
            'est_prep_time_minutes' => $convert_est_prep_time_minutes
        ];
        
        return ($result);
    }
}