<?php

namespace App\Http\Controllers\API;

use Illuminate\Support\Facades\Log;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use App\User;
use App\Business;
use App\Transaction;
use App\TransactionPayment;
use App\Category;
use App\OpenDrawerRecord;
use App\BusinessLocation;
use App\StoreStatus;
use App\Restaurant\ResTable;
use App\Utils\TransactionUtil;
use App\Http\Controllers\Controller;
use Symfony\Component\HttpFoundation\StreamedResponse;
use Carbon\Carbon;


// PHP-FPM SSE Example: push messages to client

class HandheldController extends Controller
{
    /**
     * All Utils instance.
     *
     */
    protected $transactionUtil;

    public function __construct(TransactionUtil $transactionUtil) {
        $this->transactionUtil = $transactionUtil;
    }

    public function test_fn(Request $request) {
        return ["msg" => 'connection successful.'];
    }

    //TODO login function
    public function login(Request $request)
    {
        $credentials = $request->only('username', 'password');
        // print_r($credentials) ;

        if (Auth::attempt($credentials)) {
            $user = auth()->user();
            $user_role = $user->roles->first();

            if ($user_role->name == 'Admin#' . $user->business_id) {
                $user = Auth::user();
                $userDetails = $user->toArray();
                $default_location = $userDetails['default_location'];
                
                if (!$user->api_token) {
                    $userDetails = $user->toArray();
                    User::generateToken();
                }

                return $this->respond([
                    'data' => $user->toArray(),
                ]);
            }

            return ["status" => 'The system can only be accessed by administrators.'];
        } else {
            return ["status" => 'The username or password is incorrect.'];
        }
    }

    //TODO get list of delivery order
    public function get_delivery_order_list(Request $request)
    {
        $user_data = $request->only('business_id', 'location_id', 'token', 'user_id');
        $test_data = $request->all();
       
        $ist = is_string($test_data);
        
        //if ((isset($user_data['token']))) {
            // $result = User::checkUserToken($user_data['token'], $user_data['user_id']);
            // error_log(($result));
            
            //if ($result) {
                
                $business_id = $user_data['business_id'];
                $location_id = $user_data['location_id'];
                $transaction_status = "final";
                $created_at = null;
                $type = "Delivery"; //All Delivery

                $query = Transaction::leftJoin(
                    'transactions AS SR',
                    'transactions.id',
                    '=',
                    'SR.return_parent_id'
                )
                    ->leftJoin(
                        'delivery_details AS DD',
                        'transactions.id',
                        '=',
                        'DD.transaction_id'
                    )
                    ->where('transactions.business_id', $business_id)
                    ->where('transactions.location_id', $location_id)
                    ->where('transactions.type', 'sell')
                    ->where('transactions.is_direct_sale', 0)
                    ->where('transactions.type_for_api', $type)
                    ->where('transactions.status', $transaction_status)
                    ->where('transactions.lalamove_status', '<>', 'COMPLETED')
                    ->where('transactions.lalamove_status', '<>', 'EXPIRED')
                    ->where('transactions.lalamove_status', '<>', 'REJECTED')
                    ->where('transactions.lalamove_status', '<>', 'CANCELED')
                    ->whereDate('transactions.created_at', '>=', Carbon::today());
                    $transactions = $query->orderBy('transactions.created_at', 'desc')
                    ->groupBy('transactions.id')
                    ->select('transactions.*', 'SR.refund_all', 'DD.d_time', 'DD.d_address')
                    ->with(['contact','sell_lines' => function($q){
                        $q->where('transaction_sell_lines.children_type','<>', 'modifier');
                    }])
                    ->get();
                $object = new \stdClass();
                foreach ($transactions as $key => $value) {
                    $object->$key = $value;
                }
               
                $data = [ "details" => $object];
                // $data = ["details" => $transactions];
                return
                    // json_encode((object) $transactions);
                    // response()->json($transactions);
                response()->json($data);
                    // $transactions;
                    
            // } else {
            //     $error = ["errorMessage" => 'Invalid token.'];
            //     error_log("no result");
            //     return 
            //     response()->json($error);
            // }
        // } else {
        //     $error = ["errorMessage" => 'Invalid token.'];
        //     error_log("no token");
        //     return
        //     response()->json($error);
        // }
    }

    //TODO view order details
    public function view_order(Request $request)
    {
        $user_data = $request->only('business_id', 'location_id', 'token','user_id', 'transaction_id');
        //return $user_data;
        if(isset($user_data['token']))
        {
            $result = User::checkUserToken($user_data['token'], $user_data['user_id']);

            if($result)
            {  
                $id = $user_data['transaction_id'];
                $user_id = $user_data['user_id'];
                $business_id = $user_data['business_id'];
                $location_id = $user_data['location_id'];
                $transaction_status = "final";
                $created_at = null;
                $type = "Delivery"; 

                $all_sale_history = $this->transactionUtil->get_sale_history($user_id, $business_id, $location_id, $transaction_status, $created_at, $type, $id);

                return $all_sale_history;
            }
            else
            {
                return["errorMessage"=>'Invalid token.'];
            }
        }
        else
        {
            return["errorMessage"=>'Invalid token.'];
        }
    }

    //TODO reject order
    public function reject_order(Request $request)
    {
        $input = $request;

        if(isset($input['token']))
        {
            $result = User::checkUserToken($input['token'], $input['user_id']);

            if($result)
            {
                try {
                    if (!empty($input['products'])) 
                    {
                        $user_id = $input['user_id'];
                        $business_id = $input['business_id'];
                        $transaction_id = $input['transaction_id'];
        
                        DB::beginTransaction();
        
                        $sell_return =  $this->transactionUtil->addSellReturnPOS($input, $business_id, $user_id);
        
                        //$receipt = $this->receiptContent($business_id, $sell_return->location_id, $sell_return->id);
                        if (!empty($sell_return) && isset($input['type']))
                        {
                            if($input['type'] == 'Delivery')
                            {
                                $transaction_payment = TransactionPayment::where('transaction_id', $transaction_id)
                                        ->where('stripe_status', 'succeeded')
                                        ->select('stripe_respond')
                                        ->first();
                                
                                if($transaction_payment)
                                {
                                    if($transaction_payment->stripe_respond != null)
                                    {
                                        $stripe_respond = json_decode($transaction_payment->stripe_respond);
                                        $charge_id = $stripe_respond->id;

                                        $input['location_id'] = $sell_return->location_id;
                                        $stripe_sk = $this->transactionUtil->get_stripe_and_lalamove_key($input);
                                        $stripe = new \Stripe\StripeClient(
                                                            $stripe_sk[0]['stripe_sk']
                                                        );
                                        // $stripe = new \Stripe\StripeClient(
                                        //                 $stripe_sk->original[0]['stripe_sk']
                                        //             );
                                        
                                        $stripe_refund_respond = $stripe->refunds->create([
                                            'charge' => $charge_id,
                                            ]);

                                        $stripe_refund_res = [
                                            'stripe_refund_respond' => json_encode($stripe_refund_respond),
                                            'stripe_refund_status' => $stripe_refund_respond->status
                                        ];

                                        TransactionPayment::where('transaction_id', $transaction_id)->update($stripe_refund_res);
                                    }
                                }

                                $transaction = Transaction::where('id', $transaction_id)
                                        ->first();
                                if($transaction->lalamove_orderRef != null)
                                {
                                    $this->transactionUtil->cancel_lalamove_order($transaction->lalamove_orderRef, $transaction->business_id, $transaction->location_id);
                                }
                            }
                        }

                        DB::commit();

                        $output = [
                                    'msg' => 'Success'
                                ];
                    }
                } 
                catch (\Exception $e) 
                {
                    DB::rollBack();
        
                    if (get_class($e) == \App\Exceptions\PurchaseSellMismatch::class) {
                        $msg = $e->getMessage();
                    } else {
                        \Log::emergency("File:" . $e->getFile(). "Line:" . $e->getLine(). "Message:" . $e->getMessage());
                        $msg = __('messages.something_went_wrong');
                    }
        
                    $output = [
                                    'errorMessage' => $msg
                                ];
                }

                return $output;
            }
        }
        else
        {
            return["errorMessage"=>'Invalid token.'];
        }
    }

    public function get_history_info(Request $request) {
        $user_data = $request->only('business_id', 'location_id', 'token','user_id', 'created_at');
        //return $user_data;
        if(isset($user_data['token']))
        {
            $result = User::checkUserToken($user_data['token'], $user_data['user_id']);

            if($result)
            {  
                $user_id = $user_data['user_id'];
                $business_id = $user_data['business_id'];
                $location_id = $user_data['location_id'];
                $transaction_status = "final";
                $created_at = $user_data['created_at'];
                $type = "Handheld_Delivery"; 

                $all_sale_history = $this->transactionUtil->get_sale_history($user_id, $business_id, $location_id, $transaction_status, $created_at, $type);

                return $all_sale_history;
            }
            else
            {
                return["errorMessage"=>'Invalid token.'];
            }
        }
        else
        {
            return["errorMessage"=>'Invalid token.'];
        }
    }

    //TODO print 
    function print_delivery_report(Request $request)
    {
        $user_data = $request->only('business_id', 'location_id', 'token','user_id', 'created_at', 'type', 'start_date', 'end_date');

        if(isset($user_data['token']))
        {
            $result = User::checkUserToken($user_data['token'], $user_data['user_id']);

            if($result)
            {
                try {
                    $user_id = $user_data['user_id'];
                    $business_id = $user_data['business_id'];
                    $location_id = $user_data['location_id'];
                    $transaction_status = "final";
                    $created_at = "";
                    if (!empty($user_data['start_date']) && !empty($user_data['end_date'])) {
                        $start_date = $user_data['start_date'];
                        $end_date = $user_data['end_date'];
                    } else {
                        $start_date = "";
                        $end_date = "";
                    }
                    $type = "";
                    $transaction_id = null;

                    $query = Transaction::leftjoin('transaction_payments as t', 't.transaction_id', '=', 'transactions.id')
                            ->leftjoin('variations as w', 'w.product_id', '=', 'transactions.additional_discount_method')
                            ->leftjoin('tax_rates as z', 'z.id', '=', 'transactions.tax_id')
                            ->leftJoin(
                                'transactions AS SR',
                                'transactions.id',
                                '=',
                                'SR.return_parent_id'
                            )
                            ->with('sell_lines.variations.product')
                            ->with('payment_lines')
                            ->where('transactions.business_id', $business_id)
                            ->where('transactions.location_id', $location_id)
                            ->where('transactions.type', 'sell')
                            ->where('transactions.is_direct_sale', 0)
                            ->where(function($query) {
                                $query->where('transactions.type_for_api', 'Delivery');
                            })
                            ->where(function($sql){
                                $sql->where('transactions.lalamove_status', 'COMPLETED');
                            });
        
                    if (!empty($start_date) && !empty($end_date)) {
                        $dateTime = explode(' ', $start_date);

                        if(count($dateTime) == 2) {
                            $query->where('transactions.transaction_date', '>=', $start_date)
                                ->where('transactions.transaction_date', '<=', $end_date);
                        }
                        else {
                            $query->whereDate('transactions.transaction_date', '>=', $start_date)
                                ->whereDate('transactions.transaction_date', '<=', $end_date);
                        }
                    } else {
                        $query->whereDate('transactions.transaction_date', '=', \Carbon::now()->format('Y-m-d 00:00:00'));
                    }

                    if (!empty($type)) {
                        $query->where('transactions.type_for_api', $type);
                    }
                    
                    if ($transaction_status == 'quotation') {
                        $query->where('transactions.status', 'draft')
                            ->where('transactions.sub_status', 'quotation');
                    } elseif ($transaction_status == 'draft') {
                        $query->where('transactions.status', 'draft')
                            ->whereNull('transactions.sub_status');
                    } else {
                        $query->where('transactions.status', $transaction_status);
                    }

                    $transactions = $query->orderBy('transactions.created_at', 'desc')
                                        ->groupBy('transactions.id')
                                        ->select('transactions.*', 't.method', 't.card_type', 'w.profit_percent', 'z.amount as tax_rate_amount', DB::raw('COUNT(SR.id) as return_exists'), 'SR.refund_all')
                                        ->with(['contact', 'table'])
                                        ->get();

                    //return $transactions;
                    $transaction_result = [];
                    $total_dont_have_line_discount_amt = 0;
                    $refund_total_dont_have_line_discount_amt = 0;
                    
                    foreach ($transactions as $key => $value) 
                    {
                        $item = [];
                        $payments = [];
                        $final_total_for_single_item = 0;
                        $final_total_line_discount_amount = 0;
                        $single_total_quantity_returned = 0;
                        $refund_final_total_for_single_item = 0;
                        $refund_final_total_line_discount_amount = 0;
                        $service_charge_amount = 0;
                        $refund_service_charge_amount = 0;
                        $delivery_charge_amount = 0;
                        $refund_delivery_charge_amount = 0;
                        $increment = 0;
                        
                        foreach ($value['sell_lines'] as $sellLinesKey => $sellLinesValue)
                        {
                            $total_line_discount_amount = 0;
                            $refund_total_line_discount_amount = 0;
                            
                            if($sellLinesValue["parent_sell_line_id"] == null && $sellLinesValue["transaction_id"] == $value['id'])
                            {
                                $adons = [];
                                $total_for_single_item = 0;
                                foreach ($value['sell_lines'] as $sellLinesKey1 => $sellLinesValue1)
                                {
                                    if($sellLinesValue1["parent_sell_line_id"] != null && $sellLinesValue1["parent_sell_line_id"] == $sellLinesValue['id'] && $sellLinesValue1["children_type"] == "modifier")
                                    {
                                        $adons[] = [
                                            'id' => $sellLinesValue1['variations']->id,
                                            'name' => $sellLinesValue1['variations']->name,
                                            'quantity' => $sellLinesValue1["quantity"],
                                            'amount' => $sellLinesValue1['unit_price_before_discount'], //unit_price_before_discount
                                        ];
                                        if($sellLinesValue["quantity_returned"] == "0.0000" && $sellLinesValue["change_price"] == 0)
                                        {
                                            //total modifier price
                                            $total_for_single_item = $total_for_single_item + $sellLinesValue1['unit_price_before_discount'];
                                        }
                                    }
                                }

                                $total_for_single_item = ($sellLinesValue['unit_price_before_discount'] + $total_for_single_item)* $sellLinesValue["quantity"];
                                
                                if($increment == 0)
                                {
                                    $total_dont_have_line_discount_amt = 0;
                                    $refund_total_dont_have_line_discount_amt = 0;
                                }

                                if($sellLinesValue["quantity_returned"] == "0.0000")
                                {
                                    $final_total_for_single_item += $total_for_single_item;
                                    //calculate if line item has line discount
                                    if($sellLinesValue['line_discount_type'] == "fixed")
                                    {
                                        $total_line_discount_amount += $sellLinesValue['line_discount_amount'];
                                    }
                                    else if($sellLinesValue['line_discount_type'] == "percentage")
                                    {
                                        $total_line_discount_amount = (($sellLinesValue['line_discount_amount']/100) * $total_for_single_item) + $total_line_discount_amount;
                                    }
                                    //calculate final total line discount amount
                                    $final_total_line_discount_amount += $total_line_discount_amount;
                                    //total if item dont have line discount amount
                                    if($total_line_discount_amount == 0)
                                    {
                                        $total_dont_have_line_discount_amt += $total_for_single_item;
                                    }
                                }
                                else
                                {
                                    $refund_final_total_for_single_item += $total_for_single_item;
                                    //calculate if refund line item has line discount
                                    if($sellLinesValue['line_discount_type'] == "fixed")
                                    {
                                        $refund_total_line_discount_amount += $sellLinesValue['line_discount_amount'];
                                    }
                                    else if($sellLinesValue['line_discount_type'] == "percentage")
                                    {
                                        $refund_total_line_discount_amount = (($sellLinesValue['line_discount_amount']/100) * $total_for_single_item) + $total_line_discount_amount;
                                    }
                                    //calculate refund final total line discount amount
                                    $refund_final_total_line_discount_amount += $refund_total_line_discount_amount;
                                    //refund total if item dont have line discount amount
                                    if($refund_total_line_discount_amount == 0)
                                    {
                                        $refund_total_dont_have_line_discount_amt += $total_for_single_item;
                                    }
                                    
                                    $single_total_quantity_returned += $sellLinesValue["quantity_returned"]; 
                                }

                                $item[] = [
                                    'id' => $sellLinesValue['id'],
                                    'name' => $sellLinesValue['variations']->product->name,
                                    'quantity' => $sellLinesValue['quantity'],
                                    'quantity_returned' => $sellLinesValue["quantity_returned"],
                                    'amount' => $sellLinesValue['unit_price_before_discount'],
                                    'total_before_tax' => $value['total_before_tax'],
                                    'tax_amount' => $value['tax_amount'],
                                    'line_discount_type' => $sellLinesValue['line_discount_type'],
                                    'line_discount_amount' => $sellLinesValue['line_discount_amount'],
                                    'total_line_discount_amount' => $total_line_discount_amount,
                                    'total_for_single_item' => $total_for_single_item,
                                    'refund_total_line_discount_amount' => $refund_total_line_discount_amount,
                                    // 'weight' => $sellLinesValue['weight'],
                                    // 'total_dont_have_line_discount_amt' => $total_dont_have_line_discount_amt,
                                    // 'sellLinesKey' => $sellLinesKey,
                                    'adons' => $adons,
                                ];

                                $increment++;
                            }
                        }
                        
                        //calculate total discount amount and addon discount amount (e.g. Student discount)
                        if($value['discount_type'] == "fixed")
                        {
                            $discount_amount = $value['discount_amount'] + $final_total_line_discount_amount;
                            $addon_discount_amount = $value['discount_amount'];
                        }
                        else if($value['discount_type'] == "percentage")
                        {
                            $discount_amount = ($value['discount_amount'] * $total_dont_have_line_discount_amt) + $final_total_line_discount_amount;
                            $addon_discount_amount = $value['discount_amount'] * $total_dont_have_line_discount_amt;
                        }
                        //calculate servive charge amount
                        $service_charge_amount = 0;
                        if($final_total_for_single_item > 0) {
                            $delivery_charge_amount = $value['delivery_charges'];
                        }

                        //calculate total discount amount and addon discount amount (e.g. Student discount)
                        if($value['discount_type'] == "fixed")
                        {
                            $refund_discount_amount = $value['discount_amount'] + $refund_final_total_line_discount_amount;
                            $refund_addon_discount_amount = $value['discount_amount'];
                        }
                        else if($value['discount_type'] == "percentage")
                        {
                            $refund_discount_amount = ($value['discount_amount'] * $refund_total_dont_have_line_discount_amt) + $refund_final_total_line_discount_amount;
                            $refund_addon_discount_amount = $value['discount_amount'] * $refund_total_dont_have_line_discount_amt;
                        }

                        $refund_service_charge_amount = 0;
                        if($refund_final_total_for_single_item > 0) {
                            $refund_delivery_charge_amount = $value['delivery_charges'];
                        }

                        $refund_final_total_without_discount = 0;
                        $final_total_without_discount = 0;
                        $final_total_with_discount = 0;
                        
                        $tax_amount = 0;
                        $refund_tax_amount = 0;
                        if($value['tax_id'] != null)
                        {
                            $tax_amount = ($value['tax_rate_amount']/100) * ($final_total_for_single_item);

                            $refund_tax_amount = ($value['tax_rate_amount']/100) * ($refund_final_total_for_single_item);
                        }

                        $final_total = $final_total_for_single_item + $tax_amount + $delivery_charge_amount;
                        $final_total_without_discount = $final_total_for_single_item + $tax_amount + $delivery_charge_amount - $discount_amount;
                        $final_total_with_discount = $final_total_for_single_item + $tax_amount + $delivery_charge_amount;
                        $refund_final_total_without_discount = $refund_final_total_for_single_item + $refund_tax_amount + $refund_delivery_charge_amount - $refund_discount_amount;
                        
                        // For multiple payment
                        foreach($value['payment_lines'] as $payment_lines_key => $payment_line){
                            if(count($value['payment_lines']) == 1) {
                                $cash_received_amount = $final_total;
                            } else {
                                $cash_received_amount = $payment_line['amount'];
                            }
                            $payments[] = [
                                'transaction_payment_id' => $payment_line['id'],
                                'method' => $payment_line['method'],
                                'card_type' => $payment_line['card_type'],
                                'last_4_card_digits' => $payment_line['last_4_card_digits'],
                                'received_amount' => $cash_received_amount
                            ];
                        }

                        $transaction_result[] = [
                            'id' => $value['id'],
                            'transaction_date' => $value['transaction_date'],
                            'table' => '',
                            'pax' => '',
                            'type' => $value['type'],
                            'total' => $final_total,
                            'paymentType' => $value['method'],
                            'card_type' => $value['card_type'],
                            'tax_amount' => $tax_amount,
                            'addon_discount' => ($value['profit_percent'] == null ? 0 : $value['profit_percent']),
                            'discount_type' => $value['discount_type'],
                            'discount_amount' => $discount_amount,
                            'service_charge_amount' => $service_charge_amount,
                            'delivery_charge_amount' => $delivery_charge_amount,
                            'tax_rate_amount' => $value['tax_rate_amount'],
                            'profit_percent' => ($value['profit_percent'] == null ? 0 : $value['profit_percent']),
                            'return_exists' => $value['return_exists'],
                            'refund_all' => $value['refund_all'],
                            'additional_discount_method' => $value['additional_discount_method'],
                            'rp_redeemed_amount' => $value['rp_redeemed_amount'],
                            'addon_discount_amount' => $addon_discount_amount,
                            'final_total_line_discount_amount' => $final_total_line_discount_amount,
                            'total_dont_have_line_discount_amt' => $total_dont_have_line_discount_amt,
                            'final_total_for_single_item' => $final_total_for_single_item,
                            'final_total_without_discount' => $final_total_without_discount,
                            'final_total_with_discount' => $final_total_with_discount,
                            'single_total_quantity_returned' => $single_total_quantity_returned,
                            'refund_final_total_without_discount' => $refund_final_total_without_discount,
                            'item' => $item,
                            'payments' => $payments
                        ];
                    }
                    // return $transaction_result;
                    $all_discounts_addons = Category::join('products', 'categories.id', '=', 'products.category_id')
                                        ->join('product_locations', 'products.id', '=', 'product_locations.product_id')
                                        ->join('variations', 'products.id', '=', 'variations.product_id')
                                        ->select('products.*','categories.name AS category','variations.id AS variation_id','variations.default_sell_price','variations.profit_percent')
                                        ->where('products.business_id', $business_id)
                                        ->where('product_locations.location_id', $location_id)
                                        ->where('categories.short_code', '=', '00100')
                                        ->groupBy('products.name')
                                        ->orderBy('products.name', 'asc')
                                        ->get()
                                        ->toArray();
        
                    $collection_details_total = 0;
                    $collection_details_result = [];
                    $payment_method_arr = [];
                    $sales_details = 0;
                    $total_discount = 0;
                    $final_total_line_discount_amount = 0;
                    $total_service_charge_amount = 0;
                    $total_delivery_charge_amount =0;
                    $total_tax_amount = 0;
                    $customer_reward = 0;
                    $addon_discount_result = [];
                    $total_addon_discount_amount = 0;
                    $no_of_receipts = 0;
                    $pax = 0;
                    $total_quantity_returned = 0;
                    $total_refund = 0;
                    foreach ($transaction_result as $key => $transactionValue) {
                        //table data
                        $table_query = Transaction::leftjoin('pos_res_tables as t', 't.transaction_id', '=', 'transactions.id')
                                                ->leftjoin('res_tables as z', 'z.id', '=', 't.res_table_id')
                                                ->where('transactions.id', $transactionValue['id'])
                                                ->select('t.res_table_id', 'pax', 'z.name')
                                                ->get();

                        $sales_details += $transactionValue['final_total_with_discount'];
                        $total_discount += $transactionValue['discount_amount'];
                        $final_total_line_discount_amount += $transactionValue['final_total_line_discount_amount'];
                        $total_service_charge_amount += $transactionValue['service_charge_amount'];
                        $total_delivery_charge_amount += $transactionValue['delivery_charge_amount'];
                        $total_tax_amount += $transactionValue['tax_amount'];
                        $customer_reward += $transactionValue['rp_redeemed_amount'];
                        $total_quantity_returned += $transactionValue['single_total_quantity_returned'];
                        $total_refund += $transactionValue['refund_final_total_without_discount'];
                        $no_of_receipts += 1;
                        if($table_query[0]['pax'] != null)
                        {
                            $pax += $table_query[0]['pax'];
                        }
                        
                        foreach ($transactionValue['payments'] as $paymentKey => $transactionPayment)
                        {
                            if($transactionPayment['method'] == "cash")
                            {
                                if(in_array($transactionPayment['method'], $payment_method_arr))
                                {
                                    foreach ($collection_details_result as $key => $collectionDetailsValue) {
                                        if($collectionDetailsValue['payment_method'] == $transactionPayment['method'])
                                        {
                                            $collection_details_result[$key]['quantity'] = $collectionDetailsValue['quantity'] + 1;
                                            $collection_details_result[$key]['payment_total_amount'] = $collectionDetailsValue['payment_total_amount'] + $transactionPayment['received_amount'] - $transactionValue['rp_redeemed_amount'];
                                        }
                                    }
                                }
                                else
                                {
                                    array_push($payment_method_arr, $transactionPayment['method']);

                                    $collection_details_result[] = [
                                        'payment_method' => $transactionPayment['method'],
                                        'quantity' => 1,
                                        'payment_total_amount' => $transactionPayment['received_amount'] - $transactionValue['rp_redeemed_amount'],
                                    ];
                                }
                            }
                            else
                            {
                                if(in_array($transactionPayment['card_type'], $payment_method_arr))
                                {
                                    foreach ($collection_details_result as $key => $collectionDetailsValue) {
                                        if($collectionDetailsValue['payment_method'] == $transactionPayment['card_type'])
                                        {
                                            $collection_details_result[$key]['quantity'] = $collectionDetailsValue['quantity'] + 1;
                                            $collection_details_result[$key]['payment_total_amount'] = $collectionDetailsValue['payment_total_amount'] + $transactionPayment['received_amount'] - $transactionValue['rp_redeemed_amount'];
                                        }
                                    }
                                }
                                else
                                {
                                    array_push($payment_method_arr, $transactionPayment['card_type']);

                                    $collection_details_result[] = [
                                        'payment_method' => $transactionPayment['card_type'],
                                        'quantity' => 1,
                                        'payment_total_amount' => $transactionPayment['received_amount'] - $transactionValue['rp_redeemed_amount'],
                                    ];
                                }
                            }
                        }
                        
                        $collection_details_total += $transactionValue['final_total_without_discount'];
                    }
                    //return $collection_details_result;
                    //-------------------------------CHECK OPEN DRAWER RECORD--------------------------------------------
                    $cash_in_or_out_amount = 0;
                    $open_drawer_status_arr = [];
                    $open_drawer_status_result = [];

                    $open_drawer_query = OpenDrawerRecord::where('open_drawer_records.business_id', $business_id)
                                        ->where('open_drawer_records.location_id', $location_id);
                    
                    if (!empty($start_date) && !empty($end_date)) {
                        $open_drawer_query->whereDate('open_drawer_records.created_at', '>=', $start_date)
                            ->whereDate('open_drawer_records.created_at', '<=', $end_date);
                    } else {
                        $open_drawer_query->whereDate('open_drawer_records.created_at', '=', \Carbon::now()->format('Y-m-d 00:00:00'));
                    }

                    $open_drawer_record = $open_drawer_query->select('open_drawer_records.*')
                                        ->get();
                    
                    if(count($open_drawer_record) > 0)
                    {
                        foreach ($open_drawer_record as $key => $openDrawerValue) {
                            if(in_array($openDrawerValue['status'], $open_drawer_status_arr))
                            {
                                foreach ($open_drawer_status_result as $rkey => $openDrawerStatusValue) {
                                    if($openDrawerStatusValue['status'] == $openDrawerValue['status'])
                                    {
                                        $open_drawer_status_result[$rkey]['quantity'] = $openDrawerStatusValue['quantity'] + 1;
                                        $open_drawer_status_result[$rkey]['cash_in_or_out_amount'] = $openDrawerStatusValue['cash_in_or_out_amount'] + $openDrawerValue['amount'];
                                    }
                                }
                            }
                            else
                            {
                                array_push($open_drawer_status_arr, $openDrawerValue['status']);

                                $open_drawer_status_result[] = [
                                    'status' => $openDrawerValue['status'],
                                    'quantity' => 1,
                                    'cash_in_or_out_amount' => $openDrawerValue['amount'],
                                ];
                            }

                            if($openDrawerValue['status'] == "cash in")
                            {
                                $cash_in_or_out_amount += $openDrawerValue['amount'];
                            }
                            else if($openDrawerValue['status'] == "cash out")
                            {
                                $cash_in_or_out_amount -= $openDrawerValue['amount'];
                            }
                        }
                    }
                    
                    //--------------------------------CHECK OPEN DRAWER RECORD END----------------------------------------
                    foreach ($all_discounts_addons as $all_discounts_addons_key => $allDiscountsAddonsValue) {
                        $addon_discount_amount = 0;
                        foreach ($transaction_result as $key => $transactionValue) {
                            if($allDiscountsAddonsValue["id"] == $transactionValue['additional_discount_method'])
                            {
                                $addon_discount_amount += $transactionValue['addon_discount_amount'];
                            }
                        }
                        
                        $addon_discount_result[] = [
                            'addon_discount_id' => $allDiscountsAddonsValue['id'],
                            'addon_discount_name' => $allDiscountsAddonsValue['name'],
                            'addon_discount_amount' => $addon_discount_amount,
                        ];

                        $total_addon_discount_amount += $addon_discount_amount;
                    }
                    
                    $total_previous_sale = $this->transactionUtil->get_previous_sale($user_id, $business_id, $location_id, $transaction_status, $created_at, $type, $transaction_id, $start_date, $end_date);
                    
                    $total_previous_cash_in_or_out = $this->transactionUtil->get_previous_cash_in_or_out($user_id, $business_id, $location_id, $transaction_status, $created_at, $type, $transaction_id, $start_date, $end_date);

                    $tax_rates = $this->transactionUtil->get_business_tax_rates($business_id);
                    
                    $sales_result[] = [
                        "collection_details_result" => $collection_details_result,
                        "open_drawer_status_result" => $open_drawer_status_result,
                        "collection_details_total"  => $collection_details_total + $cash_in_or_out_amount,
                        "sales_details"             => $sales_details, 
                        "less_foc"                  => 0,
                        "gross_sales"               => $sales_details,
                        "item_discount"             => $final_total_line_discount_amount,
                        "total_discount"            => 0,
                        "addon_discount_amount"     => $addon_discount_result,
                        "discount_total"            => $final_total_line_discount_amount + $total_addon_discount_amount,
                        "service_charge_amount"     => $total_service_charge_amount,
                        "delivery_charge_amount"     => $total_delivery_charge_amount,
                        "tax_amount"                => $total_tax_amount,
                        "customer_reward"           => $customer_reward,
                        "net_sales"                 => $sales_details - $final_total_line_discount_amount - $total_addon_discount_amount - $total_service_charge_amount - $total_tax_amount - $total_delivery_charge_amount,
                        "total_sales"               => $sales_details - ($final_total_line_discount_amount + $total_addon_discount_amount),
                        "rounding"                  => 0,
                        "total_collection"          => $sales_details - ($final_total_line_discount_amount + $total_addon_discount_amount),
                        "no_of_receipts"            => $no_of_receipts,
                        "average_per_receipt"       => $no_of_receipts == 0 ? 0.00 : (($collection_details_total + $cash_in_or_out_amount) / $no_of_receipts),
                        "pax"                       => $pax,
                        "average_per_pax"           => $pax == 0 ? 0.00 : (($collection_details_total + $cash_in_or_out_amount) / $pax),
                        "total_refund"              => $total_refund,
                        "no_of_refund"              => $total_quantity_returned,
                        "old_grand_total"           => $total_previous_sale + $total_previous_cash_in_or_out,
                        "new_grand_total"           => $total_previous_sale + $collection_details_total + $total_previous_cash_in_or_out,
                        "tax_rates_list"            => $tax_rates,
                    ];
                    
                    return ["transaction_result" => $transaction_result, "sales_result" => $sales_result, "discount_addons" => $all_discounts_addons];
                    
                } catch(\Exception $e) {
                    $result = ["errorMessage"=>'Result not found.'];
                }
            }
            else
            {
                return["errorMessage"=>'Invalid token.'];
            }
        }
        else
        {
            return["errorMessage"=>'Invalid token.'];
        }
    }

    //TODO change status
    function change_status(Request $request) {
        $user_data = $request->only('business_id', 'location_id', 'token', 'user_id', 'status');
        
        if (isset($user_data['token'])) {
            $result = User::checkUserToken($user_data['token'], $user_data['user_id']);
            $current_time = \Carbon\Carbon::now()->timestamp;
            if ($result) {
                // Update changes
                // require adding new db column
                
                $status = Business::where('id', $result['business_id'])->update(['status' => $user_data['status'], 'status_time_stamp' => $current_time ]);
                if ($status) {
                    return $status;
                } else {
                    return ["errorMessage" => 'business id invalid.'];
                }
            } else {
                return ["errorMessage" => 'Invalid token.'];
            }

        }

        else {
            return ["errorMessage" => 'Invalid token.'];
        }
    }

    //TODO resume transaction
    function resume_status(Request $request)
    {
        $user_data = $request->only('business_id', 'location_id', 'token', 'user_id', 'status');
        $user_id =
        $user_data['user_id'];
        if (isset($user_data['token'])) {
            $result = User::checkUserToken($user_data['token'], $user_data['user_id']);
            if ($result) {
                // Update changes
                // require adding new db column
               
                $status = Business::where('id', $result['business_id'])->update(['status' => $user_data['status']]);
                if ($status) {
                    return $status;
                } else {
                    return ["errorMessage" => 'business id invalid.'];
                }
            } else {
                return ["errorMessage" => 'Invalid token.'];
            }
        } else {
            return ["errorMessage" => 'Invalid token.'];
        }
    }

    //TODO get future orders list
    function get_future_order_list(Request $request) {
        $user_data = $request->only('business_id', 'location_id', 'token', 'user_id');
        

        if (isset($user_data['token'])) {
            $result = User::checkUserToken($user_data['token'], $user_data['user_id']);
            if ($result) {
                // get future order list
                // require adding new db column
            } else {
                return ["errorMessage" => 'Invalid token.'];
            }
        } else {
            return ["errorMessage" => 'Invalid token.'];
        }

    }

    function handheld_get_business_location_details(Request $request)
    {
        $user_data = $request->only('business_location_id', 'token', 'user_id');

        if(isset($user_data['token']))
        {    
            $result = User::checkUserToken($user_data['token'], $user_data['user_id']);

            if($result)
            {
                $business_location_details = BusinessLocation::where('id',$user_data['business_location_id'])->get();

                if (!empty($business_location_details[0]['cds'])) {
                    // $business_location_details[0]['cds'] = asset('/uploads/cds/' . rawurlencode($business_location_details[0]['cds']));
                    $business_location_details[0]['cds'] = config('constants.awsS3BaseUrl') . "/" . config('constants.awsS3Env') . "/cds/" . rawurlencode($business_location_details[0]['cds']);
                }

                if (!empty($business_location_details[0]['cds_logo_image'])) {
                    // $business_location_details[0]['cds_logo_image'] = asset('/uploads/cds/' . rawurlencode($business_location_details[0]['cds_logo_image']));
                    $business_location_details[0]['cds_logo_image'] = config('constants.awsS3BaseUrl') . "/" . config('constants.awsS3Env') . "/cds/" . rawurlencode($business_location_details[0]['cds_logo_image']);
                }

                return $this->respond($business_location_details);
            }
            else
            {
                return["errorMessage"=>'Invalid token.'];
            }
        }
        else {
            return["errorMessage"=>'Invalid token.'];
        }
    }

    //TODO Update Store Status
    function handheld_update_store_status(Request $request)
    {
        $input = $request;
        
        if (isset($input['token'])) {
            $result = User::checkUserToken($input['token'], $input['user_id']);

            if ($result) {
                //create new row in db
                try{
                    
                    //get start_pause and end_pause datetime
                    if(isset($input['sendPauseTime'])){
                        if($input['sendPauseTime'] == '30'){
                            $current_time = \Carbon\Carbon::now();
                            $end_date_time = \Carbon\Carbon::now()->addMinutes(30);
                        }elseif($input['sendPauseTime'] == '1'){
                            $current_time = \Carbon\Carbon::now();
                            $end_date_time = \Carbon\Carbon::now()->addHour($input['sendPauseTime']);
                        }elseif($input['sendPauseTime'] == '24'){
                            $current_time = \Carbon\Carbon::now();
                            $end_date_time = \Carbon\Carbon::now()->addHour($input['sendPauseTime']);
                        }else{
                            $current_time = null;
                            $end_date_time = null;
                        }
                    }

                    //check status and update db accordingly
                    if($input['status'] <> 'Online'){
                        $getLastRow = StoreStatus::latest()->first();
                        if($getLastRow == null){
                            $new_status = StoreStatus::create([
                                'location_id' => $input['location_id'],
                                'status' => $input['status'],
                                'start_date_close' => $current_time,
                                'end_date_close' => $end_date_time,
                                'active' => $input['active']
                            ]);
            
                            return ["msg" => 'New Store Status added.'];
                        }else{
                            if($getLastRow["active"] == 1){
                                $update_active =  StoreStatus::where('id', $getLastRow["id"])
                                ->where('active', 1)
                                ->update(['active' => 0]);
                            }
                        
                            $new_status = StoreStatus::create([
                                'location_id' => $input['location_id'],
                                'status' => $input['status'],
                                'start_date_close' => $current_time,
                                'end_date_close' => $end_date_time,
                                'active' => $input['active']
                            ]);
                            
                            return ["msg" => 'New Store Status added2.'];
                        }
                    }else{
                        $getLastRow = StoreStatus::latest()->first();
                        if($getLastRow == null){
                            return ['msg' => 'Online status.'];
                        }else{
                            if($getLastRow["active"] == 1){
                                $update_active =  StoreStatus::where('id', $getLastRow["id"])
                                ->where('active', 1)
                                ->update(['active' => 0]);
                            }
                            return ['msg' => 'Store Active Updated.'];
                        }
                    }
                }catch(\Exception $e){
                    return ["errorMessage" => $e];
                }
                
            } else {
                return ["errorMessage" => 'Invalid token.'];
            }

        } else {
            return ["errorMessage" => 'Invalid token.'];
        }
    }

    //TODO Get Store Status
    function handheld_get_store_status(Request $request){
        $input = $request;
        
        if (isset($input['token'])) {
            $result = User::checkUserToken($input['token'], $input['user_id']);

            if ($result) {
                try {
                    $select = StoreStatus::select('store_status.*')
                    ->where('location_id', $input['location_id'])
                    ->where('active','=', 1)
                    ->get();

                    return ($select);
                } catch(\Exception $e) {
                    return ["errorMessage" => $e];
                }

            } else {
                return ["errorMessage" => 'Invalid token.'];
            }

        } else {
            return ["errorMessage" => 'Invalid token.'];
        }
    }
}
