<?php

namespace App\Http\Controllers\API;

//use DB;
use Illuminate\Http\Request;
use Illuminate\Http\Response;
use App\Http\Controllers\Controller;
use App\BusinessLocation;
use App\User;
use App\Contact;
use App\CashRegister;
use App\Product;
use App\Category;
use App\DeliveryDetails;
use App\TaxRate;
use App\Variation;
use App\Transaction;
use App\Unit;
use App\Currency;
use App\Business;
use App\CouponUsage;
use App\TransactionSellLine;
use App\TransactionPayment;
use App\Utils\ProductUtil;
use App\Utils\TransactionUtil;
use App\Utils\CashRegisterUtil;
use App\Utils\ContactUtil;
use App\Utils\BusinessUtil;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Mail;
use Carbon\Carbon;
use Stripe;
use Config;
use File;
use App\NfcCard;
use App\NfcTransaction;
use App\VariationLocationDetails;
use App\Notifications\TestEmailNotification;
use Aws\S3\S3Client;
use Aws\Exception\AwsException;
use App\Queue\QueueTable;
use App\PosResTables;
use App\Restaurant\ResTable;
use GuzzleHttp\Client;
use App\TableQrToken;
use App\Utils\Util;
use App\VariationTemplate;
use App\VariationValueTemplate;
use App\ProductVariation;

use \Firebase\JWT\JWT;
use Firebase\JWT\Key;
use Illuminate\Support\Facades\Auth;

class TakeawayController extends Controller
{
    /**
     * All Utils instance.
     *
     */
    protected $contactUtil;
    protected $productUtil;
    protected $transactionUtil;
    protected $cashRegisterUtil;
    protected $businessUtil;
    protected $util;

    /**
     * Constructor
     *
     * @param ProductUtils $product
     * @return void
     */
    public function __construct(
        ContactUtil $contactUtil,
        ProductUtil $productUtil,
        TransactionUtil $transactionUtil,
        CashRegisterUtil $cashRegisterUtil,
        BusinessUtil $businessUtil,
        Util $util
    ) {
        $this->contactUtil = $contactUtil;
        $this->productUtil = $productUtil;
        $this->transactionUtil = $transactionUtil;
        $this->cashRegisterUtil = $cashRegisterUtil;
        $this->businessUtil = $businessUtil;
        $this->util = $util;
        $this->dummyPaymentLine = [
            'method' => 'cash',
            'amount' => 0,
            'note' => '',
            'card_transaction_number' => '',
            'card_number' => '',
            'card_type' => '',
            'card_holder_name' => '',
            'card_month' => '',
            'card_year' => '',
            'card_security' => '',
            'cheque_number' => '',
            'bank_account_number' => '',
            'is_return' => 0,
            'transaction_no' => ''
        ];
    }

    public function fetch_server_timezone()
    {
        $time_zone = date_default_timezone_get();
        $current_time = date("Y-m-d h:i:s");
        return [
            "time_zone" => $time_zone,
            "current_time" => $current_time
        ];
    }

    public function get_all_categories_do(Request $request)
    {
        $user_data = $request->only('business_id', 'business_location_id', 'service_tax_flag');

        $result = $this->get_all_categories_main($user_data);

        return $result;
    }

    public function get_all_categories(Request $request)
    {
        $user_data = $request->only('business_id', 'business_location_id', 'token', 'service_tax_flag', 'user_id', "platform");

        if (isset($user_data['token'])) {
            $result = User::checkUserToken($user_data['token'], $user_data['user_id']);

            if ($result) {
                $result = $this->get_all_categories_main($user_data);

                return $result;
            } else {
                return ["errorMessage" => 'Invalid token.'];
            }
        } else {
            return ["errorMessage" => 'Invalid token.'];
        }
    }

    public function get_all_categories_main($user_data)
    {
        $invoice_no = $this->transactionUtil->getInvoiceNumber($user_data['business_id'], 'pending', $user_data['business_location_id']);

        $category_nfc201_exists = Category::where('short_code', 'nfc201')
                                ->where('business_id', $user_data['business_id'])
                                ->exists();
        $all_business_location_categories = Category::join('products', 'categories.id', '=', 'products.category_id')
            ->join('product_locations', 'products.id', '=', 'product_locations.product_id')
            ->select('categories.*')
            ->where('categories.business_id', $user_data['business_id'])
            ->where('categories.short_code', '!=', '00100')
            ->where('categories.short_code', '!=', '00200')
            ->when($category_nfc201_exists, function($query) {
                    return $query->where('categories.short_code', '!=', 'nfc201');
                })
            ->orWhere('categories.short_code', null)
            ->where('products.business_id', $user_data['business_id'])
            ->where('product_locations.location_id', $user_data['business_location_id'])
            ->when($user_data["platform"] === "kiosk", function ($query) {
                return $query->where('products.not_for_kiosk', '!=', 1);
            })
            ->groupBy('categories.name')
            ->orderBy('categories.sequence', 'asc')
            ->get()
            ->toArray();
        $categories = array();

        for ($i = 0; $i < count($all_business_location_categories); $i++) {
            if ($all_business_location_categories[$i]['color'] == null) {
                $color = "#E3E3E3";
            } else {
                $color = $all_business_location_categories[$i]['color'];
            }
            $categories[] = [
                'id' => $all_business_location_categories[$i]['id'],
                'name' => $all_business_location_categories[$i]['name'],
                'bgColor' => $color,
                'not_for_digital_ordering' => $all_business_location_categories[$i]['not_for_digital_ordering'],
                'not_for_pickup_delivery' => $all_business_location_categories[$i]['not_for_pickup_delivery'],
                'use_as_modifier' => $all_business_location_categories[$i]['use_as_modifier'],
                'use_as_combo_products_category' => $all_business_location_categories[$i]['use_as_combo_products_category']
            ];
        }

        $business_tax_rates = TaxRate::where('business_location_id', $user_data['business_location_id'])
            ->get()
            ->toArray();
        $tax_rates = array();

        for ($i = 0; $i < count($business_tax_rates); $i++) {
            if (strtolower($business_tax_rates[$i]['name']) == 'service charge' && $user_data['service_tax_flag']) {
                $tax_rates[] = [
                    'id' => $business_tax_rates[$i]['id'],
                    'name' => $business_tax_rates[$i]['name'],
                    'amount' => $business_tax_rates[$i]['amount'],
                    'apply_inclusive_gst' => $business_tax_rates[$i]['apply_inclusive_gst'] == 1 ? true : false,
                ];
            } else if (strtolower($business_tax_rates[$i]['name']) !== 'service charge') {
                $tax_rates[] = [
                    'id' => $business_tax_rates[$i]['id'],
                    'name' => $business_tax_rates[$i]['name'],
                    'amount' => $business_tax_rates[$i]['amount'],
                    'apply_inclusive_gst' => $business_tax_rates[$i]['apply_inclusive_gst'] == 1 ? true : false,
                ];
            }
        }

        // $business_details = $this->businessUtil->getDetails($user_data['business_id']);
        $business_details = BusinessLocation::find($user_data['business_location_id']);
        $custom_payment_mode = json_decode($business_details->default_payment_accounts);
        $payment_types = $this->productUtil->payment_types($user_data['business_location_id'], true);
        foreach ($custom_payment_mode as $key => &$value) {
            if (isset($payment_types[$key])) {
                $value->name = $payment_types[$key];
            } else {
                $value->name = null;
            }
         }
     
        $payment_colors_data = Business::where('id', $user_data['business_id'])
                                    ->select('custom_labels')
                                    ->first();
        
        if ($payment_colors_data && !empty($payment_colors_data->custom_labels)) {
            $custom_labels = json_decode($payment_colors_data->custom_labels, true);
            if (isset($custom_labels['payments_color'])) {
                $payment_colors = $custom_labels['payments_color'];
            } else {
                $payment_colors = null;
            }
        } else {
            $payment_colors = null;
        }

        $result = array(
            'invoice_no' => $invoice_no,
            'categories' => $categories,
            'tax' => $tax_rates,
            'payment_mode' => $payment_types,
            'payment_color' => $payment_colors,
            'custom_payment_mode'=>$custom_payment_mode
        );

        return $this->respond($result);
    }

    public function get_invoice_no(Request $request)
    {
        $invoice_data = $request->only('business_id', 'business_location_id');

        $invoice_no = $this->transactionUtil->getInvoiceNumber($invoice_data['business_id'], 'pending', $invoice_data['business_location_id']);
        $order_check_no = $this->transactionUtil->getDisplayInvoiceNumber($invoice_data['business_id'], 'pending', $invoice_data['business_location_id']);

        $result = array(
            'invoice_no' => $invoice_no,
            'order_check_no' => $order_check_no
        );

        return $this->respond($result);
    }

    public function update_pos_selling_status(Request $request) {
        $user_data = $request->only('business_id', 'business_location_id', 'product_id', 'token', 'user_id', 'not_for_selling_by_pos', 'not_for_selling_by_pos_locations');

        if (isset($user_data['token'])) {
            $result = User::checkUserToken($user_data['token'], $user_data['user_id']);

            if ($result) {
                $product = Product::find($user_data['product_id']);
                
                if (!$product) {
                    return response()->json(['errorMessage' => 'Product not found.'], 404);
                }

                $disabledLocations = json_decode($product->not_for_selling_by_pos_locations, true);
                if (is_null($disabledLocations)) {
                    $disabledLocations = [];
                }
                
                if ($user_data['not_for_selling_by_pos'] == 0) {
                    if (($key = array_search($user_data['business_location_id'], $disabledLocations)) !== false) {
                        unset($disabledLocations[$key]);
                    }
                } else {
                    if (!in_array($user_data['business_location_id'], $disabledLocations)) {
                        $disabledLocations[] = $user_data['business_location_id'];
                    }
                }

                $updateData = [
                    'not_for_selling_by_pos' => $user_data['not_for_selling_by_pos'],
                    'not_for_selling_by_pos_locations' => json_encode(array_values($disabledLocations))
                ];

                $affectedRows = Product::where('id', $user_data['product_id'])->update($updateData);

                // Check if any rows were affected
                if ($affectedRows > 0) {
                    return response()->json(['message' => 'Update successful.'], 200);
                } else {
                    return response()->json(['message' => 'No rows were updated.'], 200);
                }

            } else {
                return ["errorMessage" => 'Invalid token.'];
            }
        } else {
            return ["errorMessage" => 'Invalid token.'];
        }
    }
    public function update_modifier_pos_selling_status(Request $request) {
        $user_data = $request->only('business_id', 'business_location_id', 'modifier_id', 'token', 'user_id', 'not_for_selling');

        if (isset($user_data['token'])) {
            $result = User::checkUserToken($user_data['token'], $user_data['user_id']);

            if ($result) {
                $variation_data = Variation::find($user_data['modifier_id']);
                
                if (!$variation_data) {
                    return response()->json(['errorMessage' => 'Modifier not found.'], 404);
                }

                // Update the 'not_for_selling' status
                $affectedRows = Variation::where('id', $user_data['modifier_id'])
                                ->update(['not_for_selling' => $user_data['not_for_selling']]);

                // Check if any rows were affected
                if ($affectedRows > 0) {
                    return response()->json(['message' => 'Update successful.'], 200);
                } else {
                    return response()->json(['message' => 'No rows were updated.'], 200);
                }

            } else {
                return response()->json(['errorMessage' => 'Invalid token.'], 401);
            }
        } else {
            return response()->json(['errorMessage' => 'Invalid token.'], 401);
        }
    }

    public function get_category_products_do(Request $request)
    {
        $user_data = $request->only('business_id', 'business_location_id', 'category_id');
        $result = $this->get_category_products_main($user_data);
        return $result;
    }

    public function get_category_products(Request $request)
    {
        $user_data = $request->only('business_id', 'business_location_id', 'category_id', 'token', 'user_id', "platform");
        if (isset($user_data['token'])) {
            $result = User::checkUserToken($user_data['token'], $user_data['user_id']);

            if ($result) {
                $result = $this->get_category_products_main($user_data);
                return $result;
            } else {
                return ["errorMessage" => 'Invalid token.'];
            }
        } else {
            return ["errorMessage" => 'Invalid token.'];
        }
    }

    public function get_category_products_main($user_data)
    {
        $selling_price_group_id = BusinessLocation::where('id', $user_data['business_location_id'])->select('selling_price_group_id')->first()->selling_price_group_id;

        if (isset($user_data['category_id']) && $user_data['category_id']) {
            $all_category_products = Category::join('products', 'categories.id', '=', 'products.category_id')
                ->join('product_locations', 'products.id', '=', 'product_locations.product_id')
                ->join('variations', 'products.id', '=', 'variations.product_id')
                ->leftJoin('variation_group_prices', function($join) use ($selling_price_group_id) {
                    $join->on('variations.id', '=', 'variation_group_prices.variation_id')
                         ->where('variation_group_prices.price_group_id', '=', $selling_price_group_id);
                })
                ->select('products.*', 'products.not_for_selling_by_pos_locations','categories.use_as_modifier as use_as_modifier', 'categories.id AS category_id', 'categories.name AS category', 'categories.short_code', 'variations.default_sell_price', 'variations.member_price', 'variations.id AS variation_id', 'categories.use_as_combo_products_category as use_as_combo_products_category', 'variation_group_prices.price_inc_tax')
                ->where('products.category_id', $user_data['category_id'])
                ->where('products.business_id', $user_data['business_id'])
                ->where('product_locations.location_id', $user_data['business_location_id'])
                ->where('products.deleted_at', NULL)
                ->where('products.type','!=' ,'retail')
                ->where('products.name', '!=', 'NFC Transaction')
                ->when($user_data["platform"] === "kiosk", function ($query) {
                    return $query->where('products.not_for_kiosk', '!=', 1);
                })
                // ->orderBy('products.name', 'asc')
                ->orderBy('products.sequence', 'asc')
                ->get()
                ->toArray();
        } else {
            $all_category_products = Category::join('products', 'categories.id', '=', 'products.category_id')
                ->join('product_locations', 'products.id', '=', 'product_locations.product_id')
                ->join('variations', 'products.id', '=', 'variations.product_id')
                ->leftJoin('variation_group_prices', function($join) use ($selling_price_group_id) {
                    $join->on('variations.id', '=', 'variation_group_prices.variation_id')
                         ->where('variation_group_prices.price_group_id', '=', $selling_price_group_id);
                })
                ->select('products.*', 'products.not_for_selling_by_pos_locations', 'categories.use_as_modifier as use_as_modifier', 'categories.id AS category_id', 'categories.name AS category', 'categories.short_code', 'variations.default_sell_price', 'variations.member_price', 'variations.id AS variation_id', 'categories.use_as_combo_products_category as use_as_combo_products_category', 'variation_group_prices.price_inc_tax')
                ->where('products.business_id', $user_data['business_id'])
                ->where('product_locations.location_id', $user_data['business_location_id'])
                ->where('products.deleted_at', NULL)
                // ->orderBy('products.name', 'asc')
                ->where('products.type','!=' ,'retail')
                ->where('products.name', '!=', 'NFC Transaction')
                ->when($user_data["platform"] === "kiosk", function ($query) {
                    return $query->where('products.not_for_kiosk', '!=', 1);
                })
                ->orderBy('products.sequence', 'asc')
                ->get()
                ->toArray();
        }
        
        //print_r($all_category_products);

        $result = array();

        for ($i = 0; $i < count($all_category_products); $i++) {
            $modifer_set = Product::where('business_id', $user_data['business_id'])
                ->with(['modifier_sets', 'variations'])
                ->find($all_category_products[$i]['id']);

            if (empty($all_category_products[$i]['weight'])) {
                $price = $all_category_products[$i]['default_sell_price'];
            } else {
                $price = $all_category_products[$i]['default_sell_price'] / floatval($all_category_products[$i]['weight']);
            }

            if (empty($all_category_products[$i]['weight'])) {
                $member_price = $all_category_products[$i]['member_price'];
            } else {
                $member_price = $all_category_products[$i]['member_price'] / floatval($all_category_products[$i]['weight']);
            }

            if (!empty($all_category_products[$i]['image'])) {
                // $image_url = asset('/uploads/img/' . rawurlencode($all_category_products[$i]['image']));
                $image_url = config('constants.awsS3BaseUrl') . "/" . config('constants.awsS3Env') . "/img/" . rawurlencode($all_category_products[$i]['image']);
            } else {
                $image_url = asset('/img/default_food.png');
            }

            $base_unit_multiplier = null;
            $sub_unit_id = null;
            if ($all_category_products[$i]['sub_unit_ids']) {
                $sub_unit_ids = json_decode($all_category_products[$i]['sub_unit_ids']);
                $intArray = array_map('intval', $sub_unit_ids);
                $sub_units = Unit::whereIn('id', $intArray)
                    ->select('base_unit_multiplier', 'actual_name', 'id')
                    ->get();
                if (!empty($sub_units) && count($sub_units)) {
                    $base_unit_multiplier = $sub_units[0]->base_unit_multiplier;
                    $sub_unit_id = $sub_units[0]->id;
                }
            } elseif ($all_category_products[$i]['unit_id']) {
                $unit = Unit::where('id', $all_category_products[$i]['unit_id'])
                    ->select('base_unit_multiplier', 'actual_name')
                    ->first();
                if (!empty($unit)) {
                    $base_unit_multiplier = $unit->base_unit_multiplier;
                }
            }

            $combo_products = [];
            if ($modifer_set->variations && count($modifer_set->variations)) {
                foreach ($modifer_set->variations as $key => $each) {
                    $variation = json_decode($each);
                    if ($variation->combo_variations && count($variation->combo_variations)) {
                        foreach ($variation->combo_variations as $key => $combo_variation) {
                            $combo_product = Variation::where('variations.id', $combo_variation->variation_id)
                                ->join('products AS p', 'variations.product_id', '=', 'p.id')
                                ->select(['p.*', 'variations.name as variation_name', 'variations.id as variation_id'])
                                ->first();
                            $combo_product['quantity'] = round($combo_variation->quantity, 2);

                            $combo_not_for_selling_by_pos_locations = $combo_product['not_for_selling_by_pos_locations'];
                            $combo_product['serving_days'] = json_decode($combo_product['serving_days'], true);

                            if (is_null($serving_days)) {
                                $combo_product['serving_days'] = [];
                            }

                            if (is_null($combo_not_for_selling_by_pos_locations) || trim($combo_not_for_selling_by_pos_locations) === "" || $combo_not_for_selling_by_pos_locations === '[]') {       
                                $combo_product['not_for_selling_by_pos_locations'] = []; 
                            } else {
                                $decoded = json_decode($combo_not_for_selling_by_pos_locations, true);

                                if (json_last_error() === JSON_ERROR_NONE) {
                                    $combo_product['not_for_selling_by_pos_locations'] = $decoded; 
                                } else {
                                    $combo_product['not_for_selling_by_pos_locations'] = []; 
                                }
                            }

                            $combo_suppliers_sku = $combo_product['suppliers_sku'];

                            if (is_null($combo_suppliers_sku) || $combo_suppliers_sku == "null"| $suppliers_sku == "null" || trim($combo_suppliers_sku) === "" || $combo_suppliers_sku === '[]') {
                                $combo_product['suppliers_sku'] = []; 
                            } else {
                                $decodedSku = json_decode($combo_suppliers_sku, true);

                                if (json_last_error() === JSON_ERROR_NONE && is_array($decodedSku)) {
                                    $combo_product['suppliers_sku'] = $decodedSku;
                                } else {
                                    // Check if $suppliers_sku is a comma-separated string
                                    if (strpos($combo_suppliers_sku, ',') !== false) {
                                        $combo_product['suppliers_sku'] = array_map('trim', explode(',', $combo_product['suppliers_sku']));
                                        $combo_product['suppliers_sku'] = array_map(function($sku) {
                                            return trim($sku, '"');
                                        }, $combo_product['suppliers_sku']);
                                    } else {
                                        $combo_product['suppliers_sku'] = [trim($combo_product['suppliers_sku'], '"')];
                                    }
                                }
                            }

                            $serving_days = json_decode($all_category_products[$i]['serving_days'], true);

                            if (is_null($serving_days)) {
                                $serving_days = [];
                            }

                            $combo_products[] = $combo_product;
                        }
                    }
                }
            }


            //REFACTOR check with frontend if using or not 
            // $is_modifier_product = false;
            // if (isset($all_category_products[$i]['use_as_modifier']) && $all_category_products[$i]['use_as_modifier'] && $all_category_products[$i]['use_as_modifier'] > 0) {
            //     $is_modifier_product = true;
            // }

            $not_for_selling_by_pos_locations = $all_category_products[$i]['not_for_selling_by_pos_locations'];

            if (is_null($not_for_selling_by_pos_locations) || trim($not_for_selling_by_pos_locations) === "" || $not_for_selling_by_pos_locations === '[]') {
                $not_for_selling_by_pos_locations = []; 
            } else {
                $decoded = json_decode($not_for_selling_by_pos_locations, true);
    
                if (json_last_error() === JSON_ERROR_NONE) {
                    $not_for_selling_by_pos_locations = $decoded; 
                } else {
                    $not_for_selling_by_pos_locations = []; 
                }
            }

            $suppliers_sku = $all_category_products[$i]['suppliers_sku'];
            
            if (is_null($suppliers_sku) || $suppliers_sku == "null" || trim($suppliers_sku) === "" || $suppliers_sku === '[]') {
                $suppliers_sku = []; 
            } else {
                $decodedSku = json_decode($suppliers_sku, true);

                if (json_last_error() === JSON_ERROR_NONE && is_array($decodedSku)) {
                    $suppliers_sku = $decodedSku;
                } else {
                    // Check if $suppliers_sku is a comma-separated string
                    if (strpos($suppliers_sku, ',') !== false) {
                        $suppliers_sku = array_map('trim', explode(',', $suppliers_sku));
                        $suppliers_sku = array_map(function($sku) {
                            return trim($sku, '"');
                        }, $suppliers_sku);
                    } else {
                        $suppliers_sku = [trim($suppliers_sku, '"')];
                    }
                }
            }

            $serving_days = json_decode($all_category_products[$i]['serving_days'], true);

            if (is_null($serving_days)) {
                $serving_days = [];
            }

            $modifier_sets = $modifer_set->modifier_sets;

            $modifier_set_details = [];
            $open_modifier_count = 0;
            $product_modifier_count = 0;

            foreach ($modifier_sets as $set) {
                if (isset($set['name']) && isset($set['is_open_modifier'])) {
                    $modifier_set_details[] = [
                        'name' => $set['name'],
                        'is_open_modifier' => $set['is_open_modifier']
                    ];
            
                    if ($set['is_open_modifier'] == 1) {
                        $open_modifier_count++;
                    } elseif ($set['is_open_modifier'] == 0) {
                        $product_modifier_count++;
                    }
                }
            }

            $not_for_selling_by_pos_locations = $all_category_products[$i]['not_for_selling_by_pos_locations'];

            if (is_null($not_for_selling_by_pos_locations) || trim($not_for_selling_by_pos_locations) === "" || $not_for_selling_by_pos_locations === '[]') {
                $not_for_selling_by_pos_locations = []; 
            } else {
                $decoded = json_decode($not_for_selling_by_pos_locations, true);
    
                if (json_last_error() === JSON_ERROR_NONE) {
                    $not_for_selling_by_pos_locations = $decoded; 
                } else {
                    $not_for_selling_by_pos_locations = []; 
                }
            }

            $result[] = [
                'id' => $all_category_products[$i]['id'],
                'variation_id' => $all_category_products[$i]['variation_id'],
                'product_type' => $all_category_products[$i]['type'],
                'unit_id' => $all_category_products[$i]['unit_id'],
                'category_id' => $all_category_products[$i]['category_id'],
                'category' => $all_category_products[$i]['category'],
                'short_code' => !empty($all_category_products[$i]['short_code']) ? $all_category_products[$i]['short_code'] : '',
                'name' => $all_category_products[$i]['name'],
                'sequence' => $all_category_products[$i]['sequence'],
                'sku' => $all_category_products[$i]['sku'],
                'product_description' => $all_category_products[$i]['product_description'],
                'image' => $image_url,
                'unit_price' => !empty($all_category_products[$i]['price_inc_tax']) ? $all_category_products[$i]['price_inc_tax'] : $price,
                'weight' => $all_category_products[$i]['weight'],
                'price' => !empty($all_category_products[$i]['price_inc_tax']) ? $all_category_products[$i]['price_inc_tax'] : $price,
                'member_price' => $member_price,
                'modifer_flag' => count($modifer_set->modifier_sets) ? 'true' : 'false',
                'not_for_digital_ordering' => $all_category_products[$i]['not_for_digital_ordering'],
                'not_for_pickup_delivery' => $all_category_products[$i]['not_for_pickup_delivery'],
                'not_for_selling_by_pos' => $all_category_products[$i]['not_for_selling_by_pos'],
                'not_for_selling' => $all_category_products[$i]['not_for_selling'],
                'not_for_selling_by_pos_locations' => $not_for_selling_by_pos_locations,
                'enable_stock' => $all_category_products[$i]['enable_stock'],
                'base_unit_multiplier' => $base_unit_multiplier,
                'sub_unit_id' => $sub_unit_id,
                'kitchen_shorthand' => $all_category_products[$i]['kitchen_shorthand'],
                'name_in_second_language' => $all_category_products[$i]['name_in_second_language'],
                'show_combo_products' => $all_category_products[$i]['show_combo_products'] ? true : false,
                'combo_products' => $combo_products,
                // 'is_modifier_product' => $is_modifier_product,
                'use_as_combo_products_category' => $all_category_products[$i]['use_as_combo_products_category'] ? true : false,
                'combo_products_category_id' => $all_category_products[$i]['combo_products_category_id'],
                'product_custom_field1'=>$all_category_products[$i]['product_custom_field1'],
                'product_custom_field2'=>$all_category_products[$i]['product_custom_field2'],
                'product_custom_field3'=>$all_category_products[$i]['product_custom_field3'],
                'product_custom_field4'=>$all_category_products[$i]['product_custom_field4'],
                'serving_days' => $serving_days,
                'serving_start_time' => $all_category_products[$i]['serving_start_time'],
                'serving_end_time' => $all_category_products[$i]['serving_end_time'],
                'suppliers_sku' => $suppliers_sku,
                'open_modifier_count' => $open_modifier_count,
                'product_modifier_count' => $product_modifier_count,
                'estimated_time' => $all_category_products[$i]['estimated_time'],
                'eligible_for_redeemsg' => $all_category_products[$i]['eligible_for_redeemsg']
            
            ];
        }

        return $this->respond($result);
    }

    function get_product_modifier_do(Request $request)
    {
        $user_data = $request->only('business_id', 'user_id', 'product_id');
        $result = $this->get_product_modifier_main($user_data);
        return $result;
    }

    function get_product_modifier(Request $request)
    {
        $user_data = $request->only('business_id', 'token', 'user_id', 'product_id');

        if (isset($user_data['token'])) {
            $result = User::checkUserToken($user_data['token'], $user_data['user_id']);

            if ($result) {
                try {
                    $result = $this->get_product_modifier_main($user_data);
                    return $result;
                } catch (\Exception $e) {
                    DB::rollBack();
                    \Log::emergency("File:" . $e->getFile() . "Line:" . $e->getLine() . "Message:" . $e->getMessage());
                    $msg = trans("messages.something_went_wrong");

                    return [
                        'errorMessage' => $msg
                    ];
                }
            } else {
                return ["errorMessage" => 'Invalid token.'];
            }
        } else {
            return ["errorMessage" => 'Invalid token.'];
        }
    }

    function get_product_modifier_main($user_data)
    {
        if (isset($user_data['product_id']) && $user_data['product_id']) {

            $modifer_set = Product::where('business_id', $user_data['business_id'])
                ->orderBy('products.sequence', 'asc')
                ->with([
                    'modifier_sets' => function ($q) {
                        $q->orderBy('sequence', 'asc');
                    }
                ])
                ->find($user_data['product_id']);

            $modifer_set_array = [];

            foreach ($modifer_set->modifier_sets as $key => $value) {
                $modifiers = Variation::where('product_id', $modifer_set->modifier_sets[$key]['id'])
                    ->get();

            foreach ($modifiers as $modifier) {
                $modifier->merge_qty = $modifer_set->modifier_sets[$key2]['merge_qty'];
                $modifier->modifier_image = !empty($modifier['modifier_image']) ?
                config('constants.awsS3BaseUrl') . "/" . config('constants.awsS3Env') . "/modifier_images/" . rawurlencode($modifier['modifier_image'])
                : null;

            }

                $modifer_set_array[] = [
                    'id' => $modifer_set->modifier_sets[$key]['id'],
                    'name' => $modifer_set->modifier_sets[$key]['name'],
                    'sequence' => $modifer_set->modifier_sets[$key]['sequence'],
                    'order_limit_at_least' => $modifer_set->modifier_sets[$key]['order_limit_at_least'],
                    'order_limit' => $modifer_set->modifier_sets[$key]['order_limit'],
                    'value' => $modifiers,
                    'not_for_receipt' => $modifer_set->modifier_sets[$key]['not_for_receipt'],
                    'not_for_digital_ordering' => $modifer_set->modifier_sets[$key]['not_for_digital_ordering'],
                    'not_for_pickup_delivery' => $modifer_set->modifier_sets[$key]['not_for_pickup_delivery'],
                    'merge_qty' => $modifer_set->modifier_sets[$key2]['merge_qty']
                ];
            }

            return ($modifer_set_array);
        } else {

            $products = Product::where('business_id', $user_data['business_id'])
                ->orderBy('products.sequence', 'asc')
                ->with([
                    'modifier_sets' => function ($q) {
                        $q->orderBy('sequence', 'asc');
                    }
                ])
                ->get()
                ->toArray();

            $result_array = [];

            foreach ($products as $key1 => $value) {

                if ($products[$key1]['modifier_sets']) {
                    $modifer_set = Product::where('business_id', $user_data['business_id'])
                        ->orderBy('products.sequence', 'asc')
                        ->with([
                            'modifier_sets' => function ($q) {
                                $q->orderBy('sequence', 'asc');
                            }
                        ])
                        ->find($products[$key1]['id']);

                    $modifer_set_array = [];

                    foreach ($modifer_set->modifier_sets as $key2 => $value) {
                        // $modifiers = Variation::where('product_variation_id', $modifer_set->modifier_sets[$key2]['id'])
                        $modifiers = Variation::where('product_id', $modifer_set->modifier_sets[$key2]['id'])
                            ->get();

                        foreach ($modifiers as $modifier) {
                            $modifier->merge_qty = $modifer_set->modifier_sets[$key2]['merge_qty'];
                            $modifier->modifier_image = !empty($modifier['modifier_image']) ?
                            config('constants.awsS3BaseUrl') . "/" . config('constants.awsS3Env') . "/modifier_images/" . rawurlencode($modifier['modifier_image'])
                            : null;
                        }

                        $modifer_set_array[] = [
                            'id' => $modifer_set->modifier_sets[$key2]['id'],
                            'name' => $modifer_set->modifier_sets[$key2]['name'],
                            'value' => $modifiers,
                            'order_limit_at_least' => $modifer_set->modifier_sets[$key2]['order_limit_at_least'],
                            'order_limit' => $modifer_set->modifier_sets[$key2]['order_limit'],
                            'not_for_receipt' => $modifer_set->modifier_sets[$key2]['not_for_receipt'],
                            'not_for_digital_ordering' => $modifer_set->modifier_sets[$key2]['not_for_digital_ordering'],
                            'not_for_pickup_delivery' => $modifer_set->modifier_sets[$key2]['not_for_pickup_delivery'],
                            'merge_qty' => $modifer_set->modifier_sets[$key2]['merge_qty']
                        ];
                    }

                    $result_array[] = [
                        'product_id' => $products[$key1]['id'],
                        'product_name' => $products[$key1]['name'],
                        'modifer_set' => $modifer_set_array
                    ];
                }
            }
            return ($result_array);
        }
    }

    function get_open_modifiers(Request $request)
    {
        $user_data = $request->only('business_id', 'token', 'user_id');

        if (isset($user_data['token'])) {
            $result = User::checkUserToken($user_data['token'], $user_data['user_id']);

            if ($result) {
                try {
                    $products = Product::where('business_id', $user_data['business_id'])
                        ->orderBy('products.sequence', 'asc')
                        ->where('is_open_modifier', 1)
                        ->get()
                        ->toArray();

                    $result_array = [];

                    foreach ($products as $product) {
                        $variations = Variation::where('product_id', $product['id'])
                            ->get();
                            // ->toArray();

                        foreach ($variations as $variation) {
                            $variation->merge_qty = $product['merge_qty']; 
                            $variation->modifier_image = !empty($variation['modifier_image']) 
                            ? config('constants.awsS3BaseUrl') . "/" . config('constants.awsS3Env') . "/modifier_images/" . rawurlencode($variation['modifier_image']) 
                            : '';
                        }

                        $result_array[] = [
                            'product_id' => $product['id'],
                            'product_name' => $product['name'],
                            'is_quick_option' => $product['is_quick_option'] == 1 ? true : false,
                            'merge_qty' => $product['merge_qty'],
                            'variations' => $variations
                        ];
                    }

                    return $result_array;

                } catch (\Exception $e) {
                    DB::rollBack();
                    \Log::emergency("File:" . $e->getFile() . "Line:" . $e->getLine() . "Message:" . $e->getMessage());
                    $msg = trans("messages.something_went_wrong");

                    return [
                        'errorMessage' => $msg
                    ];
                }
            } else {
                return ["errorMessage" => 'Invalid token.'];
            }
        } else {
            return ["errorMessage" => 'Invalid token.'];
        }

    }

    function save_pickup_delivery(Request $request)
    {
        $input = $request;
        $output = $this->saveOrder($input);
        return $output;
    }

    function save_order(Request $request)
    {
        $input = $request;

        if (isset($input['token'])) {
            $result = User::checkUserToken($input['token'], $input['user_id']);

            if ($result) {
                $output = $this->saveOrder($input);
                return $output;
            } else {
                return ["errorMessage" => 'Invalid token.'];
            }
        } else {
            return ["errorMessage" => 'Invalid token.'];
        }
    }

    function save_takeaway_digital_ordering(Request $request)
    {
        $input = $request;
        $input['user_id'] = !empty($input['user_id']) ? $input['user_id']: 2; 
        $output = $this->saveOrder($input);
        return $output;       
    }

    function saveOrder($input)
    {
        $is_direct_sale = false;
        try {
            if (!empty($input['products'])) {
                $business_id = $input['business_id'];
                $transaction_id = (isset($input['transaction_id']) && $input['transaction_id']) ? $input['transaction_id'] : 0;
                $user_id = $input['user_id'];
                $contact_id = $input['contact_id'];
                $app_order_id = isset($input['app_order_id']) ? $input['app_order_id'] : "";

                //$app_item_line_id = isset($input['products'][0]['app_item_line_id']) ? $input['products'][0]['app_item_line_id'] : "";

                if (!empty($input['products'][0]['modifier_app_ids'])) {
                    $modifiers_app_ids = array_column($input['products'], 'modifier_app_ids');
                } else {
                    $modifiers_app_ids = "";
                }
                $discount = [
                    'discount_type' => $input['discount_type'],
                    'discount_amount' => $input['discount_amount']
                ];

                if (isset($input['delivery_charges'])) {
                    $delivery_charges = $input['delivery_charges'];
                } else {
                    $delivery_charges = 0;
                }

                $invoice_total = $this->productUtil->newCalculateInvoiceTotal($input['products'], $input['tax_rate_id'], $discount, $input['service_charges'], true, $delivery_charges);
                //return $invoice_total;
                DB::beginTransaction();

                if ($input['type_for_api'] == "Pickup" || $input['type_for_api'] == "Delivery") {
                    if (strtolower($input['payment'][0]['method']) == "card" && strtolower($input['payment'][0]['card_type']) != "paynow") {
                        $stripeRespond = $this->stripePost($input);
                    }
                }

                if (empty($input['transaction_date'])) {
                    $input['transaction_date'] = \Carbon::now();
                } else {
                    $input['transaction_date'] = $this->productUtil->uf_date($input['transaction_date'], true);
                }

                $input['is_suspend'] = isset($input['is_suspend']) && 1 == $input['is_suspend'] ? 1 : 0;
                if ($input['is_suspend']) {
                    $input['sale_note'] = !empty($input['additional_notes']) ? $input['additional_notes'] : null;
                }
                //transactions table
                if ($transaction_id) {
                    $transaction = $this->transactionUtil->updateSellTransaction($transaction_id, $business_id, $input, $invoice_total, $user_id, $app_order_id);
                } else {
                    $transaction = $this->transactionUtil->createSellTransaction($business_id, $input, $invoice_total, $user_id);
                }
                //transaction_sell_lines table

                if (!empty($transaction->invoice_no)) {
                    $invoice_resp = $transaction->invoice_no;
                } else {
                    $invoice_resp = "";
                }

                if (!empty($transaction->order_check_no)) {
                    $order_check_no = $transaction->order_check_no;
                } else {
                    $order_check_no = "";
                }

                $business_details = $this->businessUtil->getDetails($business_id);
                if (in_array("modifiers", $business_details->enabled_modules)) {
                    $isModuleEnabled = true;
                } else {
                    $isModuleEnabled = false;
                }

                if ( isset($input['void_item_ids']) && !empty($input['void_item_ids']) && $input['transaction_id'] && $input['transaction_id'] ) {
                    $this->void_items($input['void_item_ids'], $input['transaction_id'], $input['location_id']);
                }

                $this->transactionUtil->createOrUpdateSellLines($transaction, $input['products'], $input['location_id'], $app_order_id, $modifiers_app_ids, $user_id, false, null, [], true, $isModuleEnabled);

                
                // if (!$is_direct_sale) {
                //     //Add change return
                //     $change_return = $this->dummyPaymentLine;
                //     $change_return['amount'] = $input['change_return'];
                //     $change_return['is_return'] = 1;
                //     $input['payment'][] = $change_return;
                // }

                $is_credit_sale = isset($input['is_credit_sale']) && $input['is_credit_sale'] == 1 ? true : false;
                //transaction_payments table
                if (!$transaction->is_suspend && !empty($input['payment']) && !$is_credit_sale) {
                    // Need to implement the coupon for the pos orders

                    if($input['is_pay_first'])
                    {

                        $transaction_payment = $this->digital_ordering_stripe_payment_for_payfirst($input, $transaction);
                        if($transaction_payment['status'] == 'failed')
                        {
                            return $output = [ 'errorMessage' => $transaction_payment['msg'],
                                                'status' => 'failed'
                                                ];
                        }
                        else{
                            $transaction_payment = $transaction_payment['data']; 
                        }
                    }
                    else{
                         $transaction_payment = $this->transactionUtil->createOrUpdatePaymentLines($transaction, $input['payment'], $app_order_id, $business_id, $user_id);
                    }
                }

                //Check for final and do some processing.
                if ($input['status'] == 'final' && $input['type_for_api'] != "Pickup" && $input['type_for_api'] != "Delivery") {
                    //update product stock
                    foreach ($input['products'] as $product) {
                        $decrease_qty = $this->productUtil
                            ->num_uf($product['quantity']);
                        if (!empty($product['base_unit_multiplier'])) {
                            $decrease_qty = $decrease_qty * $product['base_unit_multiplier'];
                        }

                        if ($product['enable_stock']) {
                            $this->productUtil->decreaseProductQuantity(
                                $product['product_id'],
                                $product['variation_id'],
                                $input['location_id'],
                                $decrease_qty
                            );
                        }

                        if ($product['product_type'] == 'combo') {
                            //Decrease quantity of combo as well.
                            $this->productUtil
                                ->decreaseProductQuantityCombo(
                                    $product['combo'],
                                    $input['location_id']
                                );
                        }
                    }

                    //Add payments to Cash Register
                    if (!$is_direct_sale && !$transaction->is_suspend && !empty($input['payment']) && !$is_credit_sale) {
                        //cash_register_transactions table
                        $this->cashRegisterUtil->addSellPayments($transaction, $input['payment'], $input['user_id']);
                    }

                    $debitOrder = $this->transactionUtil->debitOrderBalance($input);
                    if ($debitOrder == false) {
                        return response()->json(['errorMessage' => 'Insufficient NFC Card Balance.'], 200);
                    }

                    $debitOrderAmount = $this->transactionUtil->debitOrderBalanceFromCredit($input, $transaction->id);
                    if ($debitOrderAmount == false) {
                        return response()->json(['errorMessage' => 'Insufficient Credit Balance.'], 200);
                    }
                }

                if($input['status'] == 'final') {
                    if ($business_details->enable_rp == 1) {
                        $redeemed = !empty($input['rp_redeemed']) ? $input['rp_redeemed'] : 0;
                        $this->transactionUtil->updateCustomerRewardPoints($contact_id, $transaction->rp_earned, 0, $redeemed);
                    }
                } 

                //Update payment status
                $payment_status = $this->transactionUtil->updatePaymentStatus($transaction->id, $transaction->final_total);

                //$transaction->payment_status = $payment_status;

                if ($input['type_for_api'] == "Pickup" || $input['type_for_api'] == "Delivery") {
                    //update contact info
                    if (strtolower($input['payment'][0]['method']) == "card") {
                        $contact = Contact::where('id', $input['contact_id'])->firstOrFail();
                        $update_contact_data = [
                            'first_name' => !empty($input['first_name']) ? $input['first_name'] : null,
                            'last_name' => !empty($input['last_name']) ? $input['last_name'] : null,
                            'address_line_1' => !empty($input['billing_address']) ? $input['billing_address'] : null,
                            'city' => !empty($input['city']) ? $input['city'] : null,
                            'zip_code' => !empty($input['zip_code']) ? $input['zip_code'] : null,
                            'country' => !empty($input['country']) ? $input['country'] : null,
                            'mobile' => !empty($input['phone']) ? $input['phone'] : null,
                            'email' => !empty($input['email']) ? $input['email'] : null,
                            'accept_term_and_cond' => isset($input['accept_term_and_cond']) ? $input['accept_term_and_cond'] : 0,
                            'occasional_offers' => isset($input['occasional_offers']) ? $input['occasional_offers'] : 0
                        ];
                        $contact->fill($update_contact_data);
                        $contact->update();
                    }

                    //update user info
                    // $user = User::where('id', $input['user_id'])->firstOrFail();
                    // $update_user_data = [
                    //     'first_name' => !empty($input['first_name']) ? $input['first_name'] : null,
                    //     'last_name' => !empty($input['last_name']) ? $input['last_name'] : null,
                    //     'gender' => !empty($input['gender']) ? $input['gender'] : null,
                    //     //'contact_number' => !empty($input['phone']) ? $input['phone'] : null
                    // ];
                    // $user->fill($update_user_data);
                    // $user->update();

                    //save_delivery_details
                    $save_delivery_details = [
                        'transaction_id' => $transaction->id,
                        'd_date' => !empty($input['d_date']) ? $input['d_date'] : null,
                        'd_time' => !empty($input['d_time']) ? $input['d_time'] : null,
                    ];

                    if (!empty($input['d_address'])) {
                        $save_delivery_details['d_address'] = $input['d_address'];
                    }

                    if (!empty($input['outlet'])) {
                        $save_delivery_details['outlet'] = $input['outlet'];
                    }

                    $delivery_details = DeliveryDetails::create($save_delivery_details);

                    //$stripeRespond = $this->stripePost($input);

                    if (strtolower($input['payment'][0]['method']) == "card" && strtolower($input['payment'][0]['card_type']) != "paynow") {
                        $transaction_payment = TransactionPayment::where('transaction_id', $transaction->id)->first();
                        $transaction_payment->stripe_respond = json_encode($stripeRespond['data']['respond']);
                        $transaction_payment->stripe_status = $stripeRespond['data']['status'];
                        $transaction_payment->save();
                    }
                }

                DB::commit();

                if ($input['type_for_api'] == "Pickup" || $input['type_for_api'] == "Delivery") {
                    $order_sent = Carbon::createFromFormat('Y-m-d H:i:s', $transaction->created_at)->format('H:i A');
                    $output = ['msg' => "Sale order is added.", 'transaction_id' => $transaction->id, 'ref_no' => $transaction->ref_no, 'order_no' => $transaction->order_no, 'order_sent' => $order_sent, 'invoice_no' => $invoice_resp];
                } else {
                    $output = ['msg' => "Sale order is added.", 'transaction_id' => $transaction->id, 'invoice_no' => $invoice_resp, 'order_check_no' => $order_check_no, 'order_status' => $input['status'], 'status' =>'success'];
                }
                //return($input['transaction_date']);
            } else {
                DB::rollBack();
                $output = [
                    'errorMessage' => trans("messages.something_went_wrong")
                ];
            }
        } catch (\Exception $e) {
            DB::rollBack();
            \Log::emergency("File:" . $e->getFile() . "Line:" . $e->getLine() . "Message:" . $e->getMessage());
            $msg = trans("messages.something_went_wrong");

            if (get_class($e) == \App\Exceptions\PurchaseSellMismatch::class) {
                $msg = $e->getMessage();
            }
            if (get_class($e) == \App\Exceptions\AdvanceBalanceNotAvailable::class) {
                $msg = $e->getMessage();
            }

            $error_message = "File: " . $e->getFile(). " | Line: " . $e->getLine(). " | Message: " . $e->getMessage();
            $this->util->sendErrorLogOnMSTeam($error_message);

            $output = [
                'errorMessage' => $msg
            ];
        }

        return $output;
    }

      public function get_category_retail_products(Request $request)
    {
        $user_data = $request->only('business_id', 'business_location_id', 'category_id', 'token', 'user_id');

        if (isset($user_data['token'])) {
            $result = User::checkUserToken($user_data['token'], $user_data['user_id']);

            if ($result) {
                $result = $this->get_category_retail_products_main($user_data);
                return $result;
            } else {
                return ["errorMessage" => 'Invalid token.'];
            }
        } else {
            return ["errorMessage" => 'Invalid token.'];
        }
    }

    public function get_category_retail_products_main($user_data)
    {
        $selling_price_group_id = BusinessLocation::where('id', $user_data['business_location_id'])->select('selling_price_group_id')->first()->selling_price_group_id;

        if (isset($user_data['category_id']) && $user_data['category_id']) {
            $all_category_products = Category::join('products', 'categories.id', '=', 'products.category_id')
                ->leftjoin('product_locations', 'products.id', '=', 'product_locations.product_id')
                ->leftjoin('variations', 'products.id', '=', 'variations.product_id')
                // ->leftJoin('variation_group_prices', function($join) use ($selling_price_group_id) {
                //     $join->on('variations.id', '=', 'variation_group_prices.variation_id')
                //          ->where('variation_group_prices.price_group_id', '=', $selling_price_group_id);
                // })
                ->select('products.*', 'products.not_for_selling_by_pos_locations','categories.use_as_modifier as use_as_modifier', 'categories.id AS category_id', 'categories.name AS category', 'categories.short_code', 'categories.use_as_combo_products_category as use_as_combo_products_category')
                ->where('products.category_id', $user_data['category_id'])
                ->where('products.business_id', $user_data['business_id'])
                ->where('product_locations.location_id', $user_data['business_location_id'])
                ->where('products.deleted_at', NULL)
                ->where('products.type', 'retail')
                // ->orderBy('products.name', 'asc')
                ->orderBy('products.sequence', 'asc')
                ->get()
                ->toArray(); //'variations.default_sell_price', 'variations.member_price', 'variations.id AS variation_id' , 'variation_group_prices.price_inc_tax'
        } else {
            $all_category_products = Category::join('products', 'categories.id', '=', 'products.category_id')
                ->join('product_locations', 'products.id', '=', 'product_locations.product_id')
                // ->join('variations', 'products.id', '=', 'variations.product_id')
                // ->leftJoin('variation_group_prices', function($join) use ($selling_price_group_id) {
                //     $join->on('variations.id', '=', 'variation_group_prices.variation_id')
                //          ->where('variation_group_prices.price_group_id', '=', $selling_price_group_id);
                // })
                ->select('products.*', 'products.not_for_selling_by_pos_locations', 'categories.use_as_modifier as use_as_modifier', 'categories.id AS category_id', 'categories.name AS category', 'categories.short_code', 'categories.use_as_combo_products_category as use_as_combo_products_category')
                ->where('products.business_id', $user_data['business_id'])
                ->where('product_locations.location_id', $user_data['business_location_id'])
                ->where('products.deleted_at', NULL)
                ->where('products.type', 'retail')
                // ->orderBy('products.name', 'asc')
                ->orderBy('products.sequence', 'asc')
                ->get()
                ->toArray();
        }
        
        // 'variations.default_sell_price', 'variations.member_price', 'variations.id AS variation_id', , 'variation_group_prices.price_inc_tax'
        // print_r($all_category_products);
        // return $all_category_products;

        $result = array();

        for ($i = 0; $i < count($all_category_products); $i++) {
            $modifer_set = Product::where('business_id', $user_data['business_id'])
                ->with(['modifier_sets', 'variations'])
                ->find($all_category_products[$i]['id']);
            if (empty($all_category_products[$i]['weight'])) {
                $price = $all_category_products[$i]['default_sell_price'];
            } else {
                $price = $all_category_products[$i]['default_sell_price'] / floatval($all_category_products[$i]['weight']);
            }

            if (empty($all_category_products[$i]['weight'])) {
                $member_price = $all_category_products[$i]['member_price'];
            } else {
                $member_price = $all_category_products[$i]['member_price'] / floatval($all_category_products[$i]['weight']);
            }

            if (!empty($all_category_products[$i]['image'])) {
                // $image_url = asset('/uploads/img/' . rawurlencode($all_category_products[$i]['image']));
                $image_url = config('constants.awsS3BaseUrl') . "/" . config('constants.awsS3Env') . "/img/" . rawurlencode($all_category_products[$i]['image']);
                $all_category_products[$i]['image'] = $image_url;
            } else {
                $image_url = asset('/img/default_food.png');
            }

            $base_unit_multiplier = null;
            $sub_unit_id = null;
            if ($all_category_products[$i]['sub_unit_ids']) {
                $sub_unit_ids = json_decode($all_category_products[$i]['sub_unit_ids']);
                $intArray = array_map('intval', $sub_unit_ids);
                $sub_units = Unit::whereIn('id', $intArray)
                    ->select('base_unit_multiplier', 'actual_name', 'id')
                    ->get();
                if (!empty($sub_units) && count($sub_units)) {
                    $base_unit_multiplier = $sub_units[0]->base_unit_multiplier;
                    $sub_unit_id = $sub_units[0]->id;
                }
            } elseif ($all_category_products[$i]['unit_id']) {
                $unit = Unit::where('id', $all_category_products[$i]['unit_id'])
                    ->select('base_unit_multiplier', 'actual_name')
                    ->first();
                if (!empty($unit)) {
                    $base_unit_multiplier = $unit->base_unit_multiplier;
                }
            }

            $combo_products = [];
            if ($modifer_set->variations && count($modifer_set->variations)) {

                foreach ($modifer_set->variations as $key => $each) {
                    $variation = json_decode($each);
                    // dd($variation);

                    if (!empty($variation)) {
                        $variation->variation_value_ids = json_decode($variation->variation_value_ids, true);
                       
                        $modifer_set->variations[$key]['default_purchase_price'] = round($variation->default_purchase_price, 2);
                        $modifer_set->variations[$key]['dpp_inc_tax'] = round($variation->dpp_inc_tax, 2);
                        $modifer_set->variations[$key]['default_sell_price'] = round($variation->default_sell_price, 2);
                        $modifer_set->variations[$key]['profit_percent'] = round($variation->profit_percent, 2);
                        $modifer_set->variations[$key]['sell_price_inc_tax'] = round($variation->sell_price_inc_tax, 2);
                        $variation_combinations = VariationValueTemplate::whereIn('id', $variation->variation_value_ids)->get();
                        if(!empty($modifer_set->variations[$key]['modifier_image']))
                        {
                            $modifer_set->variations[$key]['modifier_image'] = config('constants.awsS3BaseUrl') . "/" . config('constants.awsS3Env') . "/retail_product_images/" . rawurlencode($modifer_set->variations[$key]['modifier_image']);
                        }
                        else{
                                 $modifer_set->variations[$key]['modifier_image'] = asset('/img/default_food.png');
                        }
                        $modifer_set->variations[$key]['variation_combinations'] = $variation_combinations;
                        $modifer_set->variations[$key]['variation_value_ids'] = $variation->variation_value_ids;

                    }

                }
            }
            // $product_variation = ProductVariation::where('product_id', $all_category_products[$i]['id'])->first();
            // $product_variation->variation_template_ids = json_decode($product_variation->variation_template_ids, true);
            // // dd($product_variation->variation_template_ids );
            // $variation_sets = VariationTemplate::whereIn('id', $product_variation->variation_template_ids)->get();
            // // dd($variation_sets);
            // if($variation_sets && count($variation_sets)){
            //      foreach ($variation_sets as $key => $variation_set) {
            //             $values = VariationValueTemplate::where('variation_template_id', $variation_set->id)->get();
            //             $variation_sets[$key]['values'] = $values;
            //      }
            // }        
            $product_variation = ProductVariation::where('product_id', $all_category_products[$i]['id'])->first();
            $product_variation->variation_template_ids = json_decode($product_variation->variation_template_ids, true);

            // Get all variation templates used for this product variation
            $variation_sets = VariationTemplate::whereIn('id', $product_variation->variation_template_ids)->get();

            if ($variation_sets && count($variation_sets)) {
                foreach ($variation_sets as $key => $variation_set) {
                    // Get all variation values for the current variation template
                    $values = VariationValueTemplate::where('variation_template_id', $variation_set->id)->get();
                    
                    // Filter the variation values to include only those that match the variation's variation_value_ids
                    $filtered_values = $values->filter(function ($value) use ($modifer_set) {
                        foreach ($modifer_set->variations as $variation) {
                            if (in_array($value->id, $variation['variation_value_ids'])) {
                                return true;
                            }
                        }
                        return false;
                    });

                    // Add the filtered values to the variation set
                    $variation_sets[$key]['values'] = $filtered_values;
                }
            }
            $totalStock = VariationLocationDetails::where('product_id', $all_category_products[$i]['id'])
                    ->where('qty_available', '>=', 0)  // Exclude rows with negative qty_available
                    ->sum('qty_available');

            $all_category_products[$i]['total_stock'] = !empty($totalStock) ? round($totalStock, 2): 0;
            //REFACTOR check with frontend if using or not 
            // $is_modifier_product = false;
            // if (isset($all_category_products[$i]['use_as_modifier']) && $all_category_products[$i]['use_as_modifier'] && $all_category_products[$i]['use_as_modifier'] > 0) {
            //     $is_modifier_product = true;
            // }

            $not_for_selling_by_pos_locations = $all_category_products[$i]['not_for_selling_by_pos_locations'];

            if (is_null($not_for_selling_by_pos_locations) || trim($not_for_selling_by_pos_locations) === "" || $not_for_selling_by_pos_locations === '[]') {
                $not_for_selling_by_pos_locations = []; 
            } else {
                $decoded = json_decode($not_for_selling_by_pos_locations, true);
    
                if (json_last_error() === JSON_ERROR_NONE) {
                    $not_for_selling_by_pos_locations = $decoded; 
                } else {
                    $not_for_selling_by_pos_locations = []; 
                }
            }

            $suppliers_sku = $all_category_products[$i]['suppliers_sku'];
            
            if (is_null($suppliers_sku) || $suppliers_sku == "null" || trim($suppliers_sku) === "" || $suppliers_sku === '[]') {
                $all_category_products[$i]['suppliers_sku'] = []; 
                $suppliers_sku = [];

            } else {
                $decodedSku = json_decode($suppliers_sku, true);

                if (json_last_error() === JSON_ERROR_NONE && is_array($decodedSku)) {
                    $suppliers_sku = $decodedSku;
                } else {
                    // Check if $suppliers_sku is a comma-separated string
                    if (strpos($suppliers_sku, ',') !== false) {
                        $suppliers_sku = array_map('trim', explode(',', $suppliers_sku));
                        $suppliers_sku = array_map(function($sku) {
                            return trim($sku, '"');
                        }, $suppliers_sku);
                    } else {
                        $suppliers_sku = [trim($suppliers_sku, '"')];
                    }
                }
            }

            $serving_days = json_decode($all_category_products[$i]['serving_days'], true);

            if (is_null($serving_days)|| empty($serving_days)) {
                $all_category_products[$i]['serving_days'] = [];
            }

            $modifier_sets = $modifer_set->modifier_sets;

            $modifier_set_details = [];
            $open_modifier_count = 0;
            $product_modifier_count = 0;

            foreach ($modifier_sets as $set) {
                if (isset($set['name']) && isset($set['is_open_modifier'])) {
                    $modifier_set_details[] = [
                        'name' => $set['name'],
                        'is_open_modifier' => $set['is_open_modifier']
                    ];
            
                    if ($set['is_open_modifier'] == 1) {
                        $open_modifier_count++;
                    } elseif ($set['is_open_modifier'] == 0) {
                        $product_modifier_count++;
                    }
                }
            }

            $not_for_selling_by_pos_locations = $all_category_products[$i]['not_for_selling_by_pos_locations'];

            if (is_null($not_for_selling_by_pos_locations) || trim($not_for_selling_by_pos_locations) === "" || $not_for_selling_by_pos_locations === '[]') {
                $not_for_selling_by_pos_locations = []; 
            } else {
                $decoded = json_decode($not_for_selling_by_pos_locations, true);
    
                if (json_last_error() === JSON_ERROR_NONE) {
                    $not_for_selling_by_pos_locations = $decoded; 
                } else {
                    $not_for_selling_by_pos_locations = []; 
                }
            }
            // dd($modifer_set->variations);
            $all_category_products[$i]['variation_sets'] = $variation_sets;
            $all_category_products[$i]['variations'] = count($modifer_set->variations) ? $modifer_set->variations : [];
        
        }

        return $this->respond($all_category_products);
    }
    // function updateOrder($input)
    // {
    //     $is_direct_sale = false;
    //     if (!empty($input['products'])) 
    //     {
    //         $id = $input['transaction_id'];
    //         $business_id = $input['business_id'];
    //         $user_id = $input['user_id'];

    //         $discount = ['discount_type' => $input['discount_type'],
    //                     'discount_amount' => $input['discount_amount']
    //                 ];

    //         if(isset($input['delivery_charges'])) 
    //         {
    //             $delivery_charges = $input['delivery_charges'];
    //         }
    //         else
    //         {
    //             $delivery_charges = 0;
    //         }

    //         $transaction_before = Transaction::find($id);
    //         $status_before =  $transaction_before->status;

    //         $invoice_total = $this->productUtil->newCalculateInvoiceTotal($input['products'], $input['tax_rate_id'], $discount, $input['service_charges'], true, $delivery_charges);

    //         if (!empty($input['transaction_date'])) {
    //             $input['transaction_date'] = $this->productUtil->uf_date($input['transaction_date'], true);
    //         }

    //         $input['is_suspend'] = isset($input['is_suspend']) && 1 == $input['is_suspend']  ? 1 : 0;
    //         if ($input['is_suspend']) {
    //             $input['sale_note'] = !empty($input['additional_notes']) ? $input['additional_notes'] : null;
    //         }

    //         //Begin transaction
    //         DB::beginTransaction();

    //         $transaction = $this->transactionUtil->updateSellTransaction($id, $business_id, $input, $invoice_total, $user_id);

    //         //Update Sell lines
    //         $business_details = $this->businessUtil->getDetails($business_id);
    //         if (in_array("modifiers", $business_details->enabled_modules)) {
    //             $isModuleEnabled = true;
    //         } else {
    //             $isModuleEnabled = false;
    //         }
    //         $deleted_lines = $this->transactionUtil->createOrUpdateSellLines($transaction, $input['products'], $input['location_id'], true, $status_before, [], true, $isModuleEnabled);

    //         //Update update lines
    //         $is_credit_sale = isset($input['is_credit_sale']) && $input['is_credit_sale'] == 1 ? true : false;

    //         // $new_sales_order_ids = $transaction->sales_order_ids ?? [];
    //         // $sales_order_ids =array_unique(array_merge($sales_order_ids, $new_sales_order_ids));

    //         // if (!empty($sales_order_ids)) {
    //         //     $this->transactionUtil->updateSalesOrderStatus($sales_order_ids);
    //         // }

    //         if (!$is_direct_sale && !$transaction->is_suspend && !empty($input['payment']) && !$is_credit_sale) {
    //             // //Add change return
    //             // $change_return = $this->dummyPaymentLine;
    //             // $change_return['amount'] = $input['change_return'];
    //             // $change_return['is_return'] = 1;
    //             // if (!empty($input['change_return_id'])) {
    //             //     $change_return['id'] = $input['change_return_id'];
    //             // }
    //             // $input['payment'][] = $change_return;

    //             $this->transactionUtil->createOrUpdatePaymentLines($transaction, $input['payment'], $business_id, $user_id);

    //             //Update cash register
    //             $this->cashRegisterUtil->updateSellPayments($status_before, $transaction, $input['payment'], $user_id);
    //         }

    //         //Update payment status
    //         $payment_status = $this->transactionUtil->updatePaymentStatus($transaction->id, $transaction->final_total);
    //         $transaction->payment_status = $payment_status;

    //         DB::commit();

    //         $output = ['msg' => "Sale order is edited." ];
    //     }
    //     else 
    //     {
    //         $output = [
    //                     'errorMessage' => trans("messages.something_went_wrong")
    //                 ];
    //     }

    //     return $output;
    // }

    public function stripePost($input)
    {
        // $stripe = new \Stripe\StripeClient(
        //     env('STRIPE_SECRET')
        // );
        // $token = $stripe->tokens->create([
        //     'card' => [
        //         'number' => '4242424242424242',
        //         'exp_month' => 9,
        //         'exp_year' => 2022,
        //         'cvc' => '314',
        //         'name' => $input->payment[0]["card_holder_name"],
        //         'address_line1' => '160 Robinson Rd, #06-01 SBF Center',
        //         'address_city' => 'Singapore',
        //         'address_state' => 'Singapore',
        //         'address_zip' => '068914',
        //         'address_country' => 'Singapore'
        //     ],
        // ]);
        // return $token;
        $amount = round($input->final_total, 2) * 100;
        $token = $input->stripe_token;
        $description = $input->type_for_api;
        //$token= $token->id;

        $stripe_sk = $this->get_stripe_and_lalamove_key($input);
        Stripe\Stripe::setApiKey($stripe_sk->original[0]['stripe_sk']);

        $charge = \Stripe\Charge::create([
            "amount" => $amount, //$amount
            "currency" => "SGD",
            "source" => $token,
            "description" => $description,
            "receipt_email" => $input->email
        ]);

        // $paymentIntent = $stripe->paymentIntents->create([
        //     'amount' => $amount,
        //     'currency' => 'usd',
        //     'payment_method_types' => ['card'],
        // ]);

        $data = array("id" => $charge->id, "amount" => $charge->amount, "currency" => $charge->currency, "status" => $charge->status, "respond" => $charge);
        //$data = array('client_secret'=> $paymentIntent->client_secret);
        return [
            'data' => $data
        ];
    }

    function get_takeaway_transaction(Request $request)
    {
        $input = $request;

        if (isset($input['token'])) {
            $result = User::checkUserToken($input['token'], $input['user_id']);
            
            if ($result) {
                $business_id = $input['business_id'];
                $location_id = $input['location_id'];
                $user_id = $input['user_id'];
                $transaction_status = $input['status'];
                $type_for_api = $input['type_for_api'];
                $days = isset($input['days']) ? $input['days'] : "";

                if ($transaction_status == 'draft') {
                    $query = Transaction::where('transactions.business_id', $business_id)
                        //->where('transactions.created_by', $user_id)
                        ->where('transactions.location_id', $location_id)
                        ->where('transactions.type', 'sell')
                        ->where('transactions.is_direct_sale', 0)
                        ->where('transactions.type_for_api', $type_for_api);
                } else {
                    $query = Transaction::leftJoin(
                        'transactions AS SR',
                        'transactions.id',
                        '=',
                        'SR.return_parent_id'
                    )
                        ->where('transactions.business_id', $business_id)
                        //->where('transactions.created_by', $user_id)
                        ->where('transactions.location_id', $location_id)
                        ->where('transactions.type', 'sell')
                        ->where('transactions.is_direct_sale', 0)
                        ->where('transactions.type_for_api', $type_for_api);
                }
                //Filter by days    
                if (!empty($days)) {
                    $query->whereDate('transactions.created_at', '>=', now()->subDays($days)->format('Y-m-d'));
                }

                if ($transaction_status == 'quotation') {
                    $query->where('transactions.status', 'draft')
                        ->where('sub_status', 'quotation');
                } elseif ($transaction_status == 'draft') {
                    $query->where('transactions.status', 'draft')
                        ->whereNull('sub_status');
                } else {
                    $query->where('transactions.status', $transaction_status);
                }

                $transaction_sub_type = $request->get('transaction_sub_type');
                if (!empty($transaction_sub_type)) {
                    $query->where('transactions.sub_type', $transaction_sub_type);
                } else {
                    $query->where('transactions.sub_type', null);
                }

                if ($transaction_status == 'draft') {
                    $transactions = $query->orderBy('transactions.created_at', 'desc')
                        ->groupBy('transactions.id')
                        ->select('transactions.*')
                        ->with(['contact', 'table'])
                        ->get();
                } else {
                    $transactions = $query->orderBy('transactions.created_at', 'desc')
                        ->groupBy('transactions.id')
                        ->select('transactions.*', 'SR.refund_all')
                        ->with(['contact', 'table'])
                        ->get();

                }

                return ($transactions);
            } else {
                return ["errorMessage" => 'Invalid token.'];
            }
        } else {
            return ["errorMessage" => 'Invalid token.'];
        }
    }

    function get_takeaway_orders(Request $request)
    {
        $input = $request;

        if (isset($input['token'])) {
            $result = User::checkUserToken($input['token'], $input['user_id']);
            
            if ($result) {
                $business_id = $input['business_id'];
                $location_id = $input['location_id'];
                $user_id = $input['user_id'];
                $transaction_status = $input['status'];
                $type_for_api = $input['type_for_api'];
                $days = isset($input['days']) ? $input['days'] : "";
                $is_takeaway_complete = !empty($input['completed_orders']) ? $input['completed_orders'] : 0;  
                
                $query = Transaction::leftJoin(
                    'transactions AS SR',
                    'transactions.id',
                    '=',
                    'SR.return_parent_id'
                )
                    ->where('transactions.business_id', $business_id)
                    //->where('transactions.created_by', $user_id)
                    ->where('transactions.location_id', $location_id)
                    ->where('transactions.type', 'sell')
                    ->where('transactions.is_direct_sale', 0)
                    ->where('transactions.type_for_api', $type_for_api);


                if($is_takeaway_complete == 1 || $is_takeaway_complete == 0){
                    $query->where('transactions.is_takeaway_complete', $is_takeaway_complete);
                }

                //Filter by days    
                if (!empty($days)) {
                    $days -=1 ;
                    $query->whereDate('transactions.created_at', '>=', now()->subDays($days)->format('Y-m-d'));
                }

                $transaction_sub_type = $request->get('transaction_sub_type');
                if (!empty($transaction_sub_type)) {
                    $query->where('transactions.sub_type', $transaction_sub_type);
                } else {
                    $query->where('transactions.sub_type', null);
                }

                if ($transaction_status == 'draft') {
                    $transactions = $query->orderBy('transactions.created_at', 'desc')
                        ->groupBy('transactions.id')
                        ->select('transactions.*')
                        ->with(['contact', 'table'])
                        ->get();
                } else {
                    $transactions = $query->orderBy('transactions.created_at', 'desc')
                        ->groupBy('transactions.id')
                        ->select('transactions.*', 'SR.refund_all')
                        ->with(['contact', 'table'])
                        ->get();

                }

                return ($transactions);
            } else {
                return ["errorMessage" => 'Invalid token.'];
            }
        } else {
            return ["errorMessage" => 'Invalid token.'];
        }
    }

    public function complete_takeaway_order(Request $request) {
        $user_data = $request->only('business_id', 'business_location_id', 'token', 'user_id', 'transaction_id');

        if (isset($user_data['token'])) {
            $result = User::checkUserToken($user_data['token'], $user_data['user_id']);
            if ($result) {
                $transaction = Transaction::where('id', $user_data['transaction_id'])
                                            ->where('type', 'sell')
                                            ->where('type_for_api', 'Takeaway')
                                            ->first();

                if ($transaction) {
                    if($transaction->status == 'final') {
                        $transaction->is_takeaway_complete = 1;
                        $transaction->save();
    
                        return response()->json(['status' => 'success' ,'message' => 'Takeaway status updated successfully.'], 200);
                    } else {
                        return response()->json(['status' => 'failed' ,'message' => 'Order payment is pending.'], 200);
                    }
                } else {
                    return ["errorMessage" => 'Transaction not found.'];
                }
            } else {
                return ["errorMessage" => 'Invalid token.'];
            }
        } else {
            return ["errorMessage" => 'Invalid token.'];
        }
    }

    public function complete_takeaway_order_bulk(Request $request) {
        $user_data = $request->only('business_id', 'business_location_id', 'token', 'user_id', 'transaction_ids');

        if (isset($user_data['token'])) {
            $result = User::checkUserToken($user_data['token'], $user_data['user_id']);
            if ($result) {
                if (isset($user_data['transaction_ids']) && is_array($user_data['transaction_ids'])) {
                    DB::beginTransaction();
                    try{
                        foreach ($user_data['transaction_ids'] as $transaction_id) {
                            $transaction = Transaction::where('id', $transaction_id)
                                                        ->where('type', 'sell')
                                                        ->where('type_for_api', 'Takeaway')
                                                        ->first();
                        
                            if ($transaction) {
                                if($transaction->status == 'final') {
                                    $transaction->is_takeaway_complete = 1;
                                    $transaction->save();
                
                                    $output = ['status' => 'success' ,'message' => 'Takeaway status updated successfully.'];
                                } else {
                                    $output = ['status' => 'failed' ,'message' => 'Order payment is pending.'];
                                }
                            } else {
                                $output =  ["errorMessage" => 'Transaction not found.'];
                            }
                            DB::commit();
                        }
                    } catch (\Exception $e) {
                        DB::rollBack();
                        return response()->json(['status' => 'error', 'message' => 'An error occurred while updating takeaway orders.', 'error' => $e->getMessage()], 500);
                    }
                } else {
                    $output = ['errorMessage' => 'Invalid transaction_ids provided.'];
                }
            } else {
                $output = ["errorMessage" => 'Invalid token.'];
            }
        } else {
            $output = ["errorMessage" => 'Invalid token.'];
        }
        return  response()->json($output);
    }

    function view_dinein_order(Request $request)
    {
        $input = $request;

        if (isset($input['token'])) {

            $result = User::checkUserToken($input['token'], $input['user_id']);

            if ($result) {

                try {

                    $id = !empty($input['transaction_id']) ? $input['transaction_id'] : "";
                    $business_id = $input['business_id'];
                    $location_id = $input['location_id'];
                    $transaction_status = $input['status'];
                    $app_order_id = !empty($input['app_order_id']) ? $input['app_order_id'] : "";
                    $order_type = !empty($input['order_type']) ? $input['order_type'] : "Dinein";

                    if (!empty($app_order_id)) {
                        //  echo $app_order_id;die;
                        $all_each_sale_history = $this->get_sale_history2($input['user_id'], $business_id, $location_id, $transaction_status, "", $order_type, $id, $app_order_id);
                    } else {
                        $all_each_sale_history = $this->get_sale_history($input['user_id'], $business_id, $location_id, $transaction_status, "", $order_type, $id, $app_order_id);
                    }
                    return $all_each_sale_history;
                } catch (\Exception $e) {
                    DB::rollBack();

                    if (get_class($e) == \App\Exceptions\PurchaseSellMismatch::class) {
                        $msg = $e->getMessage();
                    } else {
                        \Log::emergency("File:" . $e->getFile() . "Line:" . $e->getLine() . "Message:" . $e->getMessage());
                        $msg = __('messages.something_went_wrong');
                    }

                    return [
                        'errorMessage' => $msg
                    ];
                }
            } else {
                return ["errorMessage" => 'Invalid token.'];
            }
        } else {
            return ["errorMessage" => 'Invalid token.'];
        }
    }

    function view_takeaway_order(Request $request)
    {
        $input = $request;

        if (isset($input['token'])) {
            $result = User::checkUserToken($input['token'], $input['user_id']);

            if ($result) {

                try {
                    $id = $input['transaction_id'];
                    $business_id = $input['business_id'];
                    $location_id = $input['location_id'];
                    $status = (isset($input['status']) && $input['status']) ? $input['status'] : "final";

                    $all_each_sale_history = $this->get_sale_history($input['user_id'], $business_id, $location_id, $status, "", "Takeaway", $id);

                    return $all_each_sale_history;
                } catch (\Exception $e) {
                    DB::rollBack();

                    if (get_class($e) == \App\Exceptions\PurchaseSellMismatch::class) {
                        $msg = $e->getMessage();
                    } else {
                        \Log::emergency("File:" . $e->getFile() . "Line:" . $e->getLine() . "Message:" . $e->getMessage());
                        $msg = __('messages.something_went_wrong');
                    }

                    return [
                        'errorMessage' => $msg
                    ];
                }
            } else {
                return ["errorMessage" => 'Invalid token.'];
            }
        } else {
            return ["errorMessage" => 'Invalid token.'];
        }
    }

    function view_retail_order(Request $request)
    {
        $input = $request;

        if (isset($input['token'])) {
            $result = User::checkUserToken($input['token'], $input['user_id']);

            if ($result) {

                try {
                    $id = $input['transaction_id'];
                    $business_id = $input['business_id'];
                    $location_id = $input['location_id'];

                    $all_each_sale_history = $this->get_sale_history($input['user_id'], $business_id, $location_id, "final", "", "Retail", $id);

                    return $all_each_sale_history;
                } catch (\Exception $e) {
                    DB::rollBack();

                    if (get_class($e) == \App\Exceptions\PurchaseSellMismatch::class) {
                        $msg = $e->getMessage();
                    } else {
                        \Log::emergency("File:" . $e->getFile() . "Line:" . $e->getLine() . "Message:" . $e->getMessage());
                        $msg = __('messages.something_went_wrong');
                    }

                    return [
                        'errorMessage' => $msg
                    ];
                }
            } else {
                return ["errorMessage" => 'Invalid token.'];
            }
        } else {
            return ["errorMessage" => 'Invalid token.'];
        }
    }

    // function void_transaction(Request $request)
    // {
    //     $user_data = $request->only('token','user_id','transaction_id','additional_notes');

    //     if(isset($user_data['token']))
    //     {    
    //         $result = User::checkUserToken($user_data['token'], $user_data['user_id']);

    //         if($result)
    //         {
    //             $transaction = Transaction::where('id', $user_data['transaction_id'])->update(
    //                 [
    //                     'is_suspend' => 1,
    //                     'additional_notes' => $user_data['additional_notes']
    //                 ]
    //             );

    //             return $this->respond($transaction);
    //         }
    //         else
    //         {
    //             return["errorMessage"=>'Invalid token.'];
    //         }
    //     }
    //     else{
    //         return["errorMessage"=>'Invalid token.'];
    //     }
    // }

    function get_discount_addon(Request $request)
    {
        $user_data = $request->only('business_id', 'business_location_id', 'token', 'user_id');

        if (isset($user_data['token'])) {
            $result = User::checkUserToken($user_data['token'], $user_data['user_id']);

            if ($result) {
                $all_location_discounts_addons = Category::join('products', 'categories.id', '=', 'products.category_id')
                    ->join('product_locations', 'products.id', '=', 'product_locations.product_id')
                    ->join('variations', 'products.id', '=', 'variations.product_id')
                    ->select('products.*', 'categories.name AS category', 'categories.short_code', 'variations.id AS variation_id', 'variations.default_sell_price', 'variations.profit_percent')
                    ->where('products.business_id', $user_data['business_id'])
                    ->where('product_locations.location_id', $user_data['business_location_id'])
                    ->where('products.deleted_at', NULL)
                    ->whereIn('categories.short_code', array('00100', '00200'))
                    ->groupBy('products.name')
                    ->orderBy('products.name', 'asc')
                    ->get()
                    ->toArray();
                $result = array();

                for ($i = 0; $i < count($all_location_discounts_addons); $i++) {
                    $result[] = [
                        'id' => $all_location_discounts_addons[$i]['id'],
                        'short_code' => $all_location_discounts_addons[$i]['short_code'],
                        'category' => $all_location_discounts_addons[$i]['category'],
                        'name' => $all_location_discounts_addons[$i]['name'],
                        'product_type' => $all_location_discounts_addons[$i]['type'],
                        'variation_id' => $all_location_discounts_addons[$i]['variation_id'],
                        'price' => $all_location_discounts_addons[$i]['default_sell_price'],
                        'percent' => $all_location_discounts_addons[$i]['profit_percent'],
                    ];
                }

                return $this->respond($result);
            } else {
                return ["errorMessage" => 'Invalid token.'];
            }
        } else {
            return ["errorMessage" => 'Invalid token.'];
        }
    }

    function update_transaction_status(Request $request)
    {
        $user_data = $request->only('transaction_id', 'business_id', 'token', 'user_id');

        if (isset($user_data['token'])) {
            $result = User::checkUserToken($user_data['token'], $user_data['user_id']);

            if ($result) {
                $transaction = Transaction::findorfail($user_data['transaction_id']);
                $transaction->status = "final";
                $transaction->save();

                return ["transaction" => $transaction];
            } else {
                return ["errorMessage" => 'Invalid token.'];
            }
        } else {
            return ["errorMessage" => 'Invalid token.'];
        }
    }

    function get_all_sales(Request $request)
    {
        $user_data = $request->only('business_id', 'location_id', 'token', 'user_id', 'created_at', 'type', 'current_time', 'terminal_id', 'all_terminals', 'start_date', 'end_date');

        if (isset($user_data['token'])) {
            $result = User::checkUserToken($user_data['token'], $user_data['user_id']);

            if ($result) {
                $user_id = $user_data['user_id'];
                $business_id = $user_data['business_id'];
                $location_id = $user_data['location_id'];
                $transaction_status = "final";
                $created_at = !empty($user_data['created_at']) ? $user_data['created_at'] : "";
                $current_time = (isset($user_data['current_time']) && $user_data['current_time']) ? $user_data['current_time'] : "";
                $type = !empty($user_data['type']) ? $user_data['type'] : "";
                $terminal_id = !empty($user_data['terminal_id']) ? $user_data['terminal_id'] : null;
                $all_terminals = !empty($user_data['all_terminals']) ? $user_data['all_terminals'] : 0;

                $all_sale_history = $this->get_sale_history($user_id, $business_id, $location_id, $transaction_status, $created_at, $type, null, null, $current_time, $terminal_id, $all_terminals, $user_data['start_date'], $user_data['end_date']);

                return $all_sale_history;
            } else {
                return ["errorMessage" => 'Invalid token.'];
            }
        } else {
            return ["errorMessage" => 'Invalid token.'];
        }
    }
    function get_all_sales_attaphouse (Request $request)
    {
        $user_data = $request->only('business_id', 'location_id', 'token', 'user_id', 'created_at', 'type', 'current_time', 'terminal_id', 'pagination');

        if (isset($user_data['token'])) {
            $result = User::checkUserToken($user_data['token'], $user_data['user_id']);

            if ($result) {
                $user_id = $user_data['user_id'];
                $business_id = $user_data['business_id'];
                $location_id = $user_data['location_id'];
                $transaction_status = "final";
                $created_at = !empty($user_data['created_at']) ? $user_data['created_at'] : "";
                $current_time = (isset($user_data['current_time']) && $user_data['current_time']) ? $user_data['current_time'] : "";
                $type = !empty($user_data['type']) ? $user_data['type'] : "";
                $terminal_id = !empty($user_data['terminal_id']) ? $user_data['terminal_id'] : null;
                $pagination = !empty($user_data['pagination']) ? $user_data['pagination'] : null;

                $all_sale_history = $this->get_sale_history_attaphouse($user_id, $business_id, $location_id, $transaction_status, $created_at, $type, null, null, $current_time, $terminal_id, $pagination );

                return $all_sale_history;
            } else {
                return ["errorMessage" => 'Invalid token.'];
            }
        } else {
            return ["errorMessage" => 'Invalid token.'];
        }
    }
    function get_customer_profile_sale(Request $request)
    {
        $user_data = $request->only('business_id', 'location_id', 'token', 'user_id', 'created_at', 'type', 'contact_id', 'current_time');

        if (isset($user_data['token'])) {
            $result = User::checkUserToken($user_data['token'], $user_data['user_id']);

            if ($result) {
                $user_id = $user_data['user_id'];
                $business_id = $user_data['business_id'];
                $location_id = $user_data['location_id'];
                $transaction_status = "final";
                $created_at = $user_data['created_at'];
                $type = $user_data['type'];
                $contact_id = $user_data['contact_id'];
                $current_time = (isset($user_data['current_time']) && $user_data['current_time']) ? $user_data['current_time'] : "";

                $all_sale_history = $this->get_sale_history($user_id, $business_id, $location_id, $transaction_status, $created_at, $type, null, $contact_id, $current_time);

                return $all_sale_history;
            } else {
                return ["errorMessage" => 'Invalid token.'];
            }
        } else {
            return ["errorMessage" => 'Invalid token.'];
        }
    }

    function order_history_by_user(Request $request)
    {
        $user_data = $request->only('business_id', 'location_id', 'token', 'user_id', 'contact_id');

        $user_id = $user_data['user_id'];
        $business_id = $user_data['business_id'];
        $location_id = $user_data['location_id'];
        $transaction_status = "final";
        $type = "";
        $contact_id = $user_data['contact_id'];

        $all_sale_history = $this->order_history($user_id, $business_id, $location_id, $transaction_status, $type, null, $contact_id);

        return $all_sale_history;

    }

    function order_history($user_id, $business_id, $location_id, $transaction_status, $type, $transaction_id = null, $contact_id = null)
    {

        try {
            $query = Transaction::leftjoin('transaction_payments as t', 't.transaction_id', '=', 'transactions.id')
                // ->leftjoin('business as b', 'b.id', '=', 'transactions.business_id')
                // ->leftjoin('users as u', 'u.business_id', '=', 'b.id')
                ->leftjoin('variations as w', 'w.product_id', '=', 'transactions.additional_discount_method')
                ->leftjoin('tax_rates as z', 'z.id', '=', 'transactions.tax_id')
                ->leftJoin('transactions AS SR', 'transactions.id', '=', 'SR.return_parent_id')
                // ->leftJoin('transaction_sell_lines AS tsl', 'u.id', '=', 'tsl.order_placed_by')
                ->with('sell_lines.variations.product.category')
                ->with('payment_lines')
                // ->with('contact')
                ->where('transactions.business_id', $business_id)
                ->where('transactions.location_id', $location_id)
                //->where('transactions.created_by', $user_id)
                ->where('transactions.type', 'sell')
                //->where('transactions.type_for_api', 'Takeaway')
                ->where('transactions.is_direct_sale', 0);
                // ->where('tsl.order_placed_by', $user_id);


                //For web pickup and delivery
            if ($contact_id != null) {
                $query->where(function($query) use ($contact_id) {
                    $query->where('transactions.contact_id', $contact_id)
                          ->orWhereRaw('FIND_IN_SET(?, transactions.contact_ids)', [$contact_id]);
                });

                // if (!empty($created_at)) {
                //     // $query->whereDate('transactions.created_at', $created_at); //2021-08-15 00:00:00
                //     $query->whereBetween('transactions.created_at', [$today, $tomorrow]);
                // }
            }

            if ($transaction_id != null) {
                $query->where('transactions.id', $transaction_id);
            }
            // else if($type == 'TrackOrder')
            // {
            //     $query->whereDate('transactions.created_at','=', Carbon::today());
            // }
            else if ($type != 'PickupOrDelivery' && $type != 'TrackOrder' && $contact_id == null) {
                // if (!empty($created_at)) {
                //     // $query->whereDate('transactions.created_at', $created_at); //2021-08-15 00:00:00
                //     $query->whereBetween('transactions.created_at', [$today, $tomorrow]);
                // } else {
                //     // $query->whereDate('transactions.created_at', \Carbon::now()->format('Y-m-d 00:00:00'));
                //     $query->whereBetween('transactions.created_at', [$today, $tomorrow]);
                // }
            }

            if (!empty($type)) {
                //For web pickup and delivery
                if ($type == 'PickupOrDelivery' || $type == 'Pickup' || $type == 'TrackOrder' || $type == 'Delivery') {
                    $query->leftJoin(
                        'delivery_details AS DD',
                        'transactions.id',
                        '=',
                        'DD.transaction_id'
                    )
                        ->leftJoin(
                            'business_locations AS BL',
                            'DD.outlet',
                            '=',
                            'BL.id'
                        )
                        ->leftJoin(
                            'business_locations AS BLD',
                            'transactions.location_id',
                            '=',
                            'BLD.id'
                        );
                    if ($type == 'PickupOrDelivery') {
                        $query->where(function ($query) use ($contact_id, $business_id, $location_id) {
                            $query->where('transactions.type_for_api', '=', 'Pickup')
                                ->where('transactions.pickup_completed', '=', 1)
                                ->where('transactions.contact_id', $contact_id)
                                ->where('transactions.business_id', $business_id)
                                ->where('transactions.location_id', $location_id);
                        })->orWhere(function ($query) use ($contact_id, $business_id, $location_id) {
                            $query->where('transactions.type_for_api', '=', 'Delivery')
                                ->where('transactions.lalamove_status', '!=', 'ASSIGNING_DRIVER')
                                ->where('transactions.lalamove_status', '!=', 'ON_GOING')
                                ->where('transactions.lalamove_status', '!=', 'PICKED_UP')
                                ->where('transactions.contact_id', $contact_id)
                                ->where('transactions.business_id', $business_id)
                                ->where('transactions.location_id', $location_id);
                        });
                    } else if ($type == 'TrackOrder') {
                        $query->where(function ($query) use ($contact_id, $business_id, $location_id) {
                            $query->where('transactions.type_for_api', '=', 'Pickup')
                                ->where('transactions.pickup_completed', '=', 0)
                                ->where('transactions.contact_id', $contact_id)
                                ->where('transactions.business_id', $business_id)
                                ->where('transactions.location_id', $location_id);
                        })->orWhere(function ($query) use ($contact_id, $business_id, $location_id) {
                            $query->where('transactions.type_for_api', '=', 'Delivery')
                                ->where('transactions.lalamove_status', '!=', 'COMPLETED')
                                ->where('transactions.lalamove_status', '!=', 'EXPIRED')
                                ->where('transactions.lalamove_status', '!=', 'CANCELED')
                                ->where('transactions.lalamove_status', '!=', 'REJECTED')
                                ->where('transactions.contact_id', $contact_id)
                                ->where('transactions.business_id', $business_id)
                                ->where('transactions.location_id', $location_id);
                        });
                    }
                } else {
                    $query->where('transactions.type_for_api', $type);
                }
            } else {
                $query->where(function ($query) {
                    $query->where('transactions.type_for_api', 'Dinein')
                        ->orWhere('transactions.type_for_api', 'Takeaway')
                        ->orWhere('transactions.type_for_api', 'Retail')
                        ->orWhere('transactions.type_for_api', 'Kiosk')
                        ->orWhere('transactions.type_for_api', 'Common');
                });
            }

            if ($transaction_status == 'quotation') {
                $query->where('transactions.status', 'draft')
                    ->where('transactions.sub_status', 'quotation');
            } elseif ($transaction_status == 'draft') {
                $query->where('transactions.status', 'draft')
                    ->whereNull('transactions.sub_status');
            } else {
                $query->where('transactions.status', $transaction_status);
            }

            // $transaction_sub_type = $request->get('transaction_sub_type');
            // if (!empty($transaction_sub_type)) {
            //$query->where('transactions.sub_type', $transaction_sub_type);
            // } else {
            //     $query->where('transactions.sub_type', null);
            // }

            $query->orderBy('transactions.created_at', 'desc')
                ->groupBy('transactions.id');

            //For web pickup and delivery
            if ($type == 'PickupOrDelivery' || $type == 'Pickup' || $type == 'TrackOrder' || $type == 'Delivery') {
                $transactions = $query->select(
                    'transactions.*',
                    't.amount as received_amount',
                    't.method',
                    't.card_type',
                    't.last_4_card_digits',
                    'w.profit_percent',
                    'z.amount as tax_rate_amount',
                    DB::raw('COUNT(SR.id) as return_exists'),
                    'SR.refund_all',
                    'DD.d_date',
                    'DD.d_time',
                    'DD.d_address',
                    'BL.name as business_location_name_for_pickup',
                    'BL.mobile as business_location_mobile_for_pickup',
                    'BLD.name as business_location_name_for_delivery',
                    'BLD.mobile as business_location_mobile_for_delivery'
                )
                    ->with(['contact'])
                    ->get();
            } else {
                $transactions = $query->select('transactions.*', 't.amount as received_amount', 't.method', 't.card_type', 't.last_4_card_digits', 'w.profit_percent', 'z.amount as tax_rate_amount', DB::raw('COUNT(SR.id) as return_exists'), 'SR.refund_all')
                    ->with(['contact'])
                    //->limit(5)
                    ->get();
            }

            $retail_gst = 0;
            $business_tax_rates = TaxRate::where('business_id', $business_id)
                ->get()
                ->toArray();

            for ($i = 0; $i < count($business_tax_rates); $i++) {
                if (strtolower($business_tax_rates[$i]['name']) == 'gst') {
                    $retail_gst = $business_tax_rates[$i]['amount'];
                }
            }

            $businessUtil = new BusinessUtil();
            $business = $businessUtil->getDetails($business_id);
            $pos_settings = json_decode($business->pos_settings);

            //return $transactions;
            $transaction_result = [];
            $total_dont_have_line_discount_amt = 0;
            //$final_total_for_single_item = 0;
            foreach ($transactions as $key => $value) {
                $item = [];
                $payments = [];
                $final_total_for_single_item = 0;
                $final_total_line_discount_amount = 0;
                $service_charge_amount = 0;
                $increment = 0;
                $sellArray1 = $value['sell_lines'];
                $finalItems = [];
                foreach ($sellArray1->toArray() as $key => $item_sellLine) {
                    if ($item_sellLine['parent_sell_line_id'] == null) { 
                        $mainItem = $item_sellLine;
                        // dd($mainItem);
                        $mainItemPrice = $mainItem['unit_price_before_discount'];
                        foreach ($sellArray1->toArray() as $modifier) {
                            if (!empty($modifier['parent_sell_line_id']) && $modifier['parent_sell_line_id'] == $mainItem['id'] && $item_sellLine["change_price"] == 0 && $modifier["children_type"] == "modifier") {
                                $mainItemPrice += $modifier['unit_price_before_discount']; // Add the modifier price to the main product price
                            }
                        }
                        // Update the main product price
                        $mainItem['unit_price_before_discount'] = $mainItemPrice;
                        // Add the updated main item to the final result array
                        $finalItems[] = $mainItem;
                    }
                }        
                $dineService  = $this->calculateItemTotalForDineIn($finalItems, $value['type_for_api'], $value['discount_amount'], $value['discount_type'], $value['rp_redeemed_amount'], $value['id']);

                foreach ($value['sell_lines'] as $sellLinesKey => $sellLinesValue) {

                    $total_line_discount_amount = 0;
                    if ($sellLinesValue["parent_sell_line_id"] == null && $sellLinesValue["transaction_id"] == $value['id']) {
                        $adons = [];
                        $combo_adons = [];
                        $total_for_single_item = 0;
                        foreach ($value['sell_lines'] as $sellLinesKey1 => $sellLinesValue1) {
                            if ($sellLinesValue1["parent_sell_line_id"] != null && $sellLinesValue1["parent_sell_line_id"] == $sellLinesValue['id'] && $sellLinesValue1["children_type"] == "modifier") {
                                if (isset($sellLinesValue1['variations']) && !empty($sellLinesValue1['variations'])) {
                                    $adons[] = [
                                        'id' => $sellLinesValue1['variations']->id,
                                        'modifier_set_id' => $sellLinesValue1['variations']->product_id,
                                        'modifier_sell_line_id' => $sellLinesValue1['id'],
                                        'name' => $sellLinesValue1['variations']->name,
                                        'quantity' => $sellLinesValue1["quantity"],
                                        'amount' => $sellLinesValue1['unit_price_before_discount'], //unit_price_before_discount
                                        'not_for_receipt' => $sellLinesValue1['variations']->product->not_for_receipt,
                                        'modifier_app_id' => $sellLinesValue1['modifier_app_ids'],
                                        'name_in_second_language' => $sellLinesValue1['variations']->name_in_second_language,
                                        'short_hand_name' => $sellLinesValue1['variations']->short_hand_name,
                                        'merge_qty' => $sellLinesValue1['product']->merge_qty
                                    ];
                                }
                                if ($sellLinesValue["quantity_returned"] == "0.0000" && $sellLinesValue["change_price"] == 0) {
                                    //total modifier price
                                    $total_for_single_item = $total_for_single_item + $sellLinesValue1['unit_price_before_discount'];
                                }
                            } else if ($sellLinesValue1["parent_sell_line_id"] != null && $sellLinesValue1["parent_sell_line_id"] == $sellLinesValue['id'] && $sellLinesValue1["children_type"] == "combo") {
                                $combo_adons[] = [
                                    'transaction_sell_lines_id' => $sellLinesValue1['id'],
                                    'product_id' => $sellLinesValue1['product_id'],
                                    'variation_id' => $sellLinesValue1['variation_id'],
                                    'quantity' => $sellLinesValue1['quantity'],
                                ];
                            }
                        }

                        $sub_unit_id = !empty($sellLinesValue['sub_unit_id']) ? $sellLinesValue['sub_unit_id'] : "";
                        $sub_unit_multiplier = UNIT::where('id', $sub_unit_id)->get();

                        $base_unit_multiplier = !empty($sub_unit_multiplier[0]['base_unit_multiplier']) ? $sub_unit_multiplier[0]['base_unit_multiplier'] : 1;
                        //main item price + modifier price
                        if ($sellLinesValue['weight'] > 0) {
                            $total_for_single_item = ($sellLinesValue['unit_price_before_discount'] + $total_for_single_item) * $sellLinesValue["quantity"];
                        } else {
                            $total_for_single_item = ($sellLinesValue['unit_price_before_discount'] + $total_for_single_item) * $sellLinesValue["quantity"];
                        }

                        if ($increment == 0) {
                            $total_dont_have_line_discount_amt = 0;
                        }

                        if ($sellLinesValue["quantity_returned"] == "0.0000") {
                            $final_total_for_single_item += $total_for_single_item;
                            //calculate if line item has line discount
                            if ($sellLinesValue['line_discount_type'] == "fixed") {
                                $total_line_discount_amount += $sellLinesValue['line_discount_amount'];
                            } else if ($sellLinesValue['line_discount_type'] == "percentage") {
                                $total_line_discount_amount = (($sellLinesValue['line_discount_amount'] / 100) * $total_for_single_item) + $total_line_discount_amount;
                            }
                            //calculate final total line discount amount
                            $final_total_line_discount_amount += $total_line_discount_amount;
                            //total if item dont have line discount amount
                            if ($total_line_discount_amount == 0) {
                                $total_dont_have_line_discount_amt += $total_for_single_item;
                            }
                        }

                        if ($sellLinesValue['added_by_qr'] == 0) {
                            $sellLinesValue['added_by_qr'] = 'false';
                        } else {
                            $sellLinesValue['added_by_qr'] = 'true';
                        }
        
                        $combo_products = [];
                        $variations = Product::where('business_id', $business_id)
                            ->with(['variations'])
                            ->find($sellLinesValue['product_id']);
                        if (isset($variations['variations']) && $variations['variations'] && count($variations['variations'])) {
                            foreach ($variations['variations'] as $key => $each) {
                                $variation = json_decode($each);
                                if ($variation->combo_variations && count($variation->combo_variations)) {
                                    foreach ($variation->combo_variations as $key => $combo_variation) {
                                        $combo_product = Variation::where('variations.id', $combo_variation->variation_id)
                                            ->join('products AS p', 'variations.product_id', '=', 'p.id')
                                            ->select(['p.*', 'variations.name as variation_name'])
                                            ->first();
                                        $combo_product['quantity'] = round($combo_variation->quantity, 2);

                                        $not_for_selling_by_pos_locations = $combo_product['not_for_selling_by_pos_locations'];

                                        if (is_null($not_for_selling_by_pos_locations) || $not_for_selling_by_pos_locations === "[]") {
                                            $combo_product['not_for_selling_by_pos_locations'] = []; 
                                        } else {
                                            $decoded = json_decode($not_for_selling_by_pos_locations, true);

                                            if (json_last_error() === JSON_ERROR_NONE) {
                                                $combo_product['not_for_selling_by_pos_locations'] = $decoded; 
                                            } else {
                                                $combo_product['not_for_selling_by_pos_locations'] = []; 
                                            }
                                        }
                                        $combo_products[] = $combo_product;
                                    }
                                }
                            }
                        }

                        $product_data = Product::where('business_id', $business_id)
                            ->find($sellLinesValue['product_id']);


                        $item[] = [

                            'transaction_sell_line_id' => $sellLinesValue['id'],
                            'category_id' => !empty($sellLinesValue['variations']->product->category_id) ? $sellLinesValue['variations']->product->category_id : "",
                            'name' => ($sellLinesValue['variations'] && $sellLinesValue['variations']->product) ? $sellLinesValue['variations']->product->name : null,
                            'short_code' => ($sellLinesValue['variations'] && $sellLinesValue['variations']->product) ? $sellLinesValue['variations']->product->category->short_code : null,
                            'quantity' => $sellLinesValue['quantity'],
                            'quantity_returned' => $sellLinesValue["quantity_returned"],
                            'quantity_returned_note' => $sellLinesValue["quantity_returned_note"],
                            'unit_id' => ($sellLinesValue['variations'] && $sellLinesValue['variations']->product) ? $sellLinesValue['variations']->product->unit_id : null,
                            'amount' => $sellLinesValue['unit_price_before_discount'],
                            'total_before_tax' => $value['total_before_tax'],
                            'tax_amount' => $value['tax_amount'],
                            'line_discount_type' => $sellLinesValue['line_discount_type'],
                            'line_discount_amount' => $sellLinesValue['line_discount_amount'],
                            'product_id' => $sellLinesValue['product_id'],
                            'variation_id' => $sellLinesValue['variation_id'],
                            'weight' => $sellLinesValue["weight"],
                            'total_line_discount_amount' => $total_line_discount_amount,
                            'total_for_single_item' => $total_for_single_item,
                            'serve_later_quantity' => $sellLinesValue["serve_later_quantity"],
                            'adons' => $adons,
                            'printed' => $sellLinesValue["printed"],
                            'sell_line_note' => $sellLinesValue["sell_line_note"],
                            'change_price' => $sellLinesValue["change_price"],
                            'combo_variations' => $combo_adons,
                            'combo_products' => $combo_products,
                            'app_order_id' => $value['app_order_id'],
                            'app_item_line_id' => $sellLinesValue["app_item_line_id"],
                            'user_id' => $sellLinesValue['user_id'],
                            'added_by_qr' => $sellLinesValue['added_by_qr'],
                            'order_placed_by' => $sellLinesValue['order_placed_by'] ? $sellLinesValue['order_placed_by'] : null,
                            "name_in_second_language" => $product_data->name_in_second_language ? $product_data->name_in_second_language: "",
                            'image' =>$product_data->image ? config('constants.awsS3BaseUrl') . "/" . config('constants.awsS3Env') . "/img/" . rawurlencode($product_data->image) : asset('/img/default_food.png')
                        ];

                        $increment++;
                    }
                }

                if ($value['discount_type'] == "fixed") {
                    $discount_amount = $value['discount_amount'] + $final_total_line_discount_amount;
                } else if ($value['discount_type'] == "percentage") {
                    $discount_amount = ($value['discount_amount'] * $total_dont_have_line_discount_amt) + $final_total_line_discount_amount;
                }
                //calculate service charges
                if($value['rp_redeemed_amount'] > 0) {
                 // $service_charge_amount = ($final_total_for_single_item - $discount_amount - $value['rp_redeemed_amount']) * $value['service_charges']; $dineService 
                 $service_charge_amount = $dineService  * $value['service_charges'];    
                } else {
                    // $service_charge_amount = ($final_total_for_single_item - $discount_amount) * $value['service_charges'];
                    $service_charge_amount = $dineService * $value['service_charges'];
                }
                // dd($service_charge_amount);

                if($value['return_exists'] == 1) {
                    if($value['discount_type'] == 'fixed') {
                        $discountPercent = ($discount_amount / $value['total_before_tax']) * 100;
                        $discountAmount = ($total_dont_have_line_discount_amt * $discountPercent) / 100;            
                    } else {
                        $discountAmount = $discount_amount; 
                    }   

                    if($value['rp_redeemed_amount'] > 0) {

                        $rp_redeemed_amount_percent = ($value['rp_redeemed_amount'] / $value['total_before_tax']) * 100;
                        $rp_redeemed_amount = ($total_dont_have_line_discount_amt * $rp_redeemed_amount_percent) / 100;
                        // $service_charge_amount = ($final_total_for_single_item - $discountAmount - $rp_redeemed_amount) * $value['service_charges'];
                        $service_charge_amount = $dineService * $value['service_charges'];

                    } else {
                        // $service_charge_amount = ($final_total_for_single_item - $discountAmount) * $value['service_charges']; 
                        $service_charge_amount = $dineService    * $value['service_charges']; 

                    }
                }


                if ($value['delivery_charges'] != 0) {
                    //calculate tax
                    $tax_amount = 0;
                    if ($value['tax_id'] != null) {
                        if ($value["is_inclusive_gst_applied"])
                            $tax_amount = (($final_total_for_single_item - $discount_amount) / (100 + $value['tax_rate_amount'])) * $value['tax_rate_amount'];
                        else
                            $tax_amount = ($value['tax_rate_amount'] / 100) * ($final_total_for_single_item - $discount_amount);
                    }

                    if ($value['is_inclusive_gst_applied'])
                        $final_total = $final_total_for_single_item + $value['delivery_charges'];
                    else
                        $final_total = $final_total_for_single_item + $tax_amount + $value['delivery_charges'];
                } else {
                    //calculate tax
                    $tax_amount = 0;
                    $refund_tax_amount = 0;

                    if ($value['type_for_api'] == 'Retail') {
                        $tax_amount = ($final_total_for_single_item + $service_charge_amount - $discount_amount) - (($final_total_for_single_item + $service_charge_amount - $discount_amount) / (1 + ($retail_gst / 100)));

                        $final_total = round($final_total_for_single_item, 2) + 0 + round($service_charge_amount, 2) - round($discount_amount, 2);
                    } else {
                        if ($value['tax_id'] != null) {

                            if ($value["is_inclusive_gst_applied"])
                                if($value['return_exists'] == 1) {
                                    $discountPercent = ($discount_amount / $value['total_before_tax']) * 100;
                                    $discountAmount = ($total_dont_have_line_discount_amt * $discountPercent) / 100;

                                    $tax_amount = (($final_total_for_single_item + $service_charge_amount - $discountAmount) / (100 + $value['tax_rate_amount'])) * $value['tax_rate_amount'];
                                    //dd($tax_amount);
                                //$tax_amount = (($final_total_for_single_item + $service_charge_amount ) / (100 + $value['tax_rate_amount'])) * $value['tax_rate_amount'];
                                } else {
                                    if($value['rp_redeemed_amount'] > 0) {
                                        $tax_amount = (($final_total_for_single_item + $service_charge_amount - $discount_amount - $value['rp_redeemed_amount']) / (100 + $value['tax_rate_amount'])) * $value['tax_rate_amount']; 
                                   } else {
                                        $tax_amount = (($final_total_for_single_item + $service_charge_amount - $discount_amount) / (100 + $value['tax_rate_amount'])) * $value['tax_rate_amount'];
                                   }
                                    
                                    //dd($tax_amount);
                                //$tax_amount = (($final_total_for_single_item + $service_charge_amount ) / (100 + $value['tax_rate_amount'])) * $value['tax_rate_amount'];
                                }
                                
                            else
                                if($discount_amount != 0 && $value['total_before_tax']) {
                                    $discountPercent = ($discount_amount / $value['total_before_tax']) * 100;
                                    $discountAmount = ($total_dont_have_line_discount_amt * $discountPercent) / 100;
                                    if($value['rp_redeemed_amount'] > 0) {
                                        $tax_amount = ($value['tax_rate_amount'] / 100) * ($final_total_for_single_item + $service_charge_amount - $discountAmount - $value['rp_redeemed_amount']);
                                    } else {
                                        $tax_amount = ($value['tax_rate_amount'] / 100) * ($final_total_for_single_item + $service_charge_amount - $discountAmount);
                                    }
                                    
                                } else {
                                    if($value['rp_redeemed_amount'] > 0) {
                                        $tax_amount = ($value['tax_rate_amount'] / 100) * ($final_total_for_single_item + $service_charge_amount - $discountAmount - $value['rp_redeemed_amount']);
                                    } else {
                                        $tax_amount = ($value['tax_rate_amount'] / 100) * ($final_total_for_single_item + $service_charge_amount - $discount_amount);
                                    }
                                    
                                }
                                
                        }

                        if ($value['is_inclusive_gst_applied'])
                            
                            if($value['return_exists'] == 1) {
                                $discountPercent = ($discount_amount / $value['total_before_tax']) * 100;
                                $discountAmount = ($total_dont_have_line_discount_amt * $discountPercent) / 100;   

                                if($value['discount_type'] == 'fixed') {
                                    $final_total = round($final_total_for_single_item, 2) + round($service_charge_amount, 2) - $discountAmount;
                                } else {
                                    $final_total = round($final_total_for_single_item, 2) + round($service_charge_amount, 2) - round($discount_amount, 2);

                                }

                            } else {
                                $final_total = round($final_total_for_single_item, 2) + round($service_charge_amount, 2) - round($discount_amount, 2);
                            }
                            
                        else
                            if($value['return_exists'] == 1) {
                                $final_total = round($final_total_for_single_item, 2) + round($tax_amount, 2) + round($service_charge_amount, 2);
                            } else {
                                $final_total = round($final_total_for_single_item, 2) + round($tax_amount, 2) + round($service_charge_amount, 2) - round($discount_amount, 2);
                            }
                    }
                }

                $amount_rounding_method = $pos_settings->amount_rounding_method;
                $payment_method = $value->method;
                $latest_round_off_amount = $this->transactionUtil->latest_round_off_amount($payment_method, $final_total, $amount_rounding_method, $value['type_for_api']);

                // $final_total = round($final_total - $value['round_off_amount'], 2);

                if ($value['return_exists'] == 1){
                    if($value['discount_type'] == "fixed")  {
                        $discountPercent = ($discount_amount / $value['total_before_tax']) * 100;
                        $discountAmount = ($total_dont_have_line_discount_amt * $discountPercent) / 100;
                        $discount_amount = $discountAmount;
                    }
                }

                if($value['rp_redeemed_amount'] > 0 && $value['return_exists'] != 1) {
                    $final_total = $final_total - $value['rp_redeemed_amount'];
                } elseif($value['rp_redeemed_amount'] > 0 && $value['return_exists'] == 1) {
                    $rp_redeemed_amount_percent = ($value['rp_redeemed_amount'] / $value['total_before_tax']) * 100;
                    $rp_redeemed_amount = ($total_dont_have_line_discount_amt * $rp_redeemed_amount_percent) / 100;
                    $final_total = $final_total - $rp_redeemed_amount;
                }

                // For multiple payment
                foreach ($value['payment_lines'] as $payment_lines_key => $payment_line) {
                    if (count($value['payment_lines']) == 1) {
                        if ($final_total > 0) {
                            $is_rounding_applied = $this->transactionUtil->isRoundingApply($final_total);
                            if($is_rounding_applied)
                            {
                                $cash_received_amount = $final_total + $latest_round_off_amount;    
                            }
                            else {
                                $cash_received_amount = $final_total;
                            }
                            
                        } else {
                            $cash_received_amount = $final_total;
                        }
                    } else {
                        if ($value['refund_all'] == 1) {
                            $cash_received_amount = 0;
                        } else {
                            $cash_received_amount = $payment_line['amount'];
                        }
                    }
                    $payments[] = [
                        'transaction_payment_id' => $payment_line['id'],
                        'method' => $payment_line['method'],
                        'card_type' => $payment_line['card_type'],
                        'last_4_card_digits' => $payment_line['last_4_card_digits'],
                        'received_amount' => $cash_received_amount
                    ];
                }

                $table_arr = [];
                $table_name = [];
                $pax = '';

                $table_query = Transaction::leftjoin('pos_res_tables as t', 't.transaction_id', '=', 'transactions.id')
                    ->leftjoin('res_tables as z', 'z.id', '=', 't.res_table_id')
                    ->where('transactions.id', $value['id'])
                    ->select('t.res_table_id', 'pax', 'z.name')
                    ->get();

                if (!empty($table_query)) {
                    foreach ($table_query as $key => $tableValue) {
                        if ($tableValue['res_table_id'] != null) {
                            array_push($table_arr, $tableValue['res_table_id']);
                            array_push($table_name, $tableValue['name']);
                            $pax = $tableValue['pax'];
                        }
                    }
                }

                //For web pickup and delivery
                if ($type == 'PickupOrDelivery' || $type == 'Pickup' || $type == 'TrackOrder' || $type == 'Delivery') {
                    $last_4_card_digits = "**** **** **** " . $value['last_4_card_digits'];
                    $d_date = $value['d_date'];
                    $d_time = $value['d_time'];
                    $d_address = $value['d_address'];
                    $business_location_name_for_pickup = $value['business_location_name_for_pickup'];
                    $business_location_mobile_for_pickup = $value['business_location_mobile_for_pickup'];
                    $business_location_name_for_delivery = $value['business_location_name_for_delivery'];
                    $business_location_mobile_for_delivery = $value['business_location_mobile_for_delivery'];
                    $order_no = $value['order_no'];
                    $pickup_completed = $value['pickup_completed'];
                    $lalamove_orderRef = $value['lalamove_orderRef'];
                    $lalamove_status = $value['lalamove_status'];
                    $lalamove_driver_info = '';
                    if ($type == 'Delivery') {
                        $order = json_decode($value['lalamove_result'], true);
                        if (!empty($order)) {
                            if (!empty($order['data']['order']['driverId'])) {
                                $lalamove_driver_id = $order['data']['order']['driverId'];
                            } else if (!empty($order['driverId'])) {
                                $lalamove_driver_id = $order['driverId'];
                            } else {
                                $lalamove_driver_id = '';
                            }

                            if ($lalamove_driver_id != '') {
                                $lalamove_driver_info = $this->check_driver_details($lalamove_orderRef, $lalamove_driver_id, $value['business_id'], $value['location_id']);
                                $lalamove_driver_info = json_decode($lalamove_driver_info, true);
                            }
                        }
                    }
                } else {
                    $last_4_card_digits = '';
                    $d_date = '';
                    $d_time = '';
                    $d_address = '';
                    $business_location_name_for_pickup = '';
                    $business_location_mobile_for_pickup = '';
                    $business_location_name_for_delivery = '';
                    $business_location_mobile_for_delivery = '';
                    $order_no = '';
                    $pickup_completed = '';
                    $lalamove_orderRef = '';
                    $lalamove_status = '';
                    $lalamove_driver_info = '';
                }

                $check_contact_access = Contact::join('user_contact_access AS uca', 'contacts.id', 'uca.contact_id')
                    ->where('uca.contact_id', $value['contact_id'])->first();

                if ($check_contact_access) {
                    $user_query = User::where('id', $check_contact_access->user_id)->first();

                    $member_mobile = $user_query->contact_number;
                    $member_dob = $user_query->dob;
                } else {
                    $member_mobile = "";
                    $member_dob = "";
                }
                $final_total = round($final_total - $value['round_off_amount'], 2);
                $transaction_result[] = [
                    'app_order_id' => $value['app_order_id'],
                    'id' => $value['id'],
                    'business_id' => $value['business_id'],
                    'location_id' => $value['location_id'],
                    'transaction_date' => $value['transaction_date'],
                    'table_id' => $table_arr,
                    'table_name' => $table_name,
                    'pax' => $pax,
                    'invoice_no' => $value['invoice_no'],
                    'order_check_no' => $value['order_check_no'],
                    'ref_no' => $value['ref_no'],
                    'order_no' => $value['order_no'],
                    'type' => $value['type'],
                    'type_for_api' => $value['type_for_api'],
                    'total' => $final_total,
                    'round_off_amount' => round($latest_round_off_amount, 2),
                    'paymentType' => $value['method'],
                    'card_type' => $value['card_type'],
                    'tax_id' => $value['tax_id'],
                    'contact_id' => $value['contact_id'],
                    'tax_amount' => $tax_amount,
                    'addon_discount' => ($value['profit_percent'] == null ? 0 : $value['profit_percent']),
                    'discount_type' => $value['discount_type'],
                    'discount_amount' => $discount_amount,
                    'service_charge' => $value['service_charges'],
                    'delivery_charge' => $value['delivery_charges'],
                    'reward_amount' => $value['rp_redeemed'],
                    'customer_reward_amount' => $value['rp_redeemed_amount'],
                    'service_charge_amount' => $service_charge_amount,
                    'tax_rate_amount' => $value['tax_rate_amount'],
                    'profit_percent' => $value['profit_percent'],
                    'return_exists' => $value['return_exists'],
                    'refund_all' => $value['refund_all'],
                    'total_dont_have_line_discount_amt' => $total_dont_have_line_discount_amt,
                    //'total_line_discount_amount' => $total_line_discount_amount,
                    'final_total_for_single_item' => $final_total_for_single_item,
                    'received_amount' => $value['received_amount'],
                    'last_4_card_digits' => $last_4_card_digits,
                    'd_date' => $d_date,
                    'd_time' => $d_time,
                    'd_address' => $d_address,
                    'business_location_name_for_pickup' => $business_location_name_for_pickup,
                    'business_location_mobile_for_pickup' => $business_location_mobile_for_pickup,
                    'business_location_name_for_delivery' => $business_location_name_for_delivery,
                    'business_location_mobile_for_delivery' => $business_location_mobile_for_delivery,
                    'order_no' => $order_no,
                    'pickup_completed' => $pickup_completed,
                    'lalamove_orderRef' => $lalamove_orderRef,
                    'lalamove_status' => $lalamove_status,
                    'lalamove_driver_info' => $lalamove_driver_info,
                    'shipping_charges' => $value['shipping_charges'],
                    'first_name' => $value['contact']->first_name,
                    'last_name' => $value['contact']->last_name,
                    'estimated_arrival_time' => Carbon::parse(Carbon::parse($value['transaction_date'])->addHour())->format('d/m/Y h:ia'),
                    'updated_at' => Carbon::parse($value['updated_at'])->format('d/m/Y h:ia'),
                    'deposit' => $value['deposit'],
                    'member_mobile' => $member_mobile,
                    'member_dob' => $member_dob,
                    'item' => $item,
                    'payments' => $payments,
                    'is_inclusive_gst_applied' => $value['is_inclusive_gst_applied'] ? true : false,
                    'contact_ids' => $value['contact_ids'] ? explode(',', $value['contact_ids']) : null
                ];

            }

            if ($transaction_id == null && $type != 'PickupOrDelivery') {
                $query = CashRegister::where('business_id', $business_id)
                    ->where('location_id', $location_id)
                    ->with(['cash_register_transactions'])
                    ->where('user_id', $user_id);

                // dd( $today, $tomorrow );

                if (!empty($created_at)) {
                    // $query->whereDate('cash_registers.created_at', $created_at);
                    $query->whereBetween('cash_registers.created_at', [$today, $tomorrow]);
                } else {
                    $query->whereDate('cash_registers.created_at', \Carbon::now()->format('Y-m-d 00:00:00'));
                }

                $cash_registers = $query->get();

                // Remove Business Open/Close Time once tested properly FC
                return [
                    "sells" => $transaction_result,
                    "cash_registers" => $cash_registers,
                    // "business_time" => [
                    //     "start" => preg_replace('/\s+/', '', $dayStartTime),
                    //     "end" => preg_replace('/\s+/', '', $dayEndTime)
                    // ]
                ];
            } else {
                return ["sells" => $transaction_result];
            }
        } catch (\Exception $e) {
            DB::rollBack();

            \Log::emergency("File:" . $e->getFile() . "Line:" . $e->getLine() . "Message:" . $e->getMessage());
            $msg = __('messages.something_went_wrong');

            $output = [
                'errorMessage' => $msg
            ];

            return $output;
        }
    }

    public function track_order(Request $request)
    {
        $order_data = $request->only('business_id', 'location_id', 'contact_id');

        $all_sale_history = $this->get_sale_history(null, $order_data['business_id'], $order_data['location_id'], 'final', null, 'TrackOrder', null, $order_data['contact_id']);

        return $all_sale_history;
    }

    public function track_order_history(Request $request)
    {
        $business_id = $request['business_id'];
        $location_id = $request['location_id'];
        $contact_id = $request['contact_id'];

        $all_sale_history = $this->get_sale_history(null, $business_id, $location_id, 'final', null, 'PickupOrDelivery', null, $contact_id);

        return $all_sale_history;
    }

    function view_pickup_order(Request $request)
    {
        $user_data = $request->only('business_id', 'location_id', 'token', 'user_id', 'transaction_id');
        //return $user_data;
        if (isset($user_data['token'])) {
            $result = User::checkUserToken($user_data['token'], $user_data['user_id']);

            if ($result) {
                $id = $user_data['transaction_id'];
                $user_id = $user_data['user_id'];
                $business_id = $user_data['business_id'];
                $location_id = $user_data['location_id'];
                $transaction_status = "final";
                $created_at = null;
                $type = "Pickup"; //Pickup

                $all_sale_history = $this->get_sale_history($user_id, $business_id, $location_id, $transaction_status, $created_at, $type, $id);

                return $all_sale_history;
            } else {
                return ["errorMessage" => 'Invalid token.'];
            }
        } else {
            return ["errorMessage" => 'Invalid token.'];
        }
    }

    function view_delivery_order(Request $request)
    {
        $user_data = $request->only('business_id', 'location_id', 'token', 'user_id', 'transaction_id');
        //return $user_data;
        if (isset($user_data['token'])) {
            $result = User::checkUserToken($user_data['token'], $user_data['user_id']);

            if ($result) {
                $id = $user_data['transaction_id'];
                $user_id = $user_data['user_id'];
                $business_id = $user_data['business_id'];
                $location_id = $user_data['location_id'];
                $transaction_status = "final";
                $created_at = null;
                $type = "Delivery";

                $all_sale_history = $this->get_sale_history($user_id, $business_id, $location_id, $transaction_status, $created_at, $type, $id);

                return $all_sale_history;
            } else {
                return ["errorMessage" => 'Invalid token.'];
            }
        } else {
            return ["errorMessage" => 'Invalid token.'];
        }
    }


     function calculateItemTotalForDineIn($sellLines, $orderType = "Dinein", $globalDiscount = 0.0, $globalDiscountType = "fixed", $redeemedPoints = 0.0 , $transaction_id, $coupon_amount_used = 0.0 , $coupon_details = null) {
        if (empty($sellLines)) {
            return 0.0;
        }

        // Step 5 - All Items without discount
        $allItemsWithoutDiscount = array_filter($sellLines, function($item) {
            return $item['line_discount_amount'] <= 0.0;
        });

        $allItemsWithoutDiscountPrice = array_map(function($item) {
            $quantity = $item['quantity'] ? $item['quantity'] : 1; // to do  
            return ($item['unit_price_before_discount'] ?? 0.0) * $quantity;
        }, $allItemsWithoutDiscount);

        $allItemsWithoutDiscountTotal = array_sum($allItemsWithoutDiscountPrice);

        // Step 6 - Dinein Items Weight
        $globalDiscountPrice = $globalDiscount ?? 0.0;
        $itemWeightPrice = 0.0;

        $itemWeightWithGlobalDiscount = array_map(function($item) use ($globalDiscountPrice, $allItemsWithoutDiscountTotal, $orderType ,$globalDiscountType, $coupon_amount_used, $coupon_details) {
            $quantity = $item['quantity'] ? $item['quantity'] : 1; // to do  
            $itemTotal = ($item['unit_price_before_discount'] ?? 0.0)  * $quantity;
            $is_refund = $item['quantity_returned'] > 0 ? true :false; 
            $coupon_amount_used_total = 0;
            if($coupon_amount_used > 0){
                $coupon_details = json_decode($coupon_details);
                if($coupon_details->coupon_type == "discount")
                {
                    $coupon_amount_used_total = $coupon_amount_used;
                    $itemTotal = $itemTotal - ($itemTotal * $coupon_amount_used) / $allItemsWithoutDiscountTotal;
                }
              }
            
            if($globalDiscountType == 'fixed'){
                if( $allItemsWithoutDiscountTotal > 0.0)
                {
                     $itemWeightPrice = $itemTotal - ($itemTotal * $globalDiscountPrice) / ($allItemsWithoutDiscountTotal - $coupon_amount_used_total);
                  }
                  else{
                     $itemWeightPrice = $itemTotal ;
                  }   
            }
            elseif($globalDiscountType == 'percentage'){
                    
                $itemWeightPrice = $itemTotal - ($itemTotal * $globalDiscountPrice);
                
            }
            else{

                $itemWeightPrice = $itemTotal;
            }    
            $itemTag = ($orderType === 'Takeaway') 
                ? ($item['tag'] === 'T' || $item['tag'] === '' || $item['tag'] === null ? 'T' : 'D') 
                : ($item['tag'] === 'D' || $item['tag'] === '' || $item['tag'] === null ? 'D' : 'T');
            return ['price' => $itemWeightPrice, 'tag' => $itemTag, 'is_refund' => $is_refund];
        }, $allItemsWithoutDiscount);
        
        // Step 8 - All Items with Rp Amount weight
        $itemsWithIndividualDiscount = array_filter($sellLines, function($item) {
            return $item['line_discount_amount'] > 0.0;
        });

        $itemsWithIndividualDiscount = array_map(function($item) use ($orderType) {
            $quantity = $item['quantity'] ? $item['quantity'] : 1; // to do  
            $itemPrice = ($item['unit_price_before_discount'] ?? 0.0) * $quantity ;
            $itemDiscount = ($item['line_discount_type'] === 'percentage') 
                ? $itemPrice * ($item['line_discount_amount'] / 100) 
                : $item['line_discount_amount'];
            $finalPrice = $itemPrice - $itemDiscount;
            $is_refund = $item['quantity_returned'] > 0 ? true :false; 
            $itemTag = ($orderType === 'Takeaway') 
                ? ( $item['tag'] === 'T' || $item['tag'] === '' || $item['tag'] === null ? 'T' : 'D') 
                : ($item['tag'] === 'D' || $item['tag'] === '' || $item['tag'] === null ? 'D' : 'T');
            return ['price' => $finalPrice, 'tag' => $itemTag, 'is_refund' => $is_refund];
        }, $itemsWithIndividualDiscount);

        $allItemWithUpdatedPrice = array_merge($itemsWithIndividualDiscount, $itemWeightWithGlobalDiscount);

        $allUpdatedItemPicesTotalRP = array_sum(array_column($allItemWithUpdatedPrice, 'price'));

        $rpAmount = $redeemedPoints ?? 0.0;

        $allItemsWithRpUsedAmount = array_map(function($item) use ($rpAmount, $allUpdatedItemPicesTotalRP) {
            $itemTotal = $item['price'];
            $is_refund = $item['quantity_returned'] > 0 ? true :false; 
              if( $allUpdatedItemPicesTotalRP > 0.0)
                {
                     $itemWeightPrice =  $itemTotal - ($itemTotal * $rpAmount) / $allUpdatedItemPicesTotalRP;
                     $rp_redeemed_total = ($itemTotal * $rpAmount) / $allUpdatedItemPicesTotalRP;
                  }
                  else{
                    $rp_redeemed_total = 0;
                     $itemWeightPrice =  $itemTotal;
                  }   
            
            return ['price' => $itemWeightPrice, 'tag' => $item['tag'], 'is_refund' => $item['is_refund'], 'rp_redeemed_total' => $rp_redeemed_total];
        }, $allItemWithUpdatedPrice);


        $filterFinalDineinItemsForSrv = array_filter($allItemsWithRpUsedAmount, function($item) {
            return $item['tag'] !== 'T' && !$item['is_refund'];
        });

        $dineInItemsTotalForSrvChargeWithRP = array_sum(array_column(array_filter($filterFinalDineinItemsForSrv, function($item) {
            return $item['tag'] !== 'T';
        }), 'price'));

        // dd($allItemsWithRpUsedAmount)

        return $dineInItemsTotalForSrvChargeWithRP;
    }
    function calculateItemTotalForVoucher($sellLines, $orderType = "Dinein", $globalDiscount = 0.0, $globalDiscountType = "fixed", $redeemedPoints = 0.0 , $transaction_id) {
        if (empty($sellLines)) {
            return 0.0;
        }

        // Step 5 - All Items without discount
        $allItemsWithoutDiscount = array_filter($sellLines, function($item) {
            return $item['line_discount_amount'] <= 0.0;
        });

        $allItemsWithoutDiscountPrice = array_map(function($item) {
            $quantity = $item['quantity'] ? $item['quantity'] : 1; // to do  
            return ($item['unit_price_before_discount'] ?? 0.0) * $quantity;
        }, $allItemsWithoutDiscount);

        $allItemsWithoutDiscountTotal = array_sum($allItemsWithoutDiscountPrice);

        // Step 6 - Dinein Items Weight
        $globalDiscountPrice = $globalDiscount ?? 0.0;
        $itemWeightPrice = 0.0;

        $itemWeightWithGlobalDiscount = array_map(function($item) use ($globalDiscountPrice, $allItemsWithoutDiscountTotal, $orderType ,$globalDiscountType) {
            $quantity = $item['quantity'] ? $item['quantity'] : 1; // to do  
            $itemTotal = ($item['unit_price_before_discount'] ?? 0.0)  * $quantity;
            $is_refund = $item['quantity_returned'] > 0 ? true :false; 
            if($globalDiscountType == 'fixed'){
                if( $allItemsWithoutDiscountTotal > 0.0)
                {
                     $itemWeightPrice = $itemTotal - ($itemTotal * $globalDiscountPrice) / $allItemsWithoutDiscountTotal;
                  }
                  else{
                     $itemWeightPrice = $itemTotal ;
                  }   
            }
            elseif($globalDiscountType == 'percentage'){
                    
                $itemWeightPrice = $itemTotal - ($itemTotal * $globalDiscountPrice);
                
            }
            else{

                $itemWeightPrice = $itemTotal;
            }    
            $itemTag = ($orderType === 'Takeaway') 
                ? ($item['tag'] === 'T' || $item['tag'] === '' || $item['tag'] === null ? 'T' : 'D') 
                : ($item['tag'] === 'D' || $item['tag'] === '' || $item['tag'] === null ? 'D' : 'T');
            return ['price' => $itemWeightPrice, 'tag' => $itemTag, 'is_refund' => $is_refund];
        }, $allItemsWithoutDiscount);
        
        // Step 8 - All Items with Rp Amount weight
        $itemsWithIndividualDiscount = array_filter($sellLines, function($item) {
            return $item['line_discount_amount'] > 0.0;
        });

        $itemsWithIndividualDiscount = array_map(function($item) use ($orderType) {
            $quantity = $item['quantity'] ? $item['quantity'] : 1; // to do  
            $itemPrice = ($item['unit_price_before_discount'] ?? 0.0) * $quantity ;
            $itemDiscount = ($item['line_discount_type'] === 'percentage') 
                ? $itemPrice * ($item['line_discount_amount'] / 100) 
                : $item['line_discount_amount'];
            $finalPrice = $itemPrice - $itemDiscount;
            $is_refund = $item['quantity_returned'] > 0 ? true :false; 
            $itemTag = ($orderType === 'Takeaway') 
                ? ( $item['tag'] === 'T' || $item['tag'] === '' || $item['tag'] === null ? 'T' : 'D') 
                : ($item['tag'] === 'D' || $item['tag'] === '' || $item['tag'] === null ? 'D' : 'T');
            return ['price' => $finalPrice, 'tag' => $itemTag, 'is_refund' => $is_refund];
        }, $itemsWithIndividualDiscount);

        $allItemWithUpdatedPrice = array_merge($itemsWithIndividualDiscount, $itemWeightWithGlobalDiscount);

        $allUpdatedItemPicesTotalRP = array_sum(array_column($allItemWithUpdatedPrice, 'price'));

        $rpAmount = $redeemedPoints ?? 0.0;

        $allItemsWithRpUsedAmount = array_map(function($item) use ($rpAmount, $allUpdatedItemPicesTotalRP) {
            $itemTotal = $item['price'];
            $is_refund = $item['quantity_returned'] > 0 ? true :false; 
              if( $allUpdatedItemPicesTotalRP > 0.0)
                {
                     $itemWeightPrice =  $itemTotal - ($itemTotal * $rpAmount) / $allUpdatedItemPicesTotalRP;
                  }
                  else{
                     $itemWeightPrice =  $itemTotal;
                  }   
            
            return ['price' => $itemWeightPrice, 'tag' => $item['tag'], 'is_refund' => $item['is_refund']];
        }, $allItemWithUpdatedPrice);
         // Voucher calculations
         $filterFinalVoucherItem = array_sum(array_column(array_filter($allItemsWithRpUsedAmount, function($item) use ($sellLineIds) {
            return $item;
        }), 'price'));

        $filterFinalItemsForVoucher =  array_filter($allItemsWithRpUsedAmount, function($item) {
            return $item['tag'] !== 'T';
        });
        $filterFinalItemsPriceForVoucher = array_sum(array_column(array_filter($filterFinalItemsForVoucher, function($item) {
            return $item['tag'] !== 'T';
        }), 'price'));
        //

        $filterFinalDineinItemsForSrv = array_filter($allItemsWithRpUsedAmount, function($item) {
            return $item['tag'] !== 'T' && !$item['is_refund'];
        });

        $dineInItemsTotalForSrvChargeWithRP = array_sum(array_column(array_filter($filterFinalDineinItemsForSrv, function($item) {
            return $item['tag'] !== 'T';
        }), 'price'));

        return (object)['dineSRV' => $dineInItemsTotalForSrvChargeWithRP, 'dineSRVRefund' => $dineInItemsTotalForSrvChargeWithRPRefund, "finalTotalRefundAmount" => $finalTotalRefundAmount, 'filterFinalVoucherItem' =>$filterFinalVoucherItem, 'filterFinalItemsPriceForVoucher'=>$filterFinalItemsPriceForVoucher];
        
    }
  function get_sale_history($user_id, $business_id, $location_id, $transaction_status, $created_at, $type, $transaction_id = null, $contact_id = null, $current_time = null, $terminal_id = null, $all_terminals = 0, $start_date = null , $end_date = null)
    {
        $today = "";
        $tomorrow = "";
        $businessLocation = BusinessLocation::find($location_id);
        if (!empty($businessLocation) && !empty($businessLocation->day_start_time)) {
            $daystartTime = $businessLocation->day_start_time;
            $dayStartTime = $daystartTime . ":00:00";
            $dayendTime = $daystartTime - 1;
            $dayEndTime = $dayendTime . ":59:59";
        } else {
            $dayStartTime = str_replace(' ', '', Config::get('constants.businessStartTimeDefault'));
            $dayEndTime = str_replace(' ', '', Config::get('constants.businessEndTimeDefault'));
        }

        // $dayEndTime = $carbonDayEndTime->format('H:i:s');
        $is_date_range = 0;
        if(!empty($start_date)  && !empty($end_date)){

            $is_date_range =1;
        }
        

        if (isset($dayStartTime) && !empty($businessLocation) && !empty($businessLocation->day_start_time) && !empty($current_time) && !empty($created_at) && $is_date_range == 0) {
            $morning6TimeStamp = strtotime($created_at . $dayEndTime);

            $dateTimeStamp = strtotime($created_at . " " . $current_time);
            if ($dateTimeStamp >= $morning6TimeStamp) {
                $today = $created_at . ' ' . $dayStartTime;
                $tomorrow = date('Y-m-d', strtotime($created_at . ' +1 day')) . ' ' . $dayEndTime;
            } else {
                $today = date('Y-m-d', strtotime($created_at . ' -1 day')) . ' ' . $dayStartTime;
                $tomorrow = $created_at . ' ' . $dayEndTime;
            }
        } 
        elseif($is_date_range == 1){
             $morning6TimeStamp = strtotime($start_date . $dayEndTime);
             $dateTimeStamp = strtotime($start_date . " " . $dayStartTime);

            if ($dateTimeStamp >= $morning6TimeStamp) {
                $today = $start_date . ' ' . $dayStartTime;
                $tomorrow = date('Y-m-d', strtotime($end_date . ' +1 day')) . ' ' . $dayEndTime;
            } else {
                $today = date('Y-m-d', strtotime($start_date)) . ' ' . $dayStartTime;
                $tomorrow = $end_date . ' ' . $dayEndTime;
            }
        }
        else {
            $today = $created_at . Config::get('constants.businessStartTimeDefault');
            $tomorrow = $created_at . Config::get('constants.businessEndTimeDefault');
        }

        try {
            $query = Transaction::leftjoin('transaction_payments as t', 't.transaction_id', '=', 'transactions.id')
                ->leftjoin('variations as w', 'w.product_id', '=', 'transactions.additional_discount_method')
                ->leftjoin('tax_rates as z', 'z.id', '=', 'transactions.tax_id')
                ->leftJoin('transactions AS SR', 'transactions.id', '=', 'SR.return_parent_id')
                ->with('sell_lines.variations.product.category')
                ->with('payment_lines')
                ->with('void_items.modifiers')
                // ->with('contact')
                ->where('transactions.business_id', $business_id)
                ->where('transactions.location_id', $location_id)
                //->where('transactions.created_by', $user_id)
                ->where('transactions.type', 'sell')
                //->where('transactions.type_for_api', 'Takeaway')
                ->where('transactions.is_direct_sale', 0);

            //For terminal id filter
            if($terminal_id != null && $all_terminals == 0){
                $query->where(function($query) use ($terminal_id) {
                    $query->where('transactions.terminal_id', $terminal_id)
                          ->orWhereNull('transactions.terminal_id');
                });
            }

            //For web pickup and delivery
            if ($contact_id != null) {
                $query->where('transactions.contact_id', $contact_id);

                if (!empty($created_at)) {
                    // $query->whereDate('transactions.created_at', $created_at); //2021-08-15 00:00:00
                    $query->whereBetween('transactions.updated_at', [$today, $tomorrow]);
                }
            }

            if ($transaction_id != null) {
                $query->where('transactions.id', $transaction_id);
            }
            // else if($type == 'TrackOrder')
            // {
            //     $query->whereDate('transactions.created_at','=', Carbon::today());
            // }
            else if ($type != 'PickupOrDelivery' && $type != 'TrackOrder' && $contact_id == null) {
                if (!empty($created_at)) {
                    // $query->whereDate('transactions.created_at', $created_at); //2021-08-15 00:00:00
                    $query->whereBetween('transactions.updated_at', [$today, $tomorrow]);
                } else {
                    // $query->whereDate('transactions.created_at', \Carbon::now()->format('Y-m-d 00:00:00'));
                    $query->whereBetween('transactions.updated_at', [$today, $tomorrow]);
                }
            }

            if (!empty($type)) {
                //For web pickup and delivery
                if ($type == 'PickupOrDelivery' || $type == 'Pickup' || $type == 'TrackOrder' || $type == 'Delivery') {
                    $query->leftJoin(
                        'delivery_details AS DD',
                        'transactions.id',
                        '=',
                        'DD.transaction_id'
                    )
                        ->leftJoin(
                            'business_locations AS BL',
                            'DD.outlet',
                            '=',
                            'BL.id'
                        )
                        ->leftJoin(
                            'business_locations AS BLD',
                            'transactions.location_id',
                            '=',
                            'BLD.id'
                        );
                    if ($type == 'PickupOrDelivery') {
                        $query->where(function ($query) use ($contact_id, $business_id, $location_id) {
                            $query->where('transactions.type_for_api', '=', 'Pickup')
                                ->where('transactions.pickup_completed', '=', 1)
                                ->where('transactions.contact_id', $contact_id)
                                ->where('transactions.business_id', $business_id)
                                ->where('transactions.location_id', $location_id);
                        })->orWhere(function ($query) use ($contact_id, $business_id, $location_id) {
                            $query->where('transactions.type_for_api', '=', 'Delivery')
                                ->where('transactions.lalamove_status', '!=', 'ASSIGNING_DRIVER')
                                ->where('transactions.lalamove_status', '!=', 'ON_GOING')
                                ->where('transactions.lalamove_status', '!=', 'PICKED_UP')
                                ->where('transactions.contact_id', $contact_id)
                                ->where('transactions.business_id', $business_id)
                                ->where('transactions.location_id', $location_id);
                        });
                    } else if ($type == 'TrackOrder') {
                        $query->where(function ($query) use ($contact_id, $business_id, $location_id) {
                            $query->where('transactions.type_for_api', '=', 'Pickup')
                                ->where('transactions.pickup_completed', '=', 0)
                                ->where('transactions.contact_id', $contact_id)
                                ->where('transactions.business_id', $business_id)
                                ->where('transactions.location_id', $location_id);
                        })->orWhere(function ($query) use ($contact_id, $business_id, $location_id) {
                            $query->where('transactions.type_for_api', '=', 'Delivery')
                                ->where('transactions.lalamove_status', '!=', 'COMPLETED')
                                ->where('transactions.lalamove_status', '!=', 'EXPIRED')
                                ->where('transactions.lalamove_status', '!=', 'CANCELED')
                                ->where('transactions.lalamove_status', '!=', 'REJECTED')
                                ->where('transactions.contact_id', $contact_id)
                                ->where('transactions.business_id', $business_id)
                                ->where('transactions.location_id', $location_id);
                        });
                    }
                } else {
                    $query->where('transactions.type_for_api', $type);
                }
            } else {
                $query->where(function ($query) {
                    $query->where('transactions.type_for_api', 'Dinein')
                        ->orWhere('transactions.type_for_api', 'Takeaway')
                        ->orWhere('transactions.type_for_api', 'Retail')
                        ->orWhere('transactions.type_for_api', 'Kiosk')
                        ->orWhere('transactions.type_for_api', 'Common');
                });
            }

            if ($transaction_status == 'quotation') {
                $query->where('transactions.status', 'draft')
                    ->where('transactions.sub_status', 'quotation');
            } elseif ($transaction_status == 'draft') {
                $query->where('transactions.status', 'draft')
                    ->whereNull('transactions.sub_status');
            } else {
                $query->where('transactions.status', $transaction_status);
            }

            // $transaction_sub_type = $request->get('transaction_sub_type');
            // if (!empty($transaction_sub_type)) {
            //$query->where('transactions.sub_type', $transaction_sub_type);
            // } else {
            //     $query->where('transactions.sub_type', null);
            // }

            $query->orderBy('transactions.updated_at', 'desc')
                ->groupBy('transactions.id');

            //For web pickup and delivery
            if ($type == 'PickupOrDelivery' || $type == 'Pickup' || $type == 'TrackOrder' || $type == 'Delivery') {
                $transactions = $query->select(
                    'transactions.*',
                    't.amount as received_amount',
                    't.method',
                    't.card_type',
                    't.last_4_card_digits',
                    'w.profit_percent',
                    'z.amount as tax_rate_amount',
                    DB::raw('COUNT(SR.id) as return_exists'),
                    'SR.refund_all',
                    'DD.d_date',
                    'DD.d_time',
                    'DD.d_address',
                    'BL.name as business_location_name_for_pickup',
                    'BL.mobile as business_location_mobile_for_pickup',
                    'BLD.name as business_location_name_for_delivery',
                    'BLD.mobile as business_location_mobile_for_delivery'
                )
                    ->with(['contact'])
                    ->get();
            } else {
                $transactions = $query->select('transactions.*', 't.amount as received_amount', 't.method', 't.card_type', 't.last_4_card_digits', 'w.profit_percent', 'z.amount as tax_rate_amount', DB::raw('COUNT(SR.id) as return_exists'), 'SR.refund_all')
                    ->with(['contact'])
                    //->limit(5)
                    ->get();
            }

            $retail_gst = 0;
            $business_tax_rates = TaxRate::where('business_id', $business_id)
                ->get()
                ->toArray();

            for ($i = 0; $i < count($business_tax_rates); $i++) {
                if (strtolower($business_tax_rates[$i]['name']) == 'gst') {
                    $retail_gst = $business_tax_rates[$i]['amount'];
                }
            }

            $businessUtil = new BusinessUtil();
            $business = $businessUtil->getDetails($business_id);
            $pos_settings = json_decode($business->pos_settings);

            //return $transactions;
            $transaction_result = [];
            $total_dont_have_line_discount_amt = 0;
            //$final_total_for_single_item = 0;
            foreach ($transactions as $key => $value) {
                $item = [];
                $payments = [];
                $final_total_for_single_item = 0;
                $final_total_line_discount_amount = 0;
                $service_charge_amount = 0;
                $increment = 0;
                $sellArray1 = $value['sell_lines'];
                $finalItems = [];
                $return_credit_note_exist = 0;

                foreach ($sellArray1->toArray() as $key => $item_sellLine) {
                    if ($item_sellLine['parent_sell_line_id'] == null) { 
                        $mainItem = $item_sellLine;
                        // dd($mainItem);
                        $mainItemPrice = $mainItem['unit_price_before_discount'];
                        foreach ($sellArray1->toArray() as $modifier) {
                            if (!empty($modifier['parent_sell_line_id']) && $modifier['parent_sell_line_id'] == $mainItem['id'] && $item_sellLine["change_price"] == 0 && $modifier["children_type"] == "modifier") {
                                $mainItemPrice += $modifier['unit_price_before_discount']; // Add the modifier price to the main product price
                            }
                        }
                        // Update the main product price
                        $mainItem['unit_price_before_discount'] = $mainItemPrice;
                        // Add the updated main item to the final result array
                        $finalItems[] = $mainItem;
                    }
                }        
                $dineService  = $this->calculateItemTotalForDineIn($finalItems, $value['type_for_api'], $value['discount_amount'], $value['discount_type'], $value['rp_redeemed_amount'], $value['id'] , $value['coupon_amount_used'], $value['coupon_details']);

                foreach ($value['sell_lines'] as $sellLinesKey => $sellLinesValue) {
                    $total_line_discount_amount = 0;
                    if ($sellLinesValue["parent_sell_line_id"] == null && $sellLinesValue["transaction_id"] == $value['id']) {
                        $adons = [];
                        $combo_adons = [];
                        $total_for_single_item = 0;
                        foreach ($value['sell_lines'] as $sellLinesKey1 => $sellLinesValue1) {

                            if ($sellLinesValue1["parent_sell_line_id"] != null && $sellLinesValue1["parent_sell_line_id"] == $sellLinesValue['id'] && $sellLinesValue1["children_type"] == "modifier") {
                                if (isset($sellLinesValue1['variations']) && !empty($sellLinesValue1['variations'])) {

                                    $adons[] = [
                                        'id' => $sellLinesValue1['variations']->id,
                                        'modifier_set_id' => $sellLinesValue1['variations']->product_id,
                                        'modifier_sell_line_id' => $sellLinesValue1['id'],
                                        'name' => $sellLinesValue1['variations']->name,
                                        'quantity' => $sellLinesValue1["quantity"],
                                        'amount' => $sellLinesValue1['unit_price_before_discount'], //unit_price_before_discount
                                        'not_for_receipt' => $sellLinesValue1['variations']->product->not_for_receipt,
                                        'modifier_app_id' => $sellLinesValue1['modifier_app_ids'],
                                        'name_in_second_language' => $sellLinesValue1['variations']->name_in_second_language,
                                        'short_hand_name' => $sellLinesValue1['variations']->short_hand_name,
                                        'merge_qty' => $sellLinesValue1['product']->merge_qty
                                    ];
                                }
                                if ($sellLinesValue["quantity_returned"] == "0.0000" && $sellLinesValue["change_price"] == 0) {
                                    //total modifier price
                                    $total_for_single_item = $total_for_single_item + $sellLinesValue1['unit_price_before_discount'];
                                }

                            } else if ($sellLinesValue1["parent_sell_line_id"] != null && $sellLinesValue1["parent_sell_line_id"] == $sellLinesValue['id'] && $sellLinesValue1["children_type"] == "combo") {
                                $combo_adons[] = [
                                    'transaction_sell_lines_id' => $sellLinesValue1['id'],
                                    'product_id' => $sellLinesValue1['product_id'],
                                    'variation_id' => $sellLinesValue1['variation_id'],
                                    'quantity' => $sellLinesValue1['quantity'],
                                ];
                            }
                        }

                        $sub_unit_id = !empty($sellLinesValue['sub_unit_id']) ? $sellLinesValue['sub_unit_id'] : "";

                        $sub_unit_multiplier = UNIT::where('id', $sub_unit_id)->get();
                        $base_unit_multiplier = !empty($sub_unit_multiplier[0]['base_unit_multiplier']) ? $sub_unit_multiplier[0]['base_unit_multiplier'] : 1;

                        //main item price + modifier price
                        if ($sellLinesValue['weight'] > 0) {

                            $total_for_single_item = ($sellLinesValue['unit_price_before_discount'] + $total_for_single_item) * $sellLinesValue["quantity"];

                            // if(!empty($base_unit_multiplier)) {
                            //     $total_for_single_item = $total_for_single_item/$base_unit_multiplier;
                            // }
                        } else {
                            $total_for_single_item = ($sellLinesValue['unit_price_before_discount'] + $total_for_single_item) * $sellLinesValue["quantity"];

                            // if(!empty($base_unit_multiplier)) {
                            //     $total_for_single_item = $total_for_single_item/$base_unit_multiplier;
                            // }
                        }

                        if ($increment == 0) {
                            $total_dont_have_line_discount_amt = 0;
                        }
                        if ($sellLinesValue["quantity_returned"] == "0.0000") {
                            $final_total_for_single_item += $total_for_single_item;
                            //calculate if line item has line discount
                            if ($sellLinesValue['line_discount_type'] == "fixed") {
                                $total_line_discount_amount += $sellLinesValue['line_discount_amount'];
                            } else if ($sellLinesValue['line_discount_type'] == "percentage") {
                                $total_line_discount_amount = (($sellLinesValue['line_discount_amount'] / 100) * $total_for_single_item) + $total_line_discount_amount;
                            }
                            //calculate final total line discount amount
                            $final_total_line_discount_amount += $total_line_discount_amount;
                            //total if item dont have line discount amount
                            if ($total_line_discount_amount == 0) {
                                $total_dont_have_line_discount_amt += $total_for_single_item;
                            }
                        } 

                        if ($sellLinesValue['added_by_qr'] == 0) {
                            $sellLinesValue['added_by_qr'] = 'false';
                        } else {
                            $sellLinesValue['added_by_qr'] = 'true';
                        }

                        $short_code = null;
                        if (isset($sellLinesValue['variations']->product) && isset($sellLinesValue['variations']->product->category) && isset($sellLinesValue['variations']->product->category->short_code)) {
                            $short_code = $sellLinesValue['variations']->product->category->short_code;
                        }

                        $combo_products = [];
                        $variations = Product::where('business_id', $business_id)
                            ->with(['variations'])
                            ->find($sellLinesValue['product_id']);
                        if (isset($variations['variations']) && $variations['variations'] && count($variations['variations'])) {
                            foreach ($variations['variations'] as $key => $each) {
                                $variation = json_decode($each);
                                if ($variation->combo_variations && count($variation->combo_variations)) {
                                    foreach ($variation->combo_variations as $key => $combo_variation) {
                                        $combo_product = Variation::where('variations.id', $combo_variation->variation_id)
                                            ->join('products AS p', 'variations.product_id', '=', 'p.id')
                                            ->select(['p.*', 'variations.name as variation_name'])
                                            ->first();
                                        $combo_product['quantity'] = round($combo_variation->quantity, 2);

                                        $serving_days = $combo_product['serving_days'];

                                        if (is_null($serving_days) || $serving_days === "[]") {
                                            $combo_product['serving_days'] = []; 
                                        } else {
                                            $decoded = json_decode($serving_days, true);

                                            if (json_last_error() === JSON_ERROR_NONE) {
                                                $combo_product['serving_days'] = $decoded; 
                                            } else {
                                                $combo_product['serving_days'] = []; 
                                            }
                                        }

                                        $not_for_selling_by_pos_locations = $combo_product['not_for_selling_by_pos_locations'];

                                        if (is_null($not_for_selling_by_pos_locations) || $not_for_selling_by_pos_locations === "[]") {
                                            $combo_product['not_for_selling_by_pos_locations'] = []; 
                                        } else {
                                            $decoded = json_decode($not_for_selling_by_pos_locations, true);

                                            if (json_last_error() === JSON_ERROR_NONE) {
                                                $combo_product['not_for_selling_by_pos_locations'] = $decoded; 
                                            } else {
                                                $combo_product['not_for_selling_by_pos_locations'] = []; 
                                            }
                                        }

                                        $combo_suppliers_sku = $combo_product['suppliers_sku'];
                                        
                                        if (is_null($combo_suppliers_sku) || $combo_suppliers_sku == "null" || trim($combo_suppliers_sku) === "" || $combo_suppliers_sku === '[]') {
                                            $combo_product['suppliers_sku'] = []; 
                                        } else {
                                            $decodedSku = json_decode($combo_suppliers_sku, true);

                                            if (json_last_error() === JSON_ERROR_NONE && is_array($decodedSku)) {
                                                $combo_product['suppliers_sku'] = $decodedSku;
                                            } else {
                                                // Check if $suppliers_sku is a comma-separated string
                                                if (strpos($combo_suppliers_sku, ',') !== false) {
                                                    $combo_product['suppliers_sku'] = array_map('trim', explode(',', $combo_product['suppliers_sku']));
                                                    $combo_product['suppliers_sku'] = array_map(function($sku) {
                                                        return trim($sku, '"');
                                                    }, $combo_product['suppliers_sku']);
                                                } else {
                                                    $combo_product['suppliers_sku'] = [trim($combo_product['suppliers_sku'], '"')];
                                                }
                                            }
                                        }

                                        $combo_products[] = $combo_product;
                                    }
                                }
                            }
                        }

                        $sub_unit_id = !empty($sellLinesValue['variations']->product->sub_unit_ids[0]) ? $sellLinesValue['variations']->product->sub_unit_ids[0] : "";

                        $sub_unit_multiplier = UNIT::where('id', $sub_unit_id)->get();
                        $base_unit_multiplier = !empty($sub_unit_multiplier[0]['base_unit_multiplier']) ? $sub_unit_multiplier[0]['base_unit_multiplier'] : 1;

                        $variations_name = '';
                        if($value['type_for_api'] == 'Retail')
                        {
                                $variation_id = $sellLinesValue['variation_id'];
                                $variations_details = Variation::where('id', $variation_id)->first();
                                $variations_name = !empty($variations_details) ? $variations_details->name : "";

                        }

                        $product_data = Product::where('business_id', $business_id)
                            ->find($sellLinesValue['product_id']);
                            
                        if(!empty($variations_name) && $value['type_for_api'] == 'Retail'){
                            $variations_name = ' - '.$variations_name; 
                        }
                        else{
                            $variations_name = ""; 
                            
                        }
                        $item[] = [
                            'transaction_sell_line_id' => $sellLinesValue['id'],
                            'category_id' => !empty($sellLinesValue['variations']->product->category_id) ? $sellLinesValue['variations']->product->category_id : null,
                            'name' => !empty($sellLinesValue['variations']->product) ? $sellLinesValue['variations']->product->name.''.$variations_name : null,
                            'short_code' => $short_code,
                            // 'quantity' => $sellLinesValue['quantity']/$base_unit_multiplier,
                            'quantity' => $sellLinesValue['quantity'],
                            'quantity_returned' => $sellLinesValue["quantity_returned"],
                            'quantity_returned_note' => $sellLinesValue["quantity_returned_note"],
                            'unit_id' => !empty($sellLinesValue['variations']->product) ? $sellLinesValue['variations']->product->unit_id : null,
                            // 'sub_unit_id' => $sub_unit_id,
                            'amount' => $sellLinesValue['unit_price_before_discount'],
                            'total_before_tax' => $value['total_before_tax'],
                            'tax_amount' => $value['tax_amount'],
                            'line_discount_type' => $sellLinesValue['line_discount_type'],
                            'line_discount_amount' => $sellLinesValue['line_discount_amount'],
                            'product_id' => $sellLinesValue['product_id'],
                            'variation_id' => $sellLinesValue['variation_id'],
                            'weight' => $sellLinesValue["weight"],
                            'weight_price' => !empty($sellLinesValue['weight_price']) ? $sellLinesValue['weight_price'] : 0,
                            'total_line_discount_amount' => $total_line_discount_amount,
                            'total_for_single_item' => $total_for_single_item,
                            'serve_later_quantity' => $sellLinesValue["serve_later_quantity"],
                            'adons' => $adons,
                            'printed' => $sellLinesValue["printed"],
                            'sell_line_note' => $sellLinesValue["sell_line_note"],
                            'change_price' => $sellLinesValue["change_price"],
                            'combo_variations' => $combo_adons,
                            'app_order_id' => $value['app_order_id'],
                            'app_item_line_id' => $sellLinesValue["app_item_line_id"],
                            'user_id' => $sellLinesValue['user_id'],
                            'added_by_qr' => $sellLinesValue['added_by_qr'],
                            'tag' => !empty($sellLinesValue['tag']) ? $sellLinesValue['tag'] : "",
                            'kitchen_shorthand' => !empty($sellLinesValue['variations']->product->category_id) ? $sellLinesValue['variations']->product->kitchen_shorthand : null,
                            'name_in_second_language' => !empty($sellLinesValue['variations']->product) ? $sellLinesValue['variations']->product->name_in_second_language : null,
                            'show_combo_products' => !empty($sellLinesValue['variations']->product) ? ($sellLinesValue['variations']->product->show_combo_products ? true : false) : null,
                            'combo_products' => $combo_products,
                            'parent_product_group_id' => !empty($sellLinesValue['parent_product_group_id']) ? $sellLinesValue['parent_product_group_id'] : "",
                            'combo_products_category_id' => !empty($sellLinesValue['variations']->product) ? $sellLinesValue['variations']->product->combo_products_category_id : null,
                            'order_placed_by' => !empty($sellLinesValue['order_placed_by']) ? $sellLinesValue['order_placed_by'] : null,
                            'image' =>$product_data->image ? config('constants.awsS3BaseUrl') . "/" . config('constants.awsS3Env') . "/img/" . rawurlencode($product_data->image) : asset('/img/default_food.png'),
                            'refund_credit_note' => $sellLinesValue['refund_credit_note']
                        ];

                        $increment++;
                    }

                    $refund_credit_note = $sellLinesValue['refund_credit_note'];
    
                    if (!empty($refund_credit_note)) {
                        $return_credit_note_exist = 1; 
                        break; 
                    }
                }

                $coupon_amount = 0;
                if(!empty($value['coupon_amount_used']))
                {
                    $coupon_details  = $value['coupon_details'];
                    if(!empty($coupon_details)){
                        $decoded_data = json_decode($coupon_details, true);
                         $coupon_type = $decoded_data["coupon_type"] ?? null;
                        if(!empty($coupon_type) && $coupon_type == "discount"){
                            $coupon_amount = $value['coupon_amount_used'];
                        }
                        else{
                            $coupon_amount = 0.0;
                        }
                    }
                    else{
                        $coupon_amount = 0.0;
                    }
                }

                 $lineDiscountItemtotal = DB::table('transaction_sell_lines as tsl')
                        ->leftJoin('transaction_sell_lines as parent_tsl', 'tsl.parent_sell_line_id', '=', 'parent_tsl.id')
                        ->where('tsl.transaction_id', $value['id'])
                        ->where(function ($query) {
                            $query->where('tsl.line_discount_amount', '>', 0)
                                  ->orWhere(function ($subQuery) {
                                      $subQuery->whereNotNull('tsl.parent_sell_line_id')
                                               ->where('parent_tsl.line_discount_amount', '>', 0);
                                  });
                        })
                        ->sum('tsl.unit_price_before_discount');

                if ($value['discount_type'] == "fixed") {
                    $discount_amount = $value['discount_amount'] + $final_total_line_discount_amount + round($coupon_amount, 2);
                } else if ($value['discount_type'] == "percentage") {
                    if($coupon_amount > 0)
                    {
                       
                        $coupon_amount =($coupon_amount * $total_dont_have_line_discount_amt) / ($value['total_before_tax'] - $lineDiscountItemtotal);
                    }
                    $discount_amount = ($value['discount_amount'] * ($total_dont_have_line_discount_amt - round($coupon_amount, 2))) + $final_total_line_discount_amount + round($coupon_amount, 2);
                }

                // dd($value['discount_amount'] , $total_dont_have_line_discount_amt , round($coupon_amount, 2) , $final_total_line_discount_amount ,round($coupon_amount, 2));
                if($value['rp_redeemed_amount'] > 0) {
                    $service_charge_amount = $dineService * $value['service_charges'];  
                } else {
                    $service_charge_amount = $dineService * $value['service_charges'];
                }

                // }
                //calculate service charges

                $refund_details = Transaction::where('business_id' , $business_id)->where('location_id', $location_id)->where('return_parent_id', $value['id'])->first();
                if($value['return_exists'] == 1) {

                    if($value['discount_type'] == 'fixed') {
                        $discountPercent = ($discount_amount / $value['total_before_tax']) * 100;
                        $discountAmount = ($total_dont_have_line_discount_amt * $discountPercent) / 100;   

                    } else {
                        $discountAmount = $discount_amount;

                    }   
                                                            
                }

                if ($value['delivery_charges'] != 0) {
                    //calculate tax
                    $tax_amount = 0;
                    if ($value['tax_id'] != null) {
                        if ($value["is_inclusive_gst_applied"])
                            $tax_amount = (($final_total_for_single_item - $discount_amount) / (100 + $value['tax_rate_amount'])) * $value['tax_rate_amount'];
                        else
                            $tax_amount = ($value['tax_rate_amount'] / 100) * ($final_total_for_single_item - $discount_amount);
                    }

                    if ($value['is_inclusive_gst_applied'])
                        $final_total = $final_total_for_single_item + $value['delivery_charges'];
                    else
                        $final_total = $final_total_for_single_item + $tax_amount + $value['delivery_charges'];
                } else {
                    //calculate tax
                    $tax_amount = 0;
                    $refund_tax_amount = 0;

                    if ($value['type_for_api'] == 'Retail') {
                        $tax_amount = ($final_total_for_single_item + $service_charge_amount - $discount_amount) - (($final_total_for_single_item + $service_charge_amount - $discount_amount) / (1 + ($retail_gst / 100)));

                        $final_total = round($final_total_for_single_item, 2) + 0 + round($service_charge_amount, 2) - round($discount_amount, 2);
                    } else {
                        if ($value['tax_id'] != null) {

                            if ($value["is_inclusive_gst_applied"])
                                if($value['return_exists'] == 1) {
                                    if(!empty($discount_amount) && !empty($value['total_before_tax']))
                                    {
                                        if ($value['discount_type'] == "fixed") {
                                            $refunded_total = 0;
                                        }
                                        else{
                                            $refunded_total = $refund_details->total_before_tax;
                                        }     

                                        $discountPercent = ($discount_amount / ($value['total_before_tax'] - $refunded_total)) * 100;
                                        $discountAmount = (($total_dont_have_line_discount_amt * $discountPercent) / 100) + $final_total_line_discount_amount;
                                         $tax_amount = (($final_total_for_single_item + $service_charge_amount - $discountAmount) / (100 + $value['tax_rate_amount'])) * $value['tax_rate_amount'];
                                    }
                                    else{
                                         $discountPercent = 0;
                                        $discountAmount = 0;
                                         $tax_amount = (($final_total_for_single_item + $service_charge_amount - $discountAmount -  ($value['rp_redeemed_amount'] - $refund_details->rp_redeemed_amount )) / (100 + $value['tax_rate_amount'])) * $value['tax_rate_amount'];
                                    }

                                   
                                 
                                //$tax_amount = (($final_total_for_single_item + $service_charge_amount ) / (100 + $value['tax_rate_amount'])) * $value['tax_rate_amount'];
                                } else {
                                    if($value['rp_redeemed_amount'] > 0) {

                                        $tax_amount = (($final_total_for_single_item + $service_charge_amount - $discount_amount - $value['rp_redeemed_amount']) / (100 + $value['tax_rate_amount'])) * $value['tax_rate_amount']; 
                                   } else {
                                        $tax_amount = (($final_total_for_single_item + $service_charge_amount - $discount_amount) / (100 + $value['tax_rate_amount'])) * $value['tax_rate_amount'];
                                   }
                                    
                                    //dd($tax_amount);
                                //$tax_amount = (($final_total_for_single_item + $service_charge_amount ) / (100 + $value['tax_rate_amount'])) * $value['tax_rate_amount'];
                                }
                                
                            else
                                if($value['total_before_tax'] && $value['return_exists'] == 1) {
                                    if(!empty($discount_amount)){
                                        if ($value['discount_type'] == "fixed") {
                                                $refunded_total = 0;
                                            }
                                            else{
                                                $refunded_total = $refund_details->total_before_tax;
                                            }  
                                            $discountPercent = ($discount_amount / ($value['total_before_tax'] - $refunded_total)) * 100;
                                            $discountAmount = (($total_dont_have_line_discount_amt * $discountPercent) / 100) + $final_total_line_discount_amount; 
                                        }
                                        else{
                                            $discountAmount = 0;
                                        }
                                        if($value['rp_redeemed_amount'] > 0) {

                                            $tax_amount = ($value['tax_rate_amount'] / 100) * ($final_total_for_single_item + $service_charge_amount - $discountAmount -$coupon_amount - ($value['rp_redeemed_amount'] - $refund_details->rp_redeemed_amount));
                                        } else {
                                            $tax_amount = ($value['tax_rate_amount'] / 100) * ($final_total_for_single_item + $service_charge_amount  - $discountAmount);
                                            // dd($value['tax_rate_amount'], $final_total_for_single_item , $service_charge_amount ,$discountAmount);


                                    }
                                    
                                } else {
                                    if($value['rp_redeemed_amount'] > 0) {
                                        $tax_amount = ($value['tax_rate_amount'] / 100) * ($final_total_for_single_item + $service_charge_amount - $discount_amount - $value['rp_redeemed_amount']);
                                    } else {
                                        $tax_amount = ($value['tax_rate_amount'] / 100) * ($final_total_for_single_item + $service_charge_amount - $discount_amount);


                                    }
                                    
                                }
                                
                        }
                        if ($value['is_inclusive_gst_applied'])
                            
                            if($value['return_exists'] == 1) {
                                // dd($discount_amount , $value['total_before_tax']);

                                if(!empty($discount_amount) && !empty($value['total_before_tax']))
                                {
                                     $discountPercent = ($discount_amount / $value['total_before_tax']) * 100;
                                     $discountAmount = ($total_dont_have_line_discount_amt * $discountPercent) / 100;  
                                }
                                else{
                                     $discountPercent = 0;
                                     $discountAmount = 0;  
                                }
                               



                                if($value['discount_type'] == 'fixed') {
                                    $final_total = round($final_total_for_single_item, 2) + round($service_charge_amount, 2) - $discountAmount;
                                } else {
                                    $final_total = round($final_total_for_single_item, 2) + round($service_charge_amount, 2) - round($discount_amount, 2);

                                }

                            } else {
                                $final_total = round($final_total_for_single_item, 2) + round($service_charge_amount, 2) - round($discount_amount, 2);
                            }
                            
                        else
                            if($value['return_exists'] == 1) {
                                $final_total = round($final_total_for_single_item, 2) + round($tax_amount, 2) + round($service_charge_amount, 2) - round($discountAmount, 2);
                          
                            } else {
                                $final_total = round($final_total_for_single_item, 2) + round($tax_amount, 2) + round($service_charge_amount, 2) - round($discount_amount, 2);
                            }
                            
                    }
                }
                
                if(!empty($value['coupon_amount_used'])){
                    $coupon_voucher_details = json_decode($value['coupon_details'] , true);
                    if($coupon_voucher_details["coupon_type"] == "voucher"){

                        $item_details = $this->calculateItemTotalForVoucher($finalItems, $value['type_for_api'], $value['discount_amount'], $value['discount_type'], $value['rp_redeemed_amount'], $value['id']);

                        $total_before_tax_amount = $item_details->filterFinalVoucherItem;
                        $couponVoucherPercent = ($value['coupon_amount_used'] / $total_before_tax_amount) * 100;
                        $coupon_voucher_amount = $value['coupon_amount_used'];
                        $coupon_voucher_value = round($couponVoucherPercent, 2);   

                        if ($value['return_exists'] == 1) {
                       
                            if($value['is_inclusive_gst_applied']){
                                $couponVoucherAmount = (($final_total  - round($service_charge_amount, 2)) * $coupon_voucher_value) / 100;
                                $final_total =  round($final_total - $couponVoucherAmount, 2);
                            }
                            else{
                                 $couponVoucherAmount = (($final_total - round($tax_amount, 2) - round($service_charge_amount, 2)) * $coupon_voucher_value) / 100;
                                 $final_total =  round($final_total - $couponVoucherAmount, 2);
                            }

                        }
                        else{
                            $final_total =  $final_total - $value['coupon_amount_used'];
                        } 

                    }
                }

                $voucher_amount = 0;
                $voucher_value = 0;
                if(!empty($value['voucher_details'])){
                    $coupon_voucher_amount_used = 0;
                    if(!empty($value['coupon_amount_used'])){
                        $coupon_voucher_details = json_decode($value['coupon_details'] , true);
                        if($coupon_voucher_details["coupon_type"] == "voucher"){
                            $coupon_voucher_amount_used = $value['coupon_amount_used'];
                        }
                    }
                    $item_details = $this->calculateItemTotalForVoucher($finalItems, $value['type_for_api'], $value['discount_amount'], $value['discount_type'], $value['rp_redeemed_amount'], $value['id']);
                    $voucher_details = json_decode($value['voucher_details']);

                    
                    $total_before_tax_amount = $item_details->filterFinalVoucherItem;
                    $voucher_service_charge =$item_details->filterFinalItemsPriceForVoucher * $value['service_charges'];
                    // $total_before_tax_amount+=$voucher_service_charge;
                    
                    $voucherPercent = ($value['voucher_amount_used'] / ($total_before_tax_amount - $coupon_voucher_amount_used)) * 100;
                    $voucher_amount = $value['voucher_amount_used'];
                    $voucher_value = round($voucherPercent, 2);               

                    
                    if ($value['return_exists'] == 1) {
                       
                        if($value['is_inclusive_gst_applied']){
                            $voucherAmount = (($final_total  - round($service_charge_amount, 2)) * $voucher_value) / 100;
                            $final_total =  round($final_total - $voucherAmount, 2);
                        }
                        else{
                             $voucherAmount = (($final_total - round($tax_amount, 2) - round($service_charge_amount, 2)) * $voucher_value) / 100;
                             $final_total =  round($final_total - $voucherAmount, 2);
                        }

                    }
                    else{
                        $voucher_data = json_decode($value['voucher_details']);
                        $final_total =  $final_total - $value['voucher_amount_used'];
                    }


                }
                if($value['return_exists'] == 1) {
                   $final_total = round($final_total + $value['round_off_amount'], 2);
                }
                // $amount_rounding_method = $pos_settings->amount_rounding_method;
                $amount_rounding_method = $value['amount_rounding_method'];
                $payment_method = $value->method;
                $latest_round_off_amount = $value['round_off_amount'];
                $final_total = round($final_total - $value['round_off_amount'], 2);
                if ($value['return_exists'] == 1){
                    if($value['discount_type'] == "fixed")  {
                        $discountPercent = ($discount_amount / $value['total_before_tax']) * 100;
                        $discountAmount = ($total_dont_have_line_discount_amt * $discountPercent) / 100;
                        $discount_amount = $discountAmount;
                    }
                }

                if($value['rp_redeemed_amount'] > 0 && $value['return_exists'] != 1) {
                    $final_total = $final_total - $value['rp_redeemed_amount'];
                } elseif($value['rp_redeemed_amount'] > 0 && $value['return_exists'] == 1) {
                    $rp_redeemed_amount_percent = ($value['rp_redeemed_amount'] / $value['total_before_tax']) * 100;
                    $rp_redeemed_amount = ($total_dont_have_line_discount_amt * $rp_redeemed_amount_percent) / 100;

                    $final_total = $final_total - $rp_redeemed_amount;
                }

                if(!empty($value['tip_amount'])){
                    $final_total += $value['tip_amount']; 
                }
            
                // For multiple payment
                foreach ($value['payment_lines'] as $payment_lines_key => $payment_line) {
                    if (count($value['payment_lines']) == 1) {
                        if ($final_total > 0) {
                            if(!empty($value['round_off_amount']))
                            {

                                $cash_received_amount = $final_total; 
                            }
                            else {
                                $cash_received_amount = $final_total;
                            }
                            
                        } else {
                            $cash_received_amount = $final_total;
                        }
                    } else {
                        if ($value['refund_all'] == 1) {
                            $cash_received_amount = 0;
                        } else {
                            $cash_received_amount = $payment_line['amount'];
                        }
                    }
                    $payments[] = [
                        'transaction_payment_id' => $payment_line['id'],
                        'method' => $payment_line['method'],
                        'card_type' => $payment_line['card_type'],
                        'last_4_card_digits' => $payment_line['last_4_card_digits'],
                        'received_amount' => $cash_received_amount
                    ];
                }

                $table_arr = [];
                $table_name = [];
                $pax = '';

                $static_table_id = !empty($value['res_table_id']) ? $value['res_table_id'] : "";
                if(!empty($static_table_id)) {
                    $table = ResTable::find($static_table_id);
                    if ($table) {
                        $table_name[] = $table->name;
                        $table_id = $static_table_id; // Set the table_id to static_table_id
                        $table_arr[] = $static_table_id; // Add static_table_id to table_arr
                    }
                } else {
                    $table_query = Transaction::leftjoin('pos_res_tables as t', 't.transaction_id', '=', 'transactions.id')
                        ->leftjoin('res_tables as z', 'z.id', '=', 't.res_table_id')
                        ->where('transactions.id', $value['id'])
                        ->select('t.res_table_id', 'pax', 'z.name')
                        ->get();
                    // ->dump();

                    if (!empty($table_query)) {
                        foreach ($table_query as $key => $tableValue) {
                            if ($tableValue['res_table_id'] != null) {
                                array_push($table_arr, $tableValue['res_table_id']);
                                array_push($table_name, $tableValue['name']);
                                $pax = $tableValue['pax'];
                            }
                        }
                    }
                }
                

                //For web pickup and delivery
                if ($type == 'PickupOrDelivery' || $type == 'Pickup' || $type == 'TrackOrder' || $type == 'Delivery') {
                    $last_4_card_digits = "**** **** **** " . $value['last_4_card_digits'];
                    $d_date = $value['d_date'];
                    $d_time = $value['d_time'];
                    $d_address = $value['d_address'];
                    $business_location_name_for_pickup = $value['business_location_name_for_pickup'];
                    $business_location_mobile_for_pickup = $value['business_location_mobile_for_pickup'];
                    $business_location_name_for_delivery = $value['business_location_name_for_delivery'];
                    $business_location_mobile_for_delivery = $value['business_location_mobile_for_delivery'];
                    $order_no = $value['order_no'];
                    $pickup_completed = $value['pickup_completed'];
                    $lalamove_orderRef = $value['lalamove_orderRef'];
                    $lalamove_status = $value['lalamove_status'];
                    $lalamove_driver_info = '';
                    if ($type == 'Delivery') {
                        $order = json_decode($value['lalamove_result'], true);
                        if (!empty($order)) {
                            if (!empty($order['data']['order']['driverId'])) {
                                $lalamove_driver_id = $order['data']['order']['driverId'];
                            } else if (!empty($order['driverId'])) {
                                $lalamove_driver_id = $order['driverId'];
                            } else {
                                $lalamove_driver_id = '';
                            }

                            if ($lalamove_driver_id != '') {
                                $lalamove_driver_info = $this->check_driver_details($lalamove_orderRef, $lalamove_driver_id, $value['business_id'], $value['location_id']);
                                $lalamove_driver_info = json_decode($lalamove_driver_info, true);
                            }
                        }
                    }
                } else {
                    $last_4_card_digits = '';
                    $d_date = '';
                    $d_time = '';
                    $d_address = '';
                    $business_location_name_for_pickup = '';
                    $business_location_mobile_for_pickup = '';
                    $business_location_name_for_delivery = '';
                    $business_location_mobile_for_delivery = '';
                    $order_no = '';
                    $pickup_completed = '';
                    $lalamove_orderRef = '';
                    $lalamove_status = '';
                    $lalamove_driver_info = '';
                }

                $check_contact_access = Contact::join('user_contact_access AS uca', 'contacts.id', 'uca.contact_id')
                    ->where('uca.contact_id', $value['contact_id'])->first();

                if ($check_contact_access) {
                    $user_query = User::where('id', $check_contact_access->user_id)->first();

                    $member_mobile = $user_query->contact_number;
                    $member_dob = $user_query->dob;
                } else {
                    $member_mobile = "";
                    $member_dob = "";
                }

                // //Temperorary condition
                // if($value['rp_redeemed_amount'] > 0 ) {
                //     $tax_amount = 0;
                // }
                

                $transaction_result[] = [
                    'app_order_id' => $value['app_order_id'],
                    'id' => $value['id'],
                    'terminal_id' => !empty($value['terminal_id']) ? $value['terminal_id'] : "",
                    'business_id' => $value['business_id'],
                    'location_id' => $value['location_id'],
                    'transaction_date' => $value['transaction_date'],
                    'table_id' => $table_arr,
                    'table_name' => $table_name,
                    'pax' => $pax,
                    'invoice_no' => $value['invoice_no'],
                    'order_check_no' => $value['order_check_no'],
                    'ref_no' => $value['ref_no'],
                    'order_no' => $value['order_no'],
                    'type' => $value['type'],
                    'type_for_api' => $value['type_for_api'],
                    'total' => $final_total,
                    'round_off_amount' => round($latest_round_off_amount, 2),
                    'paymentType' => $value['method'],
                    'card_type' => $value['card_type'],
                    'tax_id' => $value['tax_id'],
                    'contact_id' => $value['contact_id'],
                    'tax_amount' => $tax_amount,
                    'addon_discount' => ($value['profit_percent'] == null ? 0 : $value['profit_percent']),
                    'discount_type' => $value['discount_type'],
                    'discount_amount' => $discount_amount,
                    'service_charge' => $value['service_charges'],
                    'delivery_charge' => $value['delivery_charges'],
                    'reward_amount' => $value['rp_redeemed'],
                    'customer_reward_amount' => $value['rp_redeemed_amount'],
                    'service_charge_amount' => $service_charge_amount,
                    'tax_rate_amount' => $value['tax_rate_amount'],
                    'profit_percent' => $value['profit_percent'],
                    'return_exists' => $value['return_exists'],
                    'refund_all' => $value['refund_all'],
                    'total_dont_have_line_discount_amt' => $total_dont_have_line_discount_amt,
                    //'total_line_discount_amount' => $total_line_discount_amount,
                    'final_total_for_single_item' => $final_total_for_single_item,
                    'received_amount' => $value['received_amount'],
                    'last_4_card_digits' => $last_4_card_digits,
                    'd_date' => $d_date,
                    'd_time' => $d_time,
                    'd_address' => $d_address,
                    'business_location_name_for_pickup' => $business_location_name_for_pickup,
                    'business_location_mobile_for_pickup' => $business_location_mobile_for_pickup,
                    'business_location_name_for_delivery' => $business_location_name_for_delivery,
                    'business_location_mobile_for_delivery' => $business_location_mobile_for_delivery,
                    'order_no' => $order_no,
                    'pickup_completed' => $pickup_completed,
                    'lalamove_orderRef' => $lalamove_orderRef,
                    'lalamove_status' => $lalamove_status,
                    'lalamove_driver_info' => $lalamove_driver_info,
                    'shipping_charges' => $value['shipping_charges'],
                    'first_name' => $value['contact']->first_name,
                    'last_name' => $value['contact']->last_name,
                    'estimated_arrival_time' => Carbon::parse(Carbon::parse($value['transaction_date'])->addHour())->format('d/m/Y h:ia'),
                    'updated_at' => Carbon::parse($value['updated_at'])->format('d/m/Y h:ia'),
                    'deposit' => $valuget_sale_history_attaphousee['deposit'],
                    'member_mobile' => $member_mobile,
                    'member_dob' => $member_dob,
                    'item' => $item,
                    'payments' => $payments,
                    'is_inclusive_gst_applied' => $value['is_inclusive_gst_applied'] ? true : false,
                    'tag_number' => $value['tag_number'],
                    'discount_type_id' => $value['discount_type_id'],
                    'open_discount_value' => $value['open_discount_value'],
                    'commission_type' => $value['commission_type'],
                    'status' => $value['status'],
                    'extra_tag' => !empty($value['extra_tag']) ? $value['extra_tag'] : null,
                    'cash_change_amount' => $value['cash_change_amount'],
                    'cash_received_amount' => $value['cash_received_amount'],
                    'order_platform' => $value['order_platform'],
                    'rp_unit_per_amount' => $value['rp_unit_per_amount'],
                    'is_voucher_applied' => $value['is_voucher_applied'],
                    'voucher_details' =>!empty($value['voucher_details']) ? json_decode($value['voucher_details']) :null,
                    'tip_amount' => !empty($value['tip_amount']) ? $value['tip_amount'] :0.0,
                    'voucher_amount_used' => !empty($value['voucher_amount_used']) ? $value['voucher_amount_used'] :0.0,
                    'is_coupon_applied' => !empty($value['is_coupon_applied']) ? $value['is_coupon_applied'] : 0,
                    'coupon_details' => !empty($value['coupon_details']) ? json_decode($value['coupon_details']) : null,
                    'coupon_amount_used' => !empty($value['coupon_amount_used']) ? $value['coupon_amount_used'] : null,
                    'return_credit_note_exist' => $return_credit_note_exist,
                    'void_items' => !empty($value['void_items']) ? $value['void_items'] : null,
                ];

            }
            if ($transaction_id == null && $type != 'PickupOrDelivery') {
                $query = CashRegister::where('business_id', $business_id)
                    ->where('location_id', $location_id)
                    ->with(['cash_register_transactions'])
                    ->where('user_id', $user_id);

                // dd( $today, $tomorrow );

                if (!empty($created_at)) {
                    // $query->whereDate('cash_registers.created_at', $created_at);
                    $query->whereBetween('cash_registers.created_at', [$today, $tomorrow]);
                } else {
                    $query->whereDate('cash_registers.created_at', \Carbon::now()->format('Y-m-d 00:00:00'));
                }

                $cash_registers = $query->get();


                // Remove Business Open/Close Time once tested properly FC
                return [
                    "sells" => $transaction_result,
                    "cash_registers" => $cash_registers,
                    "business_time" => [
                        "start" => preg_replace('/\s+/', '', $dayStartTime),
                        "end" => preg_replace('/\s+/', '', $dayEndTime)
                    ],
                    "business_location_timing" => [
                        "start" => $today,
                        "end" => $tomorrow
                    ]
                ];
            } else {
                return ["sells" => $transaction_result];
            }
        } catch (\Exception $e) {
            DB::rollBack();

            \Log::emergency("File:" . $e->getFile() . "Line:" . $e->getLine() . "Message:" . $e->getMessage());
            $msg = __('messages.something_went_wrong');

            $output = [
                'errorMessage' => $msg
            ];

            return $output;
        }
    }
    
    function get_sale_history_attaphouse($user_id, $business_id, $location_id, $transaction_status, $created_at, $type, $transaction_id = null, $contact_id = null, $current_time = null, $terminal_id = null, $pagination = null)
    {
        $today = "";
        $tomorrow = "";
        $businessLocation = BusinessLocation::find($location_id);
        if (!empty($businessLocation) && !empty($businessLocation->day_start_time)) {
            $daystartTime = $businessLocation->day_start_time;
            $dayStartTime = $daystartTime . ":00:00";
            $dayendTime = $daystartTime - 1;
            $dayEndTime = $dayendTime . ":59:59";
        } else {
            $dayStartTime = str_replace(' ', '', Config::get('constants.businessStartTimeDefault'));
            $dayEndTime = str_replace(' ', '', Config::get('constants.businessEndTimeDefault'));
        }

        // $dayEndTime = $carbonDayEndTime->format('H:i:s');

        if (isset($dayStartTime) && !empty($businessLocation) && !empty($businessLocation->day_start_time) && !empty($current_time) && !empty($created_at)) {
            $morning6TimeStamp = strtotime($created_at . $dayEndTime);
            $dateTimeStamp = strtotime($created_at . " " . $current_time);
            if ($dateTimeStamp >= $morning6TimeStamp) {
                $today = $created_at . ' ' . $dayStartTime;
                $tomorrow = date('Y-m-d', strtotime($created_at . ' +1 day')) . ' ' . $dayEndTime;
            } else {
                $today = date('Y-m-d', strtotime($created_at . ' -1 day')) . ' ' . $dayStartTime;
                $tomorrow = $created_at . ' ' . $dayEndTime;
            }
        } else {
            $today = $created_at . Config::get('constants.businessStartTimeDefault');
            $tomorrow = $created_at . Config::get('constants.businessEndTimeDefault');
        }

        //dd( $today, $tomorrow );
        $transactionData = [];

        try {
            $query = Transaction::leftjoin('transaction_payments as t', 't.transaction_id', '=', 'transactions.id')
                ->leftjoin('variations as w', 'w.product_id', '=', 'transactions.additional_discount_method')
                ->leftjoin('tax_rates as z', 'z.id', '=', 'transactions.tax_id')
                ->leftJoin('transactions AS SR', 'transactions.id', '=', 'SR.return_parent_id')
                ->with('sell_lines.variations.product.category')
                ->with('payment_lines')
                // ->with('contact')
                ->where('transactions.business_id', $business_id)
                ->where('transactions.location_id', $location_id)
                //->where('transactions.created_by', $user_id)
                ->where('transactions.type', 'sell')
                //->where('transactions.type_for_api', 'Takeaway')
                ->where('transactions.is_direct_sale', 0);

            //For terminal id filter
            if($terminal_id != null){
                $query->where(function($query) use ($terminal_id) {
                    $query->where('transactions.terminal_id', $terminal_id)
                          ->orWhereNull('transactions.terminal_id');
                });
            }

            //For web pickup and delivery
            if ($contact_id != null) {
                $query->where('transactions.contact_id', $contact_id);

                if (!empty($created_at)) {
                    // $query->whereDate('transactions.created_at', $created_at); //2021-08-15 00:00:00
                    $query->whereBetween('transactions.updated_at', [$today, $tomorrow]);
                }
            }

            if ($transaction_id != null) {
                $query->where('transactions.id', $transaction_id);
            }
            // else if($type == 'TrackOrder')
            // {
            //     $query->whereDate('transactions.created_at','=', Carbon::today());
            // }
            else if ($type != 'PickupOrDelivery' && $type != 'TrackOrder' && $contact_id == null) {
                if (!empty($created_at)) {
                    // $query->whereDate('transactions.created_at', $created_at); //2021-08-15 00:00:00
                    $query->whereBetween('transactions.updated_at', [$today, $tomorrow]);
                } else {
                    // $query->whereDate('transactions.created_at', \Carbon::now()->format('Y-m-d 00:00:00'));
                    $query->whereBetween('transactions.updated_at', [$today, $tomorrow]);
                }
            }

            if (!empty($type)) {
                //For web pickup and delivery
                if ($type == 'PickupOrDelivery' || $type == 'Pickup' || $type == 'TrackOrder' || $type == 'Delivery') {
                    $query->leftJoin(
                        'delivery_details AS DD',
                        'transactions.id',
                        '=',
                        'DD.transaction_id'
                    )
                        ->leftJoin(
                            'business_locations AS BL',
                            'DD.outlet',
                            '=',
                            'BL.id'
                        )
                        ->leftJoin(
                            'business_locations AS BLD',
                            'transactions.location_id',
                            '=',
                            'BLD.id'
                        );
                    if ($type == 'PickupOrDelivery') {
                        $query->where(function ($query) use ($contact_id, $business_id, $location_id) {
                            $query->where('transactions.type_for_api', '=', 'Pickup')
                                ->where('transactions.pickup_completed', '=', 1)
                                ->where('transactions.contact_id', $contact_id)
                                ->where('transactions.business_id', $business_id)
                                ->where('transactions.location_id', $location_id);
                        })->orWhere(function ($query) use ($contact_id, $business_id, $location_id) {
                            $query->where('transactions.type_for_api', '=', 'Delivery')
                                ->where('transactions.lalamove_status', '!=', 'ASSIGNING_DRIVER')
                                ->where('transactions.lalamove_status', '!=', 'ON_GOING')
                                ->where('transactions.lalamove_status', '!=', 'PICKED_UP')
                                ->where('transactions.contact_id', $contact_id)
                                ->where('transactions.business_id', $business_id)
                                ->where('transactions.location_id', $location_id);
                        });
                    } else if ($type == 'TrackOrder') {
                        $query->where(function ($query) use ($contact_id, $business_id, $location_id) {
                            $query->where('transactions.type_for_api', '=', 'Pickup')
                                ->where('transactions.pickup_completed', '=', 0)
                                ->where('transactions.contact_id', $contact_id)
                                ->where('transactions.business_id', $business_id)
                                ->where('transactions.location_id', $location_id);
                        })->orWhere(function ($query) use ($contact_id, $business_id, $location_id) {
                            $query->where('transactions.type_for_api', '=', 'Delivery')
                                ->where('transactions.lalamove_status', '!=', 'COMPLETED')
                                ->where('transactions.lalamove_status', '!=', 'EXPIRED')
                                ->where('transactions.lalamove_status', '!=', 'CANCELED')
                                ->where('transactions.lalamove_status', '!=', 'REJECTED')
                                ->where('transactions.contact_id', $contact_id)
                                ->where('transactions.business_id', $business_id)
                                ->where('transactions.location_id', $location_id);
                        });
                    }
                } else {
                    $query->where('transactions.type_for_api', $type);
                }
            } else {
                $query->where(function ($query) {
                    $query->where('transactions.type_for_api', 'Dinein')
                        ->orWhere('transactions.type_for_api', 'Takeaway')
                        ->orWhere('transactions.type_for_api', 'Retail')
                        ->orWhere('transactions.type_for_api', 'Kiosk')
                        ->orWhere('transactions.type_for_api', 'Common');
                });
            }

            if ($transaction_status == 'quotation') {
                $query->where('transactions.status', 'draft')
                    ->where('transactions.sub_status', 'quotation');
            } elseif ($transaction_status == 'draft') {
                $query->where('transactions.status', 'draft')
                    ->whereNull('transactions.sub_status');
            } else {
                $query->where('transactions.status', $transaction_status);
            }

            // $transaction_sub_type = $request->get('transaction_sub_type');
            // if (!empty($transaction_sub_type)) {
            //$query->where('transactions.sub_type', $transaction_sub_type);
            // } else {
            //     $query->where('transactions.sub_type', null);
            // }

            $query->orderBy('transactions.updated_at', 'desc')
                ->groupBy('transactions.id');

            //For web pickup and delivery
            $perPage = $pagination['limit'] ? $pagination['limit'] : 10;
            $pageNumber = $pagination['page_number'] ? $pagination['page_number'] : 1;
            if ($type == 'PickupOrDelivery' || $type == 'Pickup' || $type == 'TrackOrder' || $type == 'Delivery') {
                $transactions = $query->select(
                    'transactions.*',
                    't.amount as received_amount',
                    't.method',
                    't.card_type',
                    't.last_4_card_digits',
                    'w.profit_percent',
                    'z.amount as tax_rate_amount',
                    DB::raw('COUNT(SR.id) as return_exists'),
                    'SR.refund_all',
                    'DD.d_date',
                    'DD.d_time',
                    'DD.d_address',
                    'BL.name as business_location_name_for_pickup',
                    'BL.mobile as business_location_mobile_for_pickup',
                    'BLD.name as business_location_name_for_delivery',
                    'BLD.mobile as business_location_mobile_for_delivery'
                )
                    ->with(['contact'])
                    ->paginate($perPage, ['*'], 'page', $pageNumber);
            } else {
                $transactions = $query->select('transactions.*', 't.amount as received_amount', 't.method', 't.card_type', 't.last_4_card_digits', 'w.profit_percent', 'z.amount as tax_rate_amount', DB::raw('COUNT(SR.id) as return_exists'), 'SR.refund_all')
                    ->with(['contact'])
                    ->paginate($perPage, ['*'], 'page', $pageNumber);
            }
            $pagination_data = [
                'current_page' => $transactions->currentPage(),
                'total_pages' => $transactions->lastPage(),
                'per_page' => $transactions->perPage(),
                'total' => $transactions->total(),
              ];
            $retail_gst = 0;
            $business_tax_rates = TaxRate::where('business_id', $business_id)
                ->get()
                ->toArray();

            for ($i = 0; $i < count($business_tax_rates); $i++) {
                if (strtolower($business_tax_rates[$i]['name']) == 'gst') {
                    $retail_gst = $business_tax_rates[$i]['amount'];
                }
            }

            $businessUtil = new BusinessUtil();
            $business = $businessUtil->getDetails($business_id);
            $pos_settings = json_decode($business->pos_settings);

            //return $transactions;
            $transaction_result = [];
            $total_dont_have_line_discount_amt = 0;
            //$final_total_for_single_item = 0;
            foreach ($transactions as $key => $value) {
                $item = [];
                $payments = [];
                $final_total_for_single_item = 0;
                $final_total_line_discount_amount = 0;
                $service_charge_amount = 0;
                $increment = 0;

                foreach ($value['sell_lines'] as $sellLinesKey => $sellLinesValue) {

                    $total_line_discount_amount = 0;
                    if ($sellLinesValue["parent_sell_line_id"] == null && $sellLinesValue["transaction_id"] == $value['id']) {
                        $adons = [];
                        $combo_adons = [];
                        $total_for_single_item = 0;
                        foreach ($value['sell_lines'] as $sellLinesKey1 => $sellLinesValue1) {
                            if ($sellLinesValue1["parent_sell_line_id"] != null && $sellLinesValue1["parent_sell_line_id"] == $sellLinesValue['id'] && $sellLinesValue1["children_type"] == "modifier") {
                                if (isset($sellLinesValue1['variations']) && !empty($sellLinesValue1['variations'])) {
                                    $adons[] = [
                                        'id' => $sellLinesValue1['variations']->id,
                                        'modifier_set_id' => $sellLinesValue1['variations']->product_id,
                                        'modifier_sell_line_id' => $sellLinesValue1['id'],
                                        'name' => $sellLinesValue1['variations']->name,
                                        'quantity' => $sellLinesValue1["quantity"],
                                        'amount' => $sellLinesValue1['unit_price_before_discount'], //unit_price_before_discount
                                        'not_for_receipt' => $sellLinesValue1['variations']->product->not_for_receipt,
                                        'modifier_app_id' => $sellLinesValue1['modifier_app_ids'],
                                        'name_in_second_language' => $sellLinesValue1['variations']->name_in_second_language,
                                        'short_hand_name' => $sellLinesValue1['variations']->short_hand_name,
                                        'merge_qty' => $sellLinesValue1['product']->merge_qty
                                    ];
                                }
                                if ($sellLinesValue["quantity_returned"] == "0.0000" && $sellLinesValue["change_price"] == 0) {
                                    //total modifier price
                                    $total_for_single_item = $total_for_single_item + $sellLinesValue1['unit_price_before_discount'];
                                }

                            } else if ($sellLinesValue1["parent_sell_line_id"] != null && $sellLinesValue1["parent_sell_line_id"] == $sellLinesValue['id'] && $sellLinesValue1["children_type"] == "combo") {
                                $combo_adons[] = [
                                    'transaction_sell_lines_id' => $sellLinesValue1['id'],
                                    'product_id' => $sellLinesValue1['product_id'],
                                    'variation_id' => $sellLinesValue1['variation_id'],
                                    'quantity' => $sellLinesValue1['quantity'],
                                ];
                            }
                        }

                        $sub_unit_id = !empty($sellLinesValue['sub_unit_id']) ? $sellLinesValue['sub_unit_id'] : "";

                        $sub_unit_multiplier = UNIT::where('id', $sub_unit_id)->get();
                        $base_unit_multiplier = !empty($sub_unit_multiplier[0]['base_unit_multiplier']) ? $sub_unit_multiplier[0]['base_unit_multiplier'] : 1;

                        //main item price + modifier price
                        if ($sellLinesValue['weight'] > 0) {

                            $total_for_single_item = ($sellLinesValue['unit_price_before_discount'] + $total_for_single_item) * $sellLinesValue["quantity"];

                            // if(!empty($base_unit_multiplier)) {
                            //     $total_for_single_item = $total_for_single_item/$base_unit_multiplier;
                            // }
                        } else {
                            $total_for_single_item = ($sellLinesValue['unit_price_before_discount'] + $total_for_single_item) * $sellLinesValue["quantity"];

                            // if(!empty($base_unit_multiplier)) {
                            //     $total_for_single_item = $total_for_single_item/$base_unit_multiplier;
                            // }
                        }

                        if ($increment == 0) {
                            $total_dont_have_line_discount_amt = 0;
                        }

                        if ($sellLinesValue["quantity_returned"] == "0.0000") {
                            $final_total_for_single_item += $total_for_single_item;
                            //calculate if line item has line discount
                            if ($sellLinesValue['line_discount_type'] == "fixed") {
                                $total_line_discount_amount += $sellLinesValue['line_discount_amount'];
                            } else if ($sellLinesValue['line_discount_type'] == "percentage") {
                                $total_line_discount_amount = (($sellLinesValue['line_discount_amount'] / 100) * $total_for_single_item) + $total_line_discount_amount;
                            }
                            //calculate final total line discount amount
                            $final_total_line_discount_amount += $total_line_discount_amount;
                            //total if item dont have line discount amount
                            if ($total_line_discount_amount == 0) {
                                $total_dont_have_line_discount_amt += $total_for_single_item;
                            }
                        } 

                        if ($sellLinesValue['added_by_qr'] == 0) {
                            $sellLinesValue['added_by_qr'] = 'false';
                        } else {
                            $sellLinesValue['added_by_qr'] = 'true';
                        }

                        $short_code = null;
                        if (isset($sellLinesValue['variations']->product) && isset($sellLinesValue['variations']->product->category) && isset($sellLinesValue['variations']->product->category->short_code)) {
                            $short_code = $sellLinesValue['variations']->product->category->short_code;
                        }

                        $combo_products = [];
                        $variations = Product::where('business_id', $business_id)
                            ->with(['variations'])
                            ->find($sellLinesValue['product_id']);
                        if (isset($variations['variations']) && $variations['variations'] && count($variations['variations'])) {
                            foreach ($variations['variations'] as $key => $each) {
                                $variation = json_decode($each);
                                if ($variation->combo_variations && count($variation->combo_variations)) {
                                    foreach ($variation->combo_variations as $key => $combo_variation) {
                                        $combo_product = Variation::where('variations.id', $combo_variation->variation_id)
                                            ->join('products AS p', 'variations.product_id', '=', 'p.id')
                                            ->select(['p.*', 'variations.name as variation_name'])
                                            ->first();
                                        $combo_product['quantity'] = round($combo_variation->quantity, 2);

                                        $not_for_selling_by_pos_locations = $combo_product['not_for_selling_by_pos_locations'];

                                        if (is_null($not_for_selling_by_pos_locations) || $not_for_selling_by_pos_locations === "[]") { 
                                               $combo_product['not_for_selling_by_pos_locations'] = []; 
                                            } 
                                        else {
                                            $decoded = json_decode($not_for_selling_by_pos_locations, true);

                                            if (json_last_error() === JSON_ERROR_NONE) {
                                                $combo_product['not_for_selling_by_pos_locations'] = $decoded; 
                                            } else {
                                                $combo_product['not_for_selling_by_pos_locations'] = []; 
                                            }
                                        }
                                        $combo_products[] = $combo_product;
                                    }
                                }
                            }
                        }

                        $sub_unit_id = !empty($sellLinesValue['variations']->product->sub_unit_ids[0]) ? $sellLinesValue['variations']->product->sub_unit_ids[0] : "";

                        $sub_unit_multiplier = UNIT::where('id', $sub_unit_id)->get();
                        $base_unit_multiplier = !empty($sub_unit_multiplier[0]['base_unit_multiplier']) ? $sub_unit_multiplier[0]['base_unit_multiplier'] : 1;

                        $item[] = [
                            'transaction_sell_line_id' => $sellLinesValue['id'],
                            'category_id' => !empty($sellLinesValue['variations']->product->category_id) ? $sellLinesValue['variations']->product->category_id : null,
                            'name' => !empty($sellLinesValue['variations']->product) ? $sellLinesValue['variations']->product->name : null,
                            'short_code' => $short_code,
                            // 'quantity' => $sellLinesValue['quantity']/$base_unit_multiplier,
                            'quantity' => $sellLinesValue['quantity'],
                            'quantity_returned' => $sellLinesValue["quantity_returned"],
                            'quantity_returned_note' => $sellLinesValue["quantity_returned_note"],
                            'unit_id' => !empty($sellLinesValue['variations']->product) ? $sellLinesValue['variations']->product->unit_id : null,
                            // 'sub_unit_id' => $sub_unit_id,
                            'amount' => $sellLinesValue['unit_price_before_discount'],
                            'total_before_tax' => $value['total_before_tax'],
                            'tax_amount' => $value['tax_amount'],
                            'line_discount_type' => $sellLinesValue['line_discount_type'],
                            'line_discount_amount' => $sellLinesValue['line_discount_amount'],
                            'product_id' => $sellLinesValue['product_id'],
                            'variation_id' => $sellLinesValue['variation_id'],
                            'weight' => $sellLinesValue["weight"],
                            'weight_price' => !empty($sellLinesValue['weight_price']) ? $sellLinesValue['weight_price'] : 0,
                            'total_line_discount_amount' => $total_line_discount_amount,
                            'total_for_single_item' => $total_for_single_item,
                            'serve_later_quantity' => $sellLinesValue["serve_later_quantity"],
                            'adons' => $adons,
                            'printed' => $sellLinesValue["printed"],
                            'sell_line_note' => $sellLinesValue["sell_line_note"],
                            'change_price' => $sellLinesValue["change_price"],
                            'combo_variations' => $combo_adons,
                            'app_order_id' => $value['app_order_id'],
                            'app_item_line_id' => $sellLinesValue["app_item_line_id"],
                            'user_id' => $sellLinesValue['user_id'],
                            'added_by_qr' => $sellLinesValue['added_by_qr'],
                            'tag' => !empty($sellLinesValue['tag']) ? $sellLinesValue['tag'] : "",
                            'kitchen_shorthand' => !empty($sellLinesValue['variations']->product->category_id) ? $sellLinesValue['variations']->product->kitchen_shorthand : null,
                            'name_in_second_language' => !empty($sellLinesValue['variations']->product) ? $sellLinesValue['variations']->product->name_in_second_language : null,
                            'show_combo_products' => !empty($sellLinesValue['variations']->product) ? ($sellLinesValue['variations']->product->show_combo_products ? true : false) : null,
                            'combo_products' => $combo_products,
                            'parent_product_group_id' => !empty($sellLinesValue['parent_product_group_id']) ? $sellLinesValue['parent_product_group_id'] : "",
                            'combo_products_category_id' => !empty($sellLinesValue['variations']->product) ? $sellLinesValue['variations']->product->combo_products_category_id : null,
                            'order_placed_by' => !empty($sellLinesValue['order_placed_by']) ? $sellLinesValue['order_placed_by'] : null
                        ];

                        $increment++;
                    }
                }

                if ($value['discount_type'] == "fixed") {
                    $discount_amount = $value['discount_amount'] + $final_total_line_discount_amount;
                } else if ($value['discount_type'] == "percentage") {
                    $discount_amount = ($value['discount_amount'] * $total_dont_have_line_discount_amt) + $final_total_line_discount_amount;
                }

                //calculate service charges
                if($value['rp_redeemed_amount'] > 0) {
                    $service_charge_amount = ($final_total_for_single_item - $discount_amount - $value['rp_redeemed_amount']) * $value['service_charges'];  
                } else {
                    $service_charge_amount = ($final_total_for_single_item - $discount_amount) * $value['service_charges'];
                }

                if($value['return_exists'] == 1) {

                    if($value['discount_type'] == 'fixed') {
                        $discountPercent = ($discount_amount / $value['total_before_tax']) * 100;
                        $discountAmount = ($total_dont_have_line_discount_amt * $discountPercent) / 100;            
                    } else {
                        $discountAmount = $discount_amount; 
                    }   
                    
                    if($value['rp_redeemed_amount'] > 0) {
                        $rp_redeemed_amount_percent = ($value['rp_redeemed_amount'] / $value['total_before_tax']) * 100;
                        $rp_redeemed_amount = ($total_dont_have_line_discount_amt * $rp_redeemed_amount_percent) / 100;

                        $service_charge_amount = ($final_total_for_single_item - $discountAmount - $rp_redeemed_amount) * $value['service_charges'];
                    } else {
                        $service_charge_amount = ($final_total_for_single_item - $discountAmount) * $value['service_charges']; 
                    }
                    
                }

                if ($value['delivery_charges'] != 0) {
                    //calculate tax
                    $tax_amount = 0;
                    if ($value['tax_id'] != null) {
                        if ($value["is_inclusive_gst_applied"])
                            $tax_amount = (($final_total_for_single_item - $discount_amount) / (100 + $value['tax_rate_amount'])) * $value['tax_rate_amount'];
                        else
                            $tax_amount = ($value['tax_rate_amount'] / 100) * ($final_total_for_single_item - $discount_amount);
                    }

                    if ($value['is_inclusive_gst_applied'])
                        $final_total = $final_total_for_single_item + $value['delivery_charges'];
                    else
                        $final_total = $final_total_for_single_item + $tax_amount + $value['delivery_charges'];
                } else {
                    //calculate tax
                    $tax_amount = 0;
                    $refund_tax_amount = 0;

                    if ($value['type_for_api'] == 'Retail') {
                        $tax_amount = ($final_total_for_single_item + $service_charge_amount - $discount_amount) - (($final_total_for_single_item + $service_charge_amount - $discount_amount) / (1 + ($retail_gst / 100)));

                        $final_total = round($final_total_for_single_item, 2) + 0 + round($service_charge_amount, 2) - round($discount_amount, 2);
                    } else {
                        if ($value['tax_id'] != null) {

                            if ($value["is_inclusive_gst_applied"])
                                if($value['return_exists'] == 1) {
                                    $discountPercent = ($discount_amount / $value['total_before_tax']) * 100;
                                    $discountAmount = ($total_dont_have_line_discount_amt * $discountPercent) / 100;

                                    $tax_amount = (($final_total_for_single_item + $service_charge_amount - $discountAmount) / (100 + $value['tax_rate_amount'])) * $value['tax_rate_amount'];
                                    //dd($tax_amount);
                                //$tax_amount = (($final_total_for_single_item + $service_charge_amount ) / (100 + $value['tax_rate_amount'])) * $value['tax_rate_amount'];
                                } else {
                                    if($value['rp_redeemed_amount'] > 0) {
                                        $tax_amount = (($final_total_for_single_item + $service_charge_amount - $discount_amount - $value['rp_redeemed_amount']) / (100 + $value['tax_rate_amount'])) * $value['tax_rate_amount']; 
                                   } else {
                                        $tax_amount = (($final_total_for_single_item + $service_charge_amount - $discount_amount) / (100 + $value['tax_rate_amount'])) * $value['tax_rate_amount'];
                                   }
                                    
                                    //dd($tax_amount);
                                //$tax_amount = (($final_total_for_single_item + $service_charge_amount ) / (100 + $value['tax_rate_amount'])) * $value['tax_rate_amount'];
                                }
                                
                            else
                                if($discount_amount != 0 && $value['total_before_tax']) {
                                    $discountPercent = ($discount_amount / $value['total_before_tax']) * 100;
                                    $discountAmount = ($total_dont_have_line_discount_amt * $discountPercent) / 100;
                                    if($value['rp_redeemed_amount'] > 0) {
                                        $tax_amount = ($value['tax_rate_amount'] / 100) * ($final_total_for_single_item + $service_charge_amount - $discountAmount - $value['rp_redeemed_amount']);
                                    } else {
                                        $tax_amount = ($value['tax_rate_amount'] / 100) * ($final_total_for_single_item + $service_charge_amount - $discountAmount);
                                    }
                                    
                                } else {
                                    if($value['rp_redeemed_amount'] > 0) {
                                        $tax_amount = ($value['tax_rate_amount'] / 100) * ($final_total_for_single_item + $service_charge_amount - $discountAmount - $value['rp_redeemed_amount']);
                                    } else {
                                        $tax_amount = ($value['tax_rate_amount'] / 100) * ($final_total_for_single_item + $service_charge_amount - $discount_amount);
                                    }
                                    
                                }
                                
                        }

                        if ($value['is_inclusive_gst_applied'])
                            
                            if($value['return_exists'] == 1) {
                                $discountPercent = ($discount_amount / $value['total_before_tax']) * 100;
                                $discountAmount = ($total_dont_have_line_discount_amt * $discountPercent) / 100;   

                                if($value['discount_type'] == 'fixed') {
                                    $final_total = round($final_total_for_single_item, 2) + round($service_charge_amount, 2) - $discountAmount;
                                } else {
                                    $final_total = round($final_total_for_single_item, 2) + round($service_charge_amount, 2) - round($discount_amount, 2);

                                }

                            } else {
                                $final_total = round($final_total_for_single_item, 2) + round($service_charge_amount, 2) - round($discount_amount, 2);
                            }
                            
                        else
                            if($value['return_exists'] == 1) {
                                $final_total = round($final_total_for_single_item, 2) + round($tax_amount, 2) + round($service_charge_amount, 2);
                            } else {
                                $final_total = round($final_total_for_single_item, 2) + round($tax_amount, 2) + round($service_charge_amount, 2) - round($discount_amount, 2);
                            }
                            
                    }
                }
                if($value['return_exists'] == 1) {
                   $final_total = round($final_total + $value['round_off_amount'], 2);
                }
                // $amount_rounding_method = $pos_settings->amount_rounding_method;
                $amount_rounding_method = $value['amount_rounding_method'];
                $payment_method = $value->method;
                // $latest_round_off_amount = $this->transactionUtil->latest_round_off_amount($payment_method, $final_total, $amount_rounding_method, $value['type_for_api']);
                $latest_round_off_amount = $value['round_off_amount'];
                $final_total = round($final_total - $value['round_off_amount'], 2);
                if ($value['return_exists'] == 1){
                    if($value['discount_type'] == "fixed")  {
                        $discountPercent = ($discount_amount / $value['total_before_tax']) * 100;
                        $discountAmount = ($total_dont_have_line_discount_amt * $discountPercent) / 100;
                        $discount_amount = $discountAmount;
                    }
                }

                if($value['rp_redeemed_amount'] > 0 && $value['return_exists'] != 1) {
                    $final_total = $final_total - $value['rp_redeemed_amount'];
                } elseif($value['rp_redeemed_amount'] > 0 && $value['return_exists'] == 1) {
                    $rp_redeemed_amount_percent = ($value['rp_redeemed_amount'] / $value['total_before_tax']) * 100;
                    $rp_redeemed_amount = ($total_dont_have_line_discount_amt * $rp_redeemed_amount_percent) / 100;

                    $final_total = $final_total - $rp_redeemed_amount;
                }
            
                // For multiple payment
                foreach ($value['payment_lines'] as $payment_lines_key => $payment_line) {
                    if (count($value['payment_lines']) == 1) {
                        if ($final_total > 0) {
                            // $is_rounding_applied = $this->transactionUtil->isRoundingApply($final_total);
                            if(!empty($value['round_off_amount']))
                            {
                                $cash_received_amount = $final_total; //+ $latest_round_off_amount;    
                            }
                            else {
                                $cash_received_amount = $final_total;
                            }
                            
                        } else {
                            $cash_received_amount = $final_total;
                        }
                    } else {
                        if ($value['refund_all'] == 1) {
                            $cash_received_amount = 0;
                        } else {
                            $cash_received_amount = $payment_line['amount'];
                        }
                    }
                    $payments[] = [
                        'transaction_payment_id' => $payment_line['id'],
                        'method' => $payment_line['method'],
                        'card_type' => $payment_line['card_type'],
                        'last_4_card_digits' => $payment_line['last_4_card_digits'],
                        'received_amount' => $cash_received_amount
                    ];
                }

                $table_arr = [];
                $table_name = [];
                $pax = '';

                $table_query = Transaction::leftjoin('pos_res_tables as t', 't.transaction_id', '=', 'transactions.id')
                    ->leftjoin('res_tables as z', 'z.id', '=', 't.res_table_id')
                    ->where('transactions.id', $value['id'])
                    ->select('t.res_table_id', 'pax', 'z.name')
                    ->get();
                // ->dump();

                if (!empty($table_query)) {
                    foreach ($table_query as $key => $tableValue) {
                        if ($tableValue['res_table_id'] != null) {
                            array_push($table_arr, $tableValue['res_table_id']);
                            array_push($table_name, $tableValue['name']);
                            $pax = $tableValue['pax'];
                        }
                    }
                }

                //For web pickup and delivery
                if ($type == 'PickupOrDelivery' || $type == 'Pickup' || $type == 'TrackOrder' || $type == 'Delivery') {
                    $last_4_card_digits = "**** **** **** " . $value['last_4_card_digits'];
                    $d_date = $value['d_date'];
                    $d_time = $value['d_time'];
                    $d_address = $value['d_address'];
                    $business_location_name_for_pickup = $value['business_location_name_for_pickup'];
                    $business_location_mobile_for_pickup = $value['business_location_mobile_for_pickup'];
                    $business_location_name_for_delivery = $value['business_location_name_for_delivery'];
                    $business_location_mobile_for_delivery = $value['business_location_mobile_for_delivery'];
                    $order_no = $value['order_no'];
                    $pickup_completed = $value['pickup_completed'];
                    $lalamove_orderRef = $value['lalamove_orderRef'];
                    $lalamove_status = $value['lalamove_status'];
                    $lalamove_driver_info = '';
                    if ($type == 'Delivery') {
                        $order = json_decode($value['lalamove_result'], true);
                        if (!empty($order)) {
                            if (!empty($order['data']['order']['driverId'])) {
                                $lalamove_driver_id = $order['data']['order']['driverId'];
                            } else if (!empty($order['driverId'])) {
                                $lalamove_driver_id = $order['driverId'];
                            } else {
                                $lalamove_driver_id = '';
                            }

                            if ($lalamove_driver_id != '') {
                                $lalamove_driver_info = $this->check_driver_details($lalamove_orderRef, $lalamove_driver_id, $value['business_id'], $value['location_id']);
                                $lalamove_driver_info = json_decode($lalamove_driver_info, true);
                            }
                        }
                    }
                } else {
                    $last_4_card_digits = '';
                    $d_date = '';
                    $d_time = '';
                    $d_address = '';
                    $business_location_name_for_pickup = '';
                    $business_location_mobile_for_pickup = '';
                    $business_location_name_for_delivery = '';
                    $business_location_mobile_for_delivery = '';
                    $order_no = '';
                    $pickup_completed = '';
                    $lalamove_orderRef = '';
                    $lalamove_status = '';
                    $lalamove_driver_info = '';
                }

                $check_contact_access = Contact::join('user_contact_access AS uca', 'contacts.id', 'uca.contact_id')
                    ->where('uca.contact_id', $value['contact_id'])->first();

                if ($check_contact_access) {
                    $user_query = User::where('id', $check_contact_access->user_id)->first();

                    $member_mobile = $user_query->contact_number;
                    $member_dob = $user_query->dob;
                } else {
                    $member_mobile = "";
                    $member_dob = "";
                }

                // //Temperorary condition
                // if($value['rp_redeemed_amount'] > 0 ) {
                //     $tax_amount = 0;
                // }
                

                $transaction_result[] = [
                    'app_order_id' => $value['app_order_id'],
                    'id' => $value['id'],
                    'terminal_id' => !empty($value['terminal_id']) ? $value['terminal_id'] : "",
                    'business_id' => $value['business_id'],
                    'location_id' => $value['location_id'],
                    'transaction_date' => $value['transaction_date'],
                    'table_id' => $table_arr,
                    'table_name' => $table_name,
                    'pax' => $pax,
                    'invoice_no' => $value['invoice_no'],
                    'order_check_no' => $value['order_check_no'],
                    'ref_no' => $value['ref_no'],
                    'order_no' => $value['order_no'],
                    'type' => $value['type'],
                    'type_for_api' => $value['type_for_api'],
                    'total' => $final_total,
                    'round_off_amount' => round($latest_round_off_amount, 2),
                    'paymentType' => $value['method'],
                    'card_type' => $value['card_type'],
                    'tax_id' => $value['tax_id'],
                    'contact_id' => $value['contact_id'],
                    'tax_amount' => $tax_amount,
                    'addon_discount' => ($value['profit_percent'] == null ? 0 : $value['profit_percent']),
                    'discount_type' => $value['discount_type'],
                    'discount_amount' => $discount_amount,
                    'service_charge' => $value['service_charges'],
                    'delivery_charge' => $value['delivery_charges'],
                    'reward_amount' => $value['rp_redeemed'],
                    'customer_reward_amount' => $value['rp_redeemed_amount'],
                    'service_charge_amount' => $service_charge_amount,
                    'tax_rate_amount' => $value['tax_rate_amount'],
                    'profit_percent' => $value['profit_percent'],
                    'return_exists' => $value['return_exists'],
                    'refund_all' => $value['refund_all'],
                    'total_dont_have_line_discount_amt' => $total_dont_have_line_discount_amt,
                    //'total_line_discount_amount' => $total_line_discount_amount,
                    'final_total_for_single_item' => $final_total_for_single_item,
                    'received_amount' => $value['received_amount'],
                    'last_4_card_digits' => $last_4_card_digits,
                    'd_date' => $d_date,
                    'd_time' => $d_time,
                    'd_address' => $d_address,
                    'business_location_name_for_pickup' => $business_location_name_for_pickup,
                    'business_location_mobile_for_pickup' => $business_location_mobile_for_pickup,
                    'business_location_name_for_delivery' => $business_location_name_for_delivery,
                    'business_location_mobile_for_delivery' => $business_location_mobile_for_delivery,
                    'order_no' => $order_no,
                    'pickup_completed' => $pickup_completed,
                    'lalamove_orderRef' => $lalamove_orderRef,
                    'lalamove_status' => $lalamove_status,
                    'lalamove_driver_info' => $lalamove_driver_info,
                    'shipping_charges' => $value['shipping_charges'],
                    'first_name' => $value['contact']->first_name,
                    'last_name' => $value['contact']->last_name,
                    'estimated_arrival_time' => Carbon::parse(Carbon::parse($value['transaction_date'])->addHour())->format('d/m/Y h:ia'),
                    'updated_at' => Carbon::parse($value['updated_at'])->format('d/m/Y h:ia'),
                    'deposit' => $value['deposit'],
                    'member_mobile' => $member_mobile,
                    'member_dob' => $member_dob,
                    'item' => $item,
                    'payments' => $payments,
                    'is_inclusive_gst_applied' => $value['is_inclusive_gst_applied'] ? true : false,
                    'tag_number' => $value['tag_number'],
                    'discount_type_id' => $value['discount_type_id'],
                    'open_discount_value' => $value['open_discount_value'],
                    'commission_type' => $value['commission_type'],
                    'status' => $value['status'],
                    'extra_tag' => !empty($value['extra_tag']) ? $value['extra_tag'] : null,
                    'cash_change_amount' => $value['cash_change_amount'],
                    'cash_received_amount' => $value['cash_received_amount'],
                    'order_platform' => $value['order_platform'],
                    'rp_unit_per_amount' => $value['rp_unit_per_amount']
                ];

            }
            if ($transaction_id == null && $type != 'PickupOrDelivery') {
                $query = CashRegister::where('business_id', $business_id)
                    ->where('location_id', $location_id)
                    ->with(['cash_register_transactions'])
                    ->where('user_id', $user_id);

                // dd( $today, $tomorrow );

                if (!empty($created_at)) {
                    // $query->whereDate('cash_registers.created_at', $created_at);
                    $query->whereBetween('cash_registers.created_at', [$today, $tomorrow]);
                } else {
                    $query->whereDate('cash_registers.created_at', \Carbon::now()->format('Y-m-d 00:00:00'));
                }

                $cash_registers = $query->get();


                // Remove Business Open/Close Time once tested properly FC
                return [
                    "sells" => $transaction_result,
                    "cash_registers" => $cash_registers,
                    "business_time" => [
                        "start" => preg_replace('/\s+/', '', $dayStartTime),
                        "end" => preg_replace('/\s+/', '', $dayEndTime)
                    ],
                    "business_location_timing" => [
                        "start" => $today,
                        "end" => $tomorrow
                    ],
                    "pagination"=>$pagination_data
                ];
            } else {
                return ["sells" => $transaction_result, "pagination"=>$pagination_data,  "transactionsData"=>$transactionsData];
            }
        } catch (\Exception $e) {
            DB::rollBack();

            \Log::emergency("File:" . $e->getFile() . "Line:" . $e->getLine() . "Message:" . $e->getMessage());
            $msg = __('messages.something_went_wrong');

            $output = [
                'errorMessage' => $msg
            ];

            return $output;
        }
    }

    function get_sale_history2($user_id, $business_id, $location_id, $transaction_status, $created_at, $type, $transaction_id = null, $app_order_id, $contact_id = null)
    {
        try {
            $query = Transaction::leftjoin('transaction_payments as t', 't.app_order_id', '=', 'transactions.app_order_id')
                ->leftjoin('variations as w', 'w.product_id', '=', 'transactions.additional_discount_method')
                ->leftjoin('tax_rates as z', 'z.id', '=', 'transactions.tax_id')
                ->leftJoin('transactions AS SR', 'transactions.app_order_id', '=', 'SR.return_parent_id')
                ->with('sell_lines.variations.product.category')
                ->with('payment_lines')
                ->with('void_items.modifiers')
                // ->with('contact')
                ->where('transactions.business_id', $business_id)
                ->where('transactions.location_id', $location_id)
                //->where('transactions.created_by', $user_id)
                ->where('transactions.type', 'sell')
                //->where('transactions.type_for_api', 'Takeaway')
                ->where('transactions.is_direct_sale', 0);


            //For web pickup and delivery
            if ($contact_id != null) {
                $query->where('transactions.contact_id', $contact_id);

                if (!empty($created_at)) {
                    $query->whereDate('transactions.created_at', $created_at); //2021-08-15 00:00:00
                }
            }

            if ($app_order_id != null) {
                $query->where('transactions.app_order_id', $app_order_id);
            }
            // else if($type == 'TrackOrder')
            // {
            //     $query->whereDate('transactions.created_at','=', Carbon::today());
            // }
            else if ($type != 'PickupOrDelivery' && $type != 'TrackOrder' && $contact_id == null) {
                if (!empty($created_at)) {
                    $query->whereDate('transactions.created_at', $created_at); //2021-08-15 00:00:00
                } else {
                    $query->whereDate('transactions.created_at', \Carbon::now()->format('Y-m-d 00:00:00'));
                }
            }

            if (!empty($type)) {
                //For web pickup and delivery
                if ($type == 'PickupOrDelivery' || $type == 'Pickup' || $type == 'TrackOrder' || $type == 'Delivery') {
                    $query->leftJoin(
                        'delivery_details AS DD',
                        'transactions.app_order_id',
                        '=',
                        'DD.app_order_id'
                    )
                        ->leftJoin(
                            'business_locations AS BL',
                            'DD.outlet',
                            '=',
                            'BL.id'
                        )
                        ->leftJoin(
                            'business_locations AS BLD',
                            'transactions.location_id',
                            '=',
                            'BLD.id'
                        );
                    if ($type == 'PickupOrDelivery') {
                        $query->where(function ($query) use ($contact_id, $business_id, $location_id) {
                            $query->where('transactions.type_for_api', '=', 'Pickup')
                                ->where('transactions.pickup_completed', '=', 1)
                                ->where('transactions.contact_id', $contact_id)
                                ->where('transactions.business_id', $business_id)
                                ->where('transactions.location_id', $location_id);
                        })->orWhere(function ($query) use ($contact_id, $business_id, $location_id) {
                            $query->where('transactions.type_for_api', '=', 'Delivery')
                                ->where('transactions.lalamove_status', '!=', 'ASSIGNING_DRIVER')
                                ->where('transactions.lalamove_status', '!=', 'ON_GOING')
                                ->where('transactions.lalamove_status', '!=', 'PICKED_UP')
                                ->where('transactions.contact_id', $contact_id)
                                ->where('transactions.business_id', $business_id)
                                ->where('transactions.location_id', $location_id);
                        });
                    } else if ($type == 'TrackOrder') {
                        $query->where(function ($query) use ($contact_id, $business_id, $location_id) {
                            $query->where('transactions.type_for_api', '=', 'Pickup')
                                ->where('transactions.pickup_completed', '=', 0)
                                ->where('transactions.contact_id', $contact_id)
                                ->where('transactions.business_id', $business_id)
                                ->where('transactions.location_id', $location_id);
                        })->orWhere(function ($query) use ($contact_id, $business_id, $location_id) {
                            $query->where('transactions.type_for_api', '=', 'Delivery')
                                ->where('transactions.lalamove_status', '!=', 'COMPLETED')
                                ->where('transactions.lalamove_status', '!=', 'EXPIRED')
                                ->where('transactions.lalamove_status', '!=', 'CANCELED')
                                ->where('transactions.lalamove_status', '!=', 'REJECTED')
                                ->where('transactions.contact_id', $contact_id)
                                ->where('transactions.business_id', $business_id)
                                ->where('transactions.location_id', $location_id);
                        });
                    }
                } else {
                    $query->where('transactions.type_for_api', $type);
                }
            } else {
                $query->where(function ($query) {
                    $query->where('transactions.type_for_api', 'Dinein')
                        ->orWhere('transactions.type_for_api', 'Takeaway')
                        ->orWhere('transactions.type_for_api', 'Retail')
                        ->orWhere('transactions.type_for_api', 'Kiosk')
                        ->orWhere('transactions.type_for_api', 'Common');
                });
            }

            if ($transaction_status == 'quotation') {
                $query->where('transactions.status', 'draft')
                    ->where('transactions.sub_status', 'quotation');
            } elseif ($transaction_status == 'draft') {
                $query->where('transactions.status', 'draft')
                    ->whereNull('transactions.sub_status');
            } else {
                $query->where('transactions.status', $transaction_status);
            }

            // $transaction_sub_type = $request->get('transaction_sub_type');
            // if (!empty($transaction_sub_type)) {
            //$query->where('transactions.sub_type', $transaction_sub_type);
            // } else {
            //     $query->where('transactions.sub_type', null);
            // }

            $query->orderBy('transactions.created_at', 'desc')
                ->groupBy('transactions.id');

            //For web pickup and delivery
            if ($type == 'PickupOrDelivery' || $type == 'Pickup' || $type == 'TrackOrder' || $type == 'Delivery') {
                $transactions = $query->select(
                    'transactions.*',
                    't.amount as received_amount',
                    't.method',
                    't.card_type',
                    't.last_4_card_digits',
                    'w.profit_percent',
                    'z.amount as tax_rate_amount',
                    DB::raw('COUNT(SR.id) as return_exists'),
                    'SR.refund_all',
                    'DD.d_date',
                    'DD.d_time',
                    'DD.d_address',
                    'BL.name as business_location_name_for_pickup',
                    'BL.mobile as business_location_mobile_for_pickup',
                    'BLD.name as business_location_name_for_delivery',
                    'BLD.mobile as business_location_mobile_for_delivery'
                )
                    ->with(['contact'])
                    ->get();
            } else {
                $transactions = $query->select('transactions.*', 't.amount as received_amount', 't.method', 't.card_type', 't.last_4_card_digits', 'w.profit_percent', 'z.amount as tax_rate_amount', DB::raw('COUNT(SR.id) as return_exists'), 'SR.refund_all')
                    ->with(['contact'])
                    //->limit(5)
                    ->get();
            }

            $retail_gst = 0;
            $business_tax_rates = TaxRate::where('business_id', $business_id)
                ->get()
                ->toArray();

            for ($i = 0; $i < count($business_tax_rates); $i++) {
                if (strtolower($business_tax_rates[$i]['name']) == 'gst') {
                    $retail_gst = $business_tax_rates[$i]['amount'];
                }
            }

            $businessUtil = new BusinessUtil();
            $business = $businessUtil->getDetails($business_id);
            $pos_settings = json_decode($business->pos_settings);

            //return $transactions;
            $transaction_result = [];
            $total_dont_have_line_discount_amt = 0;
            //$final_total_for_single_item = 0;
            foreach ($transactions as $key => $value) {
                $item = [];
                $payments = [];
                $final_total_for_single_item = 0;
                $final_total_line_discount_amount = 0;
                $service_charge_amount = 0;
                $increment = 0;

                foreach ($value['sell_lines'] as $sellLinesKey => $sellLinesValue) {
                    $total_line_discount_amount = 0;
                    if ($sellLinesValue["parent_sell_line_id"] == null && $sellLinesValue["transaction_id"] == $value['id']) {
                        $adons = [];
                        $combo_adons = [];
                        $total_for_single_item = 0;
                        foreach ($value['sell_lines'] as $sellLinesKey1 => $sellLinesValue1) {
                            if ($sellLinesValue1["parent_sell_line_id"] != null && $sellLinesValue1["parent_sell_line_id"] == $sellLinesValue['id'] && $sellLinesValue1["children_type"] == "modifier") {
                                $adons[] = [
                                    'id' => $sellLinesValue1['variations']->id,
                                    'modifier_set_id' => $sellLinesValue1['variations']->product_id,
                                    'modifier_sell_line_id' => $sellLinesValue1['id'],
                                    'name' => $sellLinesValue1['variations']->name,
                                    'quantity' => $sellLinesValue1["quantity"],
                                    'amount' => $sellLinesValue1['unit_price_before_discount'], //unit_price_before_discount
                                    'not_for_receipt' => $sellLinesValue1['variations']->product->not_for_receipt,
                                    'modifier_app_id' => $sellLinesValue1['modifier_app_ids'],
                                    'kitchen_shorthand' => $sellLinesValue1['variations']->kitchen_shorthand,
                                    'name_in_second_language' => $sellLinesValue1['variations']->name_in_second_language,
                                    'short_hand_name' => $sellLinesValue1['variations']->short_hand_name
                                ];
                                if ($sellLinesValue["quantity_returned"] == "0.0000" && $sellLinesValue["change_price"] == 0) {
                                    //total modifier price
                                    $total_for_single_item = $total_for_single_item + $sellLinesValue1['unit_price_before_discount'];
                                }
                            } else if ($sellLinesValue1["parent_sell_line_id"] != null && $sellLinesValue1["parent_sell_line_id"] == $sellLinesValue['id'] && $sellLinesValue1["children_type"] == "combo") {
                                $combo_adons[] = [
                                    'transaction_sell_lines_id' => $sellLinesValue1['id'],
                                    'product_id' => $sellLinesValue1['product_id'],
                                    'variation_id' => $sellLinesValue1['variation_id'],
                                    'quantity' => $sellLinesValue1['quantity'],
                                ];
                            }
                        }

                        //main item price + modifier price
                        if ($sellLinesValue['weight'] > 0) {
                            $total_for_single_item = ($sellLinesValue['unit_price_before_discount'] + $total_for_single_item) * $sellLinesValue["quantity"];
                        } else {
                            $total_for_single_item = ($sellLinesValue['unit_price_before_discount'] + $total_for_single_item) * $sellLinesValue["quantity"];
                        }

                        if ($increment == 0) {
                            $total_dont_have_line_discount_amt = 0;
                        }

                        if ($sellLinesValue["quantity_returned"] == "0.0000") {
                            $final_total_for_single_item += $total_for_single_item;
                            //calculate if line item has line discount
                            if ($sellLinesValue['line_discount_type'] == "fixed") {
                                $total_line_discount_amount += $sellLinesValue['line_discount_amount'];
                            } else if ($sellLinesValue['line_discount_type'] == "percentage") {
                                $total_line_discount_amount = (($sellLinesValue['line_discount_amount'] / 100) * $total_for_single_item) + $total_line_discount_amount;
                            }
                            //calculate final total line discount amount
                            $final_total_line_discount_amount += $total_line_discount_amount;
                            //total if item dont have line discount amount
                            if ($total_line_discount_amount == 0) {
                                $total_dont_have_line_discount_amt += $total_for_single_item;
                            }
                        }

                        if ($sellLinesValue['added_by_qr'] == 0) {
                            $sellLinesValue['added_by_qr'] = 'false';
                        } else {
                            $sellLinesValue['added_by_qr'] = 'true';
                        }

                        $combo_products = [];
                        $variations = Product::where('business_id', $business_id)
                            ->with(['variations'])
                            ->find($sellLinesValue['product_id']);
                        if ($variations['variations'] && count($variations['variations'])) {
                            foreach ($variations['variations'] as $key => $each) {
                                $variation = json_decode($each);
                                if ($variation->combo_variations && count($variation->combo_variations)) {
                                    foreach ($variation->combo_variations as $key => $combo_variation) {
                                        $combo_product = Variation::where('variations.id', $combo_variation->variation_id)
                                            ->join('products AS p', 'variations.product_id', '=', 'p.id')
                                            ->select(['p.*', 'variations.name as variation_name'])
                                            ->first();
                                        $combo_product['quantity'] = round($combo_variation->quantity, 2);
                                        $combo_products[] = $combo_product;
                                    }
                                }
                            }
                        }

                        $item[] = [
                            'transaction_sell_line_id' => $sellLinesValue['id'],
                            'category_id' => !empty($sellLinesValue['variations']->product->category_id) ? $sellLinesValue['variations']->product->category_id : null,
                            'name' => $sellLinesValue['variations']->product->name,
                            'short_code' => $sellLinesValue['variations']->product->category->short_code,
                            'quantity' => $sellLinesValue['quantity'],
                            'quantity_returned' => $sellLinesValue["quantity_returned"],
                            'quantity_returned_note' => $sellLinesValue["quantity_returned_note"],
                            'unit_id' => $sellLinesValue['variations']->product->unit_id,
                            'amount' => $sellLinesValue['unit_price_before_discount'],
                            'total_before_tax' => $value['total_before_tax'],
                            'tax_amount' => $value['tax_amount'],
                            'line_discount_type' => $sellLinesValue['line_discount_type'],
                            'line_discount_amount' => $sellLinesValue['line_discount_amount'],
                            'product_id' => $sellLinesValue['product_id'],
                            'variation_id' => $sellLinesValue['variation_id'],
                            'weight' => $sellLinesValue["weight"],
                            'total_line_discount_amount' => $total_line_discount_amount,
                            'total_for_single_item' => $total_for_single_item,
                            'serve_later_quantity' => $sellLinesValue["serve_later_quantity"],
                            'adons' => $adons,
                            'printed' => $sellLinesValue["printed"],
                            'sell_line_note' => $sellLinesValue["sell_line_note"],
                            'change_price' => $sellLinesValue["change_price"],
                            'combo_variations' => $combo_adons,
                            'app_order_id' => $value['app_order_id'],
                            'app_item_line_id' => $sellLinesValue["app_item_line_id"],
                            'added_by_qr' => $sellLinesValue['added_by_qr'],
                            'tag' => !empty($sellLinesValue['tag']) ? $sellLinesValue['tag'] : "",
                            'kitchen_shorthand' => $sellLinesValue['variations']->product->kitchen_shorthand,
                            'name_in_second_language' => $sellLinesValue['variations']->product->name_in_second_language,
                            'show_combo_products' => $sellLinesValue['variations']->product->show_combo_products ? true : false,
                            'combo_products' => $combo_products,
                            'order_placed_by' => $sellLinesValue['order_placed_by'] ? $sellLinesValue['order_placed_by'] : null,
                        ];

                        $increment++;
                    }
                }

                if ($value['discount_type'] == "fixed") {
                    $discount_amount = $value['discount_amount'] + $final_total_line_discount_amount;
                } else if ($value['discount_type'] == "percentage") {
                    $discount_amount = ($value['discount_amount'] * $total_dont_have_line_discount_amt) + $final_total_line_discount_amount;
                }

                //calculate service charges
                $service_charge_amount = ($final_total_for_single_item - $discount_amount) * $value['service_charges'];

                if ($value['delivery_charges'] != 0) {
                    //calculate tax
                    $tax_amount = 0;
                    if ($value['tax_id'] != null) {
                        if ($value["is_inclusive_gst_applied"])
                            $tax_amount = (($final_total_for_single_item - $discount_amount) / (100 + $value['tax_rate_amount'])) * $value['tax_rate_amount'];
                        else
                            $tax_amount = ($value['tax_rate_amount'] / 100) * ($final_total_for_single_item - $discount_amount);
                    }
                    if ($value["is_inclusive_gst_applied"])
                        $final_total = $final_total_for_single_item + $value['delivery_charges'];
                    else
                        $final_total = $final_total_for_single_item + $tax_amount + $value['delivery_charges'];
                } else {
                    //calculate tax
                    $tax_amount = 0;
                    $refund_tax_amount = 0;

                    if ($value['type_for_api'] == 'Retail') {
                        $tax_amount = ($final_total_for_single_item + $service_charge_amount - $discount_amount) - (($final_total_for_single_item + $service_charge_amount - $discount_amount) / (1 + ($retail_gst / 100)));

                        $final_total = round($final_total_for_single_item, 2) + 0 + round($service_charge_amount, 2) - round($discount_amount, 2);
                    } else {
                        if ($value['tax_id'] != null) {
                            if ($value["is_inclusive_gst_applied"])
                                $tax_amount = (($final_total_for_single_item - $discount_amount) / (100 + $value['tax_rate_amount'])) * $value['tax_rate_amount'];
                            else
                                $tax_amount = ($value['tax_rate_amount'] / 100) * ($final_total_for_single_item - $discount_amount);
                        }
                        if ($value["is_inclusive_gst_applied"])
                            $final_total = round($final_total_for_single_item, 2) + round($service_charge_amount, 2) - round($discount_amount, 2);
                        else
                            $final_total = round($final_total_for_single_item, 2) + round($tax_amount, 2) + round($service_charge_amount, 2) - round($discount_amount, 2);
                    }
                }

                $amount_rounding_method = $pos_settings->amount_rounding_method;
                $payment_method = $value->method;
                $latest_round_off_amount = $this->transactionUtil->latest_round_off_amount($payment_method, $final_total, $amount_rounding_method);

                // For multiple payment
                foreach ($value['payment_lines'] as $payment_lines_key => $payment_line) {
                    if (count($value['payment_lines']) == 1) {
                        if ($final_total > 0) {
                            $cash_received_amount = $final_total + $latest_round_off_amount;
                        } else {
                            $cash_received_amount = $final_total;
                        }
                    } else {
                        if ($value['refund_all'] == 1) {
                            $cash_received_amount = 0;
                        } else {
                            $cash_received_amount = $payment_line['amount'];
                        }
                    }
                    $payments[] = [
                        'transaction_payment_id' => $payment_line['id'],
                        'method' => $payment_line['method'],
                        'card_type' => $payment_line['card_type'],
                        'last_4_card_digits' => $payment_line['last_4_card_digits'],
                        'received_amount' => $cash_received_amount
                    ];
                }

                $table_arr = [];
                $table_name = [];
                $pax = '';

                $table_query = Transaction::leftjoin('pos_res_tables as t', 't.app_order_id', '=', 'transactions.app_order_id')
                    ->leftjoin('res_tables as z', 'z.id', '=', 't.res_table_id')
                    ->where('transactions.id', $value['id'])
                    ->select('t.res_table_id', 'pax', 'z.name')
                    ->get();

                if (!empty($table_query)) {
                    foreach ($table_query as $key => $tableValue) {
                        if ($tableValue['res_table_id'] != null) {
                            array_push($table_arr, $tableValue['res_table_id']);
                            array_push($table_name, $tableValue['name']);
                            $pax = $tableValue['pax'];
                        }
                    }
                }

                //For web pickup and delivery
                if ($type == 'PickupOrDelivery' || $type == 'Pickup' || $type == 'TrackOrder' || $type == 'Delivery') {
                    $last_4_card_digits = "**** **** **** " . $value['last_4_card_digits'];
                    $d_date = $value['d_date'];
                    $d_time = $value['d_time'];
                    $d_address = $value['d_address'];
                    $business_location_name_for_pickup = $value['business_location_name_for_pickup'];
                    $business_location_mobile_for_pickup = $value['business_location_mobile_for_pickup'];
                    $business_location_name_for_delivery = $value['business_location_name_for_delivery'];
                    $business_location_mobile_for_delivery = $value['business_location_mobile_for_delivery'];
                    $order_no = $value['order_no'];
                    $pickup_completed = $value['pickup_completed'];
                    $lalamove_orderRef = $value['lalamove_orderRef'];
                    $lalamove_status = $value['lalamove_status'];
                    $lalamove_driver_info = '';
                    if ($type == 'Delivery') {
                        $order = json_decode($value['lalamove_result'], true);
                        if (!empty($order)) {
                            if (!empty($order['data']['order']['driverId'])) {
                                $lalamove_driver_id = $order['data']['order']['driverId'];
                            } else if (!empty($order['driverId'])) {
                                $lalamove_driver_id = $order['driverId'];
                            } else {
                                $lalamove_driver_id = '';
                            }

                            if ($lalamove_driver_id != '') {
                                $lalamove_driver_info = $this->check_driver_details($lalamove_orderRef, $lalamove_driver_id, $value['business_id'], $value['location_id']);
                                $lalamove_driver_info = json_decode($lalamove_driver_info, true);
                            }
                        }
                    }
                } else {
                    $last_4_card_digits = '';
                    $d_date = '';
                    $d_time = '';
                    $d_address = '';
                    $business_location_name_for_pickup = '';
                    $business_location_mobile_for_pickup = '';
                    $business_location_name_for_delivery = '';
                    $business_location_mobile_for_delivery = '';
                    $order_no = '';
                    $pickup_completed = '';
                    $lalamove_orderRef = '';
                    $lalamove_status = '';
                    $lalamove_driver_info = '';
                }

                $check_contact_access = Contact::join('user_contact_access AS uca', 'contacts.id', 'uca.contact_id')
                    ->where('uca.contact_id', $value['contact_id'])->first();

                if ($check_contact_access) {
                    $user_query = User::where('id', $check_contact_access->user_id)->first();

                    $member_mobile = $user_query->contact_no;
                    $member_dob = $user_query->dob;
                } else {
                    $member_mobile = "";
                    $member_dob = "";
                }

                $transaction_result[] = [
                    'app_order_id' => $value['app_order_id'],
                    'id' => $value['id'],
                    'business_id' => $value['business_id'],
                    'location_id' => $value['location_id'],
                    'transaction_date' => $value['transaction_date'],
                    'table_id' => $table_arr,
                    'table_name' => $table_name,
                    'pax' => $pax,
                    'invoice_no' => $value['invoice_no'],
                    'order_check_no' => $value['order_check_no'],
                    'ref_no' => $value['ref_no'],
                    'order_no' => $value['order_no'],
                    'type' => $value['type'],
                    'type_for_api' => $value['type_for_api'],
                    'total' => $final_total,
                    'round_off_amount' => round($latest_round_off_amount, 2),
                    'paymentType' => $value['method'],
                    'card_type' => $value['card_type'],
                    'tax_id' => $value['tax_id'],
                    'contact_id' => $value['contact_id'],
                    'tax_amount' => $tax_amount,
                    'addon_discount' => ($value['profit_percent'] == null ? 0 : $value['profit_percent']),
                    'discount_type' => $value['discount_type'],
                    'discount_amount' => $discount_amount,
                    'service_charge' => $value['service_charges'],
                    'delivery_charge' => $value['delivery_charges'],
                    'reward_amount' => $value['rp_redeemed'],
                    'customer_reward_amount' => $value['rp_redeemed_amount'],
                    'service_charge_amount' => $service_charge_amount,
                    'tax_rate_amount' => $value['tax_rate_amount'],
                    'profit_percent' => $value['profit_percent'],
                    'return_exists' => $value['return_exists'],
                    'refund_all' => $value['refund_all'],
                    'total_dont_have_line_discount_amt' => $total_dont_have_line_discount_amt,
                    //'total_line_discount_amount' => $total_line_discount_amount,
                    'final_total_for_single_item' => $final_total_for_single_item,
                    'received_amount' => $value['received_amount'],
                    'last_4_card_digits' => $last_4_card_digits,
                    'd_date' => $d_date,
                    'd_time' => $d_time,
                    'd_address' => $d_address,
                    'business_location_name_for_pickup' => $business_location_name_for_pickup,
                    'business_location_mobile_for_pickup' => $business_location_mobile_for_pickup,
                    'business_location_name_for_delivery' => $business_location_name_for_delivery,
                    'business_location_mobile_for_delivery' => $business_location_mobile_for_delivery,
                    'order_no' => $order_no,
                    'pickup_completed' => $pickup_completed,
                    'lalamove_orderRef' => $lalamove_orderRef,
                    'lalamove_status' => $lalamove_status,
                    'lalamove_driver_info' => $lalamove_driver_info,
                    'shipping_charges' => $value['shipping_charges'],
                    'first_name' => $value['contact']->first_name,
                    'last_name' => $value['contact']->last_name,
                    'estimated_arrival_time' => Carbon::parse(Carbon::parse($value['transaction_date'])->addHour())->format('d/m/Y h:ia'),
                    'updated_at' => Carbon::parse($value['updated_at'])->format('d/m/Y h:ia'),
                    'deposit' => $value['deposit'],
                    'member_mobile' => $member_mobile,
                    'member_dob' => $member_dob,
                    'item' => $item,
                    'payments' => $payments,
                    'is_inclusive_gst_applied' => $value['is_inclusive_gst_applied'] ? true : false,
                    'tag_number' => $value['tag_number'],
                    'discount_type_id' => $value['discount_type_id'],
                    'open_discount_value' => $value['open_discount_value'],
                    'commission_type' => $value['commission_type'],
                    'cash_change_amount' => $value['cash_change_amount'],
                    'cash_received_amount' => $value['cash_received_amount'],
                    'is_coupon_applied' => $value['is_coupon_applied'],
                    'coupon_details' => !empty($value['coupon_details']) ? json_decode($value['coupon_details'], true) : null,
                    'coupon_amount_used' => $value['coupon_amount_used'],
                    'void_items' => !empty($value['void_items']) ? $value['void_items'] : null,
                ];

            }

            if ($app_order_id == null && $type != 'PickupOrDelivery') {
                $query = CashRegister::where('business_id', $business_id)
                    ->where('location_id', $location_id)
                    ->with(['cash_register_transactions'])
                    ->where('user_id', $user_id);

                if (!empty($created_at)) {
                    $query->whereDate('cash_registers.created_at', $created_at);
                } else {
                    $query->whereDate('cash_registers.created_at', \Carbon::now()->format('Y-m-d 00:00:00'));
                }

                $cash_registers = $query->get();

                return ["sells" => $transaction_result, "cash_registers" => $cash_registers];
            } else {
                return ["sells" => $transaction_result];
            }
        } catch (\Exception $e) {
            DB::rollBack();

            \Log::emergency("File:" . $e->getFile() . "Line:" . $e->getLine() . "Message:" . $e->getMessage());
            $msg = __('messages.something_went_wrong');

            $output = [
                'errorMessage' => $msg
            ];

            return $output;
        }
    }

    //  public function get_sale_history2($user_id, $business_id, $location_id, $transaction_status, $created_at, $type, $transaction_id = null, $app_order_id ,$contact_id = null, $txt = null)
    // {

    //     try {

    //         //$transaction_id = !empty($transaction_id) ? $transaction_id : "";
    //         $query = Transaction::leftjoin('transaction_payments as t', function($join) {
    //                       $join->on('t.app_order_id', '=', 'transactions.app_order_id')
    //                           ->orOn('t.transaction_id', '=', 'transactions.id');
    //                     })
    //                 ->leftjoin('variations as w', 'w.product_id', '=', 'transactions.additional_discount_method')
    //                 ->leftjoin('tax_rates as z', 'z.id', '=', 'transactions.tax_id')
    //                 ->leftJoin('transactions AS SR', 'transactions.id', '=', 'SR.return_parent_id')
    //                 ->with('sell_lines.variations.product.category')
    //                 ->with('payment_lines')
    //                 ->with(['return_parent', 'return_parent.tax'])
    //                 ->where('transactions.business_id', $business_id)
    //                 ->where('transactions.location_id', $location_id)
    //                 //->where('transactions.created_by', $user_id)
    //                 ->where('transactions.type', 'sell');
    //                 //->where('transactions.type_for_api', 'Takeaway')
    //                 // ->where('transactions.is_direct_sale', 0);


    //         //For web pickup and delivery
    //         if($contact_id != null) {
    //             $query->where('transactions.contact_id', $contact_id);

    //             if (!empty($created_at)) {
    //                 $query->whereDate('transactions.created_at', $created_at); //2021-08-15 00:00:00
    //             }
    //         }

    //         if ($app_order_id != null || $transaction_id != null) {
    //             $query->where(function ($q) use ($app_order_id, $transaction_id) {
    //                 $q->where(function ($q1) use ($app_order_id) {
    //                     $q1->where('transactions.app_order_id', $app_order_id);
    //                     if (empty($app_order_id)) {
    //                         $q1->orWhereNull('transactions.app_order_id');
    //                     }
    //                 })->orWhere('transactions.id', $transaction_id);
    //             });
    //         }

    //         // else if($type == 'TrackOrder')
    //         // {
    //         //     $query->whereDate('transactions.created_at','=', Carbon::today());
    //         // }
    //         else if($type != 'PickupOrDelivery' && $type != 'TrackOrder' && $contact_id == null)
    //         {
    //             if (!empty($created_at)) {
    //                 $query->whereDate('transactions.created_at', $created_at); //2021-08-15 00:00:00
    //             } else {
    //                 $query->whereDate('transactions.created_at', \Carbon::now()->format('Y-m-d 00:00:00'));
    //             }
    //         }

    //         if (!empty($type)) {
    //             //For web pickup and delivery
    //             if($type == 'PickupOrDelivery' || $type == 'Pickup' || $type == 'TrackOrder' || $type == 'Delivery' || $type == 'Handheld_Delivery') {
    //                 $query->leftJoin(
    //                     'delivery_details AS DD',
    //                     'transactions.app_order_id',
    //                     '=',
    //                     'DD.app_order_id'
    //                 )
    //                 ->leftJoin(
    //                     'business_locations AS BL',
    //                     'DD.outlet',
    //                     '=',    
    //                     'BL.id'
    //                 )
    //                 ->leftJoin(
    //                     'business_locations AS BLD',
    //                     'transactions.location_id',
    //                     '=',
    //                     'BLD.id'
    //                 )
    //                 ->when(empty($app_order_id), function ($query) {
    //                     $query->leftJoin(
    //                         'delivery_details AS DD2',
    //                         'transactions.id',
    //                         '=',
    //                         'DD2.transaction_id'
    //                     );
    //                 });
    //                 if($type == 'PickupOrDelivery')
    //                 {
    //                     $query->where(function ($query) use ($contact_id, $business_id, $location_id) {
    //                         $query->where('transactions.type_for_api', '=', 'Pickup')
    //                             ->where(function ($query) { 
    //                                 $query->where('transactions.pickup_completed', '=', 1)
    //                                         ->orWhere('SR.refund_all', 1);
    //                             })
    //                             ->where('transactions.contact_id', $contact_id)
    //                             ->where('transactions.business_id', $business_id)
    //                             ->where('transactions.location_id', $location_id);
    //                     })->orWhere(function ($query) use ($contact_id, $business_id, $location_id) {
    //                         $query->where('transactions.type_for_api', '=', 'Delivery')
    //                             ->where(function ($query) { 
    //                                 $query->where('transactions.lalamove_status', '!=', 'ASSIGNING_DRIVER')
    //                                         ->where('transactions.lalamove_status', '!=', 'ON_GOING')
    //                                         ->where('transactions.lalamove_status', '!=', 'PICKED_UP')
    //                                         ->orWhere('SR.refund_all', 1);
    //                             })
    //                             ->where('transactions.contact_id', $contact_id)
    //                             ->where('transactions.business_id', $business_id)
    //                             ->where('transactions.location_id', $location_id);
    //                     });
    //                 }
    //                 else if($type == 'TrackOrder')
    //                 {
    //                     $query->where(function ($query) use ($contact_id, $business_id, $location_id) {
    //                         $query->where('transactions.type_for_api', '=', 'Pickup')
    //                             ->where('transactions.pickup_completed', '=', 0)
    //                             ->where('SR.refund_all', null)
    //                             ->where('transactions.contact_id', $contact_id)
    //                             ->where('transactions.business_id', $business_id)
    //                             ->where('transactions.location_id', $location_id);
    //                     })->orWhere(function ($query) use ($contact_id, $business_id, $location_id) {
    //                         $query->where('transactions.type_for_api', '=', 'Delivery')
    //                             ->where('transactions.lalamove_status', '!=', 'COMPLETED')
    //                             ->where('transactions.lalamove_status', '!=', 'EXPIRED')
    //                             ->where('transactions.lalamove_status', '!=', 'CANCELED')
    //                             ->where('transactions.lalamove_status', '!=', 'REJECTED')
    //                             ->where('SR.refund_all', null)
    //                             ->where('transactions.contact_id', $contact_id)
    //                             ->where('transactions.business_id', $business_id)
    //                             ->where('transactions.location_id', $location_id);
    //                     });
    //                 }
    //                 else if($type == 'Handheld_Delivery')
    //                 {
    //                     $query->where(function ($query){$query->where('transactions.type_for_api', '=', 'Delivery')
    //                         ->where('transactions.lalamove_status', '!=', 'ASSIGNING_DRIVER')
    //                         ->where('transactions.lalamove_status', '!=', 'ON_GOING')
    //                         ->where('transactions.lalamove_status', '!=', 'PICKED_UP')
    //                         ->where('transactions.lalamove_status', '!=', 'EXPIRED')
    //                         ->where('transactions.lalamove_status', '!=', 'CANCELED');
    //                     })->orWhere(function ($query) use ($created_at){
    //                         $query->where('transactions.type_for_api', '=', 'Pickup')
    //                         ->where('transactions.pickup_completed', '=', 1)
    //                         ->whereDate('transactions.created_at', $created_at);
    //                     });

    //                     //Only need COMPLETED and REJECTED
    //                     /*$query->where('transactions.type_for_api', '=', 'Delivery')
    //                             ->where('transactions.lalamove_status', '!=', 'ASSIGNING_DRIVER')
    //                             ->where('transactions.lalamove_status', '!=', 'ON_GOING')
    //                             ->where('transactions.lalamove_status', '!=', 'PICKED_UP')
    //                             ->where('transactions.lalamove_status', '!=', 'EXPIRED')
    //                             ->where('transactions.lalamove_status', '!=', 'CANCELED');*/
    //                 }
    //             } else {
    //                 $query->where('transactions.type_for_api', $type);
    //             }
    //         } else {
    //             $query->where(function($query) {
    //                 $query->where('transactions.type_for_api', 'Dinein')
    //                       ->orWhere('transactions.type_for_api', 'Takeaway')
    //                       ->orWhere('transactions.type_for_api', 'Retail')
    //                       ->orWhere('transactions.type_for_api', 'Kiosk')
    //                       ->orWhere('transactions.type_for_api', 'Common');
    //             });
    //         }

    //         if ($transaction_status == 'quotation') {
    //             $query->where('transactions.status', 'draft')
    //                 ->where('transactions.sub_status', 'quotation');
    //         } elseif ($transaction_status == 'draft') {
    //             $query->where('transactions.status', 'draft')
    //                 ->whereNull('transactions.sub_status');
    //         } else {
    //             $query->where('transactions.status', $transaction_status);
    //         }

    //         // $transaction_sub_type = $request->get('transaction_sub_type');
    //         // if (!empty($transaction_sub_type)) {
    //             //$query->where('transactions.sub_type', $transaction_sub_type);
    //         // } else {
    //         //     $query->where('transactions.sub_type', null);
    //         // }
    //         if ($txt == null || $txt == false) {
    //             $query->orderBy('transactions.created_at', 'desc')
    //                 ->when(empty($app_order_id), function ($query) {
    //                     $query->groupBy('transactions.id');
    //                 })
    //                 ->groupBy('transactions.app_order_id');
    //         } else if ($txt == true) {
    //             $query->orderBy('transactions.created_at', 'asc')
    //                 ->when(empty($app_order_id), function ($query) {
    //                     $query->groupBy('transactions.id');
    //                 })
    //                 ->groupBy('transactions.app_order_id');
    //         }

    //         //For web pickup and delivery
    //         if($type == 'PickupOrDelivery' || $type == 'Pickup' || $type == 'TrackOrder' || $type == 'Delivery' || $type == 'Handheld_Delivery') {
    //             $transactions = $query->select('transactions.*', 't.amount as received_amount', 't.method', 't.card_type', 't.last_4_card_digits', 'w.profit_percent', 
    //             'z.amount as tax_rate_amount', DB::raw('COUNT(SR.id) as return_exists'), 'SR.refund_all', 
    //             'DD.d_date', 'DD.d_time', 'DD.d_address', 'BL.name as business_location_name_for_pickup', 'BL.mobile as business_location_mobile_for_pickup', 
    //             'BLD.name as business_location_name_for_delivery', 'BLD.mobile as business_location_mobile_for_delivery', 'w.combo_variations')
    //                             ->with(['contact'])
    //                             ->get();
    //         } else {
    //             $transactions = $query->select('transactions.*', 't.amount as received_amount', 't.method', 't.card_type', 't.last_4_card_digits', 'w.profit_percent', 'z.amount as tax_rate_amount', DB::raw('COUNT(SR.id) as return_exists'), 'SR.refund_all', 'w.combo_variations')
    //                             ->with(['contact'])
    //                             //->limit(5)
    //                             ->get();
    //         }

    //         $retail_gst = 0;
    //         $business_tax_rates = TaxRate::where('business_id', $business_id)
    //                         ->get()
    //                         ->toArray();

    //         for($i = 0; $i < count($business_tax_rates); $i++)
    //         {
    //             if(strtolower($business_tax_rates[$i]['name']) == 'gst')
    //             {
    //                 $retail_gst = $business_tax_rates[$i]['amount'];
    //             }
    //         }

    //         // $businessUtil = new BusinessUtil();
    //         // $business = $businessUtil-> ($business_id);
    //         // $pos_settings = json_decode($business->pos_settings);

    //         // return $transactions;
    //         $transaction_result = [];
    //         $total_dont_have_line_discount_amt = 0;
    //         $total_sale_for_handheld = 0;
    //         $total_handheld_completed = 0;
    //         $total_handheld_rejected = 0;
    //         $refund_total_dont_have_line_discount_amt = 0;
    //         //$final_total_for_single_item = 0;
    //         foreach ($transactions as $key => $value) {

    //             $item = [];
    //             $payments = [];
    //             $final_total_for_single_item = 0;
    //             $final_total_line_discount_amount = 0;
    //             $service_charge_amount = 0;
    //             $single_total_quantity_returned = 0;
    //             $refund_final_total_for_single_item = 0;
    //             $refund_final_total_line_discount_amount = 0;
    //             $refund_service_charge_amount = 0;
    //             $increment = 0;

    //             foreach ($value['sell_lines'] as $sellLinesKey => $sellLinesValue)
    //             {
    //                 // echo "<pre>";
    //                 // print_r($sellLinesValue); die;
    //                 $total_line_discount_amount = 0;
    //                 $refund_total_line_discount_amount = 0;

    //                 if($sellLinesValue["parent_sell_line_id"] == null && $sellLinesValue["app_order_id"] == $value['app_order_id'])
    //                 {
    //                     $adons = [];
    //                     $combo_adons = [];
    //                     $total_for_single_item = 0;
    //                     foreach ($value['sell_lines'] as $sellLinesKey1 => $sellLinesValue1)
    //                     {

    //                         if($sellLinesValue1["parent_sell_line_id"] != null && $sellLinesValue1["parent_sell_line_id"] == $sellLinesValue['id'] && $sellLinesValue1["children_type"] == "modifier")
    //                         {

    //                             $adons[] = [
    //                                 'id' => $sellLinesValue1['variations']->id,
    //                                 'modifier_set_id' => $sellLinesValue1['variations']->product_id,
    //                                 'modifier_sell_line_id' => $sellLinesValue1['id'],
    //                                 'name' => $sellLinesValue1['variations']->name,
    //                                 'quantity' => $sellLinesValue1["quantity"],
    //                                 'amount' => $sellLinesValue1['unit_price_before_discount'], //unit_price_before_discount
    //                                 'not_for_receipt' => $sellLinesValue1['variations']->product->not_for_receipt,
    //                             ];
    //                             if($sellLinesValue["quantity_returned"] == "0.0000" && $sellLinesValue["change_price"] == 0)
    //                             {
    //                                 //total modifier price
    //                                 $total_for_single_item = $total_for_single_item + $sellLinesValue1['unit_price_before_discount'];
    //                             }
    //                         }
    //                         else if($sellLinesValue1["parent_sell_line_id"] != null && $sellLinesValue1["parent_sell_line_id"] == $sellLinesValue['id'] && $sellLinesValue1["children_type"] == "combo")
    //                         {

    //                             $combo_adons[] = [
    //                                 'transaction_sell_lines_id' => $sellLinesValue1['id'],
    //                                 'product_id' => $sellLinesValue1['product_id'],
    //                                 'variation_id' => $sellLinesValue1['variation_id'],
    //                                 'quantity' => $sellLinesValue1['quantity'],
    //                             ];
    //                         }


    //                     }

    //                     //main item price + modifier price
    //                     if($sellLinesValue['weight'] > 0) {
    //                         //$total_for_single_item = ($sellLinesValue['unit_price_before_discount'] / $sellLinesValue['weight'] + $total_for_single_item) * $sellLinesValue["quantity"];
    //                         $total_for_single_item = ($sellLinesValue['unit_price_before_discount'] + $total_for_single_item) * $sellLinesValue["quantity"];
    //                     } else {
    //                         $total_for_single_item = ($sellLinesValue['unit_price_before_discount'] + $total_for_single_item)* $sellLinesValue["quantity"];
    //                     }

    //                     if($increment == 0)
    //                     {
    //                         $total_dont_have_line_discount_amt = 0;
    //                         $refund_total_dont_have_line_discount_amt = 0;
    //                     }

    //                     if($sellLinesValue["quantity_returned"] == "0.0000")
    //                     {
    //                         $final_total_for_single_item += $total_for_single_item;
    //                         //calculate if line item has line discount
    //                         if($sellLinesValue['line_discount_type'] == "fixed")
    //                         {
    //                             $total_line_discount_amount += $sellLinesValue['line_discount_amount'];
    //                         }
    //                         else if($sellLinesValue['line_discount_type'] == "percentage")
    //                         {
    //                             $total_line_discount_amount = (($sellLinesValue['line_discount_amount']/100) * $total_for_single_item) + $total_line_discount_amount;
    //                         }
    //                         //calculate final total line discount amount
    //                         $final_total_line_discount_amount += $total_line_discount_amount;
    //                         //total if item dont have line discount amount
    //                         if($total_line_discount_amount == 0)
    //                         {
    //                             $total_dont_have_line_discount_amt += $total_for_single_item;
    //                         }
    //                     }
    //                     else
    //                     {
    //                         $refund_final_total_for_single_item += $total_for_single_item;
    //                         //calculate if refund line item has line discount
    //                         if($sellLinesValue['line_discount_type'] == "fixed")
    //                         {
    //                             $refund_total_line_discount_amount += $sellLinesValue['line_discount_amount'];
    //                         }
    //                         else if($sellLinesValue['line_discount_type'] == "percentage")
    //                         {
    //                             $refund_total_line_discount_amount = (($sellLinesValue['line_discount_amount']/100) * $total_for_single_item) + $total_line_discount_amount;
    //                         }
    //                         //calculate refund final total line discount amount
    //                         $refund_final_total_line_discount_amount += $refund_total_line_discount_amount;
    //                         //refund total if item dont have line discount amount
    //                         if($refund_total_line_discount_amount == 0)
    //                         {
    //                             $refund_total_dont_have_line_discount_amt += $total_for_single_item;
    //                         }

    //                         $single_total_quantity_returned += $sellLinesValue["quantity_returned"]; 
    //                     }

    //                     //if($sellLinesValue['variations']->product == null){
    //                         if($sellLinesValue['variations']->product->category == null) {
    //                             $p_short_code = null;
    //                             $p_category = null;
    //                         } else {
    //                             $p_short_code = $sellLinesValue['variations']->product->category->short_code;
    //                             $p_category = $sellLinesValue['variations']->product->category->name;
    //                         }
    //                     // } else {

    //                     // }

    //                     // if($sellLinesValue['variations']->product == null) {
    //                     //     $p_short_code = null;
    //                     //     $p_category = null;
    //                     //     $sellLinesValue['variations']->product->category_id = '';
    //                     //     $sellLinesValue['variations']->product->type = '';
    //                     //     $sellLinesValue['variations']->product->unit_id = '';
    //                     // } else {
    //                     //     $p_short_code = $sellLinesValue['variations']->product->category->short_code;
    //                     //     $p_category = $sellLinesValue['variations']->product->category->name;
    //                     // }


    //                     $item[] = [
    //                         'transaction_sell_line_id' => $sellLinesValue['id'],
    //                         'category_id' => $sellLinesValue['variations']->product->category_id,
    //                         'product_type' => $sellLinesValue['variations']->product->type,
    //                         'name' => $sellLinesValue['variations']->product->name,
    //                         'short_code' => $p_short_code,
    //                         'category' => $p_category,
    //                         'quantity' => $sellLinesValue['quantity'],
    //                         'quantity_returned' => $sellLinesValue["quantity_returned"],
    //                         'quantity_returned_note' => $sellLinesValue["quantity_returned_note"],
    //                         'unit_id' => $sellLinesValue['variations']->product->unit_id,
    //                         'amount' => $sellLinesValue['unit_price_before_discount'],
    //                         'total_before_tax' => $value['total_before_tax'],
    //                         'tax_amount' => $value['tax_amount'],
    //                         'line_discount_type' => $sellLinesValue['line_discount_type'],
    //                         'line_discount_amount' => $sellLinesValue['line_discount_amount'],
    //                         'product_id' => $sellLinesValue['product_id'],
    //                         'variation_id' => $sellLinesValue['variation_id'],
    //                         'weight' => $sellLinesValue["weight"],
    //                         'total_line_discount_amount' => $total_line_discount_amount,
    //                         'total_for_single_item' => $total_for_single_item,
    //                         'serve_later_quantity' => $sellLinesValue["serve_later_quantity"],
    //                         'adons' => $adons,
    //                         'printed' => $sellLinesValue["printed"],
    //                         'sell_line_note' => $sellLinesValue["sell_line_note"],
    //                         'change_price' => $sellLinesValue["change_price"],
    //                         'refund_total_line_discount_amount' => $refund_total_line_discount_amount,
    //                         'combo_variations' => $combo_adons,
    //                         'app_order_id' => $value['app_order_id']
    //                     ];

    //                     $increment++;
    //                 }
    //             }

    //             if($value['discount_type'] == "fixed")
    //             {
    //                 $discount_amount = $value['discount_amount'] + $final_total_line_discount_amount;
    //             }
    //             else if($value['discount_type'] == "percentage")
    //             {
    //                 $discount_amount = ($value['discount_amount'] * $total_dont_have_line_discount_amt) + $final_total_line_discount_amount;
    //             }

    //             //calculate service charges
    //             $service_charge_amount = ($final_total_for_single_item - $discount_amount) * $value['service_charges'];

    //             //calculate total discount amount and addon discount amount (e.g. Student discount)
    //             if($value['discount_type'] == "fixed")
    //             {
    //                 $refund_discount_amount = $value['discount_amount'] + $refund_final_total_line_discount_amount;
    //             }
    //             else if($value['discount_type'] == "percentage")
    //             {
    //                 $refund_discount_amount = ($value['discount_amount'] * $refund_total_dont_have_line_discount_amt) + $refund_final_total_line_discount_amount;
    //             }

    //             $refund_service_charge_amount = ($refund_final_total_for_single_item - $refund_discount_amount) * $value['service_charges'];

    //             if($value['delivery_charges'] != 0)
    //             {
    //                 //calculate tax
    //                 $tax_amount = 0;
    //                 $refund_tax_amount = 0;
    //                 if($value['tax_id'] != null)
    //                 {
    //                     $tax_amount = ($value['tax_rate_amount']/100) * ($final_total_for_single_item - $discount_amount);
    //                 }
    //                 $final_total = $final_total_for_single_item + $tax_amount + $value['delivery_charges'];
    //                 $refund_final_total = 0;
    //             }
    //             else
    //             {
    //                 //calculate tax
    //                 $tax_amount = 0;
    //                 $refund_tax_amount = 0;

    //                 if($value['type_for_api'] == 'Retail') {
    //                     $tax_amount = ($final_total_for_single_item + $service_charge_amount - $discount_amount) - (($final_total_for_single_item + $service_charge_amount - $discount_amount)/(1 + ($retail_gst/100)));

    //                     $refund_tax_amount = ($retail_gst/100) * ($refund_final_total_for_single_item - $refund_discount_amount + $refund_service_charge_amount);

    //                     $final_total = round($final_total_for_single_item, 2) + 0 + round($service_charge_amount, 2) - round($discount_amount, 2);
    //                 } else {
    //                     if($value['tax_id'] != null)
    //                     {
    //                         $tax_amount = ($value['tax_rate_amount']/100) * ($final_total_for_single_item + $service_charge_amount - $discount_amount);

    //                         $refund_tax_amount = ($value['tax_rate_amount']/100) * ($refund_final_total_for_single_item - $refund_discount_amount + $refund_service_charge_amount);
    //                     }
    //                     $final_total = round($final_total_for_single_item, 2) + round($tax_amount, 2) + round($service_charge_amount, 2) - round($discount_amount, 2);
    //                 }
    //                 $refund_final_total = round($refund_final_total_for_single_item, 2) + round($refund_service_charge_amount, 2) - round($refund_discount_amount, 2);
    //             }

    //             //$amount_rounding_method = $pos_settings->amount_rounding_method;
    //             $amount_rounding_method = $value['amount_rounding_method'];
    //             $payment_method = $value->method;
    //             $latest_round_off_amount = $this->transactionUtil->latest_round_off_amount($payment_method, $final_total, $amount_rounding_method);

    //             // For multiple payment
    //             foreach($value['payment_lines'] as $payment_lines_key => $payment_line){
    //                 if(count($value['payment_lines']) == 1) {
    //                     if($final_total > 0) {
    //                         $cash_received_amount = $final_total + $latest_round_off_amount;
    //                     } else {
    //                         $cash_received_amount = $final_total;
    //                     }
    //                     $original_received_amount = $value['final_total'];
    //                     // $total_before_gst = ($cash_received_amount - $latest_round_off_amount) / (1 + ($value['tax_rate_amount']/100));
    //                     $total_before_gst = ($cash_received_amount) / (1 + ($value['tax_rate_amount']/100)) + $refund_final_total;
    //                     $refund_final_total = $refund_final_total;
    //                 } else {
    //                     if($value['refund_all'] == 1) {
    //                         $cash_received_amount = 0;
    //                     } else {
    //                         $cash_received_amount = $payment_line['amount'];
    //                     }
    //                     $original_received_amount = $payment_line['amount'];
    //                     $total_before_gst = $payment_line['amount'] / (1 + ($value['tax_rate_amount']/100));
    //                 }

    //                 $payments[] = [
    //                     'transaction_payment_id' => $payment_line['id'],
    //                     'method' => $payment_line['method'],
    //                     'card_type' => $payment_line['card_type'],
    //                     'last_4_card_digits' => $payment_line['last_4_card_digits'],
    //                     'received_amount' => $cash_received_amount,
    //                     'original_received_amount' => $original_received_amount,
    //                     'total_before_gst' => $total_before_gst,
    //                     'refund_final_total' => $refund_final_total,
    //                     'payment_gateway_response' => $value['payment_gateway_response']
    //                 ];
    //                 if($type == 'Handheld_Delivery' && $value['lalamove_status'] == 'COMPLETED' || $value['pickup_completed'] == 1) {
    //                     $total_sale_for_handheld += $cash_received_amount;
    //                 }
    //             }

    //             $table_arr = [];
    //             $table_name = [];
    //             $pax = '';

    //             $table_query = Transaction::leftJoin('pos_res_tables as t', function($join) use ($app_order_id) {
    //                                         $join->on('t.app_order_id', '=', 'transactions.app_order_id');
    //                                             if (empty($app_order_id)) {
    //                                                 $join->orOn('t.transaction_id', '=', 'transactions.id');
    //                                             }
    //                                         })
    //                                     ->leftJoin('res_tables as z', 'z.id', '=', 't.res_table_id')
    //                                     ->when(!empty($app_order_id), function ($query) use ($app_order_id) {
    //                                         $query->where('transactions.app_order_id', $app_order_id);
    //                                     }, function ($query) use ($value) {
    //                                         $query->where('transactions.id', $value['id']);
    //                                     })
    //                                     ->select('t.res_table_id', 'pax', 'z.name')
    //                                     ->get();

    //             if (!empty($table_query)){
    //                 foreach ($table_query as $key => $tableValue) {
    //                     if($tableValue['res_table_id'] != null)
    //                     {
    //                         array_push($table_arr, $tableValue['res_table_id']);
    //                         array_push($table_name, $tableValue['name']);
    //                         $pax = $tableValue['pax'];
    //                     }
    //                 }
    //             }

    //             //For web pickup and delivery
    //             if($type == 'PickupOrDelivery' || $type == 'Pickup' || $type == 'TrackOrder' || $type == 'Delivery' || $type == 'Handheld_Delivery') {
    //                 $last_4_card_digits = "**** **** **** ".$value['last_4_card_digits'];
    //                 $d_date = $value['d_date'];
    //                 $d_time = $value['d_time'];
    //                 $d_address = $value['d_address'];
    //                 $business_location_name_for_pickup = $value['business_location_name_for_pickup'];
    //                 $business_location_mobile_for_pickup = $value['business_location_mobile_for_pickup'];
    //                 $business_location_name_for_delivery = $value['business_location_name_for_delivery'];
    //                 $business_location_mobile_for_delivery = $value['business_location_mobile_for_delivery'];
    //                 $order_no = $value['order_no'];
    //                 $pickup_completed = $value['pickup_completed'];
    //                 $lalamove_orderRef = $value['lalamove_orderRef'];
    //                 $lalamove_status = $value['lalamove_status'];
    //                 $lalamove_driver_info = '';
    //                 if($type == 'Delivery' || $type == 'Handheld_Delivery') {
    //                     $order = json_decode($value['lalamove_result'], true);
    //                     if(!empty($order)) {
    //                         if(!empty($order['data']['order']['driverId']))
    //                         {
    //                             $lalamove_driver_id = $order['data']['order']['driverId'];
    //                         }
    //                         else if(!empty($order['driverId']))
    //                         {
    //                             $lalamove_driver_id = $order['driverId'];
    //                         }
    //                         else
    //                         {
    //                             $lalamove_driver_id = '';
    //                         }

    //                         if($lalamove_driver_id != '')
    //                         {
    //                             $lalamove_driver_info = $this->check_driver_details($lalamove_orderRef, $lalamove_driver_id, $value['business_id'], $value['location_id']);
    //                             $lalamove_driver_info = json_decode($lalamove_driver_info, true);
    //                         }
    //                     }
    //                 }
    //             } else {
    //                 $last_4_card_digits = '';
    //                 $d_date = '';
    //                 $d_time = '';
    //                 $d_address = '';
    //                 $business_location_name_for_pickup = '';
    //                 $business_location_mobile_for_pickup = '';
    //                 $business_location_name_for_delivery = '';
    //                 $business_location_mobile_for_delivery = '';
    //                 $order_no = '';
    //                 $pickup_completed = '';
    //                 $lalamove_orderRef = '';
    //                 $lalamove_status = '';
    //                 $lalamove_driver_info = '';
    //             }

    //             $check_contact_access = Contact::join('user_contact_access AS uca', 'contacts.id', 'uca.contact_id')
    //             ->where('uca.contact_id', $value['contact_id'])->first();

    //             if ($check_contact_access) {
    //                 $user_query = User::where('id', $check_contact_access->user_id)->first();

    //                 $member_mobile = $user_query->contact_number;
    //                 $member_dob = $user_query->dob;
    //             } else {
    //                 $member_mobile = "";
    //                 $member_dob = "";
    //             }

    //             $refund_final_total_without_discount = $refund_final_total_for_single_item + $refund_tax_amount + $refund_service_charge_amount - $refund_discount_amount;
    //             $refund_final_total_without_discount_and_gst = $refund_final_total_for_single_item + $refund_service_charge_amount - $refund_discount_amount;

    //             $transaction_result[] = [
    //                 'app_order_id' => $value['app_order_id'],
    //                 'id' => $value['id'],
    //                 'business_id' => $value['business_id'],
    //                 'location_id' => $value['location_id'],
    //                 'transaction_date' => $value['transaction_date'],
    //                 'table_id' => $table_arr,
    //                 'table_name' => $table_name,
    //                 'pax' => $pax,
    //                 'invoice_no' => $value['invoice_no'],
    //                  'order_check_no' => $value['order_check_no'],
    //                 'ref_no' => $value['ref_no'],
    //                 'order_no' => $value['order_no'],
    //                 'type' => $value['type'],
    //                 'type_for_api' => $value['type_for_api'],
    //                 'total' => $final_total ,
    //                 'round_off_amount' => round($latest_round_off_amount, 2),
    //                 'paymentType' => $value['method'],
    //                 'card_type' => $value['card_type'],
    //                 'tax_id' => $value['tax_id'],
    //                 'contact_id' => $value['contact_id'],
    //                 'tax_amount' => $tax_amount,
    //                 'addon_discount' => ($value['profit_percent'] == null ? 0 : $value['profit_percent']),
    //                 'discount_type' => $value['discount_type'],
    //                 'discount_amount' => $discount_amount,
    //                 'service_charge' => $value['service_charges'],
    //                 'delivery_charge' => $value['delivery_charges'],
    //                 'reward_amount' => $value['rp_redeemed'],
    //                 'customer_reward_amount' => $value['rp_redeemed_amount'],
    //                 'service_charge_amount' => $service_charge_amount,
    //                 'tax_rate_amount' => $value['tax_rate_amount'],
    //                 'profit_percent' => $value['profit_percent'],
    //                 'return_exists' => $value['return_exists'],
    //                 'refund_all' => $value['refund_all'],
    //                 'total_dont_have_line_discount_amt' => $total_dont_have_line_discount_amt,
    //                 //'total_line_discount_amount' => $total_line_discount_amount,
    //                 'final_total_for_single_item' => $final_total_for_single_item,
    //                 'received_amount' => $value['received_amount'],
    //                 'last_4_card_digits' => $last_4_card_digits,
    //                 'd_date' => $d_date,
    //                 'd_time' => $d_time,
    //                 'd_address' => $d_address,
    //                 'business_location_name_for_pickup' => $business_location_name_for_pickup,
    //                 'business_location_mobile_for_pickup' => $business_location_mobile_for_pickup,
    //                 'business_location_name_for_delivery' => $business_location_name_for_delivery,
    //                 'business_location_mobile_for_delivery' => $business_location_mobile_for_delivery,
    //                 'order_no' => $order_no,
    //                 'pickup_completed' => $pickup_completed,
    //                 'lalamove_orderRef' => $lalamove_orderRef,
    //                 'lalamove_status' => $lalamove_status,
    //                 'lalamove_driver_info' => $lalamove_driver_info,
    //                 'shipping_charges' => $value['shipping_charges'],
    //                 'first_name' => $value['contact']->first_name,
    //                 'last_name' => $value['contact']->last_name,
    //                 'estimated_arrival_time' => Carbon::parse(Carbon::parse($value['transaction_date'])->addHour())->format('d/m/Y h:ia'),
    //                 'updated_at' => Carbon::parse($value['updated_at'])->format('d/m/Y h:ia'),
    //                 'deposit' => $value['deposit'],
    //                 'member_mobile' => $member_mobile,
    //                 'member_dob' => $member_dob,
    //                 'item' => $item,
    //                 'payments' => $payments,
    //                 'return_parent' => $value['return_parent'],
    //                 'original_tax_amount' => $value['tax_amount'],
    //                 'original_discount_amount' => $value['total_discount_amount'],
    //                 'refund_discount_amount' => $refund_discount_amount,
    //                 'refund_service_charge_amount' => $refund_service_charge_amount,
    //                 'refund_tax_amount' => $refund_tax_amount,
    //                 'refund_final_total_without_discount' => $refund_final_total_without_discount,
    //                 'refund_final_total_without_discount_and_gst' => $refund_final_total_without_discount_and_gst,
    //                 'return_round_off_amount' => $value['round_off_amount']
    //             ];

    //             if($type == 'Handheld_Delivery' && $value['lalamove_status'] == 'COMPLETED' || $value['pickup_completed'] == 1) {
    //                 $total_handheld_completed += 1;
    //             } else if($type == 'Handheld_Delivery' && $value['lalamove_status'] == 'REJECTED') {
    //                 $total_handheld_rejected += 1;
    //             }
    //         }

    //         if($app_order_id == null && $type != 'PickupOrDelivery') {
    //             $query = CashRegister::where('business_id', $business_id)
    //                                 ->where('location_id', $location_id)
    //                                 ->with(['cash_register_transactions'])
    //                                 ->where('user_id', $user_id);

    //             if (!empty($created_at)) {
    //                 $query->whereDate('cash_registers.created_at', $created_at);
    //             } else {
    //                 $query->whereDate('cash_registers.created_at', \Carbon::now()->format('Y-m-d 00:00:00'));
    //             }

    //             $cash_registers = $query->get();

    //             if($type == 'Handheld_Delivery') {
    //                 return["sells"=>$transaction_result, "cash_registers"=>$cash_registers, "total_sale_for_handheld"=>$total_sale_for_handheld, "total_handheld_completed"=>$total_handheld_completed, "total_handheld_rejected"=>$total_handheld_rejected];
    //             } else {
    //                 return["sells"=>$transaction_result, "cash_registers"=>$cash_registers];
    //             }
    //         } else {
    //             return["sells"=>$transaction_result];
    //         }
    //     } 
    //     catch (\Exception $e) 
    //     {

    //         DB::rollBack();

    //         \Log::emergency("File:" . $e->getFile(). "Line:" . $e->getLine(). "Message:" . $e->getMessage());
    //             $msg = __('messages.something_went_wrong');

    //         $output = [
    //                         'errorMessage' => $msg
    //                     ];

    //         return $output;
    //     }
    // }

    function get_sale_history_new($user_id, $business_id, $location_id, $transaction_status, $created_at, $type, $transaction_id = null, $contact_id = null)
    {
        try {

            $app_order_id = "";
            $date_string = $created_at;
            $hour = date("H", strtotime($date_string));

            if ($hour >= 0 && $hour < 6) {
                $today = date("Y-m-d", strtotime("-1 day")) . Config::get('constants.businessStartTime');
                $tomorrow = date("Y-m-d") . Config::get('constants.businessEndTime');
            } else {
                $today = date("Y-m-d") . Config::get('constants.businessStartTime');
                $tomorrow = date("Y-m-d", strtotime("+1 day")) . Config::get('constants.businessEndTime');
            }

            $query = Transaction::leftjoin('transaction_payments as t', 't.transaction_id', '=', 'transactions.id')
                ->leftjoin('variations as w', 'w.product_id', '=', 'transactions.additional_discount_method')
                ->leftjoin('tax_rates as z', 'z.id', '=', 'transactions.tax_id')
                ->leftJoin('transactions AS SR', 'transactions.id', '=', 'SR.return_parent_id')
                ->with('sell_lines.variations.product.category')
                ->with('payment_lines')
                // ->with('contact')
                ->where('transactions.business_id', $business_id)
                ->where('transactions.location_id', $location_id)
                //->where('transactions.created_by', $user_id)
                ->where('transactions.type', 'sell')
                //->where('transactions.type_for_api', 'Takeaway')
                ->where('transactions.is_direct_sale', 0);

            //For web pickup and delivery
            if ($contact_id != null) {
                $query->where('transactions.contact_id', $contact_id);

                if (!empty($created_at)) {
                    $query->whereBetween('transactions.created_at', [$today, $tomorrow]);
                    //$query->whereDate('transactions.created_at', $created_at); //2021-08-15 00:00:00
                }
            }

            if ($transaction_id != null) {
                $query->where('transactions.id', $transaction_id);
            }
            // else if($type == 'TrackOrder')
            // {
            //     $query->whereDate('transactions.created_at','=', Carbon::today());
            // }
            else if ($type != 'PickupOrDelivery' && $type != 'TrackOrder' && $contact_id == null) {
                if (!empty($created_at)) {
                    $query->whereBetween('transactions.created_at', [$today, $tomorrow]);
                    //$query->whereDate('transactions.created_at', $created_at); //2021-08-15 00:00:00
                } else {
                    //$query->whereBetween('transactions.created_at', [$today, $tomorrow]);
                    $query->whereDate('transactions.created_at', \Carbon::now()->format('Y-m-d 00:00:00'));
                }
            }

            if (!empty($type)) {
                //For web pickup and delivery
                if ($type == 'PickupOrDelivery' || $type == 'Pickup' || $type == 'TrackOrder' || $type == 'Delivery') {
                    $query->leftJoin(
                        'delivery_details AS DD',
                        'transactions.id',
                        '=',
                        'DD.transaction_id'
                    )
                        ->leftJoin(
                            'business_locations AS BL',
                            'DD.outlet',
                            '=',
                            'BL.id'
                        )
                        ->leftJoin(
                            'business_locations AS BLD',
                            'transactions.location_id',
                            '=',
                            'BLD.id'
                        );
                    if ($type == 'PickupOrDelivery') {
                        $query->where(function ($query) use ($contact_id, $business_id, $location_id) {
                            $query->where('transactions.type_for_api', '=', 'Pickup')
                                ->where('transactions.pickup_completed', '=', 1)
                                ->where('transactions.contact_id', $contact_id)
                                ->where('transactions.business_id', $business_id)
                                ->where('transactions.location_id', $location_id);
                        })->orWhere(function ($query) use ($contact_id, $business_id, $location_id) {
                            $query->where('transactions.type_for_api', '=', 'Delivery')
                                ->where('transactions.lalamove_status', '!=', 'ASSIGNING_DRIVER')
                                ->where('transactions.lalamove_status', '!=', 'ON_GOING')
                                ->where('transactions.lalamove_status', '!=', 'PICKED_UP')
                                ->where('transactions.contact_id', $contact_id)
                                ->where('transactions.business_id', $business_id)
                                ->where('transactions.location_id', $location_id);
                        });
                    } else if ($type == 'TrackOrder') {
                        $query->where(function ($query) use ($contact_id, $business_id, $location_id) {
                            $query->where('transactions.type_for_api', '=', 'Pickup')
                                ->where('transactions.pickup_completed', '=', 0)
                                ->where('transactions.contact_id', $contact_id)
                                ->where('transactions.business_id', $business_id)
                                ->where('transactions.location_id', $location_id);
                        })->orWhere(function ($query) use ($contact_id, $business_id, $location_id) {
                            $query->where('transactions.type_for_api', '=', 'Delivery')
                                ->where('transactions.lalamove_status', '!=', 'COMPLETED')
                                ->where('transactions.lalamove_status', '!=', 'EXPIRED')
                                ->where('transactions.lalamove_status', '!=', 'CANCELED')
                                ->where('transactions.lalamove_status', '!=', 'REJECTED')
                                ->where('transactions.contact_id', $contact_id)
                                ->where('transactions.business_id', $business_id)
                                ->where('transactions.location_id', $location_id);
                        });
                    }
                } else {
                    $query->where('transactions.type_for_api', $type);
                }
            } else {
                $query->where(function ($query) {
                    $query->where('transactions.type_for_api', 'Dinein')
                        ->orWhere('transactions.type_for_api', 'Takeaway')
                        ->orWhere('transactions.type_for_api', 'Retail')
                        ->orWhere('transactions.type_for_api', 'Kiosk')
                        ->orWhere('transactions.type_for_api', 'Common');
                });
            }

            if ($transaction_status == 'quotation') {
                $query->where('transactions.status', 'draft')
                    ->where('transactions.sub_status', 'quotation');
            } elseif ($transaction_status == 'draft') {
                $query->where('transactions.status', 'draft')
                    ->whereNull('transactions.sub_status');
            } else {
                $query->where('transactions.status', $transaction_status);
            }

            // $transaction_sub_type = $request->get('transaction_sub_type');
            // if (!empty($transaction_sub_type)) {
            //$query->where('transactions.sub_type', $transaction_sub_type);
            // } else {
            //     $query->where('transactions.sub_type', null);
            // }

            $query->orderBy('transactions.created_at', 'desc')
                ->groupBy('transactions.id');

            //For web pickup and delivery
            if ($type == 'PickupOrDelivery' || $type == 'Pickup' || $type == 'TrackOrder' || $type == 'Delivery') {
                $transactions = $query->select(
                    'transactions.*',
                    't.amount as received_amount',
                    't.method',
                    't.card_type',
                    't.last_4_card_digits',
                    'w.profit_percent',
                    'z.amount as tax_rate_amount',
                    DB::raw('COUNT(SR.id) as return_exists'),
                    'SR.refund_all',
                    'DD.d_date',
                    'DD.d_time',
                    'DD.d_address',
                    'BL.name as business_location_name_for_pickup',
                    'BL.mobile as business_location_mobile_for_pickup',
                    'BLD.name as business_location_name_for_delivery',
                    'BLD.mobile as business_location_mobile_for_delivery'
                )
                    ->with(['contact'])
                    ->get();
            } else {
                $transactions = $query->select('transactions.*', 't.amount as received_amount', 't.method', 't.card_type', 't.last_4_card_digits', 'w.profit_percent', 'z.amount as tax_rate_amount', DB::raw('COUNT(SR.id) as return_exists'), 'SR.refund_all')
                    ->with(['contact'])
                    //->limit(5)
                    ->get();
            }

            $retail_gst = 0;
            $business_tax_rates = TaxRate::where('business_id', $business_id)
                ->get()
                ->toArray();

            for ($i = 0; $i < count($business_tax_rates); $i++) {
                if (strtolower($business_tax_rates[$i]['name']) == 'gst') {
                    $retail_gst = $business_tax_rates[$i]['amount'];
                }
            }

            $businessUtil = new BusinessUtil();
            $business = $businessUtil->getDetails($business_id);
            $pos_settings = json_decode($business->pos_settings);

            //return $transactions;
            $transaction_result = [];
            $total_dont_have_line_discount_amt = 0;
            //$final_total_for_single_item = 0;
            foreach ($transactions as $key => $value) {
                $item = [];
                $payments = [];
                $final_total_for_single_item = 0;
                $final_total_line_discount_amount = 0;
                $service_charge_amount = 0;
                $increment = 0;

                foreach ($value['sell_lines'] as $sellLinesKey => $sellLinesValue) {

                    $total_line_discount_amount = 0;
                    if ($sellLinesValue["parent_sell_line_id"] == null && $sellLinesValue["transaction_id"] == $value['id']) {
                        $adons = [];
                        $combo_adons = [];
                        $total_for_single_item = 0;
                        foreach ($value['sell_lines'] as $sellLinesKey1 => $sellLinesValue1) {
                            if ($sellLinesValue1["parent_sell_line_id"] != null && $sellLinesValue1["parent_sell_line_id"] == $sellLinesValue['id'] && $sellLinesValue1["children_type"] == "modifier") {

                                $adons[] = [
                                    'id' => $sellLinesValue1['variations']->id,
                                    'modifier_set_id' => $sellLinesValue1['variations']->product_id,
                                    'modifier_sell_line_id' => $sellLinesValue1['id'],
                                    'name' => $sellLinesValue1['variations']->name,
                                    'quantity' => $sellLinesValue1["quantity"],
                                    'amount' => $sellLinesValue1['unit_price_before_discount'], //unit_price_before_discount
                                    'not_for_receipt' => $sellLinesValue1['variations']->product->not_for_receipt,
                                    'modifier_app_id' => $sellLinesValue1['modifier_app_ids']
                                ];
                                if ($sellLinesValue["quantity_returned"] == "0.0000" && $sellLinesValue["change_price"] == 0) {
                                    //total modifier price
                                    $total_for_single_item = $total_for_single_item + $sellLinesValue1['unit_price_before_discount'];
                                }
                            } else if ($sellLinesValue1["parent_sell_line_id"] != null && $sellLinesValue1["parent_sell_line_id"] == $sellLinesValue['id'] && $sellLinesValue1["children_type"] == "combo") {
                                $combo_adons[] = [
                                    'transaction_sell_lines_id' => $sellLinesValue1['id'],
                                    'product_id' => $sellLinesValue1['product_id'],
                                    'variation_id' => $sellLinesValue1['variation_id'],
                                    'quantity' => $sellLinesValue1['quantity'],
                                ];
                            }
                        }

                        //main item price + modifier price
                        if ($sellLinesValue['weight'] > 0) {
                            $total_for_single_item = ($sellLinesValue['unit_price_before_discount'] + $total_for_single_item) * $sellLinesValue["quantity"];
                        } else {
                            $total_for_single_item = ($sellLinesValue['unit_price_before_discount'] + $total_for_single_item) * $sellLinesValue["quantity"];
                        }

                        if ($increment == 0) {
                            $total_dont_have_line_discount_amt = 0;
                        }

                        if ($sellLinesValue["quantity_returned"] == "0.0000") {
                            $final_total_for_single_item += $total_for_single_item;
                            //calculate if line item has line discount
                            if ($sellLinesValue['line_discount_type'] == "fixed") {
                                $total_line_discount_amount += $sellLinesValue['line_discount_amount'];
                            } else if ($sellLinesValue['line_discount_type'] == "percentage") {
                                $total_line_discount_amount = (($sellLinesValue['line_discount_amount'] / 100) * $total_for_single_item) + $total_line_discount_amount;
                            }
                            //calculate final total line discount amount
                            $final_total_line_discount_amount += $total_line_discount_amount;
                            //total if item dont have line discount amount
                            if ($total_line_discount_amount == 0) {
                                $total_dont_have_line_discount_amt += $total_for_single_item;
                            }
                        }

                        $item[] = [
                            'transaction_sell_line_id' => $sellLinesValue['id'],
                            'category_id' => !empty($sellLinesValue['variations']->product->category_id) ? $sellLinesValue['variations']->product->category_id : "",
                            'name' => $sellLinesValue['variations']->product->name,
                            'short_code' => $sellLinesValue['variations']->product->category->short_code,
                            'quantity' => $sellLinesValue['quantity'],
                            'quantity_returned' => $sellLinesValue["quantity_returned"],
                            'quantity_returned_note' => $sellLinesValue["quantity_returned_note"],
                            'unit_id' => $sellLinesValue['variations']->product->unit_id,
                            'amount' => $sellLinesValue['unit_price_before_discount'],
                            'total_before_tax' => $value['total_before_tax'],
                            'tax_amount' => $value['tax_amount'],
                            'line_discount_type' => $sellLinesValue['line_discount_type'],
                            'line_discount_amount' => $sellLinesValue['line_discount_amount'],
                            'product_id' => $sellLinesValue['product_id'],
                            'variation_id' => $sellLinesValue['variation_id'],
                            'weight' => $sellLinesValue["weight"],
                            'total_line_discount_amount' => $total_line_discount_amount,
                            'total_for_single_item' => $total_for_single_item,
                            'serve_later_quantity' => $sellLinesValue["serve_later_quantity"],
                            'adons' => $adons,
                            'printed' => $sellLinesValue["printed"],
                            'sell_line_note' => $sellLinesValue["sell_line_note"],
                            'change_price' => $sellLinesValue["change_price"],
                            'combo_variations' => $combo_adons,
                            'app_order_id' => $value['app_order_id'],
                            'app_item_line_id' => $sellLinesValue["app_item_line_id"],
                            'user_id' => $sellLinesValue['user_id']
                        ];

                        $increment++;
                    }
                }

                if ($value['discount_type'] == "fixed") {
                    $discount_amount = $value['discount_amount'] + $final_total_line_discount_amount;
                } else if ($value['discount_type'] == "percentage") {
                    $discount_amount = ($value['discount_amount'] * $total_dont_have_line_discount_amt) + $final_total_line_discount_amount;
                }

                //calculate service charges
                $service_charge_amount = ($final_total_for_single_item - $discount_amount) * $value['service_charges'];

                if ($value['delivery_charges'] != 0) {
                    //calculate tax
                    $tax_amount = 0;
                    if ($value['tax_id'] != null) {
                        if ($value["is_inclusive_gst_applied"])
                            $tax_amount = (($final_total_for_single_item - $discount_amount) / (100 + $value['tax_rate_amount'])) * $value['tax_rate_amount'];
                        else
                            $tax_amount = ($value['tax_rate_amount'] / 100) * ($final_total_for_single_item - $discount_amount);
                    }

                    if ($value['is_inclusive_gst_applied'])
                        $final_total = $final_total_for_single_item + $value['delivery_charges'];
                    else
                        $final_total = $final_total_for_single_item + $tax_amount + $value['delivery_charges'];
                } else {
                    //calculate tax
                    $tax_amount = 0;
                    $refund_tax_amount = 0;

                    if ($value['type_for_api'] == 'Retail') {
                        $tax_amount = ($final_total_for_single_item + $service_charge_amount - $discount_amount) - (($final_total_for_single_item + $service_charge_amount - $discount_amount) / (1 + ($retail_gst / 100)));

                        $final_total = round($final_total_for_single_item, 2) + 0 + round($service_charge_amount, 2) - round($discount_amount, 2);
                    } else {
                        if ($value['tax_id'] != null) {
                            if ($value["is_inclusive_gst_applied"])
                                $tax_amount = (($final_total_for_single_item - $discount_amount) / (100 + $value['tax_rate_amount'])) * $value['tax_rate_amount'];
                            else
                                $tax_amount = ($value['tax_rate_amount'] / 100) * ($final_total_for_single_item - $discount_amount);
                        }
                        if ($value['is_inclusive_gst_applied'])
                            $final_total = round($final_total_for_single_item, 2) + round($service_charge_amount, 2) - round($discount_amount, 2);
                        else
                            $final_total = round($final_total_for_single_item, 2) + round($tax_amount, 2) + round($service_charge_amount, 2) - round($discount_amount, 2);
                    }
                }

                $amount_rounding_method = $pos_settings->amount_rounding_method;
                $payment_method = $value->method;
                $latest_round_off_amount = $this->transactionUtil->latest_round_off_amount($payment_method, $final_total, $amount_rounding_method);

                // For multiple payment
                foreach ($value['payment_lines'] as $payment_lines_key => $payment_line) {
                    if (count($value['payment_lines']) == 1) {
                        if ($final_total > 0) {
                            $cash_received_amount = $final_total + $latest_round_off_amount;
                        } else {
                            $cash_received_amount = $final_total;
                        }
                    } else {
                        if ($value['refund_all'] == 1) {
                            $cash_received_amount = 0;
                        } else {
                            $cash_received_amount = $payment_line['amount'];
                        }
                    }
                    $payments[] = [
                        'transaction_payment_id' => $payment_line['id'],
                        'method' => $payment_line['method'],
                        'card_type' => $payment_line['card_type'],
                        'last_4_card_digits' => $payment_line['last_4_card_digits'],
                        'received_amount' => $cash_received_amount
                    ];
                }

                $table_arr = [];
                $table_name = [];
                $pax = '';

                $table_query = Transaction::leftjoin('pos_res_tables as t', 't.transaction_id', '=', 'transactions.id')
                    ->leftjoin('res_tables as z', 'z.id', '=', 't.res_table_id')
                    ->where('transactions.id', $value['id'])
                    ->select('t.res_table_id', 'pax', 'z.name')
                    ->get();

                if (!empty($table_query)) {
                    foreach ($table_query as $key => $tableValue) {
                        if ($tableValue['res_table_id'] != null) {
                            array_push($table_arr, $tableValue['res_table_id']);
                            array_push($table_name, $tableValue['name']);
                            $pax = $tableValue['pax'];
                        }
                    }
                }

                //For web pickup and delivery
                if ($type == 'PickupOrDelivery' || $type == 'Pickup' || $type == 'TrackOrder' || $type == 'Delivery') {
                    $last_4_card_digits = "**** **** **** " . $value['last_4_card_digits'];
                    $d_date = $value['d_date'];
                    $d_time = $value['d_time'];
                    $d_address = $value['d_address'];
                    $business_location_name_for_pickup = $value['business_location_name_for_pickup'];
                    $business_location_mobile_for_pickup = $value['business_location_mobile_for_pickup'];
                    $business_location_name_for_delivery = $value['business_location_name_for_delivery'];
                    $business_location_mobile_for_delivery = $value['business_location_mobile_for_delivery'];
                    $order_no = $value['order_no'];
                    $pickup_completed = $value['pickup_completed'];
                    $lalamove_orderRef = $value['lalamove_orderRef'];
                    $lalamove_status = $value['lalamove_status'];
                    $lalamove_driver_info = '';
                    if ($type == 'Delivery') {
                        $order = json_decode($value['lalamove_result'], true);
                        if (!empty($order)) {
                            if (!empty($order['data']['order']['driverId'])) {
                                $lalamove_driver_id = $order['data']['order']['driverId'];
                            } else if (!empty($order['driverId'])) {
                                $lalamove_driver_id = $order['driverId'];
                            } else {
                                $lalamove_driver_id = '';
                            }

                            if ($lalamove_driver_id != '') {
                                $lalamove_driver_info = $this->check_driver_details($lalamove_orderRef, $lalamove_driver_id, $value['business_id'], $value['location_id']);
                                $lalamove_driver_info = json_decode($lalamove_driver_info, true);
                            }
                        }
                    }
                } else {
                    $last_4_card_digits = '';
                    $d_date = '';
                    $d_time = '';
                    $d_address = '';
                    $business_location_name_for_pickup = '';
                    $business_location_mobile_for_pickup = '';
                    $business_location_name_for_delivery = '';
                    $business_location_mobile_for_delivery = '';
                    $order_no = '';
                    $pickup_completed = '';
                    $lalamove_orderRef = '';
                    $lalamove_status = '';
                    $lalamove_driver_info = '';
                }

                $check_contact_access = Contact::join('user_contact_access AS uca', 'contacts.id', 'uca.contact_id')
                    ->where('uca.contact_id', $value['contact_id'])->first();

                if ($check_contact_access) {
                    $user_query = User::where('id', $check_contact_access->user_id)->first();

                    $member_mobile = $user_query->contact_number;
                    $member_dob = $user_query->dob;
                } else {
                    $member_mobile = "";
                    $member_dob = "";
                }

                $transaction_result[] = [
                    'app_order_id' => $value['app_order_id'],
                    'id' => $value['id'],
                    'business_id' => $value['business_id'],
                    'location_id' => $value['location_id'],
                    'transaction_date' => $value['transaction_date'],
                    'table_id' => $table_arr,
                    'table_name' => $table_name,
                    'pax' => $pax,
                    'invoice_no' => $value['invoice_no'],
                    'order_check_no' => $value['order_check_no'],
                    'ref_no' => $value['ref_no'],
                    'order_no' => $value['order_no'],
                    'type' => $value['type'],
                    'type_for_api' => $value['type_for_api'],
                    'total' => $final_total,
                    'round_off_amount' => round($latest_round_off_amount, 2),
                    'paymentType' => $value['method'],
                    'card_type' => $value['card_type'],
                    'tax_id' => $value['tax_id'],
                    'contact_id' => $value['contact_id'],
                    'tax_amount' => $tax_amount,
                    'addon_discount' => ($value['profit_percent'] == null ? 0 : $value['profit_percent']),
                    'discount_type' => $value['discount_type'],
                    'discount_amount' => $discount_amount,
                    'service_charge' => $value['service_charges'],
                    'delivery_charge' => $value['delivery_charges'],
                    'reward_amount' => $value['rp_redeemed'],
                    'customer_reward_amount' => $value['rp_redeemed_amount'],
                    'service_charge_amount' => $service_charge_amount,
                    'tax_rate_amount' => $value['tax_rate_amount'],
                    'profit_percent' => $value['profit_percent'],
                    'return_exists' => $value['return_exists'],
                    'refund_all' => $value['refund_all'],
                    'total_dont_have_line_discount_amt' => $total_dont_have_line_discount_amt,
                    //'total_line_discount_amount' => $total_line_discount_amount,
                    'final_total_for_single_item' => $final_total_for_single_item,
                    'received_amount' => $value['received_amount'],
                    'last_4_card_digits' => $last_4_card_digits,
                    'd_date' => $d_date,
                    'd_time' => $d_time,
                    'd_address' => $d_address,
                    'business_location_name_for_pickup' => $business_location_name_for_pickup,
                    'business_location_mobile_for_pickup' => $business_location_mobile_for_pickup,
                    'business_location_name_for_delivery' => $business_location_name_for_delivery,
                    'business_location_mobile_for_delivery' => $business_location_mobile_for_delivery,
                    'order_no' => $order_no,
                    'pickup_completed' => $pickup_completed,
                    'lalamove_orderRef' => $lalamove_orderRef,
                    'lalamove_status' => $lalamove_status,
                    'lalamove_driver_info' => $lalamove_driver_info,
                    'shipping_charges' => $value['shipping_charges'],
                    'first_name' => $value['contact']->first_name,
                    'last_name' => $value['contact']->last_name,
                    'estimated_arrival_time' => Carbon::parse(Carbon::parse($value['transaction_date'])->addHour())->format('d/m/Y h:ia'),
                    'updated_at' => Carbon::parse($value['updated_at'])->format('d/m/Y h:ia'),
                    'deposit' => $value['deposit'],
                    'member_mobile' => $member_mobile,
                    'member_dob' => $member_dob,
                    'item' => $item,
                    'payments' => $payments,
                    'is_inclusive_gst_applied' => $value['is_inclusive_gst_applied'] ? true : false
                ];

            }

            if ($transaction_id == null && $type != 'PickupOrDelivery') {
                $query = CashRegister::where('business_id', $business_id)
                    ->where('location_id', $location_id)
                    ->with(['cash_register_transactions'])
                    ->where('user_id', $user_id);

                if (!empty($created_at)) {
                    $query->whereDate('cash_registers.created_at', $created_at);
                } else {
                    $query->whereDate('cash_registers.created_at', \Carbon::now()->format('Y-m-d 00:00:00'));
                }

                $cash_registers = $query->get();

                return ["sells" => $transaction_result, "cash_registers" => $cash_registers];
            } else {
                return ["sells" => $transaction_result];
            }
        } catch (\Exception $e) {
            DB::rollBack();

            \Log::emergency("File:" . $e->getFile() . "Line:" . $e->getLine() . "Message:" . $e->getMessage());
            $msg = __('messages.something_went_wrong');

            $output = [
                'errorMessage' => $msg
            ];

            return $output;
        }
    }

    function get_sale_history_new2($user_id, $business_id, $location_id, $transaction_status, $created_at, $type, $transaction_id = null, $contact_id = null)
    {
        $app_order_id = "";
        $date_string = $created_at;
        $hour = date("H", strtotime($date_string));

        if ($hour >= 0 && $hour < 6) {
            $today = date("Y-m-d", strtotime("-1 day")) . Config::get('constants.businessStartTime');
            $tomorrow = date("Y-m-d") . Config::get('constants.businessEndTime');
        } else {
            $today = date("Y-m-d") . Config::get('constants.businessStartTime');
            $tomorrow = date("Y-m-d", strtotime("+1 day")) . Config::get('constants.businessEndTime');
        }

        try {
            $query = Transaction::leftjoin('transaction_payments as t', 't.app_order_id', '=', 'transactions.app_order_id')
                ->leftjoin('variations as w', 'w.product_id', '=', 'transactions.additional_discount_method')
                ->leftjoin('tax_rates as z', 'z.id', '=', 'transactions.tax_id')
                ->leftJoin('transactions AS SR', 'transactions.app_order_id', '=', 'SR.return_parent_id')
                ->with('sell_lines.variations.product.category')
                ->with('payment_lines')
                // ->with('contact')
                ->where('transactions.business_id', $business_id)
                ->where('transactions.location_id', $location_id)
                //->where('transactions.created_by', $user_id)
                ->where('transactions.type', 'sell')
                //->where('transactions.type_for_api', 'Takeaway')
                ->where('transactions.is_direct_sale', 0);


            //For web pickup and delivery
            if ($contact_id != null) {
                $query->where('transactions.contact_id', $contact_id);

                if (!empty($created_at)) {
                    //$query->whereDate('transactions.created_at', $created_at); //2021-08-15 00:00:00
                    $query->whereBetween('transactions.created_at', [$today, $tomorrow]);
                }
            }

            if ($app_order_id != null) {
                $query->where('transactions.app_order_id', $app_order_id);
            }
            // else if($type == 'TrackOrder')
            // {
            //     $query->whereDate('transactions.created_at','=', Carbon::today());
            // }
            else if ($type != 'PickupOrDelivery' && $type != 'TrackOrder' && $contact_id == null) {
                if (!empty($created_at)) {
                    $query->whereBetween('transactions.created_at', [$today, $tomorrow]);
                    //$query->whereDate('transactions.created_at', $created_at); //2021-08-15 00:00:00
                } else {
                    $query->whereBetween('transactions.created_at', [$today, $tomorrow]);
                    //$query->whereDate('transactions.created_at', \Carbon::now()->format('Y-m-d 00:00:00'));
                }
            }

            if (!empty($type)) {
                //For web pickup and delivery
                if ($type == 'PickupOrDelivery' || $type == 'Pickup' || $type == 'TrackOrder' || $type == 'Delivery') {
                    $query->leftJoin(
                        'delivery_details AS DD',
                        'transactions.app_order_id',
                        '=',
                        'DD.app_order_id'
                    )
                        ->leftJoin(
                            'business_locations AS BL',
                            'DD.outlet',
                            '=',
                            'BL.id'
                        )
                        ->leftJoin(
                            'business_locations AS BLD',
                            'transactions.location_id',
                            '=',
                            'BLD.id'
                        );
                    if ($type == 'PickupOrDelivery') {
                        $query->where(function ($query) use ($contact_id, $business_id, $location_id) {
                            $query->where('transactions.type_for_api', '=', 'Pickup')
                                ->where('transactions.pickup_completed', '=', 1)
                                ->where('transactions.contact_id', $contact_id)
                                ->where('transactions.business_id', $business_id)
                                ->where('transactions.location_id', $location_id);
                        })->orWhere(function ($query) use ($contact_id, $business_id, $location_id) {
                            $query->where('transactions.type_for_api', '=', 'Delivery')
                                ->where('transactions.lalamove_status', '!=', 'ASSIGNING_DRIVER')
                                ->where('transactions.lalamove_status', '!=', 'ON_GOING')
                                ->where('transactions.lalamove_status', '!=', 'PICKED_UP')
                                ->where('transactions.contact_id', $contact_id)
                                ->where('transactions.business_id', $business_id)
                                ->where('transactions.location_id', $location_id);
                        });
                    } else if ($type == 'TrackOrder') {
                        $query->where(function ($query) use ($contact_id, $business_id, $location_id) {
                            $query->where('transactions.type_for_api', '=', 'Pickup')
                                ->where('transactions.pickup_completed', '=', 0)
                                ->where('transactions.contact_id', $contact_id)
                                ->where('transactions.business_id', $business_id)
                                ->where('transactions.location_id', $location_id);
                        })->orWhere(function ($query) use ($contact_id, $business_id, $location_id) {
                            $query->where('transactions.type_for_api', '=', 'Delivery')
                                ->where('transactions.lalamove_status', '!=', 'COMPLETED')
                                ->where('transactions.lalamove_status', '!=', 'EXPIRED')
                                ->where('transactions.lalamove_status', '!=', 'CANCELED')
                                ->where('transactions.lalamove_status', '!=', 'REJECTED')
                                ->where('transactions.contact_id', $contact_id)
                                ->where('transactions.business_id', $business_id)
                                ->where('transactions.location_id', $location_id);
                        });
                    }
                } else {
                    $query->where('transactions.type_for_api', $type);
                }
            } else {
                $query->where(function ($query) {
                    $query->where('transactions.type_for_api', 'Dinein')
                        ->orWhere('transactions.type_for_api', 'Takeaway')
                        ->orWhere('transactions.type_for_api', 'Retail')
                        ->orWhere('transactions.type_for_api', 'Kiosk')
                        ->orWhere('transactions.type_for_api', 'Common');
                });
            }

            if ($transaction_status == 'quotation') {
                $query->where('transactions.status', 'draft')
                    ->where('transactions.sub_status', 'quotation');
            } elseif ($transaction_status == 'draft') {
                $query->where('transactions.status', 'draft')
                    ->whereNull('transactions.sub_status');
            } else {
                $query->where('transactions.status', $transaction_status);
            }

            // $transaction_sub_type = $request->get('transaction_sub_type');
            // if (!empty($transaction_sub_type)) {
            //$query->where('transactions.sub_type', $transaction_sub_type);
            // } else {
            //     $query->where('transactions.sub_type', null);
            // }

            $query->orderBy('transactions.created_at', 'desc')
                ->groupBy('transactions.id');

            //For web pickup and delivery
            if ($type == 'PickupOrDelivery' || $type == 'Pickup' || $type == 'TrackOrder' || $type == 'Delivery') {
                $transactions = $query->select(
                    'transactions.*',
                    't.amount as received_amount',
                    't.method',
                    't.card_type',
                    't.last_4_card_digits',
                    'w.profit_percent',
                    'z.amount as tax_rate_amount',
                    DB::raw('COUNT(SR.id) as return_exists'),
                    'SR.refund_all',
                    'DD.d_date',
                    'DD.d_time',
                    'DD.d_address',
                    'BL.name as business_location_name_for_pickup',
                    'BL.mobile as business_location_mobile_for_pickup',
                    'BLD.name as business_location_name_for_delivery',
                    'BLD.mobile as business_location_mobile_for_delivery'
                )
                    ->with(['contact'])
                    ->get();
            } else {
                $transactions = $query->select('transactions.*', 't.amount as received_amount', 't.method', 't.card_type', 't.last_4_card_digits', 'w.profit_percent', 'z.amount as tax_rate_amount', DB::raw('COUNT(SR.id) as return_exists'), 'SR.refund_all')
                    ->with(['contact'])
                    //->limit(5)
                    ->get();
            }

            $retail_gst = 0;
            $business_tax_rates = TaxRate::where('business_id', $business_id)
                ->get()
                ->toArray();

            for ($i = 0; $i < count($business_tax_rates); $i++) {
                if (strtolower($business_tax_rates[$i]['name']) == 'gst') {
                    $retail_gst = $business_tax_rates[$i]['amount'];
                }
            }

            $businessUtil = new BusinessUtil();
            $business = $businessUtil->getDetails($business_id);
            $pos_settings = json_decode($business->pos_settings);

            //return $transactions;
            $transaction_result = [];
            $total_dont_have_line_discount_amt = 0;
            //$final_total_for_single_item = 0;
            foreach ($transactions as $key => $value) {
                $item = [];
                $payments = [];
                $final_total_for_single_item = 0;
                $final_total_line_discount_amount = 0;
                $service_charge_amount = 0;
                $increment = 0;

                foreach ($value['sell_lines'] as $sellLinesKey => $sellLinesValue) {
                    $total_line_discount_amount = 0;
                    if ($sellLinesValue["parent_sell_line_id"] == null && $sellLinesValue["transaction_id"] == $value['id']) {
                        $adons = [];
                        $combo_adons = [];
                        $total_for_single_item = 0;
                        foreach ($value['sell_lines'] as $sellLinesKey1 => $sellLinesValue1) {
                            if ($sellLinesValue1["parent_sell_line_id"] != null && $sellLinesValue1["parent_sell_line_id"] == $sellLinesValue['id'] && $sellLinesValue1["children_type"] == "modifier") {
                                $adons[] = [
                                    'id' => $sellLinesValue1['variations']->id,
                                    'modifier_set_id' => $sellLinesValue1['variations']->product_id,
                                    'modifier_sell_line_id' => $sellLinesValue1['id'],
                                    'name' => $sellLinesValue1['variations']->name,
                                    'quantity' => $sellLinesValue1["quantity"],
                                    'amount' => $sellLinesValue1['unit_price_before_discount'], //unit_price_before_discount
                                    'not_for_receipt' => $sellLinesValue1['variations']->product->not_for_receipt,
                                    'modifier_app_id' => $sellLinesValue1['modifier_app_ids']
                                ];
                                if ($sellLinesValue["quantity_returned"] == "0.0000" && $sellLinesValue["change_price"] == 0) {
                                    //total modifier price
                                    $total_for_single_item = $total_for_single_item + $sellLinesValue1['unit_price_before_discount'];
                                }
                            } else if ($sellLinesValue1["parent_sell_line_id"] != null && $sellLinesValue1["parent_sell_line_id"] == $sellLinesValue['id'] && $sellLinesValue1["children_type"] == "combo") {
                                $combo_adons[] = [
                                    'transaction_sell_lines_id' => $sellLinesValue1['id'],
                                    'product_id' => $sellLinesValue1['product_id'],
                                    'variation_id' => $sellLinesValue1['variation_id'],
                                    'quantity' => $sellLinesValue1['quantity'],
                                ];
                            }
                        }

                        //main item price + modifier price
                        if ($sellLinesValue['weight'] > 0) {
                            $total_for_single_item = ($sellLinesValue['unit_price_before_discount'] + $total_for_single_item) * $sellLinesValue["quantity"];
                        } else {
                            $total_for_single_item = ($sellLinesValue['unit_price_before_discount'] + $total_for_single_item) * $sellLinesValue["quantity"];
                        }

                        if ($increment == 0) {
                            $total_dont_have_line_discount_amt = 0;
                        }

                        if ($sellLinesValue["quantity_returned"] == "0.0000") {
                            $final_total_for_single_item += $total_for_single_item;
                            //calculate if line item has line discount
                            if ($sellLinesValue['line_discount_type'] == "fixed") {
                                $total_line_discount_amount += $sellLinesValue['line_discount_amount'];
                            } else if ($sellLinesValue['line_discount_type'] == "percentage") {
                                $total_line_discount_amount = (($sellLinesValue['line_discount_amount'] / 100) * $total_for_single_item) + $total_line_discount_amount;
                            }
                            //calculate final total line discount amount
                            $final_total_line_discount_amount += $total_line_discount_amount;
                            //total if item dont have line discount amount
                            if ($total_line_discount_amount == 0) {
                                $total_dont_have_line_discount_amt += $total_for_single_item;
                            }
                        }

                        $item[] = [
                            'transaction_sell_line_id' => $sellLinesValue['id'],
                            'category_id' => $sellLinesValue['variations']->product->category_id,
                            'name' => $sellLinesValue['variations']->product->name,
                            'short_code' => $sellLinesValue['variations']->product->category->short_code,
                            'quantity' => $sellLinesValue['quantity'],
                            'quantity_returned' => $sellLinesValue["quantity_returned"],
                            'quantity_returned_note' => $sellLinesValue["quantity_returned_note"],
                            'unit_id' => $sellLinesValue['variations']->product->unit_id,
                            'amount' => $sellLinesValue['unit_price_before_discount'],
                            'total_before_tax' => $value['total_before_tax'],
                            'tax_amount' => $value['tax_amount'],
                            'line_discount_type' => $sellLinesValue['line_discount_type'],
                            'line_discount_amount' => $sellLinesValue['line_discount_amount'],
                            'product_id' => $sellLinesValue['product_id'],
                            'variation_id' => $sellLinesValue['variation_id'],
                            'weight' => $sellLinesValue["weight"],
                            'total_line_discount_amount' => $total_line_discount_amount,
                            'total_for_single_item' => $total_for_single_item,
                            'serve_later_quantity' => $sellLinesValue["serve_later_quantity"],
                            'adons' => $adons,
                            'printed' => $sellLinesValue["printed"],
                            'sell_line_note' => $sellLinesValue["sell_line_note"],
                            'change_price' => $sellLinesValue["change_price"],
                            'combo_variations' => $combo_adons,
                            'app_order_id' => $value['app_order_id'],
                            'app_item_line_id' => $sellLinesValue["app_item_line_id"]
                        ];

                        $increment++;
                    }
                }

                if ($value['discount_type'] == "fixed") {
                    $discount_amount = $value['discount_amount'] + $final_total_line_discount_amount;
                } else if ($value['discount_type'] == "percentage") {
                    $discount_amount = ($value['discount_amount'] * $total_dont_have_line_discount_amt) + $final_total_line_discount_amount;
                }

                //calculate service charges
                $service_charge_amount = ($final_total_for_single_item - $discount_amount) * $value['service_charges'];

                if ($value['delivery_charges'] != 0) {
                    //calculate tax
                    $tax_amount = 0;
                    if ($value['tax_id'] != null) {
                        if ($value["is_inclusive_gst_applied"])
                            $tax_amount = (($final_total_for_single_item - $discount_amount) / (100 + $value['tax_rate_amount'])) * $value['tax_rate_amount'];
                        else
                            $tax_amount = ($value['tax_rate_amount'] / 100) * ($final_total_for_single_item - $discount_amount);
                    }
                    if ($value["is_inclusive_gst_applied"])
                        $final_total = $final_total_for_single_item + $value['delivery_charges'];
                    else
                        $final_total = $final_total_for_single_item + $tax_amount + $value['delivery_charges'];
                } else {
                    //calculate tax
                    $tax_amount = 0;
                    $refund_tax_amount = 0;

                    if ($value['type_for_api'] == 'Retail') {
                        $tax_amount = ($final_total_for_single_item + $service_charge_amount - $discount_amount) - (($final_total_for_single_item + $service_charge_amount - $discount_amount) / (1 + ($retail_gst / 100)));

                        $final_total = round($final_total_for_single_item, 2) + 0 + round($service_charge_amount, 2) - round($discount_amount, 2);
                    } else {
                        if ($value['tax_id'] != null) {
                            if ($value["is_inclusive_gst_applied"])
                                $tax_amount = (($final_total_for_single_item + $service_charge_amount - $discount_amount) / (100 + $value['tax_rate_amount'])) * $value['tax_rate_amount'];
                            else
                                $tax_amount = ($value['tax_rate_amount'] / 100) * ($final_total_for_single_item + $service_charge_amount - $discount_amount);
                        }
                        if ($value["is_inclusive_gst_applied"])
                            $final_total = round($final_total_for_single_item, 2) + round($service_charge_amount, 2) - round($discount_amount, 2);
                        else
                            $final_total = round($final_total_for_single_item, 2) + round($tax_amount, 2) + round($service_charge_amount, 2) - round($discount_amount, 2);
                    }
                }

                $amount_rounding_method = $pos_settings->amount_rounding_method;
                $payment_method = $value->method;
                $latest_round_off_amount = $this->transactionUtil->latest_round_off_amount($payment_method, $final_total, $amount_rounding_method);

                // For multiple payment
                foreach ($value['payment_lines'] as $payment_lines_key => $payment_line) {
                    if (count($value['payment_lines']) == 1) {
                        if ($final_total > 0) {
                            $cash_received_amount = $final_total + $latest_round_off_amount;
                        } else {
                            $cash_received_amount = $final_total;
                        }
                    } else {
                        if ($value['refund_all'] == 1) {
                            $cash_received_amount = 0;
                        } else {
                            $cash_received_amount = $payment_line['amount'];
                        }
                    }
                    $payments[] = [
                        'transaction_payment_id' => $payment_line['id'],
                        'method' => $payment_line['method'],
                        'card_type' => $payment_line['card_type'],
                        'last_4_card_digits' => $payment_line['last_4_card_digits'],
                        'received_amount' => $cash_received_amount
                    ];
                }

                $table_arr = [];
                $table_name = [];
                $pax = '';

                $table_query = Transaction::leftjoin('pos_res_tables as t', 't.app_order_id', '=', 'transactions.app_order_id')
                    ->leftjoin('res_tables as z', 'z.id', '=', 't.res_table_id')
                    ->where('transactions.id', $value['id'])
                    ->select('t.res_table_id', 'pax', 'z.name')
                    ->get();

                if (!empty($table_query)) {
                    foreach ($table_query as $key => $tableValue) {
                        if ($tableValue['res_table_id'] != null) {
                            array_push($table_arr, $tableValue['res_table_id']);
                            array_push($table_name, $tableValue['name']);
                            $pax = $tableValue['pax'];
                        }
                    }
                }

                //For web pickup and delivery
                if ($type == 'PickupOrDelivery' || $type == 'Pickup' || $type == 'TrackOrder' || $type == 'Delivery') {
                    $last_4_card_digits = "**** **** **** " . $value['last_4_card_digits'];
                    $d_date = $value['d_date'];
                    $d_time = $value['d_time'];
                    $d_address = $value['d_address'];
                    $business_location_name_for_pickup = $value['business_location_name_for_pickup'];
                    $business_location_mobile_for_pickup = $value['business_location_mobile_for_pickup'];
                    $business_location_name_for_delivery = $value['business_location_name_for_delivery'];
                    $business_location_mobile_for_delivery = $value['business_location_mobile_for_delivery'];
                    $order_no = $value['order_no'];
                    $pickup_completed = $value['pickup_completed'];
                    $lalamove_orderRef = $value['lalamove_orderRef'];
                    $lalamove_status = $value['lalamove_status'];
                    $lalamove_driver_info = '';
                    if ($type == 'Delivery') {
                        $order = json_decode($value['lalamove_result'], true);
                        if (!empty($order)) {
                            if (!empty($order['data']['order']['driverId'])) {
                                $lalamove_driver_id = $order['data']['order']['driverId'];
                            } else if (!empty($order['driverId'])) {
                                $lalamove_driver_id = $order['driverId'];
                            } else {
                                $lalamove_driver_id = '';
                            }

                            if ($lalamove_driver_id != '') {
                                $lalamove_driver_info = $this->check_driver_details($lalamove_orderRef, $lalamove_driver_id, $value['business_id'], $value['location_id']);
                                $lalamove_driver_info = json_decode($lalamove_driver_info, true);
                            }
                        }
                    }
                } else {
                    $last_4_card_digits = '';
                    $d_date = '';
                    $d_time = '';
                    $d_address = '';
                    $business_location_name_for_pickup = '';
                    $business_location_mobile_for_pickup = '';
                    $business_location_name_for_delivery = '';
                    $business_location_mobile_for_delivery = '';
                    $order_no = '';
                    $pickup_completed = '';
                    $lalamove_orderRef = '';
                    $lalamove_status = '';
                    $lalamove_driver_info = '';
                }

                $check_contact_access = Contact::join('user_contact_access AS uca', 'contacts.id', 'uca.contact_id')
                    ->where('uca.contact_id', $value['contact_id'])->first();

                if ($check_contact_access) {
                    $user_query = User::where('id', $check_contact_access->user_id)->first();

                    $member_mobile = $user_query->contact_no;
                    $member_dob = $user_query->dob;
                } else {
                    $member_mobile = "";
                    $member_dob = "";
                }

                $transaction_result[] = [
                    'app_order_id' => $value['app_order_id'],
                    'id' => $value['id'],
                    'business_id' => $value['business_id'],
                    'location_id' => $value['location_id'],
                    'transaction_date' => $value['transaction_date'],
                    'table_id' => $table_arr,
                    'table_name' => $table_name,
                    'pax' => $pax,
                    'invoice_no' => $value['invoice_no'],
                    'order_check_no' => $value['order_check_no'],
                    'ref_no' => $value['ref_no'],
                    'order_no' => $value['order_no'],
                    'type' => $value['type'],
                    'type_for_api' => $value['type_for_api'],
                    'total' => $final_total,
                    'round_off_amount' => round($latest_round_off_amount, 2),
                    'paymentType' => $value['method'],
                    'card_type' => $value['card_type'],
                    'tax_id' => $value['tax_id'],
                    'contact_id' => $value['contact_id'],
                    'tax_amount' => $tax_amount,
                    'addon_discount' => ($value['profit_percent'] == null ? 0 : $value['profit_percent']),
                    'discount_type' => $value['discount_type'],
                    'discount_amount' => $discount_amount,
                    'service_charge' => $value['service_charges'],
                    'delivery_charge' => $value['delivery_charges'],
                    'reward_amount' => $value['rp_redeemed'],
                    'customer_reward_amount' => $value['rp_redeemed_amount'],
                    'service_charge_amount' => $service_charge_amount,
                    'tax_rate_amount' => $value['tax_rate_amount'],
                    'profit_percent' => $value['profit_percent'],
                    'return_exists' => $value['return_exists'],
                    'refund_all' => $value['refund_all'],
                    'total_dont_have_line_discount_amt' => $total_dont_have_line_discount_amt,
                    //'total_line_discount_amount' => $total_line_discount_amount,
                    'final_total_for_single_item' => $final_total_for_single_item,
                    'received_amount' => $value['received_amount'],
                    'last_4_card_digits' => $last_4_card_digits,
                    'd_date' => $d_date,
                    'd_time' => $d_time,
                    'd_address' => $d_address,
                    'business_location_name_for_pickup' => $business_location_name_for_pickup,
                    'business_location_mobile_for_pickup' => $business_location_mobile_for_pickup,
                    'business_location_name_for_delivery' => $business_location_name_for_delivery,
                    'business_location_mobile_for_delivery' => $business_location_mobile_for_delivery,
                    'order_no' => $order_no,
                    'pickup_completed' => $pickup_completed,
                    'lalamove_orderRef' => $lalamove_orderRef,
                    'lalamove_status' => $lalamove_status,
                    'lalamove_driver_info' => $lalamove_driver_info,
                    'shipping_charges' => $value['shipping_charges'],
                    'first_name' => $value['contact']->first_name,
                    'last_name' => $value['contact']->last_name,
                    'estimated_arrival_time' => Carbon::parse(Carbon::parse($value['transaction_date'])->addHour())->format('d/m/Y h:ia'),
                    'updated_at' => Carbon::parse($value['updated_at'])->format('d/m/Y h:ia'),
                    'deposit' => $value['deposit'],
                    'member_mobile' => $member_mobile,
                    'member_dob' => $member_dob,
                    'item' => $item,
                    'payments' => $payments,
                    'is_inclusive_gst_applied' => $value['is_inclusive_gst_applied'] ? true : false
                ];

            }

            if ($app_order_id == null && $type != 'PickupOrDelivery') {
                $query = CashRegister::where('business_id', $business_id)
                    ->where('location_id', $location_id)
                    ->with(['cash_register_transactions'])
                    ->where('user_id', $user_id);

                if (!empty($created_at)) {
                    $query->whereDate('cash_registers.created_at', $created_at);
                } else {
                    $query->whereDate('cash_registers.created_at', \Carbon::now()->format('Y-m-d 00:00:00'));
                }

                $cash_registers = $query->get();

                return ["sells" => $transaction_result, "cash_registers" => $cash_registers];
            } else {
                return ["sells" => $transaction_result];
            }
        } catch (\Exception $e) {
            DB::rollBack();

            \Log::emergency("File:" . $e->getFile() . "Line:" . $e->getLine() . "Message:" . $e->getMessage());
            $msg = __('messages.something_went_wrong');

            $output = [
                'errorMessage' => $msg
            ];

            return $output;
        }
    }

    function sales_history(Request $request)
    {
        $user_data = $request->only('business_id', 'location_id', 'token', 'user_id', 'created_at', 'type', 'days');

        if (isset($user_data['token'])) {
            $result = User::checkUserToken($user_data['token'], $user_data['user_id']);

            if ($result) {
                $user_id = $user_data['user_id'];
                $business_id = $user_data['business_id'];
                $location_id = $user_data['location_id'];
                $transaction_status = "final";
                $created_at = $user_data['created_at'];
                $type = $user_data['type'];
                $days = (isset($user_data['days']) && $user_data['days']) ? $user_data['days'] : 0;

                $all_sale_history = $this->transactionUtil->get_sales_history($user_id, $business_id, $location_id, $transaction_status, $created_at, $type, $days);

                return $all_sale_history;
            } else {
                return ["errorMessage" => 'Invalid token.'];
            }
        } else {
            return ["errorMessage" => 'Invalid token.'];
        }
    }



    // public function refund_order(Request $request)
    // {
    //     $input = $request;

    //     if(isset($input['token']))
    //     {
    //         $result = User::checkUserToken($input['token'], $input['user_id']);

    //         if($result)
    //         {
    //             try {
    //                 if (!empty($input['products'])) 
    //                 {
    //                     $user_id = $input['user_id'];
    //                     $business_id = $input['business_id'];
    //                     $transaction_id = isset($input['transaction_id']) ? $input['transaction_id'] : "";
    //                     $app_order_id = isset($input['app_order_id']) ? $input['app_order_id'] : "";

    //                     DB::beginTransaction();

    //                     $sell_return =  $this->transactionUtil->addSellReturnPOS($input, $business_id, $user_id);

    //                     //$receipt = $this->receiptContent($business_id, $sell_return->location_id, $sell_return->id);
    //                     if (!empty($sell_return) && isset($input['type']))
    //                     {
    //                         if($input['type'] == 'Pickup' || $input['type'] == 'Delivery')
    //                         {
    //                             // $transaction_payment = TransactionPayment::where('transaction_id', $transaction_id)
    //                             //         ->where('stripe_status', 'succeeded')
    //                             //         ->select('stripe_respond')
    //                             //         ->first();

    //                             $transaction_payment = TransactionPayment::where(function($query) use ($transaction_id, $app_order_id) {
    //                                     $query->when(!empty($transaction_id), function($q) use ($transaction_id) {
    //                                     $q->where('transaction_id', $transaction_id);
    //                                 })
    //                                 ->when(empty($transaction_id), function($q) use ($app_order_id) {
    //                                     $q->where('app_order_id', $app_order_id);
    //                                 });
    //                             })
    //                             ->where('stripe_status', 'succeeded')
    //                             ->select('stripe_respond')
    //                             ->first();

    //                             if($transaction_payment->stripe_respond != null)
    //                             {
    //                                 $stripe_respond = json_decode($transaction_payment->stripe_respond);
    //                                 $charge_id = $stripe_respond->id;

    //                                 $input['location_id'] = $sell_return->location_id;
    //                                 $stripe_sk = $this->get_stripe_and_lalamove_key($input);
    //                                 $stripe = new \Stripe\StripeClient(
    //                                                 $stripe_sk->original[0]['stripe_sk']
    //                                             );

    //                                 $stripe_refund_respond = $stripe->refunds->create([
    //                                     'charge' => $charge_id,
    //                                     ]);

    //                                 $stripe_refund_res = [
    //                                     'stripe_refund_respond' => json_encode($stripe_refund_respond),
    //                                     'stripe_refund_status' => $stripe_refund_respond->status
    //                                 ];

    //                                 //TransactionPayment::where('transaction_id', $transaction_id)->update($stripe_refund_res);

    //                                 TransactionPayment::where(function($query) use ($transaction_id, $app_order_id) {
    //                                     $query->when(!empty($transaction_id), function($q) use ($transaction_id) {
    //                                         $q->where('transaction_id', $transaction_id);
    //                                     })
    //                                     ->when(empty($transaction_id), function($q) use ($app_order_id) {
    //                                         $q->where('app_order_id', $app_order_id);
    //                                     });
    //                                 })
    //                                 ->update($stripe_refund_res);
    //                             }

    //                             // $transaction = Transaction::where('id', $transaction_id)
    //                             //         ->first();

    //                             $transaction = Transaction::where(function($query) use ($transaction_id, $app_order_id) {
    //                                             $query->when(!empty($transaction_id), function($q) use ($transaction_id) {
    //                                                 $q->where('id', $transaction_id);
    //                                             })
    //                                             ->when(empty($transaction_id), function($q) use ($app_order_id) {
    //                                                 $q->where('app_order_id', $app_order_id);
    //                                             });
    //                                         })
    //                                         ->first();
    //                             if($transaction->lalamove_orderRef != null)
    //                             {
    //                                 $this->cancel_lalamove_order($transaction->lalamove_orderRef, $transaction->business_id, $transaction->location_id);
    //                             }
    //                         }
    //                     }

    //                     DB::commit();

    //                     $output = [
    //                                 'msg' => 'Success'
    //                             ];
    //                 }
    //             } 
    //             catch (\Exception $e) 
    //             {
    //                 DB::rollBack();

    //                 if (get_class($e) == \App\Exceptions\PurchaseSellMismatch::class) {
    //                     $msg = $e->getMessage();
    //                 } else {
    //                     \Log::emergency("File:" . $e->getFile(). "Line:" . $e->getLine(). "Message:" . $e->getMessage());
    //                     $msg = __('messages.something_went_wrong');
    //                 }

    //                 $output = [
    //                                 'errorMessage' => $msg
    //                             ];
    //             }

    //             return $output;
    //         }
    //     }
    //     else
    //     {
    //         return["errorMessage"=>'Invalid token.'];
    //     }
    // }


    public function refund_order(Request $request)
    {
        $input = $request;

        if (isset($input['token'])) {
            $result = User::checkUserToken($input['token'], $input['user_id']);

            if ($result) {
                try {
                    if (!empty($input['products'])) {
                        $user_id = $input['user_id'];
                        $business_id = $input['business_id'];
                        $transaction_id = $input['transaction_id'];

                        DB::beginTransaction();
                        $itemCounts = DB::table('transaction_sell_lines')
                            ->select(
                                DB::raw('SUM(CASE WHEN quantity_returned = 0 AND children_type != "modifier" THEN 1 ELSE 0 END) AS total_items_count'),
                                DB::raw('SUM(CASE WHEN children_type != "modifier" THEN quantity_returned ELSE 0 END) AS total_refunded_items_count')
                            )
                            ->where('transaction_id', $input['transaction_id'])
                            ->where('quantity_returned', 0)
                            ->where('children_type', '!=', 'modifier')
                            ->first();

                        $comboItemCounts = DB::table('transaction_sell_lines')
                         ->select(
                             DB::raw('SUM(CASE WHEN quantity_returned = 0 AND children_type = "combo" THEN 1 ELSE 0 END) AS total_combo_count'),
                         )
                         ->where('transaction_id', $input['transaction_id'])
                         ->first(); 
                        $totalItemCount = $itemCounts->total_items_count - $comboItemCounts->total_combo_count;
                        $sell_return = $this->transactionUtil->addSellReturnPOS($input, $business_id, $user_id, true, $totalItemCount);

                        //$receipt = $this->receiptContent($business_id, $sell_return->location_id, $sell_return->id);
                        if (!empty($sell_return) && isset($input['type'])) {
                            if ($input['type'] == 'Pickup' || $input['type'] == 'Delivery') {
                                $transaction_payment = TransactionPayment::where('transaction_id', $transaction_id)
                                    ->where('stripe_status', 'succeeded')
                                    ->select('stripe_respond')
                                    ->first();

                                if ($transaction_payment->stripe_respond != null) {
                                    $stripe_respond = json_decode($transaction_payment->stripe_respond);
                                    $charge_id = $stripe_respond->id;

                                    $input['location_id'] = $sell_return->location_id;
                                    $stripe_sk = $this->get_stripe_and_lalamove_key($input);
                                    $stripe = new \Stripe\StripeClient(
                                        $stripe_sk->original[0]['stripe_sk']
                                    );

                                    $stripe_refund_respond = $stripe->refunds->create([
                                        'charge' => $charge_id,
                                    ]);

                                    $stripe_refund_res = [
                                        'stripe_refund_respond' => json_encode($stripe_refund_respond),
                                        'stripe_refund_status' => $stripe_refund_respond->status
                                    ];

                                    TransactionPayment::where('transaction_id', $transaction_id)->update($stripe_refund_res);
                                }

                                $transaction = Transaction::where('id', $transaction_id)
                                    ->first();
                                if ($transaction->lalamove_orderRef != null) {
                                    $this->cancel_lalamove_order($transaction->lalamove_orderRef, $transaction->business_id, $transaction->location_id);
                                }

                            }
                        }

                        DB::commit();

                        $output = [
                            'msg' => 'Success'
                        ];
                    }
                } catch (\Exception $e) {
                    DB::rollBack();

                    if (get_class($e) == \App\Exceptions\PurchaseSellMismatch::class) {
                        $msg = $e->getMessage();
                    } else {
                        \Log::emergency("File:" . $e->getFile() . "Line:" . $e->getLine() . "Message:" . $e->getMessage());
                        $msg = __('messages.something_went_wrong');
                    }

                    $output = [
                        'errorMessage' => $msg
                    ];
                }

                return $output;
            }
        } else {
            return ["errorMessage" => 'Invalid token.'];
        }
    }

    public function check_dinein_detail(Request $request)
    {
        $input = $request; //table_id, business_id, location_id, user_id

        $user_id = $input['user_id'];
        $business_id = $input['business_id'];
        $location_id = $input['location_id'];
        $table_id = $input['table_id'];
        $transaction_id = !empty($input['transaction_id']) ? $input['transaction_id'] : "";
        $queue_id = (isset($input['queue_id']) && $input['queue_id']) ? $input['queue_id'] : 0;
        $staticTableId = !empty($input['static_table_id']) ? $input['static_table_id'] : "";

        $query = Transaction::orderBy('transactions.id', 'desc')
            ->leftjoin('pos_res_tables as t', 't.transaction_id', '=', 'transactions.id')
            ->leftjoin('res_tables as z', 'z.id', '=', 't.res_table_id')
            ->where('transactions.business_id', $business_id)
            ->where('transactions.location_id', $location_id)
            //->where('t.seated', 1)
            ->whereDate('t.created_at', \Carbon::now()->format('Y-m-d 00:00:00'));

        if ($table_id) {
            $transaction_status = "draft";
            $query->where('t.res_table_id', $table_id);
        }elseif ($queue_id) {
            $transaction_status = "draft";
            $query->where('t.manage_queue_id', $queue_id);
        }elseif ($staticTableId) {
            $transaction_status = "draft";
            $query->where('t.transaction_id', $transaction_id);
        }elseif ($transaction_id) {
            $transaction_status = "final";
            $query->where('t.transaction_id', $transaction_id);
        } else {
            return ["sells" => []];
        }
  
        // ->where('transactions.status', 'draft')
        // ->where('transactions.payment_status', 'due')
        $table_query = $query->select('t.res_table_id', 'pax', 'z.name', 'transactions.id')
            ->first();

        if (!empty($table_query)) {
            //return $table_query;
            $all_each_sale_history = $this->get_sale_history($user_id, $business_id, $location_id, $transaction_status, "", "Dinein", $table_query->id);
            return $all_each_sale_history;
        } elseif(isset($staticTableId)){
            $all_each_sale_history = $this->get_sale_history($user_id, $business_id, $location_id, $transaction_status, "", "Dinein", $transaction_id);
            return $all_each_sale_history;
        } else {
            $all_each_sale_history = [];
            return ["sells" => $all_each_sale_history];
        }
    }


    public function check_takeaway_order(Request $request)
    {
        $input = $request; //table_id, business_id, location_id

        $user_id = !empty($input['user_id']) ? $input['user_id'] : null;
        $business_id = $input['business_id'];
        $location_id = $input['location_id'];
        $transaction_id = !empty($input['transaction_id']) ? $input['transaction_id'] : null;

        if (!empty($transaction_id)) {
            $transaction_status = "draft";
        } else {
            return ["sells" => []];
        }

        if (!empty($transaction_id)) {
            $all_each_sale_history = $this->get_sale_history($user_id, $business_id, $location_id, $transaction_status, "", "Takeaway", $transaction_id);
            return $all_each_sale_history;
        } else {
            $all_each_sale_history = [];
            return ["sells" => $all_each_sale_history];
        }
    }

    public function get_stripe_and_lalamove_key(Request $request)
    {
        $result = BusinessLocation::where('business_id', $request['business_id'])
            ->where('id', $request['location_id'])
            ->select('stripe_pk', 'stripe_sk', 'lalamove_pk', 'lalamove_sk')
            ->get()
            ->toArray();

        return $this->respond($result);
    }

    public function check_driver_details($lalamove_orderRef, $lalamove_driver_id, $business_id, $location_id)
    {
        //$lalamoveBaseURL = "https://rest.sandbox.lalamove.com";
        $lalamoveBaseURL = "https://rest.lalamove.com";

        // $key = "99dedb31c79c8aa20d75662866f48ce5"; // put your lalamove API key here
        // $secret = "h0SMij8vAT+aaGAaKGwRJxXNjI7Pw+Ie+DcfjzGq7VHQKtzsI1JnPHDHB2+zV6ru"; // put your lalamove API secret here

        $lalamove_result = BusinessLocation::where('business_id', $business_id)
            ->where('id', $location_id)
            ->select('lalamove_pk', 'lalamove_sk')
            ->get()
            ->toArray();

        $key = $lalamove_result[0]['lalamove_pk']; // put your lalamove API key here
        $secret = $lalamove_result[0]['lalamove_sk']; // put your lalamove API secret here

        $time = time() * 1000;
        $method = 'GET';
        $path = '/v2/orders/' . $lalamove_orderRef . '/drivers/' . $lalamove_driver_id;
        $region = 'SG_SIN';

        $rawSignature = "{$time}\r\n{$method}\r\n{$path}\r\n\r\n";
        $signature = hash_hmac("sha256", $rawSignature, $secret);
        $startTime = microtime(true);
        $token = $key . ':' . $time . ':' . $signature;

        $curl = curl_init();
        curl_setopt_array(
            $curl,
            array(
                CURLOPT_URL => $lalamoveBaseURL . $path,
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_ENCODING => '',
                CURLOPT_MAXREDIRS => 10,
                CURLOPT_TIMEOUT => 3,
                CURLOPT_FOLLOWLOCATION => true,
                CURLOPT_HEADER => false, // Enable this option if you want to see what headers Lalamove API returning in response
                CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
                CURLOPT_CUSTOMREQUEST => 'GET',
                //CURLOPT_POSTFIELDS => $body,
                CURLOPT_HTTPHEADER => array(
                    "Content-type: application/json; charset=utf-8",
                    "Authorization: hmac " . $token, // A unique Signature Hash has to be generated for EVERY API call at the time of making such call.
                    "Accept: application/json",
                    "X-LLM-Market: {$region}" // Please note to which city are you trying to make API call
                ),
            )
        );

        $response = curl_exec($curl);
        $http_code = curl_getinfo($curl, CURLINFO_HTTP_CODE);
        curl_close($curl);

        return $response;
    }

    public function cancel_lalamove_order($lalamove_orderRef, $business_id, $location_id)
    {
        //$lalamoveBaseURL = "https://rest.sandbox.lalamove.com";
        $lalamoveBaseURL = "https://rest.lalamove.com";

        // $key = "99dedb31c79c8aa20d75662866f48ce5"; // put your lalamove API key here
        // $secret = "h0SMij8vAT+aaGAaKGwRJxXNjI7Pw+Ie+DcfjzGq7VHQKtzsI1JnPHDHB2+zV6ru"; // put your lalamove API secret here
        $lalamove_result = BusinessLocation::where('business_id', $business_id)
            ->where('id', $location_id)
            ->select('lalamove_pk', 'lalamove_sk')
            ->get()
            ->toArray();

        $key = $lalamove_result[0]['lalamove_pk']; // put your lalamove API key here
        $secret = $lalamove_result[0]['lalamove_sk']; // put your lalamove API secret here

        $time = time() * 1000;
        $method = 'PUT';
        $path = '/v2/orders/' . $lalamove_orderRef . '/cancel';
        $region = 'SG_SIN';

        $body = '{}';

        $rawSignature = "{$time}\r\n{$method}\r\n{$path}\r\n\r\n{$body}";
        $signature = hash_hmac("sha256", $rawSignature, $secret);
        $startTime = microtime(true);
        $token = $key . ':' . $time . ':' . $signature;

        $curl = curl_init();
        curl_setopt_array(
            $curl,
            array(
                CURLOPT_URL => $lalamoveBaseURL . $path,
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_ENCODING => '',
                CURLOPT_MAXREDIRS => 10,
                CURLOPT_TIMEOUT => 3,
                CURLOPT_FOLLOWLOCATION => true,
                CURLOPT_HEADER => false, // Enable this option if you want to see what headers Lalamove API returning in response
                CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
                CURLOPT_CUSTOMREQUEST => 'PUT',
                CURLOPT_POSTFIELDS => $body,
                CURLOPT_HTTPHEADER => array(
                    "Content-type: application/json; charset=utf-8",
                    "Authorization: hmac " . $token, // A unique Signature Hash has to be generated for EVERY API call at the time of making such call.
                    "Accept: application/json",
                    "X-LLM-Market: {$region}" // Please note to which city are you trying to make API call
                ),
            )
        );

        $response = curl_exec($curl);
        $http_code = curl_getinfo($curl, CURLINFO_HTTP_CODE);
        curl_close($curl);

        return $response;
    }

    function view_dinein_order_bulk(Request $request)
    {
        $inputRequest = $request;

        if (isset($inputRequest['token'])) {

            $result = User::checkUserToken($inputRequest['token'], $inputRequest['user_id']);

            if ($result) {

                try {
                    if (isset($inputRequest['orders']) && !empty($inputRequest['orders'])) {
                        $orders = $inputRequest["orders"];
                        $all_each_sale_history_orders = [];
                        foreach ($orders as $key => $input) {
                            $id = !empty($input['transaction_id']) ? $input['transaction_id'] : "";
                            $business_id = $inputRequest['business_id'];
                            $location_id = $inputRequest['location_id'];
                            $transaction_status = $input['status'];
                            $app_order_id = !empty($input['app_order_id']) ? $input['app_order_id'] : "";
                            $order_type = !empty($inputRequest['order_type']) ? $inputRequest['order_type'] : "Dinein";

                            if (!empty($app_order_id)) {
                                $all_each_sale_history = $this->get_sale_history2($inputRequest['user_id'], $business_id, $location_id, $transaction_status, "", $order_type, $id, $app_order_id);
                            } else {
                                $all_each_sale_history = $this->get_sale_history($inputRequest['user_id'], $business_id, $location_id, $transaction_status, "", $order_type, $id, $app_order_id);
                            }

                            $all_each_sale_history_orders[$id] = $all_each_sale_history;
                        }
                        return $all_each_sale_history_orders;
                    }
                } catch (\Exception $e) {
                    DB::rollBack();

                    if (get_class($e) == \App\Exceptions\PurchaseSellMismatch::class) {
                        $msg = $e->getMessage();
                    } else {
                        \Log::emergency("File:" . $e->getFile() . "Line:" . $e->getLine() . "Message:" . $e->getMessage());
                        $msg = __('messages.something_went_wrong');
                    }

                    return [
                        'errorMessage' => $msg
                    ];
                }
            } else {
                return ["errorMessage" => 'Invalid token.'];
            }
        } else {
            return ["errorMessage" => 'Invalid token.'];
        }
    }

    function save_order_bulk(Request $request)
    {
        $input = $request;

        if (isset($input['token'])) {
            $result = User::checkUserToken($input['token'], $input['user_id']);

            if ($result) {
                $output = $this->saveOrderBulk($input);
                return $output;
            } else {
                return ["errorMessage" => 'Invalid token.'];
            }
        } else {
            return ["errorMessage" => 'Invalid token.'];
        }
    }

    function saveOrderBulk($inputRequest)
    {
        try {
            if (isset($inputRequest['orders']) && !empty($inputRequest['orders'])) {
                $orders = $inputRequest["orders"];

                $responseOutput = [];
                foreach ($orders as $key => $input) {

                    $is_direct_sale = false;

                    if (!empty($input['products'])) {

                        $business_id = $inputRequest['business_id'];
                        $user_id = $inputRequest['user_id'];
                        $app_order_id = isset($input['app_order_id']) ? $input['app_order_id'] : "";
                        $input['location_id'] = $inputRequest['location_id'];
                        $input['terminal_id'] = $inputRequest['terminal_id'];

                        //$app_item_line_id = isset($input['products'][0]['app_item_line_id']) ? $input['products'][0]['app_item_line_id'] : "";

                        if (!empty($input['products'][0]['modifier_app_ids'])) {
                            $modifiers_app_ids = array_column($input['products'], 'modifier_app_ids');
                        } else {
                            $modifiers_app_ids = "";
                        }

                        $discount_amount = (isset($input["discount_amount"]) && $input["discount_amount"]) ? $input["discount_amount"] : 0;
                        $discount = [
                            'discount_type' => $input['discount_type'],
                            'discount_amount' => $discount_amount
                        ];

                        if (isset($input['delivery_charges'])) {
                            $delivery_charges = $input['delivery_charges'];
                        } else {
                            $delivery_charges = 0;
                        }

                        $invoice_total = $this->productUtil->newCalculateInvoiceTotal($input['products'], $input['tax_rate_id'], $discount, $input['service_charges'], true, $delivery_charges, $input['is_inclusive_gst_applied']);
                        //return $invoice_total;
                        DB::beginTransaction();

                        if ($input['type_for_api'] == "Pickup" || $input['type_for_api'] == "Delivery") {
                            if (strtolower($input['payment'][0]['method']) == "card" && strtolower($input['payment'][0]['card_type']) != "paynow") {
                                $stripeRespond = $this->stripePost($input);
                            }
                        }

                        if (empty($input['transaction_date'])) {
                            $input['transaction_date'] = \Carbon::now();
                        } else {
                            $input['transaction_date'] = $this->productUtil->uf_date($input['transaction_date'], true);
                        }

                        $input['is_suspend'] = isset($input['is_suspend']) && 1 == $input['is_suspend'] ? 1 : 0;
                        if ($input['is_suspend']) {
                            $input['sale_note'] = !empty($input['additional_notes']) ? $input['additional_notes'] : null;
                        }
                        //transactions table
                        $transaction = $this->transactionUtil->createSellTransaction($business_id, $input, $invoice_total, $user_id);
                        //transaction_sell_lines table
                        $business_details = $this->businessUtil->getDetails($business_id);
                        if (in_array("modifiers", $business_details->enabled_modules)) {
                            $isModuleEnabled = true;
                        } else {
                            $isModuleEnabled = false;
                        }
                        $this->transactionUtil->createOrUpdateSellLines($transaction, $input['products'], $input['location_id'], $app_order_id, $modifiers_app_ids, $user_id, false, null, [], true, $isModuleEnabled);

                        // if (!$is_direct_sale) {
                        //     //Add change return
                        //     $change_return = $this->dummyPaymentLine;
                        //     $change_return['amount'] = $input['change_return'];
                        //     $change_return['is_return'] = 1;
                        //     $input['payment'][] = $change_return;
                        // }

                        $is_credit_sale = isset($input['is_credit_sale']) && $input['is_credit_sale'] == 1 ? true : false;
                        //transaction_payments table
                        if (!$transaction->is_suspend && !empty($input['payment']) && !$is_credit_sale) {
                            $transaction_payment = $this->transactionUtil->createOrUpdatePaymentLines($transaction, $input['payment'], $app_order_id, $business_id, $user_id);
                        }

                        // $is_nfc_payment = !empty($input['is_nfc_payment']) ? true : false;

                        // if ($is_nfc_payment === true) {
                        //     $debitOrder = $this->transactionUtil->debitOrderBalance($input);
                        //     if ($debitOrder == false) {
                        //         return response()->json(['errorMessage' => 'Insufficient NFC Card Balance.'], 200);
                        //     }
                        // }

                        //Check for final and do some processing.
                        if ($input['status'] == 'final' && $input['type_for_api'] != "Pickup" && $input['type_for_api'] != "Delivery") {
                            //update product stock
                            // foreach ($input['products'] as $product) {
                            //     $decrease_qty = $this->productUtil
                            //                 ->num_uf($product['quantity']);
                            //     if (!empty($product['base_unit_multiplier'])) {
                            //         $decrease_qty = $decrease_qty * $product['base_unit_multiplier'];
                            //     }

                            //     if ($product['enable_stock']) {
                            //         $this->productUtil->decreaseProductQuantity(
                            //             $product['product_id'],
                            //             $product['variation_id'],
                            //             $input['location_id'],
                            //             $decrease_qty
                            //         );
                            //     }

                            //     if ($product['product_type'] == 'combo') {
                            //         //Decrease quantity of combo as well.
                            //         $this->productUtil
                            //             ->decreaseProductQuantityCombo(
                            //                 $product['combo'],
                            //                 $input['location_id']
                            //             );
                            //     }
                            // }

                            //Add payments to Cash Register
                            if (!$is_direct_sale && !$transaction->is_suspend && !empty($input['payment']) && !$is_credit_sale) {
                                //cash_register_transactions table
                                $this->cashRegisterUtil->addSellPayments($transaction, $input['payment'], $inputRequest['user_id']);
                            }

                            // $is_nfc_payment = !empty($input['is_nfc_payment']) ? true : false;

                            // if ($is_nfc_payment === true) {
                            //     $debitOrder = $this->transactionUtil->debitOrderBalance($input);
                            //     if ($debitOrder == false) {
                            //         return response()->json(['errorMessage' => 'Insufficient NFC Card Balance.'], 200);
                            //     }
                            // }
                        }

                        //Update payment status
                        $payment_status = $this->transactionUtil->updatePaymentStatus($transaction->id, $transaction->final_total);

                        //$transaction->payment_status = $payment_status;

                        if ($input['type_for_api'] == "Pickup" || $input['type_for_api'] == "Delivery") {
                            //update contact info
                            if (strtolower($input['payment'][0]['method']) == "card") {
                                $contact = Contact::where('id', $input['contact_id'])->firstOrFail();
                                $update_contact_data = [
                                    'first_name' => !empty($input['first_name']) ? $input['first_name'] : null,
                                    'last_name' => !empty($input['last_name']) ? $input['last_name'] : null,
                                    'address_line_1' => !empty($input['billing_address']) ? $input['billing_address'] : null,
                                    'city' => !empty($input['city']) ? $input['city'] : null,
                                    'zip_code' => !empty($input['zip_code']) ? $input['zip_code'] : null,
                                    'country' => !empty($input['country']) ? $input['country'] : null,
                                    'mobile' => !empty($input['phone']) ? $input['phone'] : null,
                                    'email' => !empty($input['email']) ? $input['email'] : null,
                                    'accept_term_and_cond' => isset($input['accept_term_and_cond']) ? $input['accept_term_and_cond'] : 0,
                                    'occasional_offers' => isset($input['occasional_offers']) ? $input['occasional_offers'] : 0
                                ];
                                $contact->fill($update_contact_data);
                                $contact->update();
                            }

                            //update user info
                            // $user = User::where('id', $input['user_id'])->firstOrFail();
                            // $update_user_data = [
                            //     'first_name' => !empty($input['first_name']) ? $input['first_name'] : null,
                            //     'last_name' => !empty($input['last_name']) ? $input['last_name'] : null,
                            //     'gender' => !empty($input['gender']) ? $input['gender'] : null,
                            //     //'contact_number' => !empty($input['phone']) ? $input['phone'] : null
                            // ];
                            // $user->fill($update_user_data);
                            // $user->update();

                            //save_delivery_details
                            $save_delivery_details = [
                                'transaction_id' => $transaction->id,
                                'd_date' => !empty($input['d_date']) ? $input['d_date'] : null,
                                'd_time' => !empty($input['d_time']) ? $input['d_time'] : null,
                            ];

                            if (!empty($input['d_address'])) {
                                $save_delivery_details['d_address'] = $input['d_address'];
                            }

                            if (!empty($input['outlet'])) {
                                $save_delivery_details['outlet'] = $input['outlet'];
                            }

                            $delivery_details = DeliveryDetails::create($save_delivery_details);

                            //$stripeRespond = $this->stripePost($input);

                            if (strtolower($input['payment'][0]['method']) == "card" && strtolower($input['payment'][0]['card_type']) != "paynow") {
                                $transaction_payment = TransactionPayment::where('transaction_id', $transaction->id)->first();
                                $transaction_payment->stripe_respond = json_encode($stripeRespond['data']['respond']);
                                $transaction_payment->stripe_status = $stripeRespond['data']['status'];
                                $transaction_payment->save();
                            }
                        }

                        DB::commit();

                        if ($input['type_for_api'] == "Pickup" || $input['type_for_api'] == "Delivery") {
                            $order_sent = Carbon::createFromFormat('Y-m-d H:i:s', $transaction->created_at)->format('H:i A');
                            $temp_output = ['transaction_id' => $transaction->id, 'ref_no' => $transaction->ref_no, 'order_no' => $transaction->order_no, 'order_sent' => $order_sent];
                            $responseOutput[$transaction->id] = $temp_output;
                        }
                        //return($input['transaction_date']);
                    }
                }
                $output = ['msg' => "Sale orders are added.", "data" => $responseOutput];
            } else {
                DB::rollBack();
                $output = [
                    'errorMessage' => trans("messages.something_went_wrong")
                ];
            }
        } catch (\Exception $e) {
            DB::rollBack();
            \Log::emergency("File:" . $e->getFile() . "Line:" . $e->getLine() . "Message:" . $e->getMessage());
            $msg = trans("messages.something_went_wrong");

            if (get_class($e) == \App\Exceptions\PurchaseSellMismatch::class) {
                $msg = $e->getMessage();
            }
            if (get_class($e) == \App\Exceptions\AdvanceBalanceNotAvailable::class) {
                $msg = $e->getMessage();
            }

            $output = [
                'errorMessage' => $msg
            ];
        }

        return $output;
    }

    public function refund_order_bulk(Request $request)
    {
        $inputRequest = $request;

        if (isset($inputRequest['token'])) {
            $result = User::checkUserToken($inputRequest['token'], $inputRequest['user_id']);

            if ($result) {
                try {

                    $user_id = $inputRequest['user_id'];
                    $business_id = $inputRequest['business_id'];
                    $business_id = $inputRequest['business_id'];
                    $business_location_id = $inputRequest['business_location_id'];
                    $location_id = $inputRequest['location_id'];

                    DB::beginTransaction();

                    if (isset($inputRequest['refund_orders']) && $inputRequest['refund_orders'] && !empty($inputRequest['refund_orders'])) {
                        foreach ($inputRequest['refund_orders'] as $key => $input) {

                            $input['user_id'] = $user_id;
                            $input['business_id'] = $business_id;
                            $input['business_location_id'] = $business_location_id;
                            $input['location_id'] = $location_id;

                            if (!empty($input['products'])) {

                                $transaction_id = !empty($input['transaction_id']) ? $input['transaction_id'] : "";
                                $app_order_id = !empty($input['app_order_id']) ? $input['app_order_id'] : "";

                                $sell_return = $this->transactionUtil->addSellReturnPOS($input, $business_id, $user_id);

                                //$receipt = $this->receiptContent($business_id, $sell_return->location_id, $sell_return->id);
                                if (!empty($sell_return) && isset($input['type'])) {
                                    if ($input['type'] == 'Pickup' || $input['type'] == 'Delivery') {
                                        $transaction_payment = TransactionPayment::where(function ($query) use ($transaction_id) {
                                            if (!isset($transaction_id) || $transaction_id != null) {
                                                $query->where('app_order_id', $app_order_id);
                                            } else {
                                                $query->where('transaction_id', $transaction_id);
                                            }
                                        })
                                            ->where('stripe_status', 'succeeded')
                                            ->select('stripe_respond')
                                            ->first();

                                        if ($transaction_payment->stripe_respond != null) {
                                            $stripe_respond = json_decode($transaction_payment->stripe_respond);
                                            $charge_id = $stripe_respond->id;

                                            $input['location_id'] = $sell_return->location_id;
                                            $stripe_sk = $this->get_stripe_and_lalamove_key($input);
                                            $stripe = new \Stripe\StripeClient(
                                                $stripe_sk->original[0]['stripe_sk']
                                            );

                                            $stripe_refund_respond = $stripe->refunds->create([
                                                'charge' => $charge_id,
                                            ]);

                                            $stripe_refund_res = [
                                                'stripe_refund_respond' => json_encode($stripe_refund_respond),
                                                'stripe_refund_status' => $stripe_refund_respond->status
                                            ];

                                            TransactionPayment::where('transaction_id', $transaction_id)->update($stripe_refund_res);
                                        }

                                        $transaction = Transaction::where('id', $transaction_id)
                                            ->first();
                                        if ($transaction->lalamove_orderRef != null) {
                                            $this->cancel_lalamove_order($transaction->lalamove_orderRef, $transaction->business_id, $transaction->location_id);
                                        }
                                    }
                                }
                            }
                        }

                        DB::commit();

                        $output = [
                            'msg' => 'Success'
                        ];
                    } else {
                        $output = [
                            'errorMessage' => 'There is no orders for refund'
                        ];
                    }
                } catch (\Exception $e) {
                    DB::rollBack();

                    if (get_class($e) == \App\Exceptions\PurchaseSellMismatch::class) {
                        $msg = $e->getMessage();
                    } else {
                        \Log::emergency("File:" . $e->getFile() . "Line:" . $e->getLine() . "Message:" . $e->getMessage());
                        $msg = __('messages.something_went_wrong');
                    }

                    $output = [
                        'errorMessage' => $msg
                    ];
                }

                return $output;
            }
        } else {
            return ["errorMessage" => 'Invalid token.'];
        }
    }

    function view_order_invoice(Request $request)
    {
        try {

            $request->validate([
                'transaction_id' => 'required'
            ]);
            $all_each_sale_history = $this->get_invoice_history($request['transaction_id']);
            return $all_each_sale_history;
        } catch (\Exception $e) {
            DB::rollBack();
            if (get_class($e) == \App\Exceptions\PurchaseSellMismatch::class) {
                $msg = $e->getMessage();
            } else {
                \Log::emergency("File:" . $e->getFile() . "Line:" . $e->getLine() . "Message:" . $e->getMessage());
                $msg = __('messages.something_went_wrong');
            }
            return [
                'errorMessage' => $msg
            ];
        }
    }

    function get_invoice_history($transaction_id)
    {
        try {
            $query = Transaction::leftjoin('transaction_payments as t', 't.transaction_id', '=', 'transactions.id')
                ->leftjoin('variations as w', 'w.product_id', '=', 'transactions.additional_discount_method')
                ->leftjoin('tax_rates as z', 'z.id', '=', 'transactions.tax_id')
                ->leftJoin('transactions AS SR', 'transactions.id', '=', 'SR.return_parent_id')
                ->with('sell_lines.variations.product.category')
                ->with('payment_lines')
                ->with('void_items.modifiers')
                ->where('transactions.type', 'sell')
                ->where('transactions.is_direct_sale', 0);

            if ($transaction_id != null) {
                $query->where('transactions.id', $transaction_id);
            }

            $query->orderBy('transactions.created_at', 'desc')
                ->groupBy('transactions.id');

            $transactions = $query->select('transactions.*', 't.amount as received_amount', 't.method', 't.card_type', 't.last_4_card_digits', 'w.profit_percent', 'z.amount as tax_rate_amount', DB::raw('COUNT(SR.id) as return_exists'), 'SR.refund_all')
                ->with(['contact'])
                ->get();

            $business_id = null;
            $business_location_id = null;
            if ($transactions && count($transactions)) {
                $business_id = $transactions[0]->business_id;
                $business_location_id = $transactions[0]->location_id;
            }

            $retail_gst = 0;
            $business_tax_rates = TaxRate::where('business_id', $business_id)
                ->get()
                ->toArray();

            for ($i = 0; $i < count($business_tax_rates); $i++) {
                if (strtolower($business_tax_rates[$i]['name']) == 'gst') {
                    $retail_gst = $business_tax_rates[$i]['amount'];
                }
            }

            $businessUtil = new BusinessUtil();
            $business = $businessUtil->getDetails($business_id);
            $pos_settings = json_decode($business->pos_settings);

            $transaction_result = [];
            $total_dont_have_line_discount_amt = 0;
            foreach ($transactions as $key => $value) {
                $item = [];
                $payments = [];
                $final_total_for_single_item = 0;
                $final_total_line_discount_amount = 0;
                $service_charge_amount = 0;
                $increment = 0;

                 $sellArray1 = $value['sell_lines'];
                $finalItems = [];
                foreach ($sellArray1->toArray() as $key => $item_sellLine) {
                    if ($item_sellLine['parent_sell_line_id'] == null) { 
                        $mainItem = $item_sellLine;
                        // dd($mainItem);
                        $mainItemPrice = $mainItem['unit_price_before_discount'];
                        foreach ($sellArray1->toArray() as $modifier) {
                            if (!empty($modifier['parent_sell_line_id']) && $modifier['parent_sell_line_id'] == $mainItem['id'] && $item_sellLine["change_price"] == 0 && $modifier["children_type"] == "modifier") {
                                $mainItemPrice += $modifier['unit_price_before_discount']; // Add the modifier price to the main product price
                            }
                        }
                        // Update the main product price
                        $mainItem['unit_price_before_discount'] = $mainItemPrice;
                        // Add the updated main item to the final result array
                        $finalItems[] = $mainItem;
                    }
                }        
                $dineService  = $this->calculateItemTotalForDineIn($finalItems, $value['type_for_api'], $value['discount_amount'], $value['discount_type'], $value['rp_redeemed_amount'], $value['id']);

                foreach ($value['sell_lines'] as $sellLinesKey => $sellLinesValue) {

                    $total_line_discount_amount = 0;
                    if ($sellLinesValue["parent_sell_line_id"] == null && $sellLinesValue["transaction_id"] == $value['id']) {
                        $adons = [];
                        $combo_adons = [];
                        $total_for_single_item = 0;
                        foreach ($value['sell_lines'] as $sellLinesKey1 => $sellLinesValue1) {
                            if ($sellLinesValue1["parent_sell_line_id"] != null && $sellLinesValue1["parent_sell_line_id"] == $sellLinesValue['id'] && $sellLinesValue1["children_type"] == "modifier") {
                                if (isset($sellLinesValue1['variations']) && !empty($sellLinesValue1['variations'])) {
                                    $adons[] = [
                                        'id' => $sellLinesValue1['variations']->id,
                                        'modifier_set_id' => $sellLinesValue1['variations']->product_id,
                                        'modifier_sell_line_id' => $sellLinesValue1['id'],
                                        'name' => $sellLinesValue1['variations']->name,
                                        'quantity' => $sellLinesValue1["quantity"],
                                        'amount' => $sellLinesValue1['unit_price_before_discount'], //unit_price_before_discount
                                        'not_for_receipt' => $sellLinesValue1['variations']->product->not_for_receipt,
                                        'modifier_app_id' => $sellLinesValue1['modifier_app_ids'],
                                        'name_in_second_language' => $sellLinesValue1['variations']->name_in_second_language,
                                        'short_hand_name' => $sellLinesValue1['variations']->short_hand_name
                                    ];
                                }
                                if ($sellLinesValue["quantity_returned"] == "0.0000" && $sellLinesValue["change_price"] == 0) {
                                    //total modifier price
                                    $total_for_single_item = $total_for_single_item + $sellLinesValue1['unit_price_before_discount'];
                                }
                            } else if ($sellLinesValue1["parent_sell_line_id"] != null && $sellLinesValue1["parent_sell_line_id"] == $sellLinesValue['id'] && $sellLinesValue1["children_type"] == "combo") {
                                $combo_adons[] = [
                                    'transaction_sell_lines_id' => $sellLinesValue1['id'],
                                    'product_id' => $sellLinesValue1['product_id'],
                                    'variation_id' => $sellLinesValue1['variation_id'],
                                    'quantity' => $sellLinesValue1['quantity'],
                                ];
                            }
                        }

                        $sub_unit_id = !empty($sellLinesValue['sub_unit_id']) ? $sellLinesValue['sub_unit_id'] : "";

                        $sub_unit_multiplier = UNIT::where('id', $sub_unit_id)->get();
                        $base_unit_multiplier = !empty($sub_unit_multiplier[0]['base_unit_multiplier']) ? $sub_unit_multiplier[0]['base_unit_multiplier'] : 1;

                        //main item price + modifier price
                        if ($sellLinesValue['weight'] > 0) {

                            $total_for_single_item = ($sellLinesValue['unit_price_before_discount'] + $total_for_single_item) * $sellLinesValue["quantity"];
                        } else {
                            $total_for_single_item = ($sellLinesValue['unit_price_before_discount'] + $total_for_single_item) * $sellLinesValue["quantity"];
                        }

                        if ($increment == 0) {
                            $total_dont_have_line_discount_amt = 0;
                        }

                        if ($sellLinesValue["quantity_returned"] == "0.0000") {
                            $final_total_for_single_item += $total_for_single_item;
                            //calculate if line item has line discount
                            if ($sellLinesValue['line_discount_type'] == "fixed") {
                                $total_line_discount_amount += $sellLinesValue['line_discount_amount'];
                            } else if ($sellLinesValue['line_discount_type'] == "percentage") {
                                $total_line_discount_amount = (($sellLinesValue['line_discount_amount'] / 100) * $total_for_single_item) + $total_line_discount_amount;
                            }
                            //calculate final total line discount amount
                            $final_total_line_discount_amount += $total_line_discount_amount;
                            //total if item dont have line discount amount
                            if ($total_line_discount_amount == 0) {
                                $total_dont_have_line_discount_amt += $total_for_single_item;
                            }
                        }

                        if ($sellLinesValue['added_by_qr'] == 0) {
                            $sellLinesValue['added_by_qr'] = 'false';
                        } else {
                            $sellLinesValue['added_by_qr'] = 'true';
                        }

                        $short_code = null;
                        if (isset($sellLinesValue['variations']->product) && isset($sellLinesValue['variations']->product->category) && isset($sellLinesValue['variations']->product->category->short_code)) {
                            $short_code = $sellLinesValue['variations']->product->category->short_code;
                        }

                        $combo_products = [];
                        $variations = Product::where('business_id', $business_id)
                            ->with(['variations'])
                            ->find($sellLinesValue['product_id']);
                        if (isset($variations['variations']) && $variations['variations'] && count($variations['variations'])) {
                            foreach ($variations['variations'] as $key => $each) {
                                $variation = json_decode($each);
                                if ($variation->combo_variations && count($variation->combo_variations)) {
                                    foreach ($variation->combo_variations as $key => $combo_variation) {
                                        $combo_product = Variation::where('variations.id', $combo_variation->variation_id)
                                            ->join('products AS p', 'variations.product_id', '=', 'p.id')
                                            ->select(['p.*', 'variations.name as variation_name'])
                                            ->first();
                                        $combo_product['quantity'] = round($combo_variation->quantity, 2);     
                                        $combo_products[] = $combo_product;
                                    }
                                }
                            }
                        }

                        $sub_unit_id = !empty($sellLinesValue['variations']->product->sub_unit_ids[0]) ? $sellLinesValue['variations']->product->sub_unit_ids[0] : "";

                        $sub_unit_multiplier = UNIT::where('id', $sub_unit_id)->get();
                        $base_unit_multiplier = !empty($sub_unit_multiplier[0]['base_unit_multiplier']) ? $sub_unit_multiplier[0]['base_unit_multiplier'] : 1;

                        $item[] = [
                            'transaction_sell_line_id' => $sellLinesValue['id'],
                            'category_id' => !empty($sellLinesValue['variations']->product->category_id) ? $sellLinesValue['variations']->product->category_id : null,
                            'name' => $sellLinesValue['variations']->product->name,
                            'short_code' => $short_code,
                            'quantity' => $sellLinesValue['quantity'],
                            'quantity_returned' => $sellLinesValue["quantity_returned"],
                            'quantity_returned_note' => $sellLinesValue["quantity_returned_note"],
                            'unit_id' => $sellLinesValue['variations']->product->unit_id,
                            'amount' => $sellLinesValue['unit_price_before_discount'],
                            'total_before_tax' => $value['total_before_tax'],
                            'tax_amount' => $value['tax_amount'],
                            'line_discount_type' => $sellLinesValue['line_discount_type'],
                            'line_discount_amount' => $sellLinesValue['line_discount_amount'],
                            'product_id' => $sellLinesValue['product_id'],
                            'variation_id' => $sellLinesValue['variation_id'],
                            'weight' => $sellLinesValue["weight"],
                            'total_line_discount_amount' => $total_line_discount_amount,
                            'total_for_single_item' => $total_for_single_item,
                            'serve_later_quantity' => $sellLinesValue["serve_later_quantity"],
                            'adons' => $adons,
                            'printed' => $sellLinesValue["printed"],
                            'sell_line_note' => $sellLinesValue["sell_line_note"],
                            'change_price' => $sellLinesValue["change_price"],
                            'combo_variations' => $combo_adons,
                            'app_order_id' => $value['app_order_id'],
                            'app_item_line_id' => $sellLinesValue["app_item_line_id"],
                            'user_id' => $sellLinesValue['user_id'],
                            'added_by_qr' => $sellLinesValue['added_by_qr'],
                            'tag' => !empty($sellLinesValue['tag']) ? $sellLinesValue['tag'] : "",
                            'kitchen_shorthand' => $sellLinesValue['variations']->product->kitchen_shorthand,
                            'name_in_second_language' => $sellLinesValue['variations']->product->name_in_second_language,
                            'show_combo_products' => $sellLinesValue['variations']->product->show_combo_products ? true : false,
                            'combo_products' => $combo_products,
                            'parent_product_group_id' => !empty($sellLinesValue['parent_product_group_id']) ? $sellLinesValue['parent_product_group_id'] : "",
                            'combo_products_category_id' => $sellLinesValue['variations']->product->combo_products_category_id
                        ];

                        $increment++;
                    }
                }

                if ($value['discount_type'] == "fixed") {
                    $discount_amount = $value['discount_amount'] + $final_total_line_discount_amount;
                } else if ($value['discount_type'] == "percentage") {
                    $discount_amount = ($value['discount_amount'] * $total_dont_have_line_discount_amt) + $final_total_line_discount_amount;
                }

                //calculate service charges
                // $service_charge_amount = ($final_total_for_single_item - $discount_amount) * $value['service_charges'];
                $service_charge_amount = $dineService * $value['service_charges'];

                if ($value['delivery_charges'] != 0) {
                    //calculate tax
                    $tax_amount = 0;
                    if ($value['tax_id'] != null) {
                        if ($value["is_inclusive_gst_applied"])
                            $tax_amount = (($final_total_for_single_item - $discount_amount) / (100 + $value['tax_rate_amount'])) * $value['tax_rate_amount'];
                        else
                            $tax_amount = ($value['tax_rate_amount'] / 100) * ($final_total_for_single_item - $discount_amount);
                    }

                    if ($value['is_inclusive_gst_applied'])
                        $final_total = $final_total_for_single_item + $value['delivery_charges'];
                    else
                        $final_total = $final_total_for_single_item + $tax_amount + $value['delivery_charges'];
                } else {
                    //calculate tax
                    $tax_amount = 0;
                    if ($value['type_for_api'] == 'Retail') {
                        $tax_amount = ($final_total_for_single_item + $service_charge_amount - $discount_amount) - (($final_total_for_single_item + $service_charge_amount - $discount_amount) / (1 + ($retail_gst / 100)));

                        $final_total = round($final_total_for_single_item, 2) + 0 + round($service_charge_amount, 2) - round($discount_amount, 2);
                    } else {
                        if ($value['tax_id'] != null) {
                            if ($value["is_inclusive_gst_applied"])
                                $tax_amount = (($final_total_for_single_item + $service_charge_amount - $discount_amount) / (100 + $value['tax_rate_amount'])) * $value['tax_rate_amount'];
                            else
                                $tax_amount = ($value['tax_rate_amount'] / 100) * ($final_total_for_single_item + $service_charge_amount - $discount_amount);
                        }

                        if ($value['is_inclusive_gst_applied'])
                            $final_total = round($final_total_for_single_item, 2) + round($service_charge_amount, 2) - round($discount_amount, 2);
                        else
                            $final_total = round($final_total_for_single_item, 2) + round($tax_amount, 2) + round($service_charge_amount, 2) - round($discount_amount, 2);
                    }
                }

                $amount_rounding_method = $pos_settings->amount_rounding_method;

                $payment_method = $value->method;
                $latest_round_off_amount = $this->transactionUtil->latest_round_off_amount($payment_method, $final_total, $amount_rounding_method);

                // For multiple payment
                foreach ($value['payment_lines'] as $payment_lines_key => $payment_line) {
                    if (count($value['payment_lines']) == 1) {
                        if ($final_total > 0) {
                            $cash_received_amount = $final_total + $latest_round_off_amount;
                        } else {
                            $cash_received_amount = $final_total;
                        }
                    } else {
                        if ($value['refund_all'] == 1) {
                            $cash_received_amount = 0;
                        } else {
                            $cash_received_amount = $payment_line['amount'];
                        }
                    }
                    $payments[] = [
                        'transaction_payment_id' => $payment_line['id'],
                        'method' => $payment_line['method'],
                        'card_type' => $payment_line['card_type'],
                        'last_4_card_digits' => $payment_line['last_4_card_digits'],
                        'received_amount' => $cash_received_amount
                    ];
                }

                $table_arr = [];
                $table_name = [];
                $pax = '';

                $table_query = Transaction::leftjoin('pos_res_tables as t', 't.transaction_id', '=', 'transactions.id')
                    ->leftjoin('res_tables as z', 'z.id', '=', 't.res_table_id')
                    ->where('transactions.id', $value['id'])
                    ->select('t.res_table_id', 'pax', 'z.name')
                    ->get();
                // ->dump();

                if (!empty($table_query)) {
                    foreach ($table_query as $key => $tableValue) {
                        if ($tableValue['res_table_id'] != null) {
                            array_push($table_arr, $tableValue['res_table_id']);
                            array_push($table_name, $tableValue['name']);
                            $pax = $tableValue['pax'];
                        }
                    }
                }
                if(!empty($value['res_table_id']))
                {
                    $tabeldata = ResTable::where('id', $value['res_table_id'])->first();
                    array_push($table_arr, $tabeldata->id);
                    array_push($table_name, $tabeldata->name);
                }

                $last_4_card_digits = '';
                $d_date = '';
                $d_time = '';
                $d_address = '';
                $business_location_name_for_pickup = '';
                $business_location_mobile_for_pickup = '';
                $business_location_name_for_delivery = '';
                $business_location_mobile_for_delivery = '';
                $order_no = '';
                $pickup_completed = '';
                $lalamove_orderRef = '';
                $lalamove_status = '';
                $lalamove_driver_info = '';

                $check_contact_access = Contact::join('user_contact_access AS uca', 'contacts.id', 'uca.contact_id')
                    ->where('uca.contact_id', $value['contact_id'])->first();

                if ($check_contact_access) {
                    $user_query = User::where('id', $check_contact_access->user_id)->first();

                    $member_mobile = $user_query->contact_number;
                    $member_dob = $user_query->dob;
                } else {
                    $member_mobile = "";
                    $member_dob = "";
                }

                $final_total = round($final_total - $value['round_off_amount'], 2);

                $transaction_result[] = [
                    'app_order_id' => $value['app_order_id'],
                    'id' => $value['id'],
                    'business_id' => $value['business_id'],
                    'location_id' => $value['location_id'],
                    'transaction_date' => $value['transaction_date'],
                    'table_id' => $table_arr,
                    'table_name' => $table_name,
                    'pax' => $pax,
                    'invoice_no' => $value['invoice_no'],
                    'order_check_no' => $value['order_check_no'],
                    'ref_no' => $value['ref_no'],
                    'order_no' => $value['order_no'],
                    'type' => $value['type'],
                    'type_for_api' => $value['type_for_api'],
                    'total' => $final_total,
                    'round_off_amount' => round($latest_round_off_amount, 2),
                    'paymentType' => $value['method'],
                    'card_type' => $value['card_type'],
                    'tax_id' => $value['tax_id'],
                    'contact_id' => $value['contact_id'],
                    'tax_amount' => $tax_amount,
                    'addon_discount' => ($value['profit_percent'] == null ? 0 : $value['profit_percent']),
                    'discount_type' => $value['discount_type'],
                    'discount_amount' => $discount_amount,
                    'service_charge' => $value['service_charges'],
                    'delivery_charge' => $value['delivery_charges'],
                    'reward_amount' => $value['rp_redeemed'],
                    'customer_reward_amount' => $value['rp_redeemed_amount'],
                    'service_charge_amount' => $service_charge_amount,
                    'tax_rate_amount' => $value['tax_rate_amount'],
                    'profit_percent' => $value['profit_percent'],
                    'return_exists' => $value['return_exists'],
                    'refund_all' => $value['refund_all'],
                    'total_dont_have_line_discount_amt' => $total_dont_have_line_discount_amt,
                    'final_total_for_single_item' => $final_total_for_single_item,
                    'received_amount' => $value['received_amount'],
                    'last_4_card_digits' => $last_4_card_digits,
                    'd_date' => $d_date,
                    'd_time' => $d_time,
                    'd_address' => $d_address,
                    'business_location_name_for_pickup' => $business_location_name_for_pickup,
                    'business_location_mobile_for_pickup' => $business_location_mobile_for_pickup,
                    'business_location_name_for_delivery' => $business_location_name_for_delivery,
                    'business_location_mobile_for_delivery' => $business_location_mobile_for_delivery,
                    'order_no' => $order_no,
                    'pickup_completed' => $pickup_completed,
                    'lalamove_orderRef' => $lalamove_orderRef,
                    'lalamove_status' => $lalamove_status,
                    'lalamove_driver_info' => $lalamove_driver_info,
                    'shipping_charges' => $value['shipping_charges'],
                    'first_name' => $value['contact']->first_name,
                    'last_name' => $value['contact']->last_name,
                    'estimated_arrival_time' => Carbon::parse(Carbon::parse($value['transaction_date'])->addHour())->format('d/m/Y h:ia'),
                    'updated_at' => Carbon::parse($value['updated_at'])->format('d/m/Y h:ia'),
                    'deposit' => $value['deposit'],
                    'member_mobile' => $member_mobile,
                    'member_dob' => $member_dob,
                    'item' => $item,
                    'payments' => $payments,
                    'is_inclusive_gst_applied' => $value['is_inclusive_gst_applied'] ? true : false,
                    'tag_number' => $value['tag_number'],
                    'discount_type_id' => $value['discount_type_id'],
                    'open_discount_value' => $value['open_discount_value'],
                    'commission_type' => $value['commission_type'],
                    'status' => $value['status'],
                    'extra_tag' => !empty($value['extra_tag']) ? $value['extra_tag'] : null,
                    'cash_change_amount' => $value['cash_change_amount'],
                    'cash_received_amount' => $value['cash_received_amount'],
                    'void_items' => $value['void_items'],
                ];

            }

            $business_location_details = BusinessLocation::where('id', $business_location_id)
                ->select('name', 'landmark', 'country', 'state', 'city', 'zip_code', 'cds', 'alternate_number', 'mobile', 'uen', 'business_id')
                ->first();

            $business_id = $business_location_details['business_id'];
            $business = Business::find($business_id);
            $currencyId = $business->currency_id;
            $currencyData = Currency::find($currencyId);
            $business_location_details['currency_id'] = $currencyId;
            $business_location_details['currency_symbol'] = $currencyData->symbol;
            $business_location_details['currency_symbol_placement'] = $business->currency_symbol_placement;
            return ["sells" => $transaction_result, "business_location_details" => $business_location_details];
        } catch (\Exception $e) {
            DB::rollBack();

            \Log::emergency("File:" . $e->getFile() . "Line:" . $e->getLine() . "Message:" . $e->getMessage());
            $msg = __('messages.something_went_wrong');

            $output = [
                'errorMessage' => $msg
            ];

            return $output;
        }
    }
     public function email_order_invoice(Request $request)
    {
        try {
            $request->validate([
                'transaction_id' => 'required',
                'email' => 'required|email',
            ]);

            $allEachSaleHistory = $this->get_invoice_history($request['transaction_id']);
            // Generate PDF
            $pdfContent = $this->generatePdf($allEachSaleHistory);
            $pdfFileName='invoice_' . $request['transaction_id'] . '.pdf';
            $bucketName = config('constants.AWS_BUCKET');
            $pdfKey = config('constants.awsS3Env') . "/invoice_ereceipt/" . $pdfFileName;  // The key (path) under which the PDF will be stored in the bucket

            $s3 = new S3Client([
                'version' => 'latest',
                'region' => config('constants.AWS_DEFAULT_REGION'),  // Replace with your desired region
                'credentials' => [
                    'key' => config('constants.AWS_ACCESS_KEY_ID'),
                    'secret' => config('constants.AWS_SECRET_ACCESS_KEY'),
                ],
            ]);
            try {
                $result = $s3->putObject([
                    'Bucket' => $bucketName,
                    'Key' => $pdfKey,
                    'Body' => $pdfContent,
                    'ContentType' => 'application/pdf',  // Set the appropriate content type
                    // 'ACL' => 'public-read',  // Adjust ACL settings as needed
                ]);
                \Log::info("PDF URL: ". $result['ObjectURL']);
                $pdfUrl = ["url" => $result['ObjectURL']];
            } catch (AwsException $e) {
                \Log::info("Error uploading PDF to S3: " . $e->getMessage());
                return false;
            }
            $subject = 'E-receipt';  
            $content = 'E-receipt';
            $business = Business::where('id', $allEachSaleHistory['business_location_details']->business_id)->first();
            $email_settings = $business->email_settings ?? [];
            $this->sendEmail($pdfUrl, $request['email'], $email_settings, $subject, $content);
            return ['success' => true];
        } catch (\Exception $e) {
            if (get_class($e) == \App\Exceptions\PurchaseSellMismatch::class) {
                $msg = $e->getMessage();
            } else {
                \Log::emergency("File:" . $e->getFile() . "Line:" . $e->getLine() . "Message:" . $e->getMessage());
                $msg = __('messages.something_went_wrong');
            }
            return [
                'errorMessage' => $msg,
                'success' => false
            ];
        }
    }
    private function generatePdf($data)
    {  
        $businessLocationDetails = $data['business_location_details'];
        $sells = $data['sells'][0];

        $html = '<!DOCTYPE html>
           <html>
           <head>
           </head>
           <body>
           <div style="width: 560px; margin: 20px auto; padding-top: 10%;">
              <div style="text-align: center; margin-bottom: 30px;">
                  <p style="margin: 0; font-weight: bold;">' . $businessLocationDetails['name'] . '</p>
                  <p style="margin: 0;">' . $businessLocationDetails['landmark'] . ', ' . $businessLocationDetails['city'] . ', ' . $businessLocationDetails['country'] . '</p>
                  <p style="margin: 0;">GST No : ' . $businessLocationDetails['uen'] . '</p>
                  <p style="margin: 0;">Date & Time : ' . $sells['transaction_date'] . '</p>
                  <p style="margin: 0; font-weight: bold;">Order No : ' . $sells['invoice_no'] . '</p>
              </div>
              <table style="width: 100%; border-collapse: collapse;">
                  <tr>
                      <th style="text-align: left; padding: 8px; border-bottom: 1px solid #eee; color: #000; font-weight: bold;">
                          Item
                      </th>
                      <th style="text-align: right; padding: 8px; border-bottom: 1px solid #eee; color: #000; font-weight: bold;">
                          Qty
                      </th>
                      <th style="text-align: right; padding: 8px; border-bottom: 1px solid #eee; color: #000; font-weight: bold;">
                          Price
                      </th>
                  </tr>';

                  foreach ($sells['item'] as $item) {
                    // Calculate the price by multiplying the quantity with the amount
                    $calculatedPrice = $item['quantity'] * $item['amount'];
                    $totalWithAddons = $calculatedPrice;
                
                    foreach ($item['adons'] as $addon) {
                        $totalWithAddons += $item['quantity'] * $addon['amount'];
                    }
                    $html .= '<tr>
                        <td style="text-align: left; padding: 8px; border-bottom: ' . (empty($item['adons']) ? '1px solid #eee;' : 'none;') . '">' . $item['name'] . '</td>
                        <td style="text-align: right; padding: 8px; border-bottom: ' . (empty($item['adons']) ? '1px solid #eee;' : 'none;') . '" rowspan="' . (empty($item['adons']) ? '1' : count($item['adons']) + 1) . '">' . $item['quantity'] . '</td>
                        <td style="text-align: right; padding: 8px; border-bottom: ' . (empty($item['adons']) ? '1px solid #eee;' : 'none;') . '" rowspan="' . (empty($item['adons']) ? '1' : count($item['adons']) + 1) . '">' . $businessLocationDetails['currency_symbol'] . number_format($totalWithAddons, 2) . '</td>';
                
                    $html .= '<td colspan="2"></td>'; // Empty cells for quantity and amount of addons
                   foreach ($item['adons'] as $addon) {
                       $html .= '<tr>
                           <td style="text-align: left; padding: 8px;"> <i> &nbsp;&nbsp;&nbsp;&nbsp;' . $addon['quantity'] . ' ' . $addon['name'] . '</i></td>
                       </tr>';
                   }
                 if (!empty($item['adons'])) {
                     $html .= '<tr>
                         <td colspan="3" style="border-bottom: 1px solid #eee;"></td>
                     </tr>';
                      } 
                      $html .= '</tr>';
                             }    
                     $html .= '<tr>
                             <td colspan="2" style="text-align: right; padding: 8px; border-bottom: 1px solid #eee;">Sub Total :</td>
                         <td style="text-align: right; padding: 8px; border-bottom: 1px solid #eee;">'.$businessLocationDetails['currency_symbol'] . number_format($sells['final_total_for_single_item'], 2) . '</td>
                     </tr>
                     <tr>
                         <td colspan="2" style="text-align: right; padding: 8px; border-bottom: 1px solid #eee;">Service Charge
                             ('.(floatval($sells['service_charge']) * 100) .'%) :</td>
                         <td style="text-align: right; padding: 8px; border-bottom: 1px solid #eee;">'.$businessLocationDetails['currency_symbol'] . number_format($sells['service_charge_amount'], 2) . '</td>
                     </tr>
                     <tr>
                         <td colspan="2" style="text-align: right; padding: 8px; border-bottom: 1px solid #eee;">';

                         if ($sells['is_inclusive_gst_applied'] == false) {
                            $html .= 'GST (' . $sells['tax_rate_amount'] . '%)(Exclusive) :</td>';
                        } else {
                            $html .= 'GST (' . $sells['tax_rate_amount'] . '%)(Inclusive) :</td>';
                        }
                            $html .= '<td style="text-align: right; padding: 8px; border-bottom: 1px solid #eee;">'.$businessLocationDetails['currency_symbol'] . number_format($sells['tax_amount'], 2) . '</td>
                     </tr>
                     <tr>
                         <td colspan="2" style="text-align: right; padding: 8px; border-top: 2px solid black; border-bottom: 2px solid black; font-weight: bold;">
                             Total :</td>
                         <td style="text-align: right; padding: 8px; border-top: 2px solid black; border-bottom: 2px solid black; font-weight: bold;">
                             '.$businessLocationDetails['currency_symbol'] . number_format($sells['total'], 2) . '</td>
                     </tr>
                     <tr>';
                     if (count($sells['payments']) === 1) {
                        if($sells['payments'][0]['method'] =='card')
                        {
                            $html .= '<td colspan="2" style="text-align: left; padding: 8px; border-bottom: 2px solid #bdbdbd;">Payment Method</td>';
                            $html .= '<td style="text-align: right; padding: 8px; border-bottom: 2px solid #bdbdbd;">' . strtoupper( $sells['payments'][0]['card_type'] ). '</td>';
                        }
                        else{
                            $html .= '<td colspan="2" style="text-align: left; padding: 8px; border-bottom: 2px solid #bdbdbd;">Payment Method</td>';
                            $html .= '<td style="text-align: right; padding: 8px; border-bottom: 2px solid #bdbdbd;">' . strtoupper( $sells['payments'][0]['method'] ). '</td>';
                       
                        }
                    } else {
                        // If there are multiple payment methods
                        foreach ($sells['payments'] as $payment) {
                            if($payment['method']== 'card')
                            {
                                $html .= '<tr><td colspan="2" style="text-align: left; padding: 8px; border-bottom: 1px solid #bdbdbd;">' . strtoupper($payment['card_type']). '</td>';
                                 $html .= '<td style="text-align: right; padding: 8px; border-bottom: 1px solid #bdbdbd;">'.$businessLocationDetails['currency_symbol'] . number_format($payment['received_amount'], 2) . '</td>/tr>';

                            }
                            else{
                                $html .= '<tr><td colspan="2" style="text-align: left; padding: 8px; border-bottom: 1px solid #bdbdbd;">' . strtoupper($payment['method']). '</td>';
                                $html .= '<td style="text-align: right; padding: 8px; border-bottom: 1px solid #bdbdbd;">'.$businessLocationDetails['currency_symbol'] . number_format($payment['received_amount'], 2) . '</td>/tr>';
                            }

                        }
                    }
                     $html .=  '</td>
                 </tr>
                 
         </table>
         <div style="text-align: center; margin-top: 30px;">
             <p style="margin: 0;">Thank You</p>
             <p style="margin: 0;">See You Again</p>
         </div>
         </div>
         <footer>
         <p style="text-align: center; margin-top: 20px; font-size: 0.9em;">Powered by WarelyPOS</p>
        </footer>
        </body>
        </html>';
    
        $mpdf = new \Mpdf\Mpdf([
            'mode' => 'utf-8',
            'autoScriptToLang' => true,
            'autoLangToFont' => true,
            'autoVietnamese' => true,
            'autoArabic' => true,
            'margin_top' => 8,
            'margin_bottom' => 8,
            'format' => 'A4'
        ]);
        $mpdf->WriteHTML($html);
        
        // Output PDF content
        return $mpdf->Output('', 'S');
    }

    public function sendEmail($pdfUrl, $recipientEmail, $emailSettings, $subject, $content)
    {
        try {
            $pdfUrl = is_array($pdfUrl) ? $pdfUrl : ['url' => $pdfUrl];
            $emailSettings = is_array($emailSettings) ? $emailSettings : [];
            $emailSettingData['email_settings'] = is_array($emailSettings) ? $emailSettings : [];
            \Notification::route('mail', $recipientEmail)
                ->notify(new TestEmailNotification($emailSettingData, $subject, $content, $pdfUrl));
        } catch (\Exception $e) {
            \Log::info("Handle Caught exception: " . $e->getMessage() . " --- ");
        }
    }

    public function updateDineInOrder($input)
    {   
        try {
            $is_direct_sale = false;
            $isMoveTable = !empty($input['isMoveTable']) ? $input['isMoveTable'] : false;
            if (!empty($input['products'])) 
            {
                $id = $input['transaction_id'];
                $business_id = $input['business_id'];
                $user_id = $input['user_id'];
                $contact_id = $input['contact_id'];
                $delete_flag = $input['flag'];
                $pax = $input['pax'];
                $app_order_id = $input['app_order_id'];
                $app_item_line_id = isset($input['products'][0]['app_item_line_id']) ? $input['products'][0]['app_item_line_id'] : "";
                    
                if(!empty ($input['products'][0]['modifier_app_ids'])) {
                    $modifiers_app_ids = array_column($input['products'], 'modifier_app_ids');    
                } else {
                    $modifiers_app_ids = "";    
                }

                if(!empty($input['payment'])){
                    $payment_gateway_response = !empty($input['payment'][0]['payment_gateway_response']) ? $input['payment'][0]['payment_gateway_response'] : "";
                } else {
                    $payment_gateway_response = '';
                }
                    
                $discount = ['discount_type' => $input['discount_type'],
                            'discount_amount' => $input['discount_amount']
                        ];

                //$transaction_before = Transaction::find($id);
                $transaction_before = Transaction::where('id', $id)->first();
                
                $status_before =  $transaction_before->status;
                
                if($status_before !== 'final') {
                    
                    $rp_earned_before = $transaction_before->rp_earned;
                    $rp_redeemed_before = $transaction_before->rp_redeemed;
                    
                    $invoice_total = $this->productUtil->newCalculateInvoiceTotal($input['products'], $input['tax_rate_id'], $discount, $input['service_charges']);
                    
                    if (!empty($input['transaction_date'])) {
                        $input['transaction_date'] = $this->productUtil->uf_date($input['transaction_date'], true);
                    }

                    $input['is_suspend'] = isset($input['is_suspend']) && 1 == $input['is_suspend']  ? 1 : 0;
                    if ($input['is_suspend']) {
                        $input['sale_note'] = !empty($input['additional_notes']) ? $input['additional_notes'] : null;
                    }
                    
                    if($isMoveTable === true) {
                        $input['tag_number'] = $transaction_before->tag_number;
                    }

                    //Begin transaction
                    DB::beginTransaction();

                    $order_placed_by = (isset($input['order_placed_by']) && $input['order_placed_by']) ? $input['order_placed_by'] : 0;
                    $contact_ids = (isset($transaction_before['contact_ids']) && $transaction_before['contact_ids']) ? explode(',', $transaction_before['contact_ids']) : [];
                    if( $order_placed_by && !in_array($contact_id, $contact_ids) ) {
                        $contact_ids[] = $order_placed_by;
                    }
                    $input["contact_ids"] = implode(',', $contact_ids);
                    
                   if($input['order_platform'] == 'qr_link')
                    {
                        $transaction = $this->transactionUtil->updateSellTransactionQr($id, $business_id, $input, $invoice_total, $user_id,$app_order_id);
                    }
                    else{
                        $transaction = $this->transactionUtil->updateSellTransaction($id, $business_id, $input, $invoice_total, $user_id,$app_order_id);
                    }   
                    
                    if(!empty($transaction->invoice_no)) {
                        $invoice_resp = $transaction->invoice_no;
                    } else {
                        $invoice_resp = "";
                    }

                    if(!empty($transaction->order_check_no)) {
                        $order_check_no = $transaction->order_check_no;
                    } else {
                        $order_check_no = "";
                    }

                    //Update Sell lines
                    $business_details = $this->businessUtil->getDetails($business_id);
                    
                    if (in_array("modifiers", $business_details->enabled_modules)) {
                        $isModuleEnabled = true;
                    } else {
                        $isModuleEnabled = false;
                    }
                    
                    if ( isset($input['void_item_ids']) && !empty($input['void_item_ids']) && $input['transaction_id'] && $input['transaction_id'] ) {
                        $this->void_items($input['void_item_ids'], $input['transaction_id'], $input['location_id']);
                    }

                    $deleted_lines = $this->transactionUtil->createOrUpdateSellLines($transaction, $input['products'], $input['location_id'],$app_order_id, $modifiers_app_ids, $user_id, true, $status_before, [], true, $isModuleEnabled);
                    
                    //Update update lines
                    $is_credit_sale = isset($input['is_credit_sale']) && $input['is_credit_sale'] == 1 ? true : false;

                    
                    if (!$is_direct_sale && !$transaction->is_suspend && !empty($input['payment']) && !$is_credit_sale) {
                        $this->transactionUtil->createOrUpdatePaymentLines($transaction, $input['payment'], $app_order_id, $business_id, $user_id);

                        //Update cash register
                        $sell_payments = $this->cashRegisterUtil->updateSellPayments($status_before, $transaction, $input['payment'], $user_id,$app_order_id);
                        if($sell_payments == false) {
                            return response()->json(['status' => 'failed', 'msg' => 'Currently no cash registers are available, please reset your device' ]);    
                        }
                    }

                    //Check for final and do some processing.
                    if ($input['status'] == 'final') {
                        //Check and update reward point
                        if ($business_details->enable_rp == 1) {
                            $this->transactionUtil->updateCustomerRewardPoints($contact_id, $transaction->rp_earned, $rp_earned_before, $transaction->rp_redeemed, $rp_redeemed_before);

                        }

                        if( isset($input['res_table_id']) && count($input['res_table_id']) ) {
                            TableQrToken::where('business_id', $input['business_id'])
                                                        ->where('location_id', $input['business_location_id'])
                                                        ->whereIn('table_id', $input['res_table_id'])
                                                        ->update(['expired_at' => \Carbon::now()->format('Y-m-d H:i:s')]);
                        }
                    }
                    
                    //Update payment status
                    $payment_status = $this->transactionUtil->updatePaymentStatus($transaction->id, $transaction->final_total);
                    $transaction->payment_status = $payment_status;
                    //return $this->productUtil->adjustProductStockForInvoice($status_before, $transaction, $input, true, $input);
                    //Update product stock
                    
                    $this->productUtil->adjustProductStockForInvoice($status_before, $transaction, $input, true, $input);

                    $not_printed_lines = TransactionSellLine::where('transaction_id', $transaction['id'])
                            ->where('printed', 0)
                            ->first();
        
                    if (!empty($not_printed_lines)) {
                        Transaction::where('id', $transaction['id'])
                                        ->update(['pending_order' => 1]);
                    }

                    // PosResTables::where('app_order_id', $app_order_id)->update(['pax' => $pax]);
                    PosResTables::where('transaction_id', $transaction['id'])->update(['pax' => $pax]);
                    DB::commit();

                    $output = [
                        'msg' => "Sale order is edited.", 
                        'invoice_no' => $invoice_resp , 
                        'order_check_no' => $order_check_no,
                        'transaction_id' => $id,
                        'status' => 'success'
                    ];
                
                } else {
                    $output = ['msg' => "Unable to update table please try again", 'status' => 'failed',  'errorMessage' => "Unable to update table please try again"];
                }
            }
            else 
            {

                if($isMoveTable === true) {

                    $id = !empty($input['transaction_id']) ? $input['transaction_id'] : "";
                    $app_order_id = !empty($input['app_order_id']) ? $input['app_order_id'] : "";
                
                    if(isset($id)) {

                        $updated_rows = 0;
                        $tables = $input['res_table_id'];
                        if( $tables && count($tables) )
                            $updated_rows = PosResTables::whereIn('res_table_id', $tables)->update(['seated' => 0]);

                        if($updated_rows > 0) {
                            return response()->json(['status' => 1 ,'message' => 'Update successful'], 200);
                        } else {
                            return response()->json(['status' => 0 ,'message' => 'Update Failed'], 400);
                        }
                    }
                    elseif(isset($app_order_id)) {
                        $tables = $input['res_table_id'];
                        $updated_rows = 0;
                        if( $tables && count($tables) )
                            $updated_rows = PosResTables::whereIn('res_table_id', $tables)->update(['seated' => 0]);

                        if($updated_rows > 0) {
                            return response()->json(['status' => 1 ,'message' => 'Update successful'], 200);
                        } else {
                            return response()->json(['status' => 0 ,'message' => 'Update Failed'], 400);
                        }
                    }
                } else {
                    $output = [
                        'errorMessage' => trans("messages.something_went_wrong")
                    ]; 
                }   
            }
            return $output;
        } catch (\Exception $e) {
            \Log::emergency("File:" . $e->getFile() . "Line:" . $e->getLine() . "Message:" . $e->getMessage());
            $msg = trans("messages.something_went_wrong");

            $error_message = "File: " . $e->getFile(). " | Line: " . $e->getLine(). " | Message: " . $e->getMessage();
            $this->util->sendErrorLogOnMSTeam($error_message);

            return [
                'errorMessage' => $msg
            ];
        }
    }

    public function saveDineInOrder($input)
    {
        $is_direct_sale = false;
        try {
            
            if (!empty($input['products'])) 
            {
                
                $business_id = $input['business_id'];
                $user_id = $input['user_id'];
                $contact_id = $input['contact_id'];
                $send_print_request = !empty($input['send_print_request']) ? $input['send_print_request'] : "";
                $business_location_id = !empty($input['business_location_id']) ? $input['business_location_id'] : "";
                $app_order_id = isset($input['app_order_id']) ? $input['app_order_id'] : "";
                $json_data = !empty($input['json_data']) ? $input['json_data'] : "";
                
                $businessLocation = BusinessLocation::find($business_location_id);
                if( !empty($businessLocation) && !empty($businessLocation->day_start_time) ) {
                    $daystartTime = $businessLocation->day_start_time;
                    $dayStartTime = $daystartTime.":00:00";
                    $dayendTime = $daystartTime - 1;
                    $dayEndTime = $dayendTime.":59:59";
                }  else {
                    $dayStartTime = str_replace(' ', '', Config::get('constants.businessStartTimeDefault'));
                    $dayEndTime = str_replace(' ', '', Config::get('constants.businessEndTimeDefault'));
                }
                
                //$invoice_resp = "";
                // $app_item_line_id = isset($input['products'][0]['app_item_line_id']) ? $input['products'][0]['app_item_line_id'] : "";
                
                // if(!empty ($input['products'][0]['app_item_line_id'])) {
                //     $app_item_line_id = array_column($input['products'], 'app_item_line_id');    
                // } else {
                //     $app_item_line_id = "";    
                // }
                
                if(!empty ($input['products'][0]['modifier_app_ids'])) {
                    $modifiers_app_ids = array_column($input['products'], 'modifier_app_ids');    
                } else {
                    $modifiers_app_ids = "";    
                }
                
                $discount = ['discount_type' => $input['discount_type'],
                            'discount_amount' => $input['discount_amount']
                        ];

                $invoice_total = $this->productUtil->newCalculateInvoiceTotal($input['products'], $input['tax_rate_id'], $discount, $input['service_charges']);
                
                if(!empty($input['payment'])){
                    $payment_gateway_response = !empty($input['payment'][0]['payment_gateway_response']) ? $input['payment'][0]['payment_gateway_response'] : "";
                } else {
                    $payment_gateway_response = '';
                }
                DB::beginTransaction();
                        
                if (empty($input['transaction_date'])) {
                    $input['transaction_date'] =  \Carbon::now();
                } else {
                    $input['transaction_date'] = $this->productUtil->uf_date($input['transaction_date'], true);
                }

                $input['is_suspend'] = isset($input['is_suspend']) && 1 == $input['is_suspend']  ? 1 : 0;
                if ($input['is_suspend']) {
                    $input['sale_note'] = !empty($input['additional_notes']) ? $input['additional_notes'] : null;
                }
                
                $current_time = null;
                if( isset($user_data["current_time"]) && $user_data["current_time"] ) {
                    $current_time = $user_data["current_time"];
                }
                
                $current_date = null;
                if( isset($user_data["current_date"]) && $user_data["current_date"] ) {
                    $current_date = $user_data["current_date"];
                }
                
                if( Config::get('constants.setBusinessTime') && !empty($businessLocation) && !empty($businessLocation->day_start_time) && !empty($current_time) && !empty($current_date) ) {
                    $morning6TimeStamp = strtotime($current_date . " " . $dayEndTime);
                    $dateTimeStamp = strtotime($current_date . " " . $current_time);
                    if( $dateTimeStamp >= $morning6TimeStamp ) {
                        $today = $current_date . ' ' .$dayStartTime;
                        $tomorrow = date('Y-m-d', strtotime($current_date .' +1 day')) . ' ' .$dayEndTime;
                    } else {
                        $today = date('Y-m-d', strtotime($current_date .' -1 day')) . ' ' .$dayStartTime;
                        $tomorrow = $current_date .' '.$dayEndTime;
                    }
                } else {
                    $today = Carbon::today()->format('Y-m-d') . Config::get('constants.businessStartTimeDefault');
                    $tomorrow = Carbon::today()->format('Y-m-d') . Config::get('constants.businessEndTimeDefault');
                }
                
                // if( Config::get('constants.setBusinessTime') && !empty($businessLocation) && !empty($businessLocation->day_start_time) ) {
                //     $today = date('Y-m-d') .' '.$dayStartTime;
                //     $tomorrow = date('Y-m-d', strtotime(' +1 day')) .' '.$dayEndTime;
                // } else {
                //     $today = date('Y-m-d') . Config::get('constants.businessStartTimeDefault');
                //     $tomorrow = date('Y-m-d') . Config::get('constants.businessEndTimeDefault');
                // }
                // dd($today, $tomorrow);

                $posResTable = null;
                if( isset($input["res_table_id"]) && $input["res_table_id"] && count($input["res_table_id"]) ) {
                    foreach ($input["res_table_id"] as $res_table_id) {
                        
                        // $posResTable = PosResTables::leftJoin('transactions', function($join) {
                        //                             $join->on('transactions.app_order_id','=','pos_res_tables.app_order_id')
                        //                                  ->orWhere(function($query) {
                        //                                     $query->whereNull('pos_res_tables.app_order_id')
                        //                                               ->whereColumn('transactions.id', '=', 'pos_res_tables.transaction_id');
                        //                                      });
                        //                             })
                        //                     ->where('pos_res_tables.res_table_id', '=', $res_table_id)
                        //                             ->where('pos_res_tables.seated', '=', 1)
                        //                     ->whereBetween('pos_res_tables.created_at', [$today, $tomorrow])
                        //                     //->whereDate('pos_res_tables.created_at','>=', Carbon::today())
                        //                             ->first();
                        //    }
                    
                        $posResTable = PosResTables::leftjoin('transactions', function($join) {
                                                        $join->on('transactions.id', '=', 'pos_res_tables.transaction_id')
                                                            ->orWhere(function($query) {
                                                                $query->whereNull('transactions.id')
                                                                    ->whereColumn('pos_res_tables.app_order_id', '=', 'transactions.app_order_id');
                                                            });
                                                    })
                                                    ->where('pos_res_tables.res_table_id', '=', $res_table_id)
                                                    ->where('pos_res_tables.seated', '=', 1)
                                                    ->whereBetween('pos_res_tables.created_at', [$today, $tomorrow])
                                                    ->lockForUpdate()
                                                    ->first();
                    }
                }

                if($posResTable){
                    $output = [
                        'status' => 'failed',
                        'msg' => 'Table is occupied.',
                    ];
                    return $output;
                  
                    $transaction = Transaction::where(function ($query) use ($posResTable) {
                                        $query->where('app_order_id', $posResTable['app_order_id'])
                                              ->orWhere(function ($query) use ($posResTable) {
                                                  $query->whereNull('app_order_id')
                                                        ->where('id', $posResTable['transaction_id']);
                                              });
                                        })->first();
                                    
                    
                    if($transaction){
                        //duplicate table
                        $business_details = $this->businessUtil->getDetails($business_id);
                        if (in_array("modifiers", $business_details->enabled_modules)) {
                            $isModuleEnabled = true;
                        } else {
                            $isModuleEnabled = false;
                        }

                        $this->transactionUtil->createOrUpdateSellLines2($transaction, $input['products'], $input['location_id'], $app_order_id, $modifiers_app_ids, $user_id, false, null, [], true, $isModuleEnabled);
                        
                        //$this->transactionUtil->updateTransactionInvoice($transaction->id, $invoice_total, $business_id);
    
                        // if (!$is_direct_sale) {
                        //     //Add change return
                        //     $change_return = $this->dummyPaymentLine;
                        //     $change_return['amount'] = $input['change_return'];
                        //     $change_return['is_return'] = 1;
                        //     $input['payment'][] = $change_return;
                        // }
    
                        $is_credit_sale = isset($input['is_credit_sale']) && $input['is_credit_sale'] == 1 ? true : false;
                        //transaction_payments table
                        if (!$transaction->is_suspend && !empty($input['payment']) && !$is_credit_sale) {
                            $this->transactionUtil->createOrUpdatePaymentLines($transaction, $input['payment'], $app_order_id, $business_id, $user_id);
                        }
    
                        //update product stock
                        foreach ($input['products'] as $product) {
                            $decrease_qty = $this->productUtil
                                        ->num_uf($product['quantity']);
                            if (!empty($product['base_unit_multiplier'])) {
                                $decrease_qty = $decrease_qty * $product['base_unit_multiplier'];
                            }
    
                            if ($product['enable_stock']) {
                                $this->productUtil->decreaseProductQuantity(
                                    $product['product_id'],
                                    $product['variation_id'],
                                    $input['location_id'],
                                    $decrease_qty
                                );
                            }
    
                            if ($product['product_type'] == 'combo') {
                                //Decrease quantity of combo as well.
                                $this->productUtil
                                    ->decreaseProductQuantityCombo(
                                        $product['combo'],
                                        $input['location_id']
                                    );
                            }
                        }
    
                        //Check for final and do some processing.
                        if ($input['status'] == 'final') {
                            //Add payments to Cash Register
                            
                            if (!$is_direct_sale && !$transaction->is_suspend && !empty($input['payment']) && !$is_credit_sale) {
                                //cash_register_transactions table
                                $this->cashRegisterUtil->addSellPayments($transaction, $input['payment'], $input['user_id'], $app_order_id);
                            }
    
                            //Check and update reward point
                            if ($business_details->enable_rp == 1) {
                                $redeemed = !empty($input['rp_redeemed']) ? $input['rp_redeemed'] : 0;
                                $this->transactionUtil->updateCustomerRewardPoints($contact_id, $transaction->rp_earned, 0, $redeemed);
                            }
                        }
                        //Update payment status
                        $payment_status = $this->transactionUtil->updatePaymentStatus($transaction->id, $transaction->final_total,$app_order_id);
    
                        $transaction->payment_status = $payment_status;
                    }
                }else{
                    
                    //transactions table
                    $input['contact_ids'] = (isset($input['order_placed_by']) && $input['order_placed_by']) ? $input['order_placed_by'] : null;
                    
                    $transaction = $this->transactionUtil->createSellTransaction($business_id, $input, $invoice_total, $user_id);
                    
                    if(!empty($transaction->invoice_no)) {
                        $invoice_resp = $transaction->invoice_no;
                    } else {
                        $invoice_resp = "";
                    }
                    
                    if(!empty($transaction->order_check_no)) {
                        $order_check_no = $transaction->order_check_no;
                    } else {
                        $order_check_no = "";
                    }

                    if(!empty($transaction->id)) {
                        $transactionId = $transaction->id;
                    } else {
                        $transactionId = "";
                    }
                    
                    //pos_res_tables
                    
                    $pos_res_tables = $this->transactionUtil->createPosResTable($transaction, $input, $app_order_id);
                    //transaction_sell_lines table

                    $business_details = $this->businessUtil->getDetails($business_id);
                    if (in_array("modifiers", $business_details->enabled_modules)) {
                        $isModuleEnabled = true;
                    } else {
                        $isModuleEnabled = false;
                    }
                    $this->transactionUtil->createOrUpdateSellLines($transaction, $input['products'], $input['location_id'], $app_order_id, $modifiers_app_ids, $user_id, false, null, [], true, $isModuleEnabled);

                    // if (!$is_direct_sale) {
                    //     //Add change return
                    //     $change_return = $this->dummyPaymentLine;
                    //     $change_return['amount'] = $input['change_return'];
                    //     $change_return['is_return'] = 1;
                    //     $input['payment'][] = $change_return;
                    // }

                    $is_credit_sale = isset($input['is_credit_sale']) && $input['is_credit_sale'] == 1 ? true : false;
                    //transaction_payments table
                    if (!$transaction->is_suspend && !empty($input['payment']) && !$is_credit_sale) {
                        $this->transactionUtil->createOrUpdatePaymentLines($transaction, $input['payment'], $app_order_id, $business_id, $user_id );
                    }

                    //update product stock
                    foreach ($input['products'] as $product) {
                        $decrease_qty = $this->productUtil
                                    ->num_uf($product['quantity']);
                        if (!empty($product['base_unit_multiplier'])) {
                            $decrease_qty = $decrease_qty * $product['base_unit_multiplier'];
                        }

                        if ($product['enable_stock']) {
                            $this->productUtil->decreaseProductQuantity(
                                $product['product_id'],
                                $product['variation_id'],
                                $input['location_id'],
                                $decrease_qty
                            );
                        }

                        if ($product['product_type'] == 'combo') {
                            //Decrease quantity of combo as well.
                            $this->productUtil
                                ->decreaseProductQuantityCombo(
                                    $product['combo'],
                                    $input['location_id']
                                );
                        }
                    }

                    //Check for final and do some processing.
                    if ($input['status'] == 'final') {
                        //Add payments to Cash Register
                        if (!$is_direct_sale && !$transaction->is_suspend && !empty($input['payment']) && !$is_credit_sale) {
                            //cash_register_transactions table
                            $sell_payments = $this->cashRegisterUtil->addSellPayments($transaction, $input['payment'], $input['user_id']);
                            if($sell_payments == false) {
                                return response()->json(['status' => 'failed', 'msg' => 'Currently no cash registers are available, please reset your device' ]);    
                            }
                        }

                        //Check and update reward point
                        if ($business_details->enable_rp == 1) {
                            $redeemed = !empty($input['rp_redeemed']) ? $input['rp_redeemed'] : 0;
                            $this->transactionUtil->updateCustomerRewardPoints($contact_id, $transaction->rp_earned, 0, $redeemed);
                        }

                        $is_nfc_payment = !empty($input['is_nfc_payment']) ? true : false;

                        // if($is_nfc_payment === true) {
                        $debitOrder = $this->transactionUtil->debitOrderBalance($input);
                        if($debitOrder == false) {
                            return response()->json(['errorMessage' => 'Insufficient NFC Card Balance.'], 200);
                        }
                        $debitOrderAmount = $this->transactionUtil->debitOrderBalanceFromCredit($input, $transaction->id);
                        if ($debitOrderAmount == false) {
                            return response()->json(['errorMessage' => 'Insufficient Credit Balance.'], 200);
                        }
                        // }
                    }
                    //Update payment status
                    $payment_status = $this->transactionUtil->updatePaymentStatus($transaction->id, $transaction->final_total);

                    $transaction->payment_status = $payment_status;
                    
                    if($input['status'] == 'final') {
                        if(!empty($input['qr_token'])) {
                            $expired_at = \Carbon::now()->format('Y-m-d H:i:s');
                            $create_qr_token = [
                                'expired_at' => $expired_at
                            ];
                    
                            $qrTokenRecord = TableQrToken::where('qr_token', $input['qr_token'])->first();
                    
                            if ($qrTokenRecord) {
                                $qrTokenRecord->update($create_qr_token);
                            }
                        }
                    }
                      
                    if($send_print_request == true){
                    // $transaction_id = $request->input('transaction_id');
                    // $status = $request->input('status');
                       $device_id = !empty($input['device_id']) ? $input['device_id'] : "";
                    //$receipt_type = $request->input('receipt_type');
                    //$user_id = $request->input('user_id');
                    //$business_id = $request->input('business_id');
                    //$location_id = $request->input('location_id');
                    //$business_location_id = $request->input('business_location_id');
            
                    // Fetch the FCM token for the device ID
                    $device = ManagePosDevice::select('device_fcm_token', 'device_name')
                                                    // ->where('device_id', $device_id)
                                                    ->where('is_master', 1)
                                                    ->where('business_id', $business_id)
                                                    ->where('business_location_id', $business_location_id)
                                                    ->first();
                                                    
                    $device_sub = ManagePosDevice::select( 'device_name')
                                ->where('device_id', $device_id)
                                ->where('is_master', 0)
                                ->where('business_id', $business_id)
                                ->where('business_location_id', $business_location_id)
                                ->first();
                                
                    $device_sub_name = !empty($device_sub->device_name) ? $device_sub->device_name : "";
            
                    if ($device) {
                        $fcm_token = $device->device_fcm_token;
                        $device_name = $device->device_name;
                        // Now you can use $fcm_token and $device_name in your CURL request
                    } else {
                        // Handle device not found error
                    }
                    
                    if($transaction->payment_status == 'due'){
                        $payment_status = 'draft';
                    } else {
                        $payment_status = 'final';
                    }
                    
                    try {
                        // Send the POST request to FCM server
                        $client = new Client();
                        $response = $client->post('https://fcm.googleapis.com/fcm/send', [
                            'headers' => [
                                'Authorization' => 'key=AAAAC1EQ6G4:APA91bHjcZ8gLrFatBsh7ttZoe6VH07IFzS2UxvykIVYrg_ngrxpRngSYIoUnWy0QqCcL7IGC_n7hmKsQSk82jfhXzInUsPxUdrBIpMqLQbb8u5XYz40nik95DNokU1FBZ85w3lJ9B_y',
                                'Content-Type' => 'application/json',
                            ],
                            'json' => [
                                'to' => $fcm_token,
                                'data' => [
                                    'order_print_request' => [
                                        'transaction_id' => $transaction->id,
                                        'status' => $payment_status,
                                        'json_data' => $json_data,
                                        'from' => $device_sub_name,
                                        'receipt_type' => 'kitchen',
                                    ],
                                ],
                            ],
                        ]);
            
                        $responseBody = json_decode($response->getBody());
                        $statusCode = $response->getStatusCode();
            
                        // if($responseBody->success) {
                        //     return response()->json(['status' => 'success'], $statusCode);
                        // } else {
                        //     return response()->json(['status' => 'failed'], $statusCode);
                        // }
                    } catch (\Exception $e) {
                        // Handle the FCM request exception
                        return response()->json(['status' => 'failed', 'message' => 'FCM request failed with error: ' . $e->getMessage()], 500);
                    }
                }
                }    

                DB::commit();

                $output = [
                    'msg' => "Sale order is added.", 
                    'status' => 'success', 
                    'invoice_no' => !empty($invoice_resp) ? $invoice_resp : "",
                    'order_check_no' => $order_check_no,
                    'transaction_id' => $transactionId
                ];
            }
            else 
            {
                $output = [
                            'errorMessage' => trans("messages.something_went_wrong")
                        ];
            }
        } catch (\Exception $e) {
            DB::rollBack();
            \Log::emergency("File:" . $e->getFile(). "Line:" . $e->getLine(). "Message:" . $e->getMessage());
            $msg = trans("messages.something_went_wrong");

            $error_message = "File: " . $e->getFile(). " | Line: " . $e->getLine(). " | Message: " . $e->getMessage();
            if ($e->getCode() == 40001) {

                $output = [
                        'status' => 'failed',
                        'msg' => 'Table is occupied.'
                    ];
             }
             else{
                $this->util->sendErrorLogOnMSTeam($error_message);

                $msg = trans("messages.something_went_wrong");

                $output = [
                                'errorMessage' => $msg
                            ];
             }
        }
        return $output;
    }

    function save_digital_ordering(Request $request)
    {
        $res_table_id = 0;
        $input = $request;
        if( isset($input['queue_id']) && $input['queue_id'] ) {
            $queueTable = QueueTable::where('manage_queue_id', $input['queue_id'])
                        ->get();
            if( !empty($queueTable) && count($queueTable) ) {
                if( !$queueTable[0]->is_occupied ) {
                    return ["errorMessage" => 'Please re-register a new queue to order'];
                } else {
                    $res_table_id = $queueTable[0]->res_table_id;
                    if( $res_table_id ) {
                        $input['res_table_id'] = [$res_table_id];
                        $input['user_id'] = $queueTable[0]->commission_user_id ? $queueTable[0]->commission_user_id : 0;
                        $output = $this->saveDineInOrder($input);

                        if( isset($output) && $output && isset($output["status"]) && $output["status"] == 'success' ) {
                            $resTable = ResTable::select('res_tables.name', 'res_tables.description', 'res_tables.id')
                                        ->where('res_tables.id', $res_table_id)
                                        ->where('res_tables.business_id', $input["business_id"])
                                        ->where('res_tables.location_id', $input["location_id"])
                                        ->get();

                            if( isset($resTable) && !empty($resTable) && count($resTable) ) {
                                $output["data"] = $resTable[0];
                            }
                        }
                        return $output;
                    }
                }
            }

            if( ( empty($queueTable) && count($queueTable) == 0 ) || $res_table_id == 0 ) {
                $input['res_table_id'] = null;
                $input['manage_queue_id'] = [$input['queue_id']];
                $input['user_id'] = 0;
                $input['status'] = 'draft';
                $output = $this->saveDineInOrder($input);
                return $output;
            }
        } else {
            //if (isset($input['qr_token'])) {
                $input['table_id'] = (isset($input['res_table_id']) && $input['res_table_id']) ? $input['res_table_id'] : null;
                // $tableQrToken = TableQrToken::where('qr_token', $input['qr_token'])
                //                     ->where('location_id', $input['location_id'])
                //                     ->where('business_id', $input['business_id'])
                //                     ->where('table_id', $input['table_id'])
                //                     ->where('table_qr_tokens.expired_at', '>=', \Carbon::now()->format('Y-m-d H:i:s'));

                $tableQrToken = TableQrToken::where('table_qr_tokens.business_id', $input['business_id'])
                ->where('table_qr_tokens.location_id', $input['location_id'])
                ->where('table_qr_tokens.qr_token', $input['qr_token'])
                ->where('table_qr_tokens.table_id', $input['table_id'])
                ->where('table_qr_tokens.pax', $input['pax'])
                ->where('table_qr_tokens.user_id', $input['user_id'])
                ->where('table_qr_tokens.expired_at', '>=', \Carbon::now()->format('Y-m-d H:i:s'))
                ->orderBy('table_qr_tokens.created_at', 'desc')
                ->get();

                if($tableQrToken)
                {
                    $tableQrToken = json_decode($tableQrToken); 
                }
                if (empty($tableQrToken) && $input['is_not_static_qr']) {
                     return ["errorMessage" => 'Can’t be proceed. The order may have already been paid or the table closed.'];
                }
                // if (!empty($tableQrToken)) {
                    $products = $input['products'];
                    
                    $checkDineinDetail = $this->check_dinein_detail($input);
                    if( $checkDineinDetail && count($checkDineinDetail) && $checkDineinDetail['sells'] && count($checkDineinDetail['sells']) ) {
                        $input['transaction_id'] = $checkDineinDetail['sells'][0]['id'];
                        $input['table_id'] = $input['res_table_id'];
                        $temp_products = $checkDineinDetail['sells'][0]['item'];
                        foreach ($temp_products as $key => $temp_product) {
                            $adons = $temp_product['adons'];
                            $modifier = [];
                            $modifier_price = [];
                            $modifier_quantity = [];
                            $modifier_set_id = [];
                            foreach ($adons as $key => $adon) {
                                $modifier[] = $adon['id'];
                                $modifier_price[] = $adon['amount'];
                                $modifier_quantity[] = $adon['quantity'] . "";
                                $modifier_set_id[] = $adon['modifier_set_id'];
                            }

                            $products[] = [
                                'product_type' => "single",
                                'unit_price' => $temp_product['amount'],
                                'line_discount_type' => "",
                                'line_discount_amount' => "",
                                'item_tax' => 0.0, //fix
                                'tax_id' => "", //fix
                                'sell_line_note' => "", //fix
                                'modifier' => $modifier,
                                'modifier_price' => $modifier_price,
                                'modifier_set_id' => $modifier_set_id,
                                'modifier_quantity' => $modifier_quantity,
                                'product_id' => $temp_product['product_id'],
                                'variation_id' => $temp_product['variation_id'],
                                'enable_stock' => 0,
                                'quantity' => $temp_product['quantity'],
                                'product_unit_id' => $temp_product['unit_id'],
                                'base_unit_multiplier' => 1,
                                'unit_price_before_discount' => $temp_product['amount'],
                                'unit_price_inc_tax' => $temp_product['amount'],
                                'weight' => $temp_product['weight'],
                                'parent_product_group_id' => $temp_product['parent_product_group_id'],
                                // 'transaction_sell_lines_id' => $temp_product['transaction_sell_line_id'],
                                'serve_later_quantity' => 0,
                                'printed' => $temp_product['printed'],
                                'added_by_qr' => $temp_product['added_by_qr'] == "true",
                                'user_id' => $temp_product['user_id'],
                                'tag' => $temp_product['tag'],
                                'order_placed_by' => $temp_product['order_placed_by']                      
                            ];
                        }
                        $input['products'] = $products;
                        \Log::info("updateDineInOrder");
                        $output = $this->updateDineInOrder($input);
                    } else {
                        \Log::info("saveDineInOrder");
                        $output = $this->saveDineInOrder($input);
                    }
                    return $output;
                // } else {
                //     return ["errorMessage" => 'Please scan QR again'];
                // }

            // } else {
            //     return ["errorMessage" => 'Please scan QR again'];
            // }
        }
    }

    function save_digital_ordering_static_qr(Request $request)
    {
        $input = $request;
        $input['user_id'] = !empty($input['user_id']) ? $input['user_id']: 2; 
        $output = $this->saveOrder($input);
        return $output;       
    }

    function update_digital_ordering(Request $request)
    {
        try {
            $input = $request;
            $res_table_id = 0;
            if( isset($input['queue_id']) && $input['queue_id'] ) {
                $queueTable = QueueTable::where('manage_queue_id', $input['queue_id'])
                                        ->get();
                if( !empty($queueTable) && count($queueTable) ) {
                    if( !$queueTable[0]->is_occupied ) {
                        return ["errorMessage" => 'Please re-register a new queue to order'];
                    } else {
                        $res_table_id = $queueTable[0]->res_table_id;
                        if( $res_table_id ) {
                            $input['res_table_id'] = [$res_table_id];
                            $input['user_id'] = $queueTable[0]->commission_user_id ? $queueTable[0]->commission_user_id : 0;
                            $output = $this->updateDineInOrder($input);

                            if( isset($output) && $output && isset($output["status"]) && $output["status"] == 'success' ) {
                                $resTable = ResTable::select('res_tables.name', 'res_tables.description', 'res_tables.id')
                                            ->where('res_tables.id', $res_table_id)
                                            ->where('res_tables.business_id', $input["business_id"])
                                            ->where('res_tables.location_id', $input["location_id"])
                                            ->get();

                                if( isset($resTable) && !empty($resTable) && count($resTable) ) {
                                    $output["data"] = $resTable[0];
                                }
                            }
                            return $output;
                        }
                    }
                }

                if( ( empty($queueTable) && count($queueTable) == 0 ) || $res_table_id == 0 ) {
                    $input['res_table_id'] = null;
                    $input['manage_queue_id'] = [$input['queue_id']];
                    $input['user_id'] = 0;
                    $input['status'] = 'draft';
                    $output = $this->updateDineInOrder($input);
                    return $output;
                }
            } 
            elseif($input['type_for_api'] == 'Takeaway') {
        
                $products = $input['products'];
                \Log::info("Size Of products 1");
                \Log::info(count($products));
                $input['table_id'] = (isset($input['res_table_id']) && $input['res_table_id']) ? $input['res_table_id'] : null;
                $checkTakeawayDetail = $this->check_takeaway_order($input);
                if( $checkTakeawayDetail && count($checkTakeawayDetail) && $checkTakeawayDetail['sells'] && count($checkTakeawayDetail['sells']) ) {
                    $input['transaction_id'] = $checkTakeawayDetail['sells'][0]['id'];
                    $input['table_id'] = $input['res_table_id'];
                    $temp_products = $checkTakeawayDetail['sells'][0]['item'];
                    foreach ($temp_products as $key => $temp_product) {
                        $adons = $temp_product['adons'];
                        $modifier = [];
                        $modifier_price = [];
                        $modifier_quantity = [];
                        $modifier_set_id = [];
                        foreach ($adons as $key => $adon) {
                            $modifier[] = $adon['id'];
                            $modifier_price[] = $adon['amount'];
                            $modifier_quantity[] = $adon['quantity'] . "";
                            $modifier_set_id[] = $adon['modifier_set_id'];
                        }

                        $temp = [
                            'product_type' => "single",
                            'unit_price' => $temp_product['amount'],
                            'line_discount_type' => "",
                            'line_discount_amount' => "",
                            'item_tax' => 0.0, //fix
                            'tax_id' => "", //fix
                            'sell_line_note' => "", //fix
                            'modifier' => $modifier,
                            'modifier_price' => $modifier_price,
                            'modifier_set_id' => $modifier_set_id,
                            'modifier_quantity' => $modifier_quantity,
                            'product_id' => $temp_product['product_id'],
                            'variation_id' => $temp_product['variation_id'],
                            'enable_stock' => 0,
                            'quantity' => $temp_product['quantity'],
                            'product_unit_id' => $temp_product['unit_id'],
                            'base_unit_multiplier' => 1,
                            'unit_price_before_discount' => $temp_product['amount'],
                            'unit_price_inc_tax' => $temp_product['amount'],
                            'weight' => $temp_product['weight'],
                            'parent_product_group_id' => $temp_product['parent_product_group_id'],
                            // 'transaction_sell_lines_id' => $temp_product['transaction_sell_line_id'],
                            'serve_later_quantity' => !empty($temp_product['serve_later_quantity']) ? $temp_product['serve_later_quantity'] : 0,
                            'printed' => $temp_product['printed'],
                            'added_by_qr' => $temp_product['added_by_qr'] == "true",
                            'user_id' => $temp_product['user_id'],
                            'tag' => $temp_product['tag'],
                            'order_placed_by' => $temp_product['order_placed_by']
                        ];
                        $products[] = $temp;
                        \Log::info("Size Of products 2");
                        \Log::info(count($products));
                    }
                    $input['products'] = $products;
                    \Log::info("updateDineInOrder");
                    $output = $this->updateDineInOrder($input);
                } else {
                    \Log::info("updateDineInOrder");
                    $output = $this->updateDineInOrder($input);
                }
                return $output;
            } 
            else {
                //if (isset($input['qr_token'])) {
                    $tableQrToken = TableQrToken::where('qr_token', $input['qr_token'])
                                        ->where('location_id', $input['location_id'])
                                        ->where('business_id', $input['business_id']);

                    if (isset($input['qr_token'])){
                        $tableQrToken->where('table_qr_tokens.expired_at', '>=', \Carbon::now()->format('Y-m-d H:i:s'));
                    }

                    $tableQrToken->get()->toArray();       
                    
                    // if (!empty($tableQrToken)) {
                        $products = $input['products'];
                        \Log::info("Size Of products 1");
                        \Log::info(count($products));
                        $input['table_id'] = (isset($input['res_table_id']) && $input['res_table_id']) ? $input['res_table_id'] : null;
                        $checkDineinDetail = $this->check_dinein_detail($input);
                        if( $checkDineinDetail && count($checkDineinDetail) && $checkDineinDetail['sells'] && count($checkDineinDetail['sells']) ) {
                            $input['transaction_id'] = $checkDineinDetail['sells'][0]['id'];
                            $input['table_id'] = $input['res_table_id'];
                            $temp_products = $checkDineinDetail['sells'][0]['item'];
                            foreach ($temp_products as $key => $temp_product) {
                                $adons = $temp_product['adons'];
                                $modifier = [];
                                $modifier_price = [];
                                $modifier_quantity = [];
                                $modifier_set_id = [];
                                foreach ($adons as $key => $adon) {
                                    $modifier[] = $adon['id'];
                                    $modifier_price[] = $adon['amount'];
                                    $modifier_quantity[] = $adon['quantity'] . "";
                                    $modifier_set_id[] = $adon['modifier_set_id'];
                                }

                                $temp = [
                                    'product_type' => "single",
                                    'unit_price' => $temp_product['amount'],
                                    'line_discount_type' => "",
                                    'line_discount_amount' => "",
                                    'item_tax' => 0.0, //fix
                                    'tax_id' => "", //fix
                                    'sell_line_note' => "", //fix
                                    'modifier' => $modifier,
                                    'modifier_price' => $modifier_price,
                                    'modifier_set_id' => $modifier_set_id,
                                    'modifier_quantity' => $modifier_quantity,
                                    'product_id' => $temp_product['product_id'],
                                    'variation_id' => $temp_product['variation_id'],
                                    'enable_stock' => 0,
                                    'quantity' => $temp_product['quantity'],
                                    'product_unit_id' => $temp_product['unit_id'],
                                    'base_unit_multiplier' => 1,
                                    'unit_price_before_discount' => $temp_product['amount'],
                                    'unit_price_inc_tax' => $temp_product['amount'],
                                    'weight' => $temp_product['weight'],
                                    'parent_product_group_id' => $temp_product['parent_product_group_id'],
                                    // 'transaction_sell_lines_id' => $temp_product['transaction_sell_line_id'],
                                    'serve_later_quantity' => !empty($temp_product['serve_later_quantity']) ? $temp_product['serve_later_quantity'] : 0,
                                    'printed' => $temp_product['printed'],
                                    'added_by_qr' => $temp_product['added_by_qr'] == "true",
                                    'user_id' => $temp_product['user_id'],
                                    'tag' => $temp_product['tag'],
                                    'order_placed_by' => $temp_product['order_placed_by']
                                ];
                                $products[] = $temp;
                                \Log::info("Size Of products 2");
                                \Log::info(count($products));
                            }
                            $input['products'] = $products;
                            \Log::info("updateDineInOrder");
                            $output = $this->updateDineInOrder($input);
                        } else {
                            \Log::info("updateDineInOrder");
                            $output = $this->updateDineInOrder($input);
                        }
                        return $output;
                    // } else {
                    //     return ["errorMessage" => 'Please scan QR again'];
                    // }
                // } else {
                //     return ["errorMessage" => 'Please scan QR again'];
                // }
            }
        } catch (\Exception $e) {
            DB::rollBack();
            \Log::emergency("File:" . $e->getFile(). "Line:" . $e->getLine(). "Message:" . $e->getMessage());
            $msg = trans("messages.something_went_wrong");

            $output = [
                'errorMessage' => $msg
            ];
        }
        return $output;
    }

    public function fetchUpSellProducts(Request $request) {
        try {
            $input = $request;

            $query = TransactionSellLine::join('transactions', 'transactions.id', '=', 'transaction_sell_lines.transaction_id')
                                        ->join('products', 'products.id', '=', 'transaction_sell_lines.product_id')
                                        ->join('categories', 'categories.id', '=', 'products.category_id')
                                        ->join('variations', 'products.id', '=', 'variations.product_id')
                                        ->where('transactions.business_id', $input['business_id'])
                                        ->where('transactions.location_id', $input['business_location_id'])
                                        ->where('products.deleted_at', NULL)
                                        ->where('transactions.type', 'sell')
                                        ->where('products.not_for_selling', 0)
                                        ->select('products.*', 'categories.use_as_modifier as use_as_modifier', 'categories.id AS category_id', 'categories.name AS category', 'categories.short_code', 'variations.default_sell_price', 'variations.member_price', 'variations.id AS variation_id', 'categories.use_as_combo_products_category as use_as_combo_products_category', DB::raw('SUM(transaction_sell_lines.quantity) as total_ordered'));

            if ($input['contact_id'] != null) {
                $query->where(function($query) use ($input) {
                    $query->where('transactions.contact_id', $input['contact_id'])
                          ->orWhereRaw('FIND_IN_SET(?, transactions.contact_ids)', [$input['contact_id']]);
                });
            }

            $query->groupBy('products.id', 'products.name');
            $all_category_products = $query->orderBy('total_ordered', 'desc')
                                            ->limit(10)
                                            ->get();

            $output = [];
            if( $all_category_products && count($all_category_products) ) {
                foreach( $all_category_products AS $all_category_product) {
                    $modifer_set = Product::where('business_id', $input['business_id'])
                        ->with(['modifier_sets', 'variations'])
                        ->find($all_category_product->id);
        
                    if (empty($all_category_product->weight)) {
                        $price = $all_category_product->default_sell_price;
                    } else {
                        $price = $all_category_product->default_sell_price / floatval($all_category_product->weight);
                    }

                    if (empty($all_category_product->weight)) {
                        $member_price = $all_category_product->member_price;
                    } else {
                        $member_price = $all_category_product->member_price / floatval($all_category_product->weight);
                    }
        
                    if (!empty($all_category_product->image)) {
                        $image_url = config('constants.awsS3BaseUrl') . "/" . config('constants.awsS3Env') . "/img/" . rawurlencode($all_category_product->image);
                    } else {
                        $image_url = asset('/img/default_food.png');
                    }
        
                    $base_unit_multiplier = null;
                    $sub_unit_id = null;
                    if ($all_category_product->sub_unit_ids) {
                        $sub_unit_ids = json_decode($all_category_product->sub_unit_ids);
                        $intArray = array_map('intval', $sub_unit_ids);
                        $sub_units = Unit::whereIn('id', $intArray)
                            ->select('base_unit_multiplier', 'actual_name', 'id')
                            ->get();
                        if (!empty($sub_units) && count($sub_units)) {
                            $base_unit_multiplier = $sub_units[0]->base_unit_multiplier;
                            $sub_unit_id = $sub_units[0]->id;
                        }
                    } elseif ($all_category_product->unit_id) {
                        $unit = Unit::where('id', $all_category_product->unit_id)
                            ->select('base_unit_multiplier', 'actual_name')
                            ->first();
                        if (!empty($unit)) {
                            $base_unit_multiplier = $unit->base_unit_multiplier;
                        }
                    }

                    $combo_products = [];
                    if ( isset($modifer_set) && isset($modifer_set->variations) && $modifer_set->variations && count($modifer_set->variations)) {
                        foreach ($modifer_set->variations as $key => $each) {
                            $variation = json_decode($each);
                            if ($variation->combo_variations && count($variation->combo_variations)) {
                                foreach ($variation->combo_variations as $key => $combo_variation) {
                                    $combo_product = Variation::where('variations.id', $combo_variation->variation_id)
                                        ->join('products AS p', 'variations.product_id', '=', 'p.id')
                                        ->select(['p.*', 'variations.name as variation_name'])
                                        ->first();
                                    $combo_product['quantity'] = round($combo_variation->quantity, 2);
                                    $combo_products[] = $combo_product;
                                }
                            }
                        }
                    }
                    
                    // $is_modifier_product = false;
                    // if (isset($all_category_product->use_as_modifier) && $all_category_product->use_as_modifier && $all_category_product->use_as_modifier > 0) {
                    //     $is_modifier_product = true;
                    // }
                    $open_modifier_count = 0;
                    $product_modifier_count = 0;
                     $modifier_sets = $modifer_set->modifier_sets;

                    foreach ($modifier_sets as $set) {
                        if (isset($set['name']) && isset($set['is_open_modifier'])) {
                            $modifier_set_details[] = [
                                'name' => $set['name'],
                                'is_open_modifier' => $set['is_open_modifier']
                            ];
                    
                            if ($set['is_open_modifier'] == 1) {
                                $open_modifier_count++;
                            } elseif ($set['is_open_modifier'] == 0) {
                                $product_modifier_count++;
                            }
                        }
                    }
        
                    $output[] = [
                        'id' => $all_category_product->id,
                        'variation_id' => $all_category_product->variation_id,
                        'unit_id' => $all_category_product->unit_id,
                        'category_id' => $all_category_product->category_id,
                        'category' => $all_category_product->category,
                        'short_code' => !empty($all_category_product->short_code) ? $all_category_product->short_code : '',
                        'name' => $all_category_product->name,
                        'sequence' => $all_category_product->sequence,
                        'sku' => $all_category_product->sku,
                        'product_description' => $all_category_product->product_description,
                        'image' => $image_url,
                        'unit_price' => $all_category_product->default_sell_price,
                        'weight' => $all_category_product->weight,
                        'price' => $price,
                        'member_price' => $member_price,
                        'modifer_flag' => isset($modifer_set) && isset($modifer_set->modifier_sets) && count($modifer_set->modifier_sets) ? 'true' : 'false',
                        'not_for_digital_ordering' => $all_category_product->not_for_digital_ordering,
                        'not_for_pickup_delivery' => $all_category_product->not_for_pickup_delivery,
                        'enable_stock' => $all_category_product->enable_stock,
                        'base_unit_multiplier' => $base_unit_multiplier,
                        'sub_unit_id' => $sub_unit_id,
                        'kitchen_shorthand' => $all_category_product->kitchen_shorthand,
                        'name_in_second_language' => $all_category_product->name_in_second_language,
                        'show_combo_products' => $all_category_product->show_combo_products ? true : false,
                        'combo_products' => $combo_products,
                        // 'is_modifier_product' => $is_modifier_product,
                        'use_as_combo_products_category' => $all_category_product->use_as_combo_products_category ? true : false,
                        'combo_products_category_id' => $all_category_product->combo_products_category_id,
                        'total_ordered' => $all_category_product->total_ordered,
                        'open_modifier_count' => $open_modifier_count,
                        'product_modifier_count' => $product_modifier_count

                    ];
                }
            }
            return ["sells" => $output];
        } catch (\Exception $e) {
            DB::rollBack();
            \Log::emergency("File:" . $e->getFile(). "Line:" . $e->getLine(). "Message:" . $e->getMessage());
            $msg = trans("messages.something_went_wrong");

            $output = [
                'errorMessage' => $msg
            ];
        }

        return $output;
    }
    
    public function digital_ordering_stripe_payment(Request $request)
    {
        try {
            // Extract required data from the request
            $input = (Object) $request->all();
            $transactionId =  $input-> transaction_id;
            $payments =  $input-> payment;
            $appOrderId =  isset($input->appOrderId) ? $input->appOrderId : null;;
            $businessId =  $input-> business_id;
            $userId = isset($input->user_id) ? $input->user_id : 2;
            $isDirectSale =  $input-> is_direct_sale;
            $isSuspend =  $input-> is_suspend;
            $isCreditSale =  $input-> is_credit_sale;
            $stripe_token =  $input-> stripe_token;
            $locationId = $input->location_id;
            $status = $input->status;
            $couponValue = !empty($input->coupon_value) ? $input->coupon_value : "";
            $is_coupon_applied = !empty($input->is_coupon_applied) ? $input->is_coupon_applied : false;
            $couponId = !empty($input->coupon_id) ? $input->coupon_id : "";
            $couponType = !empty($input->coupon_type) ? $input->coupon_type : "";
            $couponName = !empty($input->coupon_name) ? $input->coupon_name : "";
            $pax = !empty($input->pax) ? $input->pax : 0;
 
            // Retrieve the transaction based on its ID
            $transaction = Transaction::where('id', $transactionId)->first();
            if(empty($stripe_token)){
                return response()->json(['status' => 'failed', 'msg' => 'Please provide the stripe token']);
            }
            if(!empty($transaction)){
                 if($transaction->status == 'final' && $transaction->payment_status == 'paid')
                {
                    return response()->json(['status' => 'failed', 'msg' => 'Payment already completed']);
                }
                $transaction->status = $status;
                $result = BusinessLocation::where('business_id', $businessId)
                ->where('id', $locationId)
                ->select('stripe_pk', 'stripe_sk', 'lalamove_pk', 'lalamove_sk')
                ->get()
                ->toArray();
                $amount = round($input->final_total, 2) * 100;
                $token = $input->stripe_token;
                $description = $input->type_for_api;
    
                Stripe\Stripe::setApiKey($result[0]['stripe_sk']);
                $charge = \Stripe\Charge::create([
                    "amount" => $amount, //$amount
                    "currency" => "SGD",
                    "source" => $token,
                    "description" => $description
                ]);
                 $stripeResponse = ["id" => $charge->id, "amount" => $charge->amount, "currency" => $charge->currency, "status" => $charge->status, "respond" => $charge];
                 // Check if payment was successful
                 if (isset($stripeResponse['status']) && $stripeResponse['status'] === 'succeeded')
                 {   
                    $stripeRespond = json_encode($stripeResponse['respond']);
                    $stripeStatus = $stripeResponse['status'];
                    $status_before =  $transaction->status;
                   
                    // Check conditions before updating payments
                    if (!$isDirectSale && !$transaction->is_suspend && !empty($payments) && !$isCreditSale) {
                        // Create or update payment lines
                        $this->transactionUtil->createOrUpdatePaymentLines($transaction, $payments, $appOrderId, $businessId, $userId, true, $stripeRespond, $stripeStatus);
                        // Update cash register
                        $sellPayments = $this->cashRegisterUtil->updateSellPayments($status_before, $transaction, $payments, $userId, $appOrderId);
                        $coupon_applied = !empty($is_coupon_applied) && $is_coupon_applied == true ? 1 : 0;
                        Transaction::where('id', $transactionId)->update(['status' => $status, 'payment_status' =>'paid', 'final_total' => $input->final_total, 'round_off_amount' => $input->round_off_amount, 'is_coupon_applied' => $coupon_applied]);
                        if ($sellPayments === false) {
                            return response()->json(['status' => 'failed', 'msg' => 'Currently no cash registers are available, please reset your device']);
                        }

                        if($is_coupon_applied == true) {
                            $couponDetails = [
                                'transaction_id' => $transactionId,
                                'coupon_id' => $couponId, 
                                'coupon_value' => $couponValue, 
                                'coupon_type' => $couponType, 
                                'pax' => $pax, 
                                'coupon_name' => $couponName
                            ];
    
                            CouponUsage::create($couponDetails);

                        }
                    return response()->json(['status' => 'success', 'msg' => 'Payment lines updated successfully']);

                    }
                } else {
                    return response()->json(['status' => 'failed', 'msg' => 'Payment processing failed. Please try again.']);
                }
                
            }else{
                return response()->json(['status' => 'failed', 'msg' => 'Transaction not found']);
            }
         } catch (\Exception $e) {
              \Log::error("Error occurred: " . $e->getMessage());
               return response()->json(['status' => 'failed', 'msg' => 'An error occurred while processing the request'], 500);
        }
    }

    public function CreateClientSecret(Request $request)
    {
        try {
            $input = (object) $request->all(); 
            $payment = $input->payment;
            $currency = $input->currency ;
            $businessId = $input->business_id;
            $locationId = $input->location_id;
    
            if (!empty($payment)) {
                $location = BusinessLocation::where('business_id', $businessId)
                    ->where('id', $locationId)
                    ->select('stripe_pk', 'stripe_sk')
                    ->first(); 
    
                if (!$location || !$location->stripe_sk) {
                    return response()->json(['status' => 'failed', 'msg' => 'Stripe keys not found for the provided location.'], 400);
                }
                \Stripe\Stripe::setApiKey($location->stripe_sk);
                $amount = round($payment, 2) * 100;
                $paymentIntent = \Stripe\PaymentIntent::create([
                    "amount" => $amount,
                    "currency" => $currency
                ]);
                return response()->json(['status' => 'success', 'client_secret' => $paymentIntent->client_secret]);
    
            } else {
                return response()->json(['status' => 'failed', 'msg' => 'Invalid payment amount'], 400);
            }
    
        } catch (\Exception $e) {
            \Log::error("Error occurred while creating PaymentIntent: " . $e->getMessage());
            return response()->json(['status' => 'failed', 'msg' => 'An error occurred while processing the request.'], 500);
        }
    }
    

    function get_all_sales_pagewise (Request $request)
    {
        $user_data = $request->only('business_id', 'location_id', 'token', 'user_id', 'created_at', 'type', 'current_time', 'terminal_id', 'pagination');

        if (isset($user_data['token'])) {
            $result = User::checkUserToken($user_data['token'], $user_data['user_id']);

            if ($result) {
                $user_id = $user_data['user_id'];
                $business_id = $user_data['business_id'];
                $location_id = $user_data['location_id'];
                $transaction_status = "final";
                $created_at = !empty($user_data['created_at']) ? $user_data['created_at'] : "";
                $current_time = (isset($user_data['current_time']) && $user_data['current_time']) ? $user_data['current_time'] : "";
                $type = !empty($user_data['type']) ? $user_data['type'] : "";
                $terminal_id = !empty($user_data['terminal_id']) ? $user_data['terminal_id'] : null;
                $pagination = !empty($user_data['pagination']) ? $user_data['pagination'] : null;

                $all_sale_history = $this->get_sale_history_pagewise($user_id, $business_id, $location_id, $transaction_status, $created_at, $type, null, null, $current_time, $terminal_id, $pagination );

                return $all_sale_history;
            } else {
                return ["errorMessage" => 'Invalid token.'];
            }
        } else {
            return ["errorMessage" => 'Invalid token.'];
        }
    }
    function get_sale_history_pagewise($user_id, $business_id, $location_id, $transaction_status, $created_at, $type, $transaction_id = null, $contact_id = null, $current_time = null, $terminal_id = null, $pagination = null)
    {
        $today = "";
        $tomorrow = "";
        $businessLocation = BusinessLocation::find($location_id);
        if (!empty($businessLocation) && !empty($businessLocation->day_start_time)) {
            $daystartTime = $businessLocation->day_start_time;
            $dayStartTime = $daystartTime . ":00:00";
            $dayendTime = $daystartTime - 1;
            $dayEndTime = $dayendTime . ":59:59";
        } else {
            $dayStartTime = str_replace(' ', '', Config::get('constants.businessStartTimeDefault'));
            $dayEndTime = str_replace(' ', '', Config::get('constants.businessEndTimeDefault'));
        }

        // $dayEndTime = $carbonDayEndTime->format('H:i:s');

        if (isset($dayStartTime) && !empty($businessLocation) && !empty($businessLocation->day_start_time) && !empty($current_time) && !empty($created_at)) {
            $morning6TimeStamp = strtotime($created_at . $dayEndTime);
            $dateTimeStamp = strtotime($created_at . " " . $current_time);
            if ($dateTimeStamp >= $morning6TimeStamp) {
                $today = $created_at . ' ' . $dayStartTime;
                $tomorrow = date('Y-m-d', strtotime($created_at . ' +1 day')) . ' ' . $dayEndTime;
            } else {
                $today = date('Y-m-d', strtotime($created_at . ' -1 day')) . ' ' . $dayStartTime;
                $tomorrow = $created_at . ' ' . $dayEndTime;
            }
        } else {
            $today = $created_at . Config::get('constants.businessStartTimeDefault');
            $tomorrow = $created_at . Config::get('constants.businessEndTimeDefault');
        }

        //dd( $today, $tomorrow );
        $transactionData = [];

        try {
            $query = Transaction::leftjoin('transaction_payments as t', 't.transaction_id', '=', 'transactions.id')
                ->leftjoin('variations as w', 'w.product_id', '=', 'transactions.additional_discount_method')
                ->leftjoin('tax_rates as z', 'z.id', '=', 'transactions.tax_id')
                ->leftJoin('transactions AS SR', 'transactions.id', '=', 'SR.return_parent_id')
                ->with('sell_lines.variations.product.category')
                ->with('payment_lines')
                // ->with('contact')
                ->where('transactions.business_id', $business_id)
                ->where('transactions.location_id', $location_id)
                //->where('transactions.created_by', $user_id)
                ->where('transactions.type', 'sell')
                //->where('transactions.type_for_api', 'Takeaway')
                ->where('transactions.is_direct_sale', 0);

            //For terminal id filter
            if($terminal_id != null){
                $query->where(function($query) use ($terminal_id) {
                    $query->where('transactions.terminal_id', $terminal_id)
                          ->orWhereNull('transactions.terminal_id');
                });
            }

            //For web pickup and delivery
            if ($contact_id != null) {
                $query->where('transactions.contact_id', $contact_id);

                if (!empty($created_at)) {
                    // $query->whereDate('transactions.created_at', $created_at); //2021-08-15 00:00:00
                    $query->whereBetween('transactions.updated_at', [$today, $tomorrow]);
                }
            }

            if ($transaction_id != null) {
                $query->where('transactions.id', $transaction_id);
            }
            // else if($type == 'TrackOrder')
            // {
            //     $query->whereDate('transactions.created_at','=', Carbon::today());
            // }
            else if ($type != 'PickupOrDelivery' && $type != 'TrackOrder' && $contact_id == null) {
                if (!empty($created_at)) {
                    // $query->whereDate('transactions.created_at', $created_at); //2021-08-15 00:00:00
                    $query->whereBetween('transactions.updated_at', [$today, $tomorrow]);
                } else {
                    // $query->whereDate('transactions.created_at', \Carbon::now()->format('Y-m-d 00:00:00'));
                    $query->whereBetween('transactions.updated_at', [$today, $tomorrow]);
                }
            }

            if (!empty($type)) {
                //For web pickup and delivery
                if ($type == 'PickupOrDelivery' || $type == 'Pickup' || $type == 'TrackOrder' || $type == 'Delivery') {
                    $query->leftJoin(
                        'delivery_details AS DD',
                        'transactions.id',
                        '=',
                        'DD.transaction_id'
                    )
                        ->leftJoin(
                            'business_locations AS BL',
                            'DD.outlet',
                            '=',
                            'BL.id'
                        )
                        ->leftJoin(
                            'business_locations AS BLD',
                            'transactions.location_id',
                            '=',
                            'BLD.id'
                        );
                    if ($type == 'PickupOrDelivery') {
                        $query->where(function ($query) use ($contact_id, $business_id, $location_id) {
                            $query->where('transactions.type_for_api', '=', 'Pickup')
                                ->where('transactions.pickup_completed', '=', 1)
                                ->where('transactions.contact_id', $contact_id)
                                ->where('transactions.business_id', $business_id)
                                ->where('transactions.location_id', $location_id);
                        })->orWhere(function ($query) use ($contact_id, $business_id, $location_id) {
                            $query->where('transactions.type_for_api', '=', 'Delivery')
                                ->where('transactions.lalamove_status', '!=', 'ASSIGNING_DRIVER')
                                ->where('transactions.lalamove_status', '!=', 'ON_GOING')
                                ->where('transactions.lalamove_status', '!=', 'PICKED_UP')
                                ->where('transactions.contact_id', $contact_id)
                                ->where('transactions.business_id', $business_id)
                                ->where('transactions.location_id', $location_id);
                        });
                    } else if ($type == 'TrackOrder') {
                        $query->where(function ($query) use ($contact_id, $business_id, $location_id) {
                            $query->where('transactions.type_for_api', '=', 'Pickup')
                                ->where('transactions.pickup_completed', '=', 0)
                                ->where('transactions.contact_id', $contact_id)
                                ->where('transactions.business_id', $business_id)
                                ->where('transactions.location_id', $location_id);
                        })->orWhere(function ($query) use ($contact_id, $business_id, $location_id) {
                            $query->where('transactions.type_for_api', '=', 'Delivery')
                                ->where('transactions.lalamove_status', '!=', 'COMPLETED')
                                ->where('transactions.lalamove_status', '!=', 'EXPIRED')
                                ->where('transactions.lalamove_status', '!=', 'CANCELED')
                                ->where('transactions.lalamove_status', '!=', 'REJECTED')
                                ->where('transactions.contact_id', $contact_id)
                                ->where('transactions.business_id', $business_id)
                                ->where('transactions.location_id', $location_id);
                        });
                    }
                } else {
                    $query->where('transactions.type_for_api', $type);
                }
            } else {
                $query->where(function ($query) {
                    $query->where('transactions.type_for_api', 'Dinein')
                        ->orWhere('transactions.type_for_api', 'Takeaway')
                        ->orWhere('transactions.type_for_api', 'Retail')
                        ->orWhere('transactions.type_for_api', 'Kiosk')
                        ->orWhere('transactions.type_for_api', 'Common');
                });
            }

            if ($transaction_status == 'quotation') {
                $query->where('transactions.status', 'draft')
                    ->where('transactions.sub_status', 'quotation');
            } elseif ($transaction_status == 'draft') {
                $query->where('transactions.status', 'draft')
                    ->whereNull('transactions.sub_status');
            } else {
                $query->where('transactions.status', $transaction_status);
            }

            // $transaction_sub_type = $request->get('transaction_sub_type');
            // if (!empty($transaction_sub_type)) {
            //$query->where('transactions.sub_type', $transaction_sub_type);
            // } else {
            //     $query->where('transactions.sub_type', null);
            // }

            $query->orderBy('transactions.updated_at', 'desc')
                ->groupBy('transactions.id');

            //For web pickup and delivery
            $perPage = $pagination['limit'] ? $pagination['limit'] : 10;
            $pageNumber = $pagination['page_number'] ? $pagination['page_number'] : 1;
            if ($type == 'PickupOrDelivery' || $type == 'Pickup' || $type == 'TrackOrder' || $type == 'Delivery') {
                $transactions = $query->select(
                    'transactions.*',
                    't.amount as received_amount',
                    't.method',
                    't.card_type',
                    't.last_4_card_digits',
                    'w.profit_percent',
                    'z.amount as tax_rate_amount',
                    DB::raw('COUNT(SR.id) as return_exists'),
                    'SR.refund_all',
                    'DD.d_date',
                    'DD.d_time',
                    'DD.d_address',
                    'BL.name as business_location_name_for_pickup',
                    'BL.mobile as business_location_mobile_for_pickup',
                    'BLD.name as business_location_name_for_delivery',
                    'BLD.mobile as business_location_mobile_for_delivery'
                )
                    ->with(['contact'])
                    ->paginate($perPage, ['*'], 'page', $pageNumber);
            } else {
                $transactions = $query->select('transactions.*', 't.amount as received_amount', 't.method', 't.card_type', 't.last_4_card_digits', 'w.profit_percent', 'z.amount as tax_rate_amount', DB::raw('COUNT(SR.id) as return_exists'), 'SR.refund_all')
                    ->with(['contact'])
                    ->paginate($perPage, ['*'], 'page', $pageNumber);
            }
            $pagination_data = [
                'current_page' => $transactions->currentPage(),
                'total_pages' => $transactions->lastPage(),
                'per_page' => $transactions->perPage(),
                'total' => $transactions->total(),
              ];
            $retail_gst = 0;
            $business_tax_rates = TaxRate::where('business_id', $business_id)
                ->get()
                ->toArray();

            for ($i = 0; $i < count($business_tax_rates); $i++) {
                if (strtolower($business_tax_rates[$i]['name']) == 'gst') {
                    $retail_gst = $business_tax_rates[$i]['amount'];
                }
            }

            $businessUtil = new BusinessUtil();
            $business = $businessUtil->getDetails($business_id);
            $pos_settings = json_decode($business->pos_settings);

            //return $transactions;
            $transaction_result = [];
            $total_dont_have_line_discount_amt = 0;
            //$final_total_for_single_item = 0;
            foreach ($transactions as $key => $value) {
                $item = [];
                $payments = [];
                $final_total_for_single_item = 0;
                $final_total_line_discount_amount = 0;
                $service_charge_amount = 0;
                $increment = 0;

                foreach ($value['sell_lines'] as $sellLinesKey => $sellLinesValue) {

                    $total_line_discount_amount = 0;
                    if ($sellLinesValue["parent_sell_line_id"] == null && $sellLinesValue["transaction_id"] == $value['id']) {
                        $adons = [];
                        $combo_adons = [];
                        $total_for_single_item = 0;
                        foreach ($value['sell_lines'] as $sellLinesKey1 => $sellLinesValue1) {
                            if ($sellLinesValue1["parent_sell_line_id"] != null && $sellLinesValue1["parent_sell_line_id"] == $sellLinesValue['id'] && $sellLinesValue1["children_type"] == "modifier") {
                                if (isset($sellLinesValue1['variations']) && !empty($sellLinesValue1['variations'])) {
                                    $adons[] = [
                                        'id' => $sellLinesValue1['variations']->id,
                                        'modifier_set_id' => $sellLinesValue1['variations']->product_id,
                                        'modifier_sell_line_id' => $sellLinesValue1['id'],
                                        'name' => $sellLinesValue1['variations']->name,
                                        'quantity' => $sellLinesValue1["quantity"],
                                        'amount' => $sellLinesValue1['unit_price_before_discount'], //unit_price_before_discount
                                        'not_for_receipt' => $sellLinesValue1['variations']->product->not_for_receipt,
                                        'modifier_app_id' => $sellLinesValue1['modifier_app_ids'],
                                        'name_in_second_language' => $sellLinesValue1['variations']->name_in_second_language,
                                        'short_hand_name' => $sellLinesValue1['variations']->short_hand_name
                                    ];
                                }
                                if ($sellLinesValue["quantity_returned"] == "0.0000" && $sellLinesValue["change_price"] == 0) {
                                    //total modifier price
                                    $total_for_single_item = $total_for_single_item + $sellLinesValue1['unit_price_before_discount'];
                                }

                            } else if ($sellLinesValue1["parent_sell_line_id"] != null && $sellLinesValue1["parent_sell_line_id"] == $sellLinesValue['id'] && $sellLinesValue1["children_type"] == "combo") {
                                $combo_adons[] = [
                                    'transaction_sell_lines_id' => $sellLinesValue1['id'],
                                    'product_id' => $sellLinesValue1['product_id'],
                                    'variation_id' => $sellLinesValue1['variation_id'],
                                    'quantity' => $sellLinesValue1['quantity'],
                                ];
                            }
                        }

                        $sub_unit_id = !empty($sellLinesValue['sub_unit_id']) ? $sellLinesValue['sub_unit_id'] : "";

                        $sub_unit_multiplier = UNIT::where('id', $sub_unit_id)->get();
                        $base_unit_multiplier = !empty($sub_unit_multiplier[0]['base_unit_multiplier']) ? $sub_unit_multiplier[0]['base_unit_multiplier'] : 1;

                        //main item price + modifier price
                        if ($sellLinesValue['weight'] > 0) {

                            $total_for_single_item = ($sellLinesValue['unit_price_before_discount'] + $total_for_single_item) * $sellLinesValue["quantity"];

                            // if(!empty($base_unit_multiplier)) {
                            //     $total_for_single_item = $total_for_single_item/$base_unit_multiplier;
                            // }
                        } else {
                            $total_for_single_item = ($sellLinesValue['unit_price_before_discount'] + $total_for_single_item) * $sellLinesValue["quantity"];

                            // if(!empty($base_unit_multiplier)) {
                            //     $total_for_single_item = $total_for_single_item/$base_unit_multiplier;
                            // }
                        }

                        if ($increment == 0) {
                            $total_dont_have_line_discount_amt = 0;
                        }

                        if ($sellLinesValue["quantity_returned"] == "0.0000") {
                            $final_total_for_single_item += $total_for_single_item;
                            //calculate if line item has line discount
                            if ($sellLinesValue['line_discount_type'] == "fixed") {
                                $total_line_discount_amount += $sellLinesValue['line_discount_amount'];
                            } else if ($sellLinesValue['line_discount_type'] == "percentage") {
                                $total_line_discount_amount = (($sellLinesValue['line_discount_amount'] / 100) * $total_for_single_item) + $total_line_discount_amount;
                            }
                            //calculate final total line discount amount
                            $final_total_line_discount_amount += $total_line_discount_amount;
                            //total if item dont have line discount amount
                            if ($total_line_discount_amount == 0) {
                                $total_dont_have_line_discount_amt += $total_for_single_item;
                            }
                        } 

                        if ($sellLinesValue['added_by_qr'] == 0) {
                            $sellLinesValue['added_by_qr'] = 'false';
                        } else {
                            $sellLinesValue['added_by_qr'] = 'true';
                        }

                        $short_code = null;
                        if (isset($sellLinesValue['variations']->product) && isset($sellLinesValue['variations']->product->category) && isset($sellLinesValue['variations']->product->category->short_code)) {
                            $short_code = $sellLinesValue['variations']->product->category->short_code;
                        }

                        $combo_products = [];
                        $variations = Product::where('business_id', $business_id)
                            ->with(['variations'])
                            ->find($sellLinesValue['product_id']);
                        if (isset($variations['variations']) && $variations['variations'] && count($variations['variations'])) {
                            foreach ($variations['variations'] as $key => $each) {
                                $variation = json_decode($each);
                                if ($variation->combo_variations && count($variation->combo_variations)) {
                                    foreach ($variation->combo_variations as $key => $combo_variation) {
                                        $combo_product = Variation::where('variations.id', $combo_variation->variation_id)
                                            ->join('products AS p', 'variations.product_id', '=', 'p.id')
                                            ->select(['p.*', 'variations.name as variation_name'])
                                            ->first();
                                        $combo_product['quantity'] = round($combo_variation->quantity, 2);
                                        $combo_products[] = $combo_product;
                                    }
                                }
                            }
                        }

                        $sub_unit_id = !empty($sellLinesValue['variations']->product->sub_unit_ids[0]) ? $sellLinesValue['variations']->product->sub_unit_ids[0] : "";

                        $sub_unit_multiplier = UNIT::where('id', $sub_unit_id)->get();
                        $base_unit_multiplier = !empty($sub_unit_multiplier[0]['base_unit_multiplier']) ? $sub_unit_multiplier[0]['base_unit_multiplier'] : 1;

                        $item[] = [
                            'transaction_sell_line_id' => $sellLinesValue['id'],
                            'category_id' => !empty($sellLinesValue['variations']->product->category_id) ? $sellLinesValue['variations']->product->category_id : null,
                            'name' => !empty($sellLinesValue['variations']->product) ? $sellLinesValue['variations']->product->name : null,
                            'short_code' => $short_code,
                            // 'quantity' => $sellLinesValue['quantity']/$base_unit_multiplier,
                            'quantity' => $sellLinesValue['quantity'],
                            'quantity_returned' => $sellLinesValue["quantity_returned"],
                            'quantity_returned_note' => $sellLinesValue["quantity_returned_note"],
                            'unit_id' => !empty($sellLinesValue['variations']->product) ? $sellLinesValue['variations']->product->unit_id : null,
                            // 'sub_unit_id' => $sub_unit_id,
                            'amount' => $sellLinesValue['unit_price_before_discount'],
                            'total_before_tax' => $value['total_before_tax'],
                            'tax_amount' => $value['tax_amount'],
                            'line_discount_type' => $sellLinesValue['line_discount_type'],
                            'line_discount_amount' => $sellLinesValue['line_discount_amount'],
                            'product_id' => $sellLinesValue['product_id'],
                            'variation_id' => $sellLinesValue['variation_id'],
                            'weight' => $sellLinesValue["weight"],
                            'weight_price' => !empty($sellLinesValue['weight_price']) ? $sellLinesValue['weight_price'] : 0,
                            'total_line_discount_amount' => $total_line_discount_amount,
                            'total_for_single_item' => $total_for_single_item,
                            'serve_later_quantity' => $sellLinesValue["serve_later_quantity"],
                            'adons' => $adons,
                            'printed' => $sellLinesValue["printed"],
                            'sell_line_note' => $sellLinesValue["sell_line_note"],
                            'change_price' => $sellLinesValue["change_price"],
                            'combo_variations' => $combo_adons,
                            'app_order_id' => $value['app_order_id'],
                            'app_item_line_id' => $sellLinesValue["app_item_line_id"],
                            'user_id' => $sellLinesValue['user_id'],
                            'added_by_qr' => $sellLinesValue['added_by_qr'],
                            'tag' => !empty($sellLinesValue['tag']) ? $sellLinesValue['tag'] : "",
                            'kitchen_shorthand' => !empty($sellLinesValue['variations']->product->category_id) ? $sellLinesValue['variations']->product->kitchen_shorthand : null,
                            'name_in_second_language' => !empty($sellLinesValue['variations']->product) ? $sellLinesValue['variations']->product->name_in_second_language : null,
                            'show_combo_products' => !empty($sellLinesValue['variations']->product) ? ($sellLinesValue['variations']->product->show_combo_products ? true : false) : null,
                            'combo_products' => $combo_products,
                            'parent_product_group_id' => !empty($sellLinesValue['parent_product_group_id']) ? $sellLinesValue['parent_product_group_id'] : "",
                            'combo_products_category_id' => !empty($sellLinesValue['variations']->product) ? $sellLinesValue['variations']->product->combo_products_category_id : null,
                            'order_placed_by' => !empty($sellLinesValue['order_placed_by']) ? $sellLinesValue['order_placed_by'] : null
                        ];

                        $increment++;
                    }
                }

                if ($value['discount_type'] == "fixed") {
                    $discount_amount = $value['discount_amount'] + $final_total_line_discount_amount;
                } else if ($value['discount_type'] == "percentage") {
                    $discount_amount = ($value['discount_amount'] * $total_dont_have_line_discount_amt) + $final_total_line_discount_amount;
                }

                //calculate service charges
                if($value['rp_redeemed_amount'] > 0) {
                    $service_charge_amount = ($final_total_for_single_item - $discount_amount - $value['rp_redeemed_amount']) * $value['service_charges'];  
                } else {
                    $service_charge_amount = ($final_total_for_single_item - $discount_amount) * $value['service_charges'];
                }

                if($value['return_exists'] == 1) {

                    if($value['discount_type'] == 'fixed') {
                        $discountPercent = ($discount_amount / $value['total_before_tax']) * 100;
                        $discountAmount = ($total_dont_have_line_discount_amt * $discountPercent) / 100;            
                    } else {
                        $discountAmount = $discount_amount; 
                    }   
                    
                    if($value['rp_redeemed_amount'] > 0) {
                        $rp_redeemed_amount_percent = ($value['rp_redeemed_amount'] / $value['total_before_tax']) * 100;
                        $rp_redeemed_amount = ($total_dont_have_line_discount_amt * $rp_redeemed_amount_percent) / 100;

                        $service_charge_amount = ($final_total_for_single_item - $discountAmount - $rp_redeemed_amount) * $value['service_charges'];
                    } else {
                        $service_charge_amount = ($final_total_for_single_item - $discountAmount) * $value['service_charges']; 
                    }
                    
                }

                if ($value['delivery_charges'] != 0) {
                    //calculate tax
                    $tax_amount = 0;
                    if ($value['tax_id'] != null) {
                        if ($value["is_inclusive_gst_applied"])
                            $tax_amount = (($final_total_for_single_item - $discount_amount) / (100 + $value['tax_rate_amount'])) * $value['tax_rate_amount'];
                        else
                            $tax_amount = ($value['tax_rate_amount'] / 100) * ($final_total_for_single_item - $discount_amount);
                    }

                    if ($value['is_inclusive_gst_applied'])
                        $final_total = $final_total_for_single_item + $value['delivery_charges'];
                    else
                        $final_total = $final_total_for_single_item + $tax_amount + $value['delivery_charges'];
                } else {
                    //calculate tax
                    $tax_amount = 0;
                    $refund_tax_amount = 0;

                    if ($value['type_for_api'] == 'Retail') {
                        $tax_amount = ($final_total_for_single_item + $service_charge_amount - $discount_amount) - (($final_total_for_single_item + $service_charge_amount - $discount_amount) / (1 + ($retail_gst / 100)));

                        $final_total = round($final_total_for_single_item, 2) + 0 + round($service_charge_amount, 2) - round($discount_amount, 2);
                    } else {
                        if ($value['tax_id'] != null) {

                            if ($value["is_inclusive_gst_applied"])
                                if($value['return_exists'] == 1) {
                                    $discountPercent = ($discount_amount / $value['total_before_tax']) * 100;
                                    $discountAmount = ($total_dont_have_line_discount_amt * $discountPercent) / 100;

                                    $tax_amount = (($final_total_for_single_item + $service_charge_amount - $discountAmount) / (100 + $value['tax_rate_amount'])) * $value['tax_rate_amount'];
                                    //dd($tax_amount);
                                //$tax_amount = (($final_total_for_single_item + $service_charge_amount ) / (100 + $value['tax_rate_amount'])) * $value['tax_rate_amount'];
                                } else {
                                    if($value['rp_redeemed_amount'] > 0) {
                                        $tax_amount = (($final_total_for_single_item + $service_charge_amount - $discount_amount - $value['rp_redeemed_amount']) / (100 + $value['tax_rate_amount'])) * $value['tax_rate_amount']; 
                                   } else {
                                        $tax_amount = (($final_total_for_single_item + $service_charge_amount - $discount_amount) / (100 + $value['tax_rate_amount'])) * $value['tax_rate_amount'];
                                   }
                                    
                                    //dd($tax_amount);
                                //$tax_amount = (($final_total_for_single_item + $service_charge_amount ) / (100 + $value['tax_rate_amount'])) * $value['tax_rate_amount'];
                                }
                                
                            else
                                if($discount_amount != 0 && $value['total_before_tax']) {
                                    $discountPercent = ($discount_amount / $value['total_before_tax']) * 100;
                                    $discountAmount = ($total_dont_have_line_discount_amt * $discountPercent) / 100;
                                    if($value['rp_redeemed_amount'] > 0) {
                                        $tax_amount = ($value['tax_rate_amount'] / 100) * ($final_total_for_single_item + $service_charge_amount - $discountAmount - $value['rp_redeemed_amount']);
                                    } else {
                                        $tax_amount = ($value['tax_rate_amount'] / 100) * ($final_total_for_single_item + $service_charge_amount - $discountAmount);
                                    }
                                    
                                } else {
                                    if($value['rp_redeemed_amount'] > 0) {
                                        $tax_amount = ($value['tax_rate_amount'] / 100) * ($final_total_for_single_item + $service_charge_amount - $discountAmount - $value['rp_redeemed_amount']);
                                    } else {
                                        $tax_amount = ($value['tax_rate_amount'] / 100) * ($final_total_for_single_item + $service_charge_amount - $discount_amount);
                                    }
                                    
                                }
                                
                        }

                        if ($value['is_inclusive_gst_applied'])
                            
                            if($value['return_exists'] == 1) {
                                $discountPercent = ($discount_amount / $value['total_before_tax']) * 100;
                                $discountAmount = ($total_dont_have_line_discount_amt * $discountPercent) / 100;   

                                if($value['discount_type'] == 'fixed') {
                                    $final_total = round($final_total_for_single_item, 2) + round($service_charge_amount, 2) - $discountAmount;
                                } else {
                                    $final_total = round($final_total_for_single_item, 2) + round($service_charge_amount, 2) - round($discount_amount, 2);

                                }

                            } else {
                                $final_total = round($final_total_for_single_item, 2) + round($service_charge_amount, 2) - round($discount_amount, 2);
                            }
                            
                        else
                            if($value['return_exists'] == 1) {
                                $final_total = round($final_total_for_single_item, 2) + round($tax_amount, 2) + round($service_charge_amount, 2);
                            } else {
                                $final_total = round($final_total_for_single_item, 2) + round($tax_amount, 2) + round($service_charge_amount, 2) - round($discount_amount, 2);
                            }
                            
                    }
                }
                if($value['return_exists'] == 1) {
                   $final_total = round($final_total + $value['round_off_amount'], 2);
                }
                // $amount_rounding_method = $pos_settings->amount_rounding_method;
                $amount_rounding_method = $value['amount_rounding_method']; 
                $payment_method = $value->method;
                // $latest_round_off_amount = $this->transactionUtil->latest_round_off_amount($payment_method, $final_total, $amount_rounding_method, $value['type_for_api']);
                $latest_round_off_amount = $value['round_off_amount'];
                $final_total = round($final_total - $value['round_off_amount'], 2);
                if ($value['return_exists'] == 1){
                    if($value['discount_type'] == "fixed")  {
                        $discountPercent = ($discount_amount / $value['total_before_tax']) * 100;
                        $discountAmount = ($total_dont_have_line_discount_amt * $discountPercent) / 100;
                        $discount_amount = $discountAmount;
                    }
                }

                if($value['rp_redeemed_amount'] > 0 && $value['return_exists'] != 1) {
                    $final_total = $final_total - $value['rp_redeemed_amount'];
                } elseif($value['rp_redeemed_amount'] > 0 && $value['return_exists'] == 1) {
                    $rp_redeemed_amount_percent = ($value['rp_redeemed_amount'] / $value['total_before_tax']) * 100;
                    $rp_redeemed_amount = ($total_dont_have_line_discount_amt * $rp_redeemed_amount_percent) / 100;

                    $final_total = $final_total - $rp_redeemed_amount;
                }
            
                // For multiple payment
                foreach ($value['payment_lines'] as $payment_lines_key => $payment_line) {
                    if (count($value['payment_lines']) == 1) {
                        if ($final_total > 0) {
                            // $is_rounding_applied = $this->transactionUtil->isRoundingApply($final_total);
                            if(!empty($value['round_off_amount']))
                            {
                                $cash_received_amount = $final_total; //+ $latest_round_off_amount;    
                            }
                            else {
                                $cash_received_amount = $final_total;
                            }
                            
                        } else {
                            $cash_received_amount = $final_total;
                        }
                    } else {
                        if ($value['refund_all'] == 1) {
                            $cash_received_amount = 0;
                        } else {
                            $cash_received_amount = $payment_line['amount'];
                        }
                    }
                    $payments[] = [
                        'transaction_payment_id' => $payment_line['id'],
                        'method' => $payment_line['method'],
                        'card_type' => $payment_line['card_type'],
                        'last_4_card_digits' => $payment_line['last_4_card_digits'],
                        'received_amount' => $cash_received_amount
                    ];
                }

                $table_arr = [];
                $table_name = [];
                $pax = '';

                $table_query = Transaction::leftjoin('pos_res_tables as t', 't.transaction_id', '=', 'transactions.id')
                    ->leftjoin('res_tables as z', 'z.id', '=', 't.res_table_id')
                    ->where('transactions.id', $value['id'])
                    ->select('t.res_table_id', 'pax', 'z.name')
                    ->get();
                // ->dump();

                if (!empty($table_query)) {
                    foreach ($table_query as $key => $tableValue) {
                        if ($tableValue['res_table_id'] != null) {
                            array_push($table_arr, $tableValue['res_table_id']);
                            array_push($table_name, $tableValue['name']);
                            $pax = $tableValue['pax'];
                        }
                    }
                }

                //For web pickup and delivery
                if ($type == 'PickupOrDelivery' || $type == 'Pickup' || $type == 'TrackOrder' || $type == 'Delivery') {
                    $last_4_card_digits = "**** **** **** " . $value['last_4_card_digits'];
                    $d_date = $value['d_date'];
                    $d_time = $value['d_time'];
                    $d_address = $value['d_address'];
                    $business_location_name_for_pickup = $value['business_location_name_for_pickup'];
                    $business_location_mobile_for_pickup = $value['business_location_mobile_for_pickup'];
                    $business_location_name_for_delivery = $value['business_location_name_for_delivery'];
                    $business_location_mobile_for_delivery = $value['business_location_mobile_for_delivery'];
                    $order_no = $value['order_no'];
                    $pickup_completed = $value['pickup_completed'];
                    $lalamove_orderRef = $value['lalamove_orderRef'];
                    $lalamove_status = $value['lalamove_status'];
                    $lalamove_driver_info = '';
                    if ($type == 'Delivery') {
                        $order = json_decode($value['lalamove_result'], true);
                        if (!empty($order)) {
                            if (!empty($order['data']['order']['driverId'])) {
                                $lalamove_driver_id = $order['data']['order']['driverId'];
                            } else if (!empty($order['driverId'])) {
                                $lalamove_driver_id = $order['driverId'];
                            } else {
                                $lalamove_driver_id = '';
                            }

                            if ($lalamove_driver_id != '') {
                                $lalamove_driver_info = $this->check_driver_details($lalamove_orderRef, $lalamove_driver_id, $value['business_id'], $value['location_id']);
                                $lalamove_driver_info = json_decode($lalamove_driver_info, true);
                            }
                        }
                    }
                } else {
                    $last_4_card_digits = '';
                    $d_date = '';
                    $d_time = '';
                    $d_address = '';
                    $business_location_name_for_pickup = '';
                    $business_location_mobile_for_pickup = '';
                    $business_location_name_for_delivery = '';
                    $business_location_mobile_for_delivery = '';
                    $order_no = '';
                    $pickup_completed = '';
                    $lalamove_orderRef = '';
                    $lalamove_status = '';
                    $lalamove_driver_info = '';
                }

                $check_contact_access = Contact::join('user_contact_access AS uca', 'contacts.id', 'uca.contact_id')
                    ->where('uca.contact_id', $value['contact_id'])->first();

                if ($check_contact_access) {
                    $user_query = User::where('id', $check_contact_access->user_id)->first();

                    $member_mobile = $user_query->contact_number;
                    $member_dob = $user_query->dob;
                } else {
                    $member_mobile = "";
                    $member_dob = "";
                }

                // //Temperorary condition
                // if($value['rp_redeemed_amount'] > 0 ) {
                //     $tax_amount = 0;
                // }
                

                $transaction_result[] = [
                    'app_order_id' => $value['app_order_id'],
                    'id' => $value['id'],
                    'terminal_id' => !empty($value['terminal_id']) ? $value['terminal_id'] : "",
                    'business_id' => $value['business_id'],
                    'location_id' => $value['location_id'],
                    'transaction_date' => $value['transaction_date'],
                    'table_id' => $table_arr,
                    'table_name' => $table_name,
                    'pax' => $pax,
                    'invoice_no' => $value['invoice_no'],
                    'order_check_no' => $value['order_check_no'],
                    'ref_no' => $value['ref_no'],
                    'order_no' => $value['order_no'],
                    'type' => $value['type'],
                    'type_for_api' => $value['type_for_api'],
                    'total' => $final_total,
                    'round_off_amount' => round($latest_round_off_amount, 2),
                    'paymentType' => $value['method'],
                    'card_type' => $value['card_type'],
                    'tax_id' => $value['tax_id'],
                    'contact_id' => $value['contact_id'],
                    'tax_amount' => $tax_amount,
                    'addon_discount' => ($value['profit_percent'] == null ? 0 : $value['profit_percent']),
                    'discount_type' => $value['discount_type'],
                    'discount_amount' => $discount_amount,
                    'service_charge' => $value['service_charges'],
                    'delivery_charge' => $value['delivery_charges'],
                    'reward_amount' => $value['rp_redeemed'],
                    'customer_reward_amount' => $value['rp_redeemed_amount'],
                    'service_charge_amount' => $service_charge_amount,
                    'tax_rate_amount' => $value['tax_rate_amount'],
                    'profit_percent' => $value['profit_percent'],
                    'return_exists' => $value['return_exists'],
                    'refund_all' => $value['refund_all'],
                    'total_dont_have_line_discount_amt' => $total_dont_have_line_discount_amt,
                    //'total_line_discount_amount' => $total_line_discount_amount,
                    'final_total_for_single_item' => $final_total_for_single_item,
                    'received_amount' => $value['received_amount'],
                    'last_4_card_digits' => $last_4_card_digits,
                    'd_date' => $d_date,
                    'd_time' => $d_time,
                    'd_address' => $d_address,
                    'business_location_name_for_pickup' => $business_location_name_for_pickup,
                    'business_location_mobile_for_pickup' => $business_location_mobile_for_pickup,
                    'business_location_name_for_delivery' => $business_location_name_for_delivery,
                    'business_location_mobile_for_delivery' => $business_location_mobile_for_delivery,
                    'order_no' => $order_no,
                    'pickup_completed' => $pickup_completed,
                    'lalamove_orderRef' => $lalamove_orderRef,
                    'lalamove_status' => $lalamove_status,
                    'lalamove_driver_info' => $lalamove_driver_info,
                    'shipping_charges' => $value['shipping_charges'],
                    'first_name' => $value['contact']->first_name,
                    'last_name' => $value['contact']->last_name,
                    'estimated_arrival_time' => Carbon::parse(Carbon::parse($value['transaction_date'])->addHour())->format('d/m/Y h:ia'),
                    'updated_at' => Carbon::parse($value['updated_at'])->format('d/m/Y h:ia'),
                    'deposit' => $value['deposit'],
                    'member_mobile' => $member_mobile,
                    'member_dob' => $member_dob,
                    'item' => $item,
                    'payments' => $payments,
                    'is_inclusive_gst_applied' => $value['is_inclusive_gst_applied'] ? true : false,
                    'tag_number' => $value['tag_number'],
                    'discount_type_id' => $value['discount_type_id'],
                    'open_discount_value' => $value['open_discount_value'],
                    'commission_type' => $value['commission_type'],
                    'status' => $value['status'],
                    'extra_tag' => !empty($value['extra_tag']) ? $value['extra_tag'] : null,
                    'cash_change_amount' => $value['cash_change_amount'],
                    'cash_received_amount' => $value['cash_received_amount'],
                    'order_platform' => $value['order_platform'],
                    'rp_unit_per_amount' => $value['rp_unit_per_amount']
                ];

            }
            if ($transaction_id == null && $type != 'PickupOrDelivery') {
                $query = CashRegister::where('business_id', $business_id)
                    ->where('location_id', $location_id)
                    ->with(['cash_register_transactions'])
                    ->where('user_id', $user_id);

                // dd( $today, $tomorrow );

                if (!empty($created_at)) {
                    // $query->whereDate('cash_registers.created_at', $created_at);
                    $query->whereBetween('cash_registers.created_at', [$today, $tomorrow]);
                } else {
                    $query->whereDate('cash_registers.created_at', \Carbon::now()->format('Y-m-d 00:00:00'));
                }

                $cash_registers = $query->get();


                // Remove Business Open/Close Time once tested properly FC
                return [
                    "sells" => $transaction_result,
                    "cash_registers" => $cash_registers,
                    "business_time" => [
                        "start" => preg_replace('/\s+/', '', $dayStartTime),
                        "end" => preg_replace('/\s+/', '', $dayEndTime)
                    ],
                    "business_location_timing" => [
                        "start" => $today,
                        "end" => $tomorrow
                    ],
                    "pagination"=>$pagination_data
                ];
            } else {
                return ["sells" => $transaction_result, "pagination"=>$pagination_data,  "transactionsData"=>$transactionsData];
            }
        } catch (\Exception $e) {
            DB::rollBack();

            \Log::emergency("File:" . $e->getFile() . "Line:" . $e->getLine() . "Message:" . $e->getMessage());
            $msg = __('messages.something_went_wrong');

            $output = [
                'errorMessage' => $msg
            ];

            return $output;
        }
    }

 public function digital_ordering_stripe_payment_for_payfirst($input, $transaction)
    {
        try {

            // Extract required data from the request
            // $input = (Object) $request->all();
            $transactionId =  $transaction->id;
            $payments =  $input-> payment;
            $appOrderId =  isset($input->appOrderId) ? $input->appOrderId : null;;
            $businessId =  $input-> business_id;
            $userId = isset($input->user_id) ? $input->user_id : 2;
            $isDirectSale =  $input-> is_direct_sale;
            $isSuspend =  $input-> is_suspend;
            $isCreditSale =  $input-> is_credit_sale;
            $stripe_token =  $input->stripe_token;
            $locationId = $input->location_id;
            $status = $input->status;
            $couponValue = !empty($input->coupon_value) ? $input->coupon_value : "";
            $is_coupon_applied = !empty($input->is_coupon_applied) ? $input->is_coupon_applied : false;
            $couponId = !empty($input->coupon_id) ? $input->coupon_id : "";
            $couponType = !empty($input->coupon_type) ? $input->coupon_type : "";
            $couponName = !empty($input->coupon_name) ? $input->coupon_name : "";
            $pax = !empty($input->pax) ? $input->pax : 0;
            $razer_payment_token = !empty($input->razer_payment_token) ? $input->razer_payment_token : null; 
 
            // Retrieve the transaction based on its ID
            $transaction = Transaction::where('id', $transactionId)->first();
           
            if(!empty($transaction)){
                
                $transaction->status = $status;
                // $amount = round($input->final_total, 2) * 100;
                // $token = $input->stripe_token;
                // $description = $input->type_for_api;
                $stripeStatus ="";  
                $stripeRespond = null;  
                $razer_payment_gateway_response=null;
                if(!empty($input['stripe_response'])){
                    $stripeRespond = $input['stripe_response'];
                    $stripeStatus = $stripeRespond->status;  
                    $stripeRespond = json_encode($stripeRespond);   
                }
                else{
                    $secretKey = env('JWT_SECRET', '#tyvagsdhkhggjakk_62');
                        $decoded = JWT::decode($razer_payment_token, new Key($secretKey, 'HS256'));
                        $decodedArray = (array) $decoded;
                        $payloadData = $decodedArray['data'];
                        $razer_payment_gateway_response = json_encode($payloadData); 
                                    
                    }                                  
                    // Check conditions before updating payments
                    if (!$isDirectSale && !$transaction->is_suspend && !empty($payments) && !$isCreditSale) {
                        // Create or update payment lines
                        $transaction_payment = $this->transactionUtil->createOrUpdatePaymentLines($transaction, $payments, $appOrderId, $businessId, $userId, true, $stripeRespond, $stripeStatus, $razer_payment_gateway_response);
                        // Update cash register
                        // $sellPayments = $this->cashRegisterUtil->createSellPayments($status_before, $transaction, $payments, $userId, $appOrderId);
                        $coupon_applied = !empty($is_coupon_applied) && $is_coupon_applied == true ? 1 : 0;
                        Transaction::where('id', $transactionId)->update(['status' => $status, 'payment_status' =>'paid', 'final_total' => $input->final_total, 'round_off_amount' => $input->round_off_amount, 'is_coupon_applied' => $coupon_applied]);
                        if ($sellPayments === false) {
                            return response()->json(['status' => 'failed', 'msg' => 'Currently no cash registers are available, please reset your device']);
                        }

                        if($is_coupon_applied == true) {
                            $couponDetails = [
                                'transaction_id' => $transactionId,
                                'coupon_id' => $couponId, 
                                'coupon_value' => $couponValue, 
                                'coupon_type' => $couponType, 
                                'pax' => $pax, 
                                'coupon_name' => $couponName
                            ];
    
                            CouponUsage::create($couponDetails);

                        }
                        return ['status' => 'success', 'msg' => '', 'data'=>$transaction_payment];

                    }
                
            }else{
                return ['status' => 'failed', 'msg' => 'Transaction not found'];
            }
         } catch (\Exception $e) {
              \Log::error("Error occurred: " . $e->getMessage());
               return ['status' => 'failed', 'msg' => 'An error occurred while processing the request'];
        }
    }
   

    function guest_user_order_history(Request $request)
    {
        $user_data = $request->only('business_id', 'location_id', 'token', 'user_id', 'contact_id','guest_user_id');

        $user_id = $user_data['user_id'];
        $business_id = $user_data['business_id'];
        $location_id = $user_data['location_id'];
        $transaction_status = "final";
        $type = "";
        $guest_user_id = $user_data['guest_user_id'];

        $all_sale_history = $this->guest_users_order_history($user_id, $business_id, $location_id, $transaction_status, $type, null, $guest_user_id);

        return $all_sale_history;

    }

    function guest_users_order_history($user_id, $business_id, $location_id, $transaction_status, $type, $transaction_id = null, $guest_user_id = null)
    {

        try {
            if(!empty($guest_user_id))
            {


                $query = Transaction::leftjoin('transaction_payments as t', 't.transaction_id', '=', 'transactions.id')
                    // ->leftjoin('business as b', 'b.id', '=', 'transactions.business_id')
                    // ->leftjoin('users as u', 'u.business_id', '=', 'b.id')
                    ->leftjoin('variations as w', 'w.product_id', '=', 'transactions.additional_discount_method')
                    ->leftjoin('tax_rates as z', 'z.id', '=', 'transactions.tax_id')
                    ->leftJoin('transactions AS SR', 'transactions.id', '=', 'SR.return_parent_id')
                    // ->leftJoin('transaction_sell_lines AS tsl', 'u.id', '=', 'tsl.order_placed_by')
                    ->with('sell_lines.variations.product.category')
                    ->with('payment_lines')
                    // ->with('contact')
                    ->where('transactions.business_id', $business_id)
                    ->where('transactions.location_id', $location_id)
                    //->where('transactions.created_by', $user_id)
                    ->where('transactions.type', 'sell')
                    //->where('transactions.type_for_api', 'Takeaway')
                    ->where('transactions.is_direct_sale', 0)
                    ->where('transactions.guest_user_id', $guest_user_id);
                    // ->limit(5); 
                    // ->where('tsl.order_placed_by', $user_id);


                    //For web pickup and delivery
                   // if ($guest_user_id != null) {
                   //      $query->where(function($query) use ($contact_id) {
                   //          $query->where('transactions.contact_id', $contact_id)
                   //                ->orWhereRaw('FIND_IN_SET(?, transactions.contact_ids)', [$contact_id]);
                   //      });

                    // if (!empty($created_at)) {
                    //     // $query->whereDate('transactions.created_at', $created_at); //2021-08-15 00:00:00
                    //     $query->whereBetween('transactions.created_at', [$today, $tomorrow]);
                    // }
              //  }

                if ($transaction_id != null) {
                    $query->where('transactions.id', $transaction_id);
                }
                // else if($type == 'TrackOrder')
                // {
                //     $query->whereDate('transactions.created_at','=', Carbon::today());
                // }
                else if ($type != 'PickupOrDelivery' && $type != 'TrackOrder') {
                    // if (!empty($created_at)) {
                    //     // $query->whereDate('transactions.created_at', $created_at); //2021-08-15 00:00:00
                    //     $query->whereBetween('transactions.created_at', [$today, $tomorrow]);
                    // } else {
                    //     // $query->whereDate('transactions.created_at', \Carbon::now()->format('Y-m-d 00:00:00'));
                    //     $query->whereBetween('transactions.created_at', [$today, $tomorrow]);
                    // }
                }

                if (!empty($type)) {
                    //For web pickup and delivery
                    if ($type == 'PickupOrDelivery' || $type == 'Pickup' || $type == 'TrackOrder' || $type == 'Delivery') {
                        $query->leftJoin(
                            'delivery_details AS DD',
                            'transactions.id',
                            '=',
                            'DD.transaction_id'
                        )
                            ->leftJoin(
                                'business_locations AS BL',
                                'DD.outlet',
                                '=',
                                'BL.id'
                            )
                            ->leftJoin(
                                'business_locations AS BLD',
                                'transactions.location_id',
                                '=',
                                'BLD.id'
                            );
                        if ($type == 'PickupOrDelivery') {
                            $query->where(function ($query) use ($contact_id, $business_id, $location_id) {
                                $query->where('transactions.type_for_api', '=', 'Pickup')
                                    ->where('transactions.pickup_completed', '=', 1)
                                    ->where('transactions.contact_id', $contact_id)
                                    ->where('transactions.business_id', $business_id)
                                    ->where('transactions.location_id', $location_id);
                            })->orWhere(function ($query) use ($contact_id, $business_id, $location_id) {
                                $query->where('transactions.type_for_api', '=', 'Delivery')
                                    ->where('transactions.lalamove_status', '!=', 'ASSIGNING_DRIVER')
                                    ->where('transactions.lalamove_status', '!=', 'ON_GOING')
                                    ->where('transactions.lalamove_status', '!=', 'PICKED_UP')
                                    ->where('transactions.contact_id', $contact_id)
                                    ->where('transactions.business_id', $business_id)
                                    ->where('transactions.location_id', $location_id);
                            });
                        } else if ($type == 'TrackOrder') {
                            $query->where(function ($query) use ($contact_id, $business_id, $location_id) {
                                $query->where('transactions.type_for_api', '=', 'Pickup')
                                    ->where('transactions.pickup_completed', '=', 0)
                                    ->where('transactions.contact_id', $contact_id)
                                    ->where('transactions.business_id', $business_id)
                                    ->where('transactions.location_id', $location_id);
                            })->orWhere(function ($query) use ($contact_id, $business_id, $location_id) {
                                $query->where('transactions.type_for_api', '=', 'Delivery')
                                    ->where('transactions.lalamove_status', '!=', 'COMPLETED')
                                    ->where('transactions.lalamove_status', '!=', 'EXPIRED')
                                    ->where('transactions.lalamove_status', '!=', 'CANCELED')
                                    ->where('transactions.lalamove_status', '!=', 'REJECTED')
                                    ->where('transactions.contact_id', $contact_id)
                                    ->where('transactions.business_id', $business_id)
                                    ->where('transactions.location_id', $location_id);
                            });
                        }
                    } else {
                        $query->where('transactions.type_for_api', $type);
                    }
                } else {
                    $query->where(function ($query) {
                        $query->where('transactions.type_for_api', 'Dinein')
                            ->orWhere('transactions.type_for_api', 'Takeaway')
                            ->orWhere('transactions.type_for_api', 'Retail')
                            ->orWhere('transactions.type_for_api', 'Kiosk')
                            ->orWhere('transactions.type_for_api', 'Common');
                    });
                }

                if ($transaction_status == 'quotation') {
                    $query->where('transactions.status', 'draft')
                        ->where('transactions.sub_status', 'quotation');
                } elseif ($transaction_status == 'draft') {
                    $query->where('transactions.status', 'draft')
                        ->whereNull('transactions.sub_status');
                } else {
                    //$query->where('transactions.status', $transaction_status);
                    $query->whereIn('transactions.status', ['final', 'draft']);
                }

                // $transaction_sub_type = $request->get('transaction_sub_type');
                // if (!empty($transaction_sub_type)) {
                //$query->where('transactions.sub_type', $transaction_sub_type);
                // } else {
                //     $query->where('transactions.sub_type', null);
                // }

                $query->orderBy('transactions.created_at', 'desc')
                    ->groupBy('transactions.id');

                //For web pickup and delivery
                if ($type == 'PickupOrDelivery' || $type == 'Pickup' || $type == 'TrackOrder' || $type == 'Delivery') {
                    $transactions = $query->select(
                        'transactions.*',
                        't.amount as received_amount',
                        't.method',
                        't.card_type',
                        't.last_4_card_digits',
                        'w.profit_percent',
                        'z.amount as tax_rate_amount',
                        DB::raw('COUNT(SR.id) as return_exists'),
                        'SR.refund_all',
                        'DD.d_date',
                        'DD.d_time',
                        'DD.d_address',
                        'BL.name as business_location_name_for_pickup',
                        'BL.mobile as business_location_mobile_for_pickup',
                        'BLD.name as business_location_name_for_delivery',
                        'BLD.mobile as business_location_mobile_for_delivery'
                    )
                        ->with(['contact'])
                        ->get();
                } else {
                    $transactions = $query->select('transactions.*', 't.amount as received_amount', 't.method', 't.card_type', 't.last_4_card_digits', 'w.profit_percent', 'z.amount as tax_rate_amount', DB::raw('COUNT(SR.id) as return_exists'), 'SR.refund_all')
                        ->with(['contact'])
                        //->limit(5)
                        ->get();
                }

                $retail_gst = 0;
                $business_tax_rates = TaxRate::where('business_id', $business_id)
                    ->get()
                    ->toArray();

                for ($i = 0; $i < count($business_tax_rates); $i++) {
                    if (strtolower($business_tax_rates[$i]['name']) == 'gst') {
                        $retail_gst = $business_tax_rates[$i]['amount'];
                    }
                }

                $businessUtil = new BusinessUtil();
                $business = $businessUtil->getDetails($business_id);
                $pos_settings = json_decode($business->pos_settings);

                //return $transactions;
                $transaction_result = [];
                $total_dont_have_line_discount_amt = 0;
                //$final_total_for_single_item = 0;

                foreach ($transactions as $key => $value) {
                    $item = [];
                    $payments = [];
                    $final_total_for_single_item = 0;
                    $final_total_line_discount_amount = 0;
                    $service_charge_amount = 0;
                    $increment = 0;
                    $sellArray1 = $value['sell_lines'];
                    $finalItems = [];
                    foreach ($sellArray1->toArray() as $key => $item_sellLine) {
                        if ($item_sellLine['parent_sell_line_id'] == null) { 
                            $mainItem = $item_sellLine;
                            // dd($mainItem);
                            $mainItemPrice = $mainItem['unit_price_before_discount'];
                            foreach ($sellArray1->toArray() as $modifier) {
                                if (!empty($modifier['parent_sell_line_id']) && $modifier['parent_sell_line_id'] == $mainItem['id'] && $item_sellLine["change_price"] == 0 && $modifier["children_type"] == "modifier") {
                                    $mainItemPrice += $modifier['unit_price_before_discount']; // Add the modifier price to the main product price
                                }
                            }
                            // Update the main product price
                            $mainItem['unit_price_before_discount'] = $mainItemPrice;
                            // Add the updated main item to the final result array
                            $finalItems[] = $mainItem;
                        }
                    }        
                    $dineService  = $this->calculateItemTotalForDineIn($finalItems, $value['type_for_api'], $value['discount_amount'], $value['discount_type'], $value['rp_redeemed_amount'], $value['id']);

                    foreach ($value['sell_lines'] as $sellLinesKey => $sellLinesValue) {

                        $total_line_discount_amount = 0;
                        if ($sellLinesValue["parent_sell_line_id"] == null && $sellLinesValue["transaction_id"] == $value['id']) {
                            $adons = [];
                            $combo_adons = [];
                            $total_for_single_item = 0;
                            foreach ($value['sell_lines'] as $sellLinesKey1 => $sellLinesValue1) {
                                if ($sellLinesValue1["parent_sell_line_id"] != null && $sellLinesValue1["parent_sell_line_id"] == $sellLinesValue['id'] && $sellLinesValue1["children_type"] == "modifier") {
                                    if (isset($sellLinesValue1['variations']) && !empty($sellLinesValue1['variations'])) {
                                        $adons[] = [
                                            'id' => $sellLinesValue1['variations']->id,
                                            'modifier_set_id' => $sellLinesValue1['variations']->product_id,
                                            'modifier_sell_line_id' => $sellLinesValue1['id'],
                                            'name' => $sellLinesValue1['variations']->name,
                                            'quantity' => $sellLinesValue1["quantity"],
                                            'amount' => $sellLinesValue1['unit_price_before_discount'], //unit_price_before_discount
                                            'not_for_receipt' => $sellLinesValue1['variations']->product->not_for_receipt,
                                            'modifier_app_id' => $sellLinesValue1['modifier_app_ids'],
                                            'name_in_second_language' => $sellLinesValue1['variations']->name_in_second_language,
                                            'short_hand_name' => $sellLinesValue1['variations']->short_hand_name,
                                            'merge_qty' => $sellLinesValue1['product']->merge_qty
                                        ];
                                    }
                                    if ($sellLinesValue["quantity_returned"] == "0.0000" && $sellLinesValue["change_price"] == 0) {
                                        //total modifier price
                                        $total_for_single_item = $total_for_single_item + $sellLinesValue1['unit_price_before_discount'];
                                    }
                                } else if ($sellLinesValue1["parent_sell_line_id"] != null && $sellLinesValue1["parent_sell_line_id"] == $sellLinesValue['id'] && $sellLinesValue1["children_type"] == "combo") {
                                    $combo_adons[] = [
                                        'transaction_sell_lines_id' => $sellLinesValue1['id'],
                                        'product_id' => $sellLinesValue1['product_id'],
                                        'variation_id' => $sellLinesValue1['variation_id'],
                                        'quantity' => $sellLinesValue1['quantity'],
                                    ];
                                }
                            }

                            $sub_unit_id = !empty($sellLinesValue['sub_unit_id']) ? $sellLinesValue['sub_unit_id'] : "";
                            $sub_unit_multiplier = UNIT::where('id', $sub_unit_id)->get();

                            $base_unit_multiplier = !empty($sub_unit_multiplier[0]['base_unit_multiplier']) ? $sub_unit_multiplier[0]['base_unit_multiplier'] : 1;
                            //main item price + modifier price
                            if ($sellLinesValue['weight'] > 0) {
                                $total_for_single_item = ($sellLinesValue['unit_price_before_discount'] + $total_for_single_item) * $sellLinesValue["quantity"];
                            } else {
                                $total_for_single_item = ($sellLinesValue['unit_price_before_discount'] + $total_for_single_item) * $sellLinesValue["quantity"];
                            }

                            if ($increment == 0) {
                                $total_dont_have_line_discount_amt = 0;
                            }

                            if ($sellLinesValue["quantity_returned"] == "0.0000") {
                                $final_total_for_single_item += $total_for_single_item;
                                //calculate if line item has line discount
                                if ($sellLinesValue['line_discount_type'] == "fixed") {
                                    $total_line_discount_amount += $sellLinesValue['line_discount_amount'];
                                } else if ($sellLinesValue['line_discount_type'] == "percentage") {
                                    $total_line_discount_amount = (($sellLinesValue['line_discount_amount'] / 100) * $total_for_single_item) + $total_line_discount_amount;
                                }
                                //calculate final total line discount amount
                                $final_total_line_discount_amount += $total_line_discount_amount;
                                //total if item dont have line discount amount
                                if ($total_line_discount_amount == 0) {
                                    $total_dont_have_line_discount_amt += $total_for_single_item;
                                }
                            }

                            if ($sellLinesValue['added_by_qr'] == 0) {
                                $sellLinesValue['added_by_qr'] = 'false';
                            } else {
                                $sellLinesValue['added_by_qr'] = 'true';
                            }
            
                            $combo_products = [];
                            $variations = Product::where('business_id', $business_id)
                                ->with(['variations'])
                                ->find($sellLinesValue['product_id']);
                            if (isset($variations['variations']) && $variations['variations'] && count($variations['variations'])) {
                                foreach ($variations['variations'] as $key => $each) {
                                    $variation = json_decode($each);
                                    if ($variation->combo_variations && count($variation->combo_variations)) {
                                        foreach ($variation->combo_variations as $key => $combo_variation) {
                                            $combo_product = Variation::where('variations.id', $combo_variation->variation_id)
                                                ->join('products AS p', 'variations.product_id', '=', 'p.id')
                                                ->select(['p.*', 'variations.name as variation_name'])
                                                ->first();
                                            $combo_product['quantity'] = round($combo_variation->quantity, 2);

                                            $not_for_selling_by_pos_locations = $combo_product['not_for_selling_by_pos_locations'];

                                            if (is_null($not_for_selling_by_pos_locations) || $not_for_selling_by_pos_locations === "[]") {
                                                $combo_product['not_for_selling_by_pos_locations'] = []; 
                                            } else {
                                                $decoded = json_decode($not_for_selling_by_pos_locations, true);

                                                if (json_last_error() === JSON_ERROR_NONE) {
                                                    $combo_product['not_for_selling_by_pos_locations'] = $decoded; 
                                                } else {
                                                    $combo_product['not_for_selling_by_pos_locations'] = []; 
                                                }
                                            }
                                            $combo_products[] = $combo_product;
                                        }
                                    }
                                }
                            }

                            $item[] = [
                                'transaction_sell_line_id' => $sellLinesValue['id'],
                                'category_id' => !empty($sellLinesValue['variations']->product->category_id) ? $sellLinesValue['variations']->product->category_id : "",
                                'name' => ($sellLinesValue['variations'] && $sellLinesValue['variations']->product) ? $sellLinesValue['variations']->product->name : null,
                                'short_code' => ($sellLinesValue['variations'] && $sellLinesValue['variations']->product) ? $sellLinesValue['variations']->product->category->short_code : null,
                                'quantity' => $sellLinesValue['quantity'],
                                'quantity_returned' => $sellLinesValue["quantity_returned"],
                                'quantity_returned_note' => $sellLinesValue["quantity_returned_note"],
                                'unit_id' => ($sellLinesValue['variations'] && $sellLinesValue['variations']->product) ? $sellLinesValue['variations']->product->unit_id : null,
                                'amount' => $sellLinesValue['unit_price_before_discount'],
                                'total_before_tax' => $value['total_before_tax'],
                                'tax_amount' => $value['tax_amount'],
                                'line_discount_type' => $sellLinesValue['line_discount_type'],
                                'line_discount_amount' => $sellLinesValue['line_discount_amount'],
                                'product_id' => $sellLinesValue['product_id'],
                                'variation_id' => $sellLinesValue['variation_id'],
                                'weight' => $sellLinesValue["weight"],
                                'total_line_discount_amount' => $total_line_discount_amount,
                                'total_for_single_item' => $total_for_single_item,
                                'serve_later_quantity' => $sellLinesValue["serve_later_quantity"],
                                'adons' => $adons,
                                'printed' => $sellLinesValue["printed"],
                                'sell_line_note' => $sellLinesValue["sell_line_note"],
                                'change_price' => $sellLinesValue["change_price"],
                                'combo_variations' => $combo_adons,
                                'combo_products' => $combo_products,
                                'app_order_id' => $value['app_order_id'],
                                'app_item_line_id' => $sellLinesValue["app_item_line_id"],
                                'user_id' => $sellLinesValue['user_id'],
                                'added_by_qr' => $sellLinesValue['added_by_qr'],
                                'order_placed_by' => $sellLinesValue['order_placed_by'] ? $sellLinesValue['order_placed_by'] : null
                            ];

                            $increment++;
                        }
                    }

                    if ($value['discount_type'] == "fixed") {
                        $discount_amount = $value['discount_amount'] + $final_total_line_discount_amount;
                    } else if ($value['discount_type'] == "percentage") {
                        $discount_amount = ($value['discount_amount'] * $total_dont_have_line_discount_amt) + $final_total_line_discount_amount;
                    }
                    //calculate service charges
                    if($value['rp_redeemed_amount'] > 0) {
                     // $service_charge_amount = ($final_total_for_single_item - $discount_amount - $value['rp_redeemed_amount']) * $value['service_charges']; $dineService 
                     $service_charge_amount = $dineService  * $value['service_charges'];    
                    } else {
                        // $service_charge_amount = ($final_total_for_single_item - $discount_amount) * $value['service_charges'];
                        $service_charge_amount = $dineService * $value['service_charges'];
                    }
                    // dd($service_charge_amount);

                    if($value['return_exists'] == 1) {
                        if($value['discount_type'] == 'fixed') {
                            $discountPercent = ($discount_amount / $value['total_before_tax']) * 100;
                            $discountAmount = ($total_dont_have_line_discount_amt * $discountPercent) / 100;            
                        } else {
                            $discountAmount = $discount_amount; 
                        }   

                        if($value['rp_redeemed_amount'] > 0) {

                            $rp_redeemed_amount_percent = ($value['rp_redeemed_amount'] / $value['total_before_tax']) * 100;
                            $rp_redeemed_amount = ($total_dont_have_line_discount_amt * $rp_redeemed_amount_percent) / 100;
                            // $service_charge_amount = ($final_total_for_single_item - $discountAmount - $rp_redeemed_amount) * $value['service_charges'];
                            $service_charge_amount = $dineService * $value['service_charges'];

                        } else {
                            // $service_charge_amount = ($final_total_for_single_item - $discountAmount) * $value['service_charges']; 
                            $service_charge_amount = $dineService    * $value['service_charges']; 

                        }
                    }


                    if ($value['delivery_charges'] != 0) {
                        //calculate tax
                        $tax_amount = 0;
                        if ($value['tax_id'] != null) {
                            if ($value["is_inclusive_gst_applied"])
                                $tax_amount = (($final_total_for_single_item - $discount_amount) / (100 + $value['tax_rate_amount'])) * $value['tax_rate_amount'];
                            else
                                $tax_amount = ($value['tax_rate_amount'] / 100) * ($final_total_for_single_item - $discount_amount);
                        }

                        if ($value['is_inclusive_gst_applied'])
                            $final_total = $final_total_for_single_item + $value['delivery_charges'];
                        else
                            $final_total = $final_total_for_single_item + $tax_amount + $value['delivery_charges'];
                    } else {
                        //calculate tax
                        $tax_amount = 0;
                        $refund_tax_amount = 0;

                        if ($value['type_for_api'] == 'Retail') {
                            $tax_amount = ($final_total_for_single_item + $service_charge_amount - $discount_amount) - (($final_total_for_single_item + $service_charge_amount - $discount_amount) / (1 + ($retail_gst / 100)));

                            $final_total = round($final_total_for_single_item, 2) + 0 + round($service_charge_amount, 2) - round($discount_amount, 2);
                        } else {
                            if ($value['tax_id'] != null) {

                                if ($value["is_inclusive_gst_applied"])
                                    if($value['return_exists'] == 1) {
                                        $discountPercent = ($discount_amount / $value['total_before_tax']) * 100;
                                        $discountAmount = ($total_dont_have_line_discount_amt * $discountPercent) / 100;

                                        $tax_amount = (($final_total_for_single_item + $service_charge_amount - $discountAmount) / (100 + $value['tax_rate_amount'])) * $value['tax_rate_amount'];
                                        //dd($tax_amount);
                                    //$tax_amount = (($final_total_for_single_item + $service_charge_amount ) / (100 + $value['tax_rate_amount'])) * $value['tax_rate_amount'];
                                    } else {
                                        if($value['rp_redeemed_amount'] > 0) {
                                            $tax_amount = (($final_total_for_single_item + $service_charge_amount - $discount_amount - $value['rp_redeemed_amount']) / (100 + $value['tax_rate_amount'])) * $value['tax_rate_amount']; 
                                       } else {
                                            $tax_amount = (($final_total_for_single_item + $service_charge_amount - $discount_amount) / (100 + $value['tax_rate_amount'])) * $value['tax_rate_amount'];
                                       }
                                        
                                        //dd($tax_amount);
                                    //$tax_amount = (($final_total_for_single_item + $service_charge_amount ) / (100 + $value['tax_rate_amount'])) * $value['tax_rate_amount'];
                                    }
                                    
                                else
                                    if($discount_amount != 0 && $value['total_before_tax']) {
                                        $discountPercent = ($discount_amount / $value['total_before_tax']) * 100;
                                        $discountAmount = ($total_dont_have_line_discount_amt * $discountPercent) / 100;
                                        if($value['rp_redeemed_amount'] > 0) {
                                            $tax_amount = ($value['tax_rate_amount'] / 100) * ($final_total_for_single_item + $service_charge_amount - $discountAmount - $value['rp_redeemed_amount']);
                                        } else {
                                            $tax_amount = ($value['tax_rate_amount'] / 100) * ($final_total_for_single_item + $service_charge_amount - $discountAmount);
                                        }
                                        
                                    } else {
                                        if($value['rp_redeemed_amount'] > 0) {
                                            $tax_amount = ($value['tax_rate_amount'] / 100) * ($final_total_for_single_item + $service_charge_amount - $discountAmount - $value['rp_redeemed_amount']);
                                        } else {
                                            $tax_amount = ($value['tax_rate_amount'] / 100) * ($final_total_for_single_item + $service_charge_amount - $discount_amount);
                                        }
                                        
                                    }
                                    
                            }

                            if ($value['is_inclusive_gst_applied'])
                                
                                if($value['return_exists'] == 1) {
                                    $discountPercent = ($discount_amount / $value['total_before_tax']) * 100;
                                    $discountAmount = ($total_dont_have_line_discount_amt * $discountPercent) / 100;   

                                    if($value['discount_type'] == 'fixed') {
                                        $final_total = round($final_total_for_single_item, 2) + round($service_charge_amount, 2) - $discountAmount;
                                    } else {
                                        $final_total = round($final_total_for_single_item, 2) + round($service_charge_amount, 2) - round($discount_amount, 2);

                                    }

                                } else {
                                    $final_total = round($final_total_for_single_item, 2) + round($service_charge_amount, 2) - round($discount_amount, 2);
                                }
                                
                            else
                                if($value['return_exists'] == 1) {
                                    $final_total = round($final_total_for_single_item, 2) + round($tax_amount, 2) + round($service_charge_amount, 2);
                                } else {
                                    $final_total = round($final_total_for_single_item, 2) + round($tax_amount, 2) + round($service_charge_amount, 2) - round($discount_amount, 2);
                                }
                        }
                    }

                    $amount_rounding_method = $pos_settings->amount_rounding_method;
                    $payment_method = $value->method;
                    $latest_round_off_amount = $this->transactionUtil->latest_round_off_amount($payment_method, $final_total, $amount_rounding_method, $value['type_for_api']);

                    // $final_total = round($final_total - $value['round_off_amount'], 2);

                    if ($value['return_exists'] == 1){
                        if($value['discount_type'] == "fixed")  {
                            $discountPercent = ($discount_amount / $value['total_before_tax']) * 100;
                            $discountAmount = ($total_dont_have_line_discount_amt * $discountPercent) / 100;
                            $discount_amount = $discountAmount;
                        }
                    }

                    if($value['rp_redeemed_amount'] > 0 && $value['return_exists'] != 1) {
                        $final_total = $final_total - $value['rp_redeemed_amount'];
                    } elseif($value['rp_redeemed_amount'] > 0 && $value['return_exists'] == 1) {
                        $rp_redeemed_amount_percent = ($value['rp_redeemed_amount'] / $value['total_before_tax']) * 100;
                        $rp_redeemed_amount = ($total_dont_have_line_discount_amt * $rp_redeemed_amount_percent) / 100;
                        $final_total = $final_total - $rp_redeemed_amount;
                    }

                    // For multiple payment
                    foreach ($value['payment_lines'] as $payment_lines_key => $payment_line) {
                        if (count($value['payment_lines']) == 1) {
                            if ($final_total > 0) {
                                $is_rounding_applied = $this->transactionUtil->isRoundingApply($final_total);
                                if($is_rounding_applied)
                                {
                                    $cash_received_amount = $final_total + $latest_round_off_amount;    
                                }
                                else {
                                    $cash_received_amount = $final_total;
                                }
                                
                            } else {
                                $cash_received_amount = $final_total;
                            }
                        } else {
                            if ($value['refund_all'] == 1) {
                                $cash_received_amount = 0;
                            } else {
                                $cash_received_amount = $payment_line['amount'];
                            }
                        }
                        $payments[] = [
                            'transaction_payment_id' => $payment_line['id'],
                            'method' => $payment_line['method'],
                            'card_type' => $payment_line['card_type'],
                            'last_4_card_digits' => $payment_line['last_4_card_digits'],
                            'received_amount' => $cash_received_amount
                        ];
                    }

                    $table_arr = [];
                    $table_name = [];
                    $pax = '';

                    $table_query = Transaction::leftjoin('pos_res_tables as t', 't.transaction_id', '=', 'transactions.id')
                        ->leftjoin('res_tables as z', 'z.id', '=', 't.res_table_id')
                        ->where('transactions.id', $value['id'])
                        ->select('t.res_table_id', 'pax', 'z.name')
                        ->get();

                    if (!empty($table_query)) {
                        foreach ($table_query as $key => $tableValue) {
                            if ($tableValue['res_table_id'] != null) {
                                array_push($table_arr, $tableValue['res_table_id']);
                                array_push($table_name, $tableValue['name']);
                                $pax = $tableValue['pax'];
                            }
                        }
                    }

                    //For web pickup and delivery
                    if ($type == 'PickupOrDelivery' || $type == 'Pickup' || $type == 'TrackOrder' || $type == 'Delivery') {
                        $last_4_card_digits = "**** **** **** " . $value['last_4_card_digits'];
                        $d_date = $value['d_date'];
                        $d_time = $value['d_time'];
                        $d_address = $value['d_address'];
                        $business_location_name_for_pickup = $value['business_location_name_for_pickup'];
                        $business_location_mobile_for_pickup = $value['business_location_mobile_for_pickup'];
                        $business_location_name_for_delivery = $value['business_location_name_for_delivery'];
                        $business_location_mobile_for_delivery = $value['business_location_mobile_for_delivery'];
                        $order_no = $value['order_no'];
                        $pickup_completed = $value['pickup_completed'];
                        $lalamove_orderRef = $value['lalamove_orderRef'];
                        $lalamove_status = $value['lalamove_status'];
                        $lalamove_driver_info = '';
                        if ($type == 'Delivery') {
                            $order = json_decode($value['lalamove_result'], true);
                            if (!empty($order)) {
                                if (!empty($order['data']['order']['driverId'])) {
                                    $lalamove_driver_id = $order['data']['order']['driverId'];
                                } else if (!empty($order['driverId'])) {
                                    $lalamove_driver_id = $order['driverId'];
                                } else {
                                    $lalamove_driver_id = '';
                                }

                                if ($lalamove_driver_id != '') {
                                    $lalamove_driver_info = $this->check_driver_details($lalamove_orderRef, $lalamove_driver_id, $value['business_id'], $value['location_id']);
                                    $lalamove_driver_info = json_decode($lalamove_driver_info, true);
                                }
                            }
                        }
                    } else {
                        $last_4_card_digits = '';
                        $d_date = '';
                        $d_time = '';
                        $d_address = '';
                        $business_location_name_for_pickup = '';
                        $business_location_mobile_for_pickup = '';
                        $business_location_name_for_delivery = '';
                        $business_location_mobile_for_delivery = '';
                        $order_no = '';
                        $pickup_completed = '';
                        $lalamove_orderRef = '';
                        $lalamove_status = '';
                        $lalamove_driver_info = '';
                    }

                    $check_contact_access = Contact::join('user_contact_access AS uca', 'contacts.id', 'uca.contact_id')
                        ->where('uca.contact_id', $value['contact_id'])->first();

                    if ($check_contact_access) {
                        $user_query = User::where('id', $check_contact_access->user_id)->first();

                        $member_mobile = $user_query->contact_number;
                        $member_dob = $user_query->dob;
                    } else {
                        $member_mobile = "";
                        $member_dob = "";
                    }
                    $final_total = round($final_total - $value['round_off_amount'], 2);
                    $transaction_result[] = [
                        'app_order_id' => $value['app_order_id'],
                        'id' => $value['id'],
                        'business_id' => $value['business_id'],
                        'location_id' => $value['location_id'],
                        'transaction_date' => $value['transaction_date'],
                        'table_id' => $table_arr,
                        'table_name' => $table_name,
                        'pax' => $pax,
                        'invoice_no' => $value['invoice_no'],
                        'order_check_no' => $value['order_check_no'],
                        'ref_no' => $value['ref_no'],
                        'order_no' => $value['order_no'],
                        'type' => $value['type'],
                        'type_for_api' => $value['type_for_api'],
                        'total' => $final_total,
                        'round_off_amount' => round($latest_round_off_amount, 2),
                        'paymentType' => $value['method'],
                        'card_type' => $value['card_type'],
                        'tax_id' => $value['tax_id'],
                        'contact_id' => $value['contact_id'],
                        'tax_amount' => $tax_amount,
                        'addon_discount' => ($value['profit_percent'] == null ? 0 : $value['profit_percent']),
                        'discount_type' => $value['discount_type'],
                        'discount_amount' => $discount_amount,
                        'service_charge' => $value['service_charges'],
                        'delivery_charge' => $value['delivery_charges'],
                        'reward_amount' => $value['rp_redeemed'],
                        'customer_reward_amount' => $value['rp_redeemed_amount'],
                        'service_charge_amount' => $service_charge_amount,
                        'tax_rate_amount' => $value['tax_rate_amount'],
                        'profit_percent' => $value['profit_percent'],
                        'return_exists' => $value['return_exists'],
                        'refund_all' => $value['refund_all'],
                        'total_dont_have_line_discount_amt' => $total_dont_have_line_discount_amt,
                        //'total_line_discount_amount' => $total_line_discount_amount,
                        'final_total_for_single_item' => $final_total_for_single_item,
                        'received_amount' => $value['received_amount'],
                        'last_4_card_digits' => $last_4_card_digits,
                        'd_date' => $d_date,
                        'd_time' => $d_time,
                        'd_address' => $d_address,
                        'business_location_name_for_pickup' => $business_location_name_for_pickup,
                        'business_location_mobile_for_pickup' => $business_location_mobile_for_pickup,
                        'business_location_name_for_delivery' => $business_location_name_for_delivery,
                        'business_location_mobile_for_delivery' => $business_location_mobile_for_delivery,
                        'order_no' => $order_no,
                        'pickup_completed' => $pickup_completed,
                        'lalamove_orderRef' => $lalamove_orderRef,
                        'lalamove_status' => $lalamove_status,
                        'lalamove_driver_info' => $lalamove_driver_info,
                        'shipping_charges' => $value['shipping_charges'],
                        'first_name' => $value['contact']->first_name,
                        'last_name' => $value['contact']->last_name,
                        'estimated_arrival_time' => Carbon::parse(Carbon::parse($value['transaction_date'])->addHour())->format('d/m/Y h:ia'),
                        'updated_at' => Carbon::parse($value['updated_at'])->format('d/m/Y h:ia'),
                        'deposit' => $value['deposit'],
                        'member_mobile' => $member_mobile,
                        'member_dob' => $member_dob,
                        'item' => $item,
                        'payments' => $payments,
                        'is_inclusive_gst_applied' => $value['is_inclusive_gst_applied'] ? true : false,
                        'contact_ids' => $value['contact_ids'] ? explode(',', $value['contact_ids']) : null,
                        'guest_user_id' => $value['guest_user_id'] ? $value['guest_user_id'] : null,
                    ];

                }

                if ($transaction_id == null && $type != 'PickupOrDelivery') {
                    $query = CashRegister::where('business_id', $business_id)
                        ->where('location_id', $location_id)
                        ->with(['cash_register_transactions'])
                        ->where('user_id', $user_id);

                    // dd( $today, $tomorrow );

                    if (!empty($created_at)) {
                        // $query->whereDate('cash_registers.created_at', $created_at);
                        $query->whereBetween('cash_registers.created_at', [$today, $tomorrow]);
                    } else {
                        $query->whereDate('cash_registers.created_at', \Carbon::now()->format('Y-m-d 00:00:00'));
                    }

                    $cash_registers = $query->get();

                    // Remove Business Open/Close Time once tested properly FC
                    return [
                        "sells" => $transaction_result,
                        "cash_registers" => $cash_registers,
                        // "business_time" => [
                        //     "start" => preg_replace('/\s+/', '', $dayStartTime),
                        //     "end" => preg_replace('/\s+/', '', $dayEndTime)
                        // ]
                    ];
                } else {
                    return ["sells" => $transaction_result];
                }
            }
            else{
                return ["sells" => []];
            }
        } catch (\Exception $e) {
            DB::rollBack();

            \Log::emergency("File:" . $e->getFile() . "Line:" . $e->getLine() . "Message:" . $e->getMessage());
            $msg = __('messages.something_went_wrong');

            $output = [
                'errorMessage' => $msg
            ];

            return $output;
        }
    }   
    
     
    function stock_details( Request $request)
    {
        $user_data = $request->only('business_id', 'location_id', 'token', 'user_id','variation_id');
        if (isset($user_data['token'])) {
            $result = User::checkUserToken($user_data['token'], $user_data['user_id']);

            if ($result) {
               // $stock_detail = VariationLocationDetails::where('variation_id', $user_data['variation_id'])
               //  ->leftjoin('business_locations', 'variation_location_details.location_id', '=', 'business_locations.id')
               //  ->select('variation_location_details.*', 'business_locations.name as location_name', 'business_locations.city', 'business_locations.state', 'business_locations.country')
               //  ->get();
                $stock_detail = VariationLocationDetails::where('variation_id', $user_data['variation_id'])
                ->leftJoin('business_locations', 'variation_location_details.location_id', '=', 'business_locations.id')
                ->select(
                    'variation_location_details.*',
                    DB::raw('ROUND(variation_location_details.qty_available, 2) as qty_available'),
                    'business_locations.name as location_name',
                    'business_locations.city',
                    'business_locations.state',
                    'business_locations.country'
                )
                ->get();


                return $stock_detail;
            } else {
                return ["errorMessage" => 'Invalid token.'];
            }
        } else {
            return ["errorMessage" => 'Invalid token.'];
        }

    }

    function stripe_payment_callback(Request $request){
        $data = $request->all();
        \Log::info("Stripe Payment Data: ", $data);

        if (isset($data['payment_intent']) && $data['redirect_status'] == 'succeeded') {
            try {
            
                return response()->json(['status' => 'success', 'message' => 'Payment succeeded', "data" => $data]);
            } catch (\Exception $e) {
                Log::error("Error retrieving PaymentIntent: " . $e->getMessage());
                return response()->json(['status' => 'error', 'message' => 'Failed to confirm payment']);
            }
        } else {
            return response()->json(['status' => 'error', 'message' => 'Payment failed or was canceled']);
        }
    }

    public function deductNFCBalance(Request $request) {
        try {
            $input = $request;
            if( isset($input['payment']) && $input['payment'] ) {
                $errorMessages = [];
                foreach ($input['payment'] as $key => $payment) {
                    $nfc_card_id = !empty($payment['nfc_card_id']) ? $payment['nfc_card_id'] : "";
                    $nfc_payment_amount = !empty($payment['amount']) ? $payment['amount'] : 0;
                    if( isset($nfc_card_id) && $nfc_card_id ){
                        $nfcCard = NfcCard::where('id', $nfc_card_id)
                                        ->where('business_id', $input['business_id'])
                                        ->first();
                        if (!$nfcCard) {
                            return response()->json(['status' => 'failed' ,'message' => 'NFC Card not found'], 200);
                        }
        
                        if ($nfcCard && !$nfcCard->is_verified ) {
                            return response()->json(['status' => 'failed' ,'message' => 'NFC Card is not verified'], 200);

                        }
        
                        if ($nfcCard && $nfcCard->status != 'active' ) {
                            return response()->json(['status' => 'failed' ,'message' => 'NFC Card is not active'], 200);

                        }
                        if($nfc_payment_amount < 0){
                            return response()->json(['status' => 'failed' ,'message' => 'Amount should be greater than zero.'], 200);;

                        }
                        $balanceInCents = intval($nfcCard->balance * 100);
                        $paymentAmountInCents = intval($nfc_payment_amount * 100); 
                        
                        if ($balanceInCents < $paymentAmountInCents) {
                            return response()->json(['status' => 'failed' ,'message' => 'Insufficient NFC Card Balance'], 200);;
                        } else {
                            $newBalance = $nfcCard->balance - $nfc_payment_amount;
                            
                            $nfcCard->balance = $newBalance;
                            $nfcCard->save();
        
                            NfcTransaction::create([
                                'nfc_card_id' => $nfcCard->id,
                                'transaction_type' => 'debit', 
                                'payment_method' => 'Nfc Card',
                                'amount' => $nfc_payment_amount,
                                'remark' => 'Card Spent',
                                'business_id' => $input['business_id']
                            ]);
                        }
                        
                    }
                    else{
                        return response()->json(['status' => 'failed' ,'message' => 'NFC Card not found'], 200);

                    }
                }

            return response()->json(['status' => 'success', 'message' => 'Amount deduct successfully', "available_balance" => $nfcCard->balance], 200);
            }
         return true;
        } catch (\Exception $e) {
            return false;
        }
    }
    public function generateGuid()
    {
        // Generate a GUID (version 4) using PHP's built-in functions
        $data = random_bytes(16);
    
        // Set the version to 0100 (version 4 UUID)
        $data[6] = chr(ord($data[6]) & 0x0f | 0x40);
        // Set the variant to 10xx
        $data[8] = chr(ord($data[8]) & 0x3f | 0x80);
    
        // Output the 36-character GUID string
        return vsprintf('%s%s-%s-%s-%s-%s%s%s', str_split(bin2hex($data), 4));
    }

public function processPayment(Request $request)
{
    try {
        \Log::info($request);
        $data = $request->all();

        // Secret key for encoding the JWT (stored in the .env file)
        $secretKey = env('JWT_SECRET', '#tyvagsdhkhggjakk_62');

        // Create the JWT payload
        $payload = [
            'data' => $data,
            'exp' => time() + 3600, // Token expiration (1 hour from now)
        ];

        // Encode the data into a JWT token
        $jwtToken = JWT::encode($payload, $secretKey, 'HS256');

        // Redirect user based on status with the JWT token in the query string //env('QR_APP_URL')
        if ($data['status'] == '00') {
            return redirect()->away(env('QR_APP_URL').'/razer-payment-success?token=' . $jwtToken.'&status=success');
        } else {
            return redirect()->away(env('QR_APP_URL').'/razer-payment-failed?token=' . $jwtToken.'&status=failed');
        }

    } catch (\Exception $e) {
        // Handle errors
        return response()->json([
            'error' => $e->getMessage()
        ], 500);
    }
}

public function void_order(Request $request){
    $user_data = $request->only('business_id', 'location_id', 'token', 'user_id', 'transaction_id');
    if (isset($user_data['token'])) {
        $result = User::checkUserToken($user_data['token'], $user_data['user_id']);
        if($result) {
            try {
                //Begin transaction
                DB::beginTransaction();
        
                $output = $this->transactionUtil->deleteVoidOrder($user_data['business_id'], $request->input('transaction_id'));
                
                DB::commit();
                return $output;
            } catch (\Exception $e) {
                DB::rollBack();
                \Log::emergency("File:" . $e->getFile(). "Line:" . $e->getLine(). "Message:" . $e->getMessage());
        
                $output['success'] = false;
                $output['msg'] = trans("messages.something_went_wrong");
                return $output;
            }
        }
        return $output = [
            'success' => false,
            'message' => "Invalid Token",
        ];
    }
    return $output = [
        'success' => false,
        'message' => "Token is required",
    ];
    
}

    function void_items($items, $transaction_id, $location_id) {
        
        if (!empty($items) && count($items) > 0) {
            $deleted_lines = TransactionSellLine::where('transaction_id', $transaction_id)
                                                    ->whereIn('id', $items)
                                                    ->select('id')->get()->toArray();
            
            $combo_delete_lines = TransactionSellLine::whereIn('parent_sell_line_id', $deleted_lines)->where('children_type', 'combo')->select('id')->get()->toArray();
            $modifier_delete_lines = TransactionSellLine::whereIn('parent_sell_line_id', $deleted_lines)->where('children_type', 'modifier')->select('id')->get()->toArray();
            
            $deleted_lines = array_merge($deleted_lines, $combo_delete_lines, $modifier_delete_lines);
            
            //$adjust_qty = $status_before == 'draft' ? false : true;
            $adjust_qty = true;

            $this->transactionUtil->saveVoidSellLines($deleted_lines, $location_id, $adjust_qty);
        }
    }
}