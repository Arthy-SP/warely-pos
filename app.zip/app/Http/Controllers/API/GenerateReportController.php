<?php

namespace App\Http\Controllers\API;

//use DB;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Carbon\Carbon;
use App\BusinessLocation;
use App\User;
use App\CashRegister;
use App\Product;
use App\Category;
use App\TaxRate;
use App\Variation;
use App\Transaction;
use App\TransactionSellLine;
use App\PosResTables;
use App\OpenDrawerRecord;
use App\Restaurant\ResTable;
use App\Utils\ProductUtil;
use App\Utils\TransactionUtil;
use App\Utils\CashRegisterUtil;
use App\Utils\ContactUtil;
use App\Utils\BusinessUtil;
use App\Http\Controllers\API\TakeawayController;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;
use Config;

class GenerateReportController extends Controller
{
    /**
     * All Utils instance.
     *
     */
    protected $contactUtil;
    protected $productUtil;
    protected $transactionUtil;
    protected $cashRegisterUtil;
    protected $businessUtil;

    /**
     * Constructor
     *
     * @param ProductUtils $product
     * @return void
     */
    public function __construct(
        ContactUtil $contactUtil,
        ProductUtil $productUtil,
        TransactionUtil $transactionUtil,
        CashRegisterUtil $cashRegisterUtil,
        BusinessUtil $businessUtil
    ) {
        $this->contactUtil = $contactUtil;
        $this->productUtil = $productUtil;
        $this->transactionUtil = $transactionUtil;
        $this->cashRegisterUtil = $cashRegisterUtil;
        $this->businessUtil = $businessUtil;
        $this->dummyPaymentLine = ['method' => 'cash', 'amount' => 0, 'note' => '', 'card_transaction_number' => '', 'card_number' => '', 'card_type' => '', 'card_holder_name' => '', 'card_month' => '', 'card_year' => '', 'card_security' => '', 'cheque_number' => '', 'bank_account_number' => '',
        'is_return' => 0, 'transaction_no' => ''];
    }

  public function generate_z_report(Request $request)
    {
        $user_data = $request->only('business_id', 'location_id', 'token','user_id', 'created_at', 'type', 'start_date', 'end_date', 'current_time', 'terminal_id', 'all_terminals', 'terminal_ids', 'is_combined_report');
        $user_data['all_terminals'] = !empty($user_data['all_terminals']) ? $user_data['all_terminals'] : 0;
        $is_combined_report = !empty($user_data['is_combined_report']) ? $user_data['is_combined_report'] : null;

        if(isset($user_data['token']))
        {
            $result = User::checkUserToken($user_data['token'], $user_data['user_id']);

            if($result)
            {
                try {
                    $user_id = $user_data['user_id'];
                    $business_id = $user_data['business_id'];
                    $location_id = $user_data['location_id'];
                    $transaction_status = "final";
                    $created_at = "";
                    $terminal_id = !empty($user_data['terminal_id']) ? $user_data['terminal_id'] : null;
                    //dd($terminal_id);
                    if (!empty($user_data['start_date']) && !empty($user_data['end_date'])) {
                        $start_date = $user_data['start_date'];
                        $end_date = $user_data['end_date'];
                    } else {
                        $start_date = "";
                        $end_date = "";
                    }
                    $type = "";
                    
                    $current_time = "";
                    if (!empty($user_data['current_time']) && $user_data['current_time'] ) {
                        $current_time = $user_data['current_time'];
                    }

                    $sale_details = $this->transactionUtil->get_sales_details($user_id, $business_id, $location_id, $transaction_status, $created_at, $start_date, $end_date, $type, null, null, $current_time, $terminal_id, false, $is_combined_report, $user_data['all_terminals'], $user_data['terminal_ids']);
                    
                    return $sale_details;
                    
                } catch(\Exception $e) {
                    $result = ["errorMessage"=>'Result not found.'];
                }
            }
            else
            {
                return["errorMessage"=>'Invalid token.'];
            }
        }
        else
        {
            return["errorMessage"=>'Invalid token.'];
        }
    }

      public function generate_refund_credit_report(Request $request)
    {
        $user_data = $request->only('business_id', 'location_id', 'token','user_id', 'type', 'start_date', 'end_date', 'current_time', 'terminal_id', 'all_terminals', 'terminal_ids');
        $user_data['all_terminals'] = !empty($user_data['all_terminals']) ? $user_data['all_terminals'] : 0;

        if(isset($user_data['token']))
        {
            $result = User::checkUserToken($user_data['token'], $user_data['user_id']);

            if($result)
            {
                try {
                    $user_id = $user_data['user_id'];
                    $business_id = $user_data['business_id'];
                    $location_id = $user_data['location_id'];
                    if (!empty($user_data['start_date']) && !empty($user_data['end_date'])) {
                        $start_date = $user_data['start_date'];
                        $end_date = $user_data['end_date'];
                    } else {
                        $start_date = "";
                        $end_date = "";
                    }
                    $type = "";
                    $terminal_id = !empty($user_data['terminal_id']) ? $user_data['terminal_id'] : null;
                    $current_time = "";
                    if (!empty($user_data['current_time']) && $user_data['current_time'] ) {
                        $current_time = $user_data['current_time'];
                    }

                    $sale_details = $this->transactionUtil->get_refund_credit_report($user_id, $business_id, $location_id, $start_date, $end_date, $terminal_id, $user_data['all_terminals'], $user_data['terminal_ids']);
                    
                    return $sale_details;
                    
                } catch(\Exception $e) {
                    $result = ["errorMessage"=>'Result not found.'];
                }
            }
            else
            {
                return["errorMessage"=>'Invalid token.'];
            }
        }
        else
        {
            return["errorMessage"=>'Invalid token.'];
        }
    }


    public function get_sales_details($user_id, $business_id, $location_id, $transaction_status, $created_at, $start_date, $end_date, $type, $transaction_id = null)
    {
        $query = Transaction::leftjoin('transaction_payments as t', 't.transaction_id', '=', 'transactions.id')
                            ->leftjoin('variations as w', 'w.product_id', '=', 'transactions.additional_discount_method')
                            ->leftjoin('tax_rates as z', 'z.id', '=', 'transactions.tax_id')
                            ->leftJoin(
                                'transactions AS SR',
                                'transactions.id',
                                '=',
                                'SR.return_parent_id'
                            )
                            ->with('sell_lines.variations.product')
                            ->with('payment_lines')
                            ->where('transactions.business_id', $business_id)
                            ->where('transactions.location_id', $location_id)
                            ->where('transactions.type', 'sell')
                            ->where('transactions.is_direct_sale', 0)
                            ->where(function($query) {
                                $query->where('transactions.type_for_api', 'Dinein')
                                      ->orWhere('transactions.type_for_api', 'Takeaway')
                                      ->orWhere('transactions.type_for_api', 'Retail')
                                      ->orWhere('transactions.type_for_api', 'Kiosk')
                                      ->orWhere('transactions.type_for_api', 'Common');
                            });
        
        if (!empty($start_date) && !empty($end_date)) {
            $dateTime = explode(' ', $start_date);

            if(count($dateTime) == 2) {
                $query->where('transactions.transaction_date', '>=', $start_date)
                    ->where('transactions.transaction_date', '<=', $end_date);
            }
            else {
                $query->whereDate('transactions.transaction_date', '>=', $start_date)
                    ->whereDate('transactions.transaction_date', '<=', $end_date);
            }
        } else {
            $query->whereDate('transactions.transaction_date', '=', \Carbon::now()->format('Y-m-d 00:00:00'));
        }

        if (!empty($type)) {
            $query->where('transactions.type_for_api', $type);
        }
        
        if ($transaction_status == 'quotation') {
            $query->where('transactions.status', 'draft')
                ->where('transactions.sub_status', 'quotation');
        } elseif ($transaction_status == 'draft') {
            $query->where('transactions.status', 'draft')
                ->whereNull('transactions.sub_status');
        } else {
            $query->where('transactions.status', $transaction_status);
        }

        $transactions = $query->orderBy('transactions.created_at', 'desc')
                            ->groupBy('transactions.id')
                            ->select('transactions.*', 't.method', 't.card_type', 'w.profit_percent', 'z.amount as tax_rate_amount', DB::raw('COUNT(SR.id) as return_exists'), 'SR.refund_all')
                            ->with(['contact', 'table'])
                            ->get();
                            
        $business = $this->businessUtil->getDetails($business_id);
        $pos_settings = json_decode($business->pos_settings);
        
        $transaction_result = [];
        $total_dont_have_line_discount_amt = 0;
        $refund_total_dont_have_line_discount_amt = 0;

        foreach ($transactions as $key => $value) 
        {
            $item = [];
            $payments = [];
            $final_total_for_single_item = 0;
            $final_total_line_discount_amount = 0;
            $single_total_quantity_returned = 0;
            $refund_final_total_for_single_item = 0;
            $refund_final_total_line_discount_amount = 0;
            $service_charge_amount = 0;
            $refund_service_charge_amount = 0;
            $increment = 0;
            
            foreach ($value['sell_lines'] as $sellLinesKey => $sellLinesValue)
            {
                $total_line_discount_amount = 0;
                $refund_total_line_discount_amount = 0;
                
                if($sellLinesValue["parent_sell_line_id"] == null && $sellLinesValue["transaction_id"] == $value['id'])
                {
                    $adons = [];
                    $total_for_single_item = 0;
                    foreach ($value['sell_lines'] as $sellLinesKey1 => $sellLinesValue1)
                    {
                        if($sellLinesValue1["parent_sell_line_id"] != null && $sellLinesValue1["parent_sell_line_id"] == $sellLinesValue['id'] && $sellLinesValue1["children_type"] == "modifier")
                        {
                            $adons[] = [
                                'id' => $sellLinesValue1['variations']->id,
                                'name' => $sellLinesValue1['variations']->name,
                                'quantity' => $sellLinesValue1["quantity"],
                                'amount' => $sellLinesValue1['unit_price_before_discount'], //unit_price_before_discount
                            ];
                            if($sellLinesValue["quantity_returned"] == "0.0000" && $sellLinesValue["change_price"] == 0)
                            {
                                //total modifier price
                                $total_for_single_item = $total_for_single_item + $sellLinesValue1['unit_price_before_discount'];
                            }
                        }
                    }

                    //main item price + modifier price
                    if($sellLinesValue['weight'] > 0) {
                        $total_for_single_item = ($sellLinesValue['unit_price_before_discount'] + $total_for_single_item) * $sellLinesValue["quantity"];
                    } else {
                        $total_for_single_item = ($sellLinesValue['unit_price_before_discount'] + $total_for_single_item)* $sellLinesValue["quantity"];
                    }

                    if($increment == 0)
                    {
                        $total_dont_have_line_discount_amt = 0;
                        $refund_total_dont_have_line_discount_amt = 0;
                    }

                    if($sellLinesValue["quantity_returned"] == "0.0000")
                    {
                        $final_total_for_single_item += $total_for_single_item;
                        //calculate if line item has line discount
                        if($sellLinesValue['line_discount_type'] == "fixed")
                        {
                            $total_line_discount_amount += $sellLinesValue['line_discount_amount'];
                        }
                        else if($sellLinesValue['line_discount_type'] == "percentage")
                        {
                            $total_line_discount_amount = (($sellLinesValue['line_discount_amount']/100) * $total_for_single_item) + $total_line_discount_amount;
                        }
                        //calculate final total line discount amount
                        $final_total_line_discount_amount += $total_line_discount_amount;
                        //total if item dont have line discount amount
                        if($total_line_discount_amount == 0)
                        {
                            $total_dont_have_line_discount_amt += $total_for_single_item;
                        }
                    }
                    else
                    {
                        $refund_final_total_for_single_item += $total_for_single_item;
                        //calculate if refund line item has line discount
                        if($sellLinesValue['line_discount_type'] == "fixed")
                        {
                            $refund_total_line_discount_amount += $sellLinesValue['line_discount_amount'];
                        }
                        else if($sellLinesValue['line_discount_type'] == "percentage")
                        {
                            $refund_total_line_discount_amount = (($sellLinesValue['line_discount_amount']/100) * $total_for_single_item) + $total_line_discount_amount;
                        }
                        //calculate refund final total line discount amount
                        $refund_final_total_line_discount_amount += $refund_total_line_discount_amount;
                        //refund total if item dont have line discount amount
                        if($refund_total_line_discount_amount == 0)
                        {
                            $refund_total_dont_have_line_discount_amt += $total_for_single_item;
                        }
                        
                        $single_total_quantity_returned += $sellLinesValue["quantity_returned"]; 
                    }

                    $item[] = [
                        'id' => $sellLinesValue['id'],
                        'name' => $sellLinesValue['variations']->product->name,
                        'quantity' => $sellLinesValue['quantity'],
                        'quantity_returned' => $sellLinesValue["quantity_returned"],
                        'amount' => $sellLinesValue['unit_price_before_discount'],
                        'total_before_tax' => $value['total_before_tax'],
                        'tax_amount' => $value['tax_amount'],
                        'line_discount_type' => $sellLinesValue['line_discount_type'],
                        'line_discount_amount' => $sellLinesValue['line_discount_amount'],
                        'total_line_discount_amount' => $total_line_discount_amount,
                        'total_for_single_item' => $total_for_single_item,
                        'refund_total_line_discount_amount' => $refund_total_line_discount_amount,
                        // 'weight' => $sellLinesValue['weight'],
                        // 'total_dont_have_line_discount_amt' => $total_dont_have_line_discount_amt,
                        // 'sellLinesKey' => $sellLinesKey,
                        'adons' => $adons,
                    ];

                    $increment++;
                }
            }
            
            //calculate total discount amount and addon discount amount (e.g. Student discount)
            if($value['discount_type'] == "fixed")
            {
                $discount_amount = $value['discount_amount'] + $final_total_line_discount_amount;
                $addon_discount_amount = $value['discount_amount'];
            }
            else if($value['discount_type'] == "percentage")
            {
                $discount_amount = ($value['discount_amount'] * $total_dont_have_line_discount_amt) + $final_total_line_discount_amount;
                $addon_discount_amount = $value['discount_amount'] * $total_dont_have_line_discount_amt;
            }
            //calculate servive charge amount
            $service_charge_amount = ($final_total_for_single_item - $discount_amount) * $value['service_charges'];
            
            //calculate total discount amount and addon discount amount (e.g. Student discount)
            if($value['discount_type'] == "fixed")
            {
                $refund_discount_amount = $value['discount_amount'] + $refund_final_total_line_discount_amount;
                $refund_addon_discount_amount = $value['discount_amount'];
            }
            else if($value['discount_type'] == "percentage")
            {
                $refund_discount_amount = ($value['discount_amount'] * $refund_total_dont_have_line_discount_amt) + $refund_final_total_line_discount_amount;
                $refund_addon_discount_amount = $value['discount_amount'] * $refund_total_dont_have_line_discount_amt;
            }

            $refund_service_charge_amount = ($refund_final_total_for_single_item - $refund_discount_amount) * $value['service_charges'];

            $refund_final_total_without_discount = 0;
            $final_total_without_discount = 0;
            $final_total_with_discount = 0;

            $tax_amount = 0;
            $refund_tax_amount = 0;
            if($value['tax_id'] != null)
            {
                $tax_amount = ($value['tax_rate_amount']/100) * ($final_total_for_single_item - $discount_amount + $service_charge_amount);

                $refund_tax_amount = ($value['tax_rate_amount']/100) * ($refund_final_total_for_single_item - $refund_discount_amount + $refund_service_charge_amount);
            }

            $final_total = round($final_total_for_single_item, 2) + round($tax_amount, 2) - round($discount_amount, 2) + round($service_charge_amount, 2);
            $final_total_without_discount = round($final_total_for_single_item, 2) + round($tax_amount, 2) + round($service_charge_amount, 2) - round($discount_amount, 2);
            $final_total_with_discount = round($final_total_for_single_item, 2) + round($tax_amount, 2) + round($service_charge_amount, 2);
            $refund_final_total_without_discount = round($refund_final_total_for_single_item, 2) + round($refund_tax_amount, 2) + round($refund_service_charge_amount, 2) - round($refund_discount_amount, 2);
            
            $amount_rounding_method = $pos_settings->amount_rounding_method;
            $payment_method = $value->method;
            $latest_round_off_amount = $this->transactionUtil->latest_round_off_amount($payment_method, $final_total, $amount_rounding_method);

            // For multiple payment
            foreach($value['payment_lines'] as $payment_lines_key => $payment_line){
                if(count($value['payment_lines']) == 1) {
                    if($final_total > 0) {
                        $cash_received_amount = $final_total + $latest_round_off_amount;
                    } else {
                        $cash_received_amount = $final_total;
                    }
                } else {
                    if($value['refund_all'] == 1) {
                        $cash_received_amount = 0;
                    } else {
                        $cash_received_amount = $payment_line['amount'];
                    }
                }
                $payments[] = [
                    'transaction_payment_id' => $payment_line['id'],
                    'method' => $payment_line['method'],
                    'card_type' => $payment_line['card_type'],
                    'last_4_card_digits' => $payment_line['last_4_card_digits'],
                    'received_amount' => $cash_received_amount
                ];
            }

            $transaction_result[] = [
                'id' => $value['id'],
                'transaction_date' => $value['transaction_date'],
                'table' => '',
                'pax' => '',
                'type' => $value['type'],
                'total' => $final_total,
                'paymentType' => $value['method'],
                'card_type' => $value['card_type'],
                'tax_amount' => $tax_amount,
                'addon_discount' => ($value['profit_percent'] == null ? 0 : $value['profit_percent']),
                'discount_type' => $value['discount_type'],
                'discount_amount' => $discount_amount,
                'service_charge_amount' => $service_charge_amount,
                'tax_rate_amount' => $value['tax_rate_amount'],
                'profit_percent' => ($value['profit_percent'] == null ? 0 : $value['profit_percent']),
                'return_exists' => $value['return_exists'],
                'refund_all' => $value['refund_all'],
                'additional_discount_method' => $value['additional_discount_method'],
                'rp_redeemed_amount' => $value['rp_redeemed_amount'],
                'round_off_amount' => round($latest_round_off_amount, 2),
                'addon_discount_amount' => $addon_discount_amount,
                'final_total_line_discount_amount' => $final_total_line_discount_amount,
                'total_dont_have_line_discount_amt' => $total_dont_have_line_discount_amt,
                'final_total_for_single_item' => $final_total_for_single_item,
                'final_total_without_discount' => $final_total_without_discount,
                'final_total_with_discount' => $final_total_with_discount,
                'single_total_quantity_returned' => $single_total_quantity_returned,
                'refund_final_total_without_discount' => $refund_final_total_without_discount,
                'item' => $item,
                'payments' => $payments
            ];
        }
        //return $transaction_result;
        //retrieve addon discount (e.g. Student discount)
        $all_discounts_addons = Category::join('products', 'categories.id', '=', 'products.category_id')
                                        ->join('product_locations', 'products.id', '=', 'product_locations.product_id')
                                        ->join('variations', 'products.id', '=', 'variations.product_id')
                                        ->select('products.*','categories.name AS category','variations.id AS variation_id','variations.default_sell_price','variations.profit_percent')
                                        ->where('products.business_id', $business_id)
                                        ->where('product_locations.location_id', $location_id)
                                        ->where('categories.short_code', '=', '00100')
                                        ->groupBy('products.name')
                                        ->orderBy('products.name', 'asc')
                                        ->get()
                                        ->toArray();
        
        $collection_details_total = 0;
        $collection_details_result = [];
        $payment_method_arr = [];
        $sales_details = 0;
        $total_discount = 0;
        $final_total_line_discount_amount = 0;
        $total_service_charge_amount = 0;
        $total_tax_amount = 0;
        $customer_reward = 0;
        $addon_discount_result = [];
        $total_addon_discount_amount = 0;
        $no_of_receipts = 0;
        $pax = 0;
        $total_quantity_returned = 0;
        $total_refund = 0;
        $total_round_off_amount = 0;
        foreach ($transaction_result as $key => $transactionValue) {
            //table data
            $table_query = Transaction::leftjoin('pos_res_tables as t', 't.transaction_id', '=', 'transactions.id')
                                    ->leftjoin('res_tables as z', 'z.id', '=', 't.res_table_id')
                                    ->where('transactions.id', $transactionValue['id'])
                                    ->select('t.res_table_id', 'pax', 'z.name')
                                    ->get();

            $sales_details += $transactionValue['final_total_with_discount'];
            $total_discount += $transactionValue['discount_amount'];
            $final_total_line_discount_amount += $transactionValue['final_total_line_discount_amount'];
            $total_service_charge_amount += $transactionValue['service_charge_amount'];
            $total_tax_amount += $transactionValue['tax_amount'];
            $customer_reward += $transactionValue['rp_redeemed_amount'];
            $total_quantity_returned += $transactionValue['single_total_quantity_returned'];
            $total_refund += $transactionValue['refund_final_total_without_discount'];
            $total_round_off_amount += $transactionValue['round_off_amount'];
            $no_of_receipts += 1;
            if($table_query[0]['pax'] != null)
            {
                $pax += $table_query[0]['pax'];
            }
            
            foreach ($transactionValue['payments'] as $paymentKey => $transactionPayment)
            {
                if($transactionPayment['method'] == "cash")
                {
                    if(in_array($transactionPayment['method'], $payment_method_arr))
                    {
                        foreach ($collection_details_result as $key => $collectionDetailsValue) {
                            if($collectionDetailsValue['payment_method'] == $transactionPayment['method'])
                            {
                                $collection_details_result[$key]['quantity'] = $collectionDetailsValue['quantity'] + 1;
                                $collection_details_result[$key]['payment_total_amount'] = $collectionDetailsValue['payment_total_amount'] + $transactionPayment['received_amount'];
                            }
                        }
                    }
                    else
                    {
                        array_push($payment_method_arr, $transactionPayment['method']);

                        $collection_details_result[] = [
                            'payment_method' => $transactionPayment['method'],
                            'quantity' => 1,
                            'payment_total_amount' => $transactionPayment['received_amount'],
                        ];
                    }
                }
                else
                {
                    if(in_array($transactionPayment['card_type'], $payment_method_arr))
                    {
                        foreach ($collection_details_result as $key => $collectionDetailsValue) {
                            if($collectionDetailsValue['payment_method'] == $transactionPayment['card_type'])
                            {
                                $collection_details_result[$key]['quantity'] = $collectionDetailsValue['quantity'] + 1;
                                $collection_details_result[$key]['payment_total_amount'] = $collectionDetailsValue['payment_total_amount'] + $transactionPayment['received_amount'];
                            }
                        }
                    }
                    else
                    {
                        array_push($payment_method_arr, $transactionPayment['card_type']);

                        $collection_details_result[] = [
                            'payment_method' => $transactionPayment['card_type'],
                            'quantity' => 1,
                            'payment_total_amount' => $transactionPayment['received_amount'],
                        ];
                    }
                }
            }
            
            $collection_details_total += $transactionValue['final_total_without_discount'];
        }
        //return $collection_details_result;
        //-------------------------------CHECK OPEN DRAWER RECORD--------------------------------------------
        $cash_in_or_out_amount = 0;
        $open_drawer_status_arr = [];
        $open_drawer_status_result = [];

        $open_drawer_query = OpenDrawerRecord::where('open_drawer_records.business_id', $business_id)
                            ->where('open_drawer_records.location_id', $location_id);
        
        if (!empty($start_date) && !empty($end_date)) {
            $open_drawer_query->whereDate('open_drawer_records.created_at', '>=', $start_date)
                ->whereDate('open_drawer_records.created_at', '<=', $end_date);
        } else {
            $open_drawer_query->whereDate('open_drawer_records.created_at', '=', \Carbon::now()->format('Y-m-d 00:00:00'));
        }

        $open_drawer_record = $open_drawer_query->select('open_drawer_records.*')
                            ->get();
        
        if(count($open_drawer_record) > 0)
        {
            foreach ($open_drawer_record as $key => $openDrawerValue) {
                if(in_array($openDrawerValue['status'], $open_drawer_status_arr))
                {
                    foreach ($open_drawer_status_result as $rkey => $openDrawerStatusValue) {
                        if($openDrawerStatusValue['status'] == $openDrawerValue['status'])
                        {
                            $open_drawer_status_result[$rkey]['quantity'] = $openDrawerStatusValue['quantity'] + 1;
                            $open_drawer_status_result[$rkey]['cash_in_or_out_amount'] = $openDrawerStatusValue['cash_in_or_out_amount'] + $openDrawerValue['amount'];
                        }
                    }
                }
                else
                {
                    array_push($open_drawer_status_arr, $openDrawerValue['status']);

                    $open_drawer_status_result[] = [
                        'status' => $openDrawerValue['status'],
                        'quantity' => 1,
                        'cash_in_or_out_amount' => $openDrawerValue['amount'],
                    ];
                }

                if($openDrawerValue['status'] == "cash in")
                {
                    $cash_in_or_out_amount += $openDrawerValue['amount'];
                }
                else if($openDrawerValue['status'] == "cash out")
                {
                    $cash_in_or_out_amount -= $openDrawerValue['amount'];
                }
            }
        }
        
        //--------------------------------CHECK OPEN DRAWER RECORD END----------------------------------------
        foreach ($all_discounts_addons as $all_discounts_addons_key => $allDiscountsAddonsValue) {
            $addon_discount_amount = 0;
            foreach ($transaction_result as $key => $transactionValue) {
                if($allDiscountsAddonsValue["id"] == $transactionValue['additional_discount_method'])
                {
                    $addon_discount_amount += $transactionValue['addon_discount_amount'];
                }
            }
            
            $addon_discount_result[] = [
                'addon_discount_id' => $allDiscountsAddonsValue['id'],
                'addon_discount_name' => $allDiscountsAddonsValue['name'],
                'addon_discount_amount' => $addon_discount_amount,
            ];

            $total_addon_discount_amount += $addon_discount_amount;
        }

        $total_previous_sale = $this->get_previous_sale($user_id, $business_id, $location_id, $transaction_status, $created_at, $type, $transaction_id, $start_date, $end_date);

        $total_previous_cash_in_or_out = $this->get_previous_cash_in_or_out($user_id, $business_id, $location_id, $transaction_status, $created_at, $type, $transaction_id, $start_date, $end_date);

        $tax_rates = $this->get_business_tax_rates($business_id);
        
        $sales_result[] = [
            "collection_details_result" => $collection_details_result,
            "open_drawer_status_result" => $open_drawer_status_result,
            "collection_details_total"  => $collection_details_total + $cash_in_or_out_amount + $total_round_off_amount,
            "sales_details"             => $sales_details, 
            "less_foc"                  => 0,
            "gross_sales"               => $sales_details,
            "item_discount"             => $final_total_line_discount_amount,
            "total_discount"            => 0,
            "addon_discount_amount"     => $addon_discount_result,
            "discount_total"            => $final_total_line_discount_amount + $total_addon_discount_amount,
            "service_charge_amount"     => $total_service_charge_amount,
            "tax_amount"                => $total_tax_amount,
            "customer_reward"           => $customer_reward,
            "rounding"                  => $total_round_off_amount,
            "net_sales"                 => $sales_details - $final_total_line_discount_amount - $total_addon_discount_amount - $total_service_charge_amount - $total_tax_amount + $total_round_off_amount,
            "total_sales"               => $sales_details - ($final_total_line_discount_amount + $total_addon_discount_amount),
            "total_collection"          => $sales_details - ($final_total_line_discount_amount + $total_addon_discount_amount),
            "no_of_receipts"            => $no_of_receipts,
            "average_per_receipt"       => $no_of_receipts == 0 ? 0.00 : (($collection_details_total + $cash_in_or_out_amount) / $no_of_receipts),
            "pax"                       => $pax,
            "average_per_pax"           => $pax == 0 ? 0.00 : (($collection_details_total + $cash_in_or_out_amount) / $pax),
            "total_refund"              => $total_refund,
            "no_of_refund"              => $total_quantity_returned,
            "old_grand_total"           => $total_previous_sale + $total_previous_cash_in_or_out,
            "new_grand_total"           => $total_previous_sale + $collection_details_total + $total_previous_cash_in_or_out,
            "tax_rates_list"            => $tax_rates,
        ];

        return ["transaction_result" => $transaction_result, "sales_result" => $sales_result, "discount_addons" => $all_discounts_addons];
    }

    public function get_previous_sale($user_id, $business_id, $location_id, $transaction_status, $created_at, $type, $transaction_id = null, $start_date, $end_date)
    {        
        $previous_sale_query = Transaction::where('transactions.business_id', $business_id)
                                        ->where('transactions.location_id', $location_id);
                                         //->whereDate('transactions.created_at', '!=', \Carbon::now()->format('Y-m-d 00:00:00'))

        if (!empty($start_date) && !empty($end_date)) {
            $previous_sale_query->whereDate('transactions.created_at', '>=', $start_date)
                ->whereDate('transactions.created_at', '<=', $end_date);
        } else {
            $previous_sale_query->whereDate('transactions.created_at', '=', \Carbon::now()->format('Y-m-d 00:00:00'));
        }

        $previous_sale_query = $previous_sale_query->select(
                                    DB::raw("SUM(IF(transactions.type='sell' AND transactions.status='final', final_total, 0)) as final_total_amount"),
                                    DB::raw("SUM(IF(transactions.type='sell_return' AND transactions.status='final', final_total, 0)) as final_total_refund_amount")
                                )
                                ->first();

        $total_sales = $previous_sale_query->final_total_amount - $previous_sale_query->final_total_refund_amount;
        
        return $total_sales;
    }

    public function get_previous_cash_in_or_out($user_id, $business_id, $location_id, $transaction_status, $created_at, $type, $transaction_id = null, $start_date, $end_date)
    {
        $total_amount_cash_in_out = 0;

        $previous_open_drawer_query = OpenDrawerRecord::where('open_drawer_records.business_id', $business_id)
                            ->where('open_drawer_records.location_id', $location_id);
        
        if (!empty($start_date) && !empty($end_date)) {
            $previous_open_drawer_query->whereDate('open_drawer_records.created_at', '>=', $start_date)
                ->whereDate('open_drawer_records.created_at', '<=', $end_date);
        } else {
            $previous_open_drawer_query->whereDate('open_drawer_records.created_at', '=', \Carbon::now()->format('Y-m-d 00:00:00'));
        }

        $previous_open_drawer_record = $previous_open_drawer_query->select(
                                DB::raw("SUM(IF(open_drawer_records.status='cash in', amount, 0)) as final_total_cash_in"),
                                DB::raw("SUM(IF(open_drawer_records.status='cash out', amount, 0)) as final_total_cash_out")
                            )
                            ->first();
                            
        $total_amount_cash_in_out = $previous_open_drawer_record->final_total_cash_in - $previous_open_drawer_record->final_total_cash_out;

        return $total_amount_cash_in_out;
    }

    public function get_business_tax_rates($business_id)
    {
        $business_tax_rates = TaxRate::orderBy('name', 'desc')
                                ->where('business_id', $business_id)
                                ->get()
                                ->toArray();
        $tax_rates = array();

        for($i = 0; $i < count($business_tax_rates); $i++)
        {
            if(strtolower($business_tax_rates[$i]['name']) == 'service charge') 
            {
                $tax_rates[] = [
                    'id' => $business_tax_rates[$i]['id'],
                    'name' => $business_tax_rates[$i]['name'],
                    'amount' => $business_tax_rates[$i]['amount'],
                ];
            }
            else if(strtolower($business_tax_rates[$i]['name']) !== 'service charge')
            {
                $tax_rates[] = [
                    'id' => $business_tax_rates[$i]['id'],
                    'name' => $business_tax_rates[$i]['name'],
                    'amount' => $business_tax_rates[$i]['amount'],
                ];
            }
        }

        return $tax_rates;
    }

    public function get_open_drawer_record()
    {
        $business_id = 2;
        $location_id = 2;
        $start_date = "2021-10-01";
        $end_date = "2021-10-01";

        $open_drawer_query = OpenDrawerRecord::where('open_drawer_records.business_id', $business_id)
                            ->where('open_drawer_records.location_id', $location_id);
        
        if (!empty($start_date) && !empty($end_date)) {
            $open_drawer_query->whereDate('open_drawer_records.created_at', '>=', $start_date)
                ->whereDate('open_drawer_records.created_at', '<=', $end_date);
        } else {
            $open_drawer_query->whereDate('open_drawer_records.created_at', '=', \Carbon::now()->format('Y-m-d 00:00:00'));
        }

        $open_drawer_record = $open_drawer_query->select('open_drawer_records.*')
                            ->get();

        return $open_drawer_record;
    }

    public function get_product_sales(Request $request)
    {
        $user_data = $request->only('business_id', 'location_id', 'token','user_id', 'created_at', 'type', 'start_date', 'end_date', 'current_time', 'terminal_id', 'all_terminals');
        $user_data['all_terminals'] = !empty($user_data['all_terminals']) ? $user_data['all_terminals'] : 0;
        if(isset($user_data['token']))
        {
            $result = User::checkUserToken($user_data['token'], $user_data['user_id']);
            
            $businessLocation = BusinessLocation::find($user_data['location_id']);
            if( !empty($businessLocation) && !empty($businessLocation->day_start_time)) {
                $daystartTime = $businessLocation->day_start_time;
                $dayStartTime = $daystartTime.":00:00";
                $dayendTime = $daystartTime - 1;
                $dayEndTime = $dayendTime.":59:59";
            } else {
                $dayStartTime = str_replace(' ', '', Config::get('constants.businessStartTimeDefault'));
                $dayEndTime = str_replace(' ', '', Config::get('constants.businessEndTimeDefault'));
            }
            
            if($result)
            {
                try {
                    $user_id = $user_data['user_id'];
                    $business_id = $user_data['business_id'];
                    $location_id = $user_data['location_id'];
                    $transaction_status = "final";
                    $created_at = "";
                    $terminal_id = !empty($user_data['terminal_id']) ? $user_data['terminal_id'] : null;
                    if (!empty($user_data['start_date']) && !empty($user_data['end_date'])) {
                        $start_date = $user_data['start_date'];
                        $end_date = $user_data['end_date'];
                    } else {
                        $start_date = "";
                        $end_date = "";
                    }
                    $type = "";
                    
                    $current_time = "";
                    if (!empty($user_data['current_time']) && $user_data['current_time'] ) {
                        $current_time = $user_data["current_time"];
                    }

                    $query = Transaction::leftjoin('transaction_payments as t', 't.transaction_id', '=', 'transactions.id')
                            ->leftjoin('variations as w', 'w.product_id', '=', 'transactions.additional_discount_method')
                            ->leftjoin('tax_rates as z', 'z.id', '=', 'transactions.tax_id')
                            ->leftJoin(
                                'transactions AS SR',
                                'transactions.id',
                                '=',
                                'SR.return_parent_id'
                            )
                            ->with('sell_lines.variations.product.category')
                            ->where('transactions.business_id', $business_id)
                            ->where('transactions.location_id', $location_id)
                            ->where('transactions.type', 'sell')
                            ->where('transactions.is_direct_sale', 0)
                            ->where(function($query) {
                                $query->where('transactions.type_for_api', 'Dinein')
                                      ->orWhere('transactions.type_for_api', 'Takeaway')
                                      ->orWhere('transactions.type_for_api', 'Retail')
                                      ->orWhere('transactions.type_for_api', 'Kiosk')
                                      ->orWhere('transactions.type_for_api', 'Common');
                            });

                    //For terminal id filter
                    if($terminal_id != null && $user_data['all_terminals'] == 0){
                        $query->where('transactions.terminal_id', $terminal_id);
                    }
        
                    if (!empty($start_date) && !empty($end_date)) {
                        $dateTime = explode(' ', $start_date);

                        if(count($dateTime) == 2) {
                            $query->where('transactions.transaction_date', '>=', $start_date)
                                ->where('transactions.transaction_date', '<=', $end_date);
                        }
                        else {
                            
                            if( Config::get('constants.setBusinessTime') && !empty($businessLocation) && !empty($businessLocation->day_start_time)) {
                                if( strtotime($start_date) == strtotime($end_date) ) {
                                    $morning6TimeStamp = strtotime($start_date . ' '.$dayEndTime);
                                    $dateTimeStamp = strtotime($start_date . " " . $current_time);
                                    
                                    if( $dateTimeStamp >= $morning6TimeStamp ) {
                                        $today = $start_date .' '.$dayStartTime;
                                        $tomorrow = date('Y-m-d', strtotime($start_date .' +1 day')) . ' '.$dayStartTime;
                                    } else {
                                        $today = date('Y-m-d', strtotime($start_date .' -1 day')) .' '.$dayStartTime;
                                        $tomorrow = $start_date . ' '.$dayEndTime;
                                    }
                                } else {
                                    $today = $start_date . ' '.$dayStartTime;
                                    $tomorrow = $end_date . ' '.$dayEndTime;
                                }
                                
                                $query->whereBetween('transactions.transaction_date', [$today, $tomorrow]);
                            } else {
                                $query->whereDate('transactions.transaction_date', '>=', $start_date)
                                    ->whereDate('transactions.transaction_date', '<=', $end_date);
                            }
                        }
                    } else {
                        $query->whereDate('transactions.transaction_date', '=', \Carbon::now()->format('Y-m-d 00:00:00'));
                    }

                    if (!empty($type)) {
                        $query->where('transactions.type_for_api', $type);
                    }
                    
                    if ($transaction_status == 'quotation') {
                        $query->where('transactions.status', 'draft')
                            ->where('transactions.sub_status', 'quotation');
                    } elseif ($transaction_status == 'draft') {
                        $query->where('transactions.status', 'draft')
                            ->whereNull('transactions.sub_status');
                    } else {
                        $query->where('transactions.status', $transaction_status);
                    }

                    $transactions = $query->orderBy('transactions.created_at', 'desc')
                                        ->groupBy('transactions.id')
                                        ->select('transactions.*', 't.method', 't.card_type', 'w.profit_percent', 'z.amount as tax_rate_amount', DB::raw('COUNT(SR.id) as return_exists'), 'SR.refund_all')
                                        ->with(['contact', 'table'])
                                        ->get();

                    $item;
                    $category_arr = [];
                    $product_report_result = [];

                    foreach ($transactions as $key => $value) 
                    {
                        
                        $final_total_for_single_item = 0;
                        $final_total_line_discount_amount = 0;

                        foreach ($value['sell_lines'] as $sellLinesKey => $sellLinesValue)
                        {
                            $total_line_discount_amount = 0;
                            $refund_total_line_discount_amount = 0;
                            
                            if($sellLinesValue["parent_sell_line_id"] == null && $sellLinesValue["transaction_id"] == $value['id'])
                            {
                                $adons = [];
                                $total_for_single_item = 0;
                                foreach ($value['sell_lines'] as $sellLinesKey1 => $sellLinesValue1)
                                {
                                    if($sellLinesValue1["parent_sell_line_id"] != null && $sellLinesValue1["parent_sell_line_id"] == $sellLinesValue['id'] && $sellLinesValue1["children_type"] == "modifier")
                                    {
                                        $adons[] = [
                                            'id' => $sellLinesValue1['variations']->id,
                                            'name' => $sellLinesValue1['variations']->name,
                                            'quantity' => $sellLinesValue1["quantity"],
                                            'amount' => $sellLinesValue1['unit_price_before_discount'], //unit_price_before_discount
                                            'kitchen_shorthand' => $sellLinesValue1['variations']->kitchen_shorthand,
                                            'name_in_second_language' => $sellLinesValue1['variations']->name_in_second_language
                                        ];
                                        if($sellLinesValue["quantity_returned"] == "0.0000" && $sellLinesValue["change_price"] == 0)
                                        {
                                            //total modifier price
                                            $total_for_single_item = $total_for_single_item + $sellLinesValue1['unit_price_before_discount'];
                                        }
                                    }
                                }
            
                                //main item price + modifier price
                                if($sellLinesValue['weight'] > 0) {
                                    $total_for_single_item = ($sellLinesValue['unit_price_before_discount'] + $total_for_single_item) * $sellLinesValue["quantity"];
                                } else {
                                    $total_for_single_item = ($sellLinesValue['unit_price_before_discount'] + $total_for_single_item)* $sellLinesValue["quantity"];
                                }
            
                                if($sellLinesValue["quantity_returned"] == "0.0000")
                                {
                                    $final_total_for_single_item += $total_for_single_item;
                                    //calculate if line item has line discount
                                    if($sellLinesValue['line_discount_type'] == "fixed")
                                    {
                                        $total_line_discount_amount += $sellLinesValue['line_discount_amount'];
                                    }
                                    else if($sellLinesValue['line_discount_type'] == "percentage")
                                    {
                                        $total_line_discount_amount = (($sellLinesValue['line_discount_amount']/100) * $total_for_single_item) + $total_line_discount_amount;
                                    }
                                    //calculate final total line discount amount
                                    $final_total_line_discount_amount += $total_line_discount_amount;
                                    
                                    if(!empty($sellLinesValue['variations']->product) && strtolower($sellLinesValue['variations']->product->name) == 'open food' || strtolower($sellLinesValue['variations']->product->name) == 'open drinks') {
                                        $latest_product_name = $sellLinesValue['sell_line_note'];
                                    } else {
                                        $latest_product_name = !empty($sellLinesValue['variations']->product) ? $sellLinesValue['variations']->product->name : null;
                                    }

                                    $combo_products = [];
                                    $variations = Product::where('business_id', $business_id)
                                                ->with(['variations'])
                                                ->find($sellLinesValue['product_id']);
                                    if( $variations['variations'] && count($variations['variations']) ) {
                                        foreach ($variations['variations'] as $key => $each) {
                                            $variation = json_decode($each);
                                            if( $variation->combo_variations && count($variation->combo_variations) ) {
                                                foreach ($variation->combo_variations as $key => $combo_variation) {
                                                    $combo_product = Variation::where('variations.id', $combo_variation->variation_id)
                                                            ->join('products AS p', 'variations.product_id', '=', 'p.id')
                                                            ->select(['p.*', 'variations.name as variation_name'])
                                                            ->first();
                                                    $combo_products[] = $combo_product;
                                                }
                                            }
                                        }
                                    }

                                    $item = [
                                        'id' => $sellLinesValue['id'],
                                        'category_name' => !empty($sellLinesValue['variations']->product) ? $sellLinesValue['variations']->product->category->name : null,
                                        'name' => $latest_product_name,
                                        'quantity' => $sellLinesValue['quantity'],
                                        'quantity_returned' => $sellLinesValue["quantity_returned"],
                                        // 'amount' => $sellLinesValue['unit_price_before_discount'],
                                        'amount' => $total_for_single_item,
                                        'total_for_single_item' => $total_for_single_item,
                                        'kitchen_shorthand' => !empty($sellLinesValue['variations']->product) ? $sellLinesValue['variations']->product->kitchen_shorthand : null,
                                        'name_in_second_language' => !empty($sellLinesValue['variations']->product) ? $sellLinesValue['variations']->product->name_in_second_language : null,
                                        'show_combo_products' => !empty($sellLinesValue['variations']->product) ? ($sellLinesValue['variations']->product->show_combo_products ? true : false) : null,
                                        'combo_products' => $combo_products,
                                        'parent_product_group_id' => !empty($sellLinesValue['parent_product_group_id']) ? $sellLinesValue['parent_product_group_id'] : "",
                                        'combo_products_category_id' => !empty($sellLinesValue['variations']->product) ? $sellLinesValue['variations']->product->combo_products_category_id : null
                                    ];
                                    $pushItem = true;

                                    if(!empty($sellLinesValue['variations']->product) && in_array($sellLinesValue['variations']->product->category->name, $category_arr))
                                    {
                                        foreach ($product_report_result as $resultKey => $productReportDetailsValue) {
                                            if($productReportDetailsValue['category'] == $sellLinesValue['variations']->product->category->name) {
                                                foreach($productReportDetailsValue['items'] as $productKey => $productDetailsValue) {
                                                    if(strtolower($product_report_result[$resultKey]['items'][$productKey]['name']) === strtolower($latest_product_name)) {
                                                        $product_report_result[$resultKey]['items'][$productKey]['quantity'] += $sellLinesValue['quantity'];
                                                        $product_report_result[$resultKey]['items'][$productKey]['quantity_returned'] += $sellLinesValue['quantity_returned'];
                                                        // $product_report_result[$resultKey]['items'][$productKey]['amount'] += $sellLinesValue['unit_price_before_discount'];
                                                        $product_report_result[$resultKey]['items'][$productKey]['amount'] += $total_for_single_item;
                                                        $product_report_result[$resultKey]['items'][$productKey]['total_for_single_item'] += $total_for_single_item;
                                                        $pushItem = false;
                                                        break;
                                                    } 
                                                }
                                                if($pushItem) {
                                                    $productItem = $product_report_result[$resultKey]['items'];
                                                    array_push($productItem, $item);
                                                    $product_report_result[$resultKey]['items'] = $productItem;
                                                }
                                                $product_report_result[$resultKey]['total_quantity'] += $sellLinesValue['quantity'];
                                                $product_report_result[$resultKey]['subtotal'] += $total_for_single_item;
                                            }
                                        }
                                    }
                                    else
                                    {
                                        $items = [];

                                        if(!empty($sellLinesValue['variations']->product))
                                            array_push($category_arr, $sellLinesValue['variations']->product->category->name);
                                        
                                        array_push($items, $item);

                                        $product_report_result[] = [
                                            'category' => !empty($sellLinesValue['variations']->product) ? $sellLinesValue['variations']->product->category->name : null,
                                            'total_quantity' => $sellLinesValue['quantity'],
                                            'subtotal' => $total_for_single_item,
                                            'items' => $items
                                        ];
                                    }
                                }
                            }
                        }
                    }
                    
                    return $product_report_result;
                    
                } catch(\Exception $e) {
                    return ["errorMessage"=>'Result not found.'];
                }
            }
            else
            {
                return["errorMessage"=>'Invalid token.'];
            }
        }
        else
        {
            return["errorMessage"=>'Invalid token.'];
        }
    }
    
    public function cron_pos_outlet_form() 
    {
        // $input = $request->only([
        //     'business_location_id', 'date_range'
        // ]);
        $now = \Carbon::now();
        $location_details = BusinessLocation::get();

        if(!empty($location_details))
        {
            foreach($location_details as $location_detail)
            {
                if(!empty($location_detail->machine_id))
                {
                    $date_receipt_name = \Carbon::parse($now)->format('Ymd');
                    $generate_time_receipt_name = \Carbon::now()->format('His');
                    $all_transaction = "";

                    $user_id = "";
                    $business_id = $location_detail->business_id;
                    $location_id = $location_detail->id;
                    $transaction_status = "final";
                    $created_at = \Carbon::parse($now)->format('Y-m-d 00:00:00');
                    $type = "";
                    $txt = true;

                    $all_sale_history = $this->transactionUtil->get_sale_history($user_id, $business_id, $location_id, $transaction_status, $created_at, $type, null, null, $txt);
                    $all_sale_return_history = $this->transactionUtil->get_sale_returns($business_id, $location_id, $transaction_status, $created_at, $type, null, null, $txt);
                    
                    $business_tax_rates = TaxRate::where('business_id', $business_id)
                            ->get()
                            ->toArray();
                    
                    if($location_detail->outlet_location_id == 0)
                    {
                        $searchString = 'OrchardGateway';
                    }
                    else if($location_detail->outlet_location_id == 1)
                    {
                        $searchString = 'Vivocity';
                    }
                    elseif($location_detail->outlet_location_id == 2)
                    {
                        $searchString = 'ThomsonPlaza';
                    }
                    elseif($location_detail->outlet_location_id == 3)
                    {
                        $searchString = 'HillonMall';
                    }
                    elseif($location_detail->outlet_location_id == 4)
                    {
                        $searchString = 'SingPostCentre';
                    }

                    //---------------OrchardGateway------------------------
                    if($searchString == 'OrchardGateway')
                    {
                        $mainFolderExist = false;
                        //search folder
                        $directories = Storage::disk('local')->allDirectories('txt_invoice');
                        if(count($directories) > 0) 
                        {
                            foreach($directories as $directoryString)
                            {
                                if(strpos($directoryString, $searchString) !== false) 
                                {
                                    $mainFolderExist = true;
                                    break;
                                }
                            }

                            if($mainFolderExist)
                            {
                                Storage::disk('local')->makeDirectory('txt_invoice/OrchardGateway');
                            }
                        } 
                        else 
                        {
                            Storage::disk('local')->makeDirectory('txt_invoice/OrchardGateway');
                        }

                        $machineString = $location_detail->machine_id; // Need to change
                        $subFolderExist = false;
                        $orchardDirectories = Storage::disk('local')->allDirectories('txt_invoice/OrchardGateway');
                        $subDirectory = 'txt_invoice/'.$searchString.'/'.$machineString;

                        if(count($orchardDirectories) > 0) 
                        {
                            foreach($orchardDirectories as $directoryString)
                            {
                                if(strpos($directoryString, $machineString) !== false) 
                                {
                                    $subFolderExist = true;
                                    break;
                                }
                            }

                            if($subFolderExist)
                            {
                                Storage::disk('local')->makeDirectory($subDirectory);
                            }
                        } 
                        else 
                        {
                            Storage::disk('local')->makeDirectory($subDirectory);
                        }

                        $file_name = $machineString.'_'.$date_receipt_name.'_'.$generate_time_receipt_name.'.txt';
                        $allFiles = Storage::disk('local')->allFiles($subDirectory);
                        $batch_id = count($allFiles) + 1;
                        $line = "";
                        foreach ($allFiles as $file) {
                            if (strpos($file, $date_receipt_name) !== false)
                            {
                                $line = fgets(fopen( public_path('/uploads/'.$file), 'r')); ///public
                                if(!empty($line))
                                {
                                    $array_filter_first_line = explode("|",$line);
                                    $batch_id = $array_filter_first_line[2];
                                }
                                break;
                            }
                        }

                        $sales = $all_sale_history['sells'];

                        $filePart = 'uploads/txt_invoice/'.$searchString.'/'.$machineString.'/';

                        // if(count($sales) > 0)
                        // {
                            //Shop has sales/ no sales
                            $total_lines = 24;

                            for($a = 0; $a < $total_lines; $a++)
                            {
                                $transaction_date = \Carbon::parse($now)->format('dmY');
                                $transaction_hours = "";
                                $total_receipt_no = 0;
                                $total_gto = 0;
                                $total_gst = 0;
                                $total_discount = 0;
                                $total_pax = 0;

                                if(strlen($a) == 1)
                                {
                                    $string = '0'.$a;
                                    $transaction_hours = $string.'59';
                                }
                                else if(strlen($a) == 2)
                                {
                                    $string = $a;
                                    $transaction_hours = $string.'59';
                                }

                                foreach($sales as $sale)
                                {
                                    $transaction_date = \Carbon::parse($sale['transaction_date'])->format('dmY');
                                    $transaction_time = \Carbon::parse($sale['transaction_date'])->format('Hi');
                                    // $receipt_no = $sale['invoice_no'];
                                    $gto = $sale['total'] - $sale['tax_amount'];
                                    $gst = $sale['tax_amount'];
                                    $discount = $sale['discount_amount'];
                                    $pax = !empty($sale['pax']) ? (integer)$sale['pax'] : 0;

                                    $first_two_char = substr($transaction_time, 0, 2);

                                    if(strlen($a) == 1)
                                    {
                                        $string = '0'.$a;
                                        $transaction_hours = $string.'59';

                                        if($first_two_char == $string) 
                                        {
                                            $total_receipt_no = $total_receipt_no + 1;
                                            $total_gto = $total_gto + $gto;
                                            $total_gst = $total_gst + $gst;
                                            $total_discount = $total_discount + $discount;
                                            $total_pax = $total_pax + $pax;
                                        }
                                    }
                                    else if(strlen($a) == 2)
                                    {
                                        $string = $a;
                                        $transaction_hours = $string.'59';

                                        if($first_two_char == $string) 
                                        {
                                            $total_receipt_no = $total_receipt_no + 1;
                                            $total_gto = $total_gto + $gto;
                                            $total_gst = $total_gst + $gst;
                                            $total_discount = $total_discount + $discount;
                                            $total_pax = $total_pax + $pax;
                                        }
                                    }

                                    if(!empty($sale['return_parent']))
                                    {
                                        $return_transaction_date = \Carbon::parse($sale['return_parent']->transaction_date)->format('dmY');
                                        $return_transaction_time = \Carbon::parse($sale['return_parent']->transaction_date)->format('Hi');

                                        $return_gto = $sale['refund_final_total_without_discount_and_gst'];
                                        $return_gst = $sale['refund_tax_amount'];
                                        $return_discount = $sale['refund_discount_amount'];
                                        $return_pax = 0;

                                        $return_first_two_char = substr($return_transaction_time, 0, 2);

                                        if(strlen($a) == 1)
                                        {
                                            $return_string = '0'.$a;
                                            $return_transaction_hours = $return_string.'59';

                                            if($return_first_two_char == $return_string) 
                                            {
                                                //$total_receipt_no = $total_receipt_no + 1;
                                                $total_gto = $total_gto - $return_gto;
                                                $total_gst = $total_gst - $return_gst;
                                                $total_discount = $total_discount - $return_discount;
                                            }
                                        }
                                        else if(strlen($a) == 2)
                                        {
                                            $return_string = $a;
                                            $return_transaction_hours = $return_string.'59';

                                            if($return_first_two_char == $return_string) 
                                            {
                                                //$total_receipt_no = $total_receipt_no + 1;
                                                $total_gto = $total_gto - $return_gto;
                                                $total_gst = $total_gst - $return_gst;
                                                $total_discount = $total_discount - $return_discount;
                                            }
                                        }
                                    }
                                }
                                $all_transaction = $all_transaction.$machineString.'|'.$transaction_date.'|'.$batch_id.'|'.$transaction_hours.'|'.$total_receipt_no.'|'.number_format((float)$total_gto, 2).'|'.number_format((float)$total_gst, 2).'|'.number_format((float)$total_discount, 2).'|'.$total_pax."\n";
                            }

                            Storage::disk('local')->put($subDirectory.'/'.$file_name, $all_transaction);
                        // }
                        // else
                        // {
                        //     //0 sales
                        //     Storage::disk('local')->put($subDirectory.'/'.$file_name, "0 sales");
                        // }

                        $ftp_server = $location_detail->ftp_server;
                        $ftp_conn = ftp_connect($ftp_server) or die("Could not connect to $ftp_server");
                        $ftp_username = $location_detail->machine_id;
                        $ftp_userpass = $location_detail->ftp_password;
                        $login = ftp_login($ftp_conn, $ftp_username, $ftp_userpass);

                        $name = basename('/txt_invoice/'.$searchString.'/'.$machineString.'/'.$file_name);
                        $file = public_path($filePart .'/'. $name);
                        ftp_put($ftp_conn, $name, $file, FTP_ASCII);
                        
                        ftp_close($ftp_conn);

                        echo json_encode( 'FTP Upload Successful.' );
                    }//---------------OrchardGateway End------------------------
                    else if($searchString == 'Vivocity')
                    {
                        $mainFolderExist = false;
                        //search folder
                        $directories = Storage::disk('local')->allDirectories('txt_invoice');
                        if(count($directories) > 0) 
                        {
                            foreach($directories as $directoryString)
                            {
                                if(strpos($directoryString, $searchString) !== false) 
                                {
                                    $mainFolderExist = true;
                                    break;
                                }
                            }

                            if($mainFolderExist)
                            {
                                Storage::disk('local')->makeDirectory('txt_invoice/Vivocity');
                            }
                        } 
                        else 
                        {
                            Storage::disk('local')->makeDirectory('txt_invoice/Vivocity');
                        }

                        $machineString = $location_detail->machine_id; // Need to change
                        $subFolderExist = false;
                        $vivoDirectories = Storage::disk('local')->allDirectories('txt_invoice/Vivocity');
                        $subDirectory = 'txt_invoice/'.$searchString.'/'.$machineString;

                        if(count($vivoDirectories) > 0) 
                        {
                            foreach($vivoDirectories as $directoryString)
                            {
                                if(strpos($directoryString, $machineString) !== false) 
                                {
                                    $subFolderExist = true;
                                    break;
                                }
                            }

                            if($subFolderExist)
                            {
                                Storage::disk('local')->makeDirectory($subDirectory);
                            }
                        } 
                        else 
                        {
                            Storage::disk('local')->makeDirectory($subDirectory);
                        }

                        $subSubFolderExist = false;
                        $subDirectories = Storage::disk('local')->allDirectories($subDirectory);
                        $subSubDirectory = 'txt_invoice/'.$searchString.'/'.$machineString.'/'.$date_receipt_name;

                        if(count($subDirectories) > 0) 
                        {
                            foreach($subDirectories as $subDirectoryString)
                            {
                                if(strpos($subDirectoryString, $date_receipt_name) !== false) 
                                {
                                    $subSubFolderExist = true;
                                    break;
                                }
                            }

                            if($subSubFolderExist)
                            {
                                Storage::disk('local')->makeDirectory($subSubDirectory);
                            }
                        } 
                        else 
                        {
                            Storage::disk('local')->makeDirectory($subSubDirectory);
                        }

                        $sales = $all_sale_history['sells'];
                        $filePart = 'uploads/txt_invoice/'.$searchString.'/'.$machineString.'/'.$date_receipt_name;

                        if(count($sales) > 0)
                        {
                            // Get all files in a directory
                            $files = Storage::disk('local')->allFiles($subSubDirectory);
                            if(count($files) > 0) 
                            {
                                // Delete Files
                                Storage::disk('local')->delete($files);
                            }

                            //Shop has sales
                            foreach($sales as $sale)
                            {
                                $each_transaction = "";
                                $gto1 = 0;
                                $payment_method1 = 0;
                                $gto2 = 0;
                                $payment_method2 = 0;
                                $gto3 = 0;
                                $payment_method3 = 0;

                                $receipt_no = $sale['invoice_no'];
                                if(empty($sale['return_parent']))
                                {
                                    foreach($sale['payments'] as $key => $payment)
                                    {
                                        if($key + 1 == 1)
                                        {
                                            $gto1 = number_format((float)$payment['received_amount'], 2);
                                            $payment_method1 = $this->transactionUtil->filter_payment_type($payment['method'], $payment['card_type']);
                                        }
                                        else if($key + 1 == 2)
                                        {
                                            $gto2 = number_format((float)$payment['received_amount'], 2);
                                            $payment_method2 = $this->transactionUtil->filter_payment_type($payment['method'], $payment['card_type']);
                                        }
                                        else if($key + 1 == 3)
                                        {
                                            $gto3 = number_format((float)$payment['received_amount'], 2);
                                            $payment_method3 = $this->transactionUtil->filter_payment_type($payment['method'], $payment['card_type']);
                                        }
                                    }

                                    $gst = number_format((float)$sale['tax_amount'], 2);
                                    $discount = number_format((float)$sale['discount_amount'], 2);
                                }
                                else
                                {
                                    foreach($sale['payments'] as $key => $payment)
                                    {
                                        if($key + 1 == 1)
                                        {
                                            $gto1 = number_format((float)$payment['original_received_amount'], 2);
                                            $payment_method1 = $this->transactionUtil->filter_payment_type($payment['method'], $payment['card_type']);
                                        }
                                        else if($key + 1 == 2)
                                        {
                                            $gto2 = number_format((float)$payment['original_received_amount'], 2);
                                            $payment_method2 = $this->transactionUtil->filter_payment_type($payment['method'], $payment['card_type']);
                                        }
                                        else if($key + 1 == 3)
                                        {
                                            $gto3 = number_format((float)$payment['original_received_amount'], 2);
                                            $payment_method3 = $this->transactionUtil->filter_payment_type($payment['method'], $payment['card_type']);
                                        }
                                    }

                                    $gst = number_format((float)$sale['original_tax_amount'], 2);
                                    $discount = number_format((float)$sale['original_discount_amount'], 2);
                                }
                                $transaction_date = \Carbon::parse($sale['transaction_date'])->format('Ymd');
                                $transaction_time_hours = \Carbon::parse($sale['transaction_date'])->format('H');
                                $transaction_time_minutes = \Carbon::parse($sale['transaction_date'])->format('i');
                                $transaction_time_second = \Carbon::parse($sale['transaction_date'])->format('s');
                                $pax = !empty($sale['pax']) ? $sale['pax'] : 0;
                                $membership_id = 0;

                                $each_transaction = $machineString.'|'.$receipt_no.'|'.$gto1.'|'.$payment_method1.'|'.$gto2.'|'.$payment_method2.'|'.$gto3.'|'.$payment_method3.'|'.$gst.'|'.$discount.'|'.$transaction_date.'|'.$transaction_time_hours.'|'.$transaction_time_minutes.'|'.$transaction_time_second.'|'.$pax.'|'.$membership_id;

                                $transaction_time = \Carbon::parse($sale['transaction_date'])->format('His');

                                $file_name = $machineString.'_'.$transaction_date.'_'.$transaction_time.'.txt';

                                Storage::disk('local')->put($subSubDirectory.'/'.$file_name, $each_transaction);

                                if(!empty($sale['return_parent']))
                                {
                                    $void_each_transaction = "";
                                    $void_gto1 = 0;
                                    $void_payment_method1 = 0;
                                    $void_gto2 = 0;
                                    $void_payment_method2 = 0;
                                    $void_gto3 = 0;
                                    $void_payment_method3 = 0;

                                    $void_receipt_no = $sale['invoice_no'].'R';
                                    if($sale['total'] == 0)
                                    {
                                        foreach($sale['payments'] as $key => $payment)
                                        {
                                            if($key + 1 == 1)
                                            {
                                                $void_gto1 = -(number_format((float)$payment['original_received_amount'], 2));
                                                $void_payment_method1 = $this->transactionUtil->filter_payment_type($payment['method'], $payment['card_type']);
                                            }
                                            else if($key + 1 == 2)
                                            {
                                                $void_gto2 = -(number_format((float)$payment['original_received_amount'], 2));
                                                $void_payment_method2 = $this->transactionUtil->filter_payment_type($payment['method'], $payment['card_type']);
                                            }
                                            else if($key + 1 == 3)
                                            {
                                                $void_gto3 = -(number_format((float)$payment['original_received_amount'], 2));
                                                $void_payment_method3 = $this->transactionUtil->filter_payment_type($payment['method'], $payment['card_type']);
                                            }
                                        }

                                        $void_gst = ($sale['return_parent']->tax_amount > 0) ? -(number_format((float)$sale['return_parent']->tax_amount, 2)) : 0;
                                        $void_discount = ($sale['return_parent']->discount_amount > 0) ? -(number_format((float)$sale['return_parent']->discount_amount, 2)) : 0;
                                    }
                                    else
                                    {
                                        foreach($sale['payments'] as $key => $payment)
                                        {
                                            if($key + 1 == 1)
                                            {
                                                $void_gto1 = -(number_format($sale['refund_final_total_without_discount'], 2));
                                                $void_payment_method1 = $this->transactionUtil->filter_payment_type($payment['method'], $payment['card_type']);
                                            }
                                        }

                                        $void_gto2 = 0;
                                        $void_payment_method2 = 0;

                                        $void_gto3 = 0;
                                        $void_payment_method3 = 0;


                                        $void_gst = ($sale['refund_tax_amount'] > 0) ? -(number_format($sale['refund_tax_amount'], 2)) : 0;
                                        $void_discount = ($sale['refund_discount_amount'] > 0) ? -(number_format($sale['refund_discount_amount'], 2)) : 0;
                                    }

                                    
                                    $void_transaction_date = \Carbon::parse($sale['return_parent']->transaction_date)->format('Ymd');
                                    $void_transaction_time_hours = \Carbon::parse($sale['return_parent']->transaction_date)->format('H');
                                    $void_transaction_time_minutes = \Carbon::parse($sale['return_parent']->transaction_date)->format('i');
                                    $void_transaction_time_second = \Carbon::parse($sale['return_parent']->transaction_date)->format('s');
                                    $void_pax = !empty($sale['pax']) ? $sale['pax'] : 0;
                                    $void_membership_id = 0;

                                    $void_each_transaction = $machineString.'|'.$void_receipt_no.'|'.$void_gto1.'|'.$void_payment_method1.'|'.$void_gto2.'|'.$void_payment_method2.'|'.$void_gto3.'|'.$void_payment_method3.'|'.$void_gst.'|'.$void_discount.'|'.$void_transaction_date.'|'.$void_transaction_time_hours.'|'.$void_transaction_time_minutes.'|'.$void_transaction_time_second.'|'.$void_pax.'|'.$void_membership_id;

                                    $void_transaction_time = \Carbon::parse($sale['return_parent']->transaction_date)->format('His');

                                    $void_file_name = $machineString.'_'.$void_transaction_date.'_'.$void_transaction_time.'.txt';

                                    Storage::disk('local')->put($subSubDirectory.'/'.$void_file_name, $void_each_transaction);
                                }
                            }
                        }
                        else
                        {
                            //0 sales
                            $file_name = $machineString.'_'.$date_receipt_name.'_'.$generate_time_receipt_name.'.txt';
                            Storage::disk('local')->put($subSubDirectory.'/'.$file_name, "0 Sales");
                        }

                        $ftp_server = $location_detail->ftp_server;
                        $ftp_conn = ftp_connect($ftp_server) or die("Could not connect to $ftp_server");
                        $ftp_username = $location_detail->machine_id;
                        $ftp_userpass = $location_detail->ftp_password;
                        $login = ftp_login($ftp_conn, $ftp_username, $ftp_userpass);

                        $allFiles = Storage::disk('local')->allFiles($subSubDirectory);
                        
                        foreach ($allFiles as $file) {
                            $name = basename($file);
                            $file = public_path($filePart .'/'. $name);
                            ftp_put($ftp_conn, $name, $file, FTP_ASCII);
                        }

                        ftp_close($ftp_conn);
                    }//---------------ThomsonPlaza, HillionMall------------------------
                    else if($searchString == 'ThomsonPlaza' || $searchString == 'HillonMall')
                    {
                        $mainFolderExist = false;
                        //search folder
                        $directories = Storage::disk('local')->allDirectories('txt_invoice');
                        if(count($directories) > 0) 
                        {
                            foreach($directories as $directoryString)
                            {
                                if(strpos($directoryString, $searchString) !== false) 
                                {
                                    $mainFolderExist = true;
                                    break;
                                }
                            }
                            
                            if($mainFolderExist)
                            {
                                if($searchString == 'ThomsonPlaza')
                                {
                                    Storage::disk('local')->makeDirectory('txt_invoice/ThomsonPlaza');
                                }
                                elseif($searchString == 'HillonMall')
                                {
                                    Storage::disk('local')->makeDirectory('txt_invoice/HillonMall');
                                }
                            }
                        } 
                        else 
                        {
                            if($searchString == 'ThomsonPlaza')
                            {
                                Storage::disk('local')->makeDirectory('txt_invoice/ThomsonPlaza');
                            }
                            elseif($searchString == 'HillonMall')
                            {
                                Storage::disk('local')->makeDirectory('txt_invoice/HillonMall');
                            }
                        }

                        $machineString = $location_detail->machine_id; // Need to change
                        $subFolderExist = false;
                        if($searchString == 'ThomsonPlaza')
                        {
                            $mallDirectories = Storage::disk('local')->allDirectories('txt_invoice/ThomsonPlaza');
                        }
                        elseif($searchString == 'HillonMall')
                        {
                            $mallDirectories = Storage::disk('local')->allDirectories('txt_invoice/HillonMall');
                        }
                        $subDirectory = 'txt_invoice/'.$searchString.'/'.$machineString;

                        if(count($mallDirectories) > 0) 
                        {
                            foreach($mallDirectories as $directoryString)
                            {
                                if(strpos($directoryString, $machineString) !== false) 
                                {
                                    $subFolderExist = true;
                                    break;
                                }
                            }

                            if($subFolderExist)
                            {
                                Storage::disk('local')->makeDirectory($subDirectory);
                            }
                        } 
                        else 
                        {
                            Storage::disk('local')->makeDirectory($subDirectory);
                        }

                        $file_name = 'H'.$machineString.'_'.$date_receipt_name.'.txt';
                        $allFiles = array_filter(Storage::disk('local')->allFiles($subDirectory), function ($item) {
                            //only txt's
                            return strpos($item, '.txt');
                        });
                        $batch_id = count($allFiles) + 1;
                        $line = "";
                        foreach ($allFiles as $file) {
                            if (strpos($file, $date_receipt_name) !== false)
                            {
                                $line = fgets(fopen( public_path('/uploads/'.$file), 'r')); ///public
                                if(!empty($line))
                                {
                                    $array_filter_first_line = explode("|",$line);
                                    $batch_id = $array_filter_first_line[1];
                                }
                                break;
                            }
                        }

                        $sales = $all_sale_history['sells'];
                        $sale_returns = $all_sale_return_history['transaction_result'];
                        // return $sales;
                        // return $sale_returns;
                        $filePart = 'uploads/txt_invoice/'.$searchString.'/'.$machineString.'/';

                        $total_lines = 24;

                        for($a = 0; $a < $total_lines; $a++)
                        {
                            $transaction_date = \Carbon::parse($now)->format('dmY');
                            $transaction_hours = "";
                            $total_receipt_no = 0;
                            $total_gto = 0;
                            $total_gst = 0;
                            $total_service_charge_amount = 0;
                            $total_discount = 0;
                            $total_pax = 0;
                            $total_cash = number_format(0, 2);
                            $total_nets = number_format(0, 2);
                            $total_visa = number_format(0, 2);
                            $total_master = number_format(0, 2);
                            $total_amex = number_format(0, 2);
                            $total_voucher = number_format(0, 2);
                            $total_others = number_format(0, 2);
                            $gst_registered = 'N';

                            if(strlen($a) == 1)
                            {
                                $string = '0'.$a;
                                $transaction_hours = $string;
                            }
                            else if(strlen($a) == 2)
                            {
                                $string = $a;
                                $transaction_hours = $string;
                            }

                            foreach($business_tax_rates as $business_tax_rate)
                            {
                                if(strtolower($business_tax_rate['name']) == 'gst')
                                {
                                    $gst_registered = 'Y';
                                    break;
                                }
                            }

                            foreach($sales as $sale)
                            {
                                $transaction_date = \Carbon::parse($sale['transaction_date'])->format('dmY');
                                $transaction_time = \Carbon::parse($sale['transaction_date'])->format('Hi');
                                // $receipt_no = $sale['invoice_no'];
                                $gto = $sale['total'] + $sale['round_off_amount'] - number_format((float)$sale['tax_amount'], 2);
                                $gst = number_format((float)$sale['tax_amount'], 2);
                                $service_charge_amount = $sale['service_charge_amount'];
                                $discount = $sale['discount_amount'];
                                $pax = !empty($sale['pax']) ? (integer)$sale['pax'] : 0;
                                $payments = $sale['payments'];

                                $first_two_char = substr($transaction_time, 0, 2);

                                if(strlen($a) == 1)
                                {
                                    $string = '0'.$a;
                                    $transaction_hours = $string;

                                    if($first_two_char == $string) 
                                    {
                                        $total_receipt_no = $total_receipt_no + 1;
                                        $total_gto = $total_gto + $gto;
                                        $total_gst = $total_gst + $gst;
                                        $total_service_charge_amount = $total_service_charge_amount + $service_charge_amount;
                                        $total_discount = $total_discount + $discount;
                                        $total_pax = $total_pax + $pax;

                                        if(!empty($sale['return_parent']))
                                        {
                                            $return_gto = $sale['refund_final_total_without_discount_and_gst'];
                                            $return_gst = $sale['refund_tax_amount'];
                                            $refund_service_charge_amount = $sale['refund_service_charge_amount'];
                                            $return_discount = $sale['refund_discount_amount'];

                                            $total_gto = $total_gto + $return_gto;
                                            $total_gst = $total_gst + $return_gst;
                                            $total_service_charge_amount = $total_service_charge_amount + $refund_service_charge_amount;
                                            $total_discount = $total_discount + $return_discount;
                                        }

                                        foreach($payments as $payment)
                                        {
                                            if($payment['card_type'] == 'credit')
                                            {
                                                $total_cash = (float)$total_cash + $payment['total_before_gst'];
                                                $total_cash = number_format((float)$total_cash, 2);
                                            }
                                            elseif($payment['card_type'] == 'nets')
                                            {
                                                $total_nets = (float)$total_nets + $payment['total_before_gst'];
                                                $total_nets = number_format((float)$total_nets, 2);
                                            } 
                                            elseif($payment['card_type'] == 'visa')
                                            {
                                                $total_visa = (float)$total_visa + $payment['total_before_gst'];
                                                $total_visa = number_format((float)$total_visa, 2);
                                            } 
                                            elseif($payment['card_type'] == 'master')
                                            {
                                                $total_master = (float)$total_master + $payment['total_before_gst'];
                                                $total_master = number_format((float)$total_master, 2);
                                            } 
                                            elseif($payment['card_type'] == 'amex')
                                            {
                                                $total_amex = (float)$total_amex + $payment['total_before_gst'];
                                                $total_amex = number_format((float)$total_amex, 2);
                                            } 
                                            elseif($payment['card_type'] == 'voucher')
                                            {
                                                $total_voucher = (float)$total_voucher + $payment['total_before_gst'];
                                                $total_voucher = number_format((float)$total_voucher, 2);
                                            } 
                                            else
                                            {
                                                $total_others = (float)$total_others + $payment['total_before_gst'];
                                                $total_others = number_format((float)$total_others, 2);
                                            } 
                                        }
                                    }
                                }
                                else if(strlen($a) == 2)
                                {
                                    $string = $a;
                                    $transaction_hours = $string;

                                    if($first_two_char == $string) 
                                    {
                                        $total_receipt_no = $total_receipt_no + 1;
                                        $total_gto = $total_gto + $gto;
                                        $total_gst = $total_gst + $gst;
                                        $total_service_charge_amount = $total_service_charge_amount + $service_charge_amount;
                                        $total_discount = $total_discount + $discount;
                                        $total_pax = $total_pax + $pax;

                                        if(!empty($sale['return_parent']))
                                        {
                                            $return_gto = $sale['refund_final_total_without_discount_and_gst'];
                                            $return_gst = $sale['refund_tax_amount'];
                                            $refund_service_charge_amount = $sale['refund_service_charge_amount'];
                                            $return_discount = $sale['refund_discount_amount'];

                                            $total_gto = $total_gto + $return_gto;
                                            $total_gst = $total_gst + $return_gst;
                                            $total_service_charge_amount = $total_service_charge_amount + $refund_service_charge_amount;
                                            $total_discount = $total_discount + $return_discount;
                                        }

                                        foreach($payments as $payment)
                                        {
                                            if($payment['card_type'] == 'credit')
                                            {
                                                $total_cash = (float)$total_cash + $payment['total_before_gst'];
                                                $total_cash = number_format((float)$total_cash, 2);
                                            }
                                            elseif($payment['card_type'] == 'nets')
                                            {
                                                $total_nets = (float)$total_nets + $payment['total_before_gst'];
                                                $total_nets = number_format((float)$total_nets, 2);
                                            } 
                                            elseif($payment['card_type'] == 'visa')
                                            {
                                                $total_visa = (float)$total_visa + $payment['total_before_gst'];
                                                $total_visa = number_format((float)$total_visa, 2);
                                            } 
                                            elseif($payment['card_type'] == 'master')
                                            {
                                                $total_master = (float)$total_master + $payment['total_before_gst'];
                                                $total_master = number_format((float)$total_master, 2);
                                            } 
                                            elseif($payment['card_type'] == 'amex')
                                            {
                                                $total_amex = (float)$total_amex + $payment['total_before_gst'];
                                                $total_amex = number_format((float)$total_amex, 2);
                                            } 
                                            elseif($payment['card_type'] == 'voucher')
                                            {
                                                $total_voucher = (float)$total_voucher + $payment['total_before_gst'];
                                                $total_voucher = number_format((float)$total_voucher, 2);
                                            } 
                                            else
                                            {
                                                $total_others = (float)$total_others + $payment['total_before_gst'];
                                                $total_others = number_format((float)$total_others, 2);
                                            } 
                                        }
                                    }
                                }
                            }

                            foreach($sale_returns as $sale_return)
                            {
                                $return_transaction_date = \Carbon::parse($sale_return->transaction_date)->format('dmY');
                                $return_transaction_time = \Carbon::parse($sale_return->transaction_date)->format('Hi');

                                $return_gto = $sale_return['total_before_tax'] * (1 + $sale_return['parent_service_charges']);
                                $return_gst = $sale_return['tax_amount'];
                                $refund_service_charge_amount = $sale_return['total_before_tax'] * ($sale_return['parent_service_charges']);
                                // $return_discount = $sale_return['refund_discount_amount'];
                                // $return_pax = 0;

                                $return_first_two_char = substr($return_transaction_time, 0, 2);

                                if(strlen($a) == 1)
                                {
                                    $return_string = '0'.$a;
                                    // $return_transaction_hours = $return_string;

                                    if($return_first_two_char == $return_string) 
                                    {
                                        //$total_receipt_no = $total_receipt_no + 1;
                                        $total_gto = $total_gto - $return_gto;
                                        // $total_gst = $total_gst - $return_gst;
                                        // $total_service_charge_amount = $total_service_charge_amount - $refund_service_charge_amount;
                                        // $total_discount = $total_discount - $return_discount;
                                    }
                                }
                                else if(strlen($a) == 2)
                                {
                                    $return_string = $a;
                                    // $return_transaction_hours = $return_string;

                                    if($return_first_two_char == $return_string) 
                                    {
                                        //$total_receipt_no = $total_receipt_no + 1;
                                        $total_gto = $total_gto - $return_gto;
                                        // $total_gst = $total_gst - $return_gst;
                                        // $total_service_charge_amount = $total_service_charge_amount - $refund_service_charge_amount;
                                        // $total_discount = $total_discount - $return_discount;
                                    }
                                }
                            }

                            $all_transaction = $all_transaction.$machineString.'|'.$batch_id.'|'.$transaction_date.'|'.$transaction_hours.'|'.$total_receipt_no.'|'.
                                                number_format((float)$total_gto, 2, ".", "").'|'.number_format((float)$total_gst, 2, ".", "").'|'.number_format((float)$total_discount, 2, ".", "").'|'.
                                                number_format((float)$total_service_charge_amount, 2, ".", "").'|'.$total_pax.'|'.$total_cash.'|'.$total_nets.'|'.$total_visa.'|'.
                                                $total_master.'|'.$total_amex.'|'.$total_voucher.'|'.$total_others.'|'.$gst_registered."\n";
                        }

                        Storage::disk('local')->put($subDirectory.'/'.$file_name, $all_transaction);

                        $ftp_server = $location_detail->ftp_server;
                        $ftp_conn = ftp_connect($ftp_server) or die("Could not connect to $ftp_server");
                        $ftp_username = $location_detail->machine_id;
                        $ftp_userpass = $location_detail->ftp_password;
                        $login = ftp_login($ftp_conn, $ftp_username, $ftp_userpass);

                        $name = basename('/txt_invoice/'.$searchString.'/'.$machineString.'/'.$file_name);
                        $file = public_path($filePart .'/'. $name);
                        ftp_put($ftp_conn, $name, $file, FTP_ASCII);
                        
                        ftp_close($ftp_conn);

                        echo json_encode( 'FTP Upload Successful.' );
                    }

                    echo json_encode( 'FTP Upload Successful.' );
                }
            }
        }
    }

    public function get_product_sales_attap_house(Request $request)
    {
        $user_data = $request->only('business_id', 'location_id', 'token','user_id', 'created_at', 'type', 'start_date', 'end_date', 'current_time', 'terminal_id', 'all_terminals');
        $user_data['all_terminals'] = !empty($user_data['all_terminals']) ? $user_data['all_terminals'] : 0;
        if(isset($user_data['token']))
        {
            $result = User::checkUserToken($user_data['token'], $user_data['user_id']);
            
            $businessLocation = BusinessLocation::find($user_data['location_id']);
            if( !empty($businessLocation) && !empty($businessLocation->day_start_time)) {
                $daystartTime = $businessLocation->day_start_time;
                $dayStartTime = $daystartTime.":00:00";
                $dayendTime = $daystartTime - 1;
                $dayEndTime = $dayendTime.":59:59";
            } else {
                $dayStartTime = str_replace(' ', '', Config::get('constants.businessStartTimeDefault'));
                $dayEndTime = str_replace(' ', '', Config::get('constants.businessEndTimeDefault'));
            }
            
            if($result)
            {
                try {
                    $user_id = $user_data['user_id'];
                    $business_id = $user_data['business_id'];
                    $location_id = $user_data['location_id'];
                    $transaction_status = "final";
                    $created_at = "";
                    $terminal_id = !empty($user_data['terminal_id']) ? $user_data['terminal_id'] : null;
                    \Log::info($terminal_id.'-terminal_id_product_sales');
                    if (!empty($user_data['start_date']) && !empty($user_data['end_date'])) {
                        $start_date = $user_data['start_date'];
                        $end_date = $user_data['end_date'];
                    } else {
                        $start_date = "";
                        $end_date = "";
                    }
                    $type = "";
                    
                    $current_time = "";
                    if (!empty($user_data['current_time']) && $user_data['current_time'] ) {
                        $current_time = $user_data["current_time"];
                    }

                    $query = Transaction::leftjoin('transaction_payments as t', 't.transaction_id', '=', 'transactions.id')
                            ->leftjoin('variations as w', 'w.product_id', '=', 'transactions.additional_discount_method')
                            ->leftjoin('tax_rates as z', 'z.id', '=', 'transactions.tax_id')
                            ->leftJoin(
                                'transactions AS SR',
                                'transactions.id',
                                '=',
                                'SR.return_parent_id'
                            )
                            ->with('sell_lines.variations.product.category')
                            ->where('transactions.business_id', $business_id)
                            ->where('transactions.location_id', $location_id)
                            ->where('transactions.type', 'sell')
                            ->where('transactions.is_direct_sale', 0)
                            ->where(function($query) {
                                $query->where('transactions.type_for_api', 'Dinein')
                                      ->orWhere('transactions.type_for_api', 'Takeaway')
                                      ->orWhere('transactions.type_for_api', 'Retail')
                                      ->orWhere('transactions.type_for_api', 'Kiosk')
                                      ->orWhere('transactions.type_for_api', 'Common');
                            });
                    
                    if($terminal_id != null && $user_data['all_terminals'] == 0){
                        $query->where('transactions.terminal_id', $terminal_id);
                    }
                    
                    if (!empty($start_date) && !empty($end_date)) {
                        $dateTime = explode(' ', $start_date);

                        if(count($dateTime) == 2) {
                            $query->where('transactions.transaction_date', '>=', $start_date)
                                ->where('transactions.transaction_date', '<=', $end_date);
                        }
                        else {
                            
                            if( Config::get('constants.setBusinessTime') && !empty($businessLocation) && !empty($businessLocation->day_start_time)) {
                                if( strtotime($start_date) == strtotime($end_date) ) {
                                    $morning6TimeStamp = strtotime($start_date . ' '.$dayEndTime);
                                    $dateTimeStamp = strtotime($start_date . " " . $current_time);
                                    
                                    if( $dateTimeStamp >= $morning6TimeStamp ) {
                                        $today = $start_date .' '.$dayStartTime;
                                        $tomorrow = date('Y-m-d', strtotime($start_date .' +1 day')) . ' '.$dayStartTime;
                                    } else {
                                        $today = date('Y-m-d', strtotime($start_date .' -1 day')) .' '.$dayStartTime;
                                        $tomorrow = $start_date . ' '.$dayEndTime;
                                    }
                                } else {
                                    $today = $start_date . ' '.$dayStartTime;
                                    $tomorrow = $end_date . ' '.$dayEndTime;
                                }
                                
                                $query->whereBetween('transactions.transaction_date', [$today, $tomorrow]);
                            } else {
                                $query->whereDate('transactions.transaction_date', '>=', $start_date)
                                    ->whereDate('transactions.transaction_date', '<=', $end_date);
                            }
                        }
                    } else {
                        $query->whereDate('transactions.transaction_date', '=', \Carbon::now()->format('Y-m-d 00:00:00'));
                    }

                    if (!empty($type)) {
                        $query->where('transactions.type_for_api', $type);
                    }
                    
                    if ($transaction_status == 'quotation') {
                        $query->where('transactions.status', 'draft')
                            ->where('transactions.sub_status', 'quotation');
                    } elseif ($transaction_status == 'draft') {
                        $query->where('transactions.status', 'draft')
                            ->whereNull('transactions.sub_status');
                    } else {
                        $query->where('transactions.status', $transaction_status);
                    }

                    $transactions = $query->orderBy('transactions.created_at', 'desc')
                                        ->groupBy('transactions.id')
                                        ->select('transactions.*', 't.method', 't.card_type', 'w.profit_percent', 'z.amount as tax_rate_amount', DB::raw('COUNT(SR.id) as return_exists'), 'SR.refund_all')
                                        ->with(['contact', 'table'])
                                        ->get();

                    $item;
                    $category_arr = [];
                    $product_report_result = [];
                    $total_quantity = 0;
                    $subtotal = 0;
                    foreach ($transactions as $key => $value) 
                    {
                        
                        $final_total_for_single_item = 0;
                        $final_total_line_discount_amount = 0;

                        foreach ($value['sell_lines'] as $sellLinesKey => $sellLinesValue)
                        {
                            $total_line_discount_amount = 0;
                            $refund_total_line_discount_amount = 0;
                            
                            if($sellLinesValue["parent_sell_line_id"] == null && $sellLinesValue["transaction_id"] == $value['id'])
                            {
                                $adons = [];
                                $total_for_single_item = 0;
                                foreach ($value['sell_lines'] as $sellLinesKey1 => $sellLinesValue1)
                                {
                                    if($sellLinesValue1["parent_sell_line_id"] != null && $sellLinesValue1["parent_sell_line_id"] == $sellLinesValue['id'] && $sellLinesValue1["children_type"] == "modifier")
                                    {
                                        $adons[] = [
                                            'id' => $sellLinesValue1['variations']->id,
                                            'name' => $sellLinesValue1['variations']->name,
                                            'quantity' => $sellLinesValue1["quantity"],
                                            'amount' => $sellLinesValue1['unit_price_before_discount'], //unit_price_before_discount
                                            'kitchen_shorthand' => $sellLinesValue1['variations']->kitchen_shorthand,
                                            'name_in_second_language' => $sellLinesValue1['variations']->name_in_second_language
                                        ];
                                        if($sellLinesValue["quantity_returned"] == "0.0000" && $sellLinesValue["change_price"] == 0)
                                        {
                                            //total modifier price
                                            $total_for_single_item = $total_for_single_item + $sellLinesValue1['unit_price_before_discount'];
                                        }
                                    }
                                }
            
                                //main item price + modifier price
                                if($sellLinesValue['weight'] > 0) {
                                    $total_for_single_item = ($sellLinesValue['unit_price_before_discount'] + $total_for_single_item) * $sellLinesValue["quantity"];
                                } else {
                                    $total_for_single_item = ($sellLinesValue['unit_price_before_discount'] + $total_for_single_item)* $sellLinesValue["quantity"];
                                }
            
                                if($sellLinesValue["quantity_returned"] == "0.0000")
                                {
                                    $final_total_for_single_item += $total_for_single_item;
                                    //calculate if line item has line discount
                                    if($sellLinesValue['line_discount_type'] == "fixed")
                                    {
                                        $total_line_discount_amount += $sellLinesValue['line_discount_amount'];
                                    }
                                    else if($sellLinesValue['line_discount_type'] == "percentage")
                                    {
                                        $total_line_discount_amount = (($sellLinesValue['line_discount_amount']/100) * $total_for_single_item) + $total_line_discount_amount;
                                    }
                                    //calculate final total line discount amount
                                    $final_total_line_discount_amount += $total_line_discount_amount;
                                    
                                    if(!empty($sellLinesValue['variations']->product) && strtolower($sellLinesValue['variations']->product->name) == 'open food' || strtolower($sellLinesValue['variations']->product->name) == 'open drinks') {
                                        $latest_product_name = $sellLinesValue['sell_line_note'];
                                    } else {
                                        $latest_product_name = !empty($sellLinesValue['variations']->product) ? $sellLinesValue['variations']->product->name : null;
                                    }

                                    $combo_products = [];
                                    $variations = Product::where('business_id', $business_id)
                                                ->with(['variations'])
                                                ->find($sellLinesValue['product_id']);
                                    if( $variations['variations'] && count($variations['variations']) ) {
                                        foreach ($variations['variations'] as $key => $each) {
                                            $variation = json_decode($each);
                                            if( $variation->combo_variations && count($variation->combo_variations) ) {
                                                foreach ($variation->combo_variations as $key => $combo_variation) {
                                                    $combo_product = Variation::where('variations.id', $combo_variation->variation_id)
                                                            ->join('products AS p', 'variations.product_id', '=', 'p.id')
                                                            ->select(['p.*', 'variations.name as variation_name'])
                                                            ->first();
                                                    $combo_products[] = $combo_product;
                                                }
                                            }
                                        }
                                    }

                                    $item = [
                                        'id' => $sellLinesValue['id'],
                                        'category_name' => !empty($sellLinesValue['variations']->product) ? $sellLinesValue['variations']->product->category->name : null,
                                        'name' => $latest_product_name,
                                        'unit_price' => $sellLinesValue['unit_price'],
                                        'change_price' => $sellLinesValue['change_price'],
                                        'quantity' => $sellLinesValue['quantity'],
                                        'quantity_returned' => $sellLinesValue["quantity_returned"],
                                        'line_discount_type' => $sellLinesValue['line_discount_type'],
                                        'line_discount_amount' => $sellLinesValue['line_discount_amount'],
                                        // 'amount' => $sellLinesValue['unit_price_before_discount'],
                                        'amount' => $total_for_single_item,
                                        'total_for_single_item' => $total_for_single_item,
                                        'kitchen_shorthand' => !empty($sellLinesValue['variations']->product) ? $sellLinesValue['variations']->product->kitchen_shorthand : null,
                                        'name_in_second_language' => !empty($sellLinesValue['variations']->product) ? $sellLinesValue['variations']->product->name_in_second_language : null,
                                        'show_combo_products' => !empty($sellLinesValue['variations']->product) ? ($sellLinesValue['variations']->product->show_combo_products ? true : false) : null,
                                        'combo_products' => $combo_products,
                                        'parent_product_group_id' => !empty($sellLinesValue['parent_product_group_id']) ? $sellLinesValue['parent_product_group_id'] : "",
                                        'combo_products_category_id' => !empty($sellLinesValue['variations']->product) ? $sellLinesValue['variations']->product->combo_products_category_id : null
                                    ];
                                    $pushItem = true;

                                    if(!empty($sellLinesValue['variations']->product) && in_array($sellLinesValue['variations']->product->category->name, $category_arr))
                                    {
                                        foreach ($product_report_result as $resultKey => $productReportDetailsValue) {
                                            if($productReportDetailsValue['category'] == $sellLinesValue['variations']->product->category->name) {
                                                foreach($productReportDetailsValue['items'] as $productKey => $productDetailsValue) {
                                                    if(strtolower($product_report_result[$resultKey]['items'][$productKey]['name']) === strtolower($latest_product_name)) {
                                                        $product_report_result[$resultKey]['items'][$productKey]['quantity'] += $sellLinesValue['quantity'];
                                                        $product_report_result[$resultKey]['items'][$productKey]['quantity_returned'] += $sellLinesValue['quantity_returned'];
                                                        // $product_report_result[$resultKey]['items'][$productKey]['amount'] += $sellLinesValue['unit_price_before_discount'];
                                                        $product_report_result[$resultKey]['items'][$productKey]['amount'] += $total_for_single_item;
                                                        $product_report_result[$resultKey]['items'][$productKey]['total_for_single_item'] += $total_for_single_item;
                                                        $pushItem = false;
                                                        break;
                                                    } 
                                                }
                                                if($pushItem) {
                                                    $productItem = $product_report_result[$resultKey]['items'];
                                                    array_push($productItem, $item);
                                                    $product_report_result[$resultKey]['items'] = $productItem;
                                                }
                                                $product_report_result[$resultKey]['total_quantity'] += $sellLinesValue['quantity'];
                                                $product_report_result[$resultKey]['subtotal'] += $total_for_single_item;
                                            }
                                        }
                                    }
                                    else
                                    {
                                        $items = [];

                                        if(!empty($sellLinesValue['variations']->product))
                                            array_push($category_arr, $sellLinesValue['variations']->product->category->name);
                                        
                                        array_push($items, $item);

                                        $product_report_result[] = [
                                            'category' => !empty($sellLinesValue['variations']->product) ? $sellLinesValue['variations']->product->category->name : null,
                                            'total_quantity' => $sellLinesValue['quantity'],
                                            'subtotal' => $total_for_single_item,
                                            'items' => $items
                                        ];
                                    }

                                    $total_quantity += $sellLinesValue["quantity"];
                                    $subtotal += $total_for_single_item;
                                }
                            }
                        }
                    }

                    
                    $sales_items = [];
                    $total_items_discount = 0;
                    if( $product_report_result ) {
                        foreach ($product_report_result as $key => $product_report) {
                            if( $product_report['items'] ) {
                                foreach($product_report['items'] AS $product_report_item) {
                                    $qty_percentage = round(($product_report_item['quantity'] / round($total_quantity, 2)) * 100, 2);
                                    $sales_percentage = round(($product_report_item['amount'] / round($subtotal, 2)) * 100, 2);
                                    $product_report_item["qty_percentage"] = $qty_percentage;
                                    $product_report_item["sales_percentage"] = $sales_percentage;
                                    if( $product_report_item["line_discount_type"] && $product_report_item["line_discount_type"] == 'percentage' ) {
                                        $product_report_item["item_discount"] = round(( round($product_report_item['unit_price'], 2) * round($product_report_item['line_discount_amount'], 2) ) / 100, 2);
                                        $total_items_discount += round($product_report_item['item_discount'], 2);
                                    } else {
                                        $total_items_discount += round($product_report_item['line_discount_amount'], 2);
                                        $product_report_item["item_discount"] = round($product_report_item['line_discount_amount'], 2);
                                    }
                                    $sales_items[] = $product_report_item;
                                }
                            }
                        }
                    }

                    if (!empty($data)) {
                        array_multisort($sales_items, SORT_ASC);
                    }
                    
                    return [
                        "items" => $sales_items,
                        "total_quantity" => round($total_quantity, 2),
                        "subtotal" => round($subtotal, 2),
                        "total_items_discount" => round($total_items_discount, 2),
                        "total_net_sales" => round(round($subtotal, 2) - round($total_items_discount, 2), 2),
                        "total_sales_count" => round($total_quantity, 2),
                        "total_other_discount" => round(0, 2) // TO DO
                    ];
                    
                } catch(\Exception $e) {
                    return ["errorMessage"=>'Result not found.'];
                }
            }
            else
            {
                return["errorMessage"=>'Invalid token.'];
            }
        }
        else
        {
            return["errorMessage"=>'Invalid token.'];
        }
    }

    public function generate_hourly_report(Request $request) {
        $user_data = $request->only('business_id', 'location_id', 'token','user_id', 'created_at', 'type', 'start_date', 'end_date', 'current_time', 'terminal_id', 'is_combined_report','all_terminals');
         $is_combined_report = !empty($user_data['is_combined_report']) ? $user_data['is_combined_report'] : false;
        if(isset($user_data['token'])) {
            $result = User::checkUserToken($user_data['token'], $user_data['user_id']);
            if($result) {
                $terminal_id = !empty($user_data['terminal_id']) ? $user_data['terminal_id'] : null;
                // \Log::info($terminal_id.'-hourly_report');
                $all_terminals = !empty($user_data['all_terminals']) ? $user_data['all_terminals'] : 0;
                    
               
                try {
                $user_data['start_date'] = $user_data['start_date'] . Config::get('constants.businessStartTimeDefault');
                $user_data['end_date'] = $user_data['end_date'] . Config::get('constants.businessEndTimeDefault');
                $finalTransactions = Transaction::select('transactions.*')
                    ->leftJoin(\DB::raw('(SELECT invoice_no, SUM(total_with_modifier) AS sell_return_total
                            FROM transactions
                            WHERE type = "sell_return"
                            AND business_id = ' . $user_data["business_id"] . '
                            GROUP BY invoice_no) AS sr'), 'sr.invoice_no', '=', 'transactions.invoice_no')
                    ->where('transactions.business_id', $user_data['business_id'])
                    //->where('transactions.location_id', $user_data['location_id'])
                    ->where('transactions.type', 'sell')
                    ->where('transactions.status', 'final')
                    ->whereIn('transactions.payment_status', ['paid', 'partial'])
                    ->whereBetween('transactions.updated_at', [$user_data['start_date'], $user_data['end_date']]); // Date range filter

                    if (is_array($user_data['location_id'])) {
                        $finalTransactions->whereIn('transactions.location_id', $user_data['location_id']);
                    } else {
                        $finalTransactions->where('transactions.location_id', $user_data['location_id']);
                    }

                    if($is_combined_report == false) {
                            if ($terminal_id != null && $all_terminals == 0) {
                            $finalTransactions = $finalTransactions->where('transactions.terminal_id', $terminal_id);
                            }
                    }
                    $finalTransactions = $finalTransactions->selectRaw('COALESCE(transactions.final_total - sr.sell_return_total, transactions.final_total) AS final_total_amount')
                        ->get()
                        ->groupBy(function ($date) {
                            return Carbon::parse($date->updated_at)->format('H');
                        });


                     $hourlyFinalSellTransactionsAll = [];
                    if ($finalTransactions->count() > 0) {
                        for ($hour = 0; $hour <= 23; $hour++) {
                            foreach ($finalTransactions as $key => $hourlyTransactions) {
                                if ($key == sprintf('%02d', $hour)) {
                                    $line = $this->processEveryHoursTransactions($key, $hourlyTransactions, 'hourly');
                                    $hourlyFinalSellTransactionsAll[] = $line;
                                }
                            }
                        }
                    }
                   $finalTotalSales = 0;
                   $finaltotalSalesCount =0;
                   foreach ($hourlyFinalSellTransactionsAll as $hourlyData) {
                        $finalTotalSales += (float) $hourlyData['total'];
                        $finaltotalSalesCount += (float) $hourlyData['qty'];
                    }
                    return [
                        "message" => "Results",
                        "data" => $hourlyFinalSellTransactionsAll,
                        "total_sales" => (float) $finalTotalSales,
                        "total_sales_qty" => $finaltotalSalesCount,
                       
                    ];
                } catch(\Exception $e) {
                    $result = ["errorMessage"=>'Result not found.'];
                }
                
            } else {
                return["errorMessage"=>'Invalid token.'];
            }
        } else {
            return["errorMessage"=>'Invalid token.'];
        }
    }

    public function generate_hourly_report_attap_house(Request $request) {
        $user_data = $request->only('business_id', 'location_id', 'token','user_id', 'created_at', 'type', 'start_date', 'end_date', 'current_time', 'terminal_id', 'is_combined_report', 'all_terminals');
        $is_combined_report = !empty($user_data['is_combined_report']) ? $user_data['is_combined_report'] : false;
        //dd($is_combined_report);
        if(isset($user_data['token'])) {
            $result = User::checkUserToken($user_data['token'], $user_data['user_id']);
            if($result) {
                $terminal_id = !empty($user_data['terminal_id']) ? $user_data['terminal_id'] : null;
                \Log::info($terminal_id.'-hourly_report');
                $all_terminals = !empty($user_data['all_terminals']) ? $user_data['all_terminals'] : 0;


                try {
                $finalTransactions = Transaction::select('transactions.*')
                    ->leftJoin(\DB::raw('(SELECT invoice_no, SUM(total_with_modifier) AS sell_return_total
                            FROM transactions
                            WHERE type = "sell_return"
                            AND business_id = ' . $user_data["business_id"] . '
                            GROUP BY invoice_no) AS sr'), 'sr.invoice_no', '=', 'transactions.invoice_no')
                    ->where('transactions.business_id', $user_data['business_id'])
                    //->whereIn('transactions.location_id', $user_data['location_id'])
                    ->where('transactions.type', 'sell')
                    ->where('transactions.status', 'final')
                    ->whereIn('transactions.payment_status', ['paid', 'partial'])
                    ->whereDate('transactions.updated_at', $user_data['start_date']);

                    if (is_array($user_data['location_id'])) {
                        $finalTransactions->whereIn('transactions.location_id', $user_data['location_id']);
                    } else {
                        $finalTransactions->where('transactions.location_id', $user_data['location_id']);
                    }

                    if($is_combined_report == false) {
                        if ($terminal_id != null && $all_terminals == 0 ) {
                            $finalTransactions = $finalTransactions->where('transactions.terminal_id', $terminal_id);
                        }
                    }
                    
                    $finalTransactions = $finalTransactions->selectRaw('COALESCE(transactions.final_total - sr.sell_return_total, transactions.final_total) AS final_total_amount')
                        ->get()
                        ->groupBy(function ($date) {
                            return Carbon::parse($date->updated_at)->format('H');
                        });


                     $hourlyFinalSellTransactionsAll = [];
                    if ($finalTransactions->count() > 0) {
                        for ($hour = 0; $hour <= 23; $hour++) {
                            foreach ($finalTransactions as $key => $hourlyTransactions) {
                                if ($key == sprintf('%02d', $hour)) {
                                    $line = $this->processEveryHoursTransactions($key, $hourlyTransactions, 'hourly');
                                    $hourlyFinalSellTransactionsAll[] = $line;
                                }
                            }
                        }
                    }
                   $finalTotalSales = 0;
                   $finaltotalSalesCount =0;
                   foreach ($hourlyFinalSellTransactionsAll as $hourlyData) {
                        $finalTotalSales += (float) $hourlyData['total'];
                        $finaltotalSalesCount += (float) $hourlyData['qty'];
                    }
                    return [
                        "message" => "Results",
                        "data" => $hourlyFinalSellTransactionsAll,
                        "total_sales" => (float) $finalTotalSales,
                        "total_sales_qty" => $finaltotalSalesCount,
                       
                    ];
                } catch(\Exception $e) {
                    $result = ["errorMessage"=>'Result not found.'];
                }
                
            } else {
                return["errorMessage"=>'Invalid token.'];
            }
        } else {
            return["errorMessage"=>'Invalid token.'];
        }
    }

    private function processHoulyTransactions($hour, $hourly_transactions, $type = null) {
        \Log::info("processHoulyTransactions => hour => ");
        \Log::info($hour);

        $gto_sales = 0;   
        foreach ($hourly_transactions as $transaction) {
            if($transaction->type=='sell'){
                $amount_before_tax = $transaction->amount;
                $gto_sales += $amount_before_tax;
            } else {
                $gto_sales -= ($transaction->final_total);
            }
        }

        if($type == "hourly") {
            return [
                "start" => sprintf('%02d', $hour) . ':00',
                "end" => sprintf('%02d', $hour) . ':59',
                "qty" => count($hourly_transactions),
                "total" => number_format($gto_sales, 2,'.','')
            ];
        } else {
            return [
                "start" => sprintf('%02d', $hour) . ':00',
                "end" => sprintf('%02d', $hour) . ':59',
                "qty" => count($hourly_transactions),
                "total" => number_format($gto_sales, 2,'.','')

            ];
        }
    }
     private function processEveryHoursTransactions($hour, $hourly_transactions, $type = null) {
        $gto_sales = 0; 
        foreach ($hourly_transactions as $transaction) {
            if($transaction->type=='sell'){
                $amount_before_tax = $transaction->final_total_amount;
                $gto_sales += $amount_before_tax;
               
            } else {
                $gto_sales -= ($transaction->final_total);
               
            }


        }

        if($type == "hourly") {
            return [
                "start" => sprintf('%02d', $hour) . ':00',
                "end" => sprintf('%02d', $hour) . ':59',
                "qty" => count($hourly_transactions),
                "total" => number_format($gto_sales, 2,'.',''),
               
            ];
        } else {
            return [
                "start" => sprintf('%02d', $hour) . ':00',
                "end" => sprintf('%02d', $hour) . ':59',
                "qty" => count($hourly_transactions),
                "total" => number_format($gto_sales, 2,'.',''),
               

            ];
        }
    }

    public function generate_z_report_attap_house(Request $request)
    {
        $user_data = $request->only('business_id', 'location_id', 'token','user_id', 'created_at', 'type', 'start_date', 'end_date', 'current_time', 'terminal_id', 'is_combined_report', 'all_terminals');
        $user_data['all_terminals'] = !empty($user_data['all_terminals']) ? $user_data['all_terminals'] : 0;
        $is_combined_report = !empty($user_data['is_combined_report']) ? $user_data['is_combined_report'] : null;

        if(isset($user_data['token']))
        {
            $result = User::checkUserToken($user_data['token'], $user_data['user_id']);

            if($result)
            {
                try {
                    $user_id = $user_data['user_id'];
                    $business_id = $user_data['business_id'];
                    $location_id = $user_data['location_id'];
                    $transaction_status = "final";
                    $terminal_id = !empty($user_data['terminal_id']) ? $user_data['terminal_id'] : null;
                    $created_at = "";
                    if (!empty($user_data['start_date']) && !empty($user_data['end_date'])) {
                        $start_date = $user_data['start_date'];
                        $end_date = $user_data['end_date'];
                    } else {
                        $start_date = "";
                        $end_date = "";
                    }
                    $type = "";
                    
                    $current_time = "";
                    if (!empty($user_data['current_time']) && $user_data['current_time'] ) {
                        $current_time = $user_data['current_time'];
                    }

                    $attap_house_report = true;

                    $sale_details = $this->transactionUtil->get_sales_details($user_id, $business_id, $location_id, $transaction_status, $created_at, $start_date, $end_date, $type, null, null, $current_time, $terminal_id, $attap_house_report, $is_combined_report,  $user_data['all_terminals']);
                    
                    return $sale_details;
                    
                } catch(\Exception $e) {
                    $result = ["errorMessage"=>'Result not found.'];
                }
            }
            else
            {
                return["errorMessage"=>'Invalid token.'];
            }
        }
        else
        {
            return["errorMessage"=>'Invalid token.'];
        }
    }
}