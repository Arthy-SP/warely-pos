<?php

namespace App\Http\Controllers;

use App\Account;
use App\BusinessLocation;
use App\InvoiceLayout;
use App\InvoiceScheme;
use App\SellingPriceGroup;
use App\Utils\ModuleUtil;
use App\Utils\Util;
use Illuminate\Http\Request;
use Spatie\Permission\Models\Permission;
use Yajra\DataTables\Facades\DataTables;
use App\BusinessOutlets;
use Illuminate\Support\Str;


class BusinessLocationController extends Controller
{
    protected $moduleUtil;
    protected $commonUtil;

    /**
     * Constructor
     *
     * @param ModuleUtil $moduleUtil
     * @return void
     */
    public function __construct(ModuleUtil $moduleUtil, Util $commonUtil)
    {
        $this->moduleUtil = $moduleUtil;
        $this->commonUtil = $commonUtil;
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        if (!auth()->user()->can('business_settings.access')) {
            abort(403, 'Unauthorized action.');
        }

        if (request()->ajax()) {
            $business_id = request()->session()->get('user.business_id');

            $locations = BusinessLocation::where('business_locations.business_id', $business_id)
                ->leftjoin(
                    'invoice_schemes as ic',
                    'business_locations.invoice_scheme_id',
                    '=',
                    'ic.id'
                )
                ->leftjoin(
                    'invoice_layouts as il',
                    'business_locations.invoice_layout_id',
                    '=',
                    'il.id'
                )
                ->leftjoin(
                    'invoice_layouts as sil',
                    'business_locations.sale_invoice_layout_id',
                    '=',
                    'sil.id'
                )
                ->leftjoin(
                    'selling_price_groups as spg',
                    'business_locations.selling_price_group_id',
                    '=',
                    'spg.id'
                )
                ->select(['business_locations.id as business_locations_id', 'business_locations.business_id', 'business_locations.name', 'location_id', 'landmark', 'city', 'zip_code', 'state',
                    'country', 'business_locations.id', 'spg.name as price_group', 'ic.name as invoice_scheme', 'il.name as invoice_layout', 'sil.name as sale_invoice_layout', 'business_locations.is_active', "business_locations.created_at", "business_locations.remark"]);

            $permitted_locations = auth()->user()->permitted_locations();
            if ($permitted_locations != 'all') {
                $locations->whereIn('business_locations.id', $permitted_locations);
            }

            return Datatables::of($locations)
                ->addColumn(
                    'action',
                    '<button type="button" data-href="{{action(\'BusinessLocationController@edit\', [$id])}}" class="btn btn-xs btn-primary btn-modal" data-container=".location_edit_modal"><i class="glyphicon glyphicon-edit"></i> @lang("messages.edit")</button>
                    <a href="{{route(\'location.settings\', [$id])}}" class="btn btn-success btn-xs"><i class="fa fa-wrench"></i> @lang("messages.settings")</a>

                    <button type="button" data-href="{{action(\'BusinessLocationController@activateDeactivateLocation\', [$id])}}" class="btn btn-xs activate-deactivate-location @if($is_active) btn-danger @else btn-success @endif"><i class="fa fa-power-off"></i> @if($is_active) @lang("lang_v1.deactivate_location") @else @lang("lang_v1.activate_location") @endif </button>
                    '
                )
                ->removeColumn('id')
                ->removeColumn('is_active')
                ->rawColumns([15])
                ->make(false);
        }

        return view('business_location.index');
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        if (!auth()->user()->can('business_settings.access')) {
            abort(403, 'Unauthorized action.');
        }
        $business_id = request()->session()->get('user.business_id');

        //Check if subscribed or not, then check for location quota
        if (!$this->moduleUtil->isSubscribed($business_id)) {
            return $this->moduleUtil->expiredResponse();
        } elseif (!$this->moduleUtil->isQuotaAvailable('locations', $business_id)) {
            return $this->moduleUtil->quotaExpiredResponse('locations', $business_id);
        }

        $invoice_layouts = InvoiceLayout::where('business_id', $business_id)
                            ->get()
                            ->pluck('name', 'id');

        $invoice_schemes = InvoiceScheme::where('business_id', $business_id)
                            ->get()
                            ->pluck('name', 'id');
        $outlets = BusinessOutlets::where('business_id', $business_id)
                        ->get()
                        ->pluck('name', 'id');

        $price_groups = SellingPriceGroup::forDropdown($business_id);

        $payment_types = $this->commonUtil->payment_types(null, false, $business_id);
        
        //Accounts
        $accounts = [];
        if ($this->commonUtil->isModuleEnabled('account')) {
            $accounts = Account::forDropdown($business_id, true, false);
        }

        $outlet_location_array = ['OrchardGateway', 'Vivocity', 'Thomson Plaza','Jem','Suntec','PLQ', 'Hillon Mall', 'SingPost Centre','TWM', 'DTS MARKETING PTE LTD'];
        $business_location_layout_arr = [
            'Layout1' => 'Layout1',
            'Layout2' => 'Layout2'
        ];
        $day_start_time_array = [
            0 => '12 AM', 
            1 => '01 AM',
            2 => '02 AM',
            3 => '03 AM',
            4 => '04 AM',
            5 => '05 AM',
            6 => '06 AM',
            7 => '07 AM',
            8 => '08 AM',
            9 => '09 AM',
            10 => '10 AM',
            11 => '11 AM',
            12 => '12 PM',
            13 => '01 PM',
            14 => '02 PM',
            15 => '03 PM',
            16 => '04 PM',
            17 => '05 PM',
            18 => '06 PM',
            19 => '07 PM',
            20 => '08 PM',
            21 => '09 PM',
            22 => '10 PM',
            23 => '11 PM'
        ];
        $platforms = [
            'pos' => 'POS',
            'digital_ordering' => 'Digital Orderig',
            'kiosk' => 'Kiosk',
        ];

        return view('business_location.create')
                    ->with(compact(
                        'invoice_layouts',
                        'invoice_schemes',
                        'price_groups',
                        'payment_types',
                        'accounts',
                        'outlet_location_array',
                        'day_start_time_array',
                        'business_location_layout_arr',
                        'platforms',
                        'outlets'
                    ));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        if (!auth()->user()->can('business_settings.access')) {
            abort(403, 'Unauthorized action.');
        }

        try {
            $business_id = $request->session()->get('user.business_id');

            //Check if subscribed or not, then check for location quota
            if (!$this->moduleUtil->isSubscribed($business_id)) {
                return $this->moduleUtil->expiredResponse();
            } elseif (!$this->moduleUtil->isQuotaAvailable('locations', $business_id)) {
                return $this->moduleUtil->quotaExpiredResponse('locations', $business_id);
            }

            $input = $request->only(['name', 'receipt_name', 'landmark', 'city', 'state', 'country', 'zip_code', 'invoice_scheme_id',
                'invoice_layout_id', 'mobile', 'alternate_number', 'email', 'website', 'custom_field1', 'custom_field2', 'custom_field3', 'custom_field4', 'location_id', 
                'selling_price_group_id', 'default_payment_accounts','default_cash_float', 'featured_products', 'sale_invoice_layout_id', 'stripe_pk', 'stripe_sk', 
                'lalamove_pk', 'lalamove_sk', 'lunch_start_time', 'lunch_end_time', 'dinner_start_time', 'dinner_end_time', 'uen', 'peppol_secret_key', 'peppol_api_key', 'peppol_business_id', 
                'not_pin_authentication', 'kitchen_receipt_chinese_only', 'hide_delivery_for_web', 'hide_pickup_for_web', 'paynow_number', 'hide_cash_calculator', 'split_kitchen_receipt_by_item', 'lock_change_price', 'show_dine_in', 'show_takeaway', 'show_pickup',
                'show_delivery', 'show_retail', 'show_kiosk', 'show_reservation', 'machine_id', 'outlet_location_id', 'ftp_server', 'ftp_password', 'mall_code', 'tenant_code', 'day_start_time','business_location_layout', 'hide_price_btn_qr', 'paynow_store_code', 'paynow_merchant_no', 'paynow_access_code', 'special_access_pin', 'receipt_header', 'receipt_footer', 'platform', 'is_static_qr','qr_payment_type', 'smooch_public_key', 'smooch_secret_key', 'allow_lesser_cash_float_amount', "ftp_port", "is_sftp",  "razer_verify_key", "razer_secret_key","razer_merchant_id", "razer_application_code","razer_terminal_mid", "razer_store_id", "ftp_login_id", 'redeemsg_api_key', 'is_pin_on_for_print_btn', "ftp_path", "remark"]);

            $input['is_sftp']=!empty($input['is_sftp'])? $input['is_sftp']:0;
            $input['ftp_login_id']=!empty($input['ftp_login_id'])? $input['ftp_login_id']:0;
            $input['remark']= !empty($input['remark'])? $input['remark']: "";
            $input['is_static_qr'] = !empty($input['is_static_qr']) ? $input['is_static_qr'] :0;
            $input['business_id'] = $business_id;
            $input['receipt_name'] = !empty($input['receipt_name']) ? $input['receipt_name'] : null;
            $input['default_payment_accounts'] = !empty($input['default_payment_accounts']) ? json_encode($input['default_payment_accounts']) : null;
            $input['lunch_start_time'] = !empty($input['lunch_start_time']) ? $input['lunch_start_time'] : "11:00:00";
            $input['lunch_end_time'] = !empty($input['lunch_end_time']) ? $input['lunch_end_time'] : "15:00:00";
            $input['dinner_start_time'] = !empty($input['dinner_start_time']) ? $input['dinner_start_time'] : "17:00:00";
            $input['dinner_end_time'] = !empty($input['dinner_end_time']) ? $input['dinner_end_time'] : "22:00:00";
            $input['uen'] = !empty($input['uen']) ? $input['uen'] : null;
            $input['peppol_secret_key'] = !empty($input['peppol_secret_key']) ? $input['peppol_secret_key'] : null;
            $input['peppol_api_key'] = !empty($input['peppol_api_key']) ? $input['peppol_api_key'] : null;
            $input['peppol_business_id'] = !empty($input['peppol_business_id']) ? $input['peppol_business_id'] : null;

            $input['not_pin_authentication'] = (!empty($input['not_pin_authentication']) &&  $input['not_pin_authentication'] == 1) ? 1 : 0;
            $input['kitchen_receipt_chinese_only'] = (!empty($input['kitchen_receipt_chinese_only']) &&  $input['kitchen_receipt_chinese_only'] == 1) ? 1 : 0;
            $input['hide_delivery_for_web'] = (!empty($input['hide_delivery_for_web']) &&  $input['hide_delivery_for_web'] == 1) ? 1 : 0;
            $input['hide_pickup_for_web'] = (!empty($input['hide_pickup_for_web']) &&  $input['hide_pickup_for_web'] == 1) ? 1 : 0;
            $input['paynow_number'] = !empty($input['paynow_number']) ? $input['paynow_number'] : null;
            $input['hide_cash_calculator'] = (!empty($input['hide_cash_calculator']) &&  $input['hide_cash_calculator'] == 1) ? 1 : 0;
            $input['split_kitchen_receipt_by_item'] = (!empty($input['split_kitchen_receipt_by_item']) &&  $input['split_kitchen_receipt_by_item'] == 1) ? 1 : 0;
            $input['lock_change_price'] = (!empty($input['lock_change_price']) &&  $input['lock_change_price'] == 1) ? 1 : 0;
            $input['hide_price_btn_qr'] = (!empty($input['hide_price_btn_qr']) &&  $input['hide_price_btn_qr'] == 1) ? 1 : 0;

            $input['show_dine_in'] = (!empty($input['show_dine_in']) &&  $input['show_dine_in'] == 1) ? 1 : 0;
            $input['show_takeaway'] = (!empty($input['show_takeaway']) &&  $input['show_takeaway'] == 1) ? 1 : 0;
            $input['show_pickup'] = (!empty($input['show_pickup']) &&  $input['show_pickup'] == 1) ? 1 : 0;
            $input['show_delivery'] = (!empty($input['show_delivery']) &&  $input['show_delivery'] == 1) ? 1 : 0;
            $input['show_retail'] = (!empty($input['show_retail']) &&  $input['show_retail'] == 1) ? 1 : 0;
            $input['show_kiosk'] = (!empty($input['show_kiosk']) &&  $input['show_kiosk'] == 1) ? 1 : 0;
            $input['day_start_time'] = (!empty($input['day_start_time']) &&  $input['day_start_time']) ? $input['day_start_time'] : 00;
            $input['business_location_layout'] = (!empty($input['business_location_layout']) &&  $input['business_location_layout']) ? $input['business_location_layout'] : 'Layout2';
            $input['paynow_store_code'] = (!empty($input['paynow_store_code']) &&  $input['paynow_store_code']) ? $input['paynow_store_code'] : '';
            $input['paynow_merchant_no'] = (!empty($input['paynow_merchant_no']) &&  $input['paynow_merchant_no']) ? $input['paynow_merchant_no'] : '';
            $input['paynow_access_code'] = (!empty($input['paynow_access_code']) &&  $input['paynow_access_code']) ? $input['paynow_access_code'] : '';
            $input['special_access_pin'] = (!empty($input['special_access_pin']) &&  $input['special_access_pin']) ? $input['special_access_pin'] : '';
            $input['receipt_header'] = (!empty($input['receipt_header']) &&  $input['receipt_header']) ? $input['receipt_header'] : '';
            $input['receipt_footer'] = (!empty($input['receipt_footer']) &&  $input['receipt_footer']) ? $input['receipt_footer'] : '';
            $input['show_reservation'] = (!empty($input['show_reservation']) &&  $input['show_reservation'] == 1) ? 1 : 0;
            $input['smooch_public_key'] = !empty($input['smooch_public_key']) ? $input['smooch_public_key'] : '';
            $input['smooch_secret_key'] = !empty($input['smooch_secret_key']) ? $input['smooch_secret_key'] : '';
            $input['allow_lesser_cash_float_amount'] = !empty($input['allow_lesser_cash_float_amount']) ? $input['allow_lesser_cash_float_amount'] : 0;
            $input['redeemsg_api_key'] = !empty($input['redeemsg_api_key']) ? $input['redeemsg_api_key'] : null;
            $input['is_pin_on_for_print_btn'] = !empty($input['is_pin_on_for_print_btn']) ? $input['is_pin_on_for_print_btn'] : 0;

            if($request->file('cds') != null) {
                $mimeType = $this->commonUtil->get_mime_type($request->file('cds')->getClientOriginalName());
                //return $mimeType;
                //return array_keys(config('constants.business_location_document_upload_mimes_types'));
                //return json_encode(!in_array($this->commonUtil->get_mime_type($request->file('cds')->getClientOriginalName()), array_keys(config('constants.business_location_document_upload_mimes_types'))));
                $mimePart = explode('/', $mimeType )[0];
                // $input['cds'] = $this->commonUtil->uploadBusinessLocationFile($request, 'cds', config('constants.cds_path'), $mimePart);
                $input['cds'] = $this->commonUtil->uploadFileOnAWSS3($request, 'cds', config('constants.cds_path'), $mimePart);
            } else {
                $input['cds'] = null;
            }

            if($request->file('cds_logo_image') != null) {
                $mimeType = $this->commonUtil->get_mime_type($request->file('cds_logo_image')->getClientOriginalName());
                //return $mimeType;
                //return array_keys(config('constants.business_location_document_upload_mimes_types'));
                //return json_encode(!in_array($this->commonUtil->get_mime_type($request->file('cds')->getClientOriginalName()), array_keys(config('constants.business_location_document_upload_mimes_types'))));
                $mimePart = explode('/', $mimeType )[0];
                // $input['cds_logo_image'] = $this->commonUtil->uploadBusinessLocationFile($request, 'cds_logo_image', config('constants.cds_path'), $mimePart);
                $input['cds_logo_image'] = $this->commonUtil->uploadFileOnAWSS3($request, 'cds_logo_image', config('constants.cds_path'), $mimePart);
            } else {
                $input['cds_logo_image'] = null;
            }

            if($request->file('success_image') != null) {
                $mimeType = $this->commonUtil->get_mime_type($request->file('success_image')->getClientOriginalName());
                $mimePart = explode('/', $mimeType )[0];
                // $input['success_image'] = $this->commonUtil->uploadBusinessLocationFile($request, 'success_image', config('constants.success_path'), $mimePart);
                $input['success_image'] = $this->commonUtil->uploadFileOnAWSS3($request, 'success_image', config('constants.success_path'), $mimePart);
            } else {
                $input['success_image'] = null;
            }

            if($request->file('logo') != null) {
                $mimeType = $this->commonUtil->get_mime_type($request->file('logo')->getClientOriginalName());
                //return $mimeType;
                //return array_keys(config('constants.business_location_document_upload_mimes_types'));
                //return json_encode(!in_array($this->commonUtil->get_mime_type($request->file('cds')->getClientOriginalName()), array_keys(config('constants.business_location_document_upload_mimes_types'))));
                $mimePart = explode('/', $mimeType )[0];
                // $input['logo'] = $this->commonUtil->uploadBusinessLocationFile($request, 'logo', config('constants.cds_path'), $mimePart);
                $input['logo'] = $this->commonUtil->uploadFileOnAWSS3($request, 'logo', config('constants.cds_path'), $mimePart);
            } else {
                $input['logo'] = null;
            }
            //return $input['cds'];

            //Update reference count
            $ref_count = $this->moduleUtil->setAndGetReferenceCount('business_location');

            if (empty($input['location_id'])) {
                $input['location_id'] = $this->moduleUtil->generateReferenceNumber('business_location', $ref_count);
            }

            $location = BusinessLocation::create($input);

            //Create a new permission related to the created location
            Permission::create(['name' => 'location.' . $location->id ]);

            $output = ['success' => true,
                            'msg' => __("business.business_location_added_success")
                        ];
        } catch (\Exception $e) {
            \Log::emergency("File:" . $e->getFile(). "Line:" . $e->getLine(). "Message:" . $e->getMessage());
            
            $output = ['success' => false,
                            'msg' => __("messages.something_went_wrong")
                        ];
        }

        return $output;
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\StoreFront  $storeFront
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\StoreFront  $storeFront
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        if (!auth()->user()->can('business_settings.access')) {
            abort(403, 'Unauthorized action.');
        }

        $business_id = request()->session()->get('user.business_id');
        $location = BusinessLocation::where('business_id', $business_id)
                                    ->find($id);
        
        $invoice_layouts = InvoiceLayout::where('business_id', $business_id)
                            ->get()
                            ->pluck('name', 'id');
        $invoice_schemes = InvoiceScheme::where('business_id', $business_id)
                            ->get()
                            ->pluck('name', 'id');

        $price_groups = SellingPriceGroup::forDropdown($business_id);
        $outlets = BusinessOutlets::where('business_id', $business_id)
                        ->get()
                        ->pluck('name', 'id');
    
        $payment_types = $this->commonUtil->payment_types(null, false, $business_id);

        //Accounts
        $accounts = [];
        if ($this->commonUtil->isModuleEnabled('account')) {
            $accounts = Account::forDropdown($business_id, true, false);
        }
        $featured_products = $location->getFeaturedProducts(true, false);

        $outlet_location_array = ['OrchardGateway', 'Vivocity', 'Thomson Plaza','Jem','Suntec','PLQ', 'Hillon Mall', 'SingPost Centre','TWM', 'DTS MARKETING PTE LTD'];
        $business_location_layout_arr = [
            'Layout1' => 'Layout1',
            'Layout2' => 'Layout2'
        ];
        $platforms = [
            'pos' => 'POS',
            'digital_ordering' => 'Digital Orderig',
            'kiosk' => 'Kiosk',
        ];
        $day_start_time_array = [
            0 => '12 AM', 
            1 => '01 AM',
            2 => '02 AM',
            3 => '03 AM',
            4 => '04 AM',
            5 => '05 AM',
            6 => '06 AM',
            7 => '07 AM',
            8 => '08 AM',
            9 => '09 AM',
            10 => '10 AM',
            11 => '11 AM',
            12 => '12 PM',
            13 => '01 PM',
            14 => '02 PM',
            15 => '03 PM',
            16 => '04 PM',
            17 => '05 PM',
            18 => '06 PM',
            19 => '07 PM',
            20 => '08 PM',
            21 => '09 PM',
            22 => '10 PM',
            23 => '11 PM'
        ];

        return view('business_location.edit')
                ->with(compact(
                    'location',
                    'invoice_layouts',
                    'invoice_schemes',
                    'price_groups',
                    'payment_types',
                    'accounts',
                    'featured_products',
                    'outlet_location_array',
                    'day_start_time_array',
                    'business_location_layout_arr',
                    'platforms',
                    "outlets"
                ));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\StoreFront  $storeFront
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        if (!auth()->user()->can('business_settings.access')) {
            abort(403, 'Unauthorized action.');
        }

        try {
            
            $business_id = $request->session()->get('user.business_id');

            $business_location = BusinessLocation::where('business_id', $business_id)
                                ->where('id', $id)
                                ->first();

            $input = $request->only(['name', 'receipt_name', 'landmark', 'city', 'state', 'country',
                'zip_code', 'invoice_scheme_id',
                'invoice_layout_id', 'mobile', 'alternate_number', 'email', 'website', 'custom_field1', 'custom_field2', 'custom_field3', 
                'custom_field4', 'location_id', 'selling_price_group_id', 'default_payment_accounts', 'default_cash_float', 'featured_products', 
                'sale_invoice_layout_id', 'stripe_pk', 'stripe_sk', 'lalamove_pk', 'lalamove_sk', 'lunch_start_time', 'lunch_end_time', 
                'dinner_start_time', 'dinner_end_time', 'uen', 'peppol_secret_key', 'peppol_api_key', 'peppol_business_id', 'not_pin_authentication', 
                'kitchen_receipt_chinese_only', 'hide_delivery_for_web', 'hide_pickup_for_web', 'paynow_number', 'hide_cash_calculator', 'split_kitchen_receipt_by_item', 'lock_change_price', 'show_dine_in', 'show_takeaway', 'show_pickup', 
                'show_delivery', 'show_retail', 'show_kiosk', 'show_reservation', 'machine_id', 'outlet_location_id', 'ftp_server', 'ftp_password', 'mall_code', 'tenant_code', 'day_start_time', 'logo','business_location_layout', 'hide_price_btn_qr', 'paynow_store_code', 'paynow_merchant_no', 'paynow_access_code', 'special_access_pin', 'enable_special_access_pin', 'receipt_header', 'receipt_footer', 'is_static_qr','qr_payment_type', 'smooch_public_key', 'smooch_secret_key', 'allow_lesser_cash_float_amount',  "ftp_port", "is_sftp" , "razer_verify_key", "razer_secret_key","razer_merchant_id", "razer_application_code","razer_terminal_mid", "razer_store_id", "ftp_login_id", "redeemsg_api_key", "is_pin_on_for_print_btn","ftp_path", "remark"]);

            $input['is_sftp']=!empty($input['is_sftp'])? $input['is_sftp']:0;
            $input['ftp_login_id']=!empty($input['ftp_login_id'])? $input['ftp_login_id']:0;
            $input['remark']=!empty($input['remark'])? $input['remark']: "";
            $input['is_static_qr'] = !empty($input['is_static_qr']) ? $input['is_static_qr'] :0;
            $input['receipt_name'] = !empty($input['receipt_name']) ? $input['receipt_name'] : null;
            $input['default_payment_accounts'] = !empty($input['default_payment_accounts']) ? json_encode($input['default_payment_accounts']) : null;

            $input['featured_products'] = !empty($input['featured_products']) ? json_encode($input['featured_products']) : null;
            $input['lunch_start_time'] = !empty($input['lunch_start_time']) ? $input['lunch_start_time'] : "11:00:00";
            $input['lunch_end_time'] = !empty($input['lunch_end_time']) ? $input['lunch_end_time'] : "15:00:00";
            $input['dinner_start_time'] = !empty($input['dinner_start_time']) ? $input['dinner_start_time'] : "17:00:00";
            $input['dinner_end_time'] = !empty($input['dinner_end_time']) ? $input['dinner_end_time'] : "22:00:00";
            $input['uen'] = !empty($input['uen']) ? $input['uen'] : null;
            $input['peppol_secret_key'] = !empty($input['peppol_secret_key']) ? $input['peppol_secret_key'] : null;
            $input['peppol_api_key'] = !empty($input['peppol_api_key']) ? $input['peppol_api_key'] : null;
            $input['peppol_business_id'] = !empty($input['peppol_business_id']) ? $input['peppol_business_id'] : null;

            $input['not_pin_authentication'] = (!empty($input['not_pin_authentication']) &&  $input['not_pin_authentication'] == 1) ? 1 : 0;
            $input['kitchen_receipt_chinese_only'] = (!empty($input['kitchen_receipt_chinese_only']) &&  $input['kitchen_receipt_chinese_only'] == 1) ? 1 : 0;
            $input['hide_delivery_for_web'] = (!empty($input['hide_delivery_for_web']) &&  $input['hide_delivery_for_web'] == 1) ? 1 : 0;
            $input['hide_pickup_for_web'] = (!empty($input['hide_pickup_for_web']) &&  $input['hide_pickup_for_web'] == 1) ? 1 : 0;
            $input['paynow_number'] = !empty($input['paynow_number']) ? $input['paynow_number'] : null;
            $input['hide_cash_calculator'] = (!empty($input['hide_cash_calculator']) &&  $input['hide_cash_calculator'] == 1) ? 1 : 0;
            $input['split_kitchen_receipt_by_item'] = (!empty($input['split_kitchen_receipt_by_item']) &&  $input['split_kitchen_receipt_by_item'] == 1) ? 1 : 0;
            $input['lock_change_price'] = (!empty($input['lock_change_price']) &&  $input['lock_change_price'] == 1) ? 1 : 0;
            $input['hide_price_btn_qr'] = (!empty($input['hide_price_btn_qr']) &&  $input['hide_price_btn_qr'] == 1) ? 1 : 0;

            $input['show_dine_in'] = (!empty($input['show_dine_in']) &&  $input['show_dine_in'] == 1) ? 1 : 0;
            $input['show_takeaway'] = (!empty($input['show_takeaway']) &&  $input['show_takeaway'] == 1) ? 1 : 0;
            $input['show_pickup'] = (!empty($input['show_pickup']) &&  $input['show_pickup'] == 1) ? 1 : 0;
            $input['show_delivery'] = (!empty($input['show_delivery']) &&  $input['show_delivery'] == 1) ? 1 : 0;
            $input['show_retail'] = (!empty($input['show_retail']) &&  $input['show_retail'] == 1) ? 1 : 0;
            $input['show_kiosk'] = (!empty($input['show_kiosk']) &&  $input['show_kiosk'] == 1) ? 1 : 0;
            $input['day_start_time'] = (!empty($input['day_start_time']) &&  $input['day_start_time']) ? $input['day_start_time'] : 00;
            $input['business_location_layout'] = (!empty($input['business_location_layout']) &&  $input['business_location_layout']) ? $input['business_location_layout'] : 'Layout2';
            $input['paynow_store_code'] = (!empty($input['paynow_store_code']) &&  $input['paynow_store_code']) ? $input['paynow_store_code'] : '';
            $input['paynow_merchant_no'] = (!empty($input['paynow_merchant_no']) &&  $input['paynow_merchant_no']) ? $input['paynow_merchant_no'] : '';
            $input['paynow_access_code'] = (!empty($input['paynow_access_code']) &&  $input['paynow_access_code']) ? $input['paynow_access_code'] : '';
            $input['special_access_pin'] = (!empty($input['special_access_pin']) &&  $input['special_access_pin']) ? $input['special_access_pin'] : '';
            $input['enable_special_access_pin'] = (!empty($input['enable_special_access_pin']) &&  $input['enable_special_access_pin']) ? $input['enable_special_access_pin'] : 0;
            $input['receipt_header'] = (!empty($input['receipt_header']) &&  $input['receipt_header']) ? $input['receipt_header'] : '';
            $input['receipt_footer'] = (!empty($input['receipt_footer']) &&  $input['receipt_footer']) ? $input['receipt_footer'] : '';
            $input['show_reservation'] = (!empty($input['show_reservation']) &&  $input['show_reservation'] == 1) ? 1 : 0;
            $input['smooch_public_key'] = !empty($input['smooch_public_key']) ? $input['smooch_public_key'] : '';
            $input['smooch_secret_key'] = !empty($input['smooch_secret_key']) ? $input['smooch_secret_key'] : '';
            $input['allow_lesser_cash_float_amount'] = !empty($input['allow_lesser_cash_float_amount']) ? $input['allow_lesser_cash_float_amount'] : 0;
            $input['redeemsg_api_key'] = !empty($input['redeemsg_api_key']) ? $input['redeemsg_api_key'] : null;
            $input['is_pin_on_for_print_btn'] = !empty($input['is_pin_on_for_print_btn']) ? $input['is_pin_on_for_print_btn'] : 0;


            if($request->file('cds') != null) {
                $mimeType = $this->commonUtil->get_mime_type($request->file('cds')->getClientOriginalName());
                //return $mimeType;
                //return array_keys(config('constants.business_location_document_upload_mimes_types'));
                //return json_encode(!in_array($this->commonUtil->get_mime_type($request->file('cds')->getClientOriginalName()), array_keys(config('constants.business_location_document_upload_mimes_types'))));
                $mimePart = explode('/', $mimeType )[0];
                // $cds = $this->commonUtil->uploadBusinessLocationFile($request, 'cds', config('constants.cds_path'), $mimePart);
                $cds = $this->commonUtil->uploadFileOnAWSS3($request, 'cds', config('constants.cds_path'), $mimePart);

                if (!empty($cds)) {
                    /*
                    if (!empty($business_location->cds)) {
                        $image_path = public_path('uploads') . '/' . config('constants.cds_path') . '/' . $business_location->cds;
                    } else {
                        $image_path = null;
                    }
                    //If previous image found then remove
                    if (!empty($image_path) && file_exists($image_path)) {
                        unlink($image_path);
                    }
                    */
                    
                    $input['cds'] = $cds;
                }
            } 

            if($request->file('cds_logo_image') != null) {
                $mimeType = $this->commonUtil->get_mime_type($request->file('cds_logo_image')->getClientOriginalName());
                //return $mimeType;
                //return array_keys(config('constants.business_location_document_upload_mimes_types'));
                //return json_encode(!in_array($this->commonUtil->get_mime_type($request->file('cds')->getClientOriginalName()), array_keys(config('constants.business_location_document_upload_mimes_types'))));
                $mimePart = explode('/', $mimeType )[0];
                // $cds_logo_image = $this->commonUtil->uploadBusinessLocationFile($request, 'cds_logo_image', config('constants.cds_path'), $mimePart);
                $cds_logo_image = $this->commonUtil->uploadFileOnAWSS3($request, 'cds_logo_image', config('constants.cds_path'), $mimePart);

                if (!empty($cds_logo_image)) {
                    /*
                    if (!empty($business_location->cds_logo_image)) {
                        $image_path = public_path('uploads') . '/' . config('constants.cds_path') . '/' . $business_location->cds_logo_image;
                    } else {
                        $image_path = null;
                    }
                    //If previous image found then remove
                    if (!empty($image_path) && file_exists($image_path)) {
                        unlink($image_path);
                    }
                    */
                    
                    $input['cds_logo_image'] = $cds_logo_image;
                }
            } 

            if($request->file('success_image') != null) {
                $mimeType = $this->commonUtil->get_mime_type($request->file('success_image')->getClientOriginalName());
                //return $mimeType;
                //return array_keys(config('constants.business_location_document_upload_mimes_types'));
                //return json_encode(!in_array($this->commonUtil->get_mime_type($request->file('cds')->getClientOriginalName()), array_keys(config('constants.business_location_document_upload_mimes_types'))));
                $mimePart = explode('/', $mimeType )[0];
                // $success_image = $this->commonUtil->uploadBusinessLocationFile($request, 'success_image', config('constants.success_path'), $mimePart);
                $success_image = $this->commonUtil->uploadFileOnAWSS3($request, 'success_image', config('constants.success_path'), $mimePart);

                if (!empty($success_image)) {
                    /*
                    if (!empty($business_location->success_image)) {
                        $image_path = public_path('uploads') . '/' . config('constants.success_path') . '/' . $business_location->success_image;
                    } else {
                        $image_path = null;
                    }
                    //If previous image found then remove
                    if (!empty($image_path) && file_exists($image_path)) {
                        unlink($image_path);
                    }
                    */
                    
                    $input['success_image'] = $success_image;
                }
            } 

            if($request->file('logo') != null) {
                $mimeType = $this->commonUtil->get_mime_type($request->file('logo')->getClientOriginalName());
                //return $mimeType;
                //return array_keys(config('constants.business_location_document_upload_mimes_types'));
                //return json_encode(!in_array($this->commonUtil->get_mime_type($request->file('cds')->getClientOriginalName()), array_keys(config('constants.business_location_document_upload_mimes_types'))));
                $mimePart = explode('/', $mimeType )[0];
                // $logo = $this->commonUtil->uploadBusinessLocationFile($request, 'logo', config('constants.cds_path'), $mimePart);
                $logo = $this->commonUtil->uploadFileOnAWSS3($request, 'logo', config('constants.cds_path'), $mimePart);

                if (!empty($logo)) {
                    /*
                    if (!empty($business_location->logo)) {
                        $image_path = public_path('uploads') . '/' . config('constants.cds_path') . '/' . $business_location->logo;
                    } else {
                        $image_path = null;
                    }
                    //If previous image found then remove
                    if (!empty($image_path) && file_exists($image_path)) {
                        unlink($image_path);
                    }
                    */
                    
                    $input['logo'] = $logo;
                }
            } 

            BusinessLocation::where('business_id', $business_id)
                            ->where('id', $id)
                            ->update($input);

            $output = ['success' => true,
                            'msg' => __('business.business_location_updated_success')
                        ];
        } catch (\Exception $e) {
            \Log::emergency("File:" . $e->getFile(). "Line:" . $e->getLine(). "Message:" . $e->getMessage());
            
            $output = ['success' => false,
                            'msg' => __("messages.something_went_wrong")
                        ];
        }

        return $output;
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\StoreFront  $storeFront
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }

    /**
    * Checks if the given location id already exist for the current business.
    *
    * @param  \Illuminate\Http\Request  $request
    * @return \Illuminate\Http\Response
    */
    public function checkLocationId(Request $request)
    {
        $location_id = $request->input('location_id');

        $valid = 'true';
        if (!empty($location_id)) {
            $business_id = $request->session()->get('user.business_id');
            $hidden_id = $request->input('hidden_id');

            $query = BusinessLocation::where('business_id', $business_id)
                            ->where('location_id', $location_id);
            if (!empty($hidden_id)) {
                $query->where('id', '!=', $hidden_id);
            }
            $count = $query->count();
            if ($count > 0) {
                $valid = 'false';
            }
        }
        echo $valid;
        exit;
    }

    /**
     * Function to activate or deactivate a location.
     * @param int $location_id
     *
     * @return json
     */
    public function activateDeactivateLocation($location_id)
    {
        if (!auth()->user()->can('business_settings.access')) {
            abort(403, 'Unauthorized action.');
        }

        try {
            $business_id = request()->session()->get('user.business_id');

            $business_location = BusinessLocation::where('business_id', $business_id)
                            ->findOrFail($location_id);

            $business_location->is_active = !$business_location->is_active;
            $business_location->save();

            $msg = $business_location->is_active ? __('lang_v1.business_location_activated_successfully') : __('lang_v1.business_location_deactivated_successfully');

            $output = ['success' => true,
                            'msg' => $msg
                        ];
        } catch (\Exception $e) {
            \Log::emergency("File:" . $e->getFile(). "Line:" . $e->getLine(). "Message:" . $e->getMessage());
            
            $output = ['success' => false,
                            'msg' => __("messages.something_went_wrong")
                        ];
        }

        return $output;
    }

    public function razerPayVcode(Request $request) {
        $input = $request->only(['business_id', 'location_id', 'amount']);
        
        $location = BusinessLocation::where('business_id', $input["business_id"])
            ->where('id', $input["location_id"])
            ->select("razer_verify_key", "razer_secret_key", "razer_merchant_id", "razer_application_code", "razer_terminal_mid")
            ->first(); 
            if ($location) {
                $uuid = Str::uuid()->toString();
            $razorConfigId = md5($input['amount'] . $location->razer_merchant_id . $uuid . $location->razer_verify_key);
            return response()->json(['vcode' => $razorConfigId , 'order_id' =>  $uuid], 200);        
            } else {
                return response()->json(['errorMessage' => 'Location not found'], 404);
            }
       
    }
}
