<?php

namespace App\Http\Controllers;

use App\CouponLayout;
use Illuminate\Http\Request;
use Datatables;

class PeppolNewController extends Controller
{
    
    public function index(Request $request)
    {
        
        // if (!auth()->user()->can('coupon_layout.view')) {
        //     abort(403, 'Unauthorized action.');
        // }

        // if (request()->ajax()) {
        //     $business_id = request()->session()->get('user.business_id');

        //     $barcodes = CouponLayout::where('business_id', $business_id)
        //                 ->select(['id','name']);

        //     return Datatables::of($barcodes)
        //         ->addColumn(
        //             'action',
        //             '<a href="{{action(\'CouponLayoutController@edit\', [$id])}}" class="btn btn-xs btn-primary"><i class="glyphicon glyphicon-edit"></i> @lang("messages.edit")</a>
        //                 &nbsp;
        //                 <button type="button" data-href="{{action(\'CouponLayoutController@destroy\', [$id])}}" class="btn btn-xs btn-danger delete_barcode_button" ><i class="glyphicon glyphicon-trash"></i> @lang("messages.delete")</button>&nbsp;
        //                 '
        //         )
        //         ->rawColumns([0, 2])
        //         ->make(false);
        // }

        return view('coupon_layout.index');
    }

    public function dashboard(Request $request) {
        return view('coupon_layout.index');
    }

    public function create()
    {
        
        if (!auth()->user()->can('coupon_layout.create')) {
            abort(403, 'Unauthorized action.');
        }

        return view('coupon_layout.create-new');
    }

    public function store(Request $request)
    {
        if (!auth()->user()->can('coupon_layout.create')) {
            abort(403, 'Unauthorized action.');
        }
    
        try {
            $input = $request->only(['name','front_extra_field','front_layout_code','back_extra_field','back_layout_code']);
            
            $business_id = $request->session()->get('user.business_id');
            $input['business_id'] = $business_id;
            $input['location_id'] = 0;
            
            CouponLayout::create($input);
        
            $output = ['success' => 1,
                            'msg' => 'Successfully added'
                        ];
            
        } catch (\Exception $e) {
            \Log::emergency("File:" . $e->getFile(). "Line:" . $e->getLine(). "Message:" . $e->getMessage());
            
            $output = ['success' => 0,
                            'msg' => __("messages.something_went_wrong")
                        ];
        } 

        return redirect('coupons-layout')->with('status', $output);
    }

    public function getLayout($id)
    {
        $business_id = request()->session()->get('user.business_id');
        if (request()->ajax()) {
            $CouponLayout = CouponLayout::find($id);
            $output = [
                'front_layout_code' => $CouponLayout->front_layout_code,
                'back_layout_code' => $CouponLayout->back_layout_code,
            ];
            return $output;
        }
    }

    public function edit($id)
    {
        if (!auth()->user()->can('coupon_layout.update')) {
            abort(403, 'Unauthorized action.');
        }

        $business_id = request()->session()->get('user.business_id');
        $CouponLayout = CouponLayout::where('business_id', $business_id)->find($id);

        return view('coupon_layout.edit')
            ->with(compact('CouponLayout'));
    }

    public function update(Request $request, $id)
    {
        if (!auth()->user()->can('coupon_layout.update')) {
            abort(403, 'Unauthorized action.');
        }

        try {
            $input = $request->only(['name','front_extra_field','front_layout_code','back_extra_field','back_layout_code']);
            
            $business_id = $request->session()->get('user.business_id');
            $input['business_id'] = $business_id;
            $input['location_id'] = 0;
            
            $barcode = CouponLayout::where('id', $id)->update($input);
            
            $output = ['success' => 1,
                          'msg' => 'Successfully Updated'
                      ];
        } catch (\Exception $e) {
            \Log::emergency("File:" . $e->getFile(). "Line:" . $e->getLine(). "Message:" . $e->getMessage());
            
            $output = ['success' => 0,
                           'msg' => __("messages.something_went_wrong")
                       ];
        }

        return redirect('coupons-layout')->with('status', $output);
    }

    public function destroy($id)
    {
        if (!auth()->user()->can('coupon_layout.delete')) {
            abort(403, 'Unauthorized action.');
        }

        if (request()->ajax()) {
            try {
                $barcode = CouponLayout::find($id);
                    $barcode->delete();
                    $output = ['success' => true,
                                'msg' => 'Successfully Deleted'
                                ];
                
            } catch (\Exception $e) {
                \Log::emergency("File:" . $e->getFile(). "Line:" . $e->getLine(). "Message:" . $e->getMessage());
            
                $output = ['success' => false,
                            'msg' => __("messages.something_went_wrong")
                        ];
            }

            return $output;
        }
    }

    
}
