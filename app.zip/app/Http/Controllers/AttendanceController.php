<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Utils\ModuleUtil;
use Illuminate\Support\Facades\DB;
use App\Attendance;
use Carbon\Carbon;
use Datatables;
use App\Breaks;
use App\BusinessLocation;
use Config;
use App\User;


class AttendanceController extends Controller
{
    public function __construct(ModuleUtil $moduleUtil)
    {
        $this->moduleUtil = $moduleUtil;
    }

    public function attendance_report()
    {
        if (!auth()->user()->can('access_tables')) {
            abort(403, 'Unauthorized action.');
        }
        if (request()->ajax()) {
            $business_id = request()->session()->get('user.business_id');
            $location_id = request()->get('location_id');
            $start_date = request()->get('start_date');
            $end_date = request()->get('end_date');
            $user_id = request()->get('user_id');

            $start_date = $start_date ? Carbon::parse($start_date)->startOfDay()->toDateTimeString() : null;
            $end_date = $end_date ? Carbon::parse($end_date)->endOfDay()->toDateTimeString() : null;

            $attendances = Attendance::where('attendances.business_id', $business_id)
                                    ->when($location_id, function ($query) use ($location_id) {
                                        return $query->where('attendances.location_id', $location_id);
                                    })
                                    ->when($user_id, function ($query) use ($user_id) {
                                        return $query->where('attendances.attendee_user_id', $user_id);
                                    })
                                    ->when($start_date && $end_date, function ($query) use ($start_date, $end_date) {
                                        return $query->whereBetween('attendances.created_at', [$start_date, $end_date]);
                                    })
                                    ->select([
                                        'attendances.id',
                                        'attendances.attendee_user_id',
                                        'attendances.clockin_time',
                                        'attendances.clockout_time',
                                        'attendances.total_working_hours',
                                        'users.first_name',
                                        'users.last_name',
                                        DB::raw('DATE(attendances.created_at) as attendance_date'),
                                    ])
                                    ->join('users', 'attendances.attendee_user_id', '=', 'users.id')
                                    ->get();
    
            // Fetch breaks data as before
            $breaks = Breaks::where('breaks.business_id', $business_id)
                            ->when($location_id, function ($query) use ($location_id) {
                                return $query->where('breaks.location_id', $location_id);
                            })
                            ->when($user_id, function ($query) use ($user_id) {
                                return $query->where('breaks.user_id', $user_id);
                            })
                            ->when($start_date && $end_date, function ($query) use ($start_date, $end_date) {
                                return $query->whereBetween(DB::raw('DATE(breaks.created_at)'), [$start_date, $end_date]);
                            })
                            ->select([
                                'breaks.user_id',
                                DB::raw('DATE(breaks.created_at) as break_date'),
                                DB::raw('SUM(TIME_TO_SEC(TIMEDIFF(breaks.break_end_time, breaks.break_start_time)) / 3600) as total_break_hours')
                            ])
                            ->groupBy('breaks.user_id', 'break_date')
                            ->get();
            $processedData = [];
            foreach ($attendances as $attendance) {
                $date = $attendance->attendance_date;
                $session_id = $attendance->id;
                $attendee_user_id = $attendance->attendee_user_id;

                if ($attendance->clockout_time != null) {
                        $clockin = strtotime($attendance->clockin_time);
                        $clockout = strtotime($attendance->clockout_time);
                        $working_hours_seconds = $clockout - $clockin; // in seconds
                }
                else{
                    $working_hours_seconds = 0;
                }
                $attendance_breaks_seconds = Breaks::where('user_id', $attendee_user_id)
                    ->where('session_id', $session_id)
                    ->whereDate('created_at', $date)
                    ->sum(DB::raw('TIME_TO_SEC(TIMEDIFF(break_end_time, break_start_time))'));
                // Calculate the actual working hours in seconds
                $actual_working_hours_seconds = $working_hours_seconds ? $working_hours_seconds - $attendance_breaks_seconds : 0;
                        
                $key = $attendee_user_id . '-' . $date;
                if (!isset($processedData[$key])) {
                    $processedData[$key] = (object)[
                        'id' => $attendance->id,
                        'attendee_user_id' => $attendance->attendee_user_id,
                        'first_name' => $attendance->first_name,
                        'last_name' => $attendance->last_name,
                        'date' => $date,
                        'first_clockin_time' => $attendance->clockin_time,
                        'last_clockout_time' => $attendance->clockout_time,
                        'total_working_hours_seconds' => $actual_working_hours_seconds,
                        'total_break_time_seconds' => $attendance_breaks_seconds,
                        'total_working_second'=>$attendance->total_working_hours
                    ];

                } elseif( $processedData[$key]->attendee_user_id == $attendance->attendee_user_id &&  $processedData[$key]->date == $date) {
                    $processedData[$key]->last_clockout_time =  $attendance->clockout_time == null ? $processedData[$key]->last_clockout_time : $attendance->clockout_time;
                    $processedData[$key]->total_working_hours_seconds += $actual_working_hours_seconds;
                    $processedData[$key]->total_break_time_seconds += $attendance_breaks_seconds;
                    $processedData[$key]->total_working_second += $attendance->total_working_hours;
                }
            }
            $formattedData = [];
            foreach ($processedData as $data) {
                $obj = new \stdClass();
                $obj->id = $data->id;
                $obj->attendee_user_id = $data->attendee_user_id;
                $obj->first_name = $data->last_name ? $data->first_name.' '.$data->last_name : $data->first_name;
                $obj->last_name = $data->last_name;
                $obj->first_clockin_time = date('h:i A', strtotime($data->first_clockin_time));
                $obj->last_clockout_time = $data->last_clockout_time != null ? date('h:i A', strtotime($data->last_clockout_time)): null;
                $total_working_hours = gmdate('H:i:s', $data->total_working_second);
                $carbonTime = Carbon::createFromFormat('H:i:s', $total_working_hours);
                $formattedTime = $carbonTime->format('H \H\r\s i \M\i\n');
                $obj->total_working_hours  =  $formattedTime;
                $obj->total_shift_hours = '00 Hrs'; // You may need to calculate this based on business logic
                $obj->total_break_time = gmdate('H:i:s', $data->total_break_time_seconds);
                $obj->date = $data->date;
                $formattedData[] = $obj;
            }
            return Datatables::of($formattedData)
                ->addColumn(
                    'action',
                    function ($row) {
                        return '<a href="' . action('AttendanceController@history', [$row->attendee_user_id ,$row->date]) . '" class="btn btn-xs btn-primary">History</a>';
                    }
                )
                ->rawColumns(['action'])
                ->make(true);
        }
    
        $business_id = request()->session()->get('user.business_id');
        $business_locations = BusinessLocation::forDropdown($business_id);
        $users = User::where('users.business_id', $business_id)
                    ->where('user_type' ,'=', 'user')
                    ->select('users.id', DB::raw('CONCAT(users.first_name, " ", IFNULL(users.last_name, "")) AS name'))
                    ->pluck('name', 'id');
        
        return view('attendance.index')->with(compact("business_locations", "users"));
    }

    public function history(Request $request, $user_id, $date)
    {
        if (!auth()->user()->can('access_tables')) {
            abort(403, 'Unauthorized action.');
        }        
        if ($request->ajax()) {
            $business_id = $request->session()->get('user.business_id');
            $location_id = $request->get('location_id');
            $start_date = $start_date ? Carbon::parse($start_date)->startOfDay()->toDateTimeString() : null;
            $end_date = $end_date ? Carbon::parse($end_date)->endOfDay()->toDateTimeString() : null;
    
            $attendances = Attendance::where('attendances.business_id', $business_id)
                ->where('attendances.attendee_user_id', $user_id)
                ->when($location_id, function ($query) use ($location_id) {
                    return $query->where('attendances.location_id', $location_id);
                })
                ->whereDate('attendances.created_at', $date)
                ->select([
                    'attendances.id',
                    'attendances.attendee_user_id',
                    'attendances.clockin_time',
                    'attendances.clockout_time',
                    'attendances.created_at',
                    'users.first_name',
                    'users.last_name',
                    DB::raw('DATE(attendances.created_at) as attendance_date'),
                ])
                ->join('users', 'attendances.attendee_user_id', '=', 'users.id')
                ->orderBy('attendances.created_at', 'ASC')
                ->get();
    
            $breaks = Breaks::where('breaks.business_id', $business_id)
                ->where('breaks.user_id', $user_id)
                ->when($location_id, function ($query) use ($location_id) {
                    return $query->where('breaks.location_id', $location_id);
                })
                ->whereDate('breaks.created_at', $date)
                ->select([
                    'breaks.id',
                    'breaks.user_id',
                    'breaks.break_start_time',
                    'breaks.break_end_time',
                    'breaks.session_id',
                    DB::raw('DATE(breaks.created_at) as break_date'),
                ])
                ->orderBy('breaks.created_at', 'ASC')
                ->get();
    
            $formattedData = [];
            $serial_no = 1;
            $date_checker = '';
            foreach ($attendances as $attendance) {
                $break_start_count = 1;
                $break_end_count = 1;
                if($date_checker == '' || $date_checker != $attendance->attendance_date){
                    $clockin_count = 1;
                    $clockout_count = 1;
                }
    
                $formattedData[] = [
                    'serial_no' => $serial_no++,
                    'date' => $attendance->attendance_date,
                    'time' => $attendance->clockin_time,
                    'type' => 'Clock-in ' . $clockin_count++,
                ];
                $date_checker = $attendance->attendance_date;
                $session_breaks = $breaks->where('session_id', $attendance->id);
    
                foreach ($session_breaks as $break) {
                    $formattedData[] = [
                        'serial_no' => $serial_no++,
                        'date' => $break->break_date,
                        'time' => $break->break_start_time,
                        'type' => 'Start break ' . $break_start_count++,
                    ];
    
                    if ($break->break_end_time) {
                        $formattedData[] = [
                            'serial_no' => $serial_no++,
                            'date' => $break->break_date,
                            'time' => $break->break_end_time,
                            'type' => 'End break ' . $break_end_count++,
                        ];
                    }
                }
    
                if ($attendance->clockout_time) {
                    $formattedData[] = [
                        'serial_no' => $serial_no++,
                        'date' => $attendance->attendance_date,
                        'time' => $attendance->clockout_time,
                        'type' => 'Clock-out ' . $clockout_count++,
                    ];
                }
            }
            return Datatables::of($formattedData)
                    ->make(true);
            }
        $business_id = $request->session()->get('user.business_id');
        $user_details = User::where('id', $user_id)
                            ->where('business_id', $business_id)
                            ->where('user_type' ,'=','user')
                            ->select('id', DB::raw('CONCAT(first_name, " ", IFNULL(last_name, "")) AS name'), 'status')->first();
        $role_name = $this->moduleUtil->getUserRoleName($user_id);
        $user_details->role = $role_name;
        $business_locations = BusinessLocation::forDropdown($business_id);
    
        return view('attendance.history')->with(compact('user_id', 'business_locations','user_details', 'date'));
    }
    

    public function edit($id)
    {
        if (!auth()->user()->can('access_tables')) {
            abort(403, 'Unauthorized action.');
        }
        if (request()->ajax()) {
            $business_id = request()->session()->get('user.business_id');
            $creditPromo = CreditPromos::join('business_locations', 'credit_promos.location_id', '=', 'business_locations.id')
            ->where('credit_promos.business_id', $business_id)
            ->where('credit_promos.id', $id)
            ->select('credit_promos.*', 'business_locations.name as location_name', 'business_locations.location_id as location_id')
            ->first();

        
            $location = $creditPromo ? $creditPromo->location_name.'('.$creditPromo->location_id.')' : '';
            $creditPromo['business_locations']= $location ; 
            return view('credit_promos.edit')->with(compact('creditPromo'));
        }
    }
    public function clockIn(Request $request)
    {   
        if (isset($request['token'])) {
            $result = User::checkUserToken($request['token'], $request['user_id']);

            if ($result) {
                $attendee_user_id = $request->input('attendee_user_id');
                $location_id =  $request->input('location_id');
                $created_at = Carbon::now()->format('Y-m-d');
                $current_time = Carbon::now()->format('H:i:s');
                $today = "";
                $tomorrow = "";
                $businessLocation = BusinessLocation::find($location_id);
                if (!empty($businessLocation) && !empty($businessLocation->day_start_time)) {
                    $daystartTime = $businessLocation->day_start_time;
                    $dayStartTime = $daystartTime . ":00:00";
                    $dayendTime = $daystartTime - 1;
                    $dayEndTime = $dayendTime . ":59:59";
                } else {
                    $dayStartTime = str_replace(' ', '', Config::get('constants.businessStartTimeDefault'));
                    $dayEndTime = str_replace(' ', '', Config::get('constants.businessEndTimeDefault'));
                }
                if (isset($dayStartTime) && !empty($businessLocation) && !empty($businessLocation->day_start_time) && !empty($current_time) && !empty($created_at)) {
                    $morning6TimeStamp = strtotime($created_at . $dayEndTime);
                    $dateTimeStamp = strtotime($created_at . " " . $current_time);
                    if ($dateTimeStamp >= $morning6TimeStamp) {
                        $today = $created_at . ' ' . $dayStartTime;
                        $tomorrow = date('Y-m-d', strtotime($created_at . ' +1 day')) . ' ' . $dayEndTime;
                    } else {
                        $today = date('Y-m-d', strtotime($created_at . ' -1 day')) . ' ' . $dayStartTime;
                        $tomorrow = $created_at . ' ' . $dayEndTime;
                    }
                } else {
                    $today = $created_at . Config::get('constants.businessStartTimeDefault');
                    $tomorrow = $created_at . Config::get('constants.businessEndTimeDefault');
                }
                $existingAttendance = Attendance::where('attendee_user_id', $attendee_user_id)
                    ->whereBetween('created_at', [$today, $tomorrow])
                    ->latest()
                    ->first();
            
                if ($existingAttendance) {
                    if (is_null($existingAttendance->clockout_time)) {
                        return response()->json(['status' =>'failed','errorMessage' => 'You have already clocked in but not clocked out yet.'], 200);
                    }
                }
                $sessionId = Attendance::where('attendee_user_id', $attendee_user_id)
                    ->whereBetween('created_at', [$today, $tomorrow])
                    ->count() + 1;
            
                $attendance = Attendance::create([
                    'attendee_user_id' => $request->input('attendee_user_id'),
                    'user_id' => $request->input('user_id'),
                    'is_on_break' => 0, 
                    'clockin_time' =>$request->input('clockin_time'),
                    'session_id' =>  $sessionId, 
                    'business_id' => $request->input('business_id'),
                    'location_id' => $request->input('location_id'),
                    'terminal_id' => $request->input('terminal_id'),
                    'clockin_date'=> $request->input('clockin_date'),
                    'last_activity_at'=> $request->input('last_activity_at')
                ]);
            
                return response()->json(['status' =>'success', 'message' => 'Clocked in successfully', 'attendance' => $attendance]);
            } else {
                return ["errorMessage" => 'Invalid token.'];
            }
        }else {
            return ["errorMessage" => 'Invalid token.'];
        }    
    
    
    }
    
    // Clock out method
    public function clockOut(Request $request)
    {
        if (isset($request['token'])) {
            $result = User::checkUserToken($request['token'], $request['user_id']);
    
            if ($result) {
                $input = $request->only('attendance_id', 'user_id', 'attendee_user_id', 'clockout_time', 'business_id', 'location_id', 'terminal_id', 'clockout_date','last_activity_at');
    
                $attendance = Attendance::where('attendee_user_id', $input['attendee_user_id']) 
                                        ->where('business_id', $input['business_id'])
                                        ->where('location_id', $input['location_id'])
                                        ->orderBy('updated_at', 'desc')
                                        ->first();
    
                if (!$attendance) {
                    return response()->json(['status' => 'failed', 'errorMessage' => 'Clock-in details not found']);
                }
    
                if ($attendance->is_on_break == 1) {
                    return response()->json(['status' => 'failed', 'errorMessage' => 'You are on break']);
                }
    
                $attendance->clockout_time = $input['clockout_time'];
                $attendance->user_id = $input['user_id'];
                $attendance->clockout_date = $input['clockout_date'];
    
                $previous_working_seconds =  $attendance->total_working_hours;
                       
                $last_break = Breaks::where('session_id', $attendance->id)
                                    ->whereNotNull('break_end_time')
                                    ->orderBy('break_end_time', 'desc')
                                    ->first();
    
                if ($last_break) {
                    $last_break_end_time = strtotime($last_break->break_end_time);
                    $clockout_time = strtotime($input['clockout_time']);
                    $working_hours_seconds = $clockout_time - $last_break_end_time;
                } else {
                    $clockin_time = strtotime($attendance->clockin_time);
                    $clockout_time = strtotime($input['clockout_time']);
                    $working_hours_seconds = $clockout_time - $clockin_time;
                }
    
                $total_working_seconds = $previous_working_seconds + $working_hours_seconds;
                // $total_working_hours = gmdate('H:i:s', $total_working_seconds);
     
                $attendance->total_working_hours = $total_working_seconds;
                $attendance->last_activity_at =$input['last_activity_at'];
                $attendance->save();
    
                return response()->json(['status' => 'success', 'message' => 'Clocked out successfully', 'attendance' => $attendance]);
    
            } else {
                return ["errorMessage" => 'Invalid token.'];
            }
        } else {
            return ["errorMessage" => 'Invalid token.'];
        }
    }
    
    // Start break method
    public function startBreak(Request $request)
    {
        try{
            $input = $request->only('attendance_id', 'user_id','attendee_user_id', 'break_start_time', 'business_id', 'location_id','terminal_id','token','last_activity_at');
            if (isset($input['token'])) {
                $result = User::checkUserToken($input['token'], $input['user_id']);
    
                if ($result) {
                    $attendance = Attendance::find($input['attendance_id']);
                    if($attendance){
                        $working_hours_seconds = 0;
                        $break_details = Breaks::where('session_id',$attendance->id)
                                                ->where('break_end_time', '=', null)
                                                ->first();
                        if($break_details)
                        {
                            return response()->json(['status' =>'failed', 'errorMessage' => 'You are already on break']);
                        }
    
                        $previous_break = Breaks::where('session_id', $attendance->id)
                                                ->whereNotNull('break_end_time')
                                                ->orderBy('break_end_time', 'desc')
                                                ->first();

                        if ($previous_break) {
                            $last_break_end_time = strtotime($previous_break->break_end_time);
                            $current_break_start_time = strtotime($request->input('break_start_time'));
                            $working_hours_seconds = $current_break_start_time > $last_break_end_time ? $current_break_start_time - $last_break_end_time : $last_break_end_time - $current_break_start_time;

                        } else {
                            // Calculate working hours from clockin time to first break start time
                            $clockin_time = strtotime($attendance->clockin_time);
                            $current_break_start_time = strtotime($request->input('break_start_time'));
                            $working_hours_seconds = $current_break_start_time - $clockin_time;


                        }
                        $previous_working_seconds = $attendance->total_working_hours ? $attendance->total_working_hours: 0;
                        $working_hours = $previous_working_seconds + $working_hours_seconds;
                        $attendance->total_working_hours = $working_hours;
                        // Create the new break record
                        $breaks = Breaks::create([
                            'user_id' => $attendance->attendee_user_id,
                            'break_start_time' =>$request->input('break_start_time'),
                            'session_id' =>  $attendance->id, 
                            'business_id' => $request->input('business_id'),
                            'location_id' => $request->input('location_id'),
                            'terminal_id' => $request->input('terminal_id'),
                        ]);
                        if($breaks)
                        {
                            $attendance->is_on_break =1;
                            $attendance->last_activity_at = $input['last_activity_at'];
                            $attendance->save();
                        }
    
                        return response()->json([
                            'status' => 'success',
                            'message' => 'Break started successfully',
                            'break' => $breaks,
                            'working_hours' => $working_hours
                        ]);
                    } else {
                        return response()->json(['status' => 'failed', 'errorMessage' => 'Clock-in details not found']);
                    }
                } else {
                    return response()->json(['errorMessage' => 'Invalid token.']);
                }
            } else {
                return response()->json(['errorMessage' => 'Invalid token.']);
            }
        } catch (\Exception $e) {
            \Log::emergency("File:" . $e->getFile() . " Line:" . $e->getLine() . " Message:" . $e->getMessage());
            $msg = trans("messages.something_went_wrong");
    
            return response()->json(['errorMessage' => $msg]);
        }
    }
    

    // End break method
    public function endBreak(Request $request)
    {
        $input = $request->only('attendance_id', 'user_id','attendee_user_id', 'break_end_time', 'business_id', 'location_id','terminal_id','token' ,'last_activity_at');
        try {
            if (isset($input['token'])) {
                $result = User::checkUserToken($input['token'], $input['user_id']);
    
                if ($result) {
                    $break= Breaks::where('session_id',$input['attendance_id'])
                                                ->where('break_end_time', '=', null)
                                                ->orderBy('updated_at', 'desc')
                                                ->first();
                    if (!$break) {
                        return response()->json(['status' => 'failed', 'errorMessage' => 'Break details not found.'], 200);
                    }
                    $break->break_end_time = $input['break_end_time'];
                    $attendance = Attendance::find($break->session_id);
                    if (!$attendance) {
                        return response()->json(['status' => 'failed', 'errorMessage' => 'Clock-in details not found.'], 200);
                    }
                    if (!$break->save()) {
                        return response()->json(['status' => 'failed', 'errorMessage' => 'Failed to update break end time.'], 200);
                    }
                    $attendance->is_on_break = 0;
                    $attendance->last_activity_at = $input['last_activity_at'];
                    if (!$attendance->save()) {
                        return response()->json(['status' => 'failed', 'errorMessage' => 'Failed to update attendance status.'], 200);
                    }

                    return response()->json(['status' => 'success', 'message' => 'Break ended successfully', 'break' => $break]);
                } else {
                    return ["errorMessage" => 'Invalid token.'];
                }
            }else {
                return ["errorMessage" => 'Invalid token.'];
            } 
        } catch (\Exception $e) {
            \Log::emergency("File:" . $e->getFile() . " Line:" . $e->getLine() . " Message:" . $e->getMessage());
            return response()->json(['status' => 'failed', 'errorMessage' => 'Something went wrong. Please try again later.'], 500);
        }

    }

    // Calculate working hours
    public function calculateWorkingHours($id)
    {
        $attendance = Attendance::find($id);
        $totalWorkingTime = Carbon::parse($attendance->clockin_time)->diffInSeconds($attendance->clockout_time);
        $breakDuration = Carbon::parse($attendance->break_start_time)->diffInSeconds($attendance->break_end_time);
        $netWorkingTime = $totalWorkingTime - $breakDuration;

        return response()->json([
            'total_working_time' => gmdate("H:i:s", $totalWorkingTime),
            'break_duration' => gmdate("H:i:s", $breakDuration),
            'net_working_time' => gmdate("H:i:s", $netWorkingTime)
        ]);
    }

    public function getWorkingHours(Request $request)
    {
        $attendee_user_id = $request->input('attendee_user_id');
        $location_id = $request->input('location_id');
        $current_time = Carbon::now()->format('H:i:s');
        $today = "";
        $tomorrow = "";

        // Get business location day start and end time
        $businessLocation = BusinessLocation::find($location_id);
        if (!empty($businessLocation) && !empty($businessLocation->day_start_time)) {
            $dayStartTime = $businessLocation->day_start_time . ":00:00";
            $dayEndTime = ($businessLocation->day_start_time - 1) . ":59:59";
        } else {
            $dayStartTime = str_replace(' ', '', Config::get('constants.businessStartTimeDefault')) . ":00:00";
            $dayEndTime = str_replace(' ', '', Config::get('constants.businessEndTimeDefault')) . ":59:59";
        }

        // Determine the today and tomorrow date ranges
        $morning6TimeStamp = strtotime($created_at . ' ' . $dayEndTime);
        $dateTimeStamp = strtotime($created_at . ' ' . $current_time);
        if ($dateTimeStamp >= $morning6TimeStamp) {
            $today = $created_at . ' ' . $dayStartTime;
            $tomorrow = date('Y-m-d', strtotime($created_at . ' +1 day')) . ' ' . $dayEndTime;
        } else {
            $today = date('Y-m-d', strtotime($created_at . ' -1 day')) . ' ' . $dayStartTime;
            $tomorrow = $created_at . ' ' . $dayEndTime;
        }

        $attendances = Attendance::where('attendee_user_id', $attendee_user_id)
            ->whereBetween('created_at', [$today, $tomorrow])
            ->get();

        $totalWorkingSeconds = 0;
        foreach ($attendances as $attendance) {
            $breaks = Breaks::where('session_id', $attendance->id)->get();
            $totalBreakSeconds = 0;

            foreach ($breaks as $break) {
                if ($break->break_end_time) {
                    $breakStartTime = Carbon::parse($attendance->created_at->format('Y-m-d') . ' ' . $break->break_start_time);
                    $breakEndTime = Carbon::parse($attendance->created_at->format('Y-m-d') . ' ' . $break->break_end_time);
                    $totalBreakSeconds += $breakEndTime->diffInSeconds($breakStartTime);
                }
            }

            if ($attendance->clockout_time) {
                $clockinTime = Carbon::parse($attendance->created_at->format('Y-m-d') . ' ' . $attendance->clockin_time);
                $clockoutTime = Carbon::parse($attendance->created_at->format('Y-m-d') . ' ' . $attendance->clockout_time);
                $workingSeconds = $clockoutTime->diffInSeconds($clockinTime) - $totalBreakSeconds;
                $totalWorkingSeconds += $workingSeconds;
            } else {
                $clockinTime = Carbon::parse($attendance->created_at->format('Y-m-d') . ' ' . $attendance->clockin_time);
                $currentTime = Carbon::now();
                $workingSeconds = $currentTime->diffInSeconds($clockinTime) - $totalBreakSeconds;
                $totalWorkingSeconds += $workingSeconds;
            }
        }

        // Convert total working seconds to H:i:s format
        $totalWorkingHours = gmdate('H:i:s', $totalWorkingSeconds);

        return response()->json([
            'status' => 'success',
            'total_working_hours' => $totalWorkingHours
        ]);
    }

    public function getTodaysWorkingHours($business_id, $location_id , $user_id, $start_date, $end_date)
    {
        $start_date = $start_date ? Carbon::parse($start_date)->startOfDay()->toDateTimeString() : null;
        $end_date = $end_date ? Carbon::parse($end_date)->endOfDay()->toDateTimeString() : null;
        $attendances = Attendance::where('attendances.business_id', $business_id)
                                    ->when($location_id, function ($query) use ($location_id) {
                                        return $query->where('attendances.location_id', $location_id);
                                    })
                                    ->when($user_id, function ($query) use ($user_id) {
                                        return $query->where('attendances.attendee_user_id', $user_id);
                                    })
                                    ->when($start_date && $end_date, function ($query) use ($start_date, $end_date) {
                                        return $query->whereBetween('attendances.created_at', [$start_date, $end_date]);
                                    })
                                    ->select([
                                        'attendances.id',
                                        'attendances.attendee_user_id',
                                        'attendances.clockin_time',
                                        'attendances.clockout_time',
                                        'users.first_name',
                                        'users.last_name',
                                        DB::raw('DATE(attendances.created_at) as attendance_date'),
                                    ])
                                    ->join('users', 'attendances.attendee_user_id', '=', 'users.id')
                                    ->get();
    
            // Fetch breaks data as before
            $breaks = Breaks::where('breaks.business_id', $business_id)
                            ->when($location_id, function ($query) use ($location_id) {
                                return $query->where('breaks.location_id', $location_id);
                            })
                            ->when($user_id, function ($query) use ($user_id) {
                                return $query->where('breaks.user_id', $user_id);
                            })
                            ->when($start_date && $end_date, function ($query) use ($start_date, $end_date) {
                                return $query->whereBetween(DB::raw('DATE(breaks.created_at)'), [$start_date, $end_date]);
                            })
                            ->select([
                                'breaks.user_id',
                                DB::raw('DATE(breaks.created_at) as break_date'),
                                DB::raw('SUM(TIME_TO_SEC(TIMEDIFF(breaks.break_end_time, breaks.break_start_time)) / 3600) as total_break_hours')
                            ])
                            ->groupBy('breaks.user_id', 'break_date')
                            ->get();
            $processedData = [];
            foreach ($attendances as $attendance) {
                $date = $attendance->attendance_date;
                $session_id = $attendance->id;
                $attendee_user_id = $attendance->attendee_user_id;

                if ($attendance->clockout_time != null) {
                        $clockin = strtotime($attendance->clockin_time);
                        $clockout = strtotime($attendance->clockout_time);
                        $working_hours_seconds = $clockout - $clockin; // in seconds
                }
                else{
                    $working_hours_seconds = 0;
                }
                $attendance_breaks_seconds = Breaks::where('user_id', $attendee_user_id)
                    ->where('session_id', $session_id)
                    ->whereDate('created_at', $date)
                    ->sum(DB::raw('TIME_TO_SEC(TIMEDIFF(break_end_time, break_start_time))'));
                // Calculate the actual working hours in seconds
                $actual_working_hours_seconds = $working_hours_seconds ? $working_hours_seconds - $attendance_breaks_seconds : 0;                        
                $key = $attendee_user_id . '-' . $date;
                if (!isset($processedData[$key])) {
                    $processedData[$key] = (object)[
                        'id' => $attendance->id,
                        'attendee_user_id' => $attendance->attendee_user_id,
                        'first_name' => $attendance->first_name,
                        'last_name' => $attendance->last_name,
                        'date' => $date,
                        'first_clockin_time' => $attendance->clockin_time,
                        'last_clockout_time' => $attendance->clockout_time,
                        'total_working_hours_seconds' => $actual_working_hours_seconds,
                        'total_break_time_seconds' => $attendance_breaks_seconds,
                    ];

                } elseif( $processedData[$key]->attendee_user_id == $attendance->attendee_user_id &&  $processedData[$key]->date == $date) {
                    $processedData[$key]->last_clockout_time =  $attendance->clockout_time == null ? $processedData[$key]->last_clockout_time : $attendance->clockout_time;
                    $processedData[$key]->total_working_hours_seconds += $actual_working_hours_seconds;
                    $processedData[$key]->total_break_time_seconds += $attendance_breaks_seconds;
                }
            }
            $formattedData = [];
            foreach ($processedData as $data) {
                $obj->total_working_hours = $data->total_working_hours_seconds;
                $obj->total_break_time = gmdate('H:i:s', $data->total_break_time_seconds);
                $obj->date = $data->date;
                $formattedData = $obj;
            }
            return $formattedData->total_working_hours;
    }
    private function calculateTotalBreakSeconds($sessionId)
    {
        $breaks = Breaks::where('session_id', $sessionId)->get();
        $totalBreakSeconds = 0;

        foreach ($breaks as $break) {
            if ($break->break_end_time) {
                $breakStartTime = Carbon::parse($break->created_at->format('Y-m-d') . ' ' . $break->break_start_time);
                $breakEndTime = Carbon::parse($break->created_at->format('Y-m-d') . ' ' . $break->break_end_time);
                $totalBreakSeconds += $breakEndTime->diffInSeconds($breakStartTime);
            }
        }

        return $totalBreakSeconds;
    }
    private function total_working_hours($attendee_user_id, $business_id, $location_id, $start_date, $end_date)
    {             
                $start_date = $start_date ? Carbon::parse($start_date)->startOfDay()->toDateTimeString() : null;
                $end_date = $end_date ? Carbon::parse($end_date)->endOfDay()->toDateTimeString() : null;
                $attendances = Attendance::where('attendances.business_id', $business_id)
                    ->when($location_id, function ($query) use ($location_id) {
                        return $query->where('attendances.location_id', $location_id);
                    })
                    ->when($attendee_user_id, function ($query) use ($attendee_user_id) {
                        return $query->where('attendances.attendee_user_id', $attendee_user_id);
                    })
                    ->when($start_date && $end_date, function ($query) use ($start_date, $end_date) {
                        return $query->whereBetween('attendances.created_at', [$start_date, $end_date]);
                    })
                    ->select([
                        'attendances.id',
                        'attendances.attendee_user_id',
                        'attendances.clockin_time',
                        'attendances.clockout_time',
                        'users.first_name',
                        'users.last_name',
                        'total_working_hours',
                        DB::raw('DATE(attendances.created_at) as attendance_date'),
                    ])
                    ->join('users', 'attendances.attendee_user_id', '=', 'users.id')
                    ->get();
                $total_working_hours_in_seconds = 0;
                foreach ($attendances as $attendance) {
                    $total_working_hours_in_seconds += $attendance->total_working_hours ? $attendance->total_working_hours : 0;
                }


        return $total_working_hours_in_seconds;
    }
       public function details(Request $request){
        try {
            $input =  $request->only('business_id', 'location_id', 'terminal_id', 'attendee_user_id','date');
            $start_date = $input['date'] ? Carbon::parse($input['date'])->startOfDay()->toDateTimeString() : null;
            $end_date = $input['date'] ? Carbon::parse($input['date'])->endOfDay()->toDateTimeString() : null;
          
            $attendance_details = Attendance::where('attendee_user_id', $input['attendee_user_id'])
                        ->where('business_id', $input['business_id'])
                        ->whereNull('clockout_time')
                        ->where(function ($query) use ($start_date, $end_date) {
                            $query->where('created_at', '<', $start_date)
                                  ->orWhere('created_at', '>', $end_date);
                        })
                        ->orderBy('created_at', 'DESC')
                        ->first();
          
            $attendance = Attendance::where('attendee_user_id', $input['attendee_user_id'])
                                    ->where('business_id',$input['business_id'])
                                    ->whereBetween('attendances.created_at', [$start_date, $end_date])
                                    ->orderBy('created_at', 'DESC')->first();
            if($attendance_details){
                $attendance = $attendance_details;
                $input['date'] = $attendance_details->created_at;
            }                        
            if($attendance){
                $total_working_hours_in_seconds = $this->total_working_hours($input['attendee_user_id'], $input['business_id'], $input['location_id'],  $input['date'], $input['date']);
                $total_working_hours = gmdate('H:i:s', $total_working_hours_in_seconds);
                $attendance->total_working_hours = $total_working_hours;
                return response()->json(['status' => 'success', 'attendance_details' => $attendance]);
            }     
            else{
                return response()->json(['status' => 'success', 'attendance_details' =>$attendance ??  (object) []]);  
            }                   
        } catch (\Exception $e) {
            \Log::emergency("File:" . $e->getFile() . "Line:" . $e->getLine() . "Message:" . $e->getMessage());
            $msg = __('messages.something_went_wrong');
            return response()->json(['status' => 'success', 'errorMessage' => $msg]);
        }
    }

    function calculateTotalBreakTime($attendee_user_id, $business_id, $location_id, $start_date, $end_date) {
        $start_date = $start_date ? Carbon::parse($start_date)->startOfDay()->toDateTimeString() : null;
        $end_date = $end_date ? Carbon::parse($end_date)->endOfDay()->toDateTimeString() : null;

        $attendances = Attendance::where('attendances.business_id', $business_id)
            ->when($location_id, function ($query) use ($location_id) {
                return $query->where('attendances.location_id', $location_id);
            })
            ->when($attendee_user_id, function ($query) use ($attendee_user_id) {
                return $query->where('attendances.attendee_user_id', $attendee_user_id);
            })
            ->when($start_date && $end_date, function ($query) use ($start_date, $end_date) {
                return $query->whereBetween('attendances.created_at', [$start_date, $end_date]);
            })
            ->whereNull('clockout_time')
            ->select([
                'attendances.id',
                'attendances.attendee_user_id',
                'attendances.clockin_time',
                'attendances.clockout_time',
                'users.first_name',
                'users.last_name',
                DB::raw('DATE(attendances.created_at) as attendance_date'),
            ])
            ->join('users', 'attendances.attendee_user_id', '=', 'users.id')
            ->get();

        $totalBreakTimeSeconds = 0;
        $break_end_time = "";

        foreach ($attendances as $attendance) {
            $breaks = Breaks::where('session_id', $attendance->id)
                ->where('user_id', $attendee_user_id)
                ->get();

            foreach ($breaks as $break) {
                if ($attendance->clockin_time && $break->break_start_time) {
                    $clockinTime = strtotime($attendance->clockin_time);
                    $breakStartTime = strtotime($break->break_start_time);
                    $totalBreakTimeSeconds = ($breakStartTime - $clockinTime);
                    $break_end_date = $break->break_end_time;
                }
            }
        }

        return (Object)['totalBreakTimeSeconds' => $totalBreakTimeSeconds , 'break_end_date' => $break_end_date];
    }

}
