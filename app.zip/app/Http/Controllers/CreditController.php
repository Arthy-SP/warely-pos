<?php

namespace App\Http\Controllers;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\DB;
use App\Services\TwilioOTPService;
use App\Utils\TransactionUtil;
use Illuminate\Http\Request;
use App\CreditTransaction;
use App\BusinessLocation;
use App\CreditPromos;
use Carbon\Carbon;
use Datatables;
use App\Credit;
use App\User;

class CreditController extends Controller
{
    protected $transactionUtil;
    protected $twilioService;

    public function __construct(
        TransactionUtil $transactionUtil,
        TwilioOTPService $twilioService
    ) {
        $this->transactionUtil = $transactionUtil;
        $this->twilioService = $twilioService;
    }

    public function index()
    {

        if (!auth()->user()->can('access_tables')) {
            abort(403, 'Unauthorized action.');
        }

        $business_id = request()->session()->get('user.business_id');
        $wallet_data = Credit::where('business_id', $business_id)->get();

        if (request()->ajax()) {
            $nfc_card_numbers = NfcCardNumbers::where('nfc_card_numbers.business_id', $business_id)
                                    ->select(['nfc_card_numbers.display_number', 'nfc_card_numbers.id', 'nfc_card_numbers.prefix', 'nfc_card_numbers.start_from']);
            
            return Datatables::of($nfc_card_numbers)
               ->addColumn(
                   'action',
                   '@role("Admin#' . $business_id . '")
                   <button data-href="{{action(\'NfcCardController@edit\', [$id])}}" class="btn btn-xs btn-primary edit_nfc_card_button"><i class="glyphicon glyphicon-edit"></i> @lang("messages.edit")</button>
                       &nbsp;
                   @endrole'
               )
               ->removeColumn('id')
               ->make(true);
       }

       return view('nfc_card_numbers.index')->with(compact('nfcCardNumbers'));
    }


    public function list()
    {
        if (!auth()->user()->can('access_tables')) {
            abort(403, 'Unauthorized action.');
        }
        if (request()->ajax()) {
            $business_id = request()->session()->get('user.business_id');
            
            $creditWalletData = Credit::leftJoin('contacts', function($join) {
                $join->on('credits.contact_id', '=', 'contacts.id')
                     ->on('credits.business_id', '=', 'contacts.business_id');
            })
            ->leftJoin('user_contact_access', 'contacts.id', '=', 'user_contact_access.contact_id')
            ->leftJoin('users', 'user_contact_access.user_id', '=', 'users.id')
            ->select([
                'credits.phone_number', 
                'credits.balance', 
                'credits.contact_id', 
                'credits.status', 
                'credits.business_id', 
                'credits.id', 
                'credits.location_id', 
                'credits.remark',
                'credits.created_at', 
                DB::raw('CONCAT(users.first_name, " ", users.last_name) as name'),
            ])->where('credits.business_id', $business_id)
            ->orderBy('credits.created_at', 'desc')
            ->get();
                
            return Datatables::of($creditWalletData)
                ->addColumn(
                    'balance',
                    '<div style="white-space: nowrap;">@format_currency($balance)</div>'
                )
                ->addColumn('status', function ($creditWalletData) use ($business_id) {
                    return ucfirst($creditWalletData->status);
                })
                ->addColumn('action', function ($creditWalletData) use ($business_id) {
                    $activateButton = '<button data-href="' . action('CreditController@activateCredit', [$creditWalletData->id]) . '" class="btn btn-xs btn-success activate_credit_button"><i class="glyphicon glyphicon-ok"></i> Activate</button>  <br>';
                    $deactivateButton = '<button data-href="' . action('CreditController@deactivateCredit', [$creditWalletData->id]) . '" class="btn btn-xs btn-danger deactivate_credit_button"><i class="glyphicon glyphicon-remove"></i> Deactivate</button> <br>';
                    
                    // Show the appropriate button based on the status
                    $buttonToShow = ($creditWalletData->status == 'active') ? $deactivateButton : $activateButton;
                    
                    // Return the buttons along with the Transactions button
                    $transactionsButton = '';
                    $editForm = '';
                    if (auth()->user()->can("Admin#" . $business_id)) {
                        $transactionsButton = '<a href="' . action('CreditController@credit_transactions', [$creditWalletData->id]) . '" class="btn btn-xs btn-primary " style= " width: 100px; height: 20px; margin-right: 5px"><i class="fa fas fa-list-alt"></i> Transactions</a> <br>';
                        if (config('app.env') == 'local' || config('app.env') == 'dev'){
                            $editForm =  '<button data-href="' . action('CreditController@editCreditDetails', [$creditWalletData->id]) . '"class="btn btn-xs btn-primary credit_edit_details_form "  data-container=".check_numbers_modal"><i class="glyphicon glyphicon-edit" style="margin-right: 0px;"></i> Edit</button>';
                        }
                    }
    
                    return $transactionsButton . $buttonToShow . $editForm;
                })
                ->rawColumns(['action','name', 'phone_number', 'status', 'balance', 'contact_id','business_id','location_id','remark'])
                ->removeColumn('id')
                ->make(true);
        }
        return view('credit.list');
    }
    public function editCreditDetails($id){
        if (!auth()->user()->can('access_tables')) {
            abort(403, 'Unauthorized action.');
        }
            if (request()->ajax()) {
            $creditData = Credit::where('id', $id)
            ->first();
            return view('credit.edit')->with(compact('creditData', 'id'));        
        }
    }
    public function updateCreditDetail(Request $request, $id){
        {
            if (!auth()->user()->can('access_tables')) {
                 abort(403, 'Unauthorized action.');
            }
            $credit_data = $request->only('balance');
             if (request()->ajax()) {
                try {
                    $creditData = Credit::where('id', $id)->first();
                    if($creditData->status == 'inactive'){
                        return  ['success' => false,
                                'message' => __("The Credit is Inactive Please activate first to update")
                            ];
                    }
                    $creditData->balance = $credit_data['balance'];
                    $creditData->save();
                    $output = ['success' => true,
                                'message' => __("lang_v1.updated_success")
                                ];
                } catch (\Exception $e) {
                    \Log::emergency("File:" . $e->getFile(). "Line:" . $e->getLine(). "Message:" . $e->getMessage());
                
                    $output = ['success' => false,
                                'message' => __("messages.something_went_wrong")
                            ];
                }
             return $output;
            }
        }
    }
    public function credit_transactions(Request $request, $id)   {
        if (!auth()->user()->can('access_tables')) {
            abort(403, 'Unauthorized action.');
        }
        $business_id = request()->session()->get('user.business_id');
        $credit_data = Credit::where('credits.business_id', $business_id)
                        ->where('credits.id', $id)
                        ->select(['credits.phone_number', 'credits.status', 'credits.balance', 
                        'credits.contact_id', 'credits.id'])
                        ->first();
        if( $credit_data ) {
            if (request()->ajax()) {
                $creditTransactions = CreditTransaction::where('credit_transactions.business_id', $business_id)
                                    ->where('credit_transactions.credit_id', $credit_data->id)
                                    ->select([DB::raw("CASE credit_transactions.transaction_type WHEN 'debit' THEN 'DEBIT' ELSE 'CREDIT' END AS transaction_type"),DB::raw("UPPER(credit_transactions.payment_type) AS payment_type"), 'credit_transactions.amount', 'credit_transactions.remark', 'credit_transactions.credit_id', 'credit_transactions.created_at', 'credit_transactions.id', 'credit_transactions.is_void', 'credit_transactions.void_reason'])
                                    ->orderBy("id", 'desc');   

                $start_date = $request->input('start_date');
                $end_date = $request->input('end_date');
    
                if (!empty($start_date) && !empty($end_date)) {
                    $start_date = date('Y-m-d 00:00:00', strtotime($start_date));
                    $end_date = date('Y-m-d 23:59:59', strtotime($end_date));

                    $creditTransactions->whereBetween('credit_transactions.created_at', [$start_date, $end_date]);
                }

                $transaction_type = request()->get('transaction_type', null);
                if (!empty($transaction_type)) {
                    $creditTransactions->where('credit_transactions.transaction_type', $transaction_type);
                }

                return Datatables::of($creditTransactions, $business_id)
                ->addColumn('action', function ($creditTransactions){
                    $voidButton='';
                    if (str_contains(strtolower($creditTransactions->remark), "top-up done") && $creditTransactions->is_void != 1) {
                        $voidButton = '<button data-href="' . action('CreditController@getReason', [$creditTransactions->id]) . '" class="btn btn-xs btn-danger btn-modal" data-container=".check_numbers_modal" style="color: white; width: 50px; height: 20px;"><i class="glyphicon glyphicon"></i>Void</button>';
                    }
                     else if(str_contains(strtolower($creditTransactions->remark), "top-up done") && $creditTransactions->is_void == 1) {
                        $voidButton = '<button data-href="" class="btn btn-xs" disabled style="color: black; background-color: gray;"><i class="glyphicon glyphicon"></i>Voided</button>';
                    }
                    else{   
                        $voidButton = '';
                    }
                    
                    return $voidButton;
                })
                ->addColumn(
                    'amount',
                    '<div style="white-space: nowrap;">@format_currency($amount)</div>'
                ) 
                ->removeColumn('id')
                ->rawColumns(['action', 'transaction_type', 'payment_type', 'amount', 'remark', 'credit_id', 'created_at', 'void_reason'])
                ->make(true);
            }
            return view('credit.transaction')->with(compact('credit_data'));
        } else {
            return redirect()->route('credit/list');
        }
    }
    public function createCredit(Request $request){
        try {
            $request->validate([
                'phone_number' => 'required|string',
                'contact_id' => 'nullable|string',
                'balance' => 'required|numeric',
                'status' => 'nullable|string',
                'business_id' => 'required|exists:business,id',
                'location_id' => 'nullable|string'
            ]);

            $existingCreditWallet = Credit::where('phone_number', $request->input('phone_number'))
                                    ->where('business_id', $request->input('business_id'))
                                    ->first();
            if ($existingCreditWallet) {
                return response()->json([
                    'message' => 'Credit with the provided phone number is already exists.'
                ], 200);
            }
            DB::beginTransaction();
            $creditWalledData = Credit::create([
                    'phone_number' => $request->input('phone_number'),
                    'contact_id' => $request->input('contact_id'),
                    'status' => $request->input('status'), 
                    'balance' => $request->input('balance')?$request->input('balance'):0.0,
                    'business_id' => $request->input('business_id'),
                    'location_id' => $request->input('location_id')
                ]);
            
            // Commit the transaction
            DB::commit();
            return response()->json(['data' => $creditWalledData], 200);
        } catch (\Illuminate\Database\QueryException $e) {
            DB::rollback();
            if ($e->errorInfo[1] == 1062) {
                return response()->json(['errorMessage' => 'Credit with the provided phone number already exists.'], 200);
            }
            return response()->json(['errorMessage' => 'Database errorMessage.'], 500);
        } catch (\Exception $e) {
            return response()->json(['errorMessage' => $e->getMessage()], 500);
        }
    }
    public function activateCredit($id)
    {
        if (!auth()->user()->can('invoice_settings.access')) {
            abort(403, 'Unauthorized action.');
        }
        if (request()->ajax()) {
            try {
                $creditWalletData = Credit::find($id);
                if ($creditWalletData) {
                    $currentDate = date('Y-m-d');
                    $currentTime = date('H:i:s');

                    $creditWalletData->update(['status' => 'active', 'remark' => "Credit is reactivated on $currentDate at $currentTime"]);
                    $output = [
                        'success' => true,
                        'message' => __("Credit activate successfully"),
                    ];
                } else {
                    $output = [
                        'success' => false,
                        'message' => __("Credit not found"),
                    ];
                }
            } catch (\Exception $e) {
                \Log::emergency("File:" . $e->getFile() . "Line:" . $e->getLine() . "Message:" . $e->getMessage());
                $output = [
                    'success' => false,
                    'message' => __("messages.something_went_wrong"),
                ];
            }
    
            return $output;
        }
    }
    public function deactivateCredit($id)
    {
        if (!auth()->user()->can('invoice_settings.access')) {
            abort(403, 'Unauthorized action.');
        }
        if (request()->ajax()) {
            try {
                $creditWalletData = Credit::find($id);
    
                if ($creditWalletData) {
                    $currentDate = date('Y-m-d');
                    $currentTime = date('H:i:s');

                    $creditWalletData->update(['status' => 'inactive', 'remark' => "Credit is deactivated on $currentDate at $currentTime"]);
                    $output = [
                        'success' => true,
                        'message' => __("Credit inactivate successfully"),
                    ];
                } else {
                    $output = [
                        'success' => false,
                        'message' => __("Credit not found"),
                    ];
                }
            } catch (\Exception $e) {
                \Log::emergency("File:" . $e->getFile() . "Line:" . $e->getLine() . "Message:" . $e->getMessage());
    
                $output = [
                    'success' => false,
                    'message' => __("messages.something_went_wrong"),
                ];
            }
    
            return $output;
        }
    }
    public function rechargeCreditWallet(Request $request)
    {
        try {
            $request->validate([
                'credit_id' => 'required|int',
                'payment_type' => 'required|string',
                'business_id' => 'required|exists:business,id',
                'token' => 'required|string',
                'user_id' => 'required|exists:users,id',
                'remark' => 'nullable|string',
                'location_id' => 'nullable|string',
                'transaction_id' => 'nullable|int',
                'amount' => 'required|numeric',

            ]);

            if (!User::checkUserToken($request->input('token'), $request->input('user_id'))) {
                return response()->json(['errorMessage' => 'Invalid token.'], 200);
            }
            $creditData = Credit::where('id', $request->input('credit_id'))
                                ->where('business_id', $request->input('business_id'))
                                ->where('status', 'active')
                                ->first();

            if (!$creditData) {
                return response()->json(['errorMessage' => 'Credit history not found.'], 200);
            }
            $txn_amount = 0;
            $available_balance = 0;
            $remark = "";
            $topup_amount = 0;
            $promo_amount = 0;
            $previous_amount = 0;
            $newBalance=0;
            if($request->input('amount')) {
               
                $isPromoApplied = false;
                $creditPromo = CreditPromos::where('business_id', $request->input('business_id'))
                            ->where('amount', $request->input('amount'))
                            ->where(function ($query) {
                                $query->where('expiry_date', '>=', now()->format('Y-m-d'))
                                    ->orWhereNull('expiry_date');
                            })
                            ->where('status', 'active')
                            ->whereNull('deleted_at')
                            ->first();
                if($creditPromo ) {
                    $isPromoApplied = true;
                    $newBalance = $creditData->balance + $creditPromo->credit_amount;
                    $txn_amount = $creditPromo->credit_amount;
                    $previous_amount = $creditData->balance;
                    $topup_amount = $creditPromo->amount;
                    $promo_amount = $creditPromo->promo_amount;
                    $available_balance = $newBalance;
                    $topup_amount = $request->input('amount');
                    $remark = 'Top-up Done (Promo ' . $creditPromo->promo_amount . ' applied)';
                }
                else{
                    $newBalance = $creditData->balance + $request->input('amount');
                    $txn_amount = $request->input('amount');
                    $previous_amount = $creditData->balance;
                    $available_balance = $newBalance;
                    $remark = 'Top-up Done';
                }

                $creditData->update(['balance' => $newBalance]);
                $transaction = [
                    'transaction_type' => 'credit', 
                    'payment_type' => $request->input('payment_type'),
                    'amount' => $txn_amount,
                    'remark' => $remark,
                    'business_id' => $request->input('business_id'),
                    'credit_id' => $creditData->id,
                    'transaction_id' => !empty($request->input('transaction_id')) ? $request->input('transaction_id') : null,
                    'location_id' => $request->input('location_id'),
                    'credit_promo_id' =>($isPromoApplied) ? (isset($creditPromo) && $creditPromo && $creditPromo->id ? $creditPromo->id : null) : null,
                    'balance_credit' => $newBalance
                    ];

                    CreditTransaction::create($transaction);
            }

            return response()->json([
                'message' => 'Credit recharged successfully.', 
                'previous_amount' => number_format($previous_amount, 2),
                'topup_amount' => number_format($txn_amount, 2),
                'available_balance' => number_format($available_balance, 2),
                'credit_details' => $creditData 
            ], 200);
        } catch (QueryException $e) {
            return response()->json(['errorMessage' => 'Database errorMessage.'], 200);
        } catch (\Exception $e) {
            return response()->json(['errorMessage' => $e->getMessage()], 200);
        }
    }

    public function get_credit_details(Request $request){
        $request->validate([
            'business_id' => 'required|exists:business,id',
            'location_id' => 'nullable|string',
            'credit_id'=> 'required|int',

        ]);
        try{
            $creditData = Credit::where('id', $request->input('credit_id'))
                            ->where('business_id', $request->input('business_id'))
                            ->first();
            if(empty($creditData)){
                return response()->json(['errorMessage' => 'Credit details not found'], 200);
            }
            return response()->json($creditData, 200);
        } catch (QueryException $e) {
                return response()->json(['errorMessage' => 'Database Error.'], 200);
        } catch (\Exception $e) {
                return response()->json(['errorMessage' => $e->getMessage()], 200);
        }

    }

    public function getReason($id){
        $voidReasons = [
            'Incorrect Amount' => 'Incorrect Amount',
            'Duplicate Transaction' => 'Duplicate Transaction',
            'Customer Cancelled' => 'Customer Cancelled',
            'Technical Issue' => 'Technical Issue',
            'Other'   => 'Other',
        ];
        
        return view('credit.voidtransaction')->with(compact('voidReasons', 'id'));        
    }


    public function void_transaction(Request $request, $id){
        if (request()->ajax()) {
            try {
                $reason = $request->input('custom_reason') == null ? $request->input('reason') : $request->input('custom_reason');
                $transactionData = CreditTransaction::join('credits', 'credit_transactions.credit_id', '=', 'credits.id')
                    ->where('credit_transactions.id', $id)
                    ->select('credit_transactions.*', 'credits.balance')
                    ->first();
        
                if ($transactionData) {
                    if ($transactionData->balance < $transactionData->amount) {
                        $output = [
                            'success' => false,
                            'message' => "Insufficient balance",
                        ];
                        return $output;
                    }
                    
                    $balance = $transactionData->balance - $transactionData->amount;
                    Credit::where('id', $transactionData->credit_id)->update(['balance' => $balance]);
        
                    CreditTransaction::where('id', $id)->update(['is_void' => 1, 'void_reason'=>  $reason]);
        
                    $output = [
                        'success' => true,
                        'message' => "Transaction voided",
                    ];
                } else {
                    $output = [
                        'success' => false,
                        'message' => "Transaction not found",
                    ];
                }
            } catch (\Exception $e) {
                \Log::emergency("File:" . $e->getFile() . "Line:" . $e->getLine() . "Message:" . $e->getMessage());
                $output = [
                    'success' => false,
                    'message' => __("messages.something_went_wrong"),
                ];
            }

            return $output;
        }
    }
    public function get_credit_transactions(Request $request){
        $request->validate([
            'business_id' => 'required|exists:business,id',
            'location_id' => 'nullable|string',
            'credit_id'=> 'required|int',
        ]);
        try{
            $creditData = Credit::where('id', $request->input('credit_id'))
                                ->where('business_id', $request->input('business_id'))
                                ->first();
            if(empty($creditData)){
                 return response()->json(['errorMessage' => 'Credit details not found'], 200);
            }
            if($creditData->status == 'inactive'){
                 return response()->json(['errorMessage' => 'Credit is deactivated'], 200); 
            }
            $credit_transactions = CreditTransaction::select(
                'credit_transactions.*',
                DB::raw('IFNULL((SELECT `invoice_no` FROM `transactions` WHERE `id` = `credit_transactions`.`transaction_id` AND `business_id` = ? ), NULL) as order_no'),
                DB::raw('IFNULL((SELECT `final_total` FROM `transactions` WHERE `id` = `credit_transactions`.`transaction_id` AND `business_id` = ?), NULL) as bill_amount'),
                DB::raw('IFNULL(credit_promos.promo_amount, 0) as promo_amount'),
                DB::raw('CAST(IFNULL(credit_transactions.amount, 0) - IFNULL(credit_promos.promo_amount, 0) as DECIMAL(10,2)) as topup_amount'),
            )
            ->setBindings([$request->input('business_id'),  $request->input('business_id')])
            ->where('credit_id', $creditData->id)
            ->leftJoin('credit_promos', 'credit_transactions.credit_promo_id', '=', 'credit_promos.id')
            ->orderBy('created_at', 'desc') 
            ->get();
            $credit_transactions->transform(function ($credit_transactions) {
                $credit_transactions->is_void = (bool) $credit_transactions->is_void;
                return $credit_transactions;
            });
                
           return response()->json(["transactions" => $credit_transactions,"total_credit" =>$creditData->balance], 200);
        } catch (QueryException $e) {
                return response()->json(['errorMessage' => 'Database Error.'], 200);
        } catch (\Exception $e) {
                return response()->json(['errorMessage' => $e->getMessage()], 200);
        }

    }    

    public function sendOtp (Request $request){
        $request->validate([
            'phone' => 'required|string',
            'business_id' => 'required|exists:business,id',
            'location_id' => 'required|string',
        ]);
        try{
            $allowedNumbers = ["+6599999999"]; 
            $result= false;
            $creditData = Credit::where('phone_number', $request->input('phone'))
                                ->where('business_id', $request->input('business_id'))
                                ->first();
            if(empty($creditData)){
                 return response()->json(['errorMessage' => 'There is no credit associated with provided number', "success"=>false], 200);
            }
            if (in_array($request->input('phone'), $allowedNumbers)) {
              $result = true;
            }
            else{
                $result = $this->twilioService->sendOTPWithTwilio($request->input('phone'));
             }
            if($result){
                return response()->json(['message' => 'Otp sent successfully', "success"=>true], 200);
            }
            else{
                return response()->json(['errorMessage' => 'something went wrong', "success"=>false], 200);
            }
    
        } catch (QueryException $e) {
                return response()->json(['errorMessage' => 'Database Error.'], 200);
        } catch (\Exception $e) {
                return response()->json(['errorMessage' => $e->getMessage()], 200);
        }
    }

    public function verifyOtp(Request $request){
        $request->validate([
            'phone' => 'required|string',
            'business_id' => 'required|exists:business,id',
            'location_id' => 'required|string',
            'otp'=>'required'
        ]);
        try{
            $allowedNumbers = ["+6599999999"]; 
            $result = [];
            if (in_array($request->input('phone'), $allowedNumbers)) {
                if($request->input('otp') == '123456')
                {
                    $result['success'] = true;
                }
                 else{
                    return response()->json(['errorMessage' => "Invalid Otp", "success"=>false], 200);
                }
             }   
             else{
                 $result = $this->twilioService->verifyOTPWithTwilio($request->input('phone'), $request->input('otp'));
             }
            if($result['success']){
                
                $creditData = Credit::where('phone_number', $request->input('phone'))
                                    ->where('business_id', $request->input('business_id'))
                                    ->first();
                    return response()->json($creditData, 200);
            }
            else{
                return response()->json(['errorMessage' => $result['message'], "success"=>false], 200);
            }
        } catch (QueryException $e) {
                return response()->json(['errorMessage' => 'Database Error.', "success"=>false], 200);
        } catch (\Exception $e) {
                return response()->json(['errorMessage' => $e->getMessage(), "success"=>false], 200);
        }

    }

    public function voidTopupTransaction(Request $request){        
        $request->validate([
            'token' => 'required|string',
            'user_id' => 'required|string',
            'transaction_id' => 'required',
            'reason' => 'required|string'
        ]);
        $user_data = $request->only('transaction_id', 'token', 'user_id','reason');
        if (isset($user_data['token'])) {
            $result = User::checkUserToken($user_data['token'], $user_data['user_id']);
            if ($result) {
                try {
                    $transactionData = CreditTransaction::join('credits', 'credit_transactions.credit_id', '=', 'credits.id')
                        ->where('credit_transactions.id', $user_data['transaction_id'])
                        ->select('credit_transactions.*', 'credits.balance')
                        ->first();
                    if ($transactionData) {
                        if($transactionData->balance<$transactionData->amount){ 
                            return response()->json(['errorMessage' => 'Insufficient balance to void the transaction.'], 200);
                        }
                        $balance = $transactionData->balance - $transactionData->amount;
                        Credit::where('id', $transactionData->credit_id)->update(['balance' => $balance]);
    
                        CreditTransaction::where('id', $user_data['transaction_id'])->update(['is_void' => 1,'void_reason'=>$user_data['reason']]);
                        return response()->json(['message' => 'Transaction voided successfully.'], 200);
                    } else {
                        return response()->json(['errorMessage' => 'Transaction not found.'], 200);
                    }
                } catch (\Exception $e) {
                    \Log::emergency("File:" . $e->getFile() . "Line:" . $e->getLine() . "Message:" . $e->getMessage());
                    $msg = trans("messages.something_went_wrong");
                    return response()->json(['errorMessage' => 'Something went wrong.'], 500);
                }
            } else {
                return response()->json(['errorMessage' => 'Invalid token..'], 200);
            }
        } else {
            return response()->json(['errorMessage' => 'Invalid token..'], 200);
        }
    }

    
    public function get_all_credit_transactions(Request $request) {
        if (!auth()->user()->can('access_tables')) {
            abort(403, 'Unauthorized action.');
        }
    
        $business_id = request()->session()->get('user.business_id');
    
        if (request()->ajax()) {
            $query = CreditTransaction::leftJoin('credits', 'credit_transactions.credit_id', '=', 'credits.id')
                ->leftJoin('contacts', function($join) use ($business_id) {
                    $join->on('credits.contact_id', '=', 'contacts.id')
                        ->where('contacts.business_id', '=', $business_id);
                })
                ->leftJoin('user_contact_access', 'contacts.id', '=', 'user_contact_access.contact_id')
                ->leftJoin('users', function($join) use ($business_id) {
                    $join->on('user_contact_access.user_id', '=', 'users.id')
                        ->where('users.business_id', '=', $business_id);
                })
                ->where('credit_transactions.business_id', $business_id)
                ->select([
                    DB::raw('CONCAT(users.first_name, " ", users.last_name) as name'),
                    'credits.phone_number',
                    'credit_transactions.created_at as timestamp',
                    'credit_transactions.void_reason',
                    DB::raw("CASE credit_transactions.transaction_type WHEN 'debit' THEN 'DEBIT' ELSE 'CREDIT' END AS transaction_type"),
                    'credit_transactions.balance_credit as closing_balance',
                    'credit_transactions.amount as transaction',
                    DB::raw('
                        CASE 
                            WHEN credit_transactions.transaction_type = "credit" 
                            THEN (credit_transactions.balance_credit - credit_transactions.amount) 
                            ELSE (credit_transactions.balance_credit + credit_transactions.amount) 
                        END as opening_balance')
                ])
                ->orderBy('credit_transactions.created_at', 'desc');
    
            $start_date = $request->input('start_date');
            $end_date = $request->input('end_date');
    
            if (!empty($start_date) && !empty($end_date)) {
                $start_date = date('Y-m-d 00:00:00', strtotime($start_date));
                $end_date = date('Y-m-d 23:59:59', strtotime($end_date));
    
                $query->whereBetween('credit_transactions.created_at', [$start_date, $end_date]);
            }
    
            $transaction_type = $request->input('transaction_type');
            if (!empty($transaction_type)) {
                $query->where('credit_transactions.transaction_type', $transaction_type);
            }

            return Datatables::of($query)
                ->addColumn(
                    'opening_balance',
                    '<div style="white-space: nowrap;">@format_currency($opening_balance)</div>'
                ) 
                ->addColumn(
                    'transaction',
                    '<div style="white-space: nowrap;">@format_currency($transaction)</div>'
                ) 
                ->addColumn(
                    'closing_balance',
                    '<div style="white-space: nowrap;">@format_currency($closing_balance)</div>'
                )
                ->filterColumn('phone_number', function ($query, $keyword) {
                    $query->where('credits.phone_number', 'like', ["%{$keyword}%"]);
                })
                ->filterColumn('name', function ($query, $keyword) {
                    $query->where('users.first_name', 'like', ["%{$keyword}%"])
                            ->orWhere('users.last_name', 'like', ["%$keyword%"]);
                })
                ->rawColumns(['name', 'phone_number', 'opening_balance', 'transaction', 'closing_balance', 'timestamp','transaction_type'])
                ->make(true);
        }
    
        return view('credit.credits_transactions');
    }
   
}
