<?php

namespace App\Http\Controllers;

use App\Account;
use App\Business;
use App\BusinessLocation;
use App\Contact;
use App\CustomerGroup;
use App\InvoiceScheme;
use App\SellingPriceGroup;
use App\TaxRate;
use App\Transaction;
use App\TransactionSellLine;
use App\TypesOfService;
use App\User;
use App\Utils\BusinessUtil;
use App\Utils\ContactUtil;
use App\Utils\ModuleUtil;
use App\Utils\ProductUtil;
use App\Utils\TransactionUtil;
use App\Warranty;
use DB;
use Illuminate\Http\Request;
use Yajra\DataTables\Facades\DataTables;
use App\Product;
use App\Media;
use Spatie\Activitylog\Models\Activity;
use Illuminate\Support\Facades\Storage;
use ZipArchive;
use File;
use PDF;
use Carbon\Carbon;
use App\Restaurant\ResTable;
use App\PosResTables;
use Config;

class SellController extends Controller
{
    /**
     * All Utils instance.
     *
     */
    protected $contactUtil;
    protected $businessUtil;
    protected $transactionUtil;
    protected $productUtil;


    /**
     * Constructor
     *
     * @param ProductUtils $product
     * @return void
     */
    public function __construct(ContactUtil $contactUtil, BusinessUtil $businessUtil, TransactionUtil $transactionUtil, ModuleUtil $moduleUtil, ProductUtil $productUtil)
    {
        $this->contactUtil = $contactUtil;
        $this->businessUtil = $businessUtil;
        $this->transactionUtil = $transactionUtil;
        $this->moduleUtil = $moduleUtil;
        $this->productUtil = $productUtil;

        $this->dummyPaymentLine = ['method' => '', 'amount' => 0, 'note' => '', 'card_transaction_number' => '', 'card_number' => '', 'card_type' => '', 'card_holder_name' => '', 'card_month' => '', 'card_year' => '', 'card_security' => '', 'cheque_number' => '', 'bank_account_number' => '',
        'is_return' => 0, 'transaction_no' => ''];

        $this->shipping_status_colors = [
            'ordered' => 'bg-yellow',
            'packed' => 'bg-info',
            'shipped' => 'bg-navy',
            'delivered' => 'bg-green',
            'cancelled' => 'bg-red',
        ];
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $is_admin = $this->businessUtil->is_admin(auth()->user());

        if ( !$is_admin && !auth()->user()->hasAnyPermission(['sell.view', 'sell.create', 'direct_sell.access', 'direct_sell.view', 'view_own_sell_only', 'view_commission_agent_sell', 'access_shipping', 'access_own_shipping', 'access_commission_agent_shipping', 'so.view_all', 'so.view_own']) ) {
            abort(403, 'Unauthorized action.');
        }

        $business_id = request()->session()->get('user.business_id');
        $is_woocommerce = $this->moduleUtil->isModuleInstalled('Woocommerce');
        $is_tables_enabled = $this->transactionUtil->isModuleEnabled('tables');
        $is_service_staff_enabled = $this->transactionUtil->isModuleEnabled('service_staff');
        $is_types_service_enabled = $this->moduleUtil->isModuleEnabled('types_of_service');

        if (request()->ajax()) {
            $payment_types = $this->transactionUtil->payment_types(null, true, $business_id);
            $with = [];
            $shipping_statuses = $this->transactionUtil->shipping_statuses();
            $payment_type_filter = null;

            $sale_type = !empty(request()->input('sale_type')) ? request()->input('sale_type') : 'sell';
            if(!empty(request()->input('payment_types')) && request()->input('payment_types') != 'All' && request()->input('payment_types') != 'Cash') {
                $payment_type_filter = request()->input('payment_types');
            } else if(!empty(request()->input('payment_types')) && request()->input('payment_types') == 'Cash') {
                $payment_type_filter = 'credit';
            }
            
            $sells = $this->transactionUtil->getListSells($business_id, $sale_type, $payment_type_filter);
            //dd($sells->toArray());
            $permitted_locations = auth()->user()->permitted_locations();
            if ($permitted_locations != 'all') {
                $sells->whereIn('transactions.location_id', $permitted_locations);
            }

            //Add condition for created_by,used in sales representative sales report
            if (request()->has('created_by')) {
                $created_by = request()->get('created_by');
                if (!empty($created_by)) {
                    $sells->where('transactions.created_by', $created_by);
                }
            }

            $partial_permissions = ['view_own_sell_only', 'view_commission_agent_sell', 'access_own_shipping', 'access_commission_agent_shipping'];
            if (!auth()->user()->can('direct_sell.access')) {
                $sells->where( function($q){
                    if (auth()->user()->hasAnyPermission(['view_own_sell_only', 'access_own_shipping'])) {
                        $q->where('transactions.created_by', request()->session()->get('user.id'));
                    }

                    //if user is commission agent display only assigned sells
                    if (auth()->user()->hasAnyPermission(['view_commission_agent_sell', 'access_commission_agent_shipping'])) {
                        $q->orWhere('transactions.commission_agent', request()->session()->get('user.id'));
                    }
                });
            }

            if (!empty(request()->input('payment_status')) && request()->input('payment_status') != 'overdue') {
                $sells->where('transactions.payment_status', request()->input('payment_status'));
            } elseif (request()->input('payment_status') == 'overdue') {
                $sells->whereIn('transactions.payment_status', ['due', 'partial'])
                    ->whereNotNull('transactions.pay_term_number')
                    ->whereNotNull('transactions.pay_term_type')
                    ->whereRaw("IF(transactions.pay_term_type='days', DATE_ADD(transactions.transaction_date, INTERVAL transactions.pay_term_number DAY) < CURDATE(), DATE_ADD(transactions.transaction_date, INTERVAL transactions.pay_term_number MONTH) < CURDATE())");
            }

            //Add condition for location,used in sales representative expense report
            if (request()->has('location_id')) {
                $location_id = request()->get('location_id');
                if (!empty($location_id)) {
                    $sells->where('transactions.location_id', $location_id);
                }
            }

            if (request()->has('terminal_id')) {
                $terminal_id = request()->get('terminal_id');
                if (!empty($terminal_id)) {
                    $sells->where('transactions.terminal_id', $terminal_id);
                }
            }
            
            if (!empty(request()->input('rewards_only')) && request()->input('rewards_only') == true) {
                $sells->where(function ($q) {
                    $q->whereNotNull('transactions.rp_earned')
                    ->orWhere('transactions.rp_redeemed', '>', 0);
                });
            }
            
            if (!empty(request()->customer_id)) {
                $customer_id = request()->customer_id;
                $sells->where('contacts.id', $customer_id);
            }
            
            if(!isset($location_id)) {
                if (!empty(request()->start_date) && !empty(request()->end_date)) {
                    $start = request()->start_date;
                    $end =  request()->end_date;
                    $sells->whereDate('transactions.transaction_date', '>=', $start)
                          ->whereDate('transactions.transaction_date', '<=', $end);
                }
            } else {
                $businessLocation = BusinessLocation::find($location_id);
                $daystartTime = $businessLocation->day_start_time;
                $dayStartTime = $daystartTime ? $daystartTime . ":00:00" : "00:00:00";
                $dayendTime = $daystartTime - 1;
                $dayEndTime = $dayendTime.":59:59";

                if (!empty(request()->start_date) && !empty(request()->end_date)) {
                    $start = request()->start_date.' '.$dayStartTime;
                    $end =  request()->end_date;
                    $end = date('Y-m-d', strtotime($end . ' +1 day')) . ' ' . $dayEndTime;
                    
                    $sells->where('transactions.transaction_date', '>=', $start)
                          ->where('transactions.transaction_date', '<=', $end);
                }
            }

            //Check is_direct sell
            if (request()->has('is_direct_sale')) {
                $is_direct_sale = request()->is_direct_sale;
                if ($is_direct_sale == 0) {
                    $sells->where('transactions.is_direct_sale', 0);
                    $sells->whereNull('transactions.sub_type');
                }
            }

            //Add condition for commission_agent,used in sales representative sales with commission report
            if (request()->has('commission_agent')) {
                $commission_agent = request()->get('commission_agent');
                if (!empty($commission_agent)) {
                    $sells->where('transactions.commission_agent', $commission_agent);
                }
            }

            if ($is_woocommerce) {
                $sells->addSelect('transactions.woocommerce_order_id');
                if (request()->only_woocommerce_sells) {
                    $sells->whereNotNull('transactions.woocommerce_order_id');
                }
            }

            if (request()->only_subscriptions) {
                $sells->where(function ($q) {
                    $q->whereNotNull('transactions.recur_parent_id')
                        ->orWhere('transactions.is_recurring', 1);
                });
            }

            if (!empty(request()->list_for) && request()->list_for == 'service_staff_report') {
                $sells->whereNotNull('transactions.res_waiter_id');
            }

            if (!empty(request()->res_waiter_id)) {
                $sells->where('transactions.res_waiter_id', request()->res_waiter_id);
            }

            if (!empty(request()->input('sub_type'))) {
                $sells->where('transactions.sub_type', request()->input('sub_type'));
            }

            if (!empty(request()->input('created_by'))) {
                $sells->where('transactions.created_by', request()->input('created_by'));
            }

            if (!empty(request()->input('status'))) {
                $sells->where('transactions.status', request()->input('status'));
            }

            if (!empty(request()->input('sales_cmsn_agnt'))) {
                $sells->where('transactions.commission_agent', request()->input('sales_cmsn_agnt'));
            }

            if (!empty(request()->input('service_staffs'))) {
                $sells->where('transactions.res_waiter_id', request()->input('service_staffs'));
            }
            $only_shipments = request()->only_shipments == 'true' ? true : false;
            if ($only_shipments) {
                $sells->whereNotNull('transactions.shipping_status');
            }
            
            if (!empty(request()->input('shipping_status'))) {
                $sells->where('transactions.shipping_status', request()->input('shipping_status'));
            }
            
            if (!empty(request()->input('for_dashboard_sales_order'))) {
                $sells->whereIn('transactions.status', ['partial', 'ordered'])
                    ->orHavingRaw('so_qty_remaining > 0');
            }

            if ($sale_type == 'sales_order') {
                if (!auth()->user()->can('so.view_all') && auth()->user()->can('so.view_own')) {
                    $sells->where('transactions.created_by', request()->session()->get('user.id'));
                }
            }
            
            $sells->groupBy('transactions.id');
            
            if (!empty(request()->suspended)) {
                
                
                $transaction_sub_type = request()->get('transaction_sub_type');
                if (!empty($transaction_sub_type)) {
                    $sells->where('transactions.sub_type', $transaction_sub_type);
                } else {
                    $sells->where('transactions.sub_type', null);
                }

                $with = ['sell_lines'];

                if ($is_tables_enabled) {
                    $with[] = 'table';
                }

                if ($is_service_staff_enabled) {
                    $with[] = 'service_staff';
                }

                $sales = $sells->where('transactions.is_suspend', 1)
                            ->with($with)
                            ->addSelect('transactions.is_suspend','transactions.peppol_guid', 'transactions.res_table_id', 'transactions.res_waiter_id', 'transactions.additional_notes')
                            ->get();
               
                return view('sale_pos.partials.suspended_sales_modal')->with(compact('sales', 'is_tables_enabled', 'is_service_staff_enabled', 'transaction_sub_type'));
            }

            $with[] = 'payment_lines';
            if (!empty($with)) {
                //if (request()->input('payment_types') == 'All') {
                    $sells->with($with);
                // } else {
                //     $sells->with($with, function ($query) {
                //         $query->where('card_type','=', strtolower(request()->input('payment_types')));
                //     });
                // }
            }

            //$business_details = $this->businessUtil->getDetails($business_id);
            if ($this->businessUtil->isModuleEnabled('subscription')) {
                $sells->addSelect('transactions.is_recurring', 'transactions.peppol_guid','transactions.recur_parent_id');
            }
            
            $sales_order_statuses = Transaction::sales_order_statuses();

            // $d = $sells->get();
            // dd($d[0]);
            
            $datatable = Datatables::of($sells)
                ->addColumn(
                    'action',
                    function ($row) use ($only_shipments, $is_admin, $sale_type) {
                        $html = '<div class="btn-group">
                                    <button type="button" class="btn btn-info dropdown-toggle btn-xs" 
                                        data-toggle="dropdown" aria-expanded="false">' .
                                        __("messages.actions") .
                                        '<span class="caret"></span><span class="sr-only">Toggle Dropdown
                                        </span>
                                    </button>
                                    <ul class="dropdown-menu dropdown-menu-left" role="menu">' ;

                        if (auth()->user()->can("sell.view") || auth()->user()->can("direct_sell.view") || auth()->user()->can("view_own_sell_only")) {
                            $html .= '<li><a href="#" data-href="' . action("SellController@show", [$row->id]) . '" class="btn-modal" data-container=".view_modal"><i class="fas fa-eye" aria-hidden="true"></i> ' . __("messages.view") . '</a></li>';
                        }
                        if (!$only_shipments) {
                            if ($row->is_direct_sale == 0) {
                                if (auth()->user()->can("sell.update")) {
                                    $html .= '<li><a target="_blank" href="' . action('SellPosController@edit', [$row->id]) . '"><i class="fas fa-edit"></i> ' . __("messages.edit") . '</a></li>';
                                }
                            } elseif ($row->type == 'sales_order') {
                                if (auth()->user()->can("so.update")) {
                                    $html .= '<li><a target="_blank" href="' . action('SellController@edit', [$row->id]) . '"><i class="fas fa-edit"></i> ' . __("messages.edit") . '</a></li>';
                                }
                            } else {
                                if (auth()->user()->can("direct_sell.update")) {
                                    $html .= '<li><a target="_blank" href="' . action('SellController@edit', [$row->id]) . '"><i class="fas fa-edit"></i> ' . __("messages.edit") . '</a></li>';
                                }
                            }

                            $delete_link = '<li><a href="' . action('SellPosController@destroy', [$row->id]) . '" class="delete-sale"><i class="fas fa-trash"></i> ' . __("messages.delete") . '</a></li>';
                            if ($row->is_direct_sale == 0) {
                                if (auth()->user()->can("sell.delete")) {
                                    $html .= $delete_link;
                                }
                            } elseif ($row->type == 'sales_order') {
                                if (auth()->user()->can("so.delete")) {
                                    $html .= $delete_link;
                                }
                            } else {
                                if (auth()->user()->can("direct_sell.delete")) {
                                    $html .= $delete_link;
                                }
                            }
                        }

                        if (config('constants.enable_download_pdf') && auth()->user()->can("print_invoice") && $sale_type != 'sales_order') {
                            $html .= '<li><a href="' . route('sell.downloadPdf', [$row->id]) . '" target="_blank"><i class="fas fa-print" aria-hidden="true"></i> ' . __("lang_v1.download_pdf") . '</a></li>';

                            if (!empty($row->shipping_status)) {
                                $html .= '<li><a href="' . route('packing.downloadPdf', [$row->id]) . '" target="_blank"><i class="fas fa-print" aria-hidden="true"></i> ' . __("lang_v1.download_paking_pdf") . '</a></li>';
                            }
                        }
                        
                        if (auth()->user()->can("sell.view") || auth()->user()->can("direct_sell.access")) {
                            if (!empty($row->document)) {
                                $document_name = !empty(explode("_", $row->document, 2)[1]) ? explode("_", $row->document, 2)[1] : $row->document ;
                                $html .= '<li><a href="' . url('uploads/documents/' . $row->document) .'" download="' . $document_name . '"><i class="fas fa-download" aria-hidden="true"></i>' . __("purchase.download_document") . '</a></li>';
                                if (isFileImage($document_name)) {
                                    $html .= '<li><a href="#" data-href="' . url('uploads/documents/' . $row->document) .'" class="view_uploaded_document"><i class="fas fa-image" aria-hidden="true"></i>' . __("lang_v1.view_document") . '</a></li>';
                                }
                            }
                        }

                        if ($is_admin || auth()->user()->hasAnyPermission(['access_shipping', 'access_own_shipping', 'access_commission_agent_shipping']) ) {
                            $html .= '<li><a href="#" data-href="' . action('SellController@editShipping', [$row->id]) . '" class="btn-modal" data-container=".view_modal"><i class="fas fa-truck" aria-hidden="true"></i>' . __("lang_v1.edit_shipping") . '</a></li>';
                        }
                            
                        if ($row->type == 'sell') {
                            if (auth()->user()->can("print_invoice")) {
                                $html .= '<li><a href="#" class="print-invoice" data-href="' . route('sell.printInvoice', [$row->id]) . '"><i class="fas fa-print" aria-hidden="true"></i> ' . __("lang_v1.print_invoice") . '</a></li>
                                    <li><a href="#" class="print-invoice" data-href="' . route('sell.printInvoice', [$row->id]) . '?package_slip=true"><i class="fas fa-file-alt" aria-hidden="true"></i> ' . __("lang_v1.packing_slip") . '</a></li>';
                            }
                            $html .= '<li class="divider"></li>';
                            if (!$only_shipments) {
                                if ($row->payment_status != "paid" && auth()->user()->can("sell.payments")) {
                                    $html .= '<li><a href="' . action('TransactionPaymentController@addPayment', [$row->id]) . '" class="add_payment_modal"><i class="fas fa-money-bill-alt"></i> ' . __("purchase.add_payment") . '</a></li>';
                                }

                                $html .= '<li><a href="' . action('TransactionPaymentController@show', [$row->id]) . '" class="view_payment_modal"><i class="fas fa-money-bill-alt"></i> ' . __("purchase.view_payments") . '</a></li>';

                                if (auth()->user()->can("sell.create")) {
                                    $html .= '<li><a href="' . action('SellController@duplicateSell', [$row->id]) . '"><i class="fas fa-copy"></i> ' . __("lang_v1.duplicate_sell") . '</a></li>

                                    <li><a href="' . action('SellReturnController@add', [$row->id]) . '"><i class="fas fa-undo"></i> ' . __("lang_v1.sell_return") . '</a></li>

                                    <li><a href="' . action('SellPosController@showInvoiceUrl', [$row->id]) . '" class="view_invoice_url"><i class="fas fa-eye"></i> ' . __("lang_v1.view_invoice_url") . '</a></li>';
                                }
                            }

                            $html .= '<li><a href="#" data-href="' . action('NotificationController@getTemplate', ["transaction_id" => $row->id,"template_for" => "new_sale"]) . '" class="btn-modal" data-container=".view_modal"><i class="fa fa-envelope" aria-hidden="true"></i>' . __("lang_v1.new_sale_notification") . '</a></li>';
                        } else {
                            $html .= '<li><a href="#" data-href="' . action('SellController@viewMedia', ["model_id" => $row->id, "model_type" => "App\Transaction", 'model_media_type' => 'shipping_document']) . '" class="btn-modal" data-container=".view_modal"><i class="fas fa-paperclip" aria-hidden="true"></i>' . __("lang_v1.shipping_documents") . '</a></li>';
                        }

                        $html .= '</ul></div>';

                        return $html;
                    }
                )
                ->removeColumn('id')
                ->editColumn(
                    'final_total',
                    '<span class="final-total" data-orig-value="{{$final_total}}">@format_currency($final_total)</span>'
                )
                ->editColumn(
                    'tax_amount',
                    '<span class="total-tax" data-orig-value="{{$tax_amount}}">@format_currency($tax_amount)</span>'
                )
                ->editColumn(
                    'total_paid',
                    '<span class="total-paid" data-orig-value="{{$total_paid}}">@format_currency($total_paid)</span>'
                )
                ->editColumn(
                    'total_before_tax',
                    '<span class="total_before_tax" data-orig-value="{{$total_before_tax}}">@format_currency($total_before_tax)</span>'
                )
                ->editColumn(
                    'discount_amount',
                    function ($row) {
                        $discount = !empty($row->discount_amount) ? $row->discount_amount : 0;

                        if (!empty($discount) && $row->discount_type == 'percentage') {
                            $discount = $row->total_before_tax * ($discount / 100);
                        }

                        return '<span class="total-discount" data-orig-value="' . $discount . '">' . $this->transactionUtil->num_f($discount, true) . '</span>';
                    }
                )
                ->editColumn('transaction_date', '{{@format_datetime($transaction_date)}}')
                ->editColumn(
                    'payment_status',
                    function ($row) {
                        $payment_status = Transaction::getPaymentStatus($row);
                        return (string) view('sell.partials.payment_status', ['payment_status' => $payment_status, 'id' => $row->id]);
                    }
                )
                ->editColumn(
                    'types_of_service_name',
                    '<span class="service-type-label" data-orig-value="{{$types_of_service_name}}" data-status-name="{{$types_of_service_name}}">{{$types_of_service_name}}</span>'
                )
                ->addColumn('total_remaining', function ($row) {
                    $total_remaining =  $row->final_total - $row->total_paid;
                    $total_remaining_html = '<span class="payment_due" data-orig-value="' . $total_remaining . '">' . $this->transactionUtil->num_f($total_remaining, true) . '</span>';

                    
                    return $total_remaining_html;
                })
                ->addColumn('return_due', function ($row) {
                    $return_due_html = '';
                    if (!empty($row->return_exists)) {
                        $return_due = $row->amount_return - $row->return_paid;
                        $return_due_html .= '<a href="' . action("TransactionPaymentController@show", [$row->return_transaction_id]) . '" class="view_purchase_return_payment_modal"><span class="sell_return_due" data-orig-value="' . $return_due . '">' . $this->transactionUtil->num_f($return_due, true) . '</span></a>';
                    }

                    return $return_due_html;
                })
                ->editColumn('invoice_no', function ($row) {
                    $invoice_no = $row->invoice_no;
                    if (!empty($row->woocommerce_order_id)) {
                        $invoice_no .= ' <i class="fab fa-wordpress text-primary no-print" title="' . __('lang_v1.synced_from_woocommerce') . '"></i>';
                    }
                    if (!empty($row->return_exists)) {
                        $invoice_no .= ' &nbsp;<small class="label bg-red label-round no-print" title="' . __('lang_v1.some_qty_returned_from_sell') .'"><i class="fas fa-undo"></i></small>';
                    }
                    if (!empty($row->is_recurring)) {
                        $invoice_no .= ' &nbsp;<small class="label bg-red label-round no-print" title="' . __('lang_v1.subscribed_invoice') .'"><i class="fas fa-recycle"></i></small>';
                    }

                    if (!empty($row->recur_parent_id)) {
                        $invoice_no .= ' &nbsp;<small class="label bg-info label-round no-print" title="' . __('lang_v1.subscription_invoice') .'"><i class="fas fa-recycle"></i></small>';
                    }

                    if (!empty($row->is_export)) {
                        $invoice_no .= '</br><small class="label label-default no-print" title="' . __('lang_v1.export') .'">'.__('lang_v1.export').'</small>';
                    }

                    return $invoice_no;
                })
                ->editColumn('shipping_status', function ($row) use ($shipping_statuses) {
                    $status_color = !empty($this->shipping_status_colors[$row->shipping_status]) ? $this->shipping_status_colors[$row->shipping_status] : 'bg-gray';
                    $status = !empty($row->shipping_status) ? '<a href="#" class="btn-modal" data-href="' . action('SellController@editShipping', [$row->id]) . '" data-container=".view_modal"><span class="label ' . $status_color .'">' . $shipping_statuses[$row->shipping_status] . '</span></a>' : '';
                     
                    return $status;
                })
                ->addColumn('conatct_name', '@if(!empty($supplier_business_name)) {{$supplier_business_name}}, <br> @endif {{$name}}')
                ->editColumn('total_items', '{{@format_quantity($total_items)}}')
                ->filterColumn('conatct_name', function ($query, $keyword) {
                    $query->where( function($q) use($keyword) {
                        $q->where('contacts.name', 'like', "%{$keyword}%")
                        ->orWhere('contacts.supplier_business_name', 'like', "%{$keyword}%");
                    });
                })
                ->addColumn('payment_methods', function ($row) use ($payment_types) {
                    $methods = array_unique($row->payment_lines->pluck('method')->toArray());
                    $count = count($methods);
                    $payment_method = '';
                    if ($count == 1) {
                        $payment_method = $payment_types[$methods[0]]; //issue
                    } elseif ($count > 1) {
                        $payment_method = __('lang_v1.checkout_multi_pay');
                    }

                    $html = !empty($payment_method) ? '<span class="payment-method" data-orig-value="' . $payment_method . '" data-status-name="' . $payment_method . '">' . $payment_method . '</span>' : '';
                    
                    return $html;
                })
                ->addColumn('payment_types', function ($row) use ($payment_types) {
                    $types = array_unique($row->payment_lines->pluck('card_type')->toArray());
                    // $types = $row->payment_lines;
                    $count = count($types);
                    $payment_type = '';
                    //if ($count == 1) {
                        $payment_type = str_replace(array('[', ']', '"'),'', json_encode($types)); 
                    //}

                    $html = !empty($payment_type) ? '<span class="payment-method" data-orig-value="' . $payment_type . '" data-status-name="' . $payment_type . '">' . $payment_type . '</span>' : '';
                    
                    return $html;
                })
                ->editColumn('status', function($row) use($sales_order_statuses, $is_admin){
                    $status = '';

                    if ($row->type == 'sales_order') {
                        if ($is_admin && $row->status != 'completed') {
                            $status = '<span class="edit-so-status label ' . $sales_order_statuses[$row->status]['class'] . '" data-href="'.action("SalesOrderController@getEditSalesOrderStatus", ['id' => $row->id]).'">' . $sales_order_statuses[$row->status]['label'] . '</span>';
                        } else {
                            $status = '<span class="label ' . $sales_order_statuses[$row->status]['class'] . '" >' . $sales_order_statuses[$row->status]['label'] . '</span>';
                        }
                    }

                    return $status;
                })
                  ->editColumn('table_name', function($row){
                        // $name = '';
                        // if ($row->res_table_id != 'null') {
                        //     $table_name = ResTable::where("id", $row->res_table_id)->value('name');
                        //     if ($table_name) {
                        //         $name = $table_name;
                        //     }
                        // }
                        // return $name;
                        $names = [];
                        if ($row->res_table_id != 'null') {
                            $records = ResTable::where("id", $row->res_table_id)->get();
                            foreach ($records as $record) {
                                $names[] = $record->name;
                            }
                        }
                        return $names;

                })
                ->editColumn('peppol_invoice_status', function($row){
                    return $row->peppol_guid ? 'Sent' : '';
              })
                ->editColumn('so_qty_remaining', '{{@format_quantity($so_qty_remaining)}}')
                ->setRowAttr([
                    'data-href' => function ($row) {
                        if (auth()->user()->can("sell.view") || auth()->user()->can("view_own_sell_only")) {
                            return  action('SellController@show', [$row->id]) ;
                        } else {
                            return '';
                        }
                    }]);

            
            $rawColumns = ['final_total', 'action', 'total_paid', 'total_remaining', 'payment_status', 'invoice_no', 'discount_amount', 'tax_amount', 'total_before_tax', 'shipping_status', 'types_of_service_name', 'payment_methods', 'payment_types', 'return_due', 'conatct_name', 'status', 'peppol_invoice_status'];
                
            return $datatable->rawColumns($rawColumns)
                      ->make(true);
        }

        $business_locations = BusinessLocation::forDropdown($business_id, false);
        $customers = Contact::customersDropdown($business_id, false);
        $sales_representative = User::forDropdown($business_id, false, false, true);
        $payment_types_dropdown = [];
        //$payment_types_dropdown = $this->transactionUtil->payment_types(null, false, $business_id);
        //$payment_types_dropdown = $this->productUtil->payment_types($location_id);
        
        //Commission agent filter
        $is_cmsn_agent_enabled = request()->session()->get('business.sales_cmsn_agnt');
        $commission_agents = [];
        if (!empty($is_cmsn_agent_enabled)) {
            $commission_agents = User::forDropdown($business_id, false, true, true);
        }

        //Service staff filter
        $service_staffs = null;
        if ($this->productUtil->isModuleEnabled('service_staff')) {
            $service_staffs = $this->productUtil->serviceStaffDropdown($business_id);
        }

        $shipping_statuses = $this->transactionUtil->shipping_statuses();
        $terminals = [];

        return view('sell.index')
        ->with(compact('business_locations', 'customers', 'is_woocommerce', 'sales_representative', 'payment_types_dropdown', 'is_cmsn_agent_enabled', 'commission_agents', 'service_staffs', 'is_tables_enabled', 'is_service_staff_enabled', 'is_types_service_enabled', 'shipping_statuses', 'terminals'));
    }

    public function getPaymentMethod()
    {
        $location_id = request()->input('location_id');
        $payment_types_dropdown = $this->transactionUtil->payment_types($location_id, false);

        return $payment_types_dropdown;
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $sale_type = request()->get('sale_type', '');

        if ($sale_type == 'sales_order') {
            if (!auth()->user()->can('so.create')) {
                abort(403, 'Unauthorized action.');
            }
        } else {
            if (!auth()->user()->can('direct_sell.access')) {
                abort(403, 'Unauthorized action.');
            }
        }
        

        $business_id = request()->session()->get('user.business_id');

        //Check if subscribed or not, then check for users quota
        if (!$this->moduleUtil->isSubscribed($business_id)) {
            return $this->moduleUtil->expiredResponse();
        } elseif (!$this->moduleUtil->isQuotaAvailable('invoices', $business_id)) {
            return $this->moduleUtil->quotaExpiredResponse('invoices', $business_id, action('SellController@index'));
        }

        $walk_in_customer = $this->contactUtil->getWalkInCustomer($business_id);
        
        $business_details = $this->businessUtil->getDetails($business_id);
        $taxes = TaxRate::forBusinessDropdown($business_id, true, true);

        $business_locations = BusinessLocation::forDropdown($business_id, false, true);
        $bl_attributes = $business_locations['attributes'];
        $business_locations = $business_locations['locations'];

        $default_location = null;
        foreach ($business_locations as $id => $name) {
            $default_location = BusinessLocation::findOrFail($id);
            break;
        }

        $commsn_agnt_setting = $business_details->sales_cmsn_agnt;
        $commission_agent = [];
        if ($commsn_agnt_setting == 'user') {
            $commission_agent = User::forDropdown($business_id);
        } elseif ($commsn_agnt_setting == 'cmsn_agnt') {
            $commission_agent = User::saleCommissionAgentsDropdown($business_id);
        }

        $types = [];
        if (auth()->user()->can('supplier.create')) {
            $types['supplier'] = __('report.supplier');
        }
        if (auth()->user()->can('customer.create')) {
            $types['customer'] = __('report.customer');
        }
        if (auth()->user()->can('supplier.create') && auth()->user()->can('customer.create')) {
            $types['both'] = __('lang_v1.both_supplier_customer');
        }
        $customer_groups = CustomerGroup::forDropdown($business_id);

        $payment_line = $this->dummyPaymentLine;
        $payment_types = $this->transactionUtil->payment_types(null, true, $business_id);

        //Selling Price Group Dropdown
        $price_groups = SellingPriceGroup::forDropdown($business_id);

        $default_datetime = $this->businessUtil->format_date('now', true);

        $pos_settings = empty($business_details->pos_settings) ? $this->businessUtil->defaultPosSettings() : json_decode($business_details->pos_settings, true);

        $invoice_schemes = InvoiceScheme::forDropdown($business_id);
        $default_invoice_schemes = InvoiceScheme::getDefault($business_id);
        if (!empty($default_location)) {
            $default_invoice_schemes = InvoiceScheme::where('business_id', $business_id)
                                        ->findorfail($default_location->invoice_scheme_id);
        }
        $shipping_statuses = $this->transactionUtil->shipping_statuses();

        //Types of service
        $types_of_service = [];
        if ($this->moduleUtil->isModuleEnabled('types_of_service')) {
            $types_of_service = TypesOfService::forDropdown($business_id);
        }

        //Accounts
        $accounts = [];
        if ($this->moduleUtil->isModuleEnabled('account')) {
            $accounts = Account::forDropdown($business_id, true, false);
        }

        $status = request()->get('status', '');

        $statuses = Transaction::sell_statuses();

        if ($sale_type == 'sales_order') {
            $status = 'ordered';
        }

        return view('sell.create')
            ->with(compact(
                'business_details',
                'taxes',
                'walk_in_customer',
                'business_locations',
                'bl_attributes',
                'default_location',
                'commission_agent',
                'types',
                'customer_groups',
                'payment_line',
                'payment_types',
                'price_groups',
                'default_datetime',
                'pos_settings',
                'invoice_schemes',
                'default_invoice_schemes',
                'types_of_service',
                'accounts',
                'shipping_statuses',
                'status',
                'sale_type',
                'statuses'
            ));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
      public function show($id)
    {
        // if (!auth()->user()->can('sell.view') && !auth()->user()->can('direct_sell.access') && !auth()->user()->can('view_own_sell_only')) {
        //     abort(403, 'Unauthorized action.');
        // }

        $business_id = request()->session()->get('user.business_id');
        $taxes = TaxRate::where('business_id', $business_id)
                            ->pluck('name', 'id');
        $query1 = Transaction::where('business_id', $business_id)
                    ->where('id', $id)
                    ->with(['contact', 'sell_lines' => function ($q) {
                        $q->whereNull('parent_sell_line_id');
                    },'sell_lines.product', 'sell_lines.product.unit', 'sell_lines.variations', 'sell_lines.variations.product_variation', 'payment_lines', 'sell_lines.modifiers', 'sell_lines.lot_details', 'tax', 'sell_lines.sub_unit', 'table', 'service_staff', 'sell_lines.service_staff', 'types_of_service', 'sell_lines.warranties', 'media']);

        if (!auth()->user()->can('sell.view') && !auth()->user()->can('direct_sell.access') && auth()->user()->can('view_own_sell_only')) {
            $query->where('transactions.created_by', request()->session()->get('user.id'));
        }
        

        $sell = $query1->firstOrFail();
        $sell->voucher_details = !empty($sell->voucher_details) ? json_decode($sell->voucher_details): null;
        
        
        $query = TransactionSellLine::join('transactions as t', 'transaction_sell_lines.transaction_id', '=', 't.id')
        ->join('variations as v', 'transaction_sell_lines.variation_id', '=', 'v.id')
        ->join('product_variations as pv', 'v.product_variation_id', '=', 'pv.id')
        ->join('contacts as c', 't.contact_id', '=', 'c.id')
        ->join('products as p', 'pv.product_id', '=', 'p.id')
        ->leftJoin('tax_rates', 't.tax_id', '=', 'tax_rates.id')
        ->leftJoin('units as u', 'p.unit_id', '=', 'u.id')
        ->leftJoin('pos_res_tables as tables_new', 't.id', '=', 'tables_new.transaction_id')
        ->leftJoin('transaction_payments as tp', 't.id', '=', 'tp.transaction_id') 
        ->leftJoin('transactions as tr', function($join) {
            $join->on('tr.return_parent_id', '=', 't.id')
                ->where('tr.type', 'sell_return')
                ->where('tr.status', 'final');
        })
        ->where('t.type', 'sell')
        ->where('t.status', 'final')
        ->select('t.id as transaction_id','t.invoice_no','t.final_total','t.transaction_date','t.total_before_tax','t.tax_amount','t.rp_redeemed_amount','t.total_discount_amount','t.tip_amount','t.rp_redeemed','t.round_off_amount','t.discount_amount','t.discount_type','tax_rates.apply_inclusive_gst','tax_rates.amount','t.service_charges','t.voucher_amount_used', 'tr.rp_redeemed_amount as refund_rp_redeemed_amount',
          DB::raw('(
                CASE
                    WHEN tr.id IS NOT NULL AND t.total_before_tax = tr.total_before_tax THEN 0
                    ELSE (
                        t.total_before_tax 
                        - (CASE WHEN tr.id IS NOT NULL THEN tr.total_before_tax ELSE 0 END) 
                        - (t.total_discount_amount - IF(tr.id IS NOT NULL, tr.total_discount_amount, 0))
                        - (t.rp_redeemed_amount - IF(tr.id IS NOT NULL, tr.rp_redeemed_amount, 0))
                        
                    )
                END
            ) as net_sales'),

           DB::raw('
                    CASE 
                        WHEN t.type_for_api = "dinein" THEN 
                            (
                                SELECT COALESCE(SUM(
                                    CASE 
                                        WHEN transaction_sell_lines.parent_sell_line_id IS NOT NULL AND parent_tsl.tag = "T" THEN
                                            transaction_sell_lines.unit_price_before_discount * (parent_tsl.quantity - parent_tsl.quantity_returned)
                                        WHEN transaction_sell_lines.tag = "T" THEN 
                                            transaction_sell_lines.unit_price_before_discount * (transaction_sell_lines.quantity - transaction_sell_lines.quantity_returned)
                                        ELSE
                                            0
                                    END
                                ), 0)
                                FROM transaction_sell_lines
                                LEFT JOIN transaction_sell_lines AS parent_tsl ON transaction_sell_lines.parent_sell_line_id = parent_tsl.id 
                                WHERE transaction_sell_lines.transaction_id = t.id
                            )  
                        ELSE 
                            0
                    END as takeaway_items_calculation
                '),

            DB::raw('
                CASE 
                    WHEN t.type_for_api = "dinein" THEN 
                        ((SELECT COALESCE(SUM(
                            transaction_sell_lines.unit_price_before_discount * (transaction_sell_lines.quantity - transaction_sell_lines.quantity_returned)
                        ), 0)
                        FROM transaction_sell_lines
                        WHERE transaction_sell_lines.transaction_id = t.id
                          AND transaction_sell_lines.tag IS NULL  AND transaction_sell_lines.children_type != "modifier"
                        ))  
                    ELSE 
                        0
                END as total_items_calculation
            '),
            DB::raw('
            CASE 
                WHEN t.type_for_api = "dinein" THEN 
                    (
                        SELECT COALESCE(SUM(
                            CASE 
                                -- Apply discount on lines with their own percentage discount
                                WHEN transaction_sell_lines.line_discount_type = "percentage" 
                                        AND transaction_sell_lines.line_discount_amount > 0 THEN 
                                    transaction_sell_lines.unit_price_before_discount 
                                    * transaction_sell_lines.line_discount_amount / 100 
                                    * (transaction_sell_lines.quantity - transaction_sell_lines.quantity_returned)
                                    * COALESCE((SELECT parent_line.quantity 
                                                FROM transaction_sell_lines AS parent_line 
                                                WHERE parent_line.id = transaction_sell_lines.parent_sell_line_id and parent_line.tag IS NULL), 1)
                                
                                -- Apply discount on lines with their own fixed discount
                                WHEN transaction_sell_lines.line_discount_type = "fixed" 
                                        AND transaction_sell_lines.line_discount_amount > 0  AND transaction_sell_lines.quantity_returned != transaction_sell_lines.quantity  THEN 
                                    transaction_sell_lines.line_discount_amount 
                                    
                                
                                WHEN transaction_sell_lines.parent_sell_line_id IS NOT NULL 
                                        AND transaction_sell_lines.line_discount_amount = 0 THEN
                                    CASE 
                                        WHEN (SELECT parent_line.line_discount_type 
                                                FROM transaction_sell_lines AS parent_line 
                                                WHERE parent_line.id = transaction_sell_lines.parent_sell_line_id) = "percentage" THEN
                                            transaction_sell_lines.unit_price_before_discount
                                            * (SELECT parent_line.line_discount_amount / 100
                                                FROM transaction_sell_lines AS parent_line
                                                WHERE parent_line.id = transaction_sell_lines.parent_sell_line_id and parent_line.tag IS NULL and parent_line.line_discount_amount > 0)
                                            * (SELECT parent_line.quantity - parent_line.quantity_returned
                                                 FROM transaction_sell_lines AS parent_line
                                                 WHERE parent_line.id = transaction_sell_lines.parent_sell_line_id and parent_line.tag IS NULL)
                                        
                                    END
                                
                                ELSE 0
                            END
                        ), 0)
                        FROM transaction_sell_lines
                        WHERE transaction_sell_lines.transaction_id = t.id
                            AND transaction_sell_lines.tag IS NULL 
                    )  
                ELSE 
                    0
            END AS total_sum_line_discount_amount

            '),
            DB::raw('
                CASE 
                    WHEN t.type_for_api = "dinein" THEN 
                        (
                            SELECT COALESCE(SUM(
                                CASE 
                                    WHEN transaction_sell_lines.line_discount_type = "percentage" THEN 
                                        (transaction_sell_lines.unit_price_before_discount * transaction_sell_lines.line_discount_amount / 100) * (transaction_sell_lines.quantity - transaction_sell_lines.quantity_returned)
                                    ELSE 
                                        transaction_sell_lines.line_discount_amount
                                END
                            ), 0)
                            FROM transaction_sell_lines
                            WHERE transaction_sell_lines.transaction_id = t.id
                              AND transaction_sell_lines.tag ="T" 
                              AND transaction_sell_lines.children_type != "modifier"
                        )  
                    ELSE 
                        0
                END as total_sum_line_tag_discount_amount
            '),
            DB::raw('
                CASE 
                    WHEN t.type_for_api = "dinein" THEN 
                        (
                            SELECT COALESCE(SUM(
                                transaction_sell_lines.unit_price_before_discount * (transaction_sell_lines.quantity - transaction_sell_lines.quantity_returned)
                            ), 0)
                            FROM transaction_sell_lines
                            WHERE transaction_sell_lines.transaction_id = t.id
                              AND transaction_sell_lines.tag IS NULL 
                              AND transaction_sell_lines.children_type != "modifier"
                              AND (transaction_sell_lines.line_discount_amount > 0 OR transaction_sell_lines.line_discount_type IS NOT NULL)
                        )  
                    ELSE 
                        0
                END as total_with_discount_items
            '),
            DB::raw('
          CASE 
                    WHEN t.type_for_api = "dinein" THEN 
                        (
                            SELECT COALESCE(SUM(
                                CASE 
                                    WHEN transaction_sell_lines.parent_sell_line_id IS NOT NULL THEN 
                                        CASE 
                                            WHEN (SELECT parent_line.change_price 
                                                  FROM transaction_sell_lines AS parent_line 
                                                  WHERE parent_line.id = transaction_sell_lines.parent_sell_line_id and parent_line.tag IS NULL) = 1 THEN 
                                                0  
                                            ELSE 
                                                transaction_sell_lines.unit_price_before_discount 
                                                * (SELECT parent_line.quantity 
                                                   FROM transaction_sell_lines AS parent_line 
                                                   WHERE parent_line.id = transaction_sell_lines.parent_sell_line_id and parent_line.tag IS NULL)
                                        END
                                    ELSE 
                                        
                                        transaction_sell_lines.unit_price_before_discount 
                                        * (transaction_sell_lines.quantity - transaction_sell_lines.quantity_returned)
                                END
                            ), 0)
                            FROM transaction_sell_lines
                            WHERE transaction_sell_lines.transaction_id = t.id
                              AND transaction_sell_lines.tag IS NULL 
                              AND (
                                  (transaction_sell_lines.parent_sell_line_id IS NOT NULL 
                                    AND (SELECT parent_line.line_discount_amount 
                                        FROM transaction_sell_lines AS parent_line 
                                        WHERE parent_line.id = transaction_sell_lines.parent_sell_line_id and parent_line.tag IS NULL) > 0)
                                  OR (transaction_sell_lines.line_discount_amount > 0 
                                      AND transaction_sell_lines.line_discount_amount IS NOT NULL)
                              )
                        )  
                    ELSE 
                        0
                END AS total_with_individual_discount_items


            '),
            DB::raw('
                CASE 
                    WHEN t.type_for_api = "dinein" THEN 
                        (
                            SELECT COALESCE(SUM(
                                transaction_sell_lines.unit_price_before_discount * (transaction_sell_lines.quantity - transaction_sell_lines.quantity_returned)
                            ), 0)
                            FROM transaction_sell_lines
                            WHERE transaction_sell_lines.transaction_id = t.id
                              AND (transaction_sell_lines.tag IS NULL OR transaction_sell_lines.tag = "T")
                              AND transaction_sell_lines.children_type != "modifier"
                              AND transaction_sell_lines.line_discount_amount > 0
                        )  
                    ELSE 
                        0
                END as individual_disc_amt
            '),
            DB::raw('
                   CASE 
                    WHEN t.type_for_api = "dinein" THEN 
                        (
                            SELECT COALESCE(SUM(
                                transaction_sell_lines.unit_price_before_discount 
                                * (transaction_sell_lines.quantity - transaction_sell_lines.quantity_returned)
                                * CASE 
                                    WHEN transaction_sell_lines.parent_sell_line_id IS NOT NULL THEN 
                                        (SELECT (parent_line.quantity - parent_line.quantity_returned)
                                        FROM transaction_sell_lines AS parent_line 
                                        WHERE parent_line.id = transaction_sell_lines.parent_sell_line_id AND parent_line.tag IS NULL)
                                    ELSE 1
                                END
                            ), 0)
                            FROM transaction_sell_lines
                            WHERE transaction_sell_lines.transaction_id = t.id
                            AND transaction_sell_lines.tag IS NULL 

                            AND (transaction_sell_lines.line_discount_amount = 0 OR transaction_sell_lines.line_discount_type IS NULL)
                            AND (
                                transaction_sell_lines.parent_sell_line_id IS NULL 
                                OR (
                                    transaction_sell_lines.parent_sell_line_id IS NOT NULL 
                                    AND (SELECT parent_line.line_discount_amount 
                                        FROM transaction_sell_lines AS parent_line 
                                        WHERE parent_line.id = transaction_sell_lines.parent_sell_line_id and parent_line.tag IS NULL) = 0
                                )
                            )
                        )  
                    ELSE 
                        0
                END AS total_without_discount_items


            '),
            DB::raw('
               CASE 
                    WHEN t.type_for_api = "dinein" THEN 
                        (
                            SELECT COALESCE(SUM(
                                transaction_sell_lines.unit_price_before_discount 
                                * (transaction_sell_lines.quantity - transaction_sell_lines.quantity_returned)
                                * CASE 
                                    WHEN transaction_sell_lines.parent_sell_line_id IS NOT NULL THEN 
                                        
                                        (SELECT (parent_line.quantity - parent_line.quantity_returned) 
                                         FROM transaction_sell_lines AS parent_line 
                                         WHERE parent_line.id = transaction_sell_lines.parent_sell_line_id)
                                    ELSE 1
                                END
                            ), 0)
                            FROM transaction_sell_lines
                            WHERE transaction_sell_lines.transaction_id = t.id
                              AND transaction_sell_lines.line_discount_amount = 0
                              AND (
                                  transaction_sell_lines.parent_sell_line_id IS NULL 
                                  OR (SELECT parent_line.line_discount_amount 
                                      FROM transaction_sell_lines AS parent_line 
                                      WHERE parent_line.id = transaction_sell_lines.parent_sell_line_id) = 0
                              )
                        )  
                    ELSE 
                        0
                END AS total_without_individual_discount_items


            '),
            DB::raw('(t.total_before_tax - t.total_discount_amount - t.rp_redeemed_amount) * t.service_charges as total_service_charges'),
            DB::raw('(t.total_before_tax - t.total_discount_amount - t.rp_redeemed_amount + (t.total_before_tax - t.total_discount_amount - t.rp_redeemed_amount) * t.service_charges) as gross_sales'),
            DB::raw('
                CASE 
                    WHEN tax_rates.apply_inclusive_gst = 1 THEN 
                        (t.total_before_tax - (CASE WHEN tr.id IS NOT NULL THEN tr.total_with_modifier ELSE 0 END) - t.total_discount_amount - t.rp_redeemed_amount + (t.total_before_tax - t.total_discount_amount - t.rp_redeemed_amount) * t.service_charges)
                    ELSE 
                        (t.total_before_tax - (CASE WHEN tr.id IS NOT NULL THEN tr.total_with_modifier ELSE 0 END) - t.total_discount_amount - t.rp_redeemed_amount + (t.total_before_tax - t.total_discount_amount - t.rp_redeemed_amount) * t.service_charges) 
                        + ((t.total_before_tax - (CASE WHEN tr.id IS NOT NULL THEN tr.total_with_modifier ELSE 0 END) - t.total_discount_amount - t.rp_redeemed_amount + (t.total_before_tax - t.total_discount_amount - t.rp_redeemed_amount) * t.service_charges) * tax_rates.amount / 100)
                END as total_amount
            '),
            DB::raw('
                CASE 
                    WHEN tax_rates.apply_inclusive_gst = 1 THEN 
                        ((t.total_before_tax - (CASE WHEN tr.id IS NOT NULL THEN tr.total_with_modifier ELSE 0 END) - t.total_discount_amount - t.rp_redeemed_amount + ((t.total_before_tax - t.total_discount_amount - t.rp_redeemed_amount) * t.service_charges)) / (tax_rates.amount + 100)) * tax_rates.amount
                    ELSE 
                        ((t.total_before_tax - (CASE WHEN tr.id IS NOT NULL THEN tr.total_with_modifier ELSE 0 END) - t.total_discount_amount - t.rp_redeemed_amount + (t.total_before_tax - t.total_discount_amount - t.rp_redeemed_amount) * t.service_charges) * tax_rates.amount / 100)
                END as gst
            '),
            DB::raw('
                CASE 
                    WHEN t.discount_type = "percentage" THEN 
                        (t.total_before_tax + transaction_sell_lines.line_discount_amount) * t.discount_amount 
                    ELSE 
                        CASE
                            WHEN tr.id IS NOT NULL AND t.id = tr.return_parent_id THEN 
                                 t.discount_amount - tr.total_discount_amount
                            ELSE
                                t.discount_amount
                        END
                END as cart_discount_amount
            '),
            DB::raw('CASE WHEN tr.id IS NOT NULL THEN tr.total_with_modifier ELSE 0 END as refund'),
            DB::raw('CASE WHEN tr.id IS NOT NULL THEN tr.total_before_tax ELSE 0 END as refund_total_before_tax'),

            DB::raw('
                (SELECT JSON_ARRAYAGG(
                            JSON_OBJECT(
                                "name", pd.name, 
                                "total_quantity", pd.total_quantity,
                                "unit_price_before_discount", pd.unit_price_before_discount,
                                "total_line_discount_amount", pd.total_line_discount_amount
                            )
                        )
                        FROM (
                            SELECT 
                                p.name,
                                SUM(
                                    CASE 
                                        WHEN transaction_sell_lines.parent_sell_line_id IS NOT NULL THEN
                                            parent_line.quantity - parent_line.quantity_returned
                                        ELSE 
                                            transaction_sell_lines.quantity - transaction_sell_lines.quantity_returned 
                                    END
                                ) AS total_quantity,
                                SUM(
                                    -- Apply parent line quantity multiplier if parent_sell_line_id is not null
                                    CASE 
                                        WHEN transaction_sell_lines.parent_sell_line_id IS NOT NULL THEN
                                            transaction_sell_lines.unit_price_before_discount * (parent_line.quantity - parent_line.quantity_returned)
                                        ELSE 
                                            transaction_sell_lines.unit_price_before_discount * (transaction_sell_lines.quantity - transaction_sell_lines.quantity_returned)
                                    END
                                ) AS unit_price_before_discount,
                               SUM(
                                    CASE 
                                        WHEN transaction_sell_lines.line_discount_type = "percentage" THEN 
                                            CASE 
                                                WHEN transaction_sell_lines.parent_sell_line_id IS NOT NULL THEN
                                                    (transaction_sell_lines.unit_price_before_discount * transaction_sell_lines.line_discount_amount / 100) *(parent_line.quantity - parent_line.quantity_returned )
                                                ELSE 
                                                    (transaction_sell_lines.unit_price_before_discount * transaction_sell_lines.line_discount_amount / 100) * (transaction_sell_lines.quantity - transaction_sell_lines.quantity_returned)
                                            END
                                        ELSE 
                                            transaction_sell_lines.line_discount_amount
                                    END
                                ) AS total_line_discount_amount
                            FROM transaction_sell_lines transaction_sell_lines
                            JOIN products p ON transaction_sell_lines.product_id = p.id
                            LEFT JOIN transaction_sell_lines parent_line
                                ON transaction_sell_lines.parent_sell_line_id = parent_line.id 
                            WHERE transaction_sell_lines.transaction_id = t.id
                            GROUP BY p.name
                        ) AS pd
                ) AS product_details

            ')
        )
        ->where('t.id', $id)
        ->where('t.business_id', $business_id)->first();

        $activities = Activity::forSubject($sell)
           ->with(['causer', 'subject'])
           ->latest()
           ->get();

           $service_charge = $this->calculateServiceCharges($query);  
        // foreach ($sell->sell_lines as $key => $value) {
        //     if (!empty($value->sub_unit_id)) {
        //         $formated_sell_line = $this->transactionUtil->recalculateSellLineTotals($business_id, $value);
        //         $sell->sell_lines[$key] = $formated_sell_line;
        //     }
        // }
        if($query->final_total <= 0){
            $service_charge = 0;
        }


        $query->sub_total =  $query->total_before_tax - $query->refund_total_before_tax;
        $query->total =  $query->net_sales > 0 ? $query->net_sales : 0;
        $total_amount_for_gst =  $query->total  + $service_charge;

        if($query->apply_inclusive_gst == 1){
            $query->gst = round((($query->net_sales + $service_charge) / ($query->amount + 100)) * $query->amount, 2); 

            // dd()
            // $query->gst = ($total_amount_for_gst / ($query->tax_rate_amount + 100)) * $query->tax_rate_amount;  

        }
        else{
            // $query->gst = ($total_amount_for_gst /  100) * $query->tax_rate_amount;

            // dd($query->net_sales , $service_charge , $row->amount);
            $query->gst  = round((($query->net_sales + $service_charge) / 100) * $query->amount, 2); 
        }

         $newVoucherAmount = 0;
        if($query->voucher_amount_used > 0)
        {

            $voucher_value = ( $query->voucher_amount_used / ($query->total_before_tax - $query->total_discount_amount)) * 100;
            $newVoucherAmount = (round($query->net_sales, 2) * $voucher_value) / 100;
              
        }

        $query->total_amount = $query->total > 0 ? $query->total + $service_charge  - $query->round_off_amount + ($query->apply_inclusive_gst == 1 ? 0 : $query->gst) : 0;
        $query->total_payable = $query->total_amount > 0 ? $query->total_amount - $newVoucherAmount + $query->tip_amount : 0;

        $query->is_all_refund = 0;

        // dd($query->refund , $query->sub_total, ($query->sub_total - $query->total_discount_amount));
        if($query->refund  == ($sell->total_before_tax - $query->total_discount_amount))
        {
            $query->is_all_refund = 1;
        }

        $payment_types = $this->transactionUtil->payment_types($sell->location_id, true);
        $order_taxes = [];
        if (!empty($sell->tax)) {
            if ($sell->tax->is_tax_group) {
                $order_taxes = $this->transactionUtil->sumGroupTaxDetails($this->transactionUtil->groupTaxDetails($sell->tax, $sell->tax_amount));
            } else {
                $order_taxes[$sell->tax->name] = $sell->tax_amount;
            }
        }

        $business_details = $this->businessUtil->getDetails($business_id);
        $pos_settings = empty($business_details->pos_settings) ? $this->businessUtil->defaultPosSettings() : json_decode($business_details->pos_settings, true);
        $shipping_statuses = $this->transactionUtil->shipping_statuses();
        $shipping_status_colors = $this->shipping_status_colors;
        $common_settings = session()->get('business.common_settings');
        $is_warranty_enabled = !empty($common_settings['enable_product_warranty']) ? true : false;

        $statuses = Transaction::sell_statuses();

        if ($sell->type == 'sales_order') {
            $sales_order_statuses = Transaction::sales_order_statuses(true);
            $statuses = array_merge($statuses, $sales_order_statuses);
        }
        $status_color_in_activity = Transaction::sales_order_statuses();
        $sales_orders = $sell->salesOrders();

        return view('sale_pos.show')
            ->with(compact(
                'taxes',
                'sell',
                'query',
                'service_charge',
                'payment_types',
                'order_taxes',
                'pos_settings',
                'shipping_statuses',
                'shipping_status_colors',
                'is_warranty_enabled',
                'activities',
                'statuses', 
                'status_color_in_activity',
                'sales_orders'
            ));
    }

    //  public function calculateServiceCharges($row) {
    //     $service_charge = 0;
    //         $final_takeaway_calculation = $row->takeaway_items_calculation;
    //       //  dd($row->discount_type, $row->total_discount_amount , $row->total_without_individual_discount_items , $row->discount_amount, $row->total_without_discount_items, $row->total_sum_line_discount_amount );
    //         if($row->discount_type == 'percentage' && $row->total_discount_amount > 0){
    //             $discount_amount = $row->total_without_individual_discount_items * $row->discount_amount;
    //             $amt_after_cart_disc = ($discount_amount/$row->total_without_individual_discount_items) * $row->total_without_discount_items;
    //             $amt_after_cart_disc = is_nan($amt_after_cart_disc)? 0 :  $amt_after_cart_disc ;
    //             $amt_after_individual_disc = $row->total_with_individual_discount_items - $row->total_sum_line_discount_amount;
    //             $amt_after_discount_percent = ($row->total_without_discount_items - $amt_after_cart_disc);
    //             $final_total = $amt_after_discount_percent + $amt_after_individual_disc;
    //             if($row->rp_redeemed > 0 ){
    //                 $service_charge = ($final_total - $row->rp_redeemed) * $row->service_charges;    
    //             }
    //             else{
    //                 $service_charge = $final_total * $row->service_charges;
    //             }
    //         }
    //         elseif($row->discount_type == 'fixed' && $row->total_discount_amount > 0){
    //             if($row->total_sum_line_discount_amount > 0 || $row->total_sum_line_tag_discount_amount > 0) {
    //                 $amt_after_cart_disc = ($row->cart_discount_amount/$row->total_without_individual_discount_items) * $row->total_without_discount_items;
    //                 $amt_after_cart_disc = is_nan($amt_after_cart_disc)? 0 :  $amt_after_cart_disc ;
    //                 $amt_after_individual_disc = $row->total_with_individual_discount_items - $row->total_sum_line_discount_amount;
    //                 $amt_after_discount_percent = ($row->total_without_discount_items - $amt_after_cart_disc);
    //                 $final_total = $amt_after_discount_percent + $amt_after_individual_disc;

    //                 if($row->rp_redeemed > 0 ){
    //                 $service_charge = ($final_total - $row->rp_redeemed) * $row->service_charges;    
    //                 }
    //                 else{
    //                     $service_charge = $final_total * $row->service_charges;
    //                 }
    //             } else {
    //                 $amt_after_cart_disc = ($row->cart_discount_amount/$row->total_without_individual_discount_items) * $row->total_without_discount_items;
    //                 $amt_after_individual_disc = $row->total_with_individual_discount_items - $row->total_sum_line_discount_amount;
    //                 $amt_after_discount_percent = ($row->total_without_discount_items - $amt_after_cart_disc);
    //                 $final_total = $amt_after_discount_percent + $amt_after_individual_disc;
    //                 if($row->rp_redeemed > 0 ){
    //                      $service_charge = ($final_total - $row->rp_redeemed) * $row->service_charges;    
    //                 }
    //                 else{
    //                     $service_charge = $final_total * $row->service_charges;
    //                 }
    //             }

    //         } 
    //         else {
    //             if($row->rp_redeemed > 0 ){
    //                 // $service_charge = ($final_total - $row->rp_redeemed) * $row->service_charges;    
    //                 $service_charge = ($row->total_before_tax - $row->refund_total_before_tax - $row->takeaway_items_calculation - $row->rp_redeemed) * $row->service_charges;
    //             }
    //             else{
    //                $service_charge = ($row->total_before_tax - $row->refund_total_before_tax - $row->takeaway_items_calculation) * $row->service_charges;
    //             }
                
    //         }

    //         return $service_charge;
    // }
    public function calculateServiceCharges($row) {
        $service_charge = 0;
            $final_takeaway_calculation = $row->takeaway_items_calculation;
          //  dd($row->discount_type, $row->total_discount_amount , $row->total_without_individual_discount_items , $row->discount_amount, $row->total_without_discount_items, $row->total_sum_line_discount_amount );
            if($row->discount_type == 'percentage' && $row->total_discount_amount > 0){
                $discount_amount = $row->total_without_individual_discount_items * $row->discount_amount;
                $amt_after_cart_disc = ($discount_amount/$row->total_without_individual_discount_items) * $row->total_without_discount_items;
                $amt_after_cart_disc = is_nan($amt_after_cart_disc)? 0 :  $amt_after_cart_disc ;
                $amt_after_individual_disc = $row->total_with_individual_discount_items - $row->total_sum_line_discount_amount;
                $amt_after_discount_percent = ($row->total_without_discount_items - $amt_after_cart_disc);
                $final_total = $amt_after_discount_percent + $amt_after_individual_disc - ($row->rp_redeemed - $row->refund_rp_redeemed_amount);
                $service_charge = $final_total * $row->service_charges;
            }
            elseif($row->discount_type == 'fixed' && $row->total_discount_amount > 0){
                if($row->total_sum_line_discount_amount > 0 || $row->total_sum_line_tag_discount_amount > 0) {
                    $amt_after_cart_disc = ($row->cart_discount_amount/$row->total_without_individual_discount_items) * $row->total_without_discount_items;
                    $amt_after_cart_disc = is_nan($amt_after_cart_disc)? 0 :  $amt_after_cart_disc ;
                    $amt_after_individual_disc = $row->total_with_individual_discount_items - $row->total_sum_line_discount_amount;
                    $amt_after_discount_percent = ($row->total_without_discount_items - $amt_after_cart_disc);
                    $final_total = $amt_after_discount_percent + $amt_after_individual_disc - ($row->rp_redeemed - $row->refund_rp_redeemed_amount);
                    $service_charge = $final_total * $row->service_charges;
                } else {

                    $amt_after_cart_disc = ($row->cart_discount_amount/$row->total_without_individual_discount_items) * $row->total_without_discount_items;
                    $amt_after_individual_disc = $row->total_with_individual_discount_items - $row->total_sum_line_discount_amount;
                    $amt_after_discount_percent = ($row->total_without_discount_items - $amt_after_cart_disc);
                    $final_total = $amt_after_discount_percent + $amt_after_individual_disc - ($row->rp_redeemed - $row->refund_rp_redeemed_amount);
                    $service_charge = $final_total * $row->service_charges; 
                }

            } 
            else {

                $service_charge = ($row->total_before_tax - ($row->rp_redeemed - $row->refund_rp_redeemed_amount) - $row->refund_total_before_tax - $row->takeaway_items_calculation) * $row->service_charges;
                // dd($row->total_before_tax , $row->rp_redeemed , $row->refund_rp_redeemed_amount, $row->refund_total_before_tax , $row->takeaway_items_calculation, $row->service_charges);
            }

            if(is_nan($service_charge)){
                $service_charge = 0;
            }

            return $service_charge;
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        if (!auth()->user()->can('direct_sell.update')) {
            abort(403, 'Unauthorized action.');
        }

        //Check if the transaction can be edited or not.
        $edit_days = request()->session()->get('business.transaction_edit_days');
        if (!$this->transactionUtil->canBeEdited($id, $edit_days)) {
            return back()
                ->with('status', ['success' => 0,
                    'msg' => __('messages.transaction_edit_not_allowed', ['days' => $edit_days])]);
        }

        //Check if return exist then not allowed
        if ($this->transactionUtil->isReturnExist($id)) {
            return back()->with('status', ['success' => 0,
                    'msg' => __('lang_v1.return_exist')]);
        }
        
        $business_id = request()->session()->get('user.business_id');
        
        $business_details = $this->businessUtil->getDetails($business_id);
        $taxes = TaxRate::forBusinessDropdown($business_id, true, true);

        $transaction = Transaction::where('business_id', $business_id)
                            ->with(['price_group', 'types_of_service', 'media', 'media.uploaded_by_user'])
                            ->whereIn('type', ['sell', 'sales_order'])
                            ->findorfail($id);

        if ($transaction->type == 'sales_order' && !auth()->user()->can('so.update')) {
            abort(403, 'Unauthorized action.');
        }

        $location_id = $transaction->location_id;
        $location_printer_type = BusinessLocation::find($location_id)->receipt_printer_type;

        $sell_details = TransactionSellLine::
                        join(
                            'products AS p',
                            'transaction_sell_lines.product_id',
                            '=',
                            'p.id'
                        )
                        ->join(
                            'variations AS variations',
                            'transaction_sell_lines.variation_id',
                            '=',
                            'variations.id'
                        )
                        ->join(
                            'product_variations AS pv',
                            'variations.product_variation_id',
                            '=',
                            'pv.id'
                        )
                        ->leftjoin('variation_location_details AS vld', function ($join) use ($location_id) {
                            $join->on('variations.id', '=', 'vld.variation_id')
                                ->where('vld.location_id', '=', $location_id);
                        })
                        ->leftjoin('units', 'units.id', '=', 'p.unit_id')
                        ->where('transaction_sell_lines.transaction_id', $id)
                        ->with(['warranties', 'so_line'])
                        ->select(
                            DB::raw("IF(pv.is_dummy = 0, CONCAT(p.name, ' (', pv.name, ':',variations.name, ')'), p.name) AS product_name"),
                            'p.id as product_id',
                            'p.enable_stock',
                            'p.name as product_actual_name',
                            'p.type as product_type',
                            'pv.name as product_variation_name',
                            'pv.is_dummy as is_dummy',
                            'variations.name as variation_name',
                            'variations.sub_sku',
                            'p.barcode_type',
                            'p.enable_sr_no',
                            'variations.id as variation_id',
                            'units.short_name as unit',
                            'units.allow_decimal as unit_allow_decimal',
                            'transaction_sell_lines.tax_id as tax_id',
                            'transaction_sell_lines.item_tax as item_tax',
                            'transaction_sell_lines.unit_price as default_sell_price',
                            'transaction_sell_lines.unit_price_inc_tax as sell_price_inc_tax',
                            'transaction_sell_lines.unit_price_before_discount as unit_price_before_discount',
                            'transaction_sell_lines.id as transaction_sell_lines_id',
                            'transaction_sell_lines.id',
                            'transaction_sell_lines.quantity as quantity_ordered',
                            'transaction_sell_lines.sell_line_note as sell_line_note',
                            'transaction_sell_lines.parent_sell_line_id',
                            'transaction_sell_lines.lot_no_line_id',
                            'transaction_sell_lines.line_discount_type',
                            'transaction_sell_lines.line_discount_amount',
                            'transaction_sell_lines.res_service_staff_id',
                            'units.id as unit_id',
                            'transaction_sell_lines.sub_unit_id',
                            'transaction_sell_lines.so_line_id',
                            DB::raw('vld.qty_available + transaction_sell_lines.quantity AS qty_available')
                        )
                        ->get();

        if (!empty($sell_details)) {
            foreach ($sell_details as $key => $value) {
                //If modifier or combo sell line then unset
                if (!empty($sell_details[$key]->parent_sell_line_id)) {
                    unset($sell_details[$key]);
                } else {
                    if ($transaction->status != 'final') {
                        $actual_qty_avlbl = $value->qty_available - $value->quantity_ordered;
                        $sell_details[$key]->qty_available = $actual_qty_avlbl;
                        $value->qty_available = $actual_qty_avlbl;
                    }
                        
                    $sell_details[$key]->formatted_qty_available = $this->productUtil->num_f($value->qty_available, false, null, true);
                    $lot_numbers = [];
                    if (request()->session()->get('business.enable_lot_number') == 1) {
                        $lot_number_obj = $this->transactionUtil->getLotNumbersFromVariation($value->variation_id, $business_id, $location_id);
                        foreach ($lot_number_obj as $lot_number) {
                            //If lot number is selected added ordered quantity to lot quantity available
                            if ($value->lot_no_line_id == $lot_number->purchase_line_id) {
                                $lot_number->qty_available += $value->quantity_ordered;
                            }

                            $lot_number->qty_formated = $this->transactionUtil->num_f($lot_number->qty_available);
                            $lot_numbers[] = $lot_number;
                        }
                    }
                    $sell_details[$key]->lot_numbers = $lot_numbers;

                    if (!empty($value->sub_unit_id)) {
                        $value = $this->productUtil->changeSellLineUnit($business_id, $value);
                        $sell_details[$key] = $value;
                    }

                    if ($this->transactionUtil->isModuleEnabled('modifiers')) {
                        //Add modifier details to sel line details
                        $sell_line_modifiers = TransactionSellLine::where('parent_sell_line_id', $sell_details[$key]->transaction_sell_lines_id)
                            ->where('children_type', 'modifier')
                            ->get();
                        $modifiers_ids = [];
                        if (count($sell_line_modifiers) > 0) {
                            $sell_details[$key]->modifiers = $sell_line_modifiers;
                            foreach ($sell_line_modifiers as $sell_line_modifier) {
                                $modifiers_ids[] = $sell_line_modifier->variation_id;
                            }
                        }
                        $sell_details[$key]->modifiers_ids = $modifiers_ids;

                        //add product modifier sets for edit
                        $this_product = Product::find($sell_details[$key]->product_id);
                        if (count($this_product->modifier_sets) > 0) {
                            $sell_details[$key]->product_ms = $this_product->modifier_sets;
                        }
                    }

                    //Get details of combo items
                    if ($sell_details[$key]->product_type == 'combo') {
                        $sell_line_combos = TransactionSellLine::where('parent_sell_line_id', $sell_details[$key]->transaction_sell_lines_id)
                            ->where('children_type', 'combo')
                            ->get()
                            ->toArray();
                        if (!empty($sell_line_combos)) {
                            $sell_details[$key]->combo_products = $sell_line_combos;
                        }

                        //calculate quantity available if combo product
                        $combo_variations = [];
                        foreach ($sell_line_combos as $combo_line) {
                            $combo_variations[] = [
                                'variation_id' => $combo_line['variation_id'],
                                'quantity' => $combo_line['quantity'] / $sell_details[$key]->quantity_ordered,
                                'unit_id' => null
                            ];
                        }
                        $sell_details[$key]->qty_available =
                        $this->productUtil->calculateComboQuantity($location_id, $combo_variations);
                        
                        if ($transaction->status == 'final') {
                            $sell_details[$key]->qty_available = $sell_details[$key]->qty_available + $sell_details[$key]->quantity_ordered;
                        }
                        
                        $sell_details[$key]->formatted_qty_available = $this->productUtil->num_f($sell_details[$key]->qty_available, false, null, true);
                    }
                }
            }
        }

        $commsn_agnt_setting = $business_details->sales_cmsn_agnt;
        $commission_agent = [];
        if ($commsn_agnt_setting == 'user') {
            $commission_agent = User::forDropdown($business_id);
        } elseif ($commsn_agnt_setting == 'cmsn_agnt') {
            $commission_agent = User::saleCommissionAgentsDropdown($business_id);
        }

        $types = [];
        if (auth()->user()->can('supplier.create')) {
            $types['supplier'] = __('report.supplier');
        }
        if (auth()->user()->can('customer.create')) {
            $types['customer'] = __('report.customer');
        }
        if (auth()->user()->can('supplier.create') && auth()->user()->can('customer.create')) {
            $types['both'] = __('lang_v1.both_supplier_customer');
        }
        $customer_groups = CustomerGroup::forDropdown($business_id);

        $transaction->transaction_date = $this->transactionUtil->format_date($transaction->transaction_date, true);

        $pos_settings = empty($business_details->pos_settings) ? $this->businessUtil->defaultPosSettings() : json_decode($business_details->pos_settings, true);

        $waiters = [];
        if ($this->productUtil->isModuleEnabled('service_staff') && !empty($pos_settings['inline_service_staff'])) {
            $waiters = $this->productUtil->serviceStaffDropdown($business_id);
        }

        $invoice_schemes = [];
        $default_invoice_schemes = null;

        if ($transaction->status == 'draft') {
            $invoice_schemes = InvoiceScheme::forDropdown($business_id);
            $default_invoice_schemes = InvoiceScheme::getDefault($business_id);
        }

        $redeem_details = [];
        if (request()->session()->get('business.enable_rp') == 1) {
            $redeem_details = $this->transactionUtil->getRewardRedeemDetails($business_id, $transaction->contact_id);

            $redeem_details['points'] += $transaction->rp_redeemed;
            $redeem_details['points'] -= $transaction->rp_earned;
        }

        $edit_discount = auth()->user()->can('edit_product_discount_from_sale_screen');
        $edit_price = auth()->user()->can('edit_product_price_from_sale_screen');

        //Accounts
        $accounts = [];
        if ($this->moduleUtil->isModuleEnabled('account')) {
            $accounts = Account::forDropdown($business_id, true, false);
        }

        $shipping_statuses = $this->transactionUtil->shipping_statuses();

        $common_settings = session()->get('business.common_settings');
        $is_warranty_enabled = !empty($common_settings['enable_product_warranty']) ? true : false;
        $warranties = $is_warranty_enabled ? Warranty::forDropdown($business_id) : [];
        
        $statuses = Transaction::sell_statuses();

        $sales_orders = [];
        if(!empty($pos_settings['enable_sales_order'])) {
            $sales_orders = Transaction::where('business_id', $business_id)
                                ->where('type', 'sales_order')
                                ->where('contact_id', $transaction->contact_id)
                                ->where( function($q) use($transaction){
                                    $q->where('status', '!=', 'completed');

                                    if (!empty($transaction->sales_order_ids)) {
                                        $q->orWhereIn('id', $transaction->sales_order_ids);
                                    }
                                })
                                ->pluck('invoice_no', 'id');
        }

        $payment_types = $this->transactionUtil->payment_types($transaction->location_id, false, $business_id);

        return view('sell.edit')
            ->with(compact('business_details', 'taxes', 'sell_details', 'transaction', 'commission_agent', 'types', 'customer_groups', 'pos_settings', 'waiters', 'invoice_schemes', 'default_invoice_schemes', 'redeem_details', 'edit_discount', 'edit_price', 'shipping_statuses', 'warranties', 'statuses', 'sales_orders', 'payment_types', 'accounts'));
    }

    /**
     * Display a listing sell drafts.
     *
     * @return \Illuminate\Http\Response
     */
    public function getDrafts()
    {
        if (!auth()->user()->can('list_drafts')) {
            abort(403, 'Unauthorized action.');
        }

        $business_id = request()->session()->get('user.business_id');

        $business_locations = BusinessLocation::forDropdown($business_id, false);
        $customers = Contact::customersDropdown($business_id, false);
      
        $sales_representative = User::forDropdown($business_id, false, false, true);
    

        return view('sale_pos.draft')
            ->with(compact('business_locations', 'customers', 'sales_representative'));
    }

    /**
     * Display a listing sell quotations.
     *
     * @return \Illuminate\Http\Response
     */
    public function getQuotations()
    {
        if (!auth()->user()->can('list_quotations')) {
            abort(403, 'Unauthorized action.');
        }

        $business_id = request()->session()->get('user.business_id');

        $business_locations = BusinessLocation::forDropdown($business_id, false);
        $customers = Contact::customersDropdown($business_id, false);
      
        $sales_representative = User::forDropdown($business_id, false, false, true);

        return view('sale_pos.quotations')
                ->with(compact('business_locations', 'customers', 'sales_representative'));
    }

    /**
     * Send the datatable response for draft or quotations.
     *
     * @return \Illuminate\Http\Response
     */
    public function getDraftDatables()
    {
        if (request()->ajax()) {
            $business_id = request()->session()->get('user.business_id');
            $is_quotation = request()->input('is_quotation', 0);

            $is_woocommerce = $this->moduleUtil->isModuleInstalled('Woocommerce');

            $sells = Transaction::leftJoin('contacts', 'transactions.contact_id', '=', 'contacts.id')
                ->leftJoin('users as u', 'transactions.created_by', '=', 'u.id')
                ->join(
                    'business_locations AS bl',
                    'transactions.location_id',
                    '=',
                    'bl.id'
                )
                ->leftJoin('transaction_sell_lines as tsl', function($join) {
                    $join->on('transactions.id', '=', 'tsl.transaction_id')
                        ->whereNull('tsl.parent_sell_line_id');
                })
                ->where('transactions.business_id', $business_id)
                ->where('transactions.type', 'sell')
                ->where('transactions.status', 'draft')
                ->select(
                    'transactions.id',
                    'transaction_date',
                    'invoice_no',
                    'contacts.name',
                    'contacts.mobile',
                    'contacts.supplier_business_name',
                    'bl.name as business_location',
                    'is_direct_sale',
                    'sub_status',
                    DB::raw('COUNT( DISTINCT tsl.id) as total_items'),
                    DB::raw('SUM(tsl.quantity) as total_quantity'),
                    DB::raw("CONCAT(COALESCE(u.surname, ''), ' ', COALESCE(u.first_name, ''), ' ', COALESCE(u.last_name, '')) as added_by"),
                    'transactions.is_export'
                );
                
            if ($is_quotation == 1) {
                $sells->where('transactions.sub_status', 'quotation');
            }
            $permitted_locations = auth()->user()->permitted_locations();
            if ($permitted_locations != 'all') {
                $sells->whereIn('transactions.location_id', $permitted_locations);
            }
                
            if (!empty(request()->start_date) && !empty(request()->end_date)) {
                $start = request()->start_date;
                $end =  request()->end_date;
                $sells->whereDate('transaction_date', '>=', $start)
                            ->whereDate('transaction_date', '<=', $end);
            }

            if (request()->has('location_id')) {
                $location_id = request()->get('location_id');
                if (!empty($location_id)) {
                    $sells->where('transactions.location_id', $location_id);
                }
            }

            if (request()->has('created_by')) {
                $created_by = request()->get('created_by');
                if (!empty($created_by)) {
                    $sells->where('transactions.created_by', $created_by);
                }
            }

            if (!empty(request()->customer_id)) {
                $customer_id = request()->customer_id;
                $sells->where('contacts.id', $customer_id);
            }

            if ($is_woocommerce) {
                $sells->addSelect('transactions.woocommerce_order_id');
            }

            $sells->groupBy('transactions.id');

            return Datatables::of($sells)
                 ->addColumn(
                    'action', function ($row) {
                        $html = '<div class="btn-group">
                                <button type="button" class="btn btn-info dropdown-toggle btn-xs" 
                                    data-toggle="dropdown" aria-expanded="false">' .
                                    __("messages.actions") .
                                    '<span class="caret"></span><span class="sr-only">Toggle Dropdown
                                    </span>
                                </button>
                                <ul class="dropdown-menu dropdown-menu-right" role="menu">
                                    <li>
                                    <a href="#" data-href="'.action('SellController@show', [$row->id]).'" class="btn-modal" data-container=".view_modal">
                                        <i class="fas fa-eye" aria-hidden="true"></i>'.__("messages.view").'
                                    </a>
                                    </li>' ;

                        if($row->is_direct_sale == 1) {
                            $html .= '<li>
                                        <a target="_blank" href="'.action('SellController@edit', [$row->id]).'">
                                            <i class="fas fa-edit"></i>' .__("messages.edit").'
                                        </a>
                                    </li>';
                        } else {
                            $html .= '<li>
                                        <a target="_blank" href="'.action('SellPosController@edit', [$row->id]).'">
                                            <i class="fas fa-edit"></i>'.  __("messages.edit").'
                                        </a>
                                    </li>';
                        }

                        $html .= '<li>
                                    <a href="#" class="print-invoice" data-href="'.route('sell.printInvoice', [$row->id]).'"><i class="fas fa-print" aria-hidden="true"></i>'. __("messages.print").'</a>
                                </li>';


                        if(config("constants.enable_download_pdf")) {
                            $sub_status = $row->sub_status == 'proforma' ? 'proforma' : '';
                            $html .= '<li>
                                        <a href="'.route('quotation.downloadPdf', ['id' => $row->id, 'sub_status' => $sub_status]).'" target="_blank">
                                            <i class="fas fa-print" aria-hidden="true"></i>'.__("lang_v1.download_pdf"). '
                                        </a>
                                    </li>';
                        }

                        if( (auth()->user()->can("sell.create") || auth()->user()->can("direct_sell.access")) && config("constants.enable_convert_draft_to_invoice")) {
                            $html .= '<li>
                                        <a href="'.action('SellPosController@convertToInvoice', [$row->id]).'" class="convert-draft"><i class="fas fa-sync-alt"></i>'.__("lang_v1.convert_to_invoice").'</a>
                                    </li>';
                        }

                        if($row->sub_status != "proforma") {
                            $html .= '<li>
                                        <a href="'.action('SellPosController@convertToProforma', [$row->id]).'" class="convert-to-proforma"><i class="fas fa-sync-alt"></i>'.__("lang_v1.convert_to_proforma").'</a>
                                    </li>';
                        }

                        $html .= '<li>
                                <a href="'.action('SellPosController@destroy', [$row->id]).'" class="delete-sale"><i class="fas fa-trash"></i>'.__("messages.delete").'</a>
                                </li>';

                        if($row->sub_status == "quotation") {
                            $html .= '<li>
                                        <a href="'.action("SellPosController@showInvoiceUrl", [$row->id]).'" class="view_invoice_url"><i class="fas fa-eye"></i>'.__("lang_v1.view_quote_url").'</a>
                                    </li>
                                    <li>
                                        <a href="#" data-href="'.action("NotificationController@getTemplate", ["transaction_id" => $row->id,"template_for" => "new_quotation"]).'" class="btn-modal" data-container=".view_modal"><i class="fa fa-envelope" aria-hidden="true"></i>' . __("lang_v1.new_quotation_notification") . '
                                        </a>
                                    </li>';
                        }

                        $html .= '</ul></div>';

                        return $html;

                })
                ->removeColumn('id')
                ->editColumn('invoice_no', function ($row) {
                    $invoice_no = $row->invoice_no;
                    if (!empty($row->woocommerce_order_id)) {
                        $invoice_no .= ' <i class="fab fa-wordpress text-primary no-print" title="' . __('lang_v1.synced_from_woocommerce') . '"></i>';
                    }

                    if ($row->sub_status == 'proforma') {
                        $invoice_no .= '<br><span class="label bg-gray">' . __('lang_v1.proforma_invoice') . '</span>';
                    }

                    if (!empty($row->is_export)) {
                        $invoice_no .= '</br><small class="label label-default no-print" title="' . __('lang_v1.export') .'">'.__('lang_v1.export').'</small>';
                    }
                    
                    return $invoice_no;
                })
                ->editColumn('transaction_date', '{{@format_date($transaction_date)}}')
                ->editColumn('total_items', '{{@format_quantity($total_items)}}')
                ->editColumn('total_quantity', '{{@format_quantity($total_quantity)}}')
                ->addColumn('conatct_name', '@if(!empty($supplier_business_name)) {{$supplier_business_name}}, <br>@endif {{$name}}')
                ->filterColumn('conatct_name', function ($query, $keyword) {
                    $query->where( function($q) use($keyword) {
                        $q->where('contacts.name', 'like', "%{$keyword}%")
                        ->orWhere('contacts.supplier_business_name', 'like', "%{$keyword}%");
                    });
                })
                ->filterColumn('added_by', function ($query, $keyword) {
                    $query->whereRaw("CONCAT(COALESCE(u.surname, ''), ' ', COALESCE(u.first_name, ''), ' ', COALESCE(u.last_name, '')) like ?", ["%{$keyword}%"]);
                })
                ->setRowAttr([
                    'data-href' => function ($row) {
                        if (auth()->user()->can("sell.view")) {
                            return  action('SellController@show', [$row->id]) ;
                        } else {
                            return '';
                        }
                    }])
                ->rawColumns(['action', 'invoice_no', 'transaction_date', 'conatct_name'])
                ->make(true);
        }
    }

    /**
     * Creates copy of the requested sale.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function duplicateSell($id)
    {
        if (!auth()->user()->can('sell.create')) {
            abort(403, 'Unauthorized action.');
        }

        try {
            $business_id = request()->session()->get('user.business_id');
            $user_id = request()->session()->get('user.id');

            $transaction = Transaction::where('business_id', $business_id)
                            ->where('type', 'sell')
                            ->findorfail($id);
            $duplicate_transaction_data = [];
            foreach ($transaction->toArray() as $key => $value) {
                if (!in_array($key, ['id', 'created_at', 'updated_at'])) {
                    $duplicate_transaction_data[$key] = $value;
                }
            }
            $duplicate_transaction_data['status'] = 'draft';
            $duplicate_transaction_data['payment_status'] = null;
            $duplicate_transaction_data['transaction_date'] =  \Carbon::now();
            $duplicate_transaction_data['created_by'] = $user_id;
            $duplicate_transaction_data['invoice_token'] = null;

            DB::beginTransaction();
            $duplicate_transaction_data['invoice_no'] = $this->transactionUtil->getInvoiceNumber($business_id, 'draft', $duplicate_transaction_data['location_id']);

            //Create duplicate transaction
            $duplicate_transaction = Transaction::create($duplicate_transaction_data);

            //Create duplicate transaction sell lines
            $duplicate_sell_lines_data = [];

            foreach ($transaction->sell_lines as $sell_line) {
                $new_sell_line = [];
                foreach ($sell_line->toArray() as $key => $value) {
                    if (!in_array($key, ['id', 'transaction_id', 'created_at', 'updated_at', 'lot_no_line_id'])) {
                        $new_sell_line[$key] = $value;
                    }
                }

                $duplicate_sell_lines_data[] = $new_sell_line;
            }

            $duplicate_transaction->sell_lines()->createMany($duplicate_sell_lines_data);

            DB::commit();

            $output = ['success' => 0,
                            'msg' => trans("lang_v1.duplicate_sell_created_successfully")
                        ];
        } catch (\Exception $e) {
            DB::rollBack();
            \Log::emergency("File:" . $e->getFile(). "Line:" . $e->getLine(). "Message:" . $e->getMessage());
            
            $output = ['success' => 0,
                            'msg' => trans("messages.something_went_wrong")
                        ];
        }

        if (!empty($duplicate_transaction)) {
            if ($duplicate_transaction->is_direct_sale == 1) {
                return redirect()->action('SellController@edit', [$duplicate_transaction->id])->with(['status', $output]);
            } else {
                return redirect()->action('SellPosController@edit', [$duplicate_transaction->id])->with(['status', $output]);
            }
        } else {
            abort(404, 'Not Found.');
        }
    }

    /**
     * Shows modal to edit shipping details.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function editShipping($id)
    {
        $is_admin = $this->businessUtil->is_admin(auth()->user());

        if ( !$is_admin && !auth()->user()->hasAnyPermission(['access_shipping', 'access_own_shipping', 'access_commission_agent_shipping']) ) {
            abort(403, 'Unauthorized action.');
        }

        $business_id = request()->session()->get('user.business_id');

        $transaction = Transaction::where('business_id', $business_id)
                                ->with(['media', 'media.uploaded_by_user'])
                                ->findorfail($id);
        $shipping_statuses = $this->transactionUtil->shipping_statuses();

        $activities = Activity::forSubject($transaction)
           ->with(['causer', 'subject'])
           ->where('activity_log.description', 'shipping_edited')
           ->latest()
           ->get();

        return view('sell.partials.edit_shipping')
               ->with(compact('transaction', 'shipping_statuses', 'activities'));
    }

    /**
     * Update shipping.
     *
     * @param  Request $request, int  $id
     * @return \Illuminate\Http\Response
     */
    public function updateShipping(Request $request, $id)
    {
        $is_admin = $this->businessUtil->is_admin(auth()->user());

        if ( !$is_admin && !auth()->user()->hasAnyPermission(['access_shipping', 'access_own_shipping', 'access_commission_agent_shipping']) ) {
            abort(403, 'Unauthorized action.');
        }

        try {
            $input = $request->only([
                    'shipping_details', 'shipping_address',
                    'shipping_status', 'delivered_to', 'shipping_custom_field_1', 'shipping_custom_field_2', 'shipping_custom_field_3', 'shipping_custom_field_4', 'shipping_custom_field_5'
                ]);
            $business_id = $request->session()->get('user.business_id');

            
            $transaction = Transaction::where('business_id', $business_id)
                                ->findOrFail($id);

            $transaction_before = $transaction->replicate();

            $transaction->update($input);

            $activity_property = ['update_note' => $request->input('shipping_note', '')];
            $this->transactionUtil->activityLog($transaction, 'shipping_edited', $transaction_before, $activity_property);

            $output = ['success' => 1,
                            'msg' => trans("lang_v1.updated_success")
                        ];
        } catch (\Exception $e) {
            \Log::emergency("File:" . $e->getFile(). "Line:" . $e->getLine(). "Message:" . $e->getMessage());
            
            $output = ['success' => 0,
                            'msg' => trans("messages.something_went_wrong")
                        ];
        }

        return $output;
    }

    /**
     * Display list of shipments.
     *
     * @return \Illuminate\Http\Response
     */
    public function shipments()
    {
        $is_admin = $this->businessUtil->is_admin(auth()->user());

        if ( !$is_admin && !auth()->user()->hasAnyPermission(['access_shipping', 'access_own_shipping', 'access_commission_agent_shipping']) ) {
            abort(403, 'Unauthorized action.');
        }

        $shipping_statuses = $this->transactionUtil->shipping_statuses();

        $business_id = request()->session()->get('user.business_id');

        $business_locations = BusinessLocation::forDropdown($business_id, false);
        $customers = Contact::customersDropdown($business_id, false);
      
        $sales_representative = User::forDropdown($business_id, false, false, true);

        $is_service_staff_enabled = $this->transactionUtil->isModuleEnabled('service_staff');

        //Service staff filter
        $service_staffs = null;
        if ($this->productUtil->isModuleEnabled('service_staff')) {
            $service_staffs = $this->productUtil->serviceStaffDropdown($business_id);
        }

        return view('sell.shipments')->with(compact('shipping_statuses'))
                ->with(compact('business_locations', 'customers', 'sales_representative', 'is_service_staff_enabled', 'service_staffs'));
    }

    public function viewMedia($model_id)
    {
        if (request()->ajax()) {
            $model_type = request()->input('model_type');
            $business_id = request()->session()->get('user.business_id');

            $query = Media::where('business_id', $business_id)
                        ->where('model_id', $model_id)
                        ->where('model_type', $model_type);

            $title = __('lang_v1.attachments');
            if (!empty(request()->input('model_media_type'))) {
                $query->where('model_media_type', request()->input('model_media_type'));
                $title = __('lang_v1.shipping_documents');
            }

            $medias = $query->get();

            return view('sell.view_media')->with(compact('medias', 'title'));
        }
    }

    public function generateTxtReceipt(Request $request)
    {
        $input = $request->only([
            'business_location_id', 'date_range'
        ]);

        if(!empty($input['business_location_id']))
        {
            $zip = new \ZipArchive();
            $array_filter_date = explode(" - ",$input['date_range']);
            $location_details = BusinessLocation::find($input['business_location_id']);

            $date_receipt_name = \Carbon::parse($array_filter_date[0])->format('Ymd');
            $generate_time_receipt_name = \Carbon::now()->format('His');
            $all_transaction = "";

            $user_id = "";
            $business_id = $location_details->business_id;
            $location_id = $input['business_location_id'];
            $transaction_status = "final";
            $created_at = \Carbon::parse($array_filter_date[0])->format('Y-m-d 00:00:00');
            $type = "";
            $txt = true;

            $all_sale_history = $this->transactionUtil->get_sale_history($user_id, $business_id, $location_id, $transaction_status, $created_at, $type, null, null, $txt);
            $all_sale_return_history = $this->transactionUtil->get_sale_returns($business_id, $location_id, $transaction_status, $created_at, $type, null, null, $txt);
            //return $all_sale_history;
            
            $business_tax_rates = TaxRate::where('business_id', $business_id)
                            ->get()
                            ->toArray();
            if($location_details->outlet_location_id == 0)
            {
                $searchString = 'OrchardGateway';
            }
            else if($location_details->outlet_location_id == 1)
            {
                $searchString = 'Vivocity';
            }
            else if($location_details->outlet_location_id == 2)
            {
                $searchString = 'ThomsonPlaza';
            }
            else if($location_details->outlet_location_id == 3)
            {
                $searchString = 'HillonMall';
            }
            else if($location_details->outlet_location_id == 4)
            {
                $searchString = 'SingPostCentre';
            }
            
            //---------------OrchardGateway------------------------
            if($searchString == 'OrchardGateway')
            {
                $mainFolderExist = false;
                //search folder
                $directories = Storage::disk('local')->allDirectories('txt_invoice');
                if(count($directories) > 0) 
                {
                    foreach($directories as $directoryString)
                    {
                        if(strpos($directoryString, $searchString) !== false) 
                        {
                            $mainFolderExist = true;
                            break;
                        }
                    }

                    if($mainFolderExist)
                    {
                        Storage::disk('local')->makeDirectory('txt_invoice/OrchardGateway');
                    }
                } 
                else 
                {
                    Storage::disk('local')->makeDirectory('txt_invoice/OrchardGateway');
                }

                $machineString = $location_details->machine_id; // Need to change
                $subFolderExist = false;
                $orchardDirectories = Storage::disk('local')->allDirectories('txt_invoice/OrchardGateway');
                $subDirectory = 'txt_invoice/'.$searchString.'/'.$machineString;

                if(count($orchardDirectories) > 0) 
                {
                    foreach($orchardDirectories as $directoryString)
                    {
                        if(strpos($directoryString, $machineString) !== false) 
                        {
                            $subFolderExist = true;
                            break;
                        }
                    }

                    if($subFolderExist)
                    {
                        Storage::disk('local')->makeDirectory($subDirectory);
                    }
                } 
                else 
                {
                    Storage::disk('local')->makeDirectory($subDirectory);
                }

                $file_name = $machineString.'_'.$date_receipt_name.'_'.$generate_time_receipt_name.'.txt';
                $allFiles = Storage::disk('local')->allFiles($subDirectory);
                $batch_id = count($allFiles) + 1;
                $line = "";
                foreach ($allFiles as $file) {
                    if (strpos($file, $date_receipt_name) !== false)
                    {
                        $line = fgets(fopen( public_path('/uploads/'.$file), 'r')); ///public
                        if(!empty($line))
                        {
                            $array_filter_first_line = explode("|",$line);
                            $batch_id = $array_filter_first_line[2];
                        }
                        break;
                    }
                }

                $sales = $all_sale_history['sells'];

                $filePart = 'uploads/txt_invoice/'.$searchString.'/'.$machineString.'/';

                if(count($sales) > 0)
                {
                    //Shop has sales
                    $total_lines = 24;

                    for($a = 0; $a < $total_lines; $a++)
                    {
                        $transaction_hours = "";
                        $total_receipt_no = 0;
                        $total_gto = 0;
                        $total_gst = 0;
                        $total_discount = 0;
                        $total_pax = 0;

                        foreach($sales as $sale)
                        {
                            $transaction_date = \Carbon::parse($sale['transaction_date'])->format('dmY');
                            $transaction_time = \Carbon::parse($sale['transaction_date'])->format('Hi');
                            // $receipt_no = $sale['invoice_no'];
                            $gto = $sale['total'] - $sale['tax_amount'];
                            $gst = $sale['tax_amount'];
                            $discount = $sale['discount_amount'];
                            $pax = !empty($sale['pax']) ? (integer)$sale['pax'] : 0;

                            $first_two_char = substr($transaction_time, 0, 2);

                            if(strlen($a) == 1)
                            {
                                $string = '0'.$a;
                                $transaction_hours = $string.'59';

                                if($first_two_char == $string) 
                                {
                                    $total_receipt_no = $total_receipt_no + 1;
                                    $total_gto = $total_gto + $gto;
                                    $total_gst = $total_gst + $gst;
                                    $total_discount = $total_discount + $discount;
                                    $total_pax = $total_pax + $pax;
                                }
                            }
                            else if(strlen($a) == 2)
                            {
                                $string = $a;
                                $transaction_hours = $string.'59';

                                if($first_two_char == $string) 
                                {
                                    $total_receipt_no = $total_receipt_no + 1;
                                    $total_gto = $total_gto + $gto;
                                    $total_gst = $total_gst + $gst;
                                    $total_discount = $total_discount + $discount;
                                    $total_pax = $total_pax + $pax;
                                }
                            }

                            if(!empty($sale['return_parent']))
                            {
                                $return_transaction_date = \Carbon::parse($sale['return_parent']->transaction_date)->format('dmY');
                                $return_transaction_time = \Carbon::parse($sale['return_parent']->transaction_date)->format('Hi');

                                $return_gto = $sale['refund_final_total_without_discount_and_gst'];
                                $return_gst = $sale['refund_tax_amount'];
                                $return_discount = $sale['refund_discount_amount'];
                                $return_pax = 0;

                                $return_first_two_char = substr($return_transaction_time, 0, 2);

                                if(strlen($a) == 1)
                                {
                                    $return_string = '0'.$a;
                                    $return_transaction_hours = $return_string.'59';

                                    if($return_first_two_char == $return_string) 
                                    {
                                        //$total_receipt_no = $total_receipt_no + 1;
                                        $total_gto = $total_gto - $return_gto;
                                        $total_gst = $total_gst - $return_gst;
                                        $total_discount = $total_discount - $return_discount;
                                    }
                                }
                                else if(strlen($a) == 2)
                                {
                                    $return_string = $a;
                                    $return_transaction_hours = $return_string.'59';

                                    if($return_first_two_char == $return_string) 
                                    {
                                        //$total_receipt_no = $total_receipt_no + 1;
                                        $total_gto = $total_gto - $return_gto;
                                        $total_gst = $total_gst - $return_gst;
                                        $total_discount = $total_discount - $return_discount;
                                    }
                                }
                            }
                        }
                        $all_transaction = $all_transaction.$machineString.'|'.$transaction_date.'|'.$batch_id.'|'.$transaction_hours.'|'.$total_receipt_no.'|'.number_format((float)$total_gto, 2).'|'.number_format((float)$total_gst, 2).'|'.number_format((float)$total_discount, 2).'|'.$total_pax."\n";
                    }

                    Storage::disk('local')->put($subDirectory.'/'.$file_name, $all_transaction);
                }
                else
                {
                    //0 sales
                    Storage::disk('local')->put($subDirectory.'/'.$file_name, "0 sales");
                }

                if (true === ($zip->open(public_path($filePart.$generate_time_receipt_name.'-txt_invoice.zip'), ZipArchive::CREATE | ZipArchive::OVERWRITE))) {
                    //foreach (Storage::allFiles('public') as $file) {
                        $name = basename('/txt_invoice/'.$searchString.'/'.$machineString.'/'.$file_name);
                        //if ($name !== '.gitignore') {
                            $zip->addFile(public_path($filePart . $name), $name);
                        //}
                    //}
    
                    $zip->close();
                }
    
                return ["url"=>'/uploads/txt_invoice/'.$searchString.'/'.$machineString.'/'.$generate_time_receipt_name.'-txt_invoice.zip'];
            }//---------------OrchardGateway End------------------------
            else if($searchString == 'Vivocity')
            {
                $mainFolderExist = false;
                //search folder
                $directories = Storage::disk('local')->allDirectories('txt_invoice');
                if(count($directories) > 0) 
                {
                    foreach($directories as $directoryString)
                    {
                        if(strpos($directoryString, $searchString) !== false) 
                        {
                            $mainFolderExist = true;
                            break;
                        }
                    }

                    if($mainFolderExist)
                    {
                        Storage::disk('local')->makeDirectory('txt_invoice/Vivocity');
                    }
                } 
                else 
                {
                    Storage::disk('local')->makeDirectory('txt_invoice/Vivocity');
                }

                $machineString = $location_details->machine_id; // Need to change
                $subFolderExist = false;
                $vivoDirectories = Storage::disk('local')->allDirectories('txt_invoice/Vivocity');
                $subDirectory = 'txt_invoice/'.$searchString.'/'.$machineString;

                if(count($vivoDirectories) > 0) 
                {
                    foreach($vivoDirectories as $directoryString)
                    {
                        if(strpos($directoryString, $machineString) !== false) 
                        {
                            $subFolderExist = true;
                            break;
                        }
                    }

                    if($subFolderExist)
                    {
                        Storage::disk('local')->makeDirectory($subDirectory);
                    }
                } 
                else 
                {
                    Storage::disk('local')->makeDirectory($subDirectory);
                }

                $subSubFolderExist = false;
                $subDirectories = Storage::disk('local')->allDirectories($subDirectory);
                $subSubDirectory = 'txt_invoice/'.$searchString.'/'.$machineString.'/'.$date_receipt_name;

                if(count($subDirectories) > 0) 
                {
                    foreach($subDirectories as $subDirectoryString)
                    {
                        if(strpos($subDirectoryString, $date_receipt_name) !== false) 
                        {
                            $subSubFolderExist = true;
                            break;
                        }
                    }

                    if($subSubFolderExist)
                    {
                        Storage::disk('local')->makeDirectory($subSubDirectory);
                    }
                } 
                else 
                {
                    Storage::disk('local')->makeDirectory($subSubDirectory);
                }

                $sales = $all_sale_history['sells'];
                $filePart = 'uploads/txt_invoice/'.$searchString.'/'.$machineString.'/'.$date_receipt_name;

                if(count($sales) > 0)
                {
                    // Get all files in a directory
                    $files = Storage::disk('local')->allFiles($subSubDirectory);
                    if(count($files) > 0) 
                    {
                        // Delete Files
                        Storage::disk('local')->delete($files);
                    }

                    //Shop has sales
                    foreach($sales as $sale)
                    {
                        $each_transaction = "";
                        $gto1 = 0;
                        $payment_method1 = 0;
                        $gto2 = 0;
                        $payment_method2 = 0;
                        $gto3 = 0;
                        $payment_method3 = 0;

                        $receipt_no = $sale['invoice_no'];
                        if(empty($sale['return_parent']))
                        {
                            foreach($sale['payments'] as $key => $payment)
                            {
                                if($key + 1 == 1)
                                {
                                    $gto1 = number_format((float)$payment['received_amount'], 2);
                                    $payment_method1 = $this->transactionUtil->filter_payment_type($payment['method'], $payment['card_type']);
                                }
                                else if($key + 1 == 2)
                                {
                                    $gto2 = number_format((float)$payment['received_amount'], 2);
                                    $payment_method2 = $this->transactionUtil->filter_payment_type($payment['method'], $payment['card_type']);
                                }
                                else if($key + 1 == 3)
                                {
                                    $gto3 = number_format((float)$payment['received_amount'], 2);
                                    $payment_method3 = $this->transactionUtil->filter_payment_type($payment['method'], $payment['card_type']);
                                }
                            }

                            $gst = number_format((float)$sale['tax_amount'], 2);
                            $discount = number_format((float)$sale['discount_amount'], 2);
                        }
                        else
                        {
                            foreach($sale['payments'] as $key => $payment)
                            {
                                if($key + 1 == 1)
                                {
                                    $gto1 = number_format((float)$payment['original_received_amount'], 2);
                                    $payment_method1 = $this->transactionUtil->filter_payment_type($payment['method'], $payment['card_type']);
                                }
                                else if($key + 1 == 2)
                                {
                                    $gto2 = number_format((float)$payment['original_received_amount'], 2);
                                    $payment_method2 = $this->transactionUtil->filter_payment_type($payment['method'], $payment['card_type']);
                                }
                                else if($key + 1 == 3)
                                {
                                    $gto3 = number_format((float)$payment['original_received_amount'], 2);
                                    $payment_method3 = $this->transactionUtil->filter_payment_type($payment['method'], $payment['card_type']);
                                }
                            }

                            $gst = number_format((float)$sale['original_tax_amount'], 2);
                            $discount = number_format((float)$sale['original_discount_amount'], 2);
                        }
                        $transaction_date = \Carbon::parse($sale['transaction_date'])->format('Ymd');
                        $transaction_time_hours = \Carbon::parse($sale['transaction_date'])->format('H');
                        $transaction_time_minutes = \Carbon::parse($sale['transaction_date'])->format('i');
                        $transaction_time_second = \Carbon::parse($sale['transaction_date'])->format('s');
                        $pax = !empty($sale['pax']) ? $sale['pax'] : 0;
                        $membership_id = 0;

                        $each_transaction = $machineString.'|'.$receipt_no.'|'.$gto1.'|'.$payment_method1.'|'.$gto2.'|'.$payment_method2.'|'.$gto3.'|'.$payment_method3.'|'.$gst.'|'.$discount.'|'.$transaction_date.'|'.$transaction_time_hours.'|'.$transaction_time_minutes.'|'.$transaction_time_second.'|'.$pax.'|'.$membership_id;

                        $transaction_time = \Carbon::parse($sale['transaction_date'])->format('His');

                        $file_name = $machineString.'_'.$transaction_date.'_'.$transaction_time.'.txt';

                        Storage::disk('local')->put($subSubDirectory.'/'.$file_name, $each_transaction);

                        if(!empty($sale['return_parent']))
                        {
                            $void_each_transaction = "";
                            $void_gto1 = 0;
                            $void_payment_method1 = 0;
                            $void_gto2 = 0;
                            $void_payment_method2 = 0;
                            $void_gto3 = 0;
                            $void_payment_method3 = 0;

                            $void_receipt_no = $sale['invoice_no'].'R';
                            if($sale['total'] == 0)
                            {
                                foreach($sale['payments'] as $key => $payment)
                                {
                                    if($key + 1 == 1)
                                    {
                                        $void_gto1 = -(number_format((float)$payment['original_received_amount'], 2));
                                        $void_payment_method1 = $this->transactionUtil->filter_payment_type($payment['method'], $payment['card_type']);
                                    }
                                    else if($key + 1 == 2)
                                    {
                                        $void_gto2 = -(number_format((float)$payment['original_received_amount'], 2));
                                        $void_payment_method2 = $this->transactionUtil->filter_payment_type($payment['method'], $payment['card_type']);
                                    }
                                    else if($key + 1 == 3)
                                    {
                                        $void_gto3 = -(number_format((float)$payment['original_received_amount'], 2));
                                        $void_payment_method3 = $this->transactionUtil->filter_payment_type($payment['method'], $payment['card_type']);
                                    }
                                }

                                $void_gst = ($sale['return_parent']->tax_amount > 0) ? -(number_format((float)$sale['return_parent']->tax_amount, 2)) : 0;
                                $void_discount = ($sale['return_parent']->discount_amount > 0) ? -(number_format((float)$sale['return_parent']->discount_amount, 2)) : 0;
                            }
                            else
                            {
                                foreach($sale['payments'] as $key => $payment)
                                {
                                    if($key + 1 == 1)
                                    {
                                        $void_gto1 = -(number_format($sale['refund_final_total_without_discount'], 2));
                                        $void_payment_method1 = $this->transactionUtil->filter_payment_type($payment['method'], $payment['card_type']);
                                    }
                                }

                                $void_gto2 = 0;
                                $void_payment_method2 = 0;

                                $void_gto3 = 0;
                                $void_payment_method3 = 0;


                                $void_gst = ($sale['refund_tax_amount'] > 0) ? -(number_format($sale['refund_tax_amount'], 2)) : 0;
                                $void_discount = ($sale['refund_discount_amount'] > 0) ? -(number_format($sale['refund_discount_amount'], 2)) : 0;
                            }

                            
                            $void_transaction_date = \Carbon::parse($sale['return_parent']->transaction_date)->format('Ymd');
                            $void_transaction_time_hours = \Carbon::parse($sale['return_parent']->transaction_date)->format('H');
                            $void_transaction_time_minutes = \Carbon::parse($sale['return_parent']->transaction_date)->format('i');
                            $void_transaction_time_second = \Carbon::parse($sale['return_parent']->transaction_date)->format('s');
                            $void_pax = !empty($sale['pax']) ? $sale['pax'] : 0;
                            $void_membership_id = 0;

                            $void_each_transaction = $machineString.'|'.$void_receipt_no.'|'.$void_gto1.'|'.$void_payment_method1.'|'.$void_gto2.'|'.$void_payment_method2.'|'.$void_gto3.'|'.$void_payment_method3.'|'.$void_gst.'|'.$void_discount.'|'.$void_transaction_date.'|'.$void_transaction_time_hours.'|'.$void_transaction_time_minutes.'|'.$void_transaction_time_second.'|'.$void_pax.'|'.$void_membership_id;

                            $void_transaction_time = \Carbon::parse($sale['return_parent']->transaction_date)->format('His');

                            $void_file_name = $machineString.'_'.$void_transaction_date.'_'.$void_transaction_time.'R.txt';

                            Storage::disk('local')->put($subSubDirectory.'/'.$void_file_name, $void_each_transaction);
                        }
                    }
                }
                else
                {
                    //0 sales
                    $file_name = $machineString.'_'.$date_receipt_name.'_'.$generate_time_receipt_name.'.txt';
                    Storage::disk('local')->put($subSubDirectory.'/'.$file_name, "0 Sales");
                }

                $allFiles = Storage::disk('local')->allFiles($subSubDirectory);
                if (true === ($zip->open(public_path($filePart.'/'.$generate_time_receipt_name.'-txt_invoice.zip'), ZipArchive::CREATE | ZipArchive::OVERWRITE))) {
                    foreach ($allFiles as $file) {
                        $name = basename($file);
                        $zip->addFile(public_path($filePart .'/'. $name), $name);
                    }

                    $zip->close();
                }

                return ["url"=>'/'.$filePart.'/'.$generate_time_receipt_name.'-txt_invoice.zip'];
            }//---------------ThomsonPlaza------------------------
            else if($searchString == 'ThomsonPlaza' || $searchString == 'HillonMall')
            {
                $mainFolderExist = false;
                //search folder
                $directories = Storage::disk('local')->allDirectories('txt_invoice');
                if(count($directories) > 0) 
                {
                    foreach($directories as $directoryString)
                    {
                        if(strpos($directoryString, $searchString) !== false) 
                        {
                            $mainFolderExist = true;
                            break;
                        }
                    }
                    
                    if($mainFolderExist)
                    {
                        if($searchString == 'ThomsonPlaza')
                        {
                            Storage::disk('local')->makeDirectory('txt_invoice/ThomsonPlaza');
                        }
                        elseif($searchString == 'HillonMall')
                        {
                            Storage::disk('local')->makeDirectory('txt_invoice/HillonMall');
                        }
                    }
                } 
                else 
                {
                    if($searchString == 'ThomsonPlaza')
                    {
                        Storage::disk('local')->makeDirectory('txt_invoice/ThomsonPlaza');
                    }
                    elseif($searchString == 'HillonMall')
                    {
                        Storage::disk('local')->makeDirectory('txt_invoice/HillonMall');
                    }
                }

                $machineString = $location_details->machine_id; // Need to change
                $subFolderExist = false;
                if($searchString == 'ThomsonPlaza')
                {
                    $mallDirectories = Storage::disk('local')->allDirectories('txt_invoice/ThomsonPlaza');
                }
                elseif($searchString == 'HillonMall')
                {
                    $mallDirectories = Storage::disk('local')->allDirectories('txt_invoice/HillonMall');
                }
                $subDirectory = 'txt_invoice/'.$searchString.'/'.$machineString;

                if(count($mallDirectories) > 0) 
                {
                    foreach($mallDirectories as $directoryString)
                    {
                        if(strpos($directoryString, $machineString) !== false) 
                        {
                            $subFolderExist = true;
                            break;
                        }
                    }

                    if($subFolderExist)
                    {
                        Storage::disk('local')->makeDirectory($subDirectory);
                    }
                } 
                else 
                {
                    Storage::disk('local')->makeDirectory($subDirectory);
                }

                $file_name = 'H'.$machineString.'_'.$date_receipt_name.'.txt';
                $allFiles = array_filter(Storage::disk('local')->allFiles($subDirectory), function ($item) {
                    //only txt's
                    return strpos($item, '.txt');
                });
                $batch_id = count($allFiles) + 1;
                $line = "";
                foreach ($allFiles as $file) {
                    if (strpos($file, $date_receipt_name) !== false)
                    {
                        $line = fgets(fopen( public_path('/uploads/'.$file), 'r')); ///public
                        if(!empty($line))
                        {
                            $array_filter_first_line = explode("|",$line);
                            $batch_id = $array_filter_first_line[1];
                        }
                        break;
                    }
                }

                $sales = $all_sale_history['sells'];
                $sale_returns = $all_sale_return_history['transaction_result'];
                // return $sales;
                // return $sale_returns;
                $filePart = 'uploads/txt_invoice/'.$searchString.'/'.$machineString.'/';

                $total_lines = 24;

                for($a = 0; $a < $total_lines; $a++)
                {
                    $transaction_hours = "";
                    $total_receipt_no = 0;
                    $total_gto = 0;
                    $total_gst = 0;
                    $total_service_charge_amount = 0;
                    $total_discount = 0;
                    $total_pax = 0;
                    $total_cash = number_format(0, 2);
                    $total_nets = number_format(0, 2);
                    $total_visa = number_format(0, 2);
                    $total_master = number_format(0, 2);
                    $total_amex = number_format(0, 2);
                    $total_voucher = number_format(0, 2);
                    $total_others = number_format(0, 2);
                    $gst_registered = 'N';

                    if(strlen($a) == 1)
                    {
                        $string = '0'.$a;
                        $transaction_hours = $string;
                    }
                    else if(strlen($a) == 2)
                    {
                        $string = $a;
                        $transaction_hours = $string;
                    }

                    foreach($business_tax_rates as $business_tax_rate)
                    {
                        if(strtolower($business_tax_rate['name']) == 'gst')
                        {
                            $gst_registered = 'Y';
                            break;
                        }
                    }

                    foreach($sales as $sale)
                    {
                        $transaction_date = \Carbon::parse($sale['transaction_date'])->format('dmY');
                        $transaction_time = \Carbon::parse($sale['transaction_date'])->format('Hi');
                        // $receipt_no = $sale['invoice_no'];
                        $gto = $sale['total'] + $sale['round_off_amount'] - number_format((float)$sale['tax_amount'], 2);
                        $gst = number_format((float)$sale['tax_amount'], 2);
                        $service_charge_amount = $sale['service_charge_amount'];
                        $discount = $sale['discount_amount'];
                        $pax = !empty($sale['pax']) ? (integer)$sale['pax'] : 0;
                        $payments = $sale['payments'];

                        $first_two_char = substr($transaction_time, 0, 2);

                        if(strlen($a) == 1)
                        {
                            $string = '0'.$a;
                            $transaction_hours = $string;

                            if($first_two_char == $string) 
                            {
                                $total_receipt_no = $total_receipt_no + 1;
                                $total_gto = $total_gto + $gto;
                                $total_gst = $total_gst + $gst;
                                $total_service_charge_amount = $total_service_charge_amount + $service_charge_amount;
                                $total_discount = $total_discount + $discount;
                                $total_pax = $total_pax + $pax;

                                if(!empty($sale['return_parent']))
                                {
                                    $return_gto = $sale['refund_final_total_without_discount_and_gst'];
                                    $return_gst = $sale['refund_tax_amount'];
                                    $refund_service_charge_amount = $sale['refund_service_charge_amount'];
                                    $return_discount = $sale['refund_discount_amount'];

                                    $total_gto = $total_gto + $return_gto;
                                    $total_gst = $total_gst + $return_gst;
                                    $total_service_charge_amount = $total_service_charge_amount + $refund_service_charge_amount;
                                    $total_discount = $total_discount + $return_discount;
                                }

                                foreach($payments as $payment)
                                {
                                    if($payment['card_type'] == 'credit')
                                    {
                                        $total_cash = (float)$total_cash + $payment['total_before_gst'];
                                        $total_cash = number_format((float)$total_cash, 2);
                                    }
                                    elseif($payment['card_type'] == 'nets')
                                    {
                                        $total_nets = (float)$total_nets + $payment['total_before_gst'];
                                        $total_nets = number_format((float)$total_nets, 2);
                                    } 
                                    elseif($payment['card_type'] == 'visa')
                                    {
                                        $total_visa = (float)$total_visa + $payment['total_before_gst'];
                                        $total_visa = number_format((float)$total_visa, 2);
                                    } 
                                    elseif($payment['card_type'] == 'master')
                                    {
                                        $total_master = (float)$total_master + $payment['total_before_gst'];
                                        $total_master = number_format((float)$total_master, 2);
                                    } 
                                    elseif($payment['card_type'] == 'amex')
                                    {
                                        $total_amex = (float)$total_amex + $payment['total_before_gst'];
                                        $total_amex = number_format((float)$total_amex, 2);
                                    } 
                                    elseif($payment['card_type'] == 'voucher')
                                    {
                                        $total_voucher = (float)$total_voucher + $payment['total_before_gst'];
                                        $total_voucher = number_format((float)$total_voucher, 2);
                                    } 
                                    else
                                    {
                                        $total_others = (float)$total_others + $payment['total_before_gst'];
                                        $total_others = number_format((float)$total_others, 2);
                                    } 
                                }
                            }
                        }
                        else if(strlen($a) == 2)
                        {
                            $string = $a;
                            $transaction_hours = $string;

                            if($first_two_char == $string) 
                            {
                                $total_receipt_no = $total_receipt_no + 1;
                                $total_gto = $total_gto + $gto;
                                $total_gst = $total_gst + $gst;
                                $total_service_charge_amount = $total_service_charge_amount + $service_charge_amount;
                                $total_discount = $total_discount + $discount;
                                $total_pax = $total_pax + $pax;

                                if(!empty($sale['return_parent']))
                                {
                                    $return_gto = $sale['refund_final_total_without_discount_and_gst'];
                                    $return_gst = $sale['refund_tax_amount'];
                                    $refund_service_charge_amount = $sale['refund_service_charge_amount'];
                                    $return_discount = $sale['refund_discount_amount'];

                                    $total_gto = $total_gto + $return_gto;
                                    $total_gst = $total_gst + $return_gst;
                                    $total_service_charge_amount = $total_service_charge_amount + $refund_service_charge_amount;
                                    $total_discount = $total_discount + $return_discount;
                                }

                                foreach($payments as $payment)
                                {
                                    if($payment['card_type'] == 'credit')
                                    {
                                        $total_cash = (float)$total_cash + $payment['total_before_gst'];
                                        $total_cash = number_format((float)$total_cash, 2);
                                    }
                                    elseif($payment['card_type'] == 'nets')
                                    {
                                        $total_nets = (float)$total_nets + $payment['total_before_gst'];
                                        $total_nets = number_format((float)$total_nets, 2);
                                    } 
                                    elseif($payment['card_type'] == 'visa')
                                    {
                                        $total_visa = (float)$total_visa + $payment['total_before_gst'];
                                        $total_visa = number_format((float)$total_visa, 2);
                                    } 
                                    elseif($payment['card_type'] == 'master')
                                    {
                                        $total_master = (float)$total_master + $payment['total_before_gst'];
                                        $total_master = number_format((float)$total_master, 2);
                                    } 
                                    elseif($payment['card_type'] == 'amex')
                                    {
                                        $total_amex = (float)$total_amex + $payment['total_before_gst'];
                                        $total_amex = number_format((float)$total_amex, 2);
                                    } 
                                    elseif($payment['card_type'] == 'voucher')
                                    {
                                        $total_voucher = (float)$total_voucher + $payment['total_before_gst'];
                                        $total_voucher = number_format((float)$total_voucher, 2);
                                    } 
                                    else
                                    {
                                        $total_others = (float)$total_others + $payment['total_before_gst'];
                                        $total_others = number_format((float)$total_others, 2);
                                    } 
                                }
                            }
                        }
                    }

                    foreach($sale_returns as $sale_return)
                    {
                        $return_transaction_date = \Carbon::parse($sale_return->transaction_date)->format('dmY');
                        $return_transaction_time = \Carbon::parse($sale_return->transaction_date)->format('Hi');

                        $return_gto = $sale_return['total_before_tax'] * (1 + $sale_return['parent_service_charges']);
                        $return_gst = $sale_return['tax_amount'];
                        $refund_service_charge_amount = $sale_return['total_before_tax'] * ($sale_return['parent_service_charges']);
                        // $return_discount = $sale_return['refund_discount_amount'];
                        // $return_pax = 0;

                        $return_first_two_char = substr($return_transaction_time, 0, 2);

                        if(strlen($a) == 1)
                        {
                            $return_string = '0'.$a;
                            // $return_transaction_hours = $return_string;

                            if($return_first_two_char == $return_string) 
                            {
                                //$total_receipt_no = $total_receipt_no + 1;
                                $total_gto = $total_gto - $return_gto;
                                // $total_gst = $total_gst - $return_gst;
                                // $total_service_charge_amount = $total_service_charge_amount - $refund_service_charge_amount;
                                // $total_discount = $total_discount - $return_discount;
                            }
                        }
                        else if(strlen($a) == 2)
                        {
                            $return_string = $a;
                            // $return_transaction_hours = $return_string;

                            if($return_first_two_char == $return_string) 
                            {
                                //$total_receipt_no = $total_receipt_no + 1;
                                $total_gto = $total_gto - $return_gto;
                                // $total_gst = $total_gst - $return_gst;
                                // $total_service_charge_amount = $total_service_charge_amount - $refund_service_charge_amount;
                                // $total_discount = $total_discount - $return_discount;
                            }
                        }
                    }

                    $all_transaction = $all_transaction.$machineString.'|'.$batch_id.'|'.$transaction_date.'|'.$transaction_hours.'|'.$total_receipt_no.'|'.
                                        number_format((float)$total_gto, 2, ".", "").'|'.number_format((float)$total_gst, 2, ".", "").'|'.number_format((float)$total_discount, 2, ".", "").'|'.
                                        number_format((float)$total_service_charge_amount, 2, ".", "").'|'.$total_pax.'|'.$total_cash.'|'.$total_nets.'|'.$total_visa.'|'.
                                        $total_master.'|'.$total_amex.'|'.$total_voucher.'|'.$total_others.'|'.$gst_registered."\n";
                }

                Storage::disk('local')->put($subDirectory.'/'.$file_name, $all_transaction);

                if (true === ($zip->open(public_path($filePart.$generate_time_receipt_name.'-txt_invoice.zip'), ZipArchive::CREATE | ZipArchive::OVERWRITE))) {
                    //foreach (Storage::allFiles('public') as $file) {
                        $name = basename('/txt_invoice/'.$searchString.'/'.$machineString.'/'.$file_name);
                        //if ($name !== '.gitignore') {
                            $zip->addFile(public_path($filePart . $name), $name);
                        //}
                    //}
    
                    $zip->close();
                }
    
                return ["url"=>'/uploads/txt_invoice/'.$searchString.'/'.$machineString.'/'.$generate_time_receipt_name.'-txt_invoice.zip'];

                // $ftp_server = $location_detail->ftp_server;
                // $ftp_conn = ftp_connect($ftp_server) or die("Could not connect to $ftp_server");
                // $ftp_username = $location_detail->machine_id;
                // $ftp_userpass = $location_detail->ftp_password;
                // $login = ftp_login($ftp_conn, $ftp_username, $ftp_userpass);

                // $name = basename('/txt_invoice/'.$searchString.'/'.$machineString.'/'.$file_name);
                // $file = public_path($filePart .'/'. $name);
                // ftp_put($ftp_conn, $name, $file, FTP_ASCII);
                
                // ftp_close($ftp_conn);

                // echo json_encode( 'FTP Upload Successful.' );
            }//---------------ThomsonPlaza End------------------------
        }
        else
        {
            return "false";
        }
    }

    public function get_product_sales($user_data) {

    $businessLocation = BusinessLocation::find($user_data['business_location_id']);
        if( !empty($businessLocation) && !empty($businessLocation->day_start_time)) {
            $daystartTime = $businessLocation->day_start_time;
            $dayStartTime = $daystartTime.":00:00";
            $dayendTime = $daystartTime - 1;
            $dayEndTime = $dayendTime.":59:59";
        } else {
            $dayStartTime = str_replace(' ', '', Config::get('constants.businessStartTimeDefault'));
            $dayEndTime = str_replace(' ', '', Config::get('constants.businessEndTimeDefault'));
        }
        
            try {
                $location_id = $user_data['business_location_id'];
                $transaction_status = "final";
                $created_at = "";
                
                if (!empty($user_data['start_date']) && !empty($user_data['end_date'])) {
                    $start_date = $user_data['start_date'];
                    $end_date = $user_data['end_date'];
                } else {
                    $start_date = "";
                    $end_date = "";
                }
                $type = "";
                
                $current_time = $user_data['current_time'];

                $query = Transaction::leftjoin('transaction_payments as t', 't.transaction_id', '=', 'transactions.id')
                        ->leftjoin('variations as w', 'w.product_id', '=', 'transactions.additional_discount_method')
                        ->leftjoin('tax_rates as z', 'z.id', '=', 'transactions.tax_id')
                        ->leftJoin(
                            'transactions AS SR',
                            'transactions.id',
                            '=',
                            'SR.return_parent_id'
                        )
                        ->with('sell_lines.variations.product.category')
                        ->where('transactions.location_id', $location_id)
                        ->where('transactions.type', 'sell')
                        ->where('transactions.is_direct_sale', 0)
                        ->where(function($query) {
                            $query->where('transactions.type_for_api', 'Dinein')
                                    ->orWhere('transactions.type_for_api', 'Takeaway')
                                    ->orWhere('transactions.type_for_api', 'Retail')
                                    ->orWhere('transactions.type_for_api', 'Kiosk')
                                    ->orWhere('transactions.type_for_api', 'Common');
                        });
                if (!empty($start_date) && !empty($end_date)) {
                    $dateTime = explode(' ', $start_date);

                    if(count($dateTime) == 2) {
                        $query->where('transactions.transaction_date', '>=', $start_date)
                            ->where('transactions.transaction_date', '<=', $end_date);
                    }
                    else {
                        
                        if( Config::get('constants.setBusinessTime') && !empty($businessLocation) && !empty($businessLocation->day_start_time)) {
                                                        
                            $query->whereBetween('transactions.transaction_date', [$start_date, $end_date]);
                        } else {
                            $query->whereDate('transactions.transaction_date', '>=', $start_date)
                                ->whereDate('transactions.transaction_date', '<=', $end_date);
                        }
                    }
                } else {
                    $query->whereDate('transactions.transaction_date', '=', \Carbon::now()->format('Y-m-d 00:00:00'));
                }

                if (!empty($type)) {
                    $query->where('transactions.type_for_api', $type);
                }
                
                if ($transaction_status == 'quotation') {
                    $query->where('transactions.status', 'draft')
                        ->where('transactions.sub_status', 'quotation');
                } elseif ($transaction_status == 'draft') {
                    $query->where('transactions.status', 'draft')
                        ->whereNull('transactions.sub_status');
                } else {
                    $query->where('transactions.status', $transaction_status);
                }
                
                $transactions = $query->orderBy('transactions.created_at', 'desc')
                                    ->groupBy('transactions.id')
                                    ->select('transactions.*', 't.method', 't.card_type', 'w.profit_percent', 'z.amount as tax_rate_amount', DB::raw('COUNT(SR.id) as return_exists'), 'SR.refund_all', 'SR.total_discount_amount')
                                    ->with(['contact', 'table'])
                                    ->get();

                $item;
                $category_arr = [];
                $product_report_result = [];
                
                foreach ($transactions as $key => $value) 
                {
                    $final_total_for_single_item = 0;
                    $final_total_line_discount_amount = 0;
                    $overall_discount_amount = $value['discount_amount'];
                    $overall_discount_type = $value['discount_type'];

                    if($overall_discount_type == "fixed") {
                            $overall_discount_amount = $overall_discount_amount - $value['total_discount_amount'];
                    }

                    if($overall_discount_amount || $overall_discount_amount > 0) {
                        // Filter out products without a line discount
                        $products_without_line_discount = $value['sell_lines']->filter(function ($sellLine) {
                            return $sellLine['line_discount_amount'] == 0 && ($sellLine['quantity_returned'] == "0.0000" || $sellLine['quantity_returned'] == "0.00" || $sellLine['quantity_returned'] == 0);
                        });
                        
                        $num_products_without_line_discount = $products_without_line_discount->count();
                        $products_without_line_discount_sum = $products_without_line_discount->map(function ($sellLine) {
                            return $sellLine['unit_price_before_discount'] * $sellLine['quantity'];
                        })->sum();

                        // Apply overall discount if there are eligible products
                        if ($num_products_without_line_discount > 0) {
                            $total_sell_price_without_discount = 0;
                    
                            // Calculate total price of products without line discount
                            foreach ($products_without_line_discount as $sellLine) {
                                $total_sell_price_without_discount += $sellLine['unit_price_before_discount'] * $sellLine['quantity'];
                            }
                    
                            // Split overall discount across products without line discount
                            foreach ($products_without_line_discount as $sellLine) {
                                $product_price_without_discount = $sellLine['unit_price_before_discount'];
                                
                                if ($overall_discount_type == 'percentage') {
                                    $overall_discount = ($product_price_without_discount * $overall_discount_amount );
                                    $total_overall_discount = $overall_discount * $sellLine['quantity'];
                                } else {
                                    $overall_discount = ($overall_discount_amount / $products_without_line_discount_sum) * $product_price_without_discount;
                                    $total_overall_discount = $overall_discount * $sellLine['quantity'];
                                }
                                
                                $product_id = $sellLine['product_id'];
                    
                                $product_overall_discount[$product_id][] = $item = [
                                    'id' => $sellLine['id'],
                                    'category_name' => $sellLine['variations']->product->category->name,
                                    'name' => $sellLine['variations']->product->name,
                                    'quantity' => $sellLine['quantity'],
                                    'quantity_returned' => $sellLine["quantity_returned"],
                                    'overall_discount' => $overall_discount,
                                    'overall_discount_type' => $overall_discount_type,
                                    'total_overall_discount' => $total_overall_discount,
                                    'unit_price' => $sellLine['unit_price_before_discount']
                                ];
                            }
                        }    
                    }

                    //dd($product_overall_discount);
                    foreach ($value['sell_lines'] as $sellLinesKey => $sellLinesValue)
                    {
                        if($overall_discount_amount == 0 || $overall_discount_amount == "0.0" || $overall_discount_amount == "0.0000" || $overall_discount_amount == 0.0 || $overall_discount_amount == 0.0000) {
                            $total_line_discount_amount = 0;
                            $refund_total_line_discount_amount = 0;
                            if($sellLinesValue["parent_sell_line_id"] == null && $sellLinesValue["transaction_id"] == $value['id'])
                            {
                                $adons = [];
                                $total_for_single_item = 0;
                                foreach ($value['sell_lines'] as $sellLinesKey1 => $sellLinesValue1)
                                {
                                    if($sellLinesValue1["parent_sell_line_id"] != null && $sellLinesValue1["parent_sell_line_id"] == $sellLinesValue['id'] && $sellLinesValue1["children_type"] == "modifier")
                                    {
                                        $adons[] = [
                                            'id' => !empty($sellLinesValue1['variations']->id) ? $sellLinesValue1['variations']->id : "",
                                            'name' => !empty($sellLinesValue1['variations']->name) ? $sellLinesValue1['variations']->name : "",
                                            'quantity' => !empty($sellLinesValue1["quantity"]) ? $sellLinesValue1["quantity"] : "",
                                            'amount' => !empty($sellLinesValue1['unit_price_before_discount']) ? $sellLinesValue1['unit_price_before_discount'] : "", //unit_price_before_discount
                                        ];
                                        if($sellLinesValue["quantity_returned"] == "0.0000" && $sellLinesValue["change_price"] == 0)
                                        {
                                            //total modifier price
                                            $total_for_single_item = $total_for_single_item + $sellLinesValue1['unit_price_before_discount'];
                                        }
                                    }
                                }
                                
                                //main item price + modifier price
                                if($sellLinesValue['weight'] > 0) {
                                    $total_for_single_item = ($sellLinesValue['unit_price_before_discount'] + $total_for_single_item) * $sellLinesValue["quantity"];
                                } else {
                                    $total_for_single_item = ($sellLinesValue['unit_price_before_discount'] + $total_for_single_item)* $sellLinesValue["quantity"];
                                }
            
                                if($sellLinesValue["quantity_returned"] == "0.0000")
                                {
                                    $final_total_for_single_item += $total_for_single_item;
                                    //calculate if line item has line discount
                                    if($sellLinesValue['line_discount_type'] == "fixed")
                                    {
                                        $total_line_discount_amount += $sellLinesValue['line_discount_amount'];
                                    }
                                    else if($sellLinesValue['line_discount_type'] == "percentage")
                                    {
                                        $total_line_discount_amount = (($sellLinesValue['line_discount_amount']/100) * $total_for_single_item) + $total_line_discount_amount;
                                        $total_line_discount_amount = $total_line_discount_amount/$sellLinesValue['quantity'];
                                    }
                                    //calculate final total line discount amount
                                    $final_total_line_discount_amount += $total_line_discount_amount;
                                    
                                    if((isset($sellLinesValue['variations']) && $sellLinesValue['variations'] && isset($sellLinesValue['variations']->product) && $sellLinesValue['variations']->product) && (strtolower($sellLinesValue['variations']->product->name) == 'open food' || strtolower($sellLinesValue['variations']->product->name) == 'open drinks')) {
                                        $latest_product_name = $sellLinesValue['sell_line_note'];
                                    } else {
                                        $latest_product_name = $sellLinesValue['variations']->product->name;
                                    }
                                    $item = [
                                        'id' => $sellLinesValue['id'],
                                        'category_name' => $sellLinesValue['variations']->product->category->name,
                                        'name' => $latest_product_name,
                                        'quantity' => $sellLinesValue['quantity'],
                                        'quantity_returned' => $sellLinesValue["quantity_returned"],
                                        'amount' => $total_for_single_item,
                                        'total_for_single_item' => $total_for_single_item,
                                        'discount' => $total_line_discount_amount,
                                        'discount_type' => $sellLinesValue["line_discount_type"],
                                        'unit_price' => $sellLinesValue['unit_price_before_discount']
                                    ];
                                    
                                    if ($sellLinesValue['line_discount_type'] === 'percentage') {
                                        $total_discount = $total_line_discount_amount * $sellLinesValue['quantity'];
                                    } else {
                                        $total_discount = $total_line_discount_amount;
                                    }
                                    
                                    $item['total_discount'] = $total_discount;
                                    
                                    if ($sellLinesValue['line_discount_type'] === 'fixed') {
                                        $item['discount'] = $total_line_discount_amount / $sellLinesValue['quantity'];
                                    }
                                    
                                    $pushItem = true;
                                    $discountGroupKey = $item['discount'];
                                    
                                    if (in_array($sellLinesValue['variations']->product->category->name, $category_arr)) {
                                        foreach ($product_report_result as $resultKey => $productReportDetailsValue) {
                                            if ($productReportDetailsValue['category'] == $sellLinesValue['variations']->product->category->name) {
                                                foreach ($productReportDetailsValue['items'] as $productKey => $productDetailsValue) {
                                                    if (
                                                        strtolower($product_report_result[$resultKey]['items'][$productKey]['name']) == strtolower($latest_product_name) &&
                                                        $product_report_result[$resultKey]['items'][$productKey]['discount'] == $discountGroupKey &&
                                                        $product_report_result[$resultKey]['items'][$productKey]['discount_type'] == $sellLinesValue['line_discount_type'] &&
                                                        $product_report_result[$resultKey]['items'][$productKey]['unit_price'] == $sellLinesValue['unit_price_before_discount']
                                                    ) {
                                                        // Merge with the previous entry

                                                        $product_report_result[$resultKey]['items'][$productKey]['quantity'] += $sellLinesValue['quantity'];
                                                        $product_report_result[$resultKey]['items'][$productKey]['quantity_returned'] += $sellLinesValue['quantity_returned'];
                                                        $product_report_result[$resultKey]['items'][$productKey]['amount'] += $total_for_single_item;
                                                        $product_report_result[$resultKey]['items'][$productKey]['total_for_single_item'] += $total_for_single_item;
                                    
                                                        // Update total_discount
                                                        if ($sellLinesValue['line_discount_type'] === 'percentage') {
                                                            $total_discount = $total_line_discount_amount * $product_report_result[$resultKey]['items'][$productKey]['quantity'];
                                                        } else {
                                                            $total_discount = $total_line_discount_amount;
                                                        }
                                                        $product_report_result[$resultKey]['items'][$productKey]['total_discount'] = $total_discount;
                                    
                                                        $pushItem = false;
                                                        break;
                                                    }
                                                }
                                                
                                                if ($pushItem) {

                                                    $productItem = $product_report_result[$resultKey]['items'];
                                                    array_push($productItem, $item);
                                                    $product_report_result[$resultKey]['items'] = $productItem;
                                                }
                                    
                                                $product_report_result[$resultKey]['total_quantity'] += $sellLinesValue['quantity'];
                                                $product_report_result[$resultKey]['subtotal'] += $total_for_single_item - ($item['discount'] * $sellLinesValue['quantity']);
                                            }
                                        }
                                    } 
                                    else {
                                        $items = [];
                                        array_push($category_arr, $sellLinesValue['variations']->product->category->name);
                                        array_push($items, $item);
                                    
                                        $product_report_result[] = [
                                            'category' => $sellLinesValue['variations']->product->category->name,
                                            'total_quantity' => $sellLinesValue['quantity'],
                                            'subtotal' => $total_for_single_item - ($item['discount'] * $item['quantity']),
                                            'items' => $items
                                        ];
                                    }
                                }
                            }
                        }
                        
                    }
                }                
                // foreach ($product_overall_discount as $group) {
                //     foreach ($group as $item) {
                //         $category = $item['category_name'];

                //         if (!isset($result[$category])) {
                //             $result[$category] = [
                //                 'category' => $category,
                //                 'total_quantity' => 0,
                //                 'subtotal' => 0,
                //                 'items' => []
                //             ];
                //         }

                //         $quantity = (float) $item['quantity'];
                //         $unit_price = (float) $item['unit_price'];
                //         $total_for_single_item = $quantity * $unit_price;
                //         $total_discount = (float) $item['total_overall_discount'];

                //         $result[$category]['total_quantity'] += $quantity;
                //         $result[$category]['subtotal'] += $total_for_single_item - $total_discount;

                //         $result[$category]['items'][] = [
                //             'id' => $item['id'],
                //             'category_name' => $item['category_name'],
                //             'name' => $item['name'],
                //             'quantity' => $quantity,
                //             'quantity_returned' => (float) $item['quantity_returned'],
                //             'amount' => $total_for_single_item,
                //             'total_for_single_item' => $total_for_single_item,
                //             'discount' => (float) $item['overall_discount'],
                //             'discount_type' => 'fixed',
                //             'unit_price' => $item['unit_price'],
                //             'total_discount' => $total_discount,
                //         ];
                //     }
                // }

                foreach ($product_overall_discount as $product_category_id => $product_list) {
                    foreach ($product_list as $product) {
                        $category_name = $product['category_name'] ?? null;
                        $found = false;
                
                        // Iterate through $line_discount_products to find a matching category
                        foreach ($product_report_result as &$line_discount_category) {
                            if ($line_discount_category['category'] === $category_name) {
                                // Append the product to the items array in the matched category
                                $line_discount_category['items'][] = [
                                    'id' => $product['id'],
                                    'category_name' => $product['category_name'],
                                    'name' => $product['name'],
                                    'quantity' => $product['quantity'],
                                    'quantity_returned' => $product['quantity_returned'],
                                    'amount' => $product['unit_price'] * $product['quantity'],
                                    'total_for_single_item' => $product['unit_price'] * $product['quantity'],
                                    'discount' => $product['overall_discount'],
                                    'discount_type' => $product['overall_discount_type'], // Custom type for identification
                                    'unit_price' => $product['unit_price'],
                                    'total_discount' => $product['total_overall_discount']
                                ];
                        
                                // Increase total_quantity
                                $line_discount_category['total_quantity'] += $product['quantity'];
                        
                                // Increase subtotal (without applying the discount)
                                $line_discount_category['subtotal'] += ($product['unit_price'] * $product['quantity']) - $product['total_overall_discount'];
                        
                                $found = true;
                                break;
                            }
                        }                        
                
                        // If the category was not found in $line_discount_products, create a new entry
                        if (!$found && $category_name !== null) {
                            $product_report_result[] = [
                                'category' => $category_name,
                                'total_quantity' => $product['quantity'],
                                'subtotal' => $product['unit_price'] * $product['quantity'],
                                'items' => [[
                                    'id' => $product['id'],
                                    'category_name' => $product['category_name'],
                                    'name' => $product['name'],
                                    'quantity' => $product['quantity'],
                                    'quantity_returned' => $product['quantity_returned'],
                                    'amount' => $product['unit_price'] * $product['quantity'],
                                    'total_for_single_item' => $product['unit_price'] * $product['quantity'],
                                    'discount' => $product['overall_discount'],
                                    'discount_type' => $product['overall_discount_type'],
                                    'unit_price' => $product['unit_price'],
                                    'total_discount' => $product['total_overall_discount']
                                ]]
                            ];
                        }
                    }
                }
                return $product_report_result;
                
            } catch(\Exception $e) {
                \Log::info("Caught exception: " . $e->getMessage().'--'. $location_id);
                $result = ["errorMessage"=>'Result not found.'];
            }
    }

    public function generateCustomReport(Request $request)
    {
        $input = $request->only([
            'business_location_id', 'date_range', 'payment_types'
        ]);

        try{
            if(!empty($input['business_location_id'])) {
                ini_set('memory_limit', '8000M');
                $zip = new \ZipArchive();
                $array_filter_date = explode(" - ",$input['date_range']);
                $start_date_no_time = \Carbon::parse($array_filter_date[0])->format('Y-m-d');
                $end_date_no_time = \Carbon::parse($array_filter_date[1])->format('Y-m-d');
                $start_date = \Carbon::parse($array_filter_date[0])->format('Y-m-d 00:00:00');
                $end_date = \Carbon::parse($array_filter_date[1])->format('Y-m-d 23:59:59');
                $type = "";
                
                $location_details = BusinessLocation::find($input['business_location_id']);
                if( !empty($location_details) && !empty($location_details->day_start_time) ) {
                    $daystartTime = $location_details->day_start_time;
                    $dayStartTime = $daystartTime ? $daystartTime . ":00:00" : "00:00:00";
                    $dayendTime = strtotime($dayStartTime) - 1;
                    $dayEndTime = date("H:i:s", $dayendTime);
                } else {
                    $dayStartTime = str_replace(' ', '', Config::get('constants.businessStartTimeDefault'));
                    $dayEndTime = str_replace(' ', '', Config::get('constants.businessEndTimeDefault'));
                }
                
                $current_date = Carbon::now()->format('Y-m-d');
                $current_time = Carbon::now()->format('H:i:s');
                
                if( !empty($location_details) && isset($location_details->day_start_time) ) {
                    $morning6TimeStamp = strtotime($current_date . " " . $dayEndTime);
                    $dateTimeStamp = strtotime($current_date . " " . $current_time);

                    if($location_details->day_start_time == 0) {
                        $today = $start_date_no_time .' '.'00:00:00';
                        $tomorrow = $end_date_no_time .' '.'23:59:59';
                    }
                    elseif( $dateTimeStamp >= $morning6TimeStamp ) {
                        $today = $start_date_no_time . ' ' .$dayStartTime;
                        $Today = $start_date_no_time;
                        $tomorrow = date('Y-m-d', strtotime($end_date_no_time .' +1 day')) . ' ' .$dayEndTime;
                        $Tomorrow = date('Y-m-d', strtotime($end_date_no_time .' +1 day'));
                    } else {
                        $today = date('Y-m-d', strtotime($start_date_no_time .' -1 day')) . ' ' .$dayStartTime;
                        $Today = date('Y-m-d', strtotime($start_date_no_time .' -1 day'));
                        $tomorrow = $end_date_no_time .' '.$dayEndTime;
                        $Tomorrow = $end_date_no_time;
                    }
                } else {
                    $today = $start_date_no_time . Config::get('constants.businessStartTimeDefault');
                    $Today = $start_date_no_time;
                    $tomorrow = $end_date_no_time . Config::get('constants.businessEndTimeDefault');
                    $Tomorrow = $end_date_no_time;
                }
                //var_dump($dayStartTime.' '.$dayEndTime.' '.$today.' '.$tomorrow );die;
                $input['start_date'] = $today;
                $input['end_date'] = $tomorrow;
                $input['current_time'] = $current_time;
                
                $today_date = date('m/d/Y', strtotime($today));
                $tomorrow_date = date('m/d/Y', strtotime($tomorrow));
                $input['date_range'] = $today_date.' - '.$tomorrow_date;

                $sells_report = $this->get_product_sales($input);
                $user_id = "";
                $business_id = $location_details->business_id;
                $location_id = $input['business_location_id'];
                $transaction_status = "final";
                $created_at = "";
                
                // $txt = true;
                $report_dtls = $this->transactionUtil->get_sales_details($user_id, $business_id, $location_id, $transaction_status, $created_at, $today, $tomorrow, $type, null, $input['payment_types']);
                $cash_in_out_data  = $report_dtls['sales_result'][0]['open_drawer_status_result'];
                $no_of_refund_credit_notes = $report_dtls['sales_result'][0]['no_of_refund_credit_notes'];
                $total_refund_credit_notes = $report_dtls['sales_result'][0]['total_refund_credit_notes'];
                $cash_in = 0;
                $cash_out = 0;

                foreach ($cash_in_out_data as $key => $cash_data) {
                    if ($cash_data["status"] == 'cash in') {
                        $cash_in += $cash_data["cash_in_or_out_amount"];
                    } else {
                        $cash_out += $cash_data["cash_in_or_out_amount"];
                    }
                }
                $collection_details_result = $report_dtls['sales_result'][0]['collection_details_result'];
                $addon_discount_amount = $report_dtls['sales_result'][0]['addon_discount_amount'];
                $tax_rates_list = $report_dtls['sales_result'][0]['tax_rates_list'];
                $htmlRows = "";
                $discountHtmlRows = "";
                //$discountTotal = 0;
                $gst_rate = 0;
                $service_charge =0;
    
                foreach($collection_details_result as $collection_row) {
                    $htmlRows .= '
                        <tr class="odd">
                            <td style="width: 50%;">'.strtoupper($collection_row['payment_method']) .' ('.$collection_row['quantity'].')</td>
                            <td style="width: 50%; text-align: right;">'.number_format($collection_row['payment_total_amount'], 2).'</td>
                        </tr>
                    ';
                }

    
                $salesRows = "";
                 if(!empty($sells_report)){
                    $salesRows = '';
                    $overall_quantity = 0;
                    $overall_total_discount = 0;
                    $overall_sub_total = 0;

                    foreach ($sells_report as $sales_data) {
                        $category = $sales_data['category'];
                        $total_quantity = $sales_data['total_quantity'];
                        $subtotal = $sales_data['subtotal'];
                        $overall_sub_total += $subtotal;
    
                        $salesRows .= '
                        <table class="items" width="1000" style="font-size: 23pt; border-collapse: collapse;" cellpadding="8">
                            <thead>
                                <tr><td></td><br></tr>
                                <tr>
                                    <td colspan="1" style="text-transform: uppercase;"><strong>' . $category . '</strong></td><br>
                                </tr>
                                <tr><td></td></tr>
                            </thead>
                            <tbody>
                                <tr style="width: 100%">
                                    <td style="width: 1%;max-width: 100px"><strong>Qty</strong></td>
                                    <td style="width: 20%;"><strong>UP</strong></td>
                                    <td style="width: 20%;"><strong>TUP</strong></td>
                                    <td style="width: 40%;"><strong>Item</strong></td>
                                    <td style="width: 20%;"><strong>DPU</strong></td>
                                    <td style="width: 20%;"><strong>TD</strong></td>
                                    <td style="width: 20%; text-align: right;"><strong>Amount</strong></td>
                                </tr>    
                        ';
                        $total_discount_amount = 0;
                        foreach ($sales_data['items'] as $item) {
                            $quantity = $item['quantity'];
                            $overall_quantity += $item['quantity'];

                            $name = $item['name'];
                            $discount = $item['discount'];
                            $total_discount = $item['quantity'] * $item['discount'];
                            $overall_total_discount += $total_discount;
                            $total_discount_amount += $total_discount ;
                            $amount = $item['amount'] - (($item['discount'] * $item['quantity']));
                            $total_unit_price = number_format($item['amount'], 2);
                            $unit_price =$item['total_for_single_item']/$quantity;
    
                            $salesRows .= '
                                <tr style="width: 100%">
                                    <td style="width: 1%;max-width: 100px">' . $quantity . '</td>
                                    <td style="width: 20%;">' . round($unit_price, 2) . '</td>
                                    <td style="width: 20%;">' . round($total_unit_price, 2) . '</td>
                                    <td style="width: 20%;">' . $name . '</td>
                                    <td style="width: 20%;">(' . round($discount, 2) . ')</td>
                                    <td style="width: 20%;">(' . round($total_discount, 2) . ')</td>
                                    <td style="width: 20%; text-align: right;">' . round($amount, 2) . '</td>
                                </tr>
                            ';
                        }
    
                        $salesRows .= '
                            <tr><td></td></tr>
                            <tr style="width: 100%">
                                <td style="width: 30%;min-width: 30%"><strong>Total Quantity:</strong> ' . $total_quantity . '</td>
                                <td style="width: 20%;min-width: 60%"></td>
                                <td style="width: 20%;min-width: 60%"></td>
                                <td align="right" style="width: 30%;min-width: 10%;text-align: right;"><strong>Total Discount:</strong> ' . $total_discount_amount . '</td>
                                <td style="width: 20%;min-width: 60%"></td>
                                <td style="width: 20%;min-width: 60%"></td>
                                <td style="width: 20%;min-width: 60%"></td>
                                <td align="right" style="width: 30%;min-width: 10%;text-align: right;"><strong>Subtotal:</strong> ' . $subtotal . '</td>
                            </tr>
                            </tbody>
                        </table>
                        <hr>
                        ';
                    }
                 } else {
                    $salesRows .= "<thead>No Product data</thead>";
                 }
    
                foreach($addon_discount_amount as $discount_row) {
                    $discountHtmlRows .= '
                        <tr class="odd">
                            <td style="width: 50%">'.$discount_row['addon_discount_name'].'</td>
                            <td style="width: 50%; text-align: right;">'.number_format($discount_row['addon_discount_amount'], 2).'</td>
                        </tr>
                    ';
    
                    //$discountTotal += $discount_row['addon_discount_amount'];
                }
    
                  foreach($tax_rates_list as $tax_row) {
                    if($tax_row['name'] == "GST") {
                        $gst_rate = $tax_row['amount'];
                    }
                    if($tax_row['name'] == "Service Charge")
                    {
                        $service_charge = $tax_row['amount'];
                    }
                }
    
                if($location_details->show_retail) {
                    $service_charge_amount = 0;
                    $gst_amount = ($report_dtls['sales_result'][0]['gross_sales'] - $report_dtls['sales_result'][0]['item_discount'] - $report_dtls['sales_result'][0]['discount_total']) * ($gst_rate/100);
                    $net_sales = $report_dtls['sales_result'][0]['gross_sales'] - $report_dtls['sales_result'][0]['item_discount'] - $report_dtls['sales_result'][0]['discount_total'] - $gst_amount;
                } else {
                    $service_charge_amount = $report_dtls['sales_result'][0]['service_charge_amount'];
                    $gst_amount = $report_dtls['sales_result'][0]['tax_amount'];
                    $net_sales = $report_dtls['sales_result'][0]['net_sales'];
                }
                //return $location_details;
                $html='
                     <body>
                     <div id="page">
                     <br><br>
                     <div id="address">
                         <p>
                             <strong>'.$location_details->name.'</strong><br>
                             Address: '.$location_details->city.'<br>
                             GST REG NO: '.$location_details->uen.'<br>
                             Closing Report from '.$today.' to '.$tomorrow.'<br>
                         </p>
                     </div><!--end address-->
     
                     <div id="content">
                             <hr>
                             <strong>SALES DETAILS</strong><br>
                             <table class="items" width="1000" style="font-size: 16pt; border-collapse: collapse;" cellpadding="8">
                                 <tbody>
                                     '.$htmlRows.'
                                 </tbody>
                             </table>
                               <hr>
                                <table class="items" width="1000" style="font-size: 16pt; border-collapse: collapse;" cellpadding="8">
                                 <tbody>
                                    <tr class="odd">
                                        <td style="width: 50%">CASH IN</td>
                                        <td style="width: 50%; text-align: right;">'.number_format($cash_in, 2).'</td>
                                    </tr>
                                    <tr class="odd">
                                        <td style="width: 50%">CASH OUT</td>
                                        <td style="width: 50%; text-align: right;">'.number_format($cash_out, 2).'</td>
                                    </tr>
                                 </tbody>
                             </table>
                              <hr>
                             <table class="items" width="1000" style="font-size: 16pt; border-collapse: collapse;" cellpadding="8">
                                 <tbody>
                                     <tr class="odd">
                                         <td style="width: 50%">Total</td>
                                         <td style="width: 50%; text-align: right;">'.number_format($report_dtls['sales_result'][0]['collection_details_total'], 2).'</td>
                                     </tr>
                                 </tbody>
                             </table>
                             <hr>
                             <table class="items" width="1000" style="font-size: 16pt; border-collapse: collapse;" cellpadding="8">
                                 <tbody>
                                     <tr class="odd">
                                         <td style="width: 50%">GROSS SALES</td>
                                         <td style="width: 50%; text-align: right;">'.number_format($report_dtls['sales_result'][0]['gross_sales'], 2).'</td>
                                     </tr>
                                     <tr class="odd">
                                         <td style="width: 50%">Voucher Total</td>
                                         <td style="width: 50%; text-align: right;">'.number_format( $report_dtls['sales_result'][0]['total_voucher_amount'], 2).'</td>
                                     </tr>
                                     <tr class="odd">
                                         <td style="width: 50%">Total Tip</td>
                                         <td style="width: 50%; text-align: right;">'.number_format( $report_dtls['sales_result'][0]['total_tip_amount'], 2).'</td>
                                     </tr>
                                       <tr class="odd">
                                         <td style="width: 50%">Rounding Total</td>
                                         <td style="width: 50%; text-align: right;">'.number_format( $report_dtls['sales_result'][0]['rounding'], 2).'</td>
                                     </tr>
                                     <tr class="odd">
                                        <td style="width: 50%">Refund Total</td>
                                        <td style="width: 50%; text-align: right;">'.number_format( $report_dtls['sales_result'][0]['total_refund'], 2).'</td>
                                    </tr>
                                      <tr class="odd">
                                         <td style="width: 50%">Total FOC</td>
                                         <td style="width: 50%; text-align: right;">'.number_format($report_dtls['sales_result'][0]['total_foc'], 2).'</td>
                                     </tr>
                                    <tr class="odd">
                                        <td style="width: 50%">Total Reward Points</td>
                                        <td style="width: 50%; text-align: right;">'.number_format( $report_dtls['sales_result'][0]['customer_reward'], 2).'</td>
                                    </tr>
                                     <tr class="odd">
                                         <td style="width: 50%">Item Discount</td>
                                         <td style="width: 50%; text-align: right;">'.number_format($report_dtls['sales_result'][0]['item_discount'], 2).'</td>
                                     </tr>
                                     '.$discountHtmlRows.'
                                     <tr class="odd">
                                         <td style="width: 50%">DISCOUNT TOTAL</td>
                                         <td style="width: 50%; text-align: right;">'.number_format($report_dtls['sales_result'][0]['discount_total'], 2).'</td>
                                     </tr>
                                      <tr class="odd">
                                         <td style="width: 50%">Total refund credit note</td>
                                         <td style="width: 50%; text-align: right;">'.number_format($total_refund_credit_notes, 2).'</td>
                                     </tr>
                                      <tr class="odd">
                                         <td style="width: 50%">No of refund credit note</td>
                                         <td style="width: 50%; text-align: right;">'.$no_of_refund_credit_notes.'</td>
                                     </tr>
                                 </tbody>
                             </table>
                             <hr>
                             <table class="items" width="1000" style="font-size: 16pt; border-collapse: collapse;" cellpadding="8">
                                 <tbody>
                                     <tr class="odd">
                                         <td style="width: 50%">'.$service_charge.'% SVC.C</td>
                                         <td style="width: 50%; text-align: right;">'.number_format($service_charge_amount, 2).'</td>
                                     </tr>
                                     <tr class="odd">
                                         <td style="width: 50%">'.$gst_rate .'% GST</td>
                                         <td style="width: 50%; text-align: right;">'.number_format($gst_amount, 2).'</td>
                                     </tr>
                                 </tbody>
                             </table>
                             <hr>
                             <table class="items" width="1000" style="font-size: 16pt; border-collapse: collapse;" cellpadding="6">
                                <tbody>
                                    <tr class="odd">
                                        <td style="width: 50%">NET SALES</td>
                                    </tr>
                                    <tr class="odd">
                                        <td style="width: 50%; font-size: 12pt;">Exclusive of GST</td>
                                        <td style="width: 50%; text-align: right;">'.number_format($net_sales, 2).'</td>
                                    </tr>
                                    <tr class="odd">
                                        <td style="width: 50%">Total Collection</td>
                                    </tr>
                                     <tr class="odd">
                                        <td style="width: 50%; font-size: 12pt;">Inclusive of GST</td>
                                        <td style="width: 50%; text-align: right;">'.number_format($report_dtls['sales_result'][0]['total_collection'], 2).'</td>
                                    </tr>                                 
                                </tbody>
                            </table>
                             <hr>
                         </div>
                         <br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
                         <div id="content">
                         <br><br>
                         <strong style="text-transform: uppercase">Product Z Report</strong><br><br>
                         <div>
                            <table>
                            <tr><td></td></tr>
                            <tr><td>UP: Unit Price</td></tr>
                            <tr><td>TUP: Total Unit Price</td></tr>
                            <tr><td>DPU: Discount Per Unit</td></tr>
                            <tr><td>TD: Total Discount</td></tr>
                            <tr><td></td></tr>
                            </table>
                        </div>
                            ' . $salesRows . '
                         </div>
                          <div>
                          
                            <table class="items" width="1000" style="font-size: 23pt; border-collapse: collapse;" cellpadding="8">
                            <thead>
                                <tr><td></td><br></tr>
                                <tr>
                                </tr>
                                <tr><td></td></tr>
                            </thead>
                            <tbody>
                                <tr style="width: 100%">
                                    <td style="width: 30%;max-width: 100px; font-size: 15pt;"><strong>Overall Quantity: </strong>' . $overall_quantity .'</td>
                                 
                                    <td style="width: 30%; font-size: 15pt;"><strong> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Overall Discount: </strong> '. $overall_total_discount. '</td>
                              
                                    <td style="width: 30%; text-align: right; font-size: 15pt;"><strong>Sub Total: </strong> ' . $overall_sub_total.'</td>
                                </tr>    
                                 <tr style="width: 100%">
                                    <td style="width: 33%; text-align: right; font-size: 15pt;"></td>
                                    <td style="width: 30%; text-align: right; font-size: 15pt;"></td>
                                    <td style="width: 50%; text-align: right; font-size: 15pt;"><strong>Rounding: </strong> ' . number_format($report_dtls['sales_result'][0]['rounding'], 2).'</td>
                                </tr>    
                                 <tr style="width: 100%">
                                    <td style="width: 33%; text-align: right; font-size: 15pt;"></td>
                                    <td style="width: 30%; text-align: right; font-size: 15pt;"></td>
                                    <td style="width: 50%; text-align: right; font-size: 15pt;"><strong>Total: </strong> ' . number_format($report_dtls['sales_result'][0]['total_collection'], 2).'</td>
                                </tr>    
                               
                            </tbody>
                        </table>
                            </div>
                     </body>';
    
                $mpdf = new \Mpdf\Mpdf([
                        'mode' => 'utf-8', 
                        'autoScriptToLang' => true,
                        'autoLangToFont' => true,
                        'autoVietnamese' => true,
                        'autoArabic' => true,
                        'margin_top' => 8,
                        'margin_bottom' => 8,
                        'format' => 'A4'
                    ]);
                $mpdf->WriteHTML($html);
                $mpdf->Output(public_path('uploads/documents/report.pdf'),'F');
    
                return ["url"=>asset('uploads/documents/report.pdf')];
            } else {
                return "false";
            }
        }
        catch(Exception $e) {
            echo 'Caught exception: ',  $e->getMessage(), "\n";
        }
    }

}
