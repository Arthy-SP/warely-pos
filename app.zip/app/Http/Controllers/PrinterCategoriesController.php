<?php

namespace App\Http\Controllers;

use App\PrinterCategories;
use App\PrinterModifiers;
use App\BusinessLocation;
use App\Category;
use App\Product;
use Datatables;
use Illuminate\Http\Request;

class PrinterCategoriesController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        if (!auth()->user()->can('access_printers')) {
             abort(403, 'Unauthorized action.');
        }

        if (request()->ajax()) {
            $business_id = request()->session()->get('user.business_id');

            $printerCategories = PrinterCategories::join('business_locations', 'business_locations.id', '=', 'printer_categories.location_id')
                                 ->select('printer_categories.id','printer_categories.name','business_locations.name AS location_name')
                                 ->where('printer_categories.business_id', $business_id);
            
            // $productModifiers = Product::select('products.id', 'products.name')
            //                             ->where('products.business_id', $business_id)
            //                             ->where('products.type', 'modifier')
            //                             ->whereNull('products.deleted_at')
            //                             ->get();

            return Datatables::of($printerCategories)
                // ->editColumn('capability_profile', function ($row) {
                //     return Printer::capability_profile_srt($row->capability_profile);
                // })
                // ->editColumn('connection_type', function ($row) {
                //     return Printer::connection_type_str($row->connection_type);
                // })
                ->addColumn(
                    'action',
                    '@can("printer.update")
                    <a href="{{action(\'PrinterCategoriesController@edit\', [$id])}}" class="btn btn-xs btn-primary"><i class="glyphicon glyphicon-edit"></i> @lang("messages.edit")</a>
                        &nbsp;
                    @endcan
                    @can("printer.delete")
                        <button data-href="{{action(\'PrinterCategoriesController@destroy\', [$id])}}" class="btn btn-xs btn-danger delete_printer_button"><i class="glyphicon glyphicon-trash"></i> @lang("messages.delete")</button>
                    @endcan'
                )
                ->removeColumn('id')
                // ->rawColumns([7])
                ->escapeColumns(['action'])
                ->make(false);
        }

        return view('printer_categories.index');
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        if (!auth()->user()->can('access_printers')) {
             abort(403, 'Unauthorized action.');
        }

        $business_id = request()->session()->get('user.business_id');
        $business_locations = BusinessLocation::forDropdown($business_id);
        $product_category = Category::forDropdown($business_id,'product');
        $product_modifiers = Category::forDropdownModifiers($business_id,'modifier');
        $products = Category::forDropdownProducts($business_id,'product');
        
        return view('printer_categories.create')
            ->with(compact('business_locations','product_category','product_modifiers','products'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        if (!auth()->user()->can('access_printers')) {
             abort(403, 'Unauthorized action.');
        }

        try {
            $business_id = $request->session()->get('user.business_id');
            $input = $request->only(['name', 'business_id', 'location_id']);

            $input['business_id'] = $business_id;
            $input['created_by'] = $request->session()->get('user.id');
            ;

            $printer = new PrinterCategories;
            $printer->fill($input)->save();

            //Add product locations
            $product_category = $request->input('product_category');
            if (!empty($product_category)) {
                $printer->product_category()->sync($product_category);
            }

            $product_modifier = $request->input('product_modifiers');
            if (!empty($product_modifier)) {
                $printer->productModifiers()->sync($product_modifier);
            }

            $products = $request->input('products');
            if (!empty($products)) {
                $printer->products()->sync($products);
            }

            $output = ['success' => 1,
                            'msg' => __('Printer added successfully')
                        ];
        } catch (\Exception $e) {
            \Log::emergency("File:" . $e->getFile(). "Line:" . $e->getLine(). "Message:" . $e->getMessage());
            
            $output = ['success' => false,
                            'msg' => __("messages.something_went_wrong")
                        ];
        }

        return redirect('printer_categories')->with('status', $output);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        if (!auth()->user()->can('access_printers')) {
             abort(403, 'Unauthorized action.');
        }

        $business_id = request()->session()->get('user.business_id');
        $printer_categories = PrinterCategories::find($id);
        
        $product_category = Category::forDropdown($business_id,'product');
        $product_modifiers = Category::forDropdownModifiers($business_id,'modifier');
        $products = Category::forDropdownProducts($business_id,'product');
        // $product_modifiers = Category::forDropdown2($business_id,'modifier');
        
        \Log::info($product_modifiers);
        \Log::info($printer_categories->productModifiers);

        return view('printer_categories.edit')
            ->with(compact('printer_categories','product_category','product_modifiers','products'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        if (!auth()->user()->can('access_printers')) {
             abort(403, 'Unauthorized action.');
        }

        try {
            $input = $request->only(['name']);
            $business_id = $request->session()->get('user.business_id');

            $printer = PrinterCategories::findOrFail($id);
            
            // $modifiers = Product::findOrFail($id);
            // dd($modifiers);
            $printer->fill($input)->save();

            //Add product locations
            $product_category = !empty($request->input('product_category')) ?
                                $request->input('product_category') : [];

            $product_modifier = !empty($request->input('product_modifiers')) ?
            $request->input('product_modifiers') : [];

            $products = !empty($request->input('products')) ?
            $request->input('products') : [];

            $printer->product_category()->sync($product_category);
            $printer->productModifiers()->sync($product_modifier);
            $printer->products()->sync($products);

            $output = ['success' => true,
                        'msg' => __("Category updated successfully")
                        ];
        } catch (\Exception $e) {
            \Log::emergency("File:" . $e->getFile(). "Line:" . $e->getLine(). "Message:" . $e->getMessage());
        
            $output = ['success' => false,
                        'msg' => __("messages.something_went_wrong")
                    ];
        }

        return redirect('printer_categories')->with('status', $output);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        if (!auth()->user()->can('access_printers')) {
             abort(403, 'Unauthorized action.');
        }
        
        if (request()->ajax()) {
            try {

                $business_id = request()->user()->business_id;

                $printer = PrinterCategories::findOrFail($id);
                $printer->delete();

                $output = ['success' => true,
                            'msg' => __("Printer deleted successfully")
                            ];
            } catch (\Exception $e) {
                \Log::emergency("File:" . $e->getFile(). "Line:" . $e->getLine(). "Message:" . $e->getMessage());
            
                $output = ['success' => false,
                            'msg' => __("messages.something_went_wrong")
                        ];
            }

            return $output;
        }
    }
}