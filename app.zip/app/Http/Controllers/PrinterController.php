<?php

namespace App\Http\Controllers;

use App\Printer;
use App\ApiPrinter;
use App\PrinterCategories;
use App\BusinessLocation;
use Datatables;
use App\Terminal;
use Illuminate\Http\Request;

// OLD RECEIPT PRINTER
// class PrinterController extends Controller
// {
//     /**
//      * Display a listing of the resource.
//      *
//      * @return \Illuminate\Http\Response
//      */
//     public function index()
//     {
//         if (!auth()->user()->can('access_printers')) {
//              abort(403, 'Unauthorized action.');
//         }

//         if (request()->ajax()) {
//             $business_id = request()->session()->get('user.business_id');

//             $printer = Printer::where('business_id', $business_id)
//                         ->select(['name', 'connection_type',
//                             'capability_profile', 'char_per_line', 'ip_address', 'port', 'path', 'id']);

//             return Datatables::of($printer)
//                 ->editColumn('capability_profile', function ($row) {
//                     return Printer::capability_profile_srt($row->capability_profile);
//                 })
//                 ->editColumn('connection_type', function ($row) {
//                     return Printer::connection_type_str($row->connection_type);
//                 })
//                 ->addColumn(
//                     'action',
//                     '@can("printer.update")
//                     <a href="{{action(\'PrinterController@edit\', [$id])}}" class="btn btn-xs btn-primary"><i class="glyphicon glyphicon-edit"></i> @lang("messages.edit")</a>
//                         &nbsp;
//                     @endcan
//                     @can("printer.delete")
//                         <button data-href="{{action(\'PrinterController@destroy\', [$id])}}" class="btn btn-xs btn-danger delete_printer_button"><i class="glyphicon glyphicon-trash"></i> @lang("messages.delete")</button>
//                     @endcan'
//                 )
//                 ->removeColumn('id')
//                 ->rawColumns([7])
//                 ->make(false);
//         }

//         return view('printer.index');
//     }

//     /**
//      * Show the form for creating a new resource.
//      *
//      * @return \Illuminate\Http\Response
//      */
//     public function create()
//     {
//         if (!auth()->user()->can('access_printers')) {
//              abort(403, 'Unauthorized action.');
//         }

//         $capability_profiles = Printer::capability_profiles();
//         $connection_types = Printer::connection_types();

//         return view('printer.create')
//             ->with(compact('capability_profiles', 'connection_types'));
//     }

//     /**
//      * Store a newly created resource in storage.
//      *
//      * @param  \Illuminate\Http\Request  $request
//      * @return \Illuminate\Http\Response
//      */
//     public function store(Request $request)
//     {
//         if (!auth()->user()->can('access_printers')) {
//              abort(403, 'Unauthorized action.');
//         }

//         try {
//             $business_id = $request->session()->get('user.business_id');
//             $input = $request->only(['name', 'connection_type', 'capability_profile', 'ip_address', 'port', 'path', 'char_per_line']);

//             $input['business_id'] = $business_id;
//             $input['created_by'] = $request->session()->get('user.id');
//             ;

//             if ($input['connection_type'] == 'network') {
//                 $input['path'] = '';
//             } elseif (in_array($input['connection_type'], ['windows', 'linux'])) {
//                 $input['ip_address'] = '';
//                 $input['port'] = '';
//             }

//             $printer = new Printer;
//             $printer->fill($input)->save();

//             $output = ['success' => 1,
//                             'msg' => __('printer.added_success')
//                         ];
//         } catch (\Exception $e) {
//             \Log::emergency("File:" . $e->getFile(). "Line:" . $e->getLine(). "Message:" . $e->getMessage());
            
//             $output = ['success' => false,
//                             'msg' => __("messages.something_went_wrong")
//                         ];
//         }

//         return redirect('printers')->with('status', $output);
//     }

//     /**
//      * Display the specified resource.
//      *
//      * @param  int  $id
//      * @return \Illuminate\Http\Response
//      */
//     public function show($id)
//     {
//         //
//     }

//     /**
//      * Show the form for editing the specified resource.
//      *
//      * @param  int  $id
//      * @return \Illuminate\Http\Response
//      */
//     public function edit($id)
//     {
//         if (!auth()->user()->can('access_printers')) {
//              abort(403, 'Unauthorized action.');
//         }

//         $business_id = request()->session()->get('user.business_id');
//         $printer = Printer::where('business_id', $business_id)->find($id);

//         $capability_profiles = Printer::capability_profiles();
//         $connection_types = Printer::connection_types();

//         return view('printer.edit')
//             ->with(compact('printer', 'capability_profiles', 'connection_types'));
//     }

//     /**
//      * Update the specified resource in storage.
//      *
//      * @param  \Illuminate\Http\Request  $request
//      * @param  int  $id
//      * @return \Illuminate\Http\Response
//      */
//     public function update(Request $request, $id)
//     {
//         if (!auth()->user()->can('access_printers')) {
//              abort(403, 'Unauthorized action.');
//         }

//         try {
//             $input = $request->only(['name', 'connection_type', 'capability_profile', 'ip_address', 'port', 'path', 'char_per_line']);
//             $business_id = $request->session()->get('user.business_id');

//             $printer = Printer::where('business_id', $business_id)->findOrFail($id);

//             if ($input['connection_type'] == 'network') {
//                 $input['path'] = '';
//             } elseif (in_array($input['connection_type'], ['windows', 'linux'])) {
//                 $input['ip_address'] = '';
//                 $input['port'] = '';
//             }

//             $printer->fill($input)->save();

//             $output = ['success' => true,
//                         'msg' => __("printer.updated_success")
//                         ];
//         } catch (\Exception $e) {
//             \Log::emergency("File:" . $e->getFile(). "Line:" . $e->getLine(). "Message:" . $e->getMessage());
        
//             $output = ['success' => false,
//                         'msg' => __("messages.something_went_wrong")
//                     ];
//         }

//         return redirect('printers')->with('status', $output);
//     }

//     /**
//      * Remove the specified resource from storage.
//      *
//      * @param  int  $id
//      * @return \Illuminate\Http\Response
//      */
//     public function destroy($id)
//     {
//         if (!auth()->user()->can('access_printers')) {
//              abort(403, 'Unauthorized action.');
//         }
        
//         if (request()->ajax()) {
//             try {
//                 $business_id = request()->user()->business_id;

//                 $printer = Printer::where('business_id', $business_id)->findOrFail($id);
//                 $printer->delete();

//                 $output = ['success' => true,
//                             'msg' => __("printer.deleted_success")
//                             ];
//             } catch (\Exception $e) {
//                 \Log::emergency("File:" . $e->getFile(). "Line:" . $e->getLine(). "Message:" . $e->getMessage());
            
//                 $output = ['success' => false,
//                             'msg' => __("messages.something_went_wrong")
//                         ];
//             }

//             return $output;
//         }
//     }
// }

class PrinterController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        if (!auth()->user()->can('access_printers')) {
             abort(403, 'Unauthorized action.');
        }

        if (request()->ajax()) {
            $business_id = request()->session()->get('user.business_id');

            $printer = ApiPrinter::join('business_locations', 'business_locations.id', '=', 'api_printer.business_location_id')
                                 ->leftjoin('terminals', 'terminals.id', '=' , 'api_printer.terminal_id')
                                 ->select('api_printer.id','api_printer.name','business_locations.name AS location_name','api_printer.connection','api_printer.address','terminals.name as terminal_name')
                                 ->where('business_locations.business_id', $business_id);

            return Datatables::of($printer)
                // ->editColumn('capability_profile', function ($row) {
                //     return Printer::capability_profile_srt($row->capability_profile);
                // })
                // ->editColumn('connection_type', function ($row) {
                //     return Printer::connection_type_str($row->connection_type);
                // })
                ->addColumn(
                    'action',
                    '@can("printer.update")
                    <a href="{{action(\'PrinterController@edit\', [$id])}}" class="btn btn-xs btn-primary"><i class="glyphicon glyphicon-edit"></i> @lang("messages.edit")</a>
                        &nbsp;
                    @endcan
                    @can("printer.delete")
                        <button data-href="{{action(\'PrinterController@destroy\', [$id])}}" class="btn btn-xs btn-danger delete_printer_button"><i class="glyphicon glyphicon-trash"></i> @lang("messages.delete")</button>
                    @endcan'
                )
                ->removeColumn('id')
                // ->rawColumns([7])
                ->escapeColumns(['action'])
                ->make(false);
        }

        return view('printer.index');
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        if (!auth()->user()->can('access_printers')) {
             abort(403, 'Unauthorized action.');
        }

        $business_id = request()->session()->get('user.business_id');

        $capability_profiles = Printer::capability_profiles();
        $connection_types = ApiPrinter::connection_types();
        $business_locations = BusinessLocation::forDropdown($business_id);
        $printer_categories = PrinterCategories::forDropdown($business_id);
        $terminals = Terminal::forDropdown($business_id);
        return view('printer.create')
            ->with(compact('capability_profiles', 'connection_types', 'business_locations', 'printer_categories','terminals'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        if (!auth()->user()->can('access_printers')) {
             abort(403, 'Unauthorized action.');
        }

        try {
            $business_id = $request->session()->get('user.business_id');
            $input = $request->only(['name', 'business_location_id', 'connection', 'address', 'printer_group_id', 'print_receipt', 'remove_receipt_title', 'remove_receipt_amount_section','terminal_id']);

            $input['business_id'] = $business_id;
            $input['created_by'] = $request->session()->get('user.id');

            if (empty($input['print_receipt']) || $input['connection'] == 'wifi') {
                $input['print_receipt'] = 0;
            } else {
                $input['print_receipt'] = 1;
            }

            $input['remove_receipt_title'] = (!empty($input['remove_receipt_title']) &&  $input['remove_receipt_title'] == 1) ? 1 : 0;
            $input['remove_receipt_amount_section'] = (!empty($input['remove_receipt_amount_section']) &&  $input['remove_receipt_amount_section'] == 1) ? 1 : 0;
            
            $apiPrinter = ApiPrinter::where("business_location_id", $input['business_location_id'])
            ->where(
                function($query) use ($input) {
                  return $query
                         ->where("name", $input['name'])
                         ->orWhere("address", $input['address']);
            })
            ->first();
            if( empty($apiPrinter) ) {
            $printer = new ApiPrinter;
            $printer->fill($input)->save();

            // //Add product locations
            // $printer_categories = $request->input('printer_categories');
            // if (!empty($printer_categories)) {
            //     $printer->printer_categories()->sync($printer_categories);
            // }

            $output = ['success' => 1,
                            'msg' => __('printer.added_success')
                        ];
            }
            else{
                $output = ['success' => 0,
                'msg' => __('Printer is already exists with provided name and address')
            ];
            }
            
        } catch (\Exception $e) {
            \Log::emergency("File:" . $e->getFile(). "Line:" . $e->getLine(). "Message:" . $e->getMessage());
            
            $output = ['success' => false,
                            'msg' => __("messages.something_went_wrong")
                        ];
        }

        return redirect('printers')->with('status', $output);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        if (!auth()->user()->can('access_printers')) {
             abort(403, 'Unauthorized action.');
        }

        $business_id = request()->session()->get('user.business_id');
        $printer = ApiPrinter::find($id);

        $capability_profiles = Printer::capability_profiles();
        $connection_types = ApiPrinter::connection_types();
        $printer_categories = PrinterCategories::forDropdown($business_id);
        $terminals = Terminal::forDropdown($printer->business_location_id);
        return view('printer.edit')
            ->with(compact('printer', 'capability_profiles', 'connection_types', 'printer_categories', 'terminals'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        if (!auth()->user()->can('access_printers')) {
             abort(403, 'Unauthorized action.');
        }
        try {
            $input = $request->only(['name', 'connection', 'address', 'printer_group_id', 'print_receipt', 'remove_receipt_title', 'remove_receipt_amount_section', 'terminal_id','business_location_id']);
            $business_id = $request->session()->get('user.business_id');
            
            if (empty($input['print_receipt']) || $input['connection'] == 'wifi') {
                $input['print_receipt'] = 0;
            } else {
                $input['print_receipt'] = 1;
            }

            $input['remove_receipt_title'] = (!empty($input['remove_receipt_title']) &&  $input['remove_receipt_title'] == 1) ? 1 : 0;
            $input['remove_receipt_amount_section'] = (!empty($input['remove_receipt_amount_section']) &&  $input['remove_receipt_amount_section'] == 1) ? 1 : 0;
            // return $input;
            $apiPrinter = ApiPrinter::where("business_location_id", $input['business_location_id'])
            ->where(
                function($query) use ($input) {
                    return $query
                           ->where("name", $input['name'])
                           ->orWhere("address", $input['address']);
                })
            ->where("id", "!=", $id)
            ->first();
            if( empty($apiPrinter) ) {
            $printer = ApiPrinter::findOrFail($id);
            $printer->fill($input)->save();

            // //Add product locations
            // $printer_categories = !empty($request->input('printer_categories')) ?
            //                     $request->input('printer_categories') : [];
            // $printer->printer_categories()->sync($printer_categories);

            $output = ['success' => true,
                        'msg' => __("printer.updated_success")
                        ];
            }
            else{
                $output = ['success' => false,
                'msg' => __('Printer is already exists with provided name and address')
            ];
            }
        } catch (\Exception $e) {
            \Log::emergency("File:" . $e->getFile(). "Line:" . $e->getLine(). "Message:" . $e->getMessage());
        
            $output = ['success' => false,
                        'msg' => __("messages.something_went_wrong")
                    ];
        }

        return redirect('printers')->with('status', $output);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        if (!auth()->user()->can('access_printers')) {
             abort(403, 'Unauthorized action.');
        }
        
        if (request()->ajax()) {
            try {
                $business_id = request()->user()->business_id;

                $printer = ApiPrinter::findOrFail($id);
                $printer->delete();

                $output = ['success' => true,
                            'msg' => __("printer.deleted_success")
                            ];
            } catch (\Exception $e) {
                \Log::emergency("File:" . $e->getFile(). "Line:" . $e->getLine(). "Message:" . $e->getMessage());
            
                $output = ['success' => false,
                            'msg' => __("messages.something_went_wrong")
                        ];
            }

            return $output;
        }
    }
    public function fetchTerminals(Request $request)
    {
        $locationId = $request->input('location_id');
        $terminals = Terminal::where('location_id', $locationId)->pluck('name', 'id');
        return view('terminal.partials.terminals', compact('terminals'));
    }
}