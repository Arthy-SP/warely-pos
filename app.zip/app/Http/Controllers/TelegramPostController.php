<?php

namespace App\Http\Controllers;

use App\Campaign;
use App\CampaignConfiguration;
use App\CampaignTelegram;
use App\TelegramChannel;
use App\TelegramPost;
use App\TelegramToken;
use Redirect;
use File;
use GuzzleHttp\Client;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;

use Datatables;

class TelegramPostController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        if (!auth()->user()->can('telegram.view') && !auth()->user()->can('telegram.create')) {
            abort(403, 'Unauthorized action.');
        }
        if(request()->ajax()){
            $business_id = request()->session()->get('user.business_id');

            $telegramPost = TelegramPost::where('business_id', $business_id)
                ->select('id', 'image', 'post_description', 'channel_id', 'scheduled_at', 'is_sended');
            return Datatables::of($telegramPost)
            ->addColumn(
                'action',
                    '<a href="{{action(\'TelegramPostController@edit\', [$id])}}" class="btn btn-xs btn-primary"><i class="glyphicon glyphicon-edit"></i> @lang("messages.edit")</a>
                    &nbsp;
                    <button type="button" data-href="{{action(\'TelegramPostController@destroy\', [$id])}}" class="btn btn-xs btn-danger delete_telegram_post_button" ><i class="glyphicon glyphicon-trash"></i> @lang("messages.delete")</button>
                    '
            )
            ->editColumn('is_sended', function ($row) {
                if ($row->is_sended == 0) {
                    return ' <small class="label pull-center bg-red no-print">' . "Scheduled". '</small>';
                } else {
                    return ' <small class="label pull-center bg-green no-print">'."Delivered".'</small>';
                }
            })
            ->editColumn('image', function ($row) {
                return '<div style="display: flex;"><img src="' . $row->image . '" alt="Product image" class="product-thumbnail-small"></div>';
            })
            ->editColumn('channel_id', function ($row) {
                $name = '';
                foreach ($row->channel_id as $key => $id) {
                    $channel = TelegramChannel::find($id);
                    if($key < count($row->channel_id)-1){
                        $name = $name.$channel->name.", ";
                    }else{
                        $name = $name.$channel->name;
                    }
                }
                return $name;
            })
            ->editColumn('post_description', function ($row) {
                $caption = substr($row->post_description, 0, 60);
                return $caption."........." ;
            })
            ->rawColumns([1, 2, 3, 4, 5, 6])
            ->make(false);
        }
        return view('telegram_post.index');
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $business_id = request()->session()->get('user.business_id');
        $bot_tokens = TelegramToken::where('business_id', $business_id)->pluck('name', 'id');
        $configurations = CampaignConfiguration::with('configured_channels')->get();
        $channel_configuration= [];
        foreach ($configurations as $configuration) {
            $channels = $configuration->configured_channels->pluck('name', 'id')->implode(', ');
            $channel_configuration[$configuration->id] = "{$configuration->name} ({$channels})";
        }
        $campaign_ids=[];
        return view('telegram_post.create')->with(compact('bot_tokens', 'channel_configuration'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\TelegramPost  $telegramPost
     * @return \Illuminate\Http\Response
     */
    public function show(TelegramPost $telegramPost)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\TelegramPost  $telegramPost
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        if (!auth()->user()->can('telegram_channel.update')) {
            abort(403, 'Unauthorized action.');
        }
            $business_id = request()->session()->get('user.business_id');
            $telegram_post = TelegramPost::where('business_id', $business_id)->find($id);
            
            $caption = $telegram_post->post_description;
            $caption = str_replace(" \r\n", "<br />", $caption);
            
            $telegram_post->caption = $caption;
            
            $bot_tokens = TelegramToken::where('business_id', $business_id)->pluck('name', 'id');
            $configurations = CampaignConfiguration::with('configured_channels')->get();
            $channel_configuration= [];
            foreach ($configurations as $configuration) {
                $channels = $configuration->configured_channels->pluck('name', 'id')->implode(', ');
                $channel_configuration[$configuration->id] = "{$configuration->name} ({$channels})";
            }
            
            return view('telegram_post.edit')
                ->with(compact('bot_tokens', 'channel_configuration', 'telegram_post'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\TelegramPost  $telegramPost
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $business_id = request()->session()->get('user.business_id');
        $input_data = $request->only(['bot_token_id', 'configuration_id', 'post_description', 'campaign_id']);

        $base_url = "https://api.telegram.org";
        $token_data = TelegramToken::find($input_data['bot_token_id']);
        $token = $token_data->token_id;
        
        $configuration_data = CampaignConfiguration::with('configured_channels')->find($input_data['configuration_id']);
        
        $channel_ids=[];
        
        foreach ($configuration_data->configured_channels as $key => $data) {
            $bot_is_admin = $this->checkBotIsAdmin($base_url, $token, $data->channel_id);
            if($bot_is_admin){
                array_push($channel_ids, $data->id);
            }else{
                $output = [
                    "success" => 0,
                    "msg" => "Bot is not an administrator of ".$data->name." channel."
                ];
                return redirect('telegram-post')->with('status', $output);
            }
        }

        $input_data['channel_id'] = $channel_ids; 
        if ($bot_is_admin) {
            if ($request->submit_type === "updatePost") {
                
                //check date and time 
                if (empty($request->post_scheduled_time)) {
                    $output = [
                        "success" => 0,
                        "msg" => "Please select date and time."
                    ];
                    return redirect('telegram-post')->with('status', $output);
                }
                $post = TelegramPost::find($id);
                if($request->hasFile('image')){
                    $upload_image = $this->uploadImageAws($request);
                }else{
                    $upload_image = $post->image;
                }

                if ($upload_image) {
                    $caption = str_replace("<br />", " \r\n", $input_data['post_description']);
                    $caption = str_replace("&nbsp;", " ", $caption);
                    $caption = str_replace("<p>", "", $caption);
                    $caption = str_replace("</p>", " ", $caption);
                    
                    $input_date = \DateTime::createFromFormat('d/m/Y H:i', $request->post_scheduled_time);
                    $post_date = $input_date->format('Y-m-d H:i:s');
                    $input_data['scheduled_at'] = $post_date;
                    $input_data['post_description'] = $caption;
                    $input_data['image'] = $upload_image;
                    $input_data['business_id'] = $business_id;

                    $post_update = $post->update($input_data);
        
                    if (!empty($post_update)) {
                        $output = [
                            "success" => 1,
                            "msg" => "Post updated successfully."
                        ];
                    } else {
                        $output = [
                            "success" => 0,
                            "msg" => "Post updating failed please try again."
                        ];
                    }
                } else {
                    $output = [
                        "success" => 0,
                        "msg" => "Image upload failed please try again."
                    ];
                }
            } else {
                $output = [
                    "success" => 0,
                    "msg" => "Something went wrong please try again."
                ];
            }
        } else {
            $output = [
                "success" => 0,
                "msg" => "Bot is not admin with this channel you can't post."
            ];
        }
        return redirect('telegram-post')->with('status', $output);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\TelegramPost  $telegramPost
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        if (request()->ajax()) {
            try {
                $post = TelegramPost::find($id);
                $post->delete();
                
                $output = ['success' => true,
                            'msg' => 'successfully deleted'
                            ];
             } catch (\Exception $e) {
                \Log::emergency("File:" . $e->getFile(). "Line:" . $e->getLine(). "Message:" . $e->getMessage());

                $output = ['success' => false,
                            'msg' => __("messages.something_went_wrong")
                        ];
            } 

            return $output;
        }
    }


    public function sendPost(Request $request)
    {
        $business_id = request()->session()->get('user.business_id');
        $input_data = $request->only(['bot_token_id', 'channel_or_group_id', 'post_description', 'campaign_id', 'configuration_id']);
        $base_url = "https://api.telegram.org";
        $token_data = TelegramToken::find($input_data['bot_token_id']);
        $token = $token_data->token_id;
        $bot_username = $token_data->username;
        
        $configuration_data = CampaignConfiguration::with('configured_channels')->find($input_data['configuration_id']);

        foreach($configuration_data->configured_channels as $data){
            $bot_is_admin = $this->checkBotIsAdmin($base_url, $token, $data->channel_id);
            if(!$bot_is_admin){
                $output = [
                    "success" => 0,
                    "msg" => "Bot is not admin with ".$data->name." channel you can't post."
                ];
                return redirect('telegram-post')->with('status', $output);
            }
        }
        if(!empty($configuration_data->campaign_id)){
            $campaign_id = $configuration_data->campaign_id;
        }
        try {
            if ($bot_is_admin) {
                if ($request->submit_type === "sendPost") {
                    $upload_image = $this->uploadImageAws($request);
                    if ($upload_image){
                        $caption = str_replace("<br />", " \r\n", $input_data['post_description']);
                        $caption = str_replace("&nbsp;", " ", $caption);
                        $caption = str_replace("<p>", "", $caption);
                        $caption = str_replace("</p>", " ", $caption);

                        $channel_ids = [];
                        foreach($configuration_data->configured_channels as $data){
                            $url = "https://t.me/".$bot_username."?start=10=".$campaign_id;
                            $client = new Client();
                            $markupButton = [
                                'inline_keyboard' => [
                                    [
                                        [
                                            'text' => 'Redeem Coupon', 
                                            'url' => $url
                                        ],
                                    ],
                                ],
                            ];
                            $response = $client->request('POST', $base_url . ":443/bot" . $token . "/sendPhoto", [
                                'multipart' => [
                                    [
                                        'name' => 'chat_id',
                                        'contents' => $data->channel_id,
                                    ],
                                    [
                                        'name' => 'photo',
                                        //'contents' => fopen('https://i.pcmag.com/imagery/articles/00Cx7vFIetxCuKxQeqPf8mi-66..v1667334873.jpg', 'r'), // Replace with your image file
                                        'contents' => fopen($upload_image, 'r'), // Replace with your image file
                                        'filename' => 'image.jpg',
                                    ],
                                    [
                                        'name' => 'caption',
                                        'contents' => $caption,
                                    ],
                                    [
                                        'name' => 'parse_mode',
                                        'contents' => 'HTML', // Optional: Markdown | HTML
                                    ],
                                    [
                                        'name' => 'reply_markup',
                                        'contents' => json_encode($markupButton),
                                    ],
                                ],
                            ]);

                            $json = json_decode($response->getBody());
                            array_push($channel_ids, $data->id);
                        }
                        if ($json->ok == "true") {
                            $input_date = \DateTime::createFromFormat('d/m/Y H:i', $request->post_scheduled_time);
                            $post_date = $input_date->format('Y-m-d H:i:s');
                            $input_data['scheduled_at'] = $post_date;
                            $input_data['post_description'] = $caption;
                            $input_data['image'] = $upload_image;
                            $input_data['is_sended'] = 1;
                            $input_data['business_id'] = $business_id;
                            $input_data['channel_id'] = $channel_ids;
                            $post_scheduled = TelegramPost::create($input_data);
                            
                            $output = [
                                "success" => 1,
                                "msg" => "Post send successfully."
                            ];
                        } else {
                            $output = [
                                "success" => 0,
                                "msg" => "Post sent failed please try again."
                            ];
                        }
                    } else {
                        $output = [
                            "success" => 0,
                            "msg" => "Image upload failed please try again."
                        ];
                    }
                    return redirect('telegram-post')->with('status', $output);
                }

                if ($request->submit_type === "schedulePost") {
                    
                    if (empty($request->post_scheduled_time)) {
                        $output = [
                            "success" => 0,
                            "msg" => "Please select date and time."
                        ];
                        // return $output;
                        return redirect('telegram-post')->with('status', $output);
                    }

                    $upload_image = $this->uploadImageAws($request);
                    if ($upload_image) {
                        $caption = str_replace("<br />", " \r\n", $input_data['post_description']);
                        $caption = str_replace("&nbsp;", " ", $caption);
                        $caption = str_replace("<p>", "", $caption);
                        $caption = str_replace("</p>", " ", $caption);
                        
                        $input_date = \DateTime::createFromFormat('d/m/Y H:i', $request->post_scheduled_time);
                        $post_date = $input_date->format('Y-m-d H:i:s');
                        $input_data['scheduled_at'] = $post_date;
                        $input_data['post_description'] = $caption;
                        $input_data['image'] = $upload_image;
                        $input_data['business_id'] = $business_id;
                        $channel_ids =[];
                        foreach($configuration_data->configured_channels as $data){
                            array_push($channel_ids, $data->id);
                        }
                        $input_data['channel_id'] = $channel_ids;
                        $post_scheduled = TelegramPost::create($input_data);
            
                        if (!empty($post_scheduled)) {
                            $output = [
                                "success" => 1,
                                "msg" => "Post scheduled successfully."
                            ];
                        } else {
                            $output = [
                                "success" => 0,
                                "msg" => "Post scheduled failed please try again."
                            ];
                        }
                    } else {
                        $output = [
                            "success" => 0,
                            "msg" => "Image upload failed please try again."
                        ];
                    }
                    return redirect('telegram-post')->with('status', $output);
                }
            } else {
                $output = [
                    "success" => 0,
                    "msg" => "Bot is not admin with this channel you can't post."
                ];
            }
        } catch (\Throwable $th) {
            \Log::info('Error Data----' . $th);
            $output = [
                "success" => 0,
                "msg" => "Something went wrong please try again."
            ];
        }
        return redirect('telegram-post')->with('status', $output);
    }


    
    public function uploadImageAws($request)
    {
        if ($request->hasFile('image')) {
            $file = $request->file('image');
            $extension = $file->getClientOriginalExtension(); // you can also use file name
            $fileName = time() . '.' . $extension;            
            // S3 destination path (folder and filename)
            $s3DestinationPath = config('constants.awsS3Env') . '/telegram-post-image/' . $fileName;

            // Upload the file to S3
            Storage::disk('s3')->put($s3DestinationPath, file_get_contents($file));
    
            // You can also specify access permissions like 'public' if needed
            Storage::disk('s3')->setVisibility($s3DestinationPath, 'public');
    
            $s3FileUrl = Storage::disk('s3')->url($s3DestinationPath);
            return $s3FileUrl;
        }
    }

    public function uploadImageLocal($request)
    {
        if ($request->hasFile('image')) {
            $file = $request->file('image');
            $extension = $file->getClientOriginalExtension(); // you can also use file name
            $fileName = time() . '.' . $extension;
            
            $path = public_path() . '/post_image';
            $file_path = url('post_image/' . $fileName);
            if (!file_exists($path)) {
                File::makeDirectory($path, $mode = 0777, true, true);
            }
            $upload = $file->move($path, $fileName);
            return $file_path;
        }
    }

    public function checkBotIsAdmin($base_url, $bot_token, $channel_id)
    {
        try {
            $client = new Client(['base_uri' => $base_url]);
            $response = $client->request('GET', "/bot" . $bot_token . "/getChatAdministrators?chat_id=" . $channel_id);
            $json = json_decode($response->getBody());
            if ($json->result[0]->status = "administrator") return true;
            else return false;
        } catch (\Exception $e) {
            return false;
        }
    }

    public function getAssociatedCampaigns(Request $request){
        if($request->ajax() && !empty($request->input('channel_id'))){
            $channel_id = $request->input('channel_id');
            $campaign_ids = CampaignTelegram::where('telegram_channel_id', $channel_id)->pluck("campaign_id");
            $campaigns=Campaign::whereIn('id', $campaign_ids)
                                    ->select(['name', 'id'])        
                                    ->get();                       
            $html='';
            if(!empty($campaigns)){
                foreach ($campaigns as $key => $campaign) {
                    $html.='<option value="'.$campaign->id.'">'.$campaign->name.'</option>';
                }
            }
            echo $html;
            exit;
        }
    }
}
