<?php

namespace App\Http\Controllers;

use App\Business;
use App\BusinessLocation;
use App\Category;
use App\UserCommission;
use Datatables;
use Illuminate\Http\Request;

class CommissionController extends Controller
{
    public function index(){
        if (!auth()->user()->can('access_commission')) {
            abort(403, 'Unauthorized action.');
        }
        
        $commission_groups = [];
        $business_id = request()->session()->get('user.business_id');
        $business = Business::findOrFail($business_id);
        $commission_type = $business->commission_type;
        if(request()->ajax()){
            
            $commission_groups = UserCommission::where('business_id', $business_id)
            ->select('id', 'name', 'total_sell_amount', 'total_sell_unit', 'commission_percentage')->get();
            
            return Datatables::of($commission_groups)
            ->addColumn(
                'action',
                '@can("printer.update")
                <a href="{{action(\'CommissionController@edit\', [$id])}}" class="btn btn-xs btn-primary"><i class="glyphicon glyphicon-edit"></i> @lang("messages.edit")</a>
                    &nbsp;
                @endcan
                @can("printer.delete")
                    <button data-href="{{action(\'CommissionController@destroy\', [$id])}}" class="btn btn-xs btn-danger delete_commission_button"><i class="glyphicon glyphicon-trash"></i> @lang("messages.delete")</button>
                @endcan'
            )
            ->removeColumn('user_id', 'business_id', 'location_id')
            // ->rawColumns([7])
            ->escapeColumns(['action'])
            ->make(false);
        }
        return view('user_commission.index', compact('commission_groups','commission_type'));
    }

    public function create(){
        if (!auth()->user()->can('access_commission')) {
            abort(403, 'Unauthorized action.');
        }
        $business_id = request()->session()->get('user.business_id');
        $business_locations = BusinessLocation::forDropdown($business_id);
        $product_category = Category::forDropdown($business_id, 'product');
        $product_subcategory = Category::catAndSubCategories($business_id);
        // $subcategory = Category::with('sub_categories')->where('business_id', $business_id)->where('parent_id', 0)->get();

        return view('user_commission.create')->with(compact('business_locations', 'product_category', 'product_subcategory'));
    }

    public function store(Request $request){
        if (!auth()->user()->can('access_commission')) {
            abort(403, 'Unauthorized action.');
        }
        try{
            $business_id = $request->session()->get('user.business_id');
            $input = $request->only('name', 'total_sell_amount', 'total_sell_unit', 'commission_percentage', 'location_id');
            $input['user_id'] = $request->session()->get('user.id');
            $input['business_id'] = $business_id;
            $input['created_by'] = $request->session()->get('user.id');
            $commission = new UserCommission();
            $commission->fill($input)->save();

            $product_category = $request->input('product_category');
            $product_subcategory = $request->input('product_subcategory');
            if($product_subcategory != null){
                foreach($product_subcategory as $subcategory){
                    array_push($product_category, $subcategory);
                }
            }
            if (!empty($product_category)) {
                $commission->product_category()->sync($product_category);
            }

            $output = ['success' => 1,
                'msg' => __('Commission group added successfully')
                ];
        } catch (\Exception $e) {
            \Log::emergency("File:" . $e->getFile(). "Line:" . $e->getLine(). "Message:" . $e->getMessage());
            
            $output = ['success' => false,
                            'msg' => __("messages.something_went_wrong")
                        ];
        }
        return redirect('user_commission')->with('status', $output);
    }

    public function edit($id)
    {
        if (!auth()->user()->can('access_commission')) {
             abort(403, 'Unauthorized action.');
        }

        $business_id = request()->session()->get('user.business_id');
        $user_commission = UserCommission::find($id);
        $product_category = Category::forDropdown($business_id, 'product');
        $product_subcategory = Category::forDropdown1($business_id, 'product');
        
        // $product_subcategory = Category::with('sub_categories')->where('business_id', $business_id);
        return view('user_commission.edit')
            ->with(compact('user_commission','product_category', 'product_subcategory'));
    }

    public function update(Request $request, $id)
    {
        if (!auth()->user()->can('access_commission')) {
             abort(403, 'Unauthorized action.');
        }

        try {
            $input = $request->only(['name', 'total_sell_amount', 'total_sell_unit', 'commission_percentage']);
            $business_id = $request->session()->get('user.business_id');

            $user_commission = UserCommission::findOrFail($id);
            $user_commission->fill($input)->save();

            //Add product locations
            $product_category = $request->input('product_category');
            $product_subcategory = $request->input('product_subcategory');
            if($product_subcategory != null){
                foreach($product_subcategory as $subcategory){
                    array_push($product_category, $subcategory);
                }
            }
            $user_commission->product_category()->sync($product_category);

            $output = ['success' => true,
                        'msg' => __("Commission group updated successfully")
                        ];
        } catch (\Exception $e) {
            \Log::emergency("File:" . $e->getFile(). "Line:" . $e->getLine(). "Message:" . $e->getMessage());
        
            $output = ['success' => false,
                        'msg' => __("messages.something_went_wrong")
                    ];
        }

        return redirect('user_commission')->with('status', $output);
    }
    public function destroy($id)
    {
        if (!auth()->user()->can('access_printers')) {
             abort(403, 'Unauthorized action.');
        }
        
        if (request()->ajax()) {
            try {
                $business_id = request()->user()->business_id;

                $user_commission = UserCommission::findOrFail($id);
                $user_commission->delete();

                $output = ['success' => true,
                            'msg' => __("Commission group deleted successfully")
                            ];
            } catch (\Exception $e) {
                \Log::emergency("File:" . $e->getFile(). "Line:" . $e->getLine(). "Message:" . $e->getMessage());
            
                $output = ['success' => false,
                            'msg' => __("messages.something_went_wrong")
                        ];
            }
            return $output;
        }
    }

    public function getSubCategories(){

        if(request()->ajax()){
            $business_id = request()->user()->business_id;
            $ids = request()->get('option');
            if($ids != null)
                $categories = Category::catAndSubCategories1($business_id, $ids);
            else
                $categories = Category::catAndSubCategories($business_id);
            $html = '';  
            foreach($categories as $category){
                $option ='';
                if(isset($category['sub_categories'])){
                    foreach($category['sub_categories'] as $sub_category){
                        $option.= '<option value='.$sub_category['id'].'> '.$sub_category['name'].' </option>';
                    }
                }
                $html.= '<optgroup label='.$category["name"].' id="'.$category["id"].'" value="'.$category["id"].'">
                            '.$option.'
                        </optgroup>';
            }
            return $html;
        }
    }
    
    
    public function commissionUpdate(Request $request)
    {
        $business_id = request()->session()->get('user.business_id');
        $business = Business::findOrFail($business_id);
        $business->commission_type = $request->input('commission_setting');
        $business->save();
    
        return response()->json([
            'success' => true
        ]);
    }
}
