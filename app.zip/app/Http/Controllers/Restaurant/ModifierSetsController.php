<?php

namespace App\Http\Controllers\Restaurant;

use App\Product;

use App\Utils\ProductUtil;
use App\Utils\Util;
use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Illuminate\Routing\Controller;

use Illuminate\Support\Facades\DB;

class ModifierSetsController extends Controller
{
    /**
     * All Utils instance.
     *
     */
    protected $productUtil;

    protected $commonUtil;

    /**
     * Constructor
     *
     * @param ProductUtils $product
     * @return void
     */
    public function __construct(ProductUtil $productUtil, Util $commnUtil)
    {
        $this->productUtil = $productUtil;
        $this->commonUtil = $commnUtil;
    }
    /**
     * Display a listing of the resource.
     * @return Response
     */
    public function index()
    {
        if (request()->ajax()) {
            $business_id = request()->session()->get('user.business_id');

            $modifer_set = Product::where('business_id', $business_id)
                            ->where('type', 'modifier')
                            ->with(['variations', 'modifier_products']);

            return \Datatables::of($modifer_set)
                ->addColumn(
                    'action',
                    '
                    @can("product.update")
                        <button type="button" data-href="{{action(\'Restaurant\ModifierSetsController@edit\', [$id])}}" class="btn btn-xs btn-primary edit_modifier_button" data-container=".modifier_modal"><i class="glyphicon glyphicon-edit"></i> @lang("messages.edit")</button>
                        &nbsp;
                        <button type="button" data-href="{{action(\'Restaurant\ProductModifierSetController@edit\', [$id])}}" class="btn btn-xs btn-info edit_modifier_button" data-container=".modifier_modal"><i class="fa fa-cubes"></i> @lang("restaurant.manage_products")</button>
                    &nbsp;
                    @endcan

                    @can("product.delete")
                        <button data-href="{{action(\'Restaurant\ModifierSetsController@destroy\', [$id])}}" class="btn btn-xs btn-danger delete_modifier_button"><i class="glyphicon glyphicon-trash"></i> @lang("messages.delete")</button>
                    @endcan
                    '
                )
                ->editColumn('modifier_products', function ($row) {
                    $products = [];
                    foreach ($row->modifier_products as $product) {
                        $products[] = $product->name;
                    }
                    return implode(', ', $products);
                })
                ->editColumn('variations', function ($row) {
                    $modifiers = [];
                    foreach ($row->variations as $modifier) {
                        $modifiers[] = $modifier->name;
                    }
                    return implode(', ', $modifiers);
                })
                ->removeColumn('id')
                ->escapeColumns(['action'])
                ->make(true);
        }

        return view('restaurant.modifier_sets.index');
    }

    /**
     * Show the form for creating a new resource.
     * @return Response
     */
    public function create()
    {
        if (!auth()->user()->can('product.create')) {
            abort(403, 'Unauthorized action.');
        }
        
        return view('restaurant.modifier_sets.create');
    }

    /**
     * Store a newly created resource in storage.
     * @param  Request $request
     * @return Response
     */
    public function store(Request $request)
    {
        try {
            if (!auth()->user()->can('product.create')) {
                abort(403, 'Unauthorized action.');
            }

            $input = $request->all();
            
            $business_id = $request->session()->get('user.business_id');
            $user_id = $request->session()->get('user.id');
            $product_details['not_for_selling'] = (!empty($request->input('not_for_selling')) &&  $request->input('not_for_selling') == 1) ? 1 : 0;

            $modifer_set_data = [
                'name' => $input['name'],
                'type' => 'modifier',
                'sku' => ' ',
                'tax_type' => 'inclusive',
                'is_open_modifier' => (!empty($input['is_open_modifier']) && $input['is_open_modifier'] == 1) ? 1 : 0,
                'merge_qty' => (!empty($input['merge_qty']) && $input['merge_qty'] == 1) ? 1 : 0,
                'is_quick_option'=>(!empty($input['is_quick_option']) && $input['is_quick_option'] == 1) ? 1 : 0,
                'not_for_receipt' => (!empty($input['not_for_receipt']) && $input['not_for_receipt'] == 1) ? 1 : 0,
                'not_for_digital_ordering' => (!empty($input['not_for_digital_ordering']) && $input['not_for_digital_ordering'] == 1) ? 1 : 0,
                'not_for_pickup_delivery' => (!empty($input['not_for_pickup_delivery']) && $input['not_for_pickup_delivery'] == 1) ? 1 : 0,
                'sequence' => $input['sequence'],
                'order_limit_at_least' => $input['order_limit_at_least'],
                'order_limit' => $input['order_limit'],
                'not_for_selling' => $input['not_for_selling_modifier_set'],
                'business_id' => $business_id,
                'created_by' => $user_id
            ];

            DB::beginTransaction();
            $modifer_set = Product::create($modifer_set_data);

            $sku = $this->productUtil->generateProductSku($modifer_set->id);
            $modifer_set->sku = $sku;
            $modifer_set->save();

            if ($request->hasFile('modifier_image')) {
                $files = $request->file('modifier_image');
                $uploadedFiles = [];
                
                foreach ($files as $key => $file) {
                    if ($file !== null) {
                        $mimeType = $this->commonUtil->get_mime_type($file->getClientOriginalName());
                        $mimePart = explode('/', $mimeType )[0];
                        $uploadedFilePath = $this->commonUtil->uploadFileModifierOnAWSS3($request, $file, config('constants.modifier_image_path'), $mimePart);
                        $uploadedFiles[$key] = $uploadedFilePath;
                    }
                }
            
                // Assuming $input['modifier_image_edit'] should be an array of file paths or other relevant data
                $input['modifier_image'] = $uploadedFiles;
            } else {
                $input['modifier_image'] = []; // Set default value if no files are uploaded
            }
            
            $modifier_modifier_image_edit = $input['modifier_image'];

            $modifers = [];

            foreach ($input['modifier_name'] as $key => $value) {
                $modifers[] = [
                    'value' => $value,
                    'default_purchase_price' => $input['modifier_price'][$key],
                    'dpp_inc_tax' => $input['modifier_price'][$key],
                    'profit_percent' => 0,
                    'default_sell_price' => $input['modifier_price'][$key],
                    'sell_price_inc_tax' => $input['modifier_price'][$key],
                    'weight' => $input['modifier_weight'][$key],
                    'name_in_second_language' => $input['modifier_name_in_second_language'][$key],
                    'short_hand_name' => $input['modifier_short_hand_name'][$key],
                    'not_for_selling' => $input['not_for_selling'][$key],
                    'modifier_image' => $modifier_modifier_image_edit[$key],
                ];
            }
            $modifiers_data = [];
            $modifiers_data[] = [
                'name' => 'DUMMY',
                'variations' => $modifers
            ];
            $this->productUtil->createVariableProductVariations($modifer_set->id, $modifiers_data);

            DB::commit();

            $output = ['success' => 1, 'msg' => __("lang_v1.added_success")];
        } catch (\Exception $e) {
            DB::rollBack();
            \Log::emergency("File:" . $e->getFile(). "Line:" . $e->getLine(). "Message:" . $e->getMessage());
            
            $output = ['success' => 0, 'msg' => __("messages.something_went_wrong")];
        }

        return $output;
    }

    /**
     * Show the specified resource.
     * @return Response
     */
    public function show()
    {
        return view('restaurant.modifier_sets.show');
    }

    /**
     * Show the form for editing the specified resource.
     * @return Response
     */
    public function edit($id, Request $request)
    {
        if (!auth()->user()->can('product.update')) {
            abort(403, 'Unauthorized action.');
        }

        try {
            $business_id = $request->session()->get('user.business_id');

            $modifer_set = Product::where('business_id', $business_id)
                            ->where('id', $id)
                            ->with(['variations'])
                            ->first();

            return view('restaurant.modifier_sets.edit')
                ->with(compact('modifer_set'));
        } catch (\Exception $e) {
            \Log::emergency("File:" . $e->getFile(). "Line:" . $e->getLine(). "Message:" . $e->getMessage());
            
            $output = ['success' => 0, 'msg' => __("messages.something_went_wrong")];
        }
    }

    /**
     * Update the specified resource in storage.
     * @param  Request $request
     * @return Response
     */
    public function update($id, Request $request)
    {
        if (!auth()->user()->can('product.update')) {
            abort(403, 'Unauthorized action.');
        }
        try {
            DB::beginTransaction();

            $input = $request->all();
            $business_id = $request->session()->get('user.business_id');
            $user_id = $request->session()->get('user.id');
            $modifer_set_data = [
                'name' => $input['name'],
                'not_for_receipt' => (!empty($input['not_for_receipt']) && $input['not_for_receipt'] == 1) ? 1 : 0,
                'not_for_digital_ordering' => (!empty($input['not_for_digital_ordering']) && $input['not_for_digital_ordering'] == 1) ? 1 : 0,
                'not_for_pickup_delivery' => (!empty($input['not_for_pickup_delivery']) && $input['not_for_pickup_delivery'] == 1) ? 1 : 0,
                'sequence' => $input['sequence'],
                'order_limit_at_least' => $input['order_limit_at_least'],
                'order_limit' => $input['order_limit'],
                'is_open_modifier' => (!empty($input['is_open_modifier']) && $input['is_open_modifier'] == 1) ? 1 : 0,
                'merge_qty' => (!empty($input['merge_qty']) && $input['merge_qty'] == 1) ? 1 : 0,
                'is_quick_option'=>(!empty($input['is_quick_option']) && $input['is_quick_option'] == 1) ? 1 : 0,
                'not_for_selling' => $input['not_for_selling_modifier_set'],
            ];

            $modifer_set = Product::where('business_id', $business_id)
                    ->where('id', $id)
                    ->where('type', 'modifier')
                    ->first();
            $modifer_set->update($modifer_set_data);

            //Get the dummy product variation
            $product_variation = $modifer_set->product_variations()->first();

            $modifiers_data[$product_variation->id]['name'] = $product_variation->name;

            $variations_edit = [];
            $variations = [];

            //Set existing variations
            if (!empty($input['modifier_name_edit'])) {
                $modifier_name_edit = $input['modifier_name_edit'];
                $modifier_price_edit = $input['modifier_price_edit'];
                $modifier_weight_edit = $input['modifier_weight_edit'];
                $modifier_second_lang_edit = $input['modifier_name_in_second_language_edit'];
                $modifier_short_hand_name_edit = $input['modifier_short_hand_name_edit'];
                $not_for_selling_edit = $input['not_for_selling_edit'];
                if ($request->has('modifier_image_name')) {
                    $modifier_image_names = $request->input('modifier_image_name');
                    $arr = [];
                    foreach ($modifier_image_names as $key => $file) {
                        $arr[$key] = $file;
                    }
                    // Assuming $input['modifier_image_edit'] should be an array of file paths or other relevant data
                    $input['modifier_image_name'] = $arr;
                }

                if ($request->hasFile('modifier_image_edit')) {
                    $files = $request->file('modifier_image_edit');
                    $uploadedFiles = [];
                    
                    foreach ($files as $key => $file) {
                        if ($file !== null) {
                            $mimeType = $this->commonUtil->get_mime_type($file->getClientOriginalName());
                            $mimePart = explode('/', $mimeType )[0];
                            $uploadedFilePath = $this->commonUtil->uploadFileModifierOnAWSS3($request, $file, config('constants.modifier_image_path'), $mimePart);
                            $uploadedFiles[$key] = $uploadedFilePath;
                        }
                    }
                
                    // Assuming $input['modifier_image_edit'] should be an array of file paths or other relevant data
                    $input['modifier_image_edit'] = $uploadedFiles;
                } else {
                    $input['modifier_image_edit'] = []; // Set default value if no files are uploaded
                }
                
                $modifier_modifier_image_edit = $input['modifier_image_edit'];
                $modifier_modifier_image_name = $input['modifier_image_name'];
                
                // Initialize variations_edit array to store modified variations
                $variations_edit = [];

                // Handle existing variations
                if (!empty($modifier_name_edit)) {
                    foreach ($modifier_name_edit as $key => $name) {
                        if (isset($modifier_price_edit[$key])) {
                            $variations_edit[$key]['value'] = $name;
                            $variations_edit[$key]['default_purchase_price'] = $modifier_price_edit[$key];
                            $variations_edit[$key]['dpp_inc_tax'] = $modifier_price_edit[$key];
                            $variations_edit[$key]['default_sell_price'] = $modifier_price_edit[$key];
                            $variations_edit[$key]['sell_price_inc_tax'] = $modifier_price_edit[$key];
                            $variations_edit[$key]['profit_percent'] = 0;
                            $variations_edit[$key]['weight'] = $modifier_weight_edit[$key];
                            $variations_edit[$key]['name_in_second_language'] = $modifier_second_lang_edit[$key];
                            $variations_edit[$key]['short_hand_name'] = $modifier_short_hand_name_edit[$key];
                            $variations_edit[$key]['not_for_selling'] = $not_for_selling_edit[$key];
                            

                            // Handle modifier_image_edit if it's an array (multiple files uploaded)
                            if (isset($modifier_modifier_image_edit[$key]) && is_array($modifier_modifier_image_edit[$key])) {
                                $variations_edit[$key]['modifier_image'] = $modifier_modifier_image_edit[$key];
                            } elseif (isset($modifier_modifier_image_edit[$key])) {
                                // Handle single file upload scenario
                                $variations_edit[$key]['modifier_image'] = $modifier_modifier_image_edit[$key];
                            } else {
                                $variations_edit[$key]['modifier_image'] = $modifier_modifier_image_name[$key];
                            }
                        }
                    }
                }

                // Set new variations based on input data
                $variations = [];

                if (!empty($input['modifier_name'])) {
                    foreach ($input['modifier_name'] as $key => $value) {
                        $variations[] = [
                            'value' => $value,
                            'default_purchase_price' => $input['modifier_price'][$key],
                            'dpp_inc_tax' => $input['modifier_price'][$key],
                            'profit_percent' => 0,
                            'default_sell_price' => $input['modifier_price'][$key],
                            'sell_price_inc_tax' => $input['modifier_price'][$key],
                            'weight' => $input['modifier_weight'][$key],
                            'name_in_second_language' => $input['modifier_name_in_second_language'][$key],
                            'short_hand_name' => $input['modifier_short_hand_name'][$key],
                            'not_for_selling' => $input['not_for_selling'][$key],

                            // Handle modifier_image if it's an array (multiple files uploaded)
                            'modifier_image' => isset($input['modifier_modifier_image'][$key]) ? $input['modifier_modifier_image'][$key] : $input['modifier_image_name'][$key],
                        ];
                    }
                }
            }

            //Update variations
            $modifiers_data[$product_variation->id]['variations_edit'] = $variations_edit;
            $modifiers_data[$product_variation->id]['variations'] = $variations;
            $this->productUtil->updateVariableProductVariations($modifer_set->id, $modifiers_data);

            DB::commit();

            $output = ['success' => 1, 'msg' => __("lang_v1.updated_success")];
        } catch (\Exception $e) {
            DB::rollBack();
            \Log::emergency("File:" . $e->getFile(). "Line:" . $e->getLine(). "Message:" . $e->getMessage());
            
            $output = ['success' => 0, 'msg' => __("messages.something_went_wrong")];
        }

        return $output;
    }

    /**
     * Remove the specified resource from storage.
     * @return Response
     */
    public function destroy($id, Request $request)
    {
        if (!auth()->user()->can('product.delete')) {
            abort(403, 'Unauthorized action.');
        }

        try {
            DB::beginTransaction();
            $business_id = $request->session()->get('user.business_id');

            Product::where('business_id', $business_id)
                ->where('type', 'modifier')
                ->where('id', $id)
                ->delete();

            DB::commit();

            $output = ['success' => 1, 'msg' => __("lang_v1.deleted_success")];
        } catch (\Exception $e) {
            DB::rollBack();
            \Log::emergency("File:" . $e->getFile(). "Line:" . $e->getLine(). "Message:" . $e->getMessage());
            
            $output = ['success' => 0, 'msg' => __("messages.something_went_wrong")];
        }

        return $output;
    }
}
