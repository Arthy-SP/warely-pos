<?php

namespace App\Http\Controllers\Restaurant;

use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Illuminate\Routing\Controller;
use Datatables;

use App\Restaurant\ResFloorPlan;
use App\Restaurant\ResTable;
use App\BusinessLocation;

class FloorPlanController extends Controller
{
    /**
     * Display a listing of the resource.
     * @return Response
     */
    public function index()
    {
        // if (!auth()->user()->can('access_tables')) {
        //     abort(403, 'Unauthorized action.');
        // }

        if (request()->ajax()) {
            $business_id = request()->session()->get('user.business_id');

            $tables = ResFloorPlan::where('res_floor_plan.business_id', $business_id)
                        ->join('business_locations AS BL', 'res_floor_plan.location_id', '=', 'BL.id')
                        ->select(['res_floor_plan.name as name', 'BL.name as location', 'res_floor_plan.id']);

            return Datatables::of($tables)
                ->addColumn(
                    'action',
                    '@role("Admin#' . $business_id . '")
                    <button data-href="{{action(\'Restaurant\FloorPlanController@edit\', [$id])}}" class="btn btn-xs btn-primary edit_table_button"><i class="glyphicon glyphicon-edit"></i> @lang("messages.edit")</button>
                        &nbsp;
                    @endrole
                    @role("Admin#' . $business_id . '")
                        <button data-href="{{action(\'Restaurant\FloorPlanController@destroy\', [$id])}}" class="btn btn-xs btn-danger delete_table_button"><i class="glyphicon glyphicon-trash"></i> @lang("messages.delete")</button>
                    @endrole'
                )
                ->removeColumn('id')
                ->escapeColumns(['action'])
                ->make(true);
        }

        return view('restaurant.floor_plan.index');
    }

    /**
     * Show the form for creating a new resource.
     * @return Response
     */
    public function create()
    {
        // if (!auth()->user()->can('access_tables')) {
        //      abort(403, 'Unauthorized action.');
        // }

        $business_id = request()->session()->get('user.business_id');
        $business_locations = BusinessLocation::forDropdown($business_id);

        return view('restaurant.floor_plan.create')
            ->with(compact('business_locations'));
    }

    /**
     * Store a newly created resource in storage.
     * @param  Request $request
     * @return Response
     */
    public function store(Request $request)
    {
        // if (!auth()->user()->can('access_tables')) {
        //      abort(403, 'Unauthorized action.');
        // }

        try {
            $input = $request->only(['name', 'location_id']);
            $business_id = $request->session()->get('user.business_id');
            $input['business_id'] = $business_id;
            $input['created_by'] = $request->session()->get('user.id');

            $table = ResFloorPlan::create($input);
            $output = ['success' => true,
                            'data' => $table,
                            'msg' => __("lang_v1.added_success")
                        ];
        } catch (\Exception $e) {
            \Log::emergency("File:" . $e->getFile(). "Line:" . $e->getLine(). "Message:" . $e->getMessage());
            
            $output = ['success' => false,
                            'msg' => __("messages.something_went_wrong")
                        ];
        }

        return $output;
    }

    /**
     * Show the specified resource.
     * @return Response
     */
    public function show()
    {
        // if (!auth()->user()->can('access_tables')) {
        //      abort(403, 'Unauthorized action.');
        // }

        return view('restaurant.floor_plan.show');
    }

    /**
     * Show the form for editing the specified resource.
     * @return Response
     */
    public function edit($id)
    {
        // if (!auth()->user()->can('access_tables')) {
        //      abort(403, 'Unauthorized action.');
        // }
        
        if (request()->ajax()) {
            $business_id = request()->session()->get('user.business_id');
            $table = ResFloorPlan::where('business_id', $business_id)->find($id);

            return view('restaurant.floor_plan.edit')
                ->with(compact('table'));
        }
    }

    /**
     * Update the specified resource in storage.
     * @param  Request $request
     * @return Response
     */
    public function update(Request $request, $id)
    {
        // if (!auth()->user()->can('access_tables')) {
        //      abort(403, 'Unauthorized action.');
        // }

        if (request()->ajax()) {
            try {
                $input = $request->only(['name']);
                $business_id = $request->session()->get('user.business_id');

                $table = ResFloorPlan::where('business_id', $business_id)->findOrFail($id);
                $table->name = $input['name'];
                $table->save();

                $output = ['success' => true,
                            'msg' => __("lang_v1.updated_success")
                            ];
            } catch (\Exception $e) {
                \Log::emergency("File:" . $e->getFile(). "Line:" . $e->getLine(). "Message:" . $e->getMessage());
            
                $output = ['success' => false,
                            'msg' => __("messages.something_went_wrong")
                        ];
            }

            return $output;
        }
    }

    /**
     * Remove the specified resource from storage.
     * @return Response
     */
    public function destroy($id)
    {
        // if (!auth()->user()->can('access_tables')) {
        //      abort(403, 'Unauthorized action.');
        // }

        if (request()->ajax()) {
            try {
                $business_id = request()->user()->business_id;

                $table = ResFloorPlan::where('business_id', $business_id)->findOrFail($id);
                $table->delete();

                $output = ['success' => true,
                            'msg' => __("lang_v1.deleted_success")
                            ];
            } catch (\Exception $e) {
                \Log::emergency("File:" . $e->getFile(). "Line:" . $e->getLine(). "Message:" . $e->getMessage());
            
                $output = ['success' => false,
                            'msg' => __("messages.something_went_wrong")
                        ];
            }

            return $output;
        }
    }
}
