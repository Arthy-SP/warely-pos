<?php

namespace App\Http\Controllers\Restaurant;

use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Illuminate\Routing\Controller;
use Datatables;
use App\PosResTables;
use App\Restaurant\ResTable;
use App\Restaurant\ResFloorPlan;
use App\BusinessLocation;
use Config;
use Carbon\Carbon;

class TableController extends Controller
{
    /**
     * Display a listing of the resource.
     * @return Response
     */
    public function index()
    {
        if (!auth()->user()->can('access_tables')) {
             abort(403, 'Unauthorized action.');
        }

        if (request()->ajax()) {
            $business_id = request()->session()->get('user.business_id');
            $user_id = request()->session()->get('user.id');


            $tables = ResTable::where('res_tables.business_id', $business_id)
                                ->whereNull('res_tables.parent_table_id')
                                ->join('business_locations AS BL', 'res_tables.location_id', '=', 'BL.id')
                                ->select(['res_tables.name as name', 'BL.name as location','res_tables.parent_table_id',
                            'res_tables.description', 'res_tables.id', 'BL.website', 'res_tables.location_id']);

            $qrAppBaseUrl = config("constants.QR_APP_URL");
            return Datatables::of($tables)
                ->addColumn('child_table_count', function ($tables) {
                    $childCount = ResTable::where('parent_table_id', $tables->id)->count();
                    return $childCount;
                })
                ->addColumn(
                    'table_qr_url',
                    '{{$website}}?table_id={{$id}}&uid='.$user_id.'&table_name={{$name}}&pax=1&business_id='.$business_id.'&location_id={{$location_id}}'
                    //$business_location->website . '?table_id=' . $table_id . '&uid=' . $user_id . '&table_name=' . $table_name . '&pax=' . $pax . '&business_id=' . $business_id . '&location_id=' . $location_id . '&token=' . $qr_token;
                )
                
                ->addColumn('qr_code', function ($tables) use ($business_id, $qrAppBaseUrl) {
                    $generateQRUrl = route('generateQR', [
                        'id' => $tables->id,
                        'tableName' => urlencode($tables->name),
                        'locationId' => $tables->location_id,
                        'businessId' => $business_id
                    ]);
                    return '
                        <button class="btn btn-xs copy_button" data-id="' . $tables->id . '" data-location-id="' . $tables->location_id . '" data-business-id="' . $business_id . '" data-qr-app-base-url="' . $qrAppBaseUrl . '" data-table-name="' . $tables->name . '"><i class="glyphicon"></i> Copy</button>
                        
                        <button data-href="' . $generateQRUrl . '" class="btn btn-xs btn-primary qr_code_button">
                            <i class="glyphicon"></i> Print
                        </button>';
                })
                ->addColumn(
                    'action',
                    '@role("Admin#' . $business_id . '")
                    <button data-href="{{action(\'Restaurant\TableController@edit\', [$id])}}" class="btn btn-xs btn-primary edit_table_button"><i class="glyphicon glyphicon-edit"></i> @lang("messages.edit")</button>
                        &nbsp;
                    @endrole
                    @role("Admin#' . $business_id . '")
                        <button data-href="{{action(\'Restaurant\TableController@destroy\', [$id])}}" class="btn btn-xs btn-danger delete_table_button"><i class="glyphicon glyphicon-trash"></i> @lang("messages.delete")</button>
                    @endrole'
                )
                ->removeColumn('id')
                ->removeColumn('website')
                ->removeColumn('location_id')
                ->escapeColumns(['action', 'table_qr_url', 'location_id'])
                ->make(true);
        }

        return view('restaurant.table.index')
        ->with(compact('business_id', 'qrAppBaseUrl'));
    }

    /**
     * Show the form for creating a new resource.
     * @return Response
     */
    public function create()
    {
        if (!auth()->user()->can('access_tables')) {
             abort(403, 'Unauthorized action.');
        }

        $business_id = request()->session()->get('user.business_id');
        $business_locations = BusinessLocation::forDropdown($business_id);
        $floor_plan = ResFloorPlan::forCreateDropdown($business_id);

        return view('restaurant.table.create')
            ->with(compact('business_locations','floor_plan'));
    }

    /**
     * Store a newly created resource in storage.
     * @param  Request $request
     * @return Response
     */
    public function store(Request $request)
    {
        if (!auth()->user()->can('access_tables')) {
             abort(403, 'Unauthorized action.');
        }

        try {
            $input = $request->only(['name', 'location', 'description', 'location_id']);
            $business_id = $request->session()->get('user.business_id');
            $input['business_id'] = $business_id;
            $input['created_by'] = $request->session()->get('user.id');
            $child_table = $request->input('child_table');
            
            $table = ResTable::create($input);

            // Create child tables if the count is 3, 5, or any other specific value
            if ($child_table != 0) {
                $input['parent_table_id'] = $table->id;
                for ($i = 1; $i <= $child_table; $i++) {
                    ResTable::create([
                          'name'        => $input['name'].'-'.$i,
                          'business_id' => $business_id,
                          'location_id' => $input['location_id'],
                          'description' => $input['description'],
                          'location'    => $input['location'],
                          'created_by'  => $input['created_by'],
                          'parent_table_id' => $table->id,
                    ]);
                }
            }
            $output = ['success' => true,
                            'data' => $table,
                            'msg' => __("lang_v1.added_success")
                        ];
        } catch (\Exception $e) {
            \Log::emergency("File:" . $e->getFile(). "Line:" . $e->getLine(). "Message:" . $e->getMessage());
            
            $output = ['success' => false,
                            'msg' => __("messages.something_went_wrong")
                        ];
        }

        return $output;
    }

    /**
     * Show the specified resource.
     * @return Response
     */
    public function show()
    {
        if (!auth()->user()->can('access_tables')) {
             abort(403, 'Unauthorized action.');
        }

        return view('restaurant.table.show');
    }

    /**
     * Show the form for editing the specified resource.
     * @return Response
     */
    public function edit($id)
    {
        if (!auth()->user()->can('access_tables')) {
             abort(403, 'Unauthorized action.');
        }
        
        if (request()->ajax()) {
            $business_id = request()->session()->get('user.business_id');
            $table = ResTable::where('business_id', $business_id)->find($id);
            $table['child_table'] = ResTable::where('parent_table_id', $table['id'])->count();
            
            $floor_plan = ResFloorPlan::forEditDropdown($business_id,$table['location_id'],$table['child_table']);
            
            return view('restaurant.table.edit')->with(compact('table','floor_plan'));
        }
    }

    /**
     * Update the specified resource in storage.
     * @param  Request $request
     * @return Response
     */
    public function update(Request $request, $id)
    {
        if (!auth()->user()->can('access_tables')) {
             abort(403, 'Unauthorized action.');
        }

        if (request()->ajax()) {
            try {
                $input = $request->only(['name', 'location', 'description']);
                $business_id = $request->session()->get('user.business_id');

                $table = ResTable::where('business_id', $business_id)->findOrFail($id);
                
                $table->name = $input['name'];
                $table->location = $input['location'];
                $table->description = $input['description'];
                $new_child_table = $request->input('child_table');

                $child_table_count = ResTable::where('parent_table_id', $table['id'])->count();
                
                if($new_child_table == $child_table_count) {
                    $table->save();

                    $child_tables = ResTable::where('parent_table_id', $table->id)->get();
                    $i = 1; 
                    foreach ($child_tables as $child_table) {
                        $child_table->name = $table->name.'-'.$i;
                        $child_table->location = $table->location;
                        $child_table->description = $table->description;
                        $child_table->save();
                        $i++;
                    }
                } 
                elseif ($new_child_table > $child_table_count) {
                    $table->save();
                    
                    $child_tables = ResTable::where('parent_table_id', $table->id)->get();
                    $i = 1; 
                    foreach ($child_tables as $child_table) {
                        $child_table->name = $table->name.'-'.$i;
                        $child_table->location = $table->location;
                        $child_table->description = $table->description;
                        $child_table->save();
                        $i++;
                    }

                    $new_tables_count = $new_child_table - $child_table_count;
                
                    for ($j = 1; $j <= $new_tables_count; $j++) {
                        ResTable::create([
                            'name' => $table->name . '-' . ($child_table_count + $j),
                            'business_id' => $table->business_id,
                            'location_id' => $table->location_id,
                            'description' => $table->description,
                            'location' => $table->location,
                            'created_by' => $table->created_by,
                            'parent_table_id' => $table->id,
                        ]);
                    }
                
                } elseif ($new_child_table < $child_table_count) {
                    $businessLocation = BusinessLocation::find($table->location_id);
                    if( !empty($businessLocation) && !empty($businessLocation->day_start_time) ) {
                        $daystartTime = $businessLocation->day_start_time;
                        $dayStartTime = $daystartTime.":00:00";
                        $dayendTime = $daystartTime - 1;
                        $dayEndTime = $dayendTime.":59:59";
                    }  else {
                        $dayStartTime = str_replace(' ', '', Config::get('constants.businessStartTimeDefault'));
                        $dayEndTime = str_replace(' ', '', Config::get('constants.businessEndTimeDefault'));
                    }

                    $current_time = null;
                    if( isset($user_data["current_time"]) && $user_data["current_time"] ) {
                        $current_time = $user_data["current_time"];
                    }
                    
                    $current_date = null;
                    if( isset($user_data["current_date"]) && $user_data["current_date"] ) {
                        $current_date = $user_data["current_date"];
                    }
                    
                    if( Config::get('constants.setBusinessTime') && !empty($businessLocation) && !empty($businessLocation->day_start_time) && !empty($current_time) && !empty($current_date) ) {
                        $morning6TimeStamp = strtotime($current_date . " " . $dayEndTime);
                        $dateTimeStamp = strtotime($current_date . " " . $current_time);
                        if( $dateTimeStamp >= $morning6TimeStamp ) {
                            $today = $current_date . ' ' .$dayStartTime;
                            $tomorrow = date('Y-m-d', strtotime($current_date .' +1 day')) . ' ' .$dayEndTime;
                        } else {
                            $today = date('Y-m-d', strtotime($current_date .' -1 day')) . ' ' .$dayStartTime;
                            $tomorrow = $current_date .' '.$dayEndTime;
                        }
                    } else {
                        $today = Carbon::today()->format('Y-m-d') . Config::get('constants.businessStartTimeDefault');
                        $tomorrow = Carbon::today()->format('Y-m-d') . Config::get('constants.businessEndTimeDefault');
                    }

                    $table->save();
                    
                    $child_tables = ResTable::where('parent_table_id', $table->id)->get();
                    $i = 1; 
                    foreach ($child_tables as $child_table) {
                        $child_table->name = $table->name.'-'.$i;
                        $child_table->location = $table->location;
                        $child_table->description = $table->description;
                        $child_table->save();
                        $i++;
                    }

                    $new_tables_count = $child_table_count - $new_child_table;

                    if ($new_tables_count >= 1) {
                        // Retrieve the last n child tables to be deleted
                        $child_tables_new = ResTable::where('parent_table_id', $table->id)
                                                ->orderBy('id', 'desc')
                                                ->limit($new_tables_count)
                                                ->get();

                        // Check if any of the child tables have seated transactions
                        $has_seated_transactions = false;
                        foreach ($child_tables_new as $child_table) {
                            $has_seated_transactions = PosResTables::where('res_table_id', $child_table->id)
                                                                ->where('seated', 1)
                                                                ->whereBetween('created_at', [$today, $tomorrow])
                                                                ->exists();
                            if ($has_seated_transactions) {
                                break;
                            }
                        }

                        if ($has_seated_transactions) {
                            // Show a message that there are seated transactions, and deletion is not allowed
                            return $output = ['success' => false, 'msg' => __("Seated transactions exist. Deletion not allowed.")];
                        } else {
                            // Delete the last n child tables
                            $child_tables->each->delete();

                            return $output = ['success' => true,
                            'msg' => __("lang_v1.updated_success")
                            ];
                        }
                    }
                }

                $output = ['success' => true,
                            'msg' => __("lang_v1.updated_success")
                            ];
            } catch (\Exception $e) {
                \Log::emergency("File:" . $e->getFile(). "Line:" . $e->getLine(). "Message:" . $e->getMessage());
            
                $output = ['success' => false,
                            'msg' => __("messages.something_went_wrong")
                        ];
            }

            return $output;
        }
    }

    /**
     * Remove the specified resource from storage.
     * @return Response
     */
    public function destroy($id)
    {
        if (!auth()->user()->can('access_tables')) {
             abort(403, 'Unauthorized action.');
        }

        if (request()->ajax()) {
            try {
                $business_id = request()->user()->business_id;

                $table = ResTable::where('business_id', $business_id)->findOrFail($id);
                $table->delete();

                $output = ['success' => true,
                            'msg' => __("lang_v1.deleted_success")
                            ];
            } catch (\Exception $e) {
                \Log::emergency("File:" . $e->getFile(). "Line:" . $e->getLine(). "Message:" . $e->getMessage());
            
                $output = ['success' => false,
                            'msg' => __("messages.something_went_wrong")
                        ];
            }

            return $output;
        }
    }

    public function generateQR(Request $request,$id, $tableName, $locationId, $businessId)
    {
        if (!auth()->user()->can('access_tables')) {
            abort(403, 'Unauthorized action.');
        }

        $business_id = request()->session()->get('user.business_id');
        $qrAppBaseUrl = config("constants.QR_APP_URL");
        $locationUrl = $qrAppBaseUrl . '/dinein' . '?t_id=' . $id . '&t_name=' .$tableName. '&location_id=' . $locationId . '&business_id=' . $businessId;

        return view('restaurant.table.qr_code')
            ->with(compact('locationUrl', 'business_id'));
    }

}
