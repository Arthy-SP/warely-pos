<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\NfcPromos;
use App\BusinessLocation;
use Datatables;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;
use App\User;
use App\NfcCard;
use App\NfcTransaction;
use App\NfcCardNumbers;
use Carbon\Carbon;
use App\Utils\TransactionUtil;

class NfcReportController extends Controller
{
    public function __construct() {

    }

    public function index()
    {
        if (!auth()->user()->can('access_tables')) {
            abort(403, 'Unauthorized action.');
        }

        $business_id = request()->session()->get('user.business_id');
        $business_locations = BusinessLocation::forDropdown($business_id);
        if (request()->ajax()) {
            $location_id = request()->get('location_id', null);               
            $transactions = NfcTransaction::select(DB::raw('DATE(nfc_transactions.created_at) as date'), DB::raw('SUM(nfc_transactions.amount) as total_amount'), DB::raw('SUM(np.promo_amount) as total_promo_amount'))
                                ->leftjoin('nfc_promos AS np', 'nfc_transactions.nfc_promo_id', '=', 'np.id')
                                ->where('nfc_transactions.business_id', $business_id)
                                ->where('nfc_transactions.is_void', '!=', 1)
                                ->where('nfc_transactions.transaction_type', 'credit')
                                ->whereNotIn('nfc_transactions.remark', ['Order Refund']);
                                if (!empty($location_id) && $location_id != 'none') {
                                    $transactions->where('nfc_transactions.location_id', $location_id);
                                }
                                $transactions->orderBy('nfc_transactions.created_at', 'desc')
                                ->orderBy('date', 'desc') // Order by date in ascending order
                                ->groupBy(DB::raw('DATE(nfc_transactions.created_at)'));

            return Datatables::of($transactions)
                ->addColumn('action', function ($transactions) use ($business_id) {
                    $transactionsButton = '';
                    $location_id = request()->get('location_id', null);
                    if (auth()->user()->can("Admin#" . $business_id)) {
                        $transactionsButton = '<a href="' . action('NfcReportController@show', [$transactions->date, 'location_id' => $location_id]) . '" class="btn btn-xs btn-primary " style= "margin-right: 5px"><i class="fa fa-eye"></i> Show</a>';
                    }
                    return $transactionsButton;
                })
                ->addColumn(
                    'total_topup_amount',
                    '<div style="white-space: nowrap;">@format_currency($total_amount - $total_promo_amount)</div>'
                )
                ->addColumn(
                    'total_promo_amount',
                    '<div style="white-space: nowrap;">@format_currency($total_promo_amount)</div>'
                )
                ->addColumn(
                    'total_amount',
                    '<div style="white-space: nowrap;">@format_currency($total_amount)</div>'
                )
                ->removeColumn('id')
                ->rawColumns(['action', 'date', 'amount', 'total_amount', 'total_topup_amount', 'total_promo_amount'])
                ->make(true);
       }

       return view('nfc_reports.index')->with(compact("business_locations"));;
    }

    /**
     * Show the specified resource.
     * @return Response
     */
    public function show($date, $location_id = null)
    {
        if (!auth()->user()->can('account.access')) {
            abort(403, 'Unauthorized action.');
        }

        $business_id = request()->session()->get('user.business_id');

        if($date) {
            $business_locations = BusinessLocation::forDropdown($business_id);
            $nfc_topup = NfcTransaction::select(DB::raw('DATE(nfc_transactions.created_at) as date'), DB::raw('SUM(nfc_transactions.amount) as total_amount'), DB::raw('SUM(np.promo_amount) as total_promo_amount'))
                                ->leftjoin('nfc_promos AS np', 'nfc_transactions.nfc_promo_id', '=', 'np.id')
                                ->where('nfc_transactions.business_id', $business_id)
                                ->whereBetween('nfc_transactions.created_at', [$date . " 00:00:00", $date . " 23:59:59"])
                                ->where('nfc_transactions.transaction_type', 'credit')
                                ->where('nfc_transactions.is_void', '!=', 1)
                                ->whereNotIn('nfc_transactions.remark', ['Order Refund'])
                                ->groupBy(DB::raw('DATE(nfc_transactions.created_at)'))
                                ->orderBy('date', 'desc') // Order by date in ascending order
                                ->first();

            $payment_methods = NfcTransaction::select('nfc_transactions.payment_method', DB::raw('SUM(nfc_transactions.amount) as total_amount'))
                                ->where('nfc_transactions.business_id', $business_id)
                                ->where('nfc_transactions.is_void', '!=', 1)
                                ->whereBetween('nfc_transactions.created_at', [$date . " 00:00:00", $date . " 23:59:59"])
                                ->where('nfc_transactions.transaction_type', 'credit')
                                ->whereNotIn('nfc_transactions.remark', ['Order Refund'])
                                ->groupBy('nfc_transactions.payment_method')
                                ->get();

            if (request()->ajax()) { 
                $location_id = $location_id ? $location_id : request()->get('location_id', null);               
                $nfcCardTransactions = NfcTransaction::where('nfc_transactions.business_id', $business_id)
                                    ->join('nfc_cards AS nc', 'nfc_transactions.nfc_card_id', '=', 'nc.id')
                                    ->leftjoin('nfc_promos AS np', 'nfc_transactions.nfc_promo_id', '=', 'np.id')
                                    ->whereBetween('nfc_transactions.created_at', [$date . " 00:00:00", $date . " 23:59:59"])
                                    ->where('nfc_transactions.transaction_type', 'credit')
                                    ->whereNotIn('nfc_transactions.remark', ['Order Refund']);

                                // Adding filter based on location ID if it's not empty
                                if (!empty($location_id) && $location_id != 'none') {
                                    $nfcCardTransactions->where('nfc_transactions.location_id', $location_id);
                                }

               $nfcCardTransactions->select([
                       'nfc_transactions.payment_method', 
                       'nfc_transactions.amount', 
                       'nfc_transactions.remark', 
                       'nfc_transactions.nfc_card_id', 
                       'nfc_transactions.created_at', 
                       'nc.card_no', 
                       'nc.sr_no', 
                       'np.amount AS actual_amount', 
                       'np.promo_amount',
                       'nfc_transactions.void_reason',
                       'nfc_transactions.is_void', 
                       'nfc_transactions.location_id'
                   ])
                   ->orderBy("nfc_transactions.created_at", 'desc');
                return Datatables::of($nfcCardTransactions)
                ->addColumn(
                    'topup_amount',
                    '<div style="white-space: nowrap;">@format_currency($amount - $promo_amount)</div>'
                )
                ->addColumn(
                    'promo_amount',
                    '<div style="white-space: nowrap;">@format_currency($promo_amount)</div>'
                )
                ->addColumn(
                    'amount',
                    '<div style="white-space: nowrap;">@format_currency($amount)</div>'
                )
                ->filterColumn('card_no', function ($query, $keyword) {
                    $query->where(function ($q) use ($keyword) {
                        $q->where('nc.card_no', 'like', "%{$keyword}%");
                    });
                })
                ->filterColumn('sr_no', function ($query, $keyword) {
                    $query->where(function ($q) use ($keyword) {
                        $q->where('nc.sr_no', 'like', "%{$keyword}%");
                    });
                })
                ->rawColumns(['transaction_type', 'payment_method', 'amount', 'remark', 'nfc_card_id', 'created_at', 'nc.card_no', 'nc.sr_no', 'actual_amount', 'promo_amount', 'topup_amount', 'void_reason','is_void'])
                ->make(true);
            }

            return view('nfc_reports.transactions')->with(compact('date', 'nfc_topup', "payment_methods","business_locations","location_id"));
        } else {
            return redirect()->route('nfc/reports');
        }
    }

    public function nfcTopupList(Request $request) {
        $request->validate([
            'token' => 'required|string',
            'user_id' => 'required|string',
            'business_id' => 'required|string'
        ]);

        $user_id = $request->input('user_id');
        $user_token = $request->input('token');
        $business_id = $request->input('business_id');
        $location_id = $request->input('location_id');

        if (!User::checkUserToken($user_token, $user_id)) {
            return response()->json(['errorMessage' => 'Invalid token.'], 200);
        }

        $transactions = NfcTransaction::select(DB::raw('DATE(nfc_transactions.created_at) as date'), DB::raw('SUM(nfc_transactions.amount) as total_amount'), DB::raw('SUM(np.promo_amount) as total_promo_amount'))
                                ->leftjoin('nfc_promos AS np', 'nfc_transactions.nfc_promo_id', '=', 'np.id')
                                ->where('nfc_transactions.business_id', $business_id)
                                ->where('nfc_transactions.is_void', '!=', 1)
                                ->where('nfc_transactions.transaction_type', 'credit')
                                ->where('nfc_transactions.location_id', $location_id)
                                ->whereNotIn('nfc_transactions.remark', ['Order Refund'])
                                ->groupBy(DB::raw('DATE(nfc_transactions.created_at)'))
                                ->orderBy("nfc_transactions.created_at", 'desc')
                                ->orderBy('date', 'desc') // Order by date in ascending order
                                ->get();

        if (!$transactions) {
            return response()->json(['errorMessage' => 'NFC Topup list not found.'], 200);
        }
        return response()->json($transactions, 200);
    }

    public function nfcTopupTransactions(Request $request) {
        $request->validate([
            'token' => 'required|string',
            'user_id' => 'required|string',
            'business_id' => 'required|string',
            'date' => 'required|string'
        ]);

        $user_id = $request->input('user_id');
        $user_token = $request->input('token');
        $business_id = $request->input('business_id');
        $date = $request->input('date');
        $is_location_wise = $request->input('is_location_wise') ? true : false;
        $location_id = $request->input('location_id');

        if (!User::checkUserToken($user_token, $user_id)) {
            return response()->json(['errorMessage' => 'Invalid token.'], 200);
        }

        $query = NfcTransaction::where('nfc_transactions.business_id', $business_id)
                                    ->join('nfc_cards AS nc', 'nfc_transactions.nfc_card_id', '=', 'nc.id')
                                    ->leftjoin('nfc_promos AS np', 'nfc_transactions.nfc_promo_id', '=', 'np.id')
                                    ->whereBetween('nfc_transactions.created_at', [$date . " 00:00:00", $date . " 23:59:59"])
                                    ->where('nfc_transactions.transaction_type', 'credit')
                                    ->where('nfc_transactions.location_id', $location_id)
                                    ->whereNotIn('nfc_transactions.remark', ['Order Refund']);
                                    
        // if( $is_location_wise ) {
        //     $query->where('nfc_transactions.location_id', $request->input('location_id'));
        // }
        $transactions = $query->select(['nfc_transactions.payment_method', 'nfc_transactions.amount', 'nfc_transactions.remark','nfc_transactions.void_reason','nfc_transactions.is_void', 'nfc_transactions.nfc_card_id', 'nfc_transactions.created_at', 
                            'nc.card_no', 'nc.sr_no', 
                            DB::raw('IF(np.promo_amount IS NULL, 0.00, np.promo_amount) as promo_amount'),
                            DB::raw('IF(np.promo_amount IS NULL, nfc_transactions.amount, nfc_transactions.amount - np.promo_amount) as topup_amount')])
                            ->orderBy('nfc_transactions.created_at', 'desc') // Order by date in ascending order
                            ->get();
        $transactions->transform(function ($transaction) {
            $transaction->is_void = (bool) $transaction->is_void;
            return $transaction;
        });

        $query_topup = NfcTransaction::select(DB::raw('DATE(nfc_transactions.created_at) as date'), DB::raw('SUM(nfc_transactions.amount) as total_amount'), DB::raw('SUM(np.promo_amount) as total_promo_amount'))
                                ->leftjoin('nfc_promos AS np', 'nfc_transactions.nfc_promo_id', '=', 'np.id')
                                ->where('nfc_transactions.business_id', $business_id)
                                ->where('nfc_transactions.is_void', '!=', 1)
                                ->whereBetween('nfc_transactions.created_at', [$date . " 00:00:00", $date . " 23:59:59"])
                                ->where('nfc_transactions.transaction_type', 'credit')
                                ->where('nfc_transactions.location_id', $location_id)
                                ->whereNotIn('nfc_transactions.remark', ['Order Refund'])
                                ->groupBy(DB::raw('DATE(nfc_transactions.created_at)'))
                                ->orderBy('nfc_transactions.created_at', 'desc') // Order by date in ascending order
                                ->orderBy('date', 'desc'); // Order by date in ascending order
                
        // if( $is_location_wise ) {
        //     $query_topup->where('nfc_transactions.location_id', $request->input('location_id'));
        // }
        $nfc_topup = $query_topup->first();

        if (!$transactions) {
            return response()->json(['errorMessage' => 'NFC Topup transactions not found.'], 200);
        }

        if( $nfc_topup ) {
            $nfc_topup->total_topup_amount = round(round($nfc_topup->total_amount, 2) - round($nfc_topup->total_promo_amount, 2), 2) . "";
        }
        else{
            $nfc_topup = (object) [
                'date' => $date,
                'total_amount' => '0.00',
                'total_promo_amount' => '0.00',
                'total_topup_amount' => '0.00',
            ];
        }
        
        $response = [
            "transactions" => $transactions,
            "nfc_topup" => $nfc_topup
        ];
        return response()->json($response, 200);
    }


}