<?php

namespace App\Http\Controllers;

use App\BusinessOutlets;
use App\BusinessLocation;
use Illuminate\Http\Request;
use Carbon\Carbon;


class BusinessOutletsController extends Controller
{

    const OUTLET_FILE_FORMATS = [
        ['id'=> 0, 'name'=> "H"],
        ['id'=> 1, 'name'=> "_"],
        ['id'=> 2, 'name'=> "{MID}"],
        ['id'=> 3, 'name'=> "{DATE}"],
        ['id'=> 4, 'name'=> "{mis}"],
        ['id'=> 5, 'name'=> "TD"],
        ['id'=> 6, 'name'=> "{LOGINID}"],
        ['id'=> 7, 'name'=> "D"],
        ['id'=> 8, 'name'=> "T"],
        ['id'=> 9, 'name'=> "."],
        ['id'=> 10, 'name'=> "{SerialNo}"],
    ];

    const DATE_FORMATS = [
        ["id" => "Ymd", "name" => "YMD"],
        [ "id" => "dmY", "name" => "DMYY"],
        ["id" => "ddmmyy", "name" => "DDMMYY"],
        ["id" => "mdy", "name" => "MDY"],
        [ "id" => "dmy", "name" => "DMY"],

    ];

    const OUTLET_REPORT_FORMATS = [
        ['id'=> "machineId", 'name'=> "Machine id"],
        ['id'=> "batch_id", 'name'=> "Batch id"],
        ['id'=> "batch_id_one", 'name'=> "Static batch id(1)"],
        ['id'=> "date", 'name'=> "Date"],
        ['id'=> "hour", 'name'=> "Hour"],
        ['id'=> "hourmin", 'name'=> "HourMinutes"],
        ['id'=> "hourly_transactions", 'name'=> "Total transactions"],
        ['id'=>"gto_sales", 'name'=> "GTO sales"],
        ['id'=> "gst", 'name'=> "GST"],
        ['id'=> "discount", 'name'=> "Discount"],
        ['id'=> "service_charges", 'name'=> "Service charges"],
        ['id'=> "pax", 'name'=> "Pax"],
        ['id'=> "cash", 'name'=> "Cash"],
        ['id'=> "nets", 'name'=> "Nets"],
        ['id'=> "visa", 'name'=> "Visa"],
        ['id'=> "mastercard", 'name'=> "Mastercard"],
        ['id'=> "amex", 'name'=> "Amex"],
        ['id'=> "voucher", 'name'=> "Voucher"],
        ['id'=> "y", 'name'=> "Y"],
        ['id'=> "n", 'name'=> "N"],
        ['id'=> "FTP_login_id", 'name'=> "FTP LOGIN ID"],
        ['id'=> "net_sales", 'name'=> "Net sales"],
        ['id'=> "gross_sales", 'name'=> "Gross Sales"],
        ['id'=> "payable_amount_gst", 'name'=> "Payable amount(Include GST)"],
        ['id'=> "payable_amount", 'name'=> "Payable amount(Exclude GST)"],
        ['id'=> "GTO_Sales_Net_Sales_Inc_Service_Charge_Exc_gst", 'name'=> "GTO Sales (inc service charge, Exc GST)"],
        ['id'=> "GTO_Sales_Inc_GST_And_Service_Charge", 'name'=> "GTO Sales (inc GST and service charge)"],  
        ['id'=> "others", 'name'=> "Others"],
        ['id'=> "d", 'name'=> "D"],
        ['id'=> "t", 'name'=> "T"],
        ['id'=> ".", 'name'=> "."],
        ['id'=> "serial_no", 'name'=> "Serial No."],
        ['id'=> "gto_amount", 'name'=> "GTO amount(0's)"],



    ];
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        $businessId = $request->session()->get('user.business_id'); 
        $outletFileFormats = collect(self::OUTLET_FILE_FORMATS)->pluck('name', 'id');
        $outletDateFormat = collect(self::DATE_FORMATS)->pluck('name', 'id');
        $outletReportFormats = collect(self::OUTLET_REPORT_FORMATS)->pluck('name', 'id');
        if ($request->ajax()) {
            $outlet = BusinessOutlets::where('business_id', $businessId)
            ->select('id', 'name', 'file_formats', 'report_formats', 'start_date',"date_formats",  'report_type')
            ->get()
            ->map(function($outlet) {
                $outlet->file_formats = collect($outlet->file_formats)
                ->map(function ($formatId) {
                    return collect(self::OUTLET_FILE_FORMATS)->firstWhere('id', $formatId)['name'] ?? $formatId;
                })
                ->implode('') . ".txt"; 

                $outlet->report_formats = collect($outlet->report_formats)
                ->map(function ($formatId) {
                    return collect(self::OUTLET_REPORT_FORMATS)->firstWhere('id', $formatId)['name'] ?? $formatId;
                })
                ->implode(' | '); 
                $outlet->file_date_format = $outlet["date_formats"] && $outlet['date_formats']["file"] ? $outlet['date_formats']["file"]  : "";
                $outlet->report_date_format = $outlet["date_formats"] && $outlet['date_formats']["report"] ? $outlet['date_formats']["report"]  : "";
                return $outlet;
            });

            return \DataTables::of($outlet)
            ->addColumn(
                'action',
                function($row) {
                    return '<button type="button" class="btn btn-xs btn-primary btn-modal" data-name="' . $row->name . '" data-id="' . $row->id . '" id="outlet-update"><i class="glyphicon glyphicon-edit"></i> Edit</button>
                            &nbsp;
                             &nbsp;
                            <a href="#" class="btn btn-xs btn-success"  onclick="downloadSample(\'' . $row->file_formats . '\', \'' . $row->report_type . '\', \'' . $row->report_formats . '\')">
                                <i class="glyphicon glyphicon-download"></i> Download Sample
                            </a>';
                }
            )
            ->rawColumns(['action'])
            ->make(true);

        }
        return view("business_outlets.index", compact('outletFileFormats', "outletReportFormats", "outletDateFormat"));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
       
        $fileFormatsArray = json_decode($request->file_formats, true);
        $businessId = $request->session()->get('user.business_id');
        $validateData = $request->validate([
            'name' => 'required|string|max:255',
            'file_formats' => 'required',
            'report_formats' => 'required|array',
            'start_date' => 'required|date',
            "file_date_format" => "required",
            "report_date_format" => "required",
        ]);
        $outlet = BusinessOutlets::where('business_id', $businessId)
                        ->where('name', $request->name)
                        ->first();

        if ($outlet) {
            return response()->json(['success' => false, 'message' => 'Outlet already exists']);
        }
        $newOutlet = BusinessOutlets::create([
            'business_id' => $businessId,
            'name' => $request->name,
            'start_date' => $request->start_date,
            'report_type' => $request->report_type,
            "file_formats" => $fileFormatsArray,
            "report_formats" => $request->report_formats,
            "date_formats" =>["report"=>$request->report_date_format,"file" =>$request->file_date_format],
            "serial_no" => $request->serial_no,
            "use_pipe_for_report" => $request->use_pipe_for_report ? 1 : 0,
            "file_extension" => $request->file_extension ? 1 : 0
        ]);
        return response()->json(['success' => true], 201);
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\BusinessOutlets  $businessOutlets
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $outlet = BusinessOutlets::where('id', $id)->first();
        $fileFormatArray = [];
        $outlet->file_formats = collect($outlet->file_formats)
            ->map(function ($formatId) use (&$fileFormatArray) {
                $fileFormatArray[] = $formatId; 
                return collect(self::OUTLET_FILE_FORMATS)->firstWhere('id', $formatId)['name'] ?? $formatId;
            })
            ->implode('') . ".txt"; 
        $outlet->format_array = $fileFormatArray;
        return response()->json(['success' => true, 'data' => $outlet], 201);

    }


    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\BusinessOutlets  $businessOutlets
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id){
        $validatedData = $request->validate([
            'name' => 'required|string|max:255',
            'file_formats' => 'required',
            'start_date' => 'required|date',
            'report_formats' => 'required|array',
            'report_type' => 'required|in:hourly,date_wise',
        ]);
        $validatedData["serial_no"] = $request->serial_no;
        $validatedData['use_pipe_for_report'] = $request->use_pipe_for_report ? 1 : 0;
        $validatedData['file_extension'] = $request->file_extension ? 1 : 0;
        $validatedData['file_formats'] = json_decode($validatedData['file_formats'], true);
        $validatedData['date_formats'] =["report"=>$request->report_date_format,"file" =>$request->file_date_format];
        $businessOutlets = BusinessOutlets::findOrFail($id);
        $businessOutlets->update($validatedData);
        return response()->json([
            'success' => true,
            'message' => __("Service charges settings updated successfully.")
        ]);
    }


    
    /**
     * Show the outlets locations
     *
     * @return \Illuminate\Http\Response
     */
    public function outletsLocations(Request $request)
    {
        $businessId = $request->session()->get('user.business_id'); 
        $currentDate = Carbon::now()->format('Y-m-d'); 

        if ($request->ajax()) {
            $outlet = BusinessOutlets::where('business_outlets.business_id', $businessId)
            ->leftjoin(
                'business_locations as business_locations',
                'business_locations.outlet_location_id',
                '=',
                'business_outlets.id'
            )
            ->where('business_locations.business_id', '=', $businessId)
                ->whereNotNull('business_locations.ftp_server')
                ->whereNotNull('business_locations.machine_id')
                ->whereNotNull('business_locations.ftp_password')
                ->select(
                    'business_outlets.id', 
                    'business_outlets.name', 
                    'business_outlets.start_date',
                    'business_outlets.report_type',
                    'business_locations.ftp_server',
                    'business_locations.machine_id',
                    'business_locations.ftp_password',
                    "business_locations.id as locationId"
                )
                ->get();
            return \DataTables::of($outlet)
                ->addColumn(
                    'action',
                    function($row) use($currentDate) {
                        return '
                            <input type="date" class="form-control sales-date-picker" 
                            id="sales-date-' . $row->id . '" 
                           max="' . $currentDate . '"
                            min="' . $row->start_date . '" 
                            data-id="' . $row->id . '" 
                            data-location ="'.$row->locationId.'"
                            required>
                           
                            <a href="" class="btn btn-xs btn-success" download="" path="" id="sales-download-' . $row->id . '" style="pointer-events: none; opacity: 0.5;">
                                <i class="glyphicon glyphicon-download"></i> Download
                            </a>
                           <button type="button" class="btn btn-xs btn-info  upload-btn upload_sales_file" id="sales-upload-' . $row->id . '" disabled="true" data-location ="'.$row->locationId.'" data-id="'.$row->id.'">
                                <i class="glyphicon glyphicon-upload"></i> Upload Files
                            </button>';
                    }
                )
                ->rawColumns(['action'])
                ->make(true);
        }
        return view("business_outlets.outlet-locations");
    }
    
}