<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Terminal;
use App\BusinessLocation;
use Datatables;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;
use App\User;
use Carbon\Carbon;
use App\Utils\TransactionUtil;

class TerminalController extends Controller
{
    public function __construct() {

    }

    public function index()
    {
        if (!auth()->user()->can('access_tables')) {
            abort(403, 'Unauthorized action.');
        }

        $business_id = request()->session()->get('user.business_id');

        if (request()->ajax()) {

            $terminals = Terminal::where('terminals.business_id', $business_id)
                               ->join('business_locations AS BL', 'terminals.location_id', '=', 'BL.id')
                               ->select(['BL.name as location_id', 'terminals.name', 'terminals.unique_id', 'terminals.fcm_token',
                               'terminals.device_name', 'terminals.device_id',
                               'terminals.status', 'terminals.created_at', 'terminals.updated_at', 'terminals.deleted_at', 
                               DB::raw("CASE terminals.status WHEN 'active' THEN 'Activated' ELSE 'Deactivated' END AS status"),
                               'terminals.last_logged_in', 'terminals.id', 'terminals.business_id', 'terminals.terminal_type',
                               DB::raw("
                                    CASE terminals.terminal_type
                                        WHEN 'primary' THEN 'Primary'
                                        WHEN 'secondary' THEN 'Secondary'
                                        ELSE 'Sub-Terminal'
                                    END AS terminal_type
                                ")]);

            return Datatables::of($terminals)
                ->addColumn(
                    'action',
                    '@role("Admin#' . $business_id . '")
                    <button data-href="{{action(\'TerminalController@edit\', [$id])}}" class="btn btn-xs btn-primary edit_terminal_button"><i class="glyphicon glyphicon-edit"></i> @lang("messages.edit")</button>
                        &nbsp;
                    @endrole
                    @role("Admin#' . $business_id . '")
                        <button data-href="{{action(\'TerminalController@show\', [$id])}}" class="btn btn-xs btn-warning view_terminal_button"><i class="glyphicon glyphicon-eye-open"></i> @lang("messages.view")</button>
                        &nbsp;
                    @endrole
                    @role("Admin#' . $business_id . '")
                        <button data-href="{{action(\'TerminalController@destroy\', [$id])}}" class="btn btn-xs btn-danger delete_terminal_button"><i class="glyphicon glyphicon-trash"></i> @lang("messages.delete")</button>
                    @endrole'
                )
                ->removeColumn('id')
                ->rawColumns(['action', 'location_id', 'name', 'unique_id', 'fcm_token', 'device_name', 'device_id', 'status', 'created_at', 'updated_at', 'deleted_at', 'last_logged_in', 'id', 'device_name'])
                ->make(true);
       }

       return view('terminal.index');
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        if (!auth()->user()->can('terminals.access')) {
            abort(403, 'Unauthorized action.');
        }

        $business_id = request()->session()->get('user.business_id');
        $business_locations = BusinessLocation::forDropdown($business_id);

        return view('terminal.create')
            ->with(compact('business_locations'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        if (!auth()->user()->can('terminals.access')) {
            abort(403, 'Unauthorized action.');
        }

        try {
            // Define validation rules
            $rules = [
                'name' => 'required|string|max:255',
                'location_id' => 'required',
                'terminal_type' => "required"
            ];

            // Define custom error messages if needed
            $messages = [
                'name.required' => 'The name field is required.',
                'location_id.required' => 'The location field is required.',
                'terminal_type.required' => 'The terminal type field is required.'
            ];

            // Perform validation
            $validator = Validator::make($request->all(), $rules, $messages);

            // Check if validation fails
            if ($validator->fails()) {
                return redirect()->back()->withErrors($validator)->withInput();
            }
            
            $input = $request->only(['name', 'location_id', 'terminal_type']);

            $business_id = $request->session()->get('user.business_id');
            $terminal = Terminal::where('business_id', $business_id)
                            ->where('name', $input['name'])
                            ->where('status', 'active')
                            ->where('location_id', $input['location_id'])
                            ->whereNull('deleted_at')
                            ->first();
            if( $terminal ) {
                $output = [
                    'success' => false,
                    'message' => "Terminal with " . $input['name'] . " is already exists"
                ];
            } else {
                if( $input['terminal_type'] == 'primary' ) {
                    $terminal = Terminal::where('business_id', $business_id)
                                ->where('terminal_type', 'primary')
                                ->where('status', 'active')
                                ->where('location_id', $input['location_id'])
                                ->whereNull('deleted_at')
                                ->first();
                    if( $terminal ) {
                        $output = [
                            'success' => false,
                            'message' => "Primary terminal is already exists in this business location"
                        ];
                    } else {
                        $input['business_id'] = $business_id;
                        Terminal::create($input);

                        $output = [
                            'success' => true,
                            'message' => __("lang_v1.added_success")
                        ];
                    }
                } else {
                    $input['business_id'] = $business_id;
                    Terminal::create($input);

                    $output = [
                        'success' => true,
                        'message' => __("lang_v1.added_success")
                    ];
                }
            }
        } catch (\Exception $e) {
            \Log::emergency("File:" . $e->getFile(). "Line:" . $e->getLine(). "Message:" . $e->getMessage());
            
            $output = [
                'success' => false,
                'message' => __("messages.something_went_wrong")
            ];
        }

        return $output;
    }

    /**
     * Show the form for editing the specified resource.
     * @return Response
     */
    public function edit($id)
    {
        if (!auth()->user()->can('access_tables')) {
            abort(403, 'Unauthorized action.');
        }

        if (request()->ajax()) {
            $business_id = request()->session()->get('user.business_id');
            $terminal = Terminal::where('business_id', $business_id)->findOrFail($id);
            return view('terminal.edit')->with(compact('terminal'));
        }
    }

    /**
     * Update the specified resource in storage.
     * @param  Request $request
     * @return Response
     */
    public function update(Request $request, $id)
    {
        if (!auth()->user()->can('access_tables')) {
             abort(403, 'Unauthorized action.');
        }

        // Define validation rules
        $rules = [
            'name' => 'required|string|max:255',
            'status' => 'required',
            'terminal_type' => 'required'
        ];

        // Define custom error messages if needed
        $messages = [
            'name.required' => 'The name field is required.',
            'status.required' => 'The status field is required.',
            'terminal_type.required' => 'The terminal type field is required.'
        ];

        // Perform validation
        $validator = Validator::make($request->all(), $rules, $messages);

        // Check if validation fails
        if ($validator->fails()) {
            return redirect()->back()->withErrors($validator)->withInput();
        }

        if (request()->ajax()) {
            try {
                $input = $request->only(['name', 'status', 'terminal_type']);

                $business_id = $request->session()->get('user.business_id');

                $location_id = null;
                $terminalExisting = Terminal::where('business_id', $business_id)->findOrFail($id);
                if($terminalExisting) {
                    $location_id = $terminalExisting->location_id;
                }

                $terminalsByLocation = Terminal::where('business_id', $business_id)
                            ->where('name', $input['name'])
                            ->whereNotIn('id', [$id])
                            ->where('status', 'active')
                            ->where('location_id', $location_id)
                            ->whereNull('deleted_at')
                            ->first();
                if( $terminalsByLocation ) {
                    $output = [
                        'success' => false,
                        'message' => "Terminal with " . $input['name'] . " is already exists"
                    ];
                } else {
                    if( $input['terminal_type'] == 'primary' ) {
                        $terminal = Terminal::where('business_id', $business_id)
                                ->where('terminal_type', 'primary')
                                ->whereNotIn('id', [$id])
                                ->where('status', 'active')
                                ->where('location_id', $location_id)
                                ->whereNull('deleted_at')
                                ->first();
                        if( $terminal ) {
                            $output = [
                                'success' => false,
                                'message' => "Primary terminal is already exists in this business location"
                            ];
                        } else {
                            $terminal = Terminal::where('business_id', $business_id)->findOrFail($id);
                            $terminal->name = $input['name'];
                            $terminal->status = $input['status'];
                            $terminal->terminal_type = $input['terminal_type'];
                            $terminal->save();

                            $output = [
                                'success' => true,
                                'message' => __("lang_v1.updated_success")
                            ];
                        }
                    } else {
                        $terminal = Terminal::where('business_id', $business_id)->findOrFail($id);
                        $terminal->name = $input['name'];
                        $terminal->status = $input['status'];
                        $terminal->terminal_type = $input['terminal_type'];
                        $terminal->save();

                        $output = [
                            'success' => true,
                            'message' => __("lang_v1.updated_success")
                        ];
                    }
                }
            } catch (\Exception $e) {
                \Log::emergency("File:" . $e->getFile(). "Line:" . $e->getLine(). "Message:" . $e->getMessage());
            
                $output = [
                    'success' => false,
                    'message' => __("messages.something_went_wrong")
                ];
            }

            return $output;
        }
    }

    /**
     * Remove the specified resource from storage.
     * @return Response
     */
    public function destroy($id)
    {
        if (!auth()->user()->can('access_tables')) {
            abort(403, 'Unauthorized action.');
        }

        if (request()->ajax()) {
            try {
                $business_id = request()->user()->business_id;
                $terminal = Terminal::where('business_id', $business_id)->findOrFail($id);
                $terminal->delete();

                $output = [
                    'success' => true,
                    'msg' => __("lang_v1.deleted_success")
                ];
            } catch (\Exception $e) {
                \Log::emergency("File:" . $e->getFile(). "Line:" . $e->getLine(). "Message:" . $e->getMessage());
            
                $output = [
                    'success' => false,
                    'msg' => __("messages.something_went_wrong")
                ];
            }

            return $output;
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Product  $product
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        if (!auth()->user()->can('terminals.view')) {
            abort(403, 'Unauthorized action.');
        }

        $business_id = request()->session()->get('user.business_id');

        $terminal = Terminal::where('terminals.business_id', $business_id)
                                ->where('terminals.business_id', $business_id)
                                ->where('terminals.id', $id)
                                ->join('business_locations AS BL', 'terminals.location_id', '=', 'BL.id')
                                ->select(['BL.name as location', 'terminals.name', 'terminals.unique_id', 'terminals.fcm_token',
                                'terminals.device_name', 'terminals.device_id',
                                'terminals.status', 'terminals.created_at', 'terminals.updated_at', 'terminals.deleted_at', 
                                DB::raw("CASE terminals.status WHEN 'active' THEN 'Activated' ELSE 'Deactivated' END AS    status"), 
                                'terminals.last_logged_in', 'terminals.id', 'terminals.location_id', 'terminals.business_id', 'terminals.terminal_type',
                                DB::raw("
                                    CASE terminals.terminal_type
                                        WHEN 'primary' THEN 'Primary'
                                        WHEN 'secondary' THEN 'Secondary'
                                        ELSE 'Sub-Terminal'
                                    END AS terminal_type
                                ")])
                                ->first();

        return view('terminal.show')->with(compact('terminal'));
    }

    public function list(Request $request) {
        $request->validate([
            'token' => 'required|string',
            'user_id' => 'required|string',
            'business_id' => 'required|string'
        ]);

        $user_id = $request->input('user_id');
        $user_token = $request->input('token');
        $business_id = $request->input('business_id');

        if (!User::checkUserToken($user_token, $user_id)) {
            return response()->json(['errorMessage' => 'Invalid token.'], 200);
        }

        $query = Terminal::where('terminals.business_id', $business_id)
                                ->where('terminals.status', 'active')
                                ->whereNull('terminals.deleted_at')
                                ->join('business_locations AS BL', 'terminals.location_id', '=', 'BL.id')
                                ->select(['BL.name as location', 'terminals.name', 'terminals.unique_id', 'terminals.fcm_token',
                                'terminals.device_name', 'terminals.device_id',
                                'terminals.status', 'terminals.created_at', 'terminals.updated_at', 'terminals.deleted_at',
                                'terminals.last_logged_in', 'terminals.id', 'terminals.location_id', 'terminals.business_id', 'terminals.terminal_type']);

        if( $request->input('location_id') ) {
            $query->where('terminals.location_id', $request->input('location_id'));
        }
        $terminals = $query->get();

        if (!$terminals) {
            return response()->json(['errorMessage' => 'Terminals not found.'], 200);
        }

        return response()->json($terminals, 200);
    }

    public function updateFcmToken(Request $request) {
        $request->validate([
            'token' => 'required|string',
            'user_id' => 'required|string',
            'business_id' => 'required|string',
            'fcm_token' => 'required|string',
            'terminal_id' => 'required'
        ]);

        $user_id = $request->input('user_id');
        $user_token = $request->input('token');
        $business_id = $request->input('business_id');
        $fcm_token = $request->input('fcm_token');
        $terminal_id = $request->input('terminal_id');

        if (!User::checkUserToken($user_token, $user_id)) {
            return response()->json(['errorMessage' => 'Invalid token.'], 200);
        }

        $terminal = Terminal::where('business_id', $business_id)->findOrFail($terminal_id);
        if( !$terminal ) {
            return response()->json(['errorMessage' => 'Terminal not found.'], 200);
        }

        $terminal->fcm_token = $fcm_token;
        $terminal->save();

        $terminal = Terminal::where('business_id', $business_id)->findOrFail($terminal_id);
        if (!$terminal) {
            return response()->json(['errorMessage' => 'Terminal not found.'], 200);
        }

        return response()->json($terminal, 200);
    }

    public function updateDeviceDetail(Request $request) {
        $request->validate([
            'token' => 'required|string',
            'user_id' => 'required|string',
            'business_id' => 'required|string',
            'terminal_id' => 'required'
        ]);

        $user_id = $request->input('user_id');
        $user_token = $request->input('token');
        $business_id = $request->input('business_id');
        $terminal_id = $request->input('terminal_id');

        $device_name = $request->input('device_name') ? $request->input('device_name') : null;
        $device_id = $request->input('device_id') ? $request->input('device_id') : null;
        $fcm_token = $request->input('fcm_token') ? $request->input('fcm_token') : null;
        $is_online = $request->input('is_online') ? 1 : 0;

        if (!User::checkUserToken($user_token, $user_id)) {
            return response()->json(['errorMessage' => 'Invalid token.'], 200);
        }

        $terminal = Terminal::where('business_id', $business_id)->findOrFail($terminal_id);
        if( !$terminal ) {
            return response()->json(['errorMessage' => 'Terminal not found.'], 200);
        }

        if( $request->input('fcm_token') )
            $terminal->fcm_token = $fcm_token;
    
        if( $request->input('device_name') )
            $terminal->device_name = $device_name;

        if( $request->input('device_id') )
            $terminal->device_id = $device_id;

        $terminal->is_online = $is_online ? 1 : 0;
        if( $is_online ) {
            $terminal->last_logged_in = date("Y-m-d h:i:s", time());
        }

        $terminal->save();

        $terminal = Terminal::where('business_id', $business_id)->findOrFail($terminal_id);
        if (!$terminal) {
            return response()->json(['errorMessage' => 'Terminal not found.'], 200);
        }

        return response()->json($terminal, 200);
    }

    public function updateTerminalStatus(Request $request) {
        $request->validate([
            'token' => 'required|string',
            'user_id' => 'required|string',
            'business_id' => 'required|string',
            'terminal_id' => 'required',
            'is_online' => 'required'
        ]);

        $user_id = $request->input('user_id');
        $user_token = $request->input('token');
        $business_id = $request->input('business_id');
        $is_online = $request->input('is_online');
        $terminal_id = $request->input('terminal_id');

        if (!User::checkUserToken($user_token, $user_id)) {
            return response()->json(['errorMessage' => 'Invalid token.'], 200);
        }

        $terminal = Terminal::where('business_id', $business_id)->findOrFail($terminal_id);
        if( !$terminal ) {
            return response()->json(['errorMessage' => 'Terminal not found.'], 200);
        }

        $terminal->is_online = $is_online ? 1 : 0;
        if( $is_online )
            $terminal->last_logged_in = date("Y-m-d h:i:s", time());

        $terminal->save();

        $terminal = Terminal::where('business_id', $business_id)->findOrFail($terminal_id);
        if (!$terminal) {
            return response()->json(['errorMessage' => 'Terminal not found.'], 200);
        }

        return response()->json($terminal, 200);
    }

    public function fetchTerminalDetail(Request $request) {
        $request->validate([
            'token' => 'required|string',
            'user_id' => 'required',
            'business_id' => 'required',
            'terminal_id' => 'required'
        ]);

        $user_id = $request->input('user_id');
        $user_token = $request->input('token');
        $business_id = $request->input('business_id');
        $terminal_id = $request->input('terminal_id');

        if (!User::checkUserToken($user_token, $user_id)) {
            return response()->json(['errorMessage' => 'Invalid token.'], 200);
        }

        $terminal = Terminal::where('terminals.business_id', $business_id)
                                ->where('terminals.status', 'active')
                                ->where('terminals.id', $terminal_id)
                                ->whereNull('terminals.deleted_at')
                                ->join('business_locations AS BL', 'terminals.location_id', '=', 'BL.id')
                                ->select(['BL.name as location', 'terminals.name', 'terminals.unique_id', 'terminals.fcm_token',
                                'terminals.device_name', 'terminals.device_id', 'terminals.is_online',
                                'terminals.status', 'terminals.created_at', 'terminals.updated_at', 'terminals.deleted_at',
                                'terminals.last_logged_in', 'terminals.id', 'terminals.location_id', 'terminals.business_id', 'terminals.terminal_type'])
                                ->first();

        if (!$terminal) {
            return response()->json(['errorMessage' => 'Terminal not found.'], 200);
        }

        return response()->json($terminal, 200);
    }

    public function getTerminals(Request $request)
    {
        if ($request->ajax() && !empty($request->input('business_location_id'))) {
            $business_location_id = $request->input('business_location_id');
            $terminals = Terminal::where('location_id', $business_location_id)
                ->select(['name', 'id'])
                ->get();
            $html = '<option selected="selected" value="">All</option>';
            if ($terminals->isNotEmpty()) {
                foreach ($terminals as $key => $terminal) {
                    $html .= '<option value="' . $terminal->id . '">' . $terminal->name . '</option>';
                }
            }else {
                $html = '<option selected="selected" value="">Please Select</option>';
            }
            echo $html;
            exit;
        }
    }
}