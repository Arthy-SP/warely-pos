<?php

namespace App\Http\Controllers;
use Illuminate\Support\Facades\Session;
use Yajra\DataTables\Facades\DataTables;
use App\ServiceChargesSettings;
use Illuminate\Http\Request;
use App\WalletTransaction;
use App\BusinessWallet;
use \Carbon;    
use Illuminate\Support\Facades\DB;



class BusinessWalletTransationController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {

        $date_filters['this_yr'] = ['start' => Carbon::today()->startOfYear()->toDateString(), 'end' => Carbon::today()->endOfYear()->toDateString()];
        $date_filters['this_month']['start'] = date('Y-m-01');
        $date_filters['this_month']['end'] = date('Y-m-t');
        $date_filters['this_week']['start'] = date('Y-m-d', strtotime('monday this week'));
        $date_filters['this_week']['end'] = date('Y-m-d', strtotime('sunday this week'));
        $businessId = $request->session()->get('user.business_id');
        $walletBalance = BusinessWallet::where('business_id', $businessId)->first();
        if ($request->ajax()) {
            $query = WalletTransaction::where('business_id', $businessId)
                ->select("transaction_type", 'transaction_date', 'amount', 'service_type', 'phone', 'available_balance');
    
            $start_date = $request->input('start_date');
            $end_date = $request->input('end_date');
    
            if (!empty($start_date) && !empty($end_date)) {
                $start_date = date('Y-m-d 00:00:00', strtotime($start_date));
                $end_date = date('Y-m-d 23:59:59', strtotime($end_date));
    
                $query->whereBetween('transaction_date', [$start_date, $end_date]);
            }
    
            $service_type = $request->input('service_type');
            if (!empty($service_type)) {
                $query->where('service_type', $service_type);
            }
    
            $businessWallet = $query->orderBy('transaction_date', 'desc')->get();
    
            return Datatables::of($businessWallet)->make(true);
        }
        $walletBalance = number_format($walletBalance->balance, 2);
        return view('wallet_transations.index', compact("date_filters", "walletBalance"));
    }
    
    public function summeries(Request $request)
    {
        $businessId = $request->session()->get('user.business_id');
        $start_date = $request->get('start');
        $end_date = $request->get('end');
        $walletTopUp = WalletTransaction::where('business_id', $businessId)
        ->whereRaw('DATE(created_at) BETWEEN ? AND ?', [$start_date, $end_date])
        ->where('transaction_type', 'credit')
        ->select(DB::raw('SUM(amount) as total'))
        ->first()
        ->total;
        $walletDeductions = WalletTransaction::where('business_id', $businessId)
            ->whereRaw('DATE(created_at) BETWEEN ? AND ?', [$start_date, $end_date])
            ->where('transaction_type', 'debit')
            ->where('service_type', 'SMS OTP charges')
            ->select(DB::raw('SUM(amount) as total'))
            ->first()
            ->total;
        return response()->json([
            'total_wallet_topup_amount' => $walletTopUp ? $walletTopUp : 0.00,
            'total_deductions' => $walletDeductions ? $walletDeductions : 0.00,
        ]);
    }
}
