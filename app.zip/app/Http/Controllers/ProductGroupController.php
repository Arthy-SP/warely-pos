<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\ProductGroup;
use App\BusinessLocation;
use Datatables;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;

class ProductGroupController extends Controller
{
    public function __construct() {

    }

    public function index()
    {
        if (!auth()->user()->can('access_tables')) {
            abort(403, 'Unauthorized action.');
        }

        $business_id = request()->session()->get('user.business_id');

        if (request()->ajax()) {
            
            $productGroups = ProductGroup::where('product_groups.business_id', $business_id)
                    ->select(['product_groups.id', 'product_groups.name', 'product_groups.business_id', 'product_groups.location_id', 'product_groups.created_at']);
            
            return Datatables::of($productGroups)
               ->addColumn(
                   'action',
                   '@role("Admin#' . $business_id . '")
                   <button data-href="{{action(\'ProductGroupController@edit\', [$id])}}" class="btn btn-xs btn-primary edit_product_group_button"><i class="glyphicon glyphicon-edit"></i> @lang("messages.edit")</button>
                       &nbsp;
                   @endrole
                   @role("Admin#' . $business_id . '")
                       <button data-href="{{action(\'ProductGroupController@destroy\', [$id])}}" class="btn btn-xs btn-danger delete_product_group_button"><i class="glyphicon glyphicon-trash"></i> @lang("messages.delete")</button>
                   @endrole'
               )
               ->removeColumn('id')
               ->rawColumns(['action', 'name'])
               ->make(true);
       }

       return view('product_groups.index');
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        if (!auth()->user()->can('product_groups.access')) {
            abort(403, 'Unauthorized action.');
        }

        $business_id = request()->session()->get('user.business_id');
        $business_locations = BusinessLocation::forDropdown($business_id);

        return view('product_groups.create')
            ->with(compact('business_locations'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        if (!auth()->user()->can('product_groups.access')) {
            abort(403, 'Unauthorized action.');
        }

        try {
            // Define validation rules
            $rules = [
                'name' => 'required|string|max:255'
            ];

            // Define custom error messages if needed
            $messages = [
                'name.required' => 'The name field is required.'
            ];

            // Perform validation
            $validator = Validator::make($request->all(), $rules, $messages);

            // Check if validation fails
            if ($validator->fails()) {
                return redirect()->back()->withErrors($validator)->withInput();
            }
            
            $input = $request->only(['name']);
            $business_id = $request->session()->get('user.business_id');
            $input['business_id'] = $business_id;
            ProductGroup::create($input);
            $output = [
                'success' => true,
                'message' => __("invoice.added_success")
            ];
        } catch (\Exception $e) {
            \Log::emergency("File:" . $e->getFile(). "Line:" . $e->getLine(). "Message:" . $e->getMessage());
            
            $output = [
                'success' => false,
                'message' => __("messages.something_went_wrong")
            ];
        }

        return $output;
    }

    /**
     * Show the form for editing the specified resource.
     * @return Response
     */
    public function edit($id)
    {
        if (!auth()->user()->can('access_tables')) {
            abort(403, 'Unauthorized action.');
        }

        if (request()->ajax()) {
            $business_id = request()->session()->get('user.business_id');
            $productGroup = ProductGroup::where('business_id', $business_id)->find($id);
            
            return view('product_groups.edit')->with(compact('productGroup'));
        }
    }

    /**
     * Update the specified resource in storage.
     * @param  Request $request
     * @return Response
     */
    public function update(Request $request, $id)
    {
        if (!auth()->user()->can('access_tables')) {
             abort(403, 'Unauthorized action.');
        }

        // Define validation rules
        $rules = [
            'name' => 'required|string|max:255'
        ];

        // Define custom error messages if needed
        $messages = [
            'name.required' => 'The name field is required.'
        ];

        // Perform validation
        $validator = Validator::make($request->all(), $rules, $messages);

        // Check if validation fails
        if ($validator->fails()) {
            return redirect()->back()->withErrors($validator)->withInput();
        }

        if (request()->ajax()) {
            try {
                $input = $request->only(['name']);
                $business_id = $request->session()->get('user.business_id');

                $productGroup = ProductGroup::where('business_id', $business_id)->findOrFail($id);
                $productGroup->name = $input['name'];
                $productGroup->save();
                $output = [
                    'success' => true,
                    'message' => __("lang_v1.updated_success")
                ];
            } catch (\Exception $e) {
                \Log::emergency("File:" . $e->getFile(). "Line:" . $e->getLine(). "Message:" . $e->getMessage());
            
                $output = ['success' => false,
                            'message' => __("messages.something_went_wrong")
                        ];
            }

            return $output;
        }
    }

    /**
     * Remove the specified resource from storage.
     * @return Response
     */
    public function destroy($id)
    {
        if (!auth()->user()->can('access_tables')) {
            abort(403, 'Unauthorized action.');
        }

        if (request()->ajax()) {
            try {
                $business_id = request()->user()->business_id;
                $productGroup = ProductGroup::where('business_id', $business_id)->findOrFail($id);
                $productGroup->delete();

                $output = ['success' => true,
                            'msg' => __("lang_v1.deleted_success")
                            ];
            } catch (\Exception $e) {
                \Log::emergency("File:" . $e->getFile(). "Line:" . $e->getLine(). "Message:" . $e->getMessage());
            
                $output = ['success' => false,
                            'msg' => __("messages.something_went_wrong")
                        ];
            }

            return $output;
        }
    }
}