<?php

namespace App\Http\Controllers\KDS;

use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Illuminate\Routing\Controller;

use App\User;
use App\Transaction;
use App\TransactionSellLine;
use App\Product;
use App\TransactionVoidSellLine;
use App\PosResTables;
use App\Utils\ProductUtil;
use App\Utils\TransactionUtil;
use App\Variation;
use App\Restaurant\ResTable;
use App\Http\Controllers\API\ApiPrinterController;

use Carbon\Carbon;
use App\Category;

class HistoryController extends Controller
{
    /**
     * All Utils instance.
     *
     */
    protected $productUtil;
    protected $printerController;

    /**
     * Constructor
     *
     * @param ProductUtils $product
     * @return void
     */
    public function __construct(ProductUtil $productUtil, TransactionUtil $transactionUtil, ApiPrinterController $printerController)
    {
        $this->productUtil = $productUtil;
        $this->transactionUtil = $transactionUtil;
        $this->printerController = $printerController;
    }

    public function getTodayHistoryList(Request $request)
    {

        $input = $request;

        if(isset($input['token']))
        {
            $result = User::checkUserToken($input['token'], $input['user_id']);

            if($result)
            {
                try {
                    $orderTypes = (isset($input["orderTypes"]) && $input["orderTypes"]) ? $input["orderTypes"] : null;
                    $date = (isset($input["date"]) && $input["date"]) ? $input["date"] . " 00:00:00" : Carbon::today();

                    $kitchen_group = !empty($input['kitchen_group']) ? $input['kitchen_group'] : "";
                    $categories = !empty($input['categories']) ? $input['categories'] : "";

                    if(!empty($kitchen_group) && !empty($categories)) {
                        $category = $this->printerController->get_printer_category_by_id($input);
                        $category = json_decode(json_encode($category), true);
                        $category = $category['original'];

                        $filtered_categories = array_filter($category, function($item) use ($kitchen_group) {
                            return isset($item['id']) && in_array($item['id'], $kitchen_group);
                        });

                        $filtered_categories = array_values($filtered_categories);
                        
                        $categories_array = [];
                        foreach ($filtered_categories as $category) {
                            if (isset($category['categories']) && is_array($category['categories'])) {
                                $categories_array = array_merge($categories_array, $category['categories']);
                            }
                        }

                        $unique_categories = array_unique($categories_array);
                        $unique_categories = array_values($unique_categories);
                        // dd($unique_categories);
                        $filter_new_categories = array_merge($categories, $unique_categories);
                        $filterCategories = array_unique($filter_new_categories);

                    } elseif(!empty($kitchen_group) && empty($categories)) {
                        $category = $this->printerController->get_printer_category_by_id($input);
                        $category = json_decode(json_encode($category), true);
                        $category = $category['original'];

                        $filtered_categories = array_filter($category, function($item) use ($kitchen_group) {
                            return isset($item['id']) && in_array($item['id'], $kitchen_group);
                        });

                        $filtered_categories = array_values($filtered_categories);
                        
                        $categories_array = [];
                        foreach ($filtered_categories as $category) {
                            if (isset($category['categories']) && is_array($category['categories'])) {
                                $categories_array = array_merge($categories_array, $category['categories']);
                            }
                        }

                        $unique_categories = array_unique($categories_array);
                        $filterCategories = array_values($unique_categories);
                        //$categories = array_merge($categories, $unique_categories);
                        //$filterCategories = array_unique($categories);
                    } elseif(!empty($categories) && empty($kitchen_group)) {
                        $filterCategories = $categories;
                    } else {
                        $filterCategories = [];
                    }

                    $query = Transaction::select('transactions.*')
                    ->with('sell_lines.variations.product')
                    ->where(function($query){
                        $query->where('transactions.kds_status' , '=', 'close_ticket');
                    })
                    ->where('transactions.business_id', '=', $input['business_id'])
                    ->where('transactions.location_id', '=', $input['location_id'])
                    ->whereDate('transactions.created_at', '>=', $date);

                    if (!empty($filterCategories)) {
                        $query->whereHas('sell_lines.variations.product', function ($query) use ($filterCategories) {
                            $query->whereIn('category_id', $filterCategories);
                        });
                    }

                    if($orderTypes) {
                        $query->whereIn('transactions.type_for_api', $orderTypes);
                    }

                    $transactions = $query->orderby('transactions.updated_at', 'DESC')
                                        ->get();

                    $today_history_list = [];
                    foreach ($transactions as $key => $value) 
                    {
                        $voidSellLines = [];
                        $transactionVoidSellLines = TransactionVoidSellLine::where('transaction_id', $value['id'])->get();

                        if( $transactionVoidSellLines && !empty($transactionVoidSellLines) && count($transactionVoidSellLines) ) {
                            foreach ($transactionVoidSellLines as $key => $transactionVoidSellLine) {
                                $voidSellLines[] = [
                                    'sl_transaction_id' => $transactionVoidSellLine['sell_line_id'],
                                    'sl_name' => $transactionVoidSellLine['name'],
                                    'sl_product_id' => 0,
                                    'sl_variation_id' => 0,
                                    'sl_quantity' => $transactionVoidSellLine['qty'],
                                    'sl_quantity_returned' => $transactionVoidSellLine["qty"],
                                    'sl_quantity_returned_note' => $transactionVoidSellLine["reason"],
                                    'sl_serve_later_quantity' => 0,
                                    'sl_kds_isCross' => 0,
                                    'moditiers' => [],
                                    'is_voided' => 1
                                ];
                            }
                        }

                        $food_items = [];
                        foreach ($value['sell_lines'] as $sellLinesKey => $sellLinesValue)
                        {
                        if (
                            $sellLinesValue["parent_sell_line_id"] == null &&
                            $sellLinesValue["transaction_id"] == $value['id'] &&
                            (empty($filterCategories) || in_array($sellLinesValue['variations']->product->category_id, $filterCategories))
                        ) {
                            if($sellLinesValue["parent_sell_line_id"] == null && $sellLinesValue["transaction_id"] == $value['id'])
                            {
                                $moditiers = [];
                                foreach ($value['sell_lines'] as $sellLinesKey1 => $sellLinesValue1)
                                {
                                    if($sellLinesValue1["parent_sell_line_id"] != null && $sellLinesValue1["parent_sell_line_id"] == $sellLinesValue['id'] && $sellLinesValue1["children_type"] == "modifier")
                                    {
                                        $moditiers[] = [
                                            'modifier_sell_line_id' => $sellLinesValue1['id'],
                                            'modifier_product_id' => $sellLinesValue1['variations']->product_id,
                                            'variations_id' => $sellLinesValue1['variations']->id,
                                            'variations_name' => $sellLinesValue1['variations']->name,
                                            'variations_quantity' => $sellLinesValue1["quantity"]
                                        ];
                                    }
                                }

                                $slCategoryId = $sellLinesValue['variations']->product->category_id;

                                $category = Category::find($slCategoryId);
                                if(!empty($category)) {
                                    $categoryName = $category->name;
                                } else {
                                    $categoryName = null;
                                }

                                $discount_amount = 0;

                                if(!empty($sellLinesValue['line_discount_amount']) ){
                                    $discount_amount = $sellLinesValue['line_discount_amount'] / $sellLinesValue['quantity'];
                                }
                                $unit_price = !empty($sellLinesValue['unit_price']) ? $sellLinesValue['unit_price'] : "";
                                
                                $combo_products = [];

                                $variations = Product::where('business_id', $input['business_id'])
                                            ->with(['variations'])
                                            ->find($sellLinesValue['product_id']);
                                if( isset($variations['variations']) && $variations['variations'] && count($variations['variations']) ) {
                                    foreach ($variations['variations'] as $key => $each) {
                                        $variation = json_decode($each);
                                        if( $variation->combo_variations && count($variation->combo_variations) ) {
                                            foreach ($variation->combo_variations as $key => $combo_variation) {
                                                $combo_product = Variation::where('variations.id', $combo_variation->variation_id)
                                                        ->join('products AS p', 'variations.product_id', '=', 'p.id')
                                                        ->select(['p.*', 'variations.name as variation_name'])
                                                        ->first();
                                                $combo_products[] = $combo_product;
                                            }
                                        }
                                    }
                                }
                                
                                $food_items[] = [
                                    'sl_transaction_id' => $sellLinesValue['id'],
                                    'sl_name' => $sellLinesValue['variations']->product->name,
                                    'sl_product_id' => $sellLinesValue['product_id'],
                                    'sl_variation_id' => $sellLinesValue['variation_id'],
                                    'sl_quantity' => $sellLinesValue['quantity'],
                                    'sl_quantity_returned' => $sellLinesValue["quantity_returned"],
                                    'sl_quantity_returned_note' => $sellLinesValue["quantity_returned_note"],
                                    'sl_serve_later_quantity' => $sellLinesValue["serve_later_quantity"],
                                    'moditiers' => $moditiers,
                                    'sl_category_id' => $slCategoryId,
                                    'sl_category' => $categoryName,
                                    'sl_combo_products' => $combo_products,
                                    'sl_sell_line_note' => $sellLinesValue['sell_line_note'],
                                    'sl_discount_amount' => $discount_amount,
                                    'sl_unit_price' => $unit_price,
                                    'sl_tag' => !empty($sellLinesValue["tag"]) ? $sellLinesValue["tag"] : "",
                                    'sl_parent_product_group_id' => !empty($sellLinesValue['parent_product_group_id']) ? $sellLinesValue['parent_product_group_id'] : "",
                                    'sl_kitchen_shorthand' => !empty($sellLinesValue['variations']->product->kitchen_shorthand) ? $sellLinesValue['variations']->product->kitchen_shorthand : "",
                                    'sl_name_in_second_language' => !empty($sellLinesValue['variations']->product->name_in_second_language) ? $sellLinesValue['variations']->product->name_in_second_language : ""
                                ];
                            }
                        }
                        }

                        // Extract the 'sl_quantity_returned' column to a separate array for sorting
                        $sl_quantity_returned = array_column($food_items, 'sl_quantity_returned');

                        // Sort $food_items based on the 'sl_quantity_returned' key (ascending order)
                        array_multisort($sl_quantity_returned, SORT_ASC, $food_items);

                        $food_items = array_merge($food_items, $voidSellLines);

                        $table_id = [];
                        $table_name = [];
                        $table_pax = [];

                        $table_query = Transaction::leftjoin('pos_res_tables as prt', 'prt.transaction_id', '=', 'transactions.id')
                        ->leftjoin('res_tables as rt', 'rt.id', '=', 'prt.res_table_id')
                        ->where('transactions.id', $value['id'])
                        ->select('prt.res_table_id', 'rt.name','prt.pax')
                        ->get();

                        if (!empty($table_query))
                        {
                            foreach ($table_query as $key => $tableValue) 
                            {
                                if($tableValue['res_table_id'] != null)
                                {
                                    array_push($table_id, $tableValue['res_table_id']);
                                    array_push($table_name, $tableValue['name']);
                                    array_push($table_pax, $tableValue['pax']);
                                }
                            }
                        }

                        $today_history_list[] = [
                            'trans_id' => $value['id'],
                            'business_id' => $value['business_id'],
                            'location_id' => $value['location_id'],  
                            'transaction_date' => $value['transaction_date'],
                            'table_id' => $table_id,
                            'table_name' => $table_name,
                            'pax' => $table_pax,
                            'invoice_no' => $value['invoice_no'],
                            'order_check_no' => $value['order_check_no'],                
                            'type_for_api' => $value['type_for_api'],        
                            'status' => $value['status'],                 
                            'food_items' => $food_items
                        ];
                    }

                    if (count($today_history_list) <= 0) {
                        return ["errorMessage" => 'No orders available', "today_history_list" => []];
                    }
                } catch (\Exception $e) {
                    dd($e);
                    return ["errorMessage" => 'Table not found.', "today_history_list" => []];
                }

                return ["today_history_list" => $today_history_list];
            }
            else
            {
                return ["errorMessage" => 'Invalid token.', "today_history_list" => []];
            }
        }
        else
        {
            return ["errorMessage" => 'Invalid token.'];
        }
    }
}
