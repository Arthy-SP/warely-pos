<?php

namespace App\Http\Controllers\KDS;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\Http\Controllers\Controller;

use App\User;
use App\BusinessLocation;

class AccessController extends Controller
{

    function kdsLogin(Request $request)
    {
        $credentials = $request->only('username', 'password');

        if (Auth::attempt($credentials)) 
        {
            $user = auth()->user();
            $user_role = $user->roles->first();

            if($user_role->name == 'Admin#' . $user->business_id)
            {
                $user = Auth::user();
                
                if(!$user->api_token) {
                    User::generateToken();
                }

                return $this->respond([
                    'data' => $user->toArray(),
                ]);
            }

            return ["status"=>'The system can only be accessed by administrators.'];
        }
        else
        {
            return ["status"=>'The username or password is incorrect.'];
        }
    }

    function kdsLogout(Request $request)
    {
        $user = $request->user();

        if(isset($user))
        {
            Auth::logout();
            $request->session()->invalidate();
            $request->session()->flush();

            return response()->json([
                'message' => 'Successfully logged out'
            ]);
        }
        else 
        {
            return response()->json([
                'message' => 'No User Login'
            ]);
        }
        
        /*
        $request->user()->token()->revoke();
        return response()->json([
            'message' => 'Successfully logged out'
        ]);
        */
    }

    function getKdsBusinessLocationList(Request $request)
    {
        $user_data = $request->only('business_id', 'token', 'user_id');

        if(isset($user_data['token']))
        {    
            $result = User::checkUserToken($user_data['token'], $user_data['user_id']);

            if($result)
            {
                $get_business_loc = BusinessLocation::where('business_id', $user_data['business_id'])
                                                    ->where('is_active', 1)
                                                    ->get();
                $arr = array();
                for($i = 0; $i < count($get_business_loc); $i ++)
                {
                    $arr[] = [
                        'business_id'   => $get_business_loc[$i]->id,
                        'location_id'   => $get_business_loc[$i]->location_id,
                        'business_name' => $get_business_loc[$i]->name
                        ];
                }
                return $this->respond($get_business_loc);
            }
            else
            {
                return["errorMessage"=>'Invalid token.'];
            }
        }
        else{
            return["errorMessage"=>'Invalid token.'];
        }
    }

    function getKdsBusinessLocationDetails(Request $request)
    {
        $user_data = $request->only('business_location_id', 'token', 'user_id');

        if(isset($user_data['token']))
        {    
            $result = User::checkUserToken($user_data['token'], $user_data['user_id']);

            if($result)
            {
                $business_location_details = BusinessLocation::where('id',$user_data['business_location_id'])->get();

                if (!empty($business_location_details[0]['cds'])) {
                    // $business_location_details[0]['cds'] = asset('/uploads/cds/' . rawurlencode($business_location_details[0]['cds']));
                    $business_location_details[0]['cds'] = config('constants.awsS3BaseUrl') . "/" . config('constants.awsS3Env') . "/cds/" . rawurlencode($business_location_details[0]['cds']);
                }

                if (!empty($business_location_details[0]['cds_logo_image'])) {
                    // $business_location_details[0]['cds_logo_image'] = asset('/uploads/cds/' . rawurlencode($business_location_details[0]['cds_logo_image']));
                    $business_location_details[0]['cds_logo_image'] = config('constants.awsS3BaseUrl') . "/" . config('constants.awsS3Env') . "/cds/" . rawurlencode($business_location_details[0]['cds_logo_image']);
                }

                return $this->respond($business_location_details);
            }
            else
            {
                return["errorMessage"=>'Invalid token.'];
            }
        }
        else {
            return["errorMessage"=>'Invalid token.'];
        }
    }
}
