<?php

namespace App\Http\Controllers\KDS;

use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Illuminate\Routing\Controller;
use App\Http\Controllers\API\ApiPrinterController;

use App\User;
use App\Transaction;
use App\TransactionSellLine;
use App\TransactionVoidSellLine;
use App\Product;
use App\Variation;
use App\PosResTables;
use App\Utils\ProductUtil;
use App\Utils\TransactionUtil;
use App\Restaurant\ResTable;
use Illuminate\Support\Facades\DB;
use App\Category;

use Carbon\Carbon;

class onGoingController extends Controller
{
    /**
     * All Utils instance.
     *
     */
    protected $productUtil;
    protected $printerController;

    /**
     * Constructor
     *
     * @param ProductUtils $product
     * @return void
     */
    public function __construct(ProductUtil $productUtil, TransactionUtil $transactionUtil, ApiPrinterController $printerController)
    {
        $this->productUtil = $productUtil;
        $this->transactionUtil = $transactionUtil;
        $this->printerController = $printerController;
    }

    public function getOnGoingList(Request $request)
    {
        $input = $request;

        if(isset($input['token']))
        {
            $result = User::checkUserToken($input['token'], $input['user_id']);

            if($result)
            {
                try {
                    $kitchen_group = !empty($input['kitchen_group']) ? $input['kitchen_group'] : "";
                    $categories = !empty($input['categories']) ? $input['categories'] : "";

                    if(!empty($kitchen_group) && !empty($categories)) {
                        $category = $this->printerController->get_printer_category_by_id($input);
                        $category = json_decode(json_encode($category), true);
                        $category = $category['original'];

                        $filtered_categories = array_filter($category, function($item) use ($kitchen_group) {
                            return isset($item['id']) && in_array($item['id'], $kitchen_group);
                        });

                        $filtered_categories = array_values($filtered_categories);
                        
                        $categories_array = [];
                        foreach ($filtered_categories as $category) {
                            if (isset($category['categories']) && is_array($category['categories'])) {
                                $categories_array = array_merge($categories_array, $category['categories']);
                            }
                        }

                        $unique_categories = array_unique($categories_array);
                        $unique_categories = array_values($unique_categories);
                        // dd($unique_categories);
                        $filter_new_categories = array_merge($categories, $unique_categories);
                        $filterCategories = array_unique($filter_new_categories);

                    } elseif(!empty($kitchen_group) && empty($categories)) {
                        $category = $this->printerController->get_printer_category_by_id($input);
                        $category = json_decode(json_encode($category), true);
                        $category = $category['original'];

                        $filtered_categories = array_filter($category, function($item) use ($kitchen_group) {
                            return isset($item['id']) && in_array($item['id'], $kitchen_group);
                        });

                        $filtered_categories = array_values($filtered_categories);
                        
                        $categories_array = [];
                        foreach ($filtered_categories as $category) {
                            if (isset($category['categories']) && is_array($category['categories'])) {
                                $categories_array = array_merge($categories_array, $category['categories']);
                            }
                        }

                        $unique_categories = array_unique($categories_array);
                        $filterCategories = array_values($unique_categories);
                        //$categories = array_merge($categories, $unique_categories);
                        //$filterCategories = array_unique($categories);
                    } elseif(!empty($categories) && empty($kitchen_group)) {
                        $filterCategories = $categories;
                    } else {
                        $filterCategories = [];
                    }
                    
                    $orderTypes = (isset($input["orderTypes"]) && $input["orderTypes"]) ? $input["orderTypes"] : null;
                    
                    $transactions = Transaction::select('transactions.*')
                    ->with('sell_lines.variations.product')
                    ->where(function($query){
                        $query->where('transactions.kds_status' , '<>', 'close_ticket')
                        ->orWhereNull('transactions.kds_status');
                    })
                    ->where('transactions.business_id', '=', $input['business_id'])
                    ->where('transactions.location_id', '=', $input['location_id'])
                    ->whereDate('transactions.created_at', '>=', Carbon::today())
                    ->when($orderTypes, function ($query, $orderTypes) {
                        $query->whereIn('transactions.type_for_api', $orderTypes);
                    })
                    ->when(!empty($filterCategories), function($query) use ($filterCategories) {
                        $query->whereHas('sell_lines.variations.product', function ($query) use ($filterCategories) {
                            $query->whereIn('category_id', $filterCategories);
                        });
                    })
                    ->orderBy('transaction_order', 'ASC')
                    ->get();

                    $today_onGoing_list = [];
                    foreach ($transactions as $key => $value) 
                    {
                        $voidSellLines = [];
                        $transactionVoidSellLines = TransactionVoidSellLine::where('transaction_id', $value['id'])->get();

                        if( $transactionVoidSellLines && !empty($transactionVoidSellLines) && count($transactionVoidSellLines) ) {
                            foreach ($transactionVoidSellLines as $key => $transactionVoidSellLine) {
                                $voidSellLines[] = [
                                    'sl_transaction_id' => $transactionVoidSellLine['sell_line_id'],
                                    'sl_name' => $transactionVoidSellLine['name'],
                                    'sl_product_id' => 0,
                                    'sl_variation_id' => 0,
                                    'sl_quantity' => $transactionVoidSellLine['qty'],
                                    'sl_quantity_returned' => $transactionVoidSellLine["qty"],
                                    'sl_quantity_returned_note' => $transactionVoidSellLine["reason"],
                                    'sl_serve_later_quantity' => 0,
                                    'sl_kds_isCross' => 0,
                                    'moditiers' => [],
                                    'is_voided' => 1
                                ];
                            }
                        }

                        $food_items = [];
                        foreach ($value['sell_lines'] as $sellLinesKey => $sellLinesValue)
                        {
                            if (
                                $sellLinesValue["parent_sell_line_id"] == null &&
                                $sellLinesValue["transaction_id"] == $value['id'] &&
                                (empty($filterCategories) || in_array($sellLinesValue['variations']->product->category_id, $filterCategories))
                            ) {
                                $moditiers = [];
                                foreach ($value['sell_lines'] as $sellLinesKey1 => $sellLinesValue1)
                                {
                                    if($sellLinesValue1["parent_sell_line_id"] != null && $sellLinesValue1["parent_sell_line_id"] == $sellLinesValue['id'] && $sellLinesValue1["children_type"] == "modifier")
                                    {
                                        $moditiers[] = [
                                            'modifier_sell_line_id' => $sellLinesValue1['id'],
                                            'modifier_product_id' => (isset($sellLinesValue1['variations']) && !empty($sellLinesValue1['variations'])) ? $sellLinesValue1['variations']->product_id : 0,
                                            'variations_id' => (isset($sellLinesValue1['variations']) && !empty($sellLinesValue1['variations'])) ? $sellLinesValue1['variations']->id : 0,
                                            'variations_name' => (isset($sellLinesValue1['variations']) && !empty($sellLinesValue1['variations'])) ? $sellLinesValue1['variations']->name : null,
                                            'modifier_default_price' => $sellLinesValue1['variations']->default_sell_price,
                                            'variations_quantity' => $sellLinesValue1["quantity"]
                                        ];
                                    }
                                }

                                $slCategoryId = $sellLinesValue['variations']->product->category_id;

                                $category = Category::find($slCategoryId);
                                if(!empty($category)) {
                                    $categoryName = $category->name;
                                } else {
                                    $categoryName = null;
                                }

                                $discount_amount = 0;

                                if(!empty($sellLinesValue['line_discount_amount']) ){
                                    $discount_amount = $sellLinesValue['line_discount_amount'] / $sellLinesValue['quantity'];
                                }
                                $unit_price = !empty($sellLinesValue['unit_price']) ? $sellLinesValue['unit_price'] : "";

                                $combo_products = [];

                                $variations = Product::where('business_id', $input['business_id'])
                                            ->with(['variations'])
                                            ->find($sellLinesValue['product_id']);
                                if( isset($variations['variations']) && $variations['variations'] && count($variations['variations']) ) {
                                    foreach ($variations['variations'] as $key => $each) {
                                        $variation = json_decode($each);
                                        if( $variation->combo_variations && count($variation->combo_variations) ) {
                                            foreach ($variation->combo_variations as $key => $combo_variation) {
                                                $combo_product = Variation::where('variations.id', $combo_variation->variation_id)
                                                        ->join('products AS p', 'variations.product_id', '=', 'p.id')
                                                        ->select(['p.*', 'variations.name as variation_name'])
                                                        ->first();
                                                $combo_products[] = $combo_product;
                                            }
                                        }
                                    }
                                }
                                
                                $food_items[] = [
                                    'sl_transaction_id' => $sellLinesValue['id'],
                                    'sl_name' => $sellLinesValue['variations']->product->name,
                                    'sl_product_id' => $sellLinesValue['product_id'],
                                    'sl_variation_id' => $sellLinesValue['variation_id'],
                                    'sl_quantity' => $sellLinesValue['quantity'],
                                    'sl_quantity_returned' => $sellLinesValue["quantity_returned"],
                                    'sl_quantity_returned_note' => $sellLinesValue["quantity_returned_note"],
                                    'sl_serve_later_quantity' => $sellLinesValue["serve_later_quantity"],
                                    'sl_kds_isCross' => $sellLinesValue["kds_isCross"],
                                    'moditiers' => $moditiers,
                                    'is_voided' => 0,
                                    'sl_category_id' => $slCategoryId,
                                    'sl_combo_products' => $combo_products,
                                    'sl_category' => $categoryName,
                                    'sl_sell_line_note' => $sellLinesValue['sell_line_note'],
                                    'sl_discount_amount' => $discount_amount,
                                    'sl_unit_price' => $unit_price,
                                    'sl_tag' => !empty($sellLinesValue["tag"]) ? $sellLinesValue["tag"] : "",
                                    'sl_parent_product_group_id' => !empty($sellLinesValue['parent_product_group_id']) ? $sellLinesValue['parent_product_group_id'] : "",
                                    'sl_kitchen_shorthand' => !empty($sellLinesValue['variations']->product->kitchen_shorthand) ? $sellLinesValue['variations']->product->kitchen_shorthand : "",
                                    'sl_name_in_second_language' => !empty($sellLinesValue['variations']->product->name_in_second_language) ? $sellLinesValue['variations']->product->name_in_second_language : ""
                                ];
                            }
                        }

                        // Extract the 'sl_quantity_returned' column to a separate array for sorting
                        $sl_quantity_returned = array_column($food_items, 'sl_quantity_returned');

                        // Sort $food_items based on the 'sl_quantity_returned' key (ascending order)
                        array_multisort($sl_quantity_returned, SORT_ASC, $food_items);

                        $food_items = array_merge($food_items, $voidSellLines);

                        $table_id = [];
                        $table_name = [];
                        $table_pax = [];

                        $table_query = Transaction::leftjoin('pos_res_tables as prt', 'prt.transaction_id', '=', 'transactions.id')
                        ->leftjoin('res_tables as rt', 'rt.id', '=', 'prt.res_table_id')
                        ->where('transactions.id', $value['id'])
                        ->select('prt.res_table_id', 'rt.name','prt.pax')
                        ->get();

                        if (!empty($table_query))
                        {
                            foreach ($table_query as $key => $tableValue) 
                            {
                                if($tableValue['res_table_id'] != null)
                                {
                                    array_push($table_id, $tableValue['res_table_id']);
                                    array_push($table_name, $tableValue['name']);
                                    array_push($table_pax, $tableValue['pax']);
                                }
                            }
                        }

                        $today_onGoing_list[] = [
                            'trans_id' => $value['id'],
                            'business_id' => $value['business_id'],
                            'location_id' => $value['location_id'],  
                            'transaction_date' => $value['transaction_date'],
                            'table_id' => $table_id,
                            'table_name' => $table_name,
                            'pax' => $table_pax,
                            'invoice_no' => $value['invoice_no'],
                            'order_check_no' => $value['order_check_no'],          
                            'type_for_api' => $value['type_for_api'],        
                            'status' => $value['status'],                 
                            'food_items' => $food_items,
                            'transaction_order' => $value['transaction_order'],
                        ];
                    }

                    if (count($today_onGoing_list) <= 0) {
                        return ["errorMessage" => 'No orders available.', "on_going_list" => []];
                    }
                } 
                catch (\Exception $e) 
                {
                    \Log::emergency("File:" . $e->getFile() . "Line:" . $e->getLine() . "Message:" . $e->getMessage());
                    return ["errorMessage" => 'Tables not found', "on_going_list" => []];
                }

                return ["on_going_list" => $today_onGoing_list];
            }
            else
            {
                return ["errorMessage" => 'Invalid token.', "on_going_list" => []];
            }
        }
        else
        {
            return ["errorMessage" => 'Invalid token.'];
        }
    }


    public function getServeLaterList(Request $request)
    {
        $input = $request;

        if(isset($input['token']))
        {
            $result = User::checkUserToken($input['token'], $input['user_id']);

            if($result)
            {
                try {
                    $transactions = Transaction::select('transactions.*')
                    ->with('sell_lines.variations.product')
                    ->whereDate('transactions.created_at', '>=', Carbon::today())
                    ->get();

                    $today_serve_later_list = [];
                    foreach ($transactions as $key => $value) 
                    {
                        $food_items = [];
                        foreach ($value['sell_lines'] as $sellLinesKey => $sellLinesValue)
                        {
                            if($sellLinesValue["parent_sell_line_id"] == null && $sellLinesValue["transaction_id"] == $value['id'])
                            {
                                $moditiers = [];
                                foreach ($value['sell_lines'] as $sellLinesKey1 => $sellLinesValue1)
                                {
                                    if($sellLinesValue1["parent_sell_line_id"] != null && $sellLinesValue1["parent_sell_line_id"] == $sellLinesValue['id'] && $sellLinesValue1["children_type"] == "modifier")
                                    {
                                        $moditiers[] = [
                                            'modifier_sell_line_id' => $sellLinesValue1['id'],
                                            'modifier_product_id' => $sellLinesValue1['variations']->product_id,
                                            'variations_id' => $sellLinesValue1['variations']->id,
                                            'variations_name' => $sellLinesValue1['variations']->name,
                                            'variations_quantity' => $sellLinesValue1["quantity"]
                                        ];
                                    }
                                }

                                if($sellLinesValue['serve_later_quantity'] >= 1){
                                    $food_items[] = [
                                        'sl_transaction_id' => $sellLinesValue['id'],
                                        'sl_name' => $sellLinesValue['variations']->product->name,
                                        'sl_product_id' => $sellLinesValue['product_id'],
                                        'sl_variation_id' => $sellLinesValue['variation_id'],
                                        'sl_quantity' => $sellLinesValue['quantity'],
                                        'sl_quantity_returned' => $sellLinesValue["quantity_returned"],
                                        'sl_quantity_returned_note' => $sellLinesValue["quantity_returned_note"],
                                        'sl_serve_later_quantity' => $sellLinesValue["serve_later_quantity"],
                                        'moditiers' => $moditiers
                                    ];
                                }
                            }
                        }

                        $table_id = [];
                        $table_name = [];

                        $table_query = Transaction::leftjoin('pos_res_tables as prt', 'prt.transaction_id', '=', 'transactions.id')
                        ->leftjoin('res_tables as rt', 'rt.id', '=', 'prt.res_table_id')
                        ->where('transactions.id', $value['id'])
                        ->select('prt.res_table_id', 'rt.name')
                        ->get();

                        if(!empty($table_query))
                        {
                            foreach ($table_query as $key => $tableValue) 
                            {
                                if($tableValue['res_table_id'] != null)
                                {
                                    array_push($table_id, $tableValue['res_table_id']);
                                    array_push($table_name, $tableValue['name']);
                                }
                            }
                        }

                        if(!empty($food_items))
                        {
                            $today_serve_later_list[] = [
                                'trans_id' => $value['id'],
                                'business_id' => $value['business_id'],
                                'location_id' => $value['location_id'],  
                                'transaction_date' => $value['transaction_date'],
                                'table_id' => $table_id,
                                'table_name' => $table_name,
                                'invoice_no' => $value['invoice_no'],                
                                'type_for_api' => $value['type_for_api'],        
                                'status' => $value['status'],                 
                                'food_items' => $food_items
                            ];
                        } 
                    }

                    if (count($today_serve_later_list) <= 0) {
                        $today_serve_later_list = ["errorMessage" => 'Serve Later List not found.'];
                    }
                } 
                catch (\Exception $e) 
                {
                    $today_serve_later_list = ["errorMessage" => 'Table not found.'];
                }

                return ["Today Serve Later List" => $today_serve_later_list];
            }
            else
            {
                return ["errorMessage" => 'Invalid token.'];
            }
        }
        else
        {
            return ["errorMessage" => 'Invalid token.'];
        }
    }

    public function updateServeLaterQty(Request $request)
    {
        $input = $request;

        if(isset($input['token']))
        {
            $result = User::checkUserToken($input['token'], $input['user_id']);

            if($result)
            {
                $transaction_sell_line_id = $input['transaction_sell_line_id'];
                $serve_all = $input['serve_all'];

                try {
                    if ($serve_all) {
                        if (!empty($transaction_sell_line_id)) {
                            for ($i = 0; $i < count($transaction_sell_line_id); $i++) {
                                TransactionSellLine::where('id', $transaction_sell_line_id[$i])
                                    ->update(['serve_later_quantity' => 0]);
                            }
                        }
                    } 
                    else 
                    {
                        if (!empty($transaction_sell_line_id)) {
                            $transaction = TransactionSellLine::where('id', $transaction_sell_line_id[0])->firstOrFail();
                            $serve_later_quantity = $transaction->serve_later_quantity - 1;
    
                            TransactionSellLine::where('id', $transaction_sell_line_id[0])
                                ->update(['serve_later_quantity' => $serve_later_quantity]);
                        }
                    }
    
                    return ["msg" => 'Order updated'];
                } 
                catch (\Exception $e) 
                {
                    DB::rollBack();
                    \Log::emergency("File:" . $e->getFile() . "Line:" . $e->getLine() . "Message:" . $e->getMessage());
                    $msg = trans("messages.something_went_wrong");
    
                    $output = [
                        'errorMessage' => $msg
                    ];
                }
            }
            else
            {
                return ["errorMessage" => 'Invalid token.'];
            }
        }
        else
        {
            return ["errorMessage" => 'Invalid token.'];
        }
    }

    public function closeTicket(Request $request)
    {
        $input = $request;

        if(isset($input['token']))
        {
            $result = User::checkUserToken($input['token'], $input['user_id']);

            if($result)
            {
                $transaction_id = $input['transaction_id'];
                $close_ticket = $input['close_ticket'];
                //$serve_later_quantity = $input['serve_later_quantity'];
                $updated_date = Carbon::now();
                $force_close = $input['force_close'];

                try 
                {
                    //check having serve later
                    /*if ($serve_later_quantity >= 1) 
                    {
                        //add serve later into serve later tab
                        $transaction = Transaction::where('id', $transaction_id)->firstOrFail();
                        $update_ticket_to_close = [
                            //any status using in db to cater dine in order complete
                            'kds_status' => $close_ticket,
                            'updated_at' => $updated_date
                        ];

                        $transaction->fill($update_ticket_to_close);
                        $transaction->update();

                        $output = ['msg' => "This order is completed and have serve later item."];
                    } 
                    else 
                    {

                        $transaction = Transaction::where('id', $transaction_id)->firstOrFail();
                        $update_ticket_to_close = [
                            //any status using in db to cater dine in order complete
                            'kds_status' => $close_ticket,
                            'updated_at' => $updated_date
                        ];

                        $transaction->fill($update_ticket_to_close);
                        $transaction->update();
                        $output = ['msg' => "This order is completed."];
                    }*/

                    if($force_close === true) {

                        $pendingServeLater = TransactionSellLine::where("transaction_id", "=", $transaction_id)
                                                                        ->where("serve_later_quantity", "=", 1)
                                                                        ->where("kds_isCross", "=", 0)
                                                                        ->where("children_type", "=", "")
                                                                        ->get();

                        if( count($pendingServeLater) > 0 ) {
                            return $output = ['errorMessage' => "Unable to close ticket, some serve later items are pending."];
                        }

                        $transaction = Transaction::where('id', $transaction_id)->firstOrFail();
                        $update_ticket_to_close = [
                            //any status using in db to cater dine in order complete
                            'kds_status' => $close_ticket,
                            'updated_at' => $updated_date
                        ];
                        $transaction->fill($update_ticket_to_close);
                        $transaction->update();
                        $output = ['msg' => "Ticket closed"];

                    } else {
                        $pendngServeNow = TransactionSellLine::where("transaction_id", "=", $transaction_id)
                                                                    ->where("kds_isCross", "=", 0)
                                                                    ->where("serve_later_quantity", "=", 0)
                                                                    ->where("children_type", "=", "")
                                                                    ->get();

                        $pendingServeLater = TransactionSellLine::where("transaction_id", "=", $transaction_id)
                                                                        ->where("serve_later_quantity", "=", 1)
                                                                        ->where("kds_isCross", "=", 0)
                                                                        ->where("children_type", "=", "")
                                                                        ->get();

                        if( count($pendngServeNow) > 0 ) {
                            return $output = ['errorMessage' => "Unable to close ticket, some items are pending."];
                        }

                        if( count($pendingServeLater) > 0 ) {
                            return $output = ['errorMessage' => "Unable to close ticket, some serve later items are pending."];
                        }

                        $transaction = Transaction::where('id', $transaction_id)->firstOrFail();
                        $update_ticket_to_close = [
                            //any status using in db to cater dine in order complete
                            'kds_status' => $close_ticket,
                            'updated_at' => $updated_date
                        ];
                        $transaction->fill($update_ticket_to_close);
                        $transaction->update();
                        $output = ['msg' => "Ticket closed"];
                    }
                } 
                catch (\Exception $e) 
                {
                    DB::rollBack();
                    \Log::emergency("File:" . $e->getFile() . "Line:" . $e->getLine() . "Message:" . $e->getMessage());
                    $msg = trans("messages.something_went_wrong");

                    $output = [
                        'errorMessage' => $msg
                    ];
                }
                return $output;
            } 
            else 
            {
                return ["errorMessage" => 'Invalid token.'];
            }
        }
        else
        {
            return ["errorMessage" => 'Invalid token.'];
        }     
    }

    public function voidItem(Request $request)
    {
        $input = $request;

        if(isset($input['token']))
        {
            $result = User::checkUserToken($input['token'], $input['user_id']);

            if($result)
            {
                //$item_ID = $input['product_id'];
                //$invoice_no = $input['invoice_no'];
                $sellLinesID = $input['sellLinesID'];
                $qty = $input['qty'];
                $totalQty = $input['totalQty'];
                $reason = $input['reason'];
                $name = $input['name'];
                $user_id = $input['user_id'];
                $transaction_id = $input['transactionId'];

                //get item id, qty, invoice no
                if (!empty($qty) && !empty($sellLinesID)) 
                {
                    try{
                        if( $totalQty && $totalQty > $qty) {
                            // 'quantity_returned' => $qty, 
                            TransactionSellLine::where('id', $sellLinesID)->update(['quantity' => ($totalQty - $qty)]);
                        } else {
                            TransactionSellLine::where('id', $sellLinesID)->delete();
                            //->where('qty', $qty)
                            //->update(['quantity_returned' => DB::raw('quantity')]);
                        }

                        if( $reason ) {
                            $voidSellLines = TransactionVoidSellLine::where('transaction_id', $transaction_id)
                                                    ->where('sell_line_id', $sellLinesID)
                                                    ->where('reason', $reason)
                                                    ->get();
                            if( !empty($voidSellLines) && count($voidSellLines) ) {
                                $req_data = [
                                    'reason' => $reason,
                                    'qty' => $qty + $voidSellLines[0]->qty,
                                    'created_by' => $user_id
                                ];
                                TransactionVoidSellLine::where('transaction_id', $transaction_id)
                                                    ->where('sell_line_id', $sellLinesID)
                                                    ->where('reason', $reason)
                                                    ->update($req_data);
                            } else {
                                $req_data = [
                                    'transaction_id' => $transaction_id,
                                    'reason' => $reason,
                                    'name' => $name,
                                    'qty' => $qty,
                                    'created_by' => $user_id,
                                    'sell_line_id' => $sellLinesID
                                ];
                                TransactionVoidSellLine::create($req_data);
                            }
                        }

                        $output = ['msg' => "Item is voided."];
                    } 
                    catch(\Exception $e) 
                    {
                        DB::rollBack();
                        \Log::emergency("File:" . $e->getFile() . "Line:" . $e->getLine() . "Message:" . $e->getMessage());
                        $msg = trans("messages.something_went_wrong");

                        $output = [
                            'errorMessage' => $msg
                        ];
                    }
                    return $output;
                } 
                else 
                {
                    return ["errorMessage" => 'No Item found.'];
                }
            }
            else 
            {
                return ["errorMessage" => 'Invalid token.'];
            }
        }
        else
        {
            return ["errorMessage" => 'Invalid token.'];
        }     
    }

    public function kdsIsCross(Request $request){
        $input = $request;

        if(isset($input['token']))
        {
            $result = User::checkUserToken($input['token'], $input['user_id']);

            if($result)
            {
                //function cross the sellLines item
                $sellLinesID = $input['sellLinesID'];
                $isCross = $input['isCross'];
                $updated_date = Carbon::now();

                if (!empty($sellLinesID)) 
                {
                    try{
                        if ($isCross == 1)
                        {
                            $transactionSellLine = TransactionSellLine::where('id', $sellLinesID)
                                ->update(['kds_isCross' => 1,
                                          'updated_at' => $updated_date]);
                        } elseif ($isCross == 0)
                        {
                            $transactionSellLine = TransactionSellLine::where('id', $sellLinesID)
                                ->update(['kds_isCross' => 0,
                                          'updated_at' => $updated_date]);
                        }

                        $output = ['msg' => "Item is updated."];
                    } 
                    catch(\Exception $e) 
                    {
                        DB::rollBack();
                        \Log::emergency("File:" . $e->getFile() . "Line:" . $e->getLine() . "Message:" . $e->getMessage());
                        $msg = trans("messages.something_went_wrong");

                        $output = [
                            'errorMessage' => $msg
                        ];
                    }
                    return $output;
                } 
                else 
                {
                    return ["errorMessage" => 'No Sell Line Item found.'];
                }
            }
            else 
            {
                return ["errorMessage" => 'Invalid token.'];
            }
        }
        else
        {
            return ["errorMessage" => 'Invalid token.'];
        }   
    }

    public function reorderTicket(Request $request) {
        $input = $request;
        if(isset($input['token'])) {
            $result = User::checkUserToken($input['token'], $input['user_id']);
            if($result) {
                try {
                    if( isset($input['business_id']) && $input['business_id'] 
                    && isset($input['location_id']) && $input['location_id'] 
                    && isset($input['current_transaction_order']) && $input['current_transaction_order'] 
                    && isset($input['new_transaction_order']) && $input['new_transaction_order']
                    && isset($input['transaction_id']) && $input['transaction_id'] ) {
                        DB::beginTransaction();

                        DB::select("CALL reorderTransactions(" . $input['business_id'] . ", " . $input['location_id'] . ", " . $input['current_transaction_order'] . ", " . $input['new_transaction_order'] . ", " . $input['transaction_id'] . ", '" . Carbon::today() . "')");

                        DB::commit();

                        $output = ['msg' => "Re-order is completed."];
                    } else {
                        return ["errorMessage" => 'Invalid parameters.'];
                    }
                } catch (\Exception $e) {
                    DB::rollBack();
                    \Log::emergency("File:" . $e->getFile() . "Line:" . $e->getLine() . "Message:" . $e->getMessage());
                    $msg = trans("messages.something_went_wrong");

                    $output = [
                        'errorMessage' => $msg
                    ];
                }
                return $output;
            } else {
                return ["errorMessage" => 'Invalid token.'];
            }
        } else {
            return ["errorMessage" => 'Invalid token.'];
        }
    }
}
