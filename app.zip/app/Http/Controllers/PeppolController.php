<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Datatables;
use DB;
use App\Business;
use App\PeppolWebhookEvent;
use App\PeppolDocument;
use GuzzleHttp\Client;
use Carbon\Carbon;
use App\Transaction;
use App\Contact;
use App\TaxRate;
use Exception;
use App\PeppolLegalEntity;

class PeppolController extends Controller
{
    public function register()
    {
        return view('peppol.register');
    }

    public function index(Request $request)
    {
        if ($request->ajax()) {
            $peppolRegistrations = PeppolRegistration::select(['legal_entity_id', 'identifier', 'created_at', 'status']);
            
            return Datatables::of($peppolRegistrations)
                ->make(true);
        }

        $peppolRegistrations = PeppolRegistration::all(); // If you want to load data without AJAX

        return view('peppol.index', compact('peppolRegistrations'));
    }

    public function store(Request $request)
    {
        $legalEntityId = $request->legal_entity_id;
        PeppolRegistration::create([
            'legal_entity_id' => $request->legal_entity_id,
            'identifier' => $request->identifier
        ]);
        $apiUrl = "https://api.storecove.com/api/v2/legal_entities/{$legalEntityId}/peppol_identifiers";
        $params = [
            'legal_entity_id' => $request->legal_entity_id,
            'peppol_identifier' => $request->identifier
        ];

        try {
            $client = new \GuzzleHttp\Client();
            $response = $client->post($apiUrl, [
                'json' => $params,  
                'headers' => [
                    'Authorization' => 'Bearer ' . '8EzJrFUTh3gKxm1FkBmq9qQ0wXpkcE-2yA_BGFA6_ag',  
                    'Accept' => 'application/json'
                ]
            ]);
    
            $responseBody = json_decode($response->getBody(), true);
            
            // Check if API call is successful
            if ($response->getStatusCode() == 200) {
                $output = [
                    'success' => 1,
                    'msg' => __('Peppol registration added successfully, and identifier created.')
                ];
            } else {
                // Handle error if status code is not 200
                $output = [
                    'success' => 0,
                    'msg' => __('There was an issue with the Peppol identifier creation. Please try again.')
                ];
            }
    
        } catch (\Exception $e) {
            // Handle exception
            $output = [
                'success' => 0,
                'msg' => __('Error: ') . $e->getMessage()
            ];
        }

        return redirect('peppol')->with('status', $output);
    }

    public function invoiceAcknowledgement(Request $request){
        dd($request->all());
        \Log::info("tst>>>>>>>>>>>>>>>>>>>>>>>>>.");
        return;
    }

    public function documentReceived(Request $request){

        
        try { 
            $data = $request->all();
            //\Log::info("function is running", [$data['document_guid']]);
            $client = new Client();
            
            $webhookEvent = PeppolWebhookEvent::create([
                'event_type' => $data['event_type'],
                'event_group' => $data['event_group'],
                'event' => $data['event'],
                'document_guid' => $data['document_guid'],
                'guid' => $data['guid'],
                'raw_response' => json_encode($data),
            ]);

            $documentResponse = $client->get("https://api.storecove.com/api/v2/received_documents/{$data['document_guid']}/json", [
                'headers' => [
                    'Authorization' => 'Bearer ' . '8EzJrFUTh3gKxm1FkBmq9qQ0wXpkcE-2yA_BGFA6_ag',
                    'Content-Type' => 'application/json',
                ],
            ]);
            
            if ($documentResponse->getStatusCode() !== 200) {
                throw new Exception('Failed to retrieve document. Status code: ' . $documentResponse->getStatusCode());
            }
            
            $documentData = json_decode($documentResponse->getBody(), true);

            \Log::info("documentResponse ========", [$documentData]);
            
            if (empty($documentData)) {
                throw new Exception('Invalid document response structure or empty response.');
            }

            if($documentData['document']['document_type'] === 'invoice') {
                $document_id = $documentData['document']['invoice']['invoice_number'];    
            } else {
                $document_id = $documentData['document']['order']['document_number'];
            }
            
            //\Log::info("document id", [$document_id]);
            // Save document
            PeppolDocument::create([
                'guid' => $documentData['guid'],
                'webhook_event_id' => $webhookEvent->id,
                'document_data' => json_encode($documentData),
                'document_id' => $document_id
            ]);
            
            return response()->json(['success' => true, 'message' => 'Success.'], 200);
        } catch (Exception $e) {
            \Log::error('An error occurred while processing the webhook:', ['error' => $e->getMessage()]);
            return response()->json(['error' => 'An error occurred while processing the webhook.'], 500);
        }
    }

    public function receivedInvoices(Request $request)
    {
        $business_id = request()->session()->get('user.business_id');
        if ($request->ajax()) {
            $documents = PeppolDocument::all()->filter(function ($document) {
                $data = json_decode($document->document_data, true);
                return isset($data['document']['document_type']) && $data['document']['document_type'] === 'invoice';
            });

            $invoiceNumber = $data['document']['invoice']['invoice_number'] ?? null;
            $transaction = Transaction::where('invoice_no', $invoiceNumber)
                                        ->orWhere('ref_no', $invoiceNumber)
                                        ->where('business_id', $business_id)
                                        ->whereIn('type', ['sell', 'purchase', 'expense'])
                                        ->orderBy('created_at', 'desc')
                                        ->first();
            
            $transactionId = $transaction ? $transaction->id : null;

            $query = $documents->map(function ($document) {
                    $data = json_decode($document->document_data, true);

                    return (object) [
                        'buyer_reference' => $data['document']['invoice']['accounting_supplier_party']['public_identifiers'][0]['id'],
                        'customer_contact_person' => $data['document']['invoice']['accounting_supplier_party']['party']['contact']['email'],
                        'vendor_id' => '',
                        'supplier_email_address' => $data['document']['invoice']['accounting_supplier_party']['party']['contact']['email'],
                        'payment_terms_notes' => $data['document']['invoice']['payment_terms']['note'],
                        'order_id' => $data['document']['invoice']['invoice_number'],
                        'invoice_description' => $data['document']['invoice']['invoice_lines']['description'],
                        'purchase_order_line_reference' => '',
                        'suppliers_legal_company_name' => $data['document']['invoice']['accounting_supplier_party']['party']['company_name'],
                        'transaction_id' => $transactionId
                    ];
            });
        
        return Datatables::of($query)  
                    ->editColumn('order_id', function ($row) {
                        $invoice_no =  '<a data-href="' . action('SellController@show', [$row->transaction_id]) . '" href="#" data-container=".view_modal" class="btn-modal">' . $row->order_id . '</a>';
                        return $invoice_no;
                    })
                    ->rawColumns(['order_id'])
        ->make(true);
        }
        return view('peppol.received_invoices')->with('invoiceDetails');
    }

    public function receivedOrders(Request $request)
    {
        if ($request->ajax()) {
            $documents = PeppolDocument::all()->filter(function ($document) {
                $data = json_decode($document->document_data, true);
                return isset($data['document']['document_type']) && $data['document']['document_type'] === 'order';
            });

            $query = $documents->map(function ($document) {
                    $data = json_decode($document->document_data, true);
                    
                    return [
                        'buyer_reference' => $data['document']['order']['document_number'] ?? '',
                        'customer_contact_person' => $data['document']['order']['buyer_customer_party']['contact']['email'] ?? '',
                        'vendor_id' => $data['document']['order']['seller_supplier_party']['contact']['email'] ?? '',
                        'supplier_email_address' => $data['document']['order']['seller_supplier_party']['contact']['email'] ?? '',
                        'payment_terms_notes' => $data['document']['order']['payment_terms']['note'] ?? '',
                        'order_id' => $data['document']['order']['document_number'] ?? '',
                        'invoice_description' => $data['document']['order']['invoice_lines'][0]['name'] ?? '',
                        'purchase_order_line_reference' => $data['document']['order']['order_lines'][0]['references'][0]['document_id'],
                        'suppliers_legal_company_name' => $data['document']['order']['seller_supplier_party']['company_name'] ?? '',
                    ];
            });

            return Datatables::of($query)
                ->editColumn('order_id', function ($row) {
                            $invoice_no =  '<a data-href="' . action('PurchaseController@show', [$row->order_id]) . '" href="#" data-container=".view_modal" class="btn-modal">' . $row->order_id . '</a>';
                            return $invoice_no;
                        })
                ->rawColumns(['order_id'])
                ->make(true);
        }

        return view('peppol.received_orders', compact('invoiceDetails'));
    }

    public function convertOrderToInvoice(Request $request)
    {
        $invoice_number = $request->input('invoice_number');

        $transaction = Transaction::where('ref_no', $invoice_number)->first();
        if ($transaction) {
            
            $this->peppolDoc($transaction);

            return response()->json(['success' => true, 'message' => 'Order converted to invoice successfully.']);
        }

        return response()->json(['success' => false, 'message' => 'Transaction not found.'], 404);
    }
    public function generateGuid()
    {
        $data = random_bytes(16);

        $data[6] = chr(ord($data[6]) & 0x0f | 0x40);
        
        $data[8] = chr(ord($data[8]) & 0x3f | 0x80);
    
        return vsprintf('%s%s-%s-%s-%s-%s%s%s', str_split(bin2hex($data), 4));
    }

    // public function peppolDoc($transaction)
    // {
    //      $guid = $this->generateGuid();
    //     $contact_details = Contact::where('id', $transaction->contact_id)->first();
    //     //if($contact_details && $contact_details->peppole_identifier_id){
    //         $gst = TaxRate::where("business_id", $transaction->business_id)
    //         ->where("name", "GST")->select("amount")->first();
    //         $taxAmount = round(($transaction->total_before_tax * $gst->amount) / 100, 2);
    //         $amountIncludingVat = round($transaction->total_before_tax + $taxAmount, 2);
    //         $peppoleIdentifierDetails = $this->getPeppolIdentifier($contact_details->peppole_identifier_id);

          
    //         // $invoicePayload = [
    //         //     "legalEntityId" => 301805,
    //         //     "routing" => [
    //         //         "emails" => [
    //         //             $peppoleIdentifierDetails && $peppoleIdentifierDetails['email'] ? $peppoleIdentifierDetails['email'] : "mayankdubey@warelycorp.com"
    //         //         ],
    //         //         "eIdentifiers" => [
    //         //             [
    //         //                 "scheme" => "SG:UEN",//$peppoleIdentifierDetails && $peppoleIdentifierDetails['participantIdentifierSchema'] ? $peppoleIdentifierDetails['participantIdentifierSchema'] :"SG:UEN",
    //         //                 "id" => $peppoleIdentifierDetails && $peppoleIdentifierDetails['participantIdentifierValue'] ? $peppoleIdentifierDetails['participantIdentifierValue'] : "SGUEN201729553C" //participantIdentifierValue
    //         //             ]
    //         //         ]
    //         //     ],
    //         //     "document" => [
    //         //         "documentType" => "invoice",
    //         //         "invoice" => [
    //         //             "invoiceNumber" => $transaction->ref_no,
    //         //             "issueDate" =>  date('Y-m-d'),//"2024-10-16",  
    //         //             "documentCurrencyCode" => "SGD",
    //         //             "taxSystem" => "tax_line_percentages",
    //         //             "accountingCustomerParty" => [
    //         //                 "party" => [
    //         //                     "companyName" => $peppoleIdentifierDetails && $peppoleIdentifierDetails['multilingualNameDtos'] ? $peppoleIdentifierDetails['multilingualNameDtos'] :"Peppol user", //multilingualNameDtos
    //         //                     "address" => [
    //         //                         "street1" => "Street 123",
    //         //                         "zip" => "1111AA",
    //         //                         "city" => "Here",
    //         //                         "country" => "SG"
    //         //                     ]
    //         //                 ],
    //         //                 "publicIdentifiers" => [
    //         //                     [
    //         //                         "scheme" => "SG:UEN",//$peppoleIdentifierDetails && $peppoleIdentifierDetails['participantIdentifierSchema'] ? $peppoleIdentifierDetails['participantIdentifierSchema'] :"SG:UEN",
    //         //                 "id" => $peppoleIdentifierDetails && $peppoleIdentifierDetails['participantIdentifierValue'] ? $peppoleIdentifierDetails['participantIdentifierValue'] : "SGUEN201729553C" //participantIdentifierValue 
    //         //                     ]
    //         //                 ]
    //         //             ],
    //         //             "invoiceLines" => [
    //         //                 [
    //         //                     "description" => "The things you purchased",
    //         //                     "amountExcludingVat" => $transaction->final_total,
    //         //                     "tax" => [
    //         //                         "percentage" => $gst->amount,
    //         //                         "category" => "standard",
    //         //                         "country" => "SG"
    //         //                     ]
    //         //                 ]
    //         //             ],
    //         //             "taxSubtotals" => [
    //         //                 [
    //         //                     "percentage" => $gst->amount,
    //         //                     "category" => "standard",
    //         //                     "country" => "SG",
    //         //                     "taxableAmount" => $transaction->final_total,
    //         //                     "taxAmount" => $taxAmount
    //         //                 ]
    //         //             ],
    //         //             "paymentMeansArray" => [
    //         //                 [
    //         //                     "account" => "NL50ABNA0552321249",
    //         //                     "holder" => "Storecove",
    //         //                     "code" => "credit_transfer"
    //         //                 ]
    //         //             ],
    //         //             "amountIncludingVat" => $amountIncludingVat
    //         //         ]
    //         //     ]
    //         // ];
    //         $invoicePayload = [
    //             "legalEntityId" => 301805,
    //             "idempotencyGuid" => $guid,
    //             "routing" => [
    //                 "eIdentifiers" => [
    //                     [
    //                         "scheme" => "NL:KVK",
    //                         "id" => "27375186"
    //                     ]
    //                 ],
    //                 "emails" => [
    //                     "receiver@example.com"
    //                 ]
    //             ],
    //             "attachments" => [
    //                 [
    //                     "filename" => "myname.pdf",
    //                     "document" => "JVBERi0xLjIgCjkgMCBvYmoKPDwKPj4Kc3RyZWFtCkJULyAzMiBUZiggIFlPVVIgVEVYVCBIRVJFICAgKScgRVQKZW5kc3RyZWFtCmVuZG9iago0IDAgb2JqCjw8Ci9UeXBlIC9QYWdlCi9QYXJlbnQgNSAwIFIKL0NvbnRlbnRzIDkgMCBSCj4+CmVuZG9iago1IDAgb2JqCjw8Ci9LaWRzIFs0IDAgUiBdCi9Db3VudCAxCi9UeXBlIC9QYWdlcwovTWVkaWFCb3ggWyAwIDAgMjUwIDUwIF0KPj4KZW5kb2JqCjMgMCBvYmoKPDwKL1BhZ2VzIDUgMCBSCi9UeXBlIC9DYXRhbG9nCj4+CmVuZG9iagp0cmFpbGVyCjw8Ci9Sb290IDMgMCBSCj4+CiUlRU9G",
    //                     "mimeType" => "application/pdf",
    //                     "primaryImage" => false,
    //                     "documentId" => "myId",
    //                     "description" => "A Description"
    //                 ]
    //             ],
    //             "document" => [
    //                 "documentType" => "invoice",
    //                 "invoice" => [
    //                     "taxSystem" => "tax_line_percentages",
    //                     "documentCurrency" => "EUR",
    //                     "invoiceNumber" => "F463333333336",
    //                     "issueDate" => "2020-11-26",
    //                     "taxPointDate" => "2020-11-26",
    //                     "dueDate" => "2020-12-26",
    //                     "invoicePeriod" => "2020-11-12 - 2020-11-17",
    //                     "accountingCost" => "23089",
    //                     "note" => "This is the invoice note. Senders can enter free text. This may not be read by the receiver, so it is not encouraged to use this.",
    //                     "accountingSupplierParty" => [
    //                         "party" => [
    //                             "contact" => [
    //                                 "email" => "sender@company.com",
    //                                 "firstName" => "Jony",
    //                                 "lastName" => "Ponski",
    //                                 "phone" => "088-333333333"
    //                             ]
    //                         ]
    //                     ],
    //                     "accountingCustomerParty" => [
    //                         "publicIdentifiers" => [
    //                             [
    //                                 "scheme" => "NL:KVK",
    //                                 "id" => "27375186"
    //                             ],
    //                             [
    //                                 "scheme" => "NL:VAT",
    //                                 "id" => "NL999999999B01"
    //                             ]
    //                         ],
    //                         "party" => [
    //                             "companyName" => "Receiver Company",
    //                             "address" => [
    //                                 "street1" => "Streety 123",
    //                                 "street2" => null,
    //                                 "city" => "Alphen aan den Rijn",
    //                                 "zip" => "2400 AA",
    //                                 "county" => null,
    //                                 "country" => "NL"
    //                             ],
    //                             "contact" => [
    //                                 "email" => "receiver@company.com",
    //                                 "firstName" => "Pon",
    //                                 "lastName" => "Johnson",
    //                                 "phone" => "088-444444444"
    //                             ]
    //                         ]
    //                     ],
    //                     "delivery" => [
    //                         "deliveryPartyName" => "Delivered To Name",
    //                         "actualDeliveryDate" => "2020-11-01",
    //                         "deliveryLocation" => [
    //                             "id" => "871690930000478611",
    //                             "schemeId" => "EAN",
    //                             "address" => [
    //                                 "street1" => "line1",
    //                                 "street2" => "line2",
    //                                 "city" => "CITY",
    //                                 "zip" => "3423423",
    //                                 "county" => "CA",
    //                                 "country" => "US"
    //                             ]
    //                         ]
    //                     ],
    //                     "paymentTerms" => [
    //                         "note" => "For payment terms, only a note is supported by Peppol currently."
    //                     ],
    //                     "paymentMeansArray" => [
    //                         [
    //                             "code" => "credit_transfer",
    //                             "account" => "NL50RABO0162432445",
    //                             "paymentId" => "44556677"
    //                         ]
    //                     ],
    //                     "invoiceLines" => [
    //                         [
    //                             "lineId" => "1",
    //                             "amountExcludingVat" => 2.88,
    //                             "itemPrice" => 0.12332,
    //                             "baseQuantity" => 2,
    //                             "quantity" => 63,
    //                             "quantityUnitCode" => "KWH",
    //                             "allowanceCharges" => [
    //                                 [
    //                                     "reason" => "special discount",
    //                                     "amountExcludingTax" => -0.25
    //                                 ],
    //                                 [
    //                                     "reason" => "even more special discount",
    //                                     "amountExcludingTax" => -0.75
    //                                 ]
    //                             ],
    //                             "tax" => [
    //                                 "percentage" => 21,
    //                                 "country" => "NL",
    //                                 "category" => "standard"
    //                             ],
    //                             "orderLineReferenceLineId" => "3",
    //                             "accountingCost" => "23089",
    //                             "name" => "Supply peak",
    //                             "description" => "Supply",
    //                             "invoicePeriod" => "2020-11-12 - 2020-11-17",
    //                             "note" => "Only half the story...",
    //                             "references" => [
    //                                 [
    //                                     "documentType" => "item_classification_code",
    //                                     "documentId" => "A reference to a commodity classification / item classification code"
    //                                 ],
    //                                 [
    //                                     "documentType" => "item_commodity_code",
    //                                     "documentId" => "A reference to a commodity classification / commodity code"
    //                                 ],
    //                                 [
    //                                     "documentType" => "item_specification",
    //                                     "documentId" => "A reference to an item specification document"
    //                                 ],
    //                                 [
    //                                     "documentType" => "line_document_reference",
    //                                     "documentId" => "A reference to another document"
    //                                 ],
    //                                 [
    //                                     "documentType" => "line_standard_item_identification",
    //                                     "documentId" => "For India IRP, use this for HSN code. For LHDNM, use this for Classification Code code."
    //                                 ],
    //                                 [
    //                                     "documentType" => "line_sellers_item_identification",
    //                                     "documentId" => "The seller's item identification"
    //                                 ],
    //                                 [
    //                                     "documentType" => "line_buyers_item_identification",
    //                                     "documentId" => "The buyer's item identification"
    //                                 ],
    //                                 [
    //                                     "documentType" => "line_batch_number",
    //                                     "documentId" => "This is a batch number"
    //                                 ],
    //                                 [
    //                                     "documentType" => "line_serial_number",
    //                                     "documentId" => "This is a serial number"
    //                                 ]
    //                             ],
    //                             "additionalItemProperties" => [
    //                                 [
    //                                     "name" => "Key1",
    //                                     "value" => "871690930000222221"
    //                                 ]
    //                             ]
    //                         ]
    //                     ],
    //                     "allowanceCharges" => [
    //                         [
    //                             "reason" => "late payment",
    //                             "amountExcludingTax" => 10.2,
    //                             "tax" => [
    //                                 "percentage" => 21,
    //                                 "country" => "NL",
    //                                 "category" => "standard"
    //                             ]
    //                         ]
    //                     ],
    //                     "taxSubtotals" => [
    //                         [
    //                             "taxableAmount" => 13.08,
    //                             "taxAmount" => 2.75,
    //                             "percentage" => 21,
    //                             "country" => "NL"
    //                         ]
    //                     ],
    //                     "amountIncludingVat" => 15.83,
    //                     "prepaidAmount" => 1
    //                 ]
    //             ]
    //         ];
            
    //         \Log::info($invoicePayload);
    //         try {
    //             $client = new Client();
               
    //             $response = $client->post('https://api.storecove.com/api/v2/document_submissions', [
    //                 'headers' => [
    //                     'Authorization' => 'Bearer ' . "8EzJrFUTh3gKxm1FkBmq9qQ0wXpkcE-2yA_BGFA6_ag",
    //                     'Content-Type' => 'application/json'
    //                 ],
    //                 'json' => $invoicePayload
    //             ]);
    //             dd($response);
    //             // Fetch the status code
    //             $statusCode = $response->getStatusCode();
    //             if($statusCode === 200)    {
    //                 $responseBody = $response->getBody()->getContents();
    //                 $responseData = json_decode($responseBody, true);
    //                 $responseOrderBody = $responseOrder->getBody()->getContents();
    //                 $responseOrderBodyData = json_decode($responseOrderBody, true);
    //                 Transaction::where('id', $transaction->id)->update(['peppol_guid' => $responseData["guid"], "peppol_order_guid" =>$responseOrderBodyData["guid"] ]);
    //             }
                        
    //         } catch (RequestException $e) {
    //             \Log::error("Request failed: " . $e->getMessage());
            
    //             if ($e->hasResponse()) {
    //                 $errorResponse = $e->getResponse();
    //                 $errorBody = $errorResponse->getBody()->getContents();
    //                 \Log::error("Error Response: " . $errorBody);
    //             }
    //             return response()->json(['error' => 'Unable to fetch data, please check logs for details.'], 500);
    //         }

    // }

    public function peppolDoc($transaction)
    {
        $contact_details = Contact::where('id', $transaction->contact_id)->first();
        //\Log::info("TEst".$contact_details->peppole_identifier_id);

        $gst = TaxRate::where("business_id", $transaction->business_id)
            ->where("name", "GST")->select("amount")->first();
        $taxAmount = round(($transaction->total_before_tax * $gst->amount) / 100, 2);
        $amountIncludingVat = round($transaction->total_before_tax + $taxAmount, 2);

        $peppoleIdentifierDetails = $this->getPeppolIdentifier($contact_details->peppole_identifier_id);

        $invoicePayload = [
            "legalEntityId" => 301805,
            "routing" => [
                "emails" => [
                    $peppoleIdentifierDetails && $peppoleIdentifierDetails['email'] ? $peppoleIdentifierDetails['email'] : "mayankdubey@warelycorp.com"
                ],
                "eIdentifiers" => [
                    [
                        "scheme" => "SG:UEN",
                        "id" => $peppoleIdentifierDetails && $peppoleIdentifierDetails['participantIdentifierValue'] ? $peppoleIdentifierDetails['participantIdentifierValue'] : "SGUEN201729553C"
                    ]
                ]
            ],
            "document" => [
                "documentType" => "invoice",
                "invoice" => [
                    "invoiceNumber" => $transaction->ref_no,
                    "issueDate" => date('Y-m-d'),
                    "documentCurrencyCode" => "SGD",
                    "taxSystem" => "tax_line_percentages",
                    "accountingCustomerParty" => [
                        "party" => [
                            "companyName" => $peppoleIdentifierDetails && $peppoleIdentifierDetails['multilingualNameDtos'] ? $peppoleIdentifierDetails['multilingualNameDtos'] : "Peppol user",
                            "address" => [
                                "street1" => "Street 123",
                                "zip" => "1111AA",
                                "city" => "Here",
                                "country" => "SG"
                            ]
                        ],
                        "publicIdentifiers" => [
                            [
                                "scheme" => "SG:UEN",
                                "id" => $peppoleIdentifierDetails && $peppoleIdentifierDetails['participantIdentifierValue'] ? $peppoleIdentifierDetails['participantIdentifierValue'] : "SGUEN201729553C"
                            ]
                        ]
                    ],
                    "invoiceLines" => [
                        [
                            "description" => "The things you purchased",
                            "amountExcludingVat" => intval($transaction->total_before_tax),
                            "tax" => [
                                "percentage" => $gst->amount,
                                "category" => "standard",
                                "country" => "SG"
                            ]
                        ]
                    ],
                    "taxSubtotals" => [
                        [
                            "percentage" => $gst->amount,
                            "category" => "standard",
                            "country" => "SG",
                            "taxableAmount" => intval($transaction->total_before_tax),
                            "taxAmount" => $taxAmount
                        ]
                    ],
                    "paymentMeansArray" => [
                        [
                            "account" => "NL50ABNA0552321249",
                            "holder" => "Storecove",
                            "code" => "credit_transfer"
                        ]
                    ],
                    "amountIncludingVat" => $amountIncludingVat
                ]
            ]
        ];
        // $invoicePayload = [
        //     "legalEntityId" => 301805,
        //     "routing" => [
        //         "emails" => [
        //         "mayankdubey@warelycorp.com"
        //         ],
        //         "eIdentifiers" => [
        //             [
        //                 "scheme" => "SG:UEN",
        //                 "id" => $peppoleIdentifierDetails && $peppoleIdentifierDetails['participantIdentifierValue'] ? $peppoleIdentifierDetails['participantIdentifierValue'] : "SGUEN201729553C"
        //             ]
        //         ]
        //     ],
        //     "document" => [
        //         "documentType" => "invoice",
        //         "invoice" => [
        //             "invoiceNumber" => $transaction->ref_no,
        //             "issueDate" => date('Y-m-d'),
        //             "documentCurrencyCode" => "SGD",
        //             "taxSystem" => "tax_line_percentages",
        //             "accountingCustomerParty" => [
        //                 "party" => [
        //                     "companyName" => $peppoleIdentifierDetails && $peppoleIdentifierDetails['multilingualNameDtos'] ? $peppoleIdentifierDetails['multilingualNameDtos'] : "Peppol user",
        //                     "address" => [
        //                         "street1" => "Street 123",
        //                         "zip" => "1111AA",
        //                         "city" => "Here",
        //                         "country" => "SG"
        //                     ]
        //                 ],
        //                 "publicIdentifiers" => [
        //                     [
        //                         "scheme" => "SG:UEN",
        //                         "id" => $peppoleIdentifierDetails && $peppoleIdentifierDetails['participantIdentifierValue'] ? $peppoleIdentifierDetails['participantIdentifierValue'] : "SGUEN201729553C"
        //                     ]
        //                 ]
        //             ],
        //             "invoiceLines" => [
        //                 [
        //                     "description" => "The things you purchased",
        //                     "amountExcludingVat" => intval($transaction->total_before_tax),
        //                     "tax" => [
        //                         "percentage" =>$gst->amount,
        //                         "category" => "standard",
        //                         "country" => "SG"
        //                     ]
        //                 ]
        //             ],
        //             "taxSubtotals" => [
        //                 [
        //                     "percentage" => $gst->amount,
        //                     "category" => "standard",
        //                     "country" => "SG",
        //                     "taxableAmount" => intval($transaction->total_before_tax), // Removes decimal places
        //                     "taxAmount" => $taxAmount
        //                 ]
        //             ],
        //             "paymentMeansArray" => [
        //                 [
        //                     "account" => "NL50ABNA0552321249",
        //                     "holder" => "Storecove",
        //                     "code" => "credit_transfer"
        //                 ]
        //             ],
        //             "amountIncludingVat" => $amountIncludingVat
        //         ]
        //     ]
        // ];
        
        
        //\Log::info($invoicePayload);

        $client = new Client();
        try {
            $response = $client->post('https://api.storecove.com/api/v2/document_submissions', [
                'headers' => [
                    'Authorization' => 'Bearer ' . "8EzJrFUTh3gKxm1FkBmq9qQ0wXpkcE-2yA_BGFA6_ag",
                    'Content-Type' => 'application/json'
                ],
                'json' => $invoicePayload
            ]);

            $statusCode = $response->getStatusCode();
            if ($statusCode === 200) {
                $responseBody = $response->getBody()->getContents();
                $responseData = json_decode($responseBody, true);
                Transaction::where('id', $transaction->id)
                    ->update(['peppol_guid' => $responseData["guid"]]);
            }
        } catch (RequestException $e) {
            \Log::error("Request failed: " . $e->getMessage());
            if ($e->hasResponse()) {
                $errorResponse = $e->getResponse();
                $errorBody = $errorResponse->getBody()->getContents();
                \Log::error("Error Response: " . $errorBody);
            }
            return response()->json(['error' => 'Unable to fetch data, please check logs for details.'], 500);
        }
    }


        public function getPeppolIdentifier($peppolIdentifier) {
        // try {
            $client = new Client();
            // Define query parameters as an associative array
            $queryParams = [
                'sortBy' => 'registered',
                'sortDirection' => 'DESC',
                'freeText' => $peppolIdentifier,//"0195:sguen200507099",//$peppolIdentifier,
                'limit' => 10
            ];
    
            // Pass the query parameters in the request
            $response = $client->get('https://api.peppoldirectory.sg/public/web/search', [
                'query' => $queryParams
            ]);
    
            $statusCode = $response->getStatusCode();
    
            if ($statusCode === 200) {
                $responseBody = $response->getBody()->getContents();
                $responseData = json_decode($responseBody, true);
                if (isset($responseData['participants'][0])) {
                    // Access the first participant's data
                    $participant = $responseData['participants'][0];
                    $peppolIdentifierDetails = [];    
                    if (!empty($participant)) {
                        $peppolIdentifierDetails = [
                            'multilingualNameDtos' => $participant['businessEntityDtos'][0]['multilingualNameDtos'][0]['name'] ?? 'Peppol user',
                            'participantIdentifierValue' => $participant['participantIdentifier']['participantIdentifierValue'] ?? 'Unknown Identifier',
                            'participantIdentifierSchema' => $participant['participantIdentifier']['participantIdentifierSchema'] ?? 'Unknown Identifier',
                            'email' => $participant['businessEntityDtos'][0]['contactDtos'][0]['email'] ?? 'No Email Provided',
                            'registered' => $participant['registered'] ?? null,
                            'contactName' => $participant['businessEntityDtos'][0]['contactDtos'][0]['name'] ?? 'No Contact Name',
                            'phoneNumber' => $participant['businessEntityDtos'][0]['contactDtos'][0]['phoneNumber'] ?? 'No Phone Number',
                        ];
                    }
    
                    return $peppolIdentifierDetails;
                } else {
                    return [];
                }
            }
        // } catch (RequestException $e) {
        //     \Log::error("Request failed: " . $e->getMessage());
            
        //     if ($e->hasResponse()) {
        //         $errorResponse = $e->getResponse();
        //         $errorBody = $errorResponse->getBody()->getContents();
        //         \Log::error("Error Response: " . $errorBody);
        //     }
    
    }

    public function changeInvoiceStatus(Request $request)
    {
        $input = $request->all();
        $client = new Client();
        $status = "reject"; 
        if (!empty($input["type"])) {
            $status = "accept";
            $invoicePayload = [
                "receiveGuid" => $input["id"],
                "document" => [
                    "documentType" => "invoice_response",
                    "invoiceResponse" => [
                        "responseCode" => $input['responseCode'] ?? "AP",
                        "clarifications" => $input['clarifications'] ?? []
                    ]
                ]
            ];
        } else {
            $invoicePayload = [
                "receiveGuid" => $input["id"],
                "document" => [
                    "documentType" => "invoice_response",
                    "invoiceResponse" => [
                        "responseCode" => "RE",
                        "clarifications" => [
                            [
                                "clarificationCode" => "REF",
                                "clarificationCodeType" => "OPStatusReason"
                            ],
                            [
                                "clarificationCode" => "NOA",
                                "clarificationCodeType" => "OPStatusAction"
                            ]
                        ]
                    ]
                ]
            ];
        }

        try {
            $response = $client->post('https://api.storecove.com/api/v2/document_submissions', [
                'headers' => [
                    'Authorization' => 'Bearer ' . "8EzJrFUTh3gKxm1FkBmq9qQ0wXpkcE-2yA_BGFA6_ag",
                    'Content-Type' => 'application/json'
                ],
                'json' => $invoicePayload
            ]);

            $statusCode = $response->getStatusCode();
            if ($statusCode === 200) {
                $responseBody = $response->getBody()->getContents();
                $responseData = json_decode($responseBody, true);
                PeppolDocument::where('guid', $input['id'])
                    ->update(['invoice_status' => $status]);
                return response()->json(['message' => 'Invoice status updated successfully.', 'data' => $responseData], 200);
            } else {
                return response()->json(['error' => 'Failed to update invoice status.', 'status_code' => $statusCode], $statusCode);
            }
        } catch (RequestException $e) {
            \Log::error("Request failed: " . $e->getMessage());
            if ($e->hasResponse()) {
                $errorResponse = $e->getResponse();
                $errorBody = $errorResponse->getBody()->getContents();
                \Log::error("Error Response: " . $errorBody);
                return response()->json(['error' => 'Request failed with an error response.', 'details' => $errorBody], $errorResponse->getStatusCode());
            }
            return response()->json(['error' => 'Unable to fetch data, please check logs for details.'], 500);
        }
    }

    public function registerLegalEntity(Request $request) {
        
        $business_id = session()->get('user.business_id');
        return view('peppol.register_legal_entity');
    }

    public function storeLegalEntity(Request $request)
    {
        $data = $request->validate([
            'business_id' => 'required|exists:businesses,id',
            'acts_as_receiver' => 'nullable|boolean',
            'acts_as_sender' => 'nullable|boolean',
            'additional_tax_identifiers' => 'nullable|array',
            'advertisements' => 'nullable|array',
            'api_keys' => 'nullable|array',
            'city' => 'nullable|string|max:255',
            'classification_code' => 'nullable|string|max:255',
            'country' => 'nullable|string|max:255',
            'county' => 'nullable|string|max:255',
            'line1' => 'nullable|string|max:255',
            'line2' => 'nullable|string|max:255',
            'party_name' => 'nullable|string|max:255',
            'peppol_identifiers' => 'nullable|array',
            'public' => 'nullable|boolean',
            'tax_registered' => 'nullable|boolean',
            'tenant_id' => 'nullable|string|max:255',
            'zip' => 'nullable|string|max:255',
        ]);
        
        PeppolLegalEntity::create($data);


        return redirect()->back()->with('success', 'Peppol Legal Entity registered successfully.');
    }

}
