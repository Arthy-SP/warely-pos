<?php

namespace App\Http\Controllers;

use App\Couponsystem;
use App\CouponLayout;
use App\Campaign;
use App\CampaignList;
use App\Utils\Util;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;

use Datatables;

class CouponsystemController extends Controller
{
    
    protected $commonUtil;

    public function __construct(Util $commonUtil)
    {
        $this->commonUtil = $commonUtil;
        
    }


    public function index()
    {
        
        if (!auth()->user()->can('couponsystem.access')) {
            abort(403, 'Unauthorized action.');
        }

        if (request()->ajax()) {
            $business_id = request()->session()->get('user.business_id');

            $barcodes = Couponsystem::where('business_id', $business_id)
                        ->select(['id','coupon_name', 'coupon_qty', 'coupon_value']);

            return Datatables::of($barcodes)
                ->addColumn(
                    'action',
                    '<a href="{{action(\'CouponsystemController@edit\', [$id])}}" class="btn btn-xs btn-primary"><i class="glyphicon glyphicon-edit"></i> @lang("messages.edit")</a>
                        &nbsp;
                        <button type="button" data-href="{{action(\'CouponsystemController@destroy\', [$id])}}" class="btn btn-xs btn-danger delete_barcode_button" ><i class="glyphicon glyphicon-trash"></i> @lang("messages.delete")</button>&nbsp;
                        '
                )
                ->rawColumns([0, 4])
                ->make(false);
        }

        return view('coupon_system.index');
    }
    public function create()
    {
        
        if (!auth()->user()->can('couponsystem.access')) {
            abort(403, 'Unauthorized action.');
        }
        $business_id = request()->session()->get('user.business_id');
        $layout_ids = CouponLayout::where('business_id', $business_id)
                            ->pluck('name', 'id');


        return view('coupon_system.create')->with(compact('layout_ids'));
    }

    public function show($id)
    {
        
    }
    
    public function store(Request $request)
    {
        if (!auth()->user()->can('couponsystem.access')) {
            abort(403, 'Unauthorized action.');
        }

        try {
            $input = $request->only(['layout_id', 'coupon_name', 'coupon_qty', 'min_purchase', 'coupon_value', 'start_date', 'end_date', 'expiry_day', 'min_pax', 'front_image', 'back_image', 'coupon_type', 'occurence', 'occurence_weekly_options', 'coupon_start_time', 'coupon_end_time', 'coupon_code']);

            $business_id = $request->session()->get('user.business_id');
            
            if($this->coupon_code_exists($business_id, $input['coupon_code'])){
                return redirect('coupons')->with('status', ['success' => 0, 'msg' => 'coupon code already exists']);
            }
            $input['start_date'] = date('Y-m-d',strtotime($input['start_date']));
            $input['end_date'] = date('Y-m-d', strtotime($input['end_date']));
            $input['business_id'] = $business_id;

            if (!empty($input['occurence_weekly_options'])) {
                $input['occurence_weekly_options'] = json_encode($input['occurence_weekly_options']);
            }

            if($input['occurence'] == 'daily') {
                $input['occurence_weekly_options'] = null;
            }

            $front_image = $this->commonUtil->uploadFile($request, 'front_image', 'coupons', 'image');
            if (!empty($front_image)) {
                $input['front_image'] = $front_image;
            }

            $back_image = $this->commonUtil->uploadFile($request, 'back_image', 'coupons', 'image');
            if (!empty($back_image)) {
                $input['back_image'] = $back_image;
            }
            

            $barcode = Couponsystem::create($input);
            $output = ['success' => 1,
                            'msg' => 'successfully added'
                        ];
         } catch (\Exception $e) {
            \Log::emergency("File:" . $e->getFile(). "Line:" . $e->getLine(). "Message:" . $e->getMessage());
            
            $output = ['success' => 0,
                            'msg' => __("messages.something_went_wrong")
                        ];
        } 
        return redirect('coupons')->with('status', $output);
    }

    public function edit($id)
    {
        if (!auth()->user()->can('couponsystem.access')) {
            abort(403, 'Unauthorized action.');
        }

        $business_id = request()->session()->get('user.business_id');
        
        $coupons = Couponsystem::where('business_id', $business_id)->find($id);
        
        $start_date = Carbon::parse($coupons->start_date)->format('Y-m-d');
        $end_date = Carbon::parse($coupons->end_date)->format('Y-m-d');
        $layout_ids = CouponLayout::where('business_id', $business_id)
                                    ->pluck('name', 'id');
        return view('coupon_system.edit')
            ->with(compact('coupons','layout_ids','start_date','end_date'));
    }

    public function update(Request $request, $id)
    {
        if (!auth()->user()->can('couponsystem.access')) {
            abort(403, 'Unauthorized action.');
        }

        try {
            $input = $request->only(['layout_id', 'coupon_name', 'coupon_qty', 'min_purchase', 'coupon_value','start_date', 'end_date', 'expiry_day', 'min_pax',
                                    'front_image', 'back_image', 'coupon_type', 'occurence', 'occurence_weekly_options', 'coupon_start_time', 'coupon_end_time', 'coupon_code']);
            
            $business_id = $request->session()->get('user.business_id');

            if($this->coupon_code_exists($business_id, $input['coupon_code'], $id)){
                return redirect('coupons')->with('status', ['success' => 0, 'msg' => 'coupon code already exists']);
            }
            $input['business_id'] = $business_id;
            $input['start_date'] = date('Y-m-d',strtotime($input['start_date']));
            $input['end_date'] = date('Y-m-d', strtotime($input['end_date']));

            if (!empty($input['occurence_weekly_options'])) {
                $input['occurence_weekly_options'] = json_encode($input['occurence_weekly_options']);
            }

            if($input['occurence'] == 'daily') {
                $input['occurence_weekly_options'] = null;
            }
            /*
            $front_image = $this->commonUtil->uploadFile($request, 'front_image', 'coupons', 'image');
            if (!empty($front_image)) {
                $input['front_image'] = $front_image;
            }

            $back_image = $this->commonUtil->uploadFile($request, 'back_image', 'coupons', 'image');
            if (!empty($back_image)) {
                $input['back_image'] = $back_image;
            }
            */

            $barcode = Couponsystem::where('id', $id)->update($input);
            
            $output = ['success' => 1,
                          'msg' => 'successfully updated'
                      ];
       } catch (\Exception $e) {
            \Log::emergency("File:" . $e->getFile(). "Line:" . $e->getLine(). "Message:" . $e->getMessage());
            
            $output = ['success' => 0,
                           'msg' => __("messages.something_went_wrong")
                       ];
        } 

        return redirect('coupons')->with('status', $output);
    }
    public function dashboard() {
        
        $business_id = request()->session()->get('user.business_id');
        //$coupons = Couponsystem::where('business_id', $business_id);
        
        $coupon = CampaignList::select(DB::raw('count(id) as total_quantity'))->where('business_id', $business_id)->where('status',0)->first();
        $coupons['AVAILABLE'] = $coupon->total_quantity;

        $Campaign = CampaignList::select(DB::raw('count(id) as total_quantity'))->where('business_id', $business_id)->where('status',1)->first();
        $coupons['ISSUED'] = $Campaign->total_quantity;

        $Campaign = CampaignList::select(DB::raw('count(id) as total_quantity'))->where('business_id', $business_id)->where('status',2)->first();
        $coupons['REDEEM'] = $Campaign->total_quantity;
        
        $Campaign = CampaignList::select(DB::raw('count(id) as total_quantity'))->where('business_id', $business_id)->whereDate('expiry_date','<',date('Y-m-d H:i:s'))->whereDate('expiry_date','!=','0000-00-00 00:00:00')->first();
        $coupons['EXPIRED'] = $Campaign->total_quantity;

        $all_Coupons = Couponsystem::where('business_id', $business_id)
                            ->pluck('coupon_name', 'id');

        $all_Campaign = Campaign::where('business_id', $business_id)
                            ->pluck('name', 'id'); 
        // dd($all_Campaign, $all_Coupons);               
        $coupon_status =['AVAILABLE', 'ISSUED', 'REDEEM', 'EXPIRED'];
        return view('coupon_system.dashboard')
            ->with(compact('coupons','all_Coupons','all_Campaign', 'coupon_status' ));
    }
    
    public function getCampaign()
    {
        if (request()->ajax()) {
            
            $business_id = request()->session()->get('user.business_id');
            $coupon_id = (int)request()->coupon_id;

            $all_Campaign = Campaign::where('business_id', $business_id)->where('coupon_id',$coupon_id)
                            ->pluck('name', 'id');
                            $options = '<option value="">Select Campaign</option>';
            foreach ($all_Campaign as $key => $value) {
                
                $options .= "<option value='".$key."'>".$value."</option>";
            }                                        
            return $options;
        }
    }
    public function getTotals()
    {
        if (request()->ajax()) {
            
            $business_id = request()->session()->get('user.business_id');
            $coupon_id = (int)request()->coupon_id;
            $campaign_id = (int)request()->campaign_id;
            
            $coupon = CampaignList::select(DB::raw('count(id) as total_quantity'))->where('business_id', $business_id)->where('status',0);
            if($coupon_id > 0) $coupon->where('coupon_id',$coupon_id);
            if($campaign_id > 0) $coupon->where('campaign_id',$campaign_id);
            $coupon = $coupon->first();
            $output['AVAILABLE'] = (int)$coupon->total_quantity;

            $Campaign = CampaignList::select(DB::raw('count(id) as total_quantity'))->where('business_id', $business_id)->where('status',1);
            if($coupon_id > 0) $Campaign->where('coupon_id',$coupon_id);
            if($campaign_id > 0) $Campaign->where('campaign_id',$campaign_id);
            $Campaign = $Campaign->first();
            $output['ISSUED'] = (int)$Campaign->total_quantity;

            $Campaign = CampaignList::select(DB::raw('count(id) as total_quantity'))->where('business_id', $business_id)->where('status',2);
            if($coupon_id > 0) $Campaign->where('coupon_id',$coupon_id);
            if($campaign_id > 0) $Campaign->where('campaign_id',$campaign_id);
            $Campaign = $Campaign->first();
            $output['REDEEM'] = (int)$Campaign->total_quantity;
            
            $Campaign = CampaignList::select(DB::raw('count(id) as total_quantity'))->where('business_id', $business_id)->whereDate('expiry_date','<',date('Y-m-d H:i:s'))->whereDate('expiry_date','!=','0000-00-00 00:00:00');
            if($coupon_id > 0) $Campaign->where('coupon_id',$coupon_id);
            if($campaign_id > 0) $Campaign->where('campaign_id',$campaign_id);
            $Campaign = $Campaign->first();
            $output['EXPIRED'] = (int)$Campaign->total_quantity;
            
            
            return $output;
        }
    }
    public function destroy($id)
    {
        if (!auth()->user()->can('couponsystem.access')) {
            abort(403, 'Unauthorized action.');
        }

        if (request()->ajax()) {
            try {
                $barcode = Couponsystem::find($id);
                    $barcode->delete();
                    $output = ['success' => true,
                                'msg' => 'successfully deleted'
                                ];
            } catch (\Exception $e) {
                \Log::emergency("File:" . $e->getFile(). "Line:" . $e->getLine(). "Message:" . $e->getMessage());
            
                $output = ['success' => false,
                            'msg' => __("messages.something_went_wrong")
                        ];
            }

            return $output;
        }
    }
    public function savelayout(Request $request, $id)
    {
        if (request()->ajax()) {
            $input = $request->only(['front_image', 'back_image']);
            $barcode = Couponsystem::where('id', $id)->update($input);
            
            return 1;
        }
    }
    public function getCoupons($id)
    {
        $business_id = request()->session()->get('user.business_id');
        if (request()->ajax()) {
            $CouponLayout = CouponLayout::find($id);
            $output = [
                'front_layout_code' => $CouponLayout->front_layout_code,
                'back_layout_code' => $CouponLayout->back_layout_code,
            ];
            return $output;
        }
    }

    public function coupon_code_exists($business_id, $code, $id=null){
        $coupon = Couponsystem::where('business_id', $business_id)
            ->where('coupon_code', $code);
            if ($id !== null) {
                $coupon->where('id', '!=', $id);
            }
            return $coupon->exists();
    }

}

