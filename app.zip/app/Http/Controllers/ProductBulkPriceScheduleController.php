<?php

namespace App\Http\Controllers;

use App\ProductBulkPriceSchedule;
use Illuminate\Http\Request;
use App\Category;
use App\Product;
use App\BusinessLocation;
use App\SellingPriceGroup;
use App\VariationGroupPrice;
use App\Variation;
use Carbon\Carbon;
use Illuminate\Support\Facades\Response;


class ProductBulkPriceScheduleController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */ 

    public function index()
    {
        if (!auth()->user()->can('product.view') && !auth()->user()->can('product.create')) {
            abort(403, 'Unauthorized action.');
        }
    
        $business_id = request()->session()->get('user.business_id');

        \Log::info(request()->ajax());

        if (request()->ajax()) {
            $query = Product::
                leftJoin('variations as v', 'v.product_id', '=', 'products.id')
                ->leftJoin('categories as c1', 'products.category_id', '=', 'c1.id')
                ->leftJoin('categories as c2', 'products.sub_category_id', '=', 'c2.id')
                ->leftJoin('variation_group_prices as vgp', 'v.id', '=', 'vgp.variation_id') 
                ->where('products.business_id', $business_id)
                ->select(
                    'products.id',
                    'products.name as product',
                    'v.default_sell_price as default_sell_price',
                    'v.id as variation_id',
                    'v.member_price as member_price',
                    'products.category_id as category_id',
                    'vgp.price_inc_tax' 
                );
    
            $category_id = request()->get('category_id', null);
            if (!empty($category_id)) {
                $query->where('products.category_id', $category_id);
            }
    
            return \Datatables::of($query)
                ->addColumn('variation_group_prices', function ($product) {
                    $variationGroupPrices = VariationGroupPrice::where("variation_id", $product->variation_id)->get();
    
                    return $variationGroupPrices->map(function ($variationGroupPrice) {
                        $sellingPriceGroup = SellingPriceGroup::where('id', $variationGroupPrice->price_group_id)->first();
                        return [
                            'group' => $sellingPriceGroup ? $sellingPriceGroup->name : null,
                            'id' => $sellingPriceGroup ? $sellingPriceGroup->id : null,
                            'price_inc_tax' => number_format($variationGroupPrice->price_inc_tax,2) 
                        ];
                    });
                })
                ->make(true); 
        }
    
        $categories = Category::forDropdown($business_id, 'product');
    
        return view('product_bulk_price_update.index')->with(compact('categories'));
    }


    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        try {
            $business_id = session()->get('user.business_id');
            $validated = $request->validate([
                'schedule_datetime' => 'required|date|after_or_equal:now', 
                'data' => 'required|array',
                'data.*.product_id' => 'required|integer|exists:products,id',
                'data.*.category_id' => 'nullable|integer|exists:categories,id', 
                'data.*.price' => 'nullable|numeric', 
                'data.*.member_price' => 'nullable|numeric', 
                'data.*.group' => 'nullable|array', 
                'data.*.group.*' => 'numeric', 
            ]);
    
            $bulkInsertData = [];
            foreach ($validated['data'] as $product) {
                $bulkInsertData[] = [
                    "business_id" => $business_id,
                    'product_id' => $product['product_id'],
                    'category_id' => $product['category_id'] ?? null,
                    'schedule_date_time' => $validated['schedule_datetime'],
                    'prices' => json_encode(
                        [
                            "groups" => $product['group'] ?? [],
                            "member_price" => $product['member_price'] ?? null,
                            "price" => $product['price'] ?? null,
                        ]
                    ), // Convert prices to JSON
                    'status' => 'active', // Default status
                    'created_at' => now(),
                    'updated_at' => now(),
                ];
            }
    
            // Bulk insert into the database
            ProductBulkPriceSchedule::insert($bulkInsertData);
    
            return response()->json([
                'message' => 'Schedule saved successfully!',
                'data' => $bulkInsertData,
            ], 201); // Return a success response with status 201
        } catch (\Illuminate\Validation\ValidationException $e) {
            return response()->json([
                'message' => 'Validation failed.',
                'errors' => $e->errors(),
            ], 422); 
        } catch (\Exception $e) {
            \Log::error('Error saving schedule:', ['exception' => $e]);
    
            return response()->json([
                'message' => 'An error occurred while saving the schedule.',
                'error' => $e->getMessage(),
            ], 500); 
        }
    }
    

    /**
     * Display the specified resource.
     *
     * @param  \App\ProductBulkPriceSchedule  $productBulkPriceSchedule
     * @return \Illuminate\Http\Response
     */
    public function getSchedules()
    {
        $business_id = request()->session()->get('user.business_id');
        if (request()->ajax()) {
            $data = ProductBulkPriceSchedule::with(['category:id,name'])
                ->where("business_id", $business_id)
                ->groupBy("category_id")
                ->get(['id', 'product_id', 'category_id', 'schedule_date_time']); // Select only necessary columns
    
            return \DataTables::of($data)
                ->addColumn('category', function ($row) {
                    return $row->category ? $row->category->name : '';
                })
                ->addColumn('action', function ($row) {
                    return '
                        <a href="/products/update_price/schedules/' . $row->category_id . '/edit" class="btn btn-sm btn-primary">Edit</a>
                        <a href="/products/update_price/schedules/' . $row->category_id . '/view" class="btn btn-sm btn-success">View</a>
                        <a href="#"  data-id="'. $row->category_id.'"class="btn btn-sm btn-warning btn-export">Export</a>
                        <a href="/products/update_price/schedules/' . $row->category_id . '/duplicate" class="btn btn-sm btn-info">Duplicate</a>
                        <button type="button" data-id="'. $row->category_id.'" data-href="/products/update_price/schedules/delete/'.$row->category_id.'" class="btn btn-sm btn-danger delete-btn destroy-schedules">Delete</button>

                    ';
                })
                ->make(true);  
        }
    
        return view('product_bulk_price_update.show');
    }
    
    public function viewSchedules($category_id , $page)
    {
        $business_id = request()->session()->get('user.business_id');
        $data = ProductBulkPriceSchedule::with(['product:id,name'])
            ->where("business_id", $business_id);
    
        if ($category_id) {
            $data->where('category_id', $category_id);
        }
    
        $data = $data->get(['id', 'product_id', 'category_id', 'prices', 'schedule_date_time']);
    
        $group_keys = []; 
        $data = $data->map(function ($row) use (&$group_keys) {
            $prices = $row->prices; 
            $row->member_price = $prices['member_price'] ?? 0;
            $row->price = $prices['price'] ?? 0;
            $row->groups = $prices['groups'] ?? [];
            $group_keys = array_unique(array_merge($group_keys, array_keys($row->groups)));
            return $row;
        });
    
        return view('product_bulk_price_update.view', compact('data', 'category_id', 'group_keys', 'page'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\ProductBulkPriceSchedule  $productBulkPriceSchedule
     * @return \Illuminate\Http\Response
     */
    public function updateSchedules(Request $request)
    {
        $business_id = $request->session()->get('user.business_id');
        
           try {
            $data = $request->all();
            $duplicateData = [];
            foreach ($data['schedule_date_time'] as $id => $schedule_date_time) {
                if (empty($schedule_date_time)) {
                    continue;
                }
    
                $schedule = ProductBulkPriceSchedule::where('id', $id)
                    ->where('business_id', $business_id)
                    ->first();
    
                if ($schedule) {
                    $prices = [
                        'member_price' => $data['member_price'][$id] ?? null,
                        'price' => $data['price'][$id] ?? null,
                        'groups' => $data['groups'][$id] ?? [],
                    ];
    
                    if ($schedule_date_time) {
                        $schedule_date_time = Carbon::createFromFormat('Y-m-d H:i', $schedule_date_time);
                    }
                    if($data['page'] === "edit"){
                        $schedule->schedule_date_time = $schedule_date_time;                
                        $schedule->prices = $prices;
                        $schedule->save();
                    }else{
                        $duplicateData[] = [
                            'product_id' => $schedule->product_id,
                            'category_id' => $schedule->category_id,
                            'business_id' => $business_id,
                            'schedule_date_time' => $schedule_date_time,
                            'prices' => json_encode($prices),
                            'status' => 'active', 
                            'created_at' => now(),
                            'updated_at' => now(),
                        ];
                    }
                }
            }
            if($data['page'] === "duplicate"){
                ProductBulkPriceSchedule::insert($duplicateData);
            }
            return response()->json([
                'message' => 'Schedule saved successfully!',
                'scuess' =>true,
            ], 201);    
        
        } catch (\Illuminate\Validation\ValidationException $e) {
            \Log::error('Error updating schedules:', ['message' => $e->getMessage()]);
            return response()->json([
                'message' => 'An error occurred while updating schedules. Please try again.',
                'scuess' =>true,
            ], 201);
        }
    }
    public function exportSchedules($category_id)
    {
        $business_id = request()->session()->get('user.business_id');
        $schedules = ProductBulkPriceSchedule::with(['category:id,name', 'product:id,name'])
            ->where('business_id', $business_id)
            ->where('category_id', $category_id)
            ->get();
    
        $handle = fopen('php://output', 'w');
    
        fputcsv($handle, ['Category', 'Product', 'Schedule Date Time', 'Member Price', 'Price', 'Groups']);
    
        foreach ($schedules as $schedule) {
            $prices = $schedule->prices;
            $groups = $prices['groups'] ?? [];
    
            fputcsv($handle, [
                $schedule->category->name ?? 'N/A', 
                $schedule->product->name ?? 'N/A',  
                $schedule->schedule_date_time,      
                $prices['member_price'] ?? '0.00',  
                $prices['price'] ?? '0.00',         
                implode(', ', $groups),             
            ]);
        }
    
        $filename = 'product_bulk_price_schedule_' . now()->format('Y-m-d_H-i-s') . '.csv';
        return response()->stream(function () use ($handle) {
            fclose($handle);
        }, 200, [
            'Content-Type' => 'text/csv',
            'Content-Disposition' => 'attachment; filename="' . $filename . '"',
        ]);
    }
    
    public function destroySchedules($category_id)
    {
        try {
            $business_id = request()->session()->get('user.business_id');
    
            $destroyedSchedules = ProductBulkPriceSchedule::where('business_id', $business_id)
                                                          ->where('category_id', $category_id)
                                                          ->delete();
    
            if ($destroyedSchedules) {
                $msg = __('Category schdule delete sucessfully.');
                $output = [
                    'success' => true,
                    'msg' => $msg
                ];
            } else {
                $msg = __('lang_v1.no_schedules_found_for_deletion');
                $output = [
                    'success' => false,
                    'msg' => $msg
                ];
            }
        } catch (\Exception $e) {
            \Log::emergency("File: " . $e->getFile() . " Line: " . $e->getLine() . " Message: " . $e->getMessage());
                $output = [
                'success' => false,
                'msg' => __("messages.something_went_wrong")
            ];
        }
       return response()->json($output);
    }
    
 
}













