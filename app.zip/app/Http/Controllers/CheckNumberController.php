<?php

namespace App\Http\Controllers;

use App\InvoiceNumbers;
use App\BusinessLocation;
use Illuminate\Http\Request;
use Datatables;

class CheckNumberController extends Controller
{
/**
     * Display a listing of the resource.
     * @return Response
     */
    public function index()
    {
        if (!auth()->user()->can('access_tables')) {
            abort(403, 'Unauthorized action.');
        }

        if (request()->ajax()) {
            $business_id = request()->session()->get('user.business_id');
            
            $check_numbers = InvoiceNumbers::where('invoice_numbers.business_id', $business_id)
                                    ->join('business_locations AS BL', 'invoice_numbers.location_id', '=', 'BL.id')
                                    ->select(['BL.name as location', 'invoice_numbers.display_number', 'invoice_numbers.id', 'BL.website', 'invoice_numbers.location_id'
                                        , 'invoice_numbers.prefix', 'invoice_numbers.start_from']);
            
            return Datatables::of($check_numbers)
               ->addColumn(
                   'action',
                   '@role("Admin#' . $business_id . '")
                   <button data-href="{{action(\'CheckNumberController@edit\', [$id])}}" class="btn btn-xs btn-primary edit_check_numbers_button"><i class="glyphicon glyphicon-edit"></i> @lang("messages.edit")</button>
                       &nbsp;
                   @endrole
                   @role("Admin#' . $business_id . '")
                       <button data-href="{{action(\'CheckNumberController@destroy\', [$id])}}" class="btn btn-xs btn-danger delete_check_numbers_button"><i class="glyphicon glyphicon-trash"></i> @lang("messages.delete")</button>
                   @endrole'
               )
               ->removeColumn('id')
               ->make(true);
       }

       return view('check_numbers.index');
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        if (!auth()->user()->can('invoice_settings.access')) {
            abort(403, 'Unauthorized action.');
        }

        $business_id = request()->session()->get('user.business_id');
        $business_locations = BusinessLocation::forDropdown($business_id);

        return view('check_numbers.create')
            ->with(compact('business_locations'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        if (!auth()->user()->can('invoice_settings.access')) {
            abort(403, 'Unauthorized action.');
        }

        try {
            $input = $request->only(['display_number', 'prefix', 'location_id', 'start_from']);
            $business_id = $request->session()->get('user.business_id');
            $input['business_id'] = $business_id;

            $check_number = InvoiceNumbers::where('business_id', $business_id)
                                        ->where('location_id', $input['location_id'])
                                        ->whereNull('deleted_at')
                                        ->get();

            if( $check_number->isEmpty() ) {
                InvoiceNumbers::create($input);
                $output = ['success' => true,
                                'msg' => __("invoice.added_success")
                            ];
            } else {
                $output = ['success' => false,
                            'msg' => "Check number for selected business location is already created. You can edit the setting"
                        ];
            }
        } catch (\Exception $e) {
            \Log::emergency("File:" . $e->getFile(). "Line:" . $e->getLine(). "Message:" . $e->getMessage());
            
            $output = ['success' => false,
                            'msg' => __("messages.something_went_wrong")
                        ];
        }

        return $output;
    }

    /**
     * Show the specified resource.
     * @return Response
     */
    public function show()
    {
        if (!auth()->user()->can('access_tables')) {
            abort(403, 'Unauthorized action.');
        }

        return view('check_numbers.show');
    }

    /**
     * Show the form for editing the specified resource.
     * @return Response
     */
    public function edit($id)
    {
        if (!auth()->user()->can('access_tables')) {
            abort(403, 'Unauthorized action.');
        }

        if (request()->ajax()) {
            $business_id = request()->session()->get('user.business_id');
            $check_number = InvoiceNumbers::where('business_id', $business_id)->find($id);
            
            return view('check_numbers.edit')->with(compact('check_number'));
        }
    }

    /**
     * Update the specified resource in storage.
     * @param  Request $request
     * @return Response
     */
    public function update(Request $request, $id)
    {
        if (!auth()->user()->can('access_tables')) {
             abort(403, 'Unauthorized action.');
        }

        if (request()->ajax()) {
            try {
                $input = $request->only(['display_number', 'prefix', 'start_from']);
                $business_id = $request->session()->get('user.business_id');
                $checkNumber = InvoiceNumbers::where('business_id', $business_id)->findOrFail($id);
                
                $checkNumber->display_number = $input['display_number'];
                $checkNumber->prefix = $input['prefix'];
                $checkNumber->start_from = $input['start_from'];
                $checkNumber->save();

                $output = ['success' => true,
                            'msg' => __("lang_v1.updated_success")
                            ];
            } catch (\Exception $e) {
                \Log::emergency("File:" . $e->getFile(). "Line:" . $e->getLine(). "Message:" . $e->getMessage());
            
                $output = ['success' => false,
                            'msg' => __("messages.something_went_wrong")
                        ];
            }

            return $output;
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        if (!auth()->user()->can('invoice_settings.access')) {
            abort(403, 'Unauthorized action.');
        }

        if (request()->ajax()) {
            try {
                $invoice = InvoiceNumbers::find($id);
                $invoice->delete();
                $output = [
                    'success' => true,
                    'msg' => __("invoice.deleted_success")
                ];
            } catch (\Exception $e) {
                \Log::emergency("File:" . $e->getFile(). "Line:" . $e->getLine(). "Message:" . $e->getMessage());
            
                $output = ['success' => false,
                            'msg' => __("messages.something_went_wrong")
                        ];
            }

            return $output;
        }
    }
}
