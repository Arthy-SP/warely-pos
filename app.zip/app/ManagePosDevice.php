<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ManagePosDevice extends Model
{
    
    protected $table = 'manage_pos_device';
    
    protected $fillable = [
        
        'device_id',
        'device_name',
        'device_type',
        'business_id',
        'business_location_id',
        'is_master',
        'device_fcm_token',
        'user_id'
    ];
    
    protected $casts = [
        'is_master' => 'boolean'
    ];

}