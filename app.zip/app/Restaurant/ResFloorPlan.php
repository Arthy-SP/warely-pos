<?php

namespace App\Restaurant;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use DB;

class ResFloorPlan extends Model
{
    use SoftDeletes;
    
    /**
     * The attributes that should be mutated to dates.
     *
     * @var array
     */
    
    
    /**
     * The attributes that aren't mass assignable.
     *
     * @var array
     */

    protected $guarded = ['id'];
    protected $table = 'res_floor_plan';
    protected $fillable = ['business_id', 'location_id', 'name', 'created_by'];

    public static function forCreateDropdown($business_id, $show_select = true)
    {
        $query = ResFloorPlan::join('business_locations','business_locations.id','=','res_floor_plan.location_id')
        ->select('res_floor_plan.id',DB::raw('CONCAT(business_locations.name," - ", res_floor_plan.name) AS name'))
        ->where('res_floor_plan.business_id', $business_id)
        ->orderBy('name');

        $floorPlan= $query->pluck('name', 'id');
        if ($show_select) {
            $floorPlan->prepend(__('messages.please_select'), '');
        }
        return $floorPlan;
    }

    public static function forEditDropdown($business_id, $location_id, $show_select = true)
    {
        $query = ResFloorPlan::where('business_id', $business_id)
                             ->where('location_id', $location_id);

        $floorPlan= $query->pluck('name', 'id');
        if ($show_select) {
            $floorPlan->prepend(__('messages.please_select'), '');
        }
        return $floorPlan;
    }
}
