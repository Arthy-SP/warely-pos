<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ServiceChargesSettings extends Model
{
    protected $table = 'service_charges_settings';

    protected $primaryKey = 'id';


    public $timestamps = false;

    protected $fillable = [
        'sms_otp_charge',
        'promotional_sms_charge',
        'whatsapp_message_charge',
        'email_charge',
        'country',
        "country_code"
    ];  

}
