<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class ProductGroup extends Model
{
    use SoftDeletes;

    /**
     * The attributes that aren't mass assignable.
     *
     * @var array
     */
    protected $guarded = ['id'];

    /**
     * Product Groups Dropdown
     *
     * @param int $business_id
     * @return array
     */
    public static function forDropdown($business_id)
    {
        $productGroups = ProductGroup::where('business_id', $business_id)
                            ->whereNull('deleted_at')
                            ->select('id', 'name')
                            ->get();

        $dropdown =  $productGroups->pluck('name', 'id');

        return $dropdown;
    }
}