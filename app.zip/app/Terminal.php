<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Terminal extends Model
{
    use SoftDeletes;

    /**
     * The attributes that aren't mass assignable.
     *
     * @var array
     */
    protected $guarded = ['id'];

    public static function forDropdown($location_id, $show_select = true)
    {
        $query = Terminal::where('location_id', $location_id);

        $terminal = $query->pluck('name', 'id');
        if ($show_select) {
            $terminal->prepend(__('messages.please_select'), '');
        }
        return $terminal;
    }
}