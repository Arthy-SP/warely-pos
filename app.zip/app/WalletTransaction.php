<?php
namespace App;
use Illuminate\Database\Eloquent\Model;

class WalletTransaction extends Model
{
    protected $table = 'wallet_transactions';

    protected $fillable = [
        'wallet_id',
        'transaction_type',
        'transaction_id',
        'transaction_date',
        'status',
        'amount',
        'payment_type',
        'service_type',
        'available_balance',
        'is_void',
        'void_reason',
        'description',
        'business_id',
        "phone"
    ];

    // Define any relationships, such as with Wallet or Business
    public function wallet()
    {
        return $this->belongsTo(Wallet::class);
    }

    public function business()
    {
        return $this->belongsTo(Business::class);
    }

}
